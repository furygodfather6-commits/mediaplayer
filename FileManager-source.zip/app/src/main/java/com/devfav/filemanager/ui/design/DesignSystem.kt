@file:OptIn(
    androidx.compose.foundation.ExperimentalFoundationApi::class,
    androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.animation.ExperimentalAnimationApi::class,
    androidx.compose.ui.ExperimentalComposeUiApi::class
)

package com.devfav.filemanager.ui.design

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.hapticfeedback.*
import androidx.compose.ui.input.pointer.*
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import androidx.compose.ui.window.Popup
import com.devfav.filemanager.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.text.input.ImeAction

// ════════════════════════════════════════════════════════════
// SECTION 1 — SPLIT SCREEN STATE SYSTEM
//             (Core — referenced everywhere in UI)
// ════════════════════════════════════════════════════════════

enum class SplitMode {
    SINGLE,          // Normal single pane
    SPLIT_VERTICAL,  // Left | Right (landscape)
    SPLIT_HORIZONTAL // Top | Bottom (portrait stack)
}

enum class ActivePane {
    PRIMARY, SECONDARY
}

@Stable
class SplitScreenState(
    initialMode: SplitMode = SplitMode.SINGLE,
) {
    var mode by mutableStateOf(initialMode)
    var activePane by mutableStateOf(ActivePane.PRIMARY)
    var splitRatio by mutableStateOf(0.5f)           // 0.3 → 0.7
    var isDraggingDivider by mutableStateOf(false)
    var primaryPath by mutableStateOf("/storage/emulated/0")
    var secondaryPath by mutableStateOf("/storage/emulated/0")

    val isSplit: Boolean get() = mode != SplitMode.SINGLE

    fun toggleSplit(screenWidth: Dp) {
        mode = when (mode) {
            SplitMode.SINGLE            -> if (screenWidth >= 600.dp)
                                               SplitMode.SPLIT_VERTICAL
                                           else
                                               SplitMode.SPLIT_HORIZONTAL
            SplitMode.SPLIT_VERTICAL   -> SplitMode.SINGLE
            SplitMode.SPLIT_HORIZONTAL -> SplitMode.SINGLE
        }
    }

    fun swapPanes() {
        val tmp = primaryPath
        primaryPath = secondaryPath
        secondaryPath = tmp
    }

    fun setActive(pane: ActivePane) {
        activePane = pane
    }

    fun clampRatio(delta: Float, totalPx: Float) {
        val newRatio = (splitRatio + delta / totalPx).coerceIn(0.28f, 0.72f)
        splitRatio = newRatio
    }
}

val LocalSplitScreen = staticCompositionLocalOf<SplitScreenState> {
    error("No SplitScreenState — wrap root with SplitScreenProvider")
}

@Composable
fun SplitScreenProvider(
    state: SplitScreenState = remember { SplitScreenState() },
    content: @Composable () -> Unit,
) {
    CompositionLocalProvider(LocalSplitScreen provides state) {
        content()
    }
}

// ── Split Screen Root Layout ────────────────────────────────
@Composable
fun SplitScreenLayout(
    state: SplitScreenState = LocalSplitScreen.current,
    primaryPane: @Composable () -> Unit,
    secondaryPane: @Composable () -> Unit,
    modifier: Modifier = Modifier,
) {
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val totalWidth = maxWidth
        val totalHeight = maxHeight

        when (state.mode) {

            // ── Single Pane ──────────────────────────────────
            SplitMode.SINGLE -> {
                primaryPane()
            }

            // ── Vertical Split (Left | Right) ────────────────
            SplitMode.SPLIT_VERTICAL -> {
                val primaryWidth = totalWidth * state.splitRatio

                Row(modifier = Modifier.fillMaxSize()) {

                    // Primary pane
                    Box(
                        modifier = Modifier
                            .width(primaryWidth)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(topEnd = 0.dp, bottomEnd = 0.dp))
                            .border(
                                width = if (state.activePane == ActivePane.PRIMARY)
                                    2.dp else 0.dp,
                                color = if (state.activePane == ActivePane.PRIMARY)
                                    MaterialTheme.colorScheme.primary
                                else Color.Transparent,
                                shape = RoundedCornerShape(topEnd = 0.dp)
                            )
                    ) {
                        primaryPane()
                        // Active pane indicator
                        SplitPaneIndicator(
                            isActive = state.activePane == ActivePane.PRIMARY,
                            label = "Pane A",
                            alignment = Alignment.TopStart,
                        )
                    }

                    // Draggable divider
                    SplitDivider(
                        isVertical = true,
                        isDragging = state.isDraggingDivider,
                        onDrag = { delta ->
                            with(density) {
                                state.clampRatio(delta, totalWidth.toPx())
                            }
                        },
                        onDragStart = {
                            state.isDraggingDivider = true
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        },
                        onDragEnd = {
                            state.isDraggingDivider = false
                        },
                    )

                    // Secondary pane
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .border(
                                width = if (state.activePane == ActivePane.SECONDARY)
                                    2.dp else 0.dp,
                                color = if (state.activePane == ActivePane.SECONDARY)
                                    MaterialTheme.colorScheme.primary
                                else Color.Transparent,
                                shape = RoundedCornerShape(topStart = 0.dp)
                            )
                    ) {
                        secondaryPane()
                        SplitPaneIndicator(
                            isActive = state.activePane == ActivePane.SECONDARY,
                            label = "Pane B",
                            alignment = Alignment.TopEnd,
                        )
                    }
                }
            }

            // ── Horizontal Split (Top | Bottom) ──────────────
            SplitMode.SPLIT_HORIZONTAL -> {
                val primaryHeight = totalHeight * state.splitRatio

                Column(modifier = Modifier.fillMaxSize()) {

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(primaryHeight)
                    ) {
                        primaryPane()
                        SplitPaneIndicator(
                            isActive = state.activePane == ActivePane.PRIMARY,
                            label = "Pane A",
                            alignment = Alignment.TopStart,
                        )
                    }

                    SplitDivider(
                        isVertical = false,
                        isDragging = state.isDraggingDivider,
                        onDrag = { delta ->
                            with(density) {
                                state.clampRatio(delta, totalHeight.toPx())
                            }
                        },
                        onDragStart = {
                            state.isDraggingDivider = true
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        },
                        onDragEnd = {
                            state.isDraggingDivider = false
                        },
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    ) {
                        secondaryPane()
                        SplitPaneIndicator(
                            isActive = state.activePane == ActivePane.SECONDARY,
                            label = "Pane B",
                            alignment = Alignment.TopEnd,
                        )
                    }
                }
            }
        }
    }
}

// ── Split Draggable Divider ─────────────────────────────────
@Composable
private fun SplitDivider(
    isVertical: Boolean,
    isDragging: Boolean,
    onDrag: (Float) -> Unit,
    onDragStart: () -> Unit,
    onDragEnd: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended
    val dividerColor by animateColorAsState(
        targetValue = if (isDragging)
            MaterialTheme.colorScheme.primary
        else
            ext.divider,
        animationSpec = tween(AnimationTokens.durationMD),
        label = "dividerColor",
    )
    val dividerThickness by animateDpAsState(
        targetValue = if (isDragging) 3.dp else 1.dp,
        animationSpec = tween(AnimationTokens.durationMD),
        label = "dividerThickness",
    )
    val handleScale by animateFloatAsState(
        targetValue = if (isDragging) 1.2f else 1f,
        animationSpec = spring(stiffness = AnimationTokens.springStiff),
        label = "handleScale",
    )

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .then(
                if (isVertical)
                    Modifier.fillMaxHeight().width(20.dp)
                else
                    Modifier.fillMaxWidth().height(20.dp)
            )
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { onDragStart() },
                    onDragEnd   = { onDragEnd() },
                    onDragCancel = { onDragEnd() },
                    onDrag      = { _, dragAmount ->
                        onDrag(if (isVertical) dragAmount.x else dragAmount.y)
                    },
                )
            },
    ) {
        // Thin line
        Box(
            modifier = Modifier
                .then(
                    if (isVertical)
                        Modifier.fillMaxHeight().width(dividerThickness)
                    else
                        Modifier.fillMaxWidth().height(dividerThickness)
                )
                .background(dividerColor),
        )

        // Drag handle pill
        Box(
            modifier = Modifier
                .scale(handleScale)
                .then(
                    if (isVertical)
                        Modifier.width(4.dp).height(40.dp)
                    else
                        Modifier.height(4.dp).width(40.dp)
                )
                .clip(RoundedCornerShape(999.dp))
                .background(
                    if (isDragging) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.outline
                ),
        )
    }
}

// ── Split Pane Active Indicator ─────────────────────────────
@Composable
private fun SplitPaneIndicator(
    isActive: Boolean,
    label: String,
    alignment: Alignment,
    modifier: Modifier = Modifier,
) {
    AnimatedVisibility(
        visible = isActive,
        enter   = fadeIn() + scaleIn(initialScale = 0.8f),
        exit    = fadeOut() + scaleOut(targetScale = 0.8f),
        modifier = modifier,
    ) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = alignment) {
            Surface(
                color  = MaterialTheme.colorScheme.primary,
                shape  = if (alignment == Alignment.TopStart)
                    RoundedCornerShape(bottomEnd = 8.dp)
                else
                    RoundedCornerShape(bottomStart = 8.dp),
                modifier = Modifier.padding(0.dp),
            ) {
                Text(
                    text  = label,
                    style = ExtraTypography.overline,
                    color = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.padding(
                        horizontal = SpacingTokens.sm,
                        vertical   = SpacingTokens.xxs,
                    ),
                )
            }
        }
    }
}

// ── Split Screen FAB Action Button ─────────────────────────
@Composable
fun SplitToggleFab(
    modifier: Modifier = Modifier,
) {
    val state = LocalSplitScreen.current
    val screenWidth = LocalConfiguration.current.screenWidthDp.dp

    SmallFloatingActionButton(
        onClick = { state.toggleSplit(screenWidth) },
        containerColor = MaterialTheme.colorScheme.secondaryContainer,
        contentColor   = MaterialTheme.colorScheme.onSecondaryContainer,
        shape          = ShapeTokens.fabShape,
        modifier       = modifier,
    ) {
        AnimatedContent(
            targetState = state.isSplit,
            label       = "splitIcon",
        ) { isSplit ->
            Icon(
                imageVector = if (isSplit)
                    Icons.Rounded.WebAsset
                else
                    Icons.Rounded.VerticalSplit,
                contentDescription = if (isSplit)
                    "Exit split screen"
                else
                    "Enter split screen",
                modifier = Modifier.size(SpacingTokens.iconSizeLg),
            )
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 2 — GLASS MORPHISM COMPONENTS
// ════════════════════════════════════════════════════════════

// ── Glass Card (primary surface) ───────────────────────────
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    selected: Boolean = false,
    enabled: Boolean = true,
    elevation: Dp = ElevationTokens.card,
    shape: Shape = ShapeTokens.cardShape,
    contentPadding: PaddingValues = PaddingValues(SpacingTokens.cardPadding),
    content: @Composable ColumnScope.() -> Unit,
) {
    val ext = MaterialTheme.extended
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val scale by animateFloatAsState(
        targetValue = when {
            isPressed  -> AnimationTokens.pressedScale
            selected   -> AnimationTokens.selectedScale
            else       -> AnimationTokens.normalScale
        },
        animationSpec = spring(stiffness = AnimationTokens.springStiff),
        label = "cardScale",
    )

    val borderColor by animateColorAsState(
        targetValue = when {
            selected -> ext.selectionBorder
            else     -> ext.glassBorder
        },
        animationSpec = tween(AnimationTokens.durationMD),
        label = "cardBorder",
    )

    val bgColor by animateColorAsState(
        targetValue = when {
            selected -> ext.selectionBackground
            else     -> ext.glassBackground
        },
        animationSpec = tween(AnimationTokens.durationMD),
        label = "cardBg",
    )

    Surface(
        onClick          = onClick ?: {},
        enabled          = enabled && onClick != null,
        modifier         = modifier
            .scale(scale)
            .shadow(
                elevation    = if (selected) ElevationTokens.cardHover else elevation,
                shape        = shape,
                ambientColor = if (selected) ext.glowPrimary else Color.Black,
                spotColor    = if (selected) ext.glowPrimary else Color.Black,
            ),
        shape            = shape,
        color            = bgColor,
        border           = BorderStroke(
            width = if (selected) 1.5.dp else 0.5.dp,
            color = borderColor,
        ),
        interactionSource = interactionSource,
        tonalElevation   = elevation,
    ) {
        Column(
            modifier = Modifier.padding(contentPadding),
            content  = content,
        )
    }
}

// ── Glass Surface (no click, raw container) ─────────────────
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    shape: Shape = ShapeTokens.cardShape,
    alpha: Float = 0.6f,
    borderAlpha: Float = 0.15f,
    content: @Composable BoxScope.() -> Unit,
) {
    val ext = MaterialTheme.extended
    Box(
        modifier = modifier
            .clip(shape)
            .background(ext.glassBackground.copy(alpha = alpha))
            .border(
                width = 0.5.dp,
                color = ext.glassBorder.copy(alpha = borderAlpha),
                shape = shape,
            ),
        content = content,
    )
}

// ── Frosted Panel (heavy blur effect via canvas) ────────────
@Composable
fun FrostedPanel(
    modifier: Modifier = Modifier,
    shape: Shape = ShapeTokens.bottomSheetShape,
    content: @Composable BoxScope.() -> Unit,
) {
    val ext = MaterialTheme.extended
    Box(
        modifier = modifier
            .clip(shape)
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        ext.surfaceSheet.copy(alpha = 0.92f),
                        ext.surfaceSheet.copy(alpha = 0.98f),
                    )
                )
            )
            .border(
                width = 0.5.dp,
                color = ext.glassBorderStrong,
                shape = shape,
            ),
        content = content,
    )
}

// ════════════════════════════════════════════════════════════
// SECTION 3 — BUTTON SYSTEM
// ════════════════════════════════════════════════════════════

// ── Primary Button (gradient fill) ─────────────────────────
@Composable
fun FmPrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    loading: Boolean = false,
    leadingIcon: @Composable (() -> Unit)? = null,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) AnimationTokens.pressedScale else 1f,
        animationSpec = spring(stiffness = AnimationTokens.springStiff),
        label = "btnScale",
    )
    val gradient = GradientTokens.primaryBrush()

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .scale(scale)
            .height(48.dp)
            .clip(ShapeTokens.chipShape)
            .then(
                if (enabled) Modifier.background(gradient)
                else Modifier.background(MaterialTheme.colorScheme.surfaceVariant)
            )
            .clickable(
                interactionSource = interactionSource,
                indication        = ripple(color = RawColors.White),
                enabled           = enabled && !loading,
                onClick           = onClick,
            )
            .padding(horizontal = SpacingTokens.xxl),
    ) {
        AnimatedContent(
            targetState = loading,
            label       = "btnContent",
        ) { isLoading ->
            if (isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(20.dp),
                    color    = RawColors.White,
                    strokeWidth = 2.dp,
                )
            } else {
                Row(
                    verticalAlignment    = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
                ) {
                    leadingIcon?.invoke()
                    Text(
                        text  = text,
                        style = MaterialTheme.typography.labelLarge,
                        color = if (enabled) RawColors.White
                                else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

// ── Secondary Button (outlined) ─────────────────────────────
@Composable
fun FmSecondaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    leadingIcon: @Composable (() -> Unit)? = null,
) {
    val ext = MaterialTheme.extended
    OutlinedButton(
        onClick  = onClick,
        enabled  = enabled,
        modifier = modifier.height(48.dp),
        shape    = ShapeTokens.chipShape,
        border   = BorderStroke(
            width = 1.5.dp,
            color = if (enabled) MaterialTheme.colorScheme.primary
                    else ext.divider,
        ),
        contentPadding = PaddingValues(horizontal = SpacingTokens.xxl),
    ) {
        if (leadingIcon != null) {
            leadingIcon()
            Spacer(Modifier.width(SpacingTokens.sm))
        }
        Text(
            text  = text,
            style = MaterialTheme.typography.labelLarge,
            color = if (enabled) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

// ── Ghost Button (text only) ────────────────────────────────
@Composable
fun FmGhostButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    color: Color = MaterialTheme.colorScheme.primary,
    leadingIcon: @Composable (() -> Unit)? = null,
) {
    TextButton(
        onClick  = onClick,
        enabled  = enabled,
        modifier = modifier.height(48.dp),
        shape    = ShapeTokens.chipShape,
        contentPadding = PaddingValues(horizontal = SpacingTokens.lg),
    ) {
        if (leadingIcon != null) {
            leadingIcon()
            Spacer(Modifier.width(SpacingTokens.xs))
        }
        Text(
            text  = text,
            style = MaterialTheme.typography.labelLarge,
            color = if (enabled) color
                    else MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

// ── Danger Button (destructive action) ─────────────────────
@Composable
fun FmDangerButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    loading: Boolean = false,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) AnimationTokens.pressedScale else 1f,
        animationSpec = spring(stiffness = AnimationTokens.springStiff),
        label = "dangerScale",
    )

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .scale(scale)
            .height(48.dp)
            .clip(ShapeTokens.chipShape)
            .background(
                if (enabled) MaterialTheme.colorScheme.error
                else MaterialTheme.colorScheme.surfaceVariant
            )
            .clickable(
                interactionSource = interactionSource,
                indication        = ripple(color = RawColors.White),
                enabled           = enabled && !loading,
                onClick           = onClick,
            )
            .padding(horizontal = SpacingTokens.xxl),
    ) {
        if (loading) {
            CircularProgressIndicator(
                modifier = Modifier.size(20.dp),
                color    = MaterialTheme.colorScheme.onError,
                strokeWidth = 2.dp,
            )
        } else {
            Text(
                text  = text,
                style = MaterialTheme.typography.labelLarge,
                color = if (enabled) MaterialTheme.colorScheme.onError
                        else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 4 — ICON SYSTEM
//             Premium icon wrapper with tint + badge
// ════════════════════════════════════════════════════════════

// ── Icon Button Premium ─────────────────────────────────────
@Composable
fun FmIconButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color = MaterialTheme.extended.iconPrimary,
    enabled: Boolean = true,
    badge: Int? = null,
    size: Dp = SpacingTokens.iconSizeLg,
    containerSize: Dp = 40.dp,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.88f else 1f,
        animationSpec = spring(stiffness = AnimationTokens.springStiff),
        label = "iconBtnScale",
    )

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(containerSize)
            .scale(scale)
            .clip(CircleShape)
            .clickable(
                interactionSource = interactionSource,
                indication        = ripple(
                    bounded = true,
                    color   = tint,
                ),
                enabled = enabled,
                onClick = onClick,
            ),
    ) {
        Icon(
            imageVector         = icon,
            contentDescription  = contentDescription,
            tint                = if (enabled) tint
                                  else MaterialTheme.colorScheme.onSurface
                                           .copy(alpha = 0.38f),
            modifier            = Modifier.size(size),
        )

        // Badge
        if (badge != null && badge > 0) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = 2.dp, y = (-2).dp)
                    .size(16.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.error),
            ) {
                Text(
                    text  = if (badge > 99) "99+" else badge.toString(),
                    style = ExtraTypography.extensionBadge,
                    color = MaterialTheme.colorScheme.onError,
                )
            }
        }
    }
}

// ── File Type Icon with color + extension badge ─────────────
@Composable
fun FileTypeIcon(
    fileType: FileIconType,
    modifier: Modifier = Modifier,
    size: Dp = SpacingTokens.iconSizeFolder,
    showBadge: Boolean = true,
) {
    val ext = MaterialTheme.extended
    val (icon, color, label) = remember(fileType) {
        fileTypeData(fileType, ext)
    }

    Box(
        contentAlignment = Alignment.BottomEnd,
        modifier         = modifier.size(size),
    ) {
        // Icon background glow
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(size)
                .clip(RoundedCornerShape(ShapeTokens.radiusMD))
                .background(color.copy(alpha = 0.12f)),
        ) {
            Icon(
                imageVector        = icon,
                contentDescription = label,
                tint               = color,
                modifier           = Modifier.size(size * 0.6f),
            )
        }

        // Extension badge
        if (showBadge && fileType is FileIconType.File) {
            Surface(
                color  = color,
                shape  = ShapeTokens.badgeShape,
                modifier = Modifier.offset(x = 2.dp, y = 2.dp),
            ) {
                Text(
                    text     = fileType.extension.uppercase()
                                   .take(4),
                    style    = ExtraTypography.extensionBadge,
                    color    = RawColors.White,
                    modifier = Modifier.padding(
                        horizontal = 3.dp,
                        vertical   = 1.dp,
                    ),
                )
            }
        }
    }
}

sealed class FileIconType(open val extension: String = "") {
    object Folder      : FileIconType()
    object FolderOpen  : FileIconType()
    data class File(override val extension: String) : FileIconType(extension)
    data class Image(override val extension: String = "jpg") : FileIconType(extension)
    data class Video(override val extension: String = "mp4") : FileIconType(extension)
    data class Audio(override val extension: String = "mp3") : FileIconType(extension)
    data class Document(override val extension: String = "pdf") : FileIconType(extension)
    data class Archive(override val extension: String = "zip") : FileIconType(extension)
    data class Apk(override val extension: String = "apk") : FileIconType(extension)
    data class Code(override val extension: String = "kt") : FileIconType(extension)
    data class Unknown(override val extension: String = "") : FileIconType(extension)
}

private fun fileTypeData(
    type: FileIconType,
    ext: ExtendedColors,
): Triple<androidx.compose.ui.graphics.vector.ImageVector, Color, String> {
    return when (type) {
        FileIconType.Folder, FileIconType.FolderOpen ->
            Triple(Icons.Rounded.Folder,       ext.folderColor,   "Folder")
        is FileIconType.File -> when {
            type.extension.matches(
                Regex("jpg|jpeg|png|gif|bmp|webp|svg", RegexOption.IGNORE_CASE)
            ) -> Triple(Icons.Rounded.Image,   ext.imageColor,    "Image")
            type.extension.matches(
                Regex("mp4|mkv|avi|mov|webm|flv", RegexOption.IGNORE_CASE)
            ) -> Triple(Icons.Rounded.PlayCircle, ext.videoColor, "Video")
            type.extension.matches(
                Regex("mp3|wav|flac|aac|ogg|m4a", RegexOption.IGNORE_CASE)
            ) -> Triple(Icons.Rounded.AudioFile, ext.audioColor,  "Audio")
            type.extension.matches(
                Regex("pdf|doc|docx|xls|xlsx|ppt|txt", RegexOption.IGNORE_CASE)
            ) -> Triple(Icons.Rounded.Description, ext.documentColor, "Document")
            type.extension.matches(
                Regex("zip|rar|7z|tar|gz|bz2", RegexOption.IGNORE_CASE)
            ) -> Triple(Icons.Rounded.FolderZip,  ext.archiveColor,  "Archive")
            type.extension.matches(
                Regex("apk|xapk|aab", RegexOption.IGNORE_CASE)
            ) -> Triple(Icons.Rounded.Android,    ext.apkColor,      "APK")
            type.extension.matches(
                Regex("kt|java|py|js|ts|html|css|xml|json", RegexOption.IGNORE_CASE)
            ) -> Triple(Icons.Rounded.Code,       ext.codeColor,     "Code")
            else -> Triple(Icons.Rounded.InsertDriveFile, ext.unknownColor, "File")
        }
        else -> Triple(Icons.Rounded.InsertDriveFile, ext.unknownColor, "File")
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 5 — CHIP SYSTEM
// ════════════════════════════════════════════════════════════

// ── Filter Chip Premium ─────────────────────────────────────
@Composable
fun FmFilterChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    leadingIcon: @Composable (() -> Unit)? = null,
    count: Int? = null,
) {
    val ext = MaterialTheme.extended
    val bgColor by animateColorAsState(
        targetValue = if (selected)
            MaterialTheme.colorScheme.primaryContainer
        else
            MaterialTheme.colorScheme.surfaceVariant,
        label = "chipBg",
    )
    val contentColor by animateColorAsState(
        targetValue = if (selected)
            MaterialTheme.colorScheme.onPrimaryContainer
        else
            MaterialTheme.colorScheme.onSurfaceVariant,
        label = "chipContent",
    )
    val borderColor by animateColorAsState(
        targetValue = if (selected)
            MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
        else
            ext.stroke,
        label = "chipBorder",
    )
    val scale by animateFloatAsState(
        targetValue = if (selected) 1.02f else 1f,
        animationSpec = spring(stiffness = AnimationTokens.springBouncy),
        label = "chipScale",
    )

    Surface(
        onClick = onClick,
        color   = bgColor,
        shape   = ShapeTokens.chipShape,
        border  = BorderStroke(1.dp, borderColor),
        modifier = modifier.scale(scale),
    ) {
        Row(
            verticalAlignment    = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            modifier = Modifier.padding(
                horizontal = SpacingTokens.md,
                vertical   = SpacingTokens.xs + 2.dp,
            ),
        ) {
            // Check icon anim
            AnimatedVisibility(
                visible = selected,
                enter   = fadeIn() + expandHorizontally(),
                exit    = fadeOut() + shrinkHorizontally(),
            ) {
                Icon(
                    imageVector        = Icons.Rounded.Check,
                    contentDescription = null,
                    tint               = contentColor,
                    modifier           = Modifier.size(14.dp),
                )
            }
            leadingIcon?.invoke()
            Text(
                text  = label,
                style = MaterialTheme.typography.labelMedium,
                color = contentColor,
            )
            if (count != null) {
                Surface(
                    color  = contentColor.copy(alpha = 0.2f),
                    shape  = ShapeTokens.badgeShape,
                ) {
                    Text(
                        text  = count.toString(),
                        style = ExtraTypography.extensionBadge.copy(
                            fontSize = 10.sp
                        ),
                        color    = contentColor,
                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp),
                    )
                }
            }
        }
    }
}

// ── Action Chip ─────────────────────────────────────────────
@Composable
fun FmActionChip(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.secondary,
) {
    val ext = MaterialTheme.extended
    Surface(
        onClick = onClick,
        color   = color.copy(alpha = 0.1f),
        shape   = ShapeTokens.chipShape,
        border  = BorderStroke(1.dp, color.copy(alpha = 0.3f)),
        modifier = modifier,
    ) {
        Row(
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(SpacingTokens.xs),
            modifier = Modifier.padding(
                horizontal = SpacingTokens.md,
                vertical   = SpacingTokens.xs + 2.dp,
            ),
        ) {
            Icon(
                imageVector        = icon,
                contentDescription = null,
                tint               = color,
                modifier           = Modifier.size(14.dp),
            )
            Text(
                text  = label,
                style = MaterialTheme.typography.labelMedium,
                color = color,
            )
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 6 — PREMIUM FAB SYSTEM
// ════════════════════════════════════════════════════════════

@Composable
fun FmMainFab(
    expanded: Boolean,
    onToggle: () -> Unit,
    onCreateFolder: () -> Unit,
    onCreateFile: () -> Unit,
    onPaste: (() -> Unit)? = null,
    onScan: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
) {
    val rotation by animateFloatAsState(
        targetValue   = if (expanded) 45f else 0f,
        animationSpec = spring(stiffness = AnimationTokens.springStiff),
        label         = "fabRotation",
    )

    Column(
        horizontalAlignment  = Alignment.End,
        verticalArrangement  = Arrangement.spacedBy(SpacingTokens.md),
        modifier             = modifier,
    ) {
        // Mini action buttons (expand up)
        AnimatedVisibility(
            visible = expanded,
            enter   = fadeIn() + slideInVertically(initialOffsetY = { it }),
            exit    = fadeOut() + slideOutVertically(targetOffsetY = { it }),
        ) {
            Column(
                horizontalAlignment  = Alignment.End,
                verticalArrangement  = Arrangement.spacedBy(SpacingTokens.sm),
            ) {
                // Scan QR/Barcode
                onScan?.let {
                    FabMiniItem(
                        label   = "Scan",
                        icon    = Icons.Rounded.QrCodeScanner,
                        color   = MaterialTheme.colorScheme.tertiary,
                        onClick = {
                            it()
                            onToggle()
                        },
                    )
                }
                // Paste clipboard
                onPaste?.let {
                    FabMiniItem(
                        label   = "Paste",
                        icon    = Icons.Rounded.ContentPaste,
                        color   = MaterialTheme.colorScheme.secondary,
                        onClick = {
                            it()
                            onToggle()
                        },
                    )
                }
                // Create file
                FabMiniItem(
                    label   = "New File",
                    icon    = Icons.Rounded.NoteAdd,
                    color   = MaterialTheme.colorScheme.secondary,
                    onClick = {
                        onCreateFile()
                        onToggle()
                    },
                )
                // Create folder
                FabMiniItem(
                    label   = "New Folder",
                    icon    = Icons.Rounded.CreateNewFolder,
                    color   = MaterialTheme.colorScheme.primary,
                    onClick = {
                        onCreateFolder()
                        onToggle()
                    },
                )
            }
        }

        // Main FAB
        FloatingActionButton(
            onClick          = onToggle,
            shape            = ShapeTokens.fabShape,
            containerColor   = MaterialTheme.colorScheme.primary,
            contentColor     = MaterialTheme.colorScheme.onPrimary,
            elevation        = FloatingActionButtonDefaults.elevation(
                defaultElevation = ElevationTokens.fab,
            ),
        ) {
            Icon(
                imageVector        = Icons.Rounded.Add,
                contentDescription = "Create",
                modifier           = Modifier.rotate(rotation),
            )
        }
    }
}

@Composable
private fun FabMiniItem(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    onClick: () -> Unit,
) {
    Row(
        verticalAlignment     = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
    ) {
        // Label pill
        Surface(
            color  = MaterialTheme.colorScheme.surface,
            shape  = ShapeTokens.tooltipShape,
            shadowElevation = ElevationTokens.tooltip,
        ) {
            Text(
                text     = label,
                style    = MaterialTheme.typography.labelMedium,
                color    = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(
                    horizontal = SpacingTokens.md,
                    vertical   = SpacingTokens.xs,
                ),
            )
        }

        // Mini FAB
        SmallFloatingActionButton(
            onClick          = onClick,
            shape            = ShapeTokens.fabShape,
            containerColor   = color.copy(alpha = 0.15f),
            contentColor     = color,
            elevation        = FloatingActionButtonDefaults.elevation(
                defaultElevation = ElevationTokens.sm,
            ),
        ) {
            Icon(
                imageVector        = icon,
                contentDescription = label,
                modifier           = Modifier.size(20.dp),
            )
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 7 — SEARCH BAR (Premium)
// ════════════════════════════════════════════════════════════

@Composable
fun FmSearchBar(
    query: String,
    onQueryChange: (String) -> Unit,
    onSearch: (String) -> Unit,
    active: Boolean,
    onActiveChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    placeholder: String = "Search files, folders...",
    onVoiceSearch: (() -> Unit)? = null,
) {
    val ext = MaterialTheme.extended

    val elevation by animateDpAsState(
        targetValue   = if (active) ElevationTokens.lg else ElevationTokens.sm,
        animationSpec = tween(AnimationTokens.durationMD),
        label         = "searchElevation",
    )

    Surface(
        shape           = ShapeTokens.searchShape,
        color           = MaterialTheme.colorScheme.surfaceVariant,
        shadowElevation = elevation,
        modifier        = modifier
            .fillMaxWidth()
            .height(SpacingTokens.searchBarHeight),
        border = if (active) BorderStroke(
            width = 1.5.dp,
            color = MaterialTheme.colorScheme.primary,
        ) else null,
    ) {
        Row(
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = SpacingTokens.lg),
        ) {
            // Search icon
            Icon(
                imageVector        = Icons.Rounded.Search,
                contentDescription = null,
                tint               = if (active)
                                         MaterialTheme.colorScheme.primary
                                     else
                                         ext.iconSecondary,
                modifier           = Modifier.size(SpacingTokens.iconSizeLg),
            )

            // Text field
            BasicTextField_Wrapper(
                value         = query,
                onValueChange = onQueryChange,
                onSearch      = onSearch,
                placeholder   = placeholder,
                modifier      = Modifier.weight(1f),
            )

            // Clear / Voice
            AnimatedContent(
                targetState = query.isNotEmpty(),
                label       = "searchAction",
            ) { hasQuery ->
                if (hasQuery) {
                    FmIconButton(
                        icon               = Icons.Rounded.Close,
                        contentDescription = "Clear",
                        onClick            = { onQueryChange("") },
                        tint               = ext.iconSecondary,
                        containerSize      = 32.dp,
                        size               = 18.dp,
                    )
                } else if (onVoiceSearch != null) {
                    FmIconButton(
                        icon               = Icons.Rounded.Mic,
                        contentDescription = "Voice search",
                        onClick            = onVoiceSearch,
                        tint               = ext.iconSecondary,
                        containerSize      = 32.dp,
                        size               = 18.dp,
                    )
                }
            }
        }
    }
}

// Minimal wrapper for BasicTextField styling
@Composable
private fun BasicTextField_Wrapper(
    value: String,
    onValueChange: (String) -> Unit,
    onSearch: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended
    androidx.compose.foundation.text.BasicTextField(
        value           = value,
        onValueChange   = onValueChange,
        singleLine      = true,
        textStyle       = MaterialTheme.typography.bodyLarge.copy(
            color = ext.textPrimary,
        ),
        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
            imeAction = androidx.compose.ui.text.input.ImeAction.Search,
        ),
        keyboardActions = androidx.compose.foundation.text.KeyboardActions(
            onSearch = { onSearch(value) },
        ),
        decorationBox  = { innerTextField ->
            Box(modifier = modifier) {
                if (value.isEmpty()) {
                    Text(
                        text  = placeholder,
                        style = MaterialTheme.typography.bodyLarge,
                        color = ext.textTertiary,
                    )
                }
                innerTextField()
            }
        },
        modifier = modifier,
    )
}

// ════════════════════════════════════════════════════════════
// SECTION 8 — SHIMMER LOADING
// ════════════════════════════════════════════════════════════

@Composable
fun ShimmerBox(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(ShapeTokens.radiusMD),
) {
    val ext = MaterialTheme.extended
    val infiniteTransition = rememberInfiniteTransition(label = "shimmer")
    val progress by infiniteTransition.animateFloat(
        initialValue   = 0f,
        targetValue    = 1f,
        animationSpec  = infiniteRepeatable(
            animation = tween(
                durationMillis = AnimationTokens.durationShimmer,
                easing         = LinearEasing,
            ),
        ),
        label = "shimmerProgress",
    )

    Box(
        modifier = modifier
            .clip(shape)
            .background(
                GradientTokens.shimmerBrush(
                    base      = ext.shimmerBase,
                    highlight = ext.shimmerHighlight,
                    progress  = progress,
                )
            ),
    )
}

// ── Shimmer File List Item ──────────────────────────────────
@Composable
fun ShimmerFileListItem(modifier: Modifier = Modifier) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .fillMaxWidth()
            .height(SpacingTokens.listItemHeight)
            .padding(
                horizontal = SpacingTokens.screenPaddingH,
                vertical   = SpacingTokens.sm,
            ),
    ) {
        ShimmerBox(modifier = Modifier.size(44.dp), shape = RoundedCornerShape(12.dp))
        Spacer(Modifier.width(SpacingTokens.lg))
        Column(verticalArrangement = Arrangement.spacedBy(SpacingTokens.xs)) {
            ShimmerBox(modifier = Modifier.width(160.dp).height(14.dp))
            ShimmerBox(modifier = Modifier.width(100.dp).height(11.dp))
        }
        Spacer(Modifier.weight(1f))
        ShimmerBox(modifier = Modifier.width(48.dp).height(11.dp))
    }
}

// ── Shimmer Grid Item ───────────────────────────────────────
@Composable
fun ShimmerFileGridItem(modifier: Modifier = Modifier) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
        modifier = modifier
            .width(SpacingTokens.gridItemSize)
            .padding(SpacingTokens.xs),
    ) {
        ShimmerBox(
            modifier = Modifier
                .fillMaxWidth()
                .height(110.dp),
            shape = RoundedCornerShape(ShapeTokens.radiusLG),
        )
        ShimmerBox(modifier = Modifier.width(100.dp).height(13.dp))
        ShimmerBox(modifier = Modifier.width(60.dp).height(11.dp))
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 9 — EMPTY STATE
// ════════════════════════════════════════════════════════════

@Composable
fun EmptyStateView(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector = Icons.Rounded.FolderOpen,
    action: Pair<String, () -> Unit>? = null,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended
    val infiniteTransition = rememberInfiniteTransition(label = "emptyAnim")
    val floatAnim by infiniteTransition.animateFloat(
        initialValue  = 0f,
        targetValue   = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "emptyFloat",
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = modifier
            .fillMaxSize()
            .padding(SpacingTokens.xxxl),
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(100.dp)
                .offset(y = (floatAnim * (-8f)).dp)
                .clip(RoundedCornerShape(28.dp))
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.primaryContainer,
                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0f),
                        )
                    )
                ),
        ) {
            Icon(
                imageVector        = icon,
                contentDescription = null,
                tint               = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f),
                modifier           = Modifier.size(52.dp),
            )
        }

        Spacer(Modifier.height(SpacingTokens.xxl))

        Text(
            text      = title,
            style     = MaterialTheme.typography.titleMedium,
            color     = ext.textPrimary,
            textAlign = TextAlign.Center,
        )

        Spacer(Modifier.height(SpacingTokens.sm))

        Text(
            text      = subtitle,
            style     = MaterialTheme.typography.bodyMedium,
            color     = ext.textSecondary,
            textAlign = TextAlign.Center,
        )

        if (action != null) {
            Spacer(Modifier.height(SpacingTokens.xxl))
            FmPrimaryButton(
                text    = action.first,
                onClick = action.second,
            )
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 10 — PREMIUM BOTTOM SHEET SCAFFOLD
// ════════════════════════════════════════════════════════════

@Composable
fun FmBottomSheet(
    visible: Boolean,
    onDismiss: () -> Unit,
    title: String? = null,
    subtitle: String? = null,
    showDragHandle: Boolean = true,
    skipPartiallyExpanded: Boolean = true,
    content: @Composable ColumnScope.() -> Unit,
) {
    val ext = MaterialTheme.extended
    val sheetState = rememberModalBottomSheetState(
        skipPartiallyExpanded = skipPartiallyExpanded,
    )

    if (visible) {
        ModalBottomSheet(
            onDismissRequest   = onDismiss,
            sheetState         = sheetState,
            shape              = ShapeTokens.bottomSheetShape,
            containerColor     = ext.surfaceSheet,
            dragHandle         = if (showDragHandle) {
                {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier         = Modifier
                            .fillMaxWidth()
                            .padding(top = SpacingTokens.md, bottom = SpacingTokens.sm),
                    ) {
                        Box(
                            modifier = Modifier
                                .width(36.dp)
                                .height(4.dp)
                                .clip(RoundedCornerShape(999.dp))
                                .background(ext.stroke),
                        )
                    }
                }
            } else null,
        ) {
            // Optional header
            if (title != null || subtitle != null) {
                Column(
                    modifier = Modifier.padding(
                        horizontal = SpacingTokens.screenPaddingH,
                        vertical   = SpacingTokens.sm,
                    ),
                ) {
                    title?.let {
                        Text(
                            text  = it,
                            style = MaterialTheme.typography.titleMedium,
                            color = ext.textPrimary,
                        )
                    }
                    subtitle?.let {
                        Text(
                            text  = it,
                            style = MaterialTheme.typography.bodySmall,
                            color = ext.textSecondary,
                        )
                    }
                }
                FmDivider(modifier = Modifier.padding(vertical = SpacingTokens.sm))
            }
            content()
            // Bottom nav inset
            Spacer(
                Modifier.height(
                    WindowInsets.navigationBars.asPaddingValues()
                        .calculateBottomPadding()
                )
            )
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 11 — DIVIDERS & STROKES
// ════════════════════════════════════════════════════════════

@Composable
fun FmDivider(
    modifier: Modifier = Modifier,
    thickness: Dp = 0.5.dp,
    color: Color = MaterialTheme.extended.divider,
    startIndent: Dp = 0.dp,
) {
    HorizontalDivider(
        modifier  = modifier.padding(start = startIndent),
        thickness = thickness,
        color     = color,
    )
}

@Composable
fun FmVerticalDivider(
    modifier: Modifier = Modifier,
    thickness: Dp = 0.5.dp,
    color: Color = MaterialTheme.extended.divider,
) {
    VerticalDivider(
        modifier  = modifier,
        thickness = thickness,
        color     = color,
    )
}

// ════════════════════════════════════════════════════════════
// SECTION 12 — PROGRESS INDICATORS
// ════════════════════════════════════════════════════════════

// ── Linear Progress Bar (for copy/zip operations) ───────────
@Composable
fun FmLinearProgress(
    progress: Float?,          // null = indeterminate
    modifier: Modifier = Modifier,
    trackColor: Color = MaterialTheme.colorScheme.surfaceVariant,
    label: String? = null,
) {
    val gradient = GradientTokens.primaryBrush()

    Column(
        verticalArrangement = Arrangement.spacedBy(SpacingTokens.xs),
        modifier            = modifier,
    ) {
        if (label != null) {
            Row(
                modifier              = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    text  = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.extended.textSecondary,
                )
                if (progress != null) {
                    Text(
                        text  = "${(progress * 100).toInt()}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(999.dp))
                .background(trackColor),
        ) {
            if (progress != null) {
                val animProgress by animateFloatAsState(
                    targetValue   = progress.coerceIn(0f, 1f),
                    animationSpec = tween(AnimationTokens.durationLG),
                    label         = "progress",
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth(animProgress)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(999.dp))
                        .background(gradient),
                )
            } else {
                // Indeterminate shimmer
                ShimmerBox(
                    modifier = Modifier.fillMaxSize(),
                    shape    = RoundedCornerShape(999.dp),
                )
            }
        }
    }
}

// ── Circular Progress (compact) ─────────────────────────────
@Composable
fun FmCircularProgress(
    progress: Float? = null,
    size: Dp = 40.dp,
    strokeWidth: Dp = 3.dp,
    color: Color = MaterialTheme.colorScheme.primary,
) {
    if (progress != null) {
        val animProgress by animateFloatAsState(
            targetValue   = progress.coerceIn(0f, 1f),
            animationSpec = tween(AnimationTokens.durationLG),
            label         = "circProgress",
        )
        CircularProgressIndicator(
            progress    = { animProgress },
            modifier    = Modifier.size(size),
            color       = color,
            strokeWidth = strokeWidth,
            trackColor  = color.copy(alpha = 0.15f),
        )
    } else {
        CircularProgressIndicator(
            modifier    = Modifier.size(size),
            color       = color,
            strokeWidth = strokeWidth,
        )
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 13 — SELECTION CHECKBOX (Premium animated)
// ════════════════════════════════════════════════════════════

@Composable
fun FmCheckbox(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended
    val scale by animateFloatAsState(
        targetValue   = if (checked) 1.1f else 1f,
        animationSpec = spring(stiffness = AnimationTokens.springBouncy),
        label         = "checkScale",
    )
    val bgColor by animateColorAsState(
        targetValue   = if (checked) MaterialTheme.colorScheme.primary
                        else Color.Transparent,
        animationSpec = tween(AnimationTokens.durationSM),
        label         = "checkBg",
    )
    val borderColor by animateColorAsState(
        targetValue   = if (checked) MaterialTheme.colorScheme.primary
                        else ext.stroke,
        label         = "checkBorder",
    )

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(22.dp)
            .scale(scale)
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .border(
                width = 1.5.dp,
                color = borderColor,
                shape = RoundedCornerShape(6.dp),
            )
            .clickable { onCheckedChange(!checked) },
    ) {
        AnimatedVisibility(
            visible = checked,
            enter   = fadeIn() + scaleIn(initialScale = 0.6f),
            exit    = fadeOut() + scaleOut(targetScale = 0.6f),
        ) {
            Icon(
                imageVector        = Icons.Rounded.Check,
                contentDescription = null,
                tint               = MaterialTheme.colorScheme.onPrimary,
                modifier           = Modifier.size(14.dp),
            )
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 14 — TOOLTIP
// ════════════════════════════════════════════════════════════

@Composable
fun FmTooltip(
    text: String,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    var visible by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val ext = MaterialTheme.extended

    Box(
        modifier = modifier.pointerInput(Unit) {
            detectTapGestures(
                onLongPress = {
                    visible = true
                    scope.launch {
                        delay(2000)
                        visible = false
                    }
                },
            )
        },
    ) {
        content()
        AnimatedVisibility(
            visible  = visible,
            enter    = fadeIn() + slideInVertically(initialOffsetY = { it / 2 }),
            exit     = fadeOut() + slideOutVertically(targetOffsetY = { it / 2 }),
            modifier = Modifier.align(Alignment.TopCenter).offset(y = (-36).dp),
        ) {
            Surface(
                color           = ext.textPrimary.copy(alpha = 0.9f),
                shape           = ShapeTokens.tooltipShape,
                shadowElevation = ElevationTokens.tooltip,
            ) {
                Text(
                    text     = text,
                    style    = MaterialTheme.typography.labelSmall,
                    color    = ext.surfaceSheet,
                    modifier = Modifier.padding(
                        horizontal = SpacingTokens.sm,
                        vertical   = SpacingTokens.xxs + 1.dp,
                    ),
                )
            }
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 15 — STORAGE MINI BAR (shared UI token)
// ════════════════════════════════════════════════════════════

data class StorageSegment(
    val label: String,
    val fraction: Float,
    val color: Color,
)

@Composable
fun StorageMiniBar(
    segments: List<StorageSegment>,
    totalLabel: String,
    usedLabel: String,
    freeLabel: String,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended
    Column(
        verticalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
        modifier            = modifier,
    ) {
        // Labels
        Row(
            modifier              = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                text  = "Storage",
                style = MaterialTheme.typography.labelMedium,
                color = ext.textSecondary,
            )
            Text(
                text  = totalLabel,
                style = MaterialTheme.typography.labelMedium,
                color = ext.textPrimary,
            )
        }

        // Segmented bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(999.dp))
                .background(ext.storageFree),
        ) {
            segments.forEach { seg ->
                val animFraction by animateFloatAsState(
                    targetValue   = seg.fraction,
                    animationSpec = tween(AnimationTokens.durationXL, easing = FastOutSlowInEasing),
                    label         = "storageSeg${seg.label}",
                )
                Box(
                    modifier = Modifier
                        .weight(animFraction.coerceAtLeast(0.001f))
                        .fillMaxHeight()
                        .background(seg.color),
                )
            }
        }

        // Legend
        Row(
            horizontalArrangement = Arrangement.spacedBy(SpacingTokens.lg),
        ) {
            StorageLegendDot(color = ext.storageUsed,    label = "Used: $usedLabel")
            StorageLegendDot(color = ext.storageFree,    label = "Free: $freeLabel")
        }
    }
}

@Composable
private fun StorageLegendDot(color: Color, label: String) {
    Row(
        verticalAlignment     = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.xxs + 2.dp),
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color),
        )
        Text(
            text  = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.extended.textSecondary,
        )
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 16 — VIEW MODE TOGGLE (Grid / List / Compact)
// ════════════════════════════════════════════════════════════

enum class ViewMode { LIST, GRID, COMPACT }

@Composable
fun ViewModeToggle(
    current: ViewMode,
    onChange: (ViewMode) -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended

    Surface(
        color  = MaterialTheme.colorScheme.surfaceVariant,
        shape  = ShapeTokens.chipShape,
        modifier = modifier,
    ) {
        Row(modifier = Modifier.padding(3.dp)) {
            ViewMode.entries.forEach { mode ->
                val selected = current == mode
                val bgColor by animateColorAsState(
                    targetValue   = if (selected)
                                        MaterialTheme.colorScheme.surface
                                    else
                                        Color.Transparent,
                    animationSpec = tween(AnimationTokens.durationSM),
                    label         = "viewMode${mode.name}",
                )
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(34.dp)
                        .clip(ShapeTokens.chipShape)
                        .background(bgColor)
                        .clickable { onChange(mode) },
                ) {
                    Icon(
                        imageVector = when (mode) {
                            ViewMode.LIST    -> Icons.Rounded.ViewList
                            ViewMode.GRID    -> Icons.Rounded.GridView
                            ViewMode.COMPACT -> Icons.Rounded.ViewHeadline
                        },
                        contentDescription = mode.name,
                        tint               = if (selected)
                                                 MaterialTheme.colorScheme.primary
                                             else
                                                 ext.iconSecondary,
                        modifier           = Modifier.size(18.dp),
                    )
                }
            }
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 17 — MODIFIER EXTENSIONS (dev utilities)
// ════════════════════════════════════════════════════════════

// Glow shadow modifier
fun Modifier.glowShadow(
    color: Color,
    borderRadius: Dp = 16.dp,
    glowRadius: Dp = 12.dp,
    offsetY: Dp = 4.dp,
    alpha: Float = 0.3f,
): Modifier = this.drawBehind {
    drawIntoCanvas { canvas ->
        val paint = Paint().apply {
            asFrameworkPaint().apply {
                isAntiAlias = true
                this.color  = android.graphics.Color.TRANSPARENT
                setShadowLayer(
                    glowRadius.toPx(),
                    0f,
                    offsetY.toPx(),
                    android.graphics.Color.argb(
                        (alpha * 255).toInt(),
                        (color.red * 255).toInt(),
                        (color.green * 255).toInt(),
                        (color.blue * 255).toInt(),
                    )
                )
            }
        }
        canvas.drawRoundRect(
            left   = 0f,
            top    = 0f,
            right  = size.width,
            bottom = size.height,
            radiusX = borderRadius.toPx(),
            radiusY = borderRadius.toPx(),
            paint   = paint,
        )
    }
}

// Conditional modifier
fun Modifier.conditional(
    condition: Boolean,
    ifTrue: Modifier.() -> Modifier,
    ifFalse: (Modifier.() -> Modifier)? = null,
): Modifier = if (condition) ifTrue() else ifFalse?.invoke(this) ?: this

// Animated border modifier (selected state)
fun Modifier.animatedBorder(
    selected: Boolean,
    selectedColor: Color,
    idleColor: Color = Color.Transparent,
    width: Dp = 1.5.dp,
    shape: Shape = RoundedCornerShape(16.dp),
): Modifier = composed {
    val color by animateColorAsState(
        targetValue   = if (selected) selectedColor else idleColor,
        animationSpec = tween(AnimationTokens.durationMD),
        label         = "animBorder",
    )
    this.border(width, color, shape)
}

// ════════════════════════════════════════════════════════════
// END OF FILE 2 — DesignSystem.kt
// Next → File 3: FileManagerState.kt
// (Data models, ViewState, SortType, SelectionState,
//  FileItem, BreadcrumbState, ClipboardState)
// ════════════════════════════════════════════════════════════

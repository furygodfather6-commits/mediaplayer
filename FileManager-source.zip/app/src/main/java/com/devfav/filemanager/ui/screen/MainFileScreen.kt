@file:OptIn(
    androidx.compose.foundation.ExperimentalFoundationApi::class,
    androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.animation.ExperimentalAnimationApi::class,
    androidx.compose.ui.ExperimentalComposeUiApi::class
)

package com.devfav.filemanager.ui.screen


import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.hapticfeedback.*
import androidx.compose.ui.input.nestedscroll.*
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import androidx.compose.ui.zIndex
import com.devfav.filemanager.ui.design.*
import com.devfav.filemanager.ui.state.*
import com.devfav.filemanager.ui.theme.*
import kotlinx.coroutines.launch
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.gestures.*
import androidx.compose.ui.text.input.ImeAction

// ════════════════════════════════════════════════════════════
// SECTION 1 — BOTTOM NAV DESTINATIONS
// ════════════════════════════════════════════════════════════

enum class NavDestination(
    val label: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val iconSelected: androidx.compose.ui.graphics.vector.ImageVector,
    val route: String,
) {
    HOME(
        label        = "Home",
        icon         = Icons.Rounded.HomeWork,
        iconSelected = Icons.Rounded.Home,
        route        = "home",
    ),
    RECENTS(
        label        = "Recents",
        icon         = Icons.Rounded.History,
        iconSelected = Icons.Rounded.History,
        route        = "recents",
    ),
    FAVORITES(
        label        = "Favorites",
        icon         = Icons.Rounded.StarBorder,
        iconSelected = Icons.Rounded.Star,
        route        = "favorites",
    ),
    STORAGE(
        label        = "Storage",
        icon         = Icons.Rounded.Storage,
        iconSelected = Icons.Rounded.Storage,
        route        = "storage",
    ),
}

// ════════════════════════════════════════════════════════════
// SECTION 2 — MAIN FILE SCREEN ROOT
// ════════════════════════════════════════════════════════════

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainFileScreen(
    state: FileManagerState = LocalFileManagerState.current,
    themeState: ThemeState  = rememberThemeState(),
    onNavigateToSearch: () -> Unit = {},
    onFileOpen: (FileItem) -> Unit = {},
) {
    val scope          = rememberCoroutineScope()
    val haptic         = LocalHapticFeedback.current
    val configuration  = LocalConfiguration.current
    val screenWidth    = configuration.screenWidthDp.dp
    val isLandscape    = configuration.screenWidthDp > configuration.screenHeightDp
    val isDark         = themeState.isDark()
    val ext            = MaterialTheme.extended

    // Scroll behavior for TopBar
    val scrollBehavior = TopAppBarDefaults.exitUntilCollapsedScrollBehavior(
        rememberTopAppBarState()
    )

    // Current nav destination
    var currentNav by remember { mutableStateOf(NavDestination.HOME) }

    // Back handler
    BackHandler(enabled = true) {
        when {
            state.activePane.selection.isSelectionMode -> {
                state.activePane.selection.exitSelectionMode()
            }
            state.search.isActive -> {
                state.search.deactivate()
            }
            state.isFabExpanded -> {
                state.collapseFab()
            }
            state.splitScreen.isSplit &&
            state.splitScreen.activePane == ActivePane.SECONDARY -> {
                if (!state.secondaryPane.goBack()) {
                    state.splitScreen.setActive(ActivePane.PRIMARY)
                }
            }
            else -> {
                state.goBack()
            }
        }
    }

    // Snackbar host
    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(state.snackbarMessage) {
        state.snackbarMessage?.let { msg ->
            scope.launch {
                snackbarHostState.showSnackbar(
                    message     = msg.message,
                    actionLabel = msg.action?.first,
                    duration    = SnackbarDuration.Short,
                )
                state.dismissSnackbar()
            }
        }
    }

    // Auto split on landscape
    LaunchedEffect(isLandscape) {
        if (isLandscape && !state.splitScreen.isSplit) {
            state.splitScreen.mode = SplitMode.SPLIT_VERTICAL
        } else if (!isLandscape && state.splitScreen.mode == SplitMode.SPLIT_VERTICAL) {
            state.splitScreen.mode = SplitMode.SINGLE
        }
    }

    SplitScreenProvider(state = state.splitScreen) {
        Scaffold(
            modifier = Modifier
                .fillMaxSize()
                .nestedScroll(scrollBehavior.nestedScrollConnection),

            // ── Top Bar ─────────────────────────────────────
            topBar = {
                FileManagerTopBar(
                    state          = state,
                    themeState     = themeState,
                    scrollBehavior = scrollBehavior,
                    onSearchClick  = {
                        state.search.activate()
                        onNavigateToSearch()
                    },
                )
            },

            // ── Bottom Nav ──────────────────────────────────
            bottomBar = {
                AnimatedVisibility(
                    visible = !state.activePane.selection.isSelectionMode,
                    enter   = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                    exit    = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
                ) {
                    FileManagerBottomNav(
                        current  = currentNav,
                        onChange = { currentNav = it },
                        state    = state,
                    )
                }
            },

            // ── Selection Toolbar (replaces bottom nav) ──────
            // Handled inside bottomBar AnimatedVisibility above

            // ── FAB ─────────────────────────────────────────
            floatingActionButton = {
                AnimatedVisibility(
                    visible = !state.activePane.selection.isSelectionMode &&
                              !state.search.isActive,
                    enter   = scaleIn() + fadeIn(),
                    exit    = scaleOut() + fadeOut(),
                ) {
                    Column(
                        horizontalAlignment = Alignment.End,
                        verticalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
                    ) {
                        // Split toggle mini FAB
                        SplitToggleFab()
                        // Main FAB
                        FmMainFab(
                            expanded        = state.isFabExpanded,
                            onToggle        = { state.toggleFab() },
                            onCreateFolder  = {
                                state.showCreateFolderDialog = true
                            },
                            onCreateFile    = {
                                state.showCreateFileDialog = true
                            },
                            onPaste         = if (state.canPaste()) {
                                { /* trigger paste operation */ }
                            } else null,
                        )
                    }
                }
            },

            // ── Snackbar ─────────────────────────────────────
            snackbarHost = {
                FmSnackbarHost(
                    hostState = snackbarHostState,
                    message   = state.snackbarMessage,
                )
            },

            containerColor = ext.gradientSurface.first(),
        ) { paddingValues ->

            // ── Main Content Area ────────────────────────────
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(
                        Brush.verticalGradient(
                            colors = ext.gradientSurface,
                        )
                    ),
            ) {
                // FAB scrim
                AnimatedVisibility(
                    visible  = state.isFabExpanded,
                    enter    = fadeIn(),
                    exit     = fadeOut(),
                    modifier = Modifier.fillMaxSize().zIndex(1f),
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(RawColors.OverlayMedium)
                            .clickable(
                                indication        = null,
                                interactionSource = remember { MutableInteractionSource() },
                            ) { state.collapseFab() },
                    )
                }

                // ── Split Screen Content ─────────────────────
                SplitScreenLayout(
                    state         = state.splitScreen,
                    primaryPane   = {
                        PaneContent(
                            paneState    = state.primaryPane,
                            fmState      = state,
                            currentNav   = currentNav,
                            onFileOpen   = onFileOpen,
                            isActive     = state.splitScreen.activePane == ActivePane.PRIMARY,
                            onPaneFocus  = {
                                state.splitScreen.setActive(ActivePane.PRIMARY)
                            },
                        )
                    },
                    secondaryPane = {
                        PaneContent(
                            paneState    = state.secondaryPane,
                            fmState      = state,
                            currentNav   = currentNav,
                            onFileOpen   = onFileOpen,
                            isActive     = state.splitScreen.activePane == ActivePane.SECONDARY,
                            onPaneFocus  = {
                                state.splitScreen.setActive(ActivePane.SECONDARY)
                            },
                        )
                    },
                )

                // ── Selection Multi Toolbar ──────────────────
                AnimatedVisibility(
                    visible  = state.activePane.selection.isSelectionMode,
                    enter    = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                    exit     = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
                    modifier = Modifier.align(Alignment.BottomCenter).zIndex(2f),
                ) {
                    SelectionToolbar(state = state)
                }
            }
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 3 — PANE CONTENT (used in both split panes)
// ════════════════════════════════════════════════════════════

@Composable
private fun PaneContent(
    paneState: PaneState,
    fmState: FileManagerState,
    currentNav: NavDestination,
    onFileOpen: (FileItem) -> Unit,
    isActive: Boolean,
    onPaneFocus: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .clickable(
                indication        = null,
                interactionSource = remember { MutableInteractionSource() },
                onClick           = onPaneFocus,
            ),
    ) {
        // ── Breadcrumb Navigation ────────────────────────────
        BreadcrumbNavBar(
            breadcrumb = paneState.breadcrumb,
            onSegmentClick = { segment ->
                paneState.navigateTo(segment.path)
            },
            onNavigateUp = { paneState.goBack() },
            modifier = Modifier.fillMaxWidth(),
        )

        // ── Storage Bar (only on HOME, primary pane) ─────────
        AnimatedVisibility(
            visible = currentNav == NavDestination.HOME &&
                      !fmState.splitScreen.isSplit,
        ) {
            StorageBarSection(
                storageState = fmState.storage,
                modifier     = Modifier
                    .fillMaxWidth()
                    .padding(
                        horizontal = SpacingTokens.screenPaddingH,
                        vertical   = SpacingTokens.sm,
                    ),
            )
        }

        // ── Quick Access (HOME only, single pane) ────────────
        AnimatedVisibility(
            visible = currentNav == NavDestination.HOME &&
                      !fmState.splitScreen.isSplit &&
                      paneState.breadcrumb.stack.size <= 1,
        ) {
            QuickAccessSection(
                onNavigate = { path -> paneState.navigateTo(path) },
                modifier   = Modifier.fillMaxWidth(),
            )
        }

        // ── Sort + Filter + View Mode Bar ────────────────────
        SortFilterBar(
            paneState = paneState,
            fmState   = fmState,
        )

        // ── File List/Grid Content ───────────────────────────
        // (rendered in File 5 — FileGridListView)
        FileContentArea(
            paneState  = paneState,
            fmState    = fmState,
            onFileOpen = onFileOpen,
        )
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 4 — TOP BAR
// ════════════════════════════════════════════════════════════

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FileManagerTopBar(
    state: FileManagerState,
    themeState: ThemeState,
    scrollBehavior: TopAppBarScrollBehavior,
    onSearchClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext    = MaterialTheme.extended
    val isDark = themeState.isDark()
    val selection = state.activePane.selection

    // Animated title based on selection mode
    val titleText = when {
        selection.isSelectionMode ->
            "${selection.selectedCount} Selected"
        else -> "File Manager"
    }

    LargeTopAppBar(
        title = {
            AnimatedContent(
                targetState = titleText,
                transitionSpec = {
                    (slideInVertically { -it } + fadeIn()).togetherWith(
                        slideOutVertically { it } + fadeOut()
                    )
                },
                label = "topBarTitle",
            ) { title ->
                Column {
                    Text(
                        text  = title,
                        style = MaterialTheme.typography.headlineSmall,
                        color = ext.textPrimary,
                        maxLines   = 1,
                        overflow   = TextOverflow.Ellipsis,
                    )
                    // Subtitle — active path (collapsed state)
                    AnimatedVisibility(
                        visible = scrollBehavior.state.collapsedFraction > 0.5f &&
                                  !selection.isSelectionMode,
                    ) {
                        Text(
                            text  = state.activePane.breadcrumb.getDisplayPath(),
                            style = ExtraTypography.pathStyle,
                            color = ext.textSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
        },
        navigationIcon = {
            AnimatedContent(
                targetState = selection.isSelectionMode,
                label       = "navIcon",
            ) { isSelecting ->
                if (isSelecting) {
                    FmIconButton(
                        icon               = Icons.Rounded.Close,
                        contentDescription = "Exit selection",
                        onClick            = { selection.exitSelectionMode() },
                        tint               = ext.textPrimary,
                    )
                } else {
                    // App logo / hamburger
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(ShapeTokens.radiusMD))
                            .background(
                                Brush.linearGradient(
                                    colors = ext.gradientPrimary,
                                )
                            ),
                    ) {
                        Icon(
                            imageVector        = Icons.Rounded.Folder,
                            contentDescription = "App logo",
                            tint               = RawColors.White,
                            modifier           = Modifier.size(22.dp),
                        )
                    }
                }
            }
        },
        actions = {
            // Selection mode actions
            AnimatedContent(
                targetState = selection.isSelectionMode,
                label       = "topBarActions",
            ) { isSelecting ->
                if (isSelecting) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.xxs),
                    ) {
                        // Select all
                        FmIconButton(
                            icon               = Icons.Rounded.SelectAll,
                            contentDescription = "Select all",
                            onClick            = {
                                selection.selectAll(state.activePane.displayItems)
                            },
                            tint = ext.textPrimary,
                        )
                        // Invert selection
                        FmIconButton(
                            icon               = Icons.Rounded.Deselect,
                            contentDescription = "Invert selection",
                            onClick            = {
                                val all = state.activePane.displayItems
                                val notSelected = all.filter {
                                    !selection.isSelected(it.id)
                                }
                                selection.deselectAll()
                                notSelected.forEach { selection.toggleSelection(it.id) }
                                if (notSelected.isNotEmpty()) {
                                    selection.enterSelectionMode(notSelected.first().id)
                                }
                            },
                            tint = ext.textPrimary,
                        )
                    }
                } else {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.xxs),
                    ) {
                        // Search
                        FmIconButton(
                            icon               = Icons.Rounded.Search,
                            contentDescription = "Search",
                            onClick            = onSearchClick,
                            tint               = ext.iconPrimary,
                        )
                        // Theme toggle
                        FmIconButton(
                            icon               = if (isDark)
                                                     Icons.Rounded.LightMode
                                                 else
                                                     Icons.Rounded.DarkMode,
                            contentDescription = "Toggle theme",
                            onClick            = { themeState.toggle() },
                            tint               = ext.iconPrimary,
                        )
                        // Overflow menu
                        TopBarOverflowMenu(state = state)
                    }
                }
            }
        },
        colors = TopAppBarDefaults.largeTopAppBarColors(
            containerColor          = Color.Transparent,
            scrolledContainerColor  = ext.surfaceElevated.copy(alpha = 0.95f),
            titleContentColor       = ext.textPrimary,
            navigationIconContentColor = ext.textPrimary,
            actionIconContentColor  = ext.iconPrimary,
        ),
        scrollBehavior = scrollBehavior,
        modifier       = modifier,
    )
}

// ── Top Bar Overflow Menu ───────────────────────────────────
@Composable
private fun TopBarOverflowMenu(state: FileManagerState) {
    var expanded by remember { mutableStateOf(false) }
    val ext = MaterialTheme.extended

    Box {
        FmIconButton(
            icon               = Icons.Rounded.MoreVert,
            contentDescription = "More options",
            onClick            = { expanded = true },
            tint               = ext.iconPrimary,
        )
        DropdownMenu(
            expanded         = expanded,
            onDismissRequest = { expanded = false },
            modifier         = Modifier
                .background(ext.surfaceDialog)
                .width(200.dp),
        ) {
            OverflowMenuItem(
                icon    = Icons.Rounded.Refresh,
                label   = "Refresh",
                onClick = {
                    expanded = false
                    // trigger refresh
                },
            )
            OverflowMenuItem(
                icon    = Icons.Rounded.GridView,
                label   = "View Options",
                onClick = {
                    expanded = false
                    // open view sheet
                },
            )
            OverflowMenuItem(
                icon    = Icons.Rounded.VisibilityOff,
                label   = "Show Hidden Files",
                onClick = {
                    expanded = false
                    state.activePane.updateSortConfig(
                        state.activePane.sortConfig.copy(
                            showHidden = !state.activePane.sortConfig.showHidden
                        )
                    )
                },
            )
            HorizontalDivider(color = ext.divider)
            OverflowMenuItem(
                icon    = Icons.Rounded.Info,
                label   = "Storage Info",
                onClick = {
                    expanded = false
                    state.showStorageAnalyzer = true
                },
            )
            OverflowMenuItem(
                icon    = Icons.Rounded.Settings,
                label   = "Settings",
                onClick = { expanded = false },
            )
        }
    }
}

@Composable
private fun OverflowMenuItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit,
) {
    val ext = MaterialTheme.extended
    DropdownMenuItem(
        text = {
            Row(
                verticalAlignment     = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
            ) {
                Icon(
                    imageVector        = icon,
                    contentDescription = null,
                    tint               = ext.iconSecondary,
                    modifier           = Modifier.size(18.dp),
                )
                Text(
                    text  = label,
                    style = MaterialTheme.typography.bodyMedium,
                    color = ext.textPrimary,
                )
            }
        },
        onClick = onClick,
    )
}

// ════════════════════════════════════════════════════════════
// SECTION 5 — BREADCRUMB NAV BAR
// ════════════════════════════════════════════════════════════

@Composable
fun BreadcrumbNavBar(
    breadcrumb: BreadcrumbState,
    onSegmentClick: (BreadcrumbSegment) -> Unit,
    onNavigateUp: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext         = MaterialTheme.extended
    val scrollState = rememberScrollState()
    val scope       = rememberCoroutineScope()

    // Auto-scroll to end on path change
    LaunchedEffect(breadcrumb.stack.size) {
        scope.launch {
            scrollState.animateScrollTo(scrollState.maxValue)
        }
    }

    Surface(
        color  = ext.surfaceElevated.copy(alpha = 0.6f),
        modifier = modifier.height(SpacingTokens.breadcrumbHeight),
    ) {
        Row(
            verticalAlignment     = Alignment.CenterVertically,
            modifier              = Modifier.fillMaxSize(),
        ) {
            // Back button
            AnimatedVisibility(
                visible = breadcrumb.canGoBack,
                enter   = expandHorizontally() + fadeIn(),
                exit    = shrinkHorizontally() + fadeOut(),
            ) {
                FmIconButton(
                    icon               = Icons.Rounded.ArrowBackIosNew,
                    contentDescription = "Go back",
                    onClick            = onNavigateUp,
                    tint               = ext.iconPrimary,
                    size               = 16.dp,
                    containerSize      = 36.dp,
                )
            }

            // Scrollable breadcrumb path
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier          = Modifier
                    .weight(1f)
                    .horizontalScroll(scrollState)
                    .padding(horizontal = SpacingTokens.sm),
            ) {
                breadcrumb.stack.forEachIndexed { index, segment ->
                    val isLast = index == breadcrumb.stack.lastIndex

                    // Segment chip
                    BreadcrumbSegmentChip(
                        segment   = segment,
                        isActive  = isLast,
                        onClick   = {
                            if (!isLast) onSegmentClick(segment)
                        },
                    )

                    // Separator
                    if (!isLast) {
                        Icon(
                            imageVector        = Icons.Rounded.ChevronRight,
                            contentDescription = null,
                            tint               = ext.iconTertiary,
                            modifier           = Modifier.size(16.dp),
                        )
                    }
                }
            }

            // Right fade gradient
            Box(
                modifier = Modifier
                    .width(24.dp)
                    .fillMaxHeight()
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(
                                Color.Transparent,
                                ext.surfaceElevated.copy(alpha = 0.6f),
                            )
                        )
                    )
            )
        }
    }
}

@Composable
private fun BreadcrumbSegmentChip(
    segment: BreadcrumbSegment,
    isActive: Boolean,
    onClick: () -> Unit,
) {
    val ext = MaterialTheme.extended
    val bgColor by animateColorAsState(
        targetValue = if (isActive)
            MaterialTheme.colorScheme.primaryContainer
        else
            Color.Transparent,
        label = "breadcrumbBg",
    )
    val textColor by animateColorAsState(
        targetValue = if (isActive)
            MaterialTheme.colorScheme.onPrimaryContainer
        else
            ext.textSecondary,
        label = "breadcrumbText",
    )

    Surface(
        onClick  = onClick,
        enabled  = !isActive,
        color    = bgColor,
        shape    = ShapeTokens.chipShape,
        modifier = Modifier.padding(vertical = SpacingTokens.xxs),
    ) {
        Row(
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(3.dp),
            modifier              = Modifier.padding(
                horizontal = SpacingTokens.sm,
                vertical   = 3.dp,
            ),
        ) {
            if (segment.isRoot) {
                Icon(
                    imageVector        = Icons.Rounded.PhoneAndroid,
                    contentDescription = null,
                    tint               = textColor,
                    modifier           = Modifier.size(12.dp),
                )
            }
            Text(
                text  = segment.name,
                style = ExtraTypography.pathStyle.copy(
                    fontWeight = if (isActive)
                        androidx.compose.ui.text.font.FontWeight.SemiBold
                    else
                        androidx.compose.ui.text.font.FontWeight.Normal,
                ),
                color    = textColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 6 — SORT + FILTER BAR
// ════════════════════════════════════════════════════════════

@Composable
fun SortFilterBar(
    paneState: PaneState,
    fmState: FileManagerState,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended
    val scrollState = rememberScrollState()

    Column(modifier = modifier) {
        // ── Top row: item count + view mode + sort ───────────
        Row(
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier              = Modifier
                .fillMaxWidth()
                .padding(
                    horizontal = SpacingTokens.screenPaddingH,
                    vertical   = SpacingTokens.xs,
                ),
        ) {
            // Item count label
            Text(
                text  = buildItemCountLabel(paneState),
                style = MaterialTheme.typography.labelMedium,
                color = ext.textSecondary,
            )

            Row(
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
                verticalAlignment     = Alignment.CenterVertically,
            ) {
                // Sort button
                FmTooltip(text = "Sort: ${paneState.sortConfig.displayLabel}") {
                    Surface(
                        onClick = { fmState.showSortSheet = true },
                        color   = MaterialTheme.colorScheme.surfaceVariant,
                        shape   = ShapeTokens.chipShape,
                    ) {
                        Row(
                            verticalAlignment     = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(SpacingTokens.xxs),
                            modifier              = Modifier.padding(
                                horizontal = SpacingTokens.md,
                                vertical   = SpacingTokens.xs,
                            ),
                        ) {
                            Icon(
                                imageVector        = Icons.Rounded.Sort,
                                contentDescription = "Sort",
                                tint               = ext.iconPrimary,
                                modifier           = Modifier.size(15.dp),
                            )
                            Text(
                                text  = paneState.sortConfig.sortBy.displayName,
                                style = MaterialTheme.typography.labelSmall,
                                color = ext.textPrimary,
                            )
                            // Ascending / Descending indicator
                            Icon(
                                imageVector = if (paneState.sortConfig.sortOrder ==
                                                  SortOrder.ASCENDING)
                                    Icons.Rounded.ArrowUpward
                                else
                                    Icons.Rounded.ArrowDownward,
                                contentDescription = null,
                                tint     = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(12.dp),
                            )
                        }
                    }
                }

                // View mode toggle
                ViewModeToggle(
                    current  = paneState.viewMode,
                    onChange = { paneState.viewMode = it },
                )
            }
        }

        // ── Filter chips row ─────────────────────────────────
        Row(
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
            modifier              = Modifier
                .fillMaxWidth()
                .horizontalScroll(scrollState)
                .padding(
                    horizontal = SpacingTokens.screenPaddingH,
                    vertical   = SpacingTokens.xs,
                ),
        ) {
            // Filter icon button
            FmIconButton(
                icon               = Icons.Rounded.FilterList,
                contentDescription = "Filters",
                onClick            = { fmState.showFilterSheet = true },
                tint               = if (paneState.filterConfig.hasActiveFilters)
                                         MaterialTheme.colorScheme.primary
                                     else
                                         MaterialTheme.extended.iconSecondary,
                containerSize      = 32.dp,
                size               = 18.dp,
                badge              = if (paneState.filterConfig.hasActiveFilters)
                                         paneState.filterConfig.activeFilterCount
                                     else null,
            )

            // Filter chips
            FilterType.entries.forEach { filter ->
                FmFilterChip(
                    label    = filter.displayName,
                    selected = paneState.filterConfig.activeFilter == filter,
                    onClick  = {
                        paneState.updateFilterConfig(
                            paneState.filterConfig.copy(activeFilter = filter)
                        )
                    },
                )
            }
        }

        FmDivider()
    }
}

private fun buildItemCountLabel(paneState: PaneState): String {
    val items   = paneState.displayItems
    val folders = items.count { it.isDirectory }
    val files   = items.count { !it.isDirectory }
    return buildString {
        if (folders > 0) append("$folders folder${if (folders != 1) "s" else ""}")
        if (folders > 0 && files > 0) append("  •  ")
        if (files > 0) append("$files file${if (files != 1) "s" else ""}")
        if (items.isEmpty()) append("Empty folder")
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 7 — QUICK ACCESS SECTION
// ════════════════════════════════════════════════════════════

private data class QuickAccessItem(
    val label: String,
    val path: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val gradient: List<Color>,
)

@Composable
fun QuickAccessSection(
    onNavigate: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended

    val items = remember {
        listOf(
            QuickAccessItem(
                "Downloads",
                "/storage/emulated/0/Download",
                Icons.Rounded.Download,
                listOf(Color(0xFF6366F1), Color(0xFF8B5CF6)),
            ),
            QuickAccessItem(
                "Images",
                "/storage/emulated/0/DCIM",
                Icons.Rounded.Image,
                listOf(Color(0xFF06B6D4), Color(0xFF3B82F6)),
            ),
            QuickAccessItem(
                "Documents",
                "/storage/emulated/0/Documents",
                Icons.Rounded.Description,
                listOf(Color(0xFFF59E0B), Color(0xFFEF4444)),
            ),
            QuickAccessItem(
                "Videos",
                "/storage/emulated/0/Movies",
                Icons.Rounded.VideoLibrary,
                listOf(Color(0xFFEF4444), Color(0xFFEC4899)),
            ),
            QuickAccessItem(
                "Music",
                "/storage/emulated/0/Music",
                Icons.Rounded.LibraryMusic,
                listOf(Color(0xFF10B981), Color(0xFF06B6D4)),
            ),
            QuickAccessItem(
                "WhatsApp",
                "/storage/emulated/0/WhatsApp",
                Icons.Rounded.Chat,
                listOf(Color(0xFF25D366), Color(0xFF128C7E)),
            ),
        )
    }

    Column(modifier = modifier) {
        // Section header
        Row(
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier              = Modifier
                .fillMaxWidth()
                .padding(
                    horizontal = SpacingTokens.screenPaddingH,
                    vertical   = SpacingTokens.sm,
                ),
        ) {
            Text(
                text  = "QUICK ACCESS",
                style = ExtraTypography.overline,
                color = ext.textSecondary,
            )
        }

        // Horizontal scroll row
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
            contentPadding        = PaddingValues(
                horizontal = SpacingTokens.screenPaddingH,
                vertical   = SpacingTokens.xs,
            ),
        ) {
            items(items) { item ->
                QuickAccessCard(
                    item      = item,
                    onClick   = { onNavigate(item.path) },
                )
            }
        }

        Spacer(Modifier.height(SpacingTokens.sm))
    }
}

@Composable
private fun QuickAccessCard(
    item: QuickAccessItem,
    onClick: () -> Unit,
) {
    val ext = MaterialTheme.extended
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue   = if (isPressed) 0.94f else 1f,
        animationSpec = spring(stiffness = AnimationTokens.springStiff),
        label         = "quickAccessScale",
    )

    Box(
        modifier = Modifier
            .scale(scale)
            .width(90.dp)
            .clip(RoundedCornerShape(ShapeTokens.radiusLG))
            .background(
                Brush.linearGradient(
                    colors = item.gradient.map { it.copy(alpha = 0.15f) },
                )
            )
            .border(
                width = 0.5.dp,
                color = item.gradient.first().copy(alpha = 0.3f),
                shape = RoundedCornerShape(ShapeTokens.radiusLG),
            )
            .clickable(
                interactionSource = interactionSource,
                indication        = ripple(color = item.gradient.first()),
                onClick           = onClick,
            )
            .padding(SpacingTokens.md),
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier         = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        Brush.linearGradient(colors = item.gradient)
                    ),
            ) {
                Icon(
                    imageVector        = item.icon,
                    contentDescription = item.label,
                    tint               = RawColors.White,
                    modifier           = Modifier.size(24.dp),
                )
            }
            Text(
                text      = item.label,
                style     = MaterialTheme.typography.labelSmall,
                color     = ext.textPrimary,
                textAlign = TextAlign.Center,
                maxLines  = 1,
                overflow  = TextOverflow.Ellipsis,
            )
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 8 — STORAGE BAR SECTION
// ════════════════════════════════════════════════════════════

@Composable
fun StorageBarSection(
    storageState: StorageState,
    modifier: Modifier = Modifier,
) {
    val ext     = MaterialTheme.extended
    val volume  = storageState.primaryVolume ?: return

    GlassCard(
        modifier       = modifier,
        contentPadding = PaddingValues(SpacingTokens.lg),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(SpacingTokens.md)) {

            // Volume info row
            Row(
                verticalAlignment     = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier              = Modifier.fillMaxWidth(),
            ) {
                Row(
                    verticalAlignment     = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                Brush.linearGradient(ext.gradientPrimary)
                            ),
                    ) {
                        Icon(
                            imageVector        = Icons.Rounded.PhoneAndroid,
                            contentDescription = null,
                            tint               = RawColors.White,
                            modifier           = Modifier.size(20.dp),
                        )
                    }
                    Column {
                        Text(
                            text  = volume.displayName,
                            style = MaterialTheme.typography.titleSmall,
                            color = ext.textPrimary,
                        )
                        Text(
                            text  = "${volume.displayUsed} of ${volume.displayTotal} used",
                            style = MaterialTheme.typography.labelSmall,
                            color = ext.textSecondary,
                        )
                    }
                }

                // Percentage badge
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .clip(RoundedCornerShape(ShapeTokens.radiusSM))
                        .background(
                            MaterialTheme.colorScheme.primaryContainer
                        )
                        .padding(
                            horizontal = SpacingTokens.sm,
                            vertical   = SpacingTokens.xxs,
                        ),
                ) {
                    Text(
                        text  = "${volume.usedPercent}%",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                    )
                }
            }

            // Storage bar
            StorageMiniBar(
                segments   = storageState.toStorageSegments(ext),
                totalLabel = volume.displayTotal,
                usedLabel  = volume.displayUsed,
                freeLabel  = volume.displayFree,
            )

            // SD card row if available
            storageState.sdCard?.let { sd ->
                FmDivider()
                Row(
                    verticalAlignment     = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier              = Modifier.fillMaxWidth(),
                ) {
                    Row(
                        verticalAlignment     = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
                    ) {
                        Icon(
                            imageVector        = Icons.Rounded.SdCard,
                            contentDescription = null,
                            tint               = ext.iconSecondary,
                            modifier           = Modifier.size(18.dp),
                        )
                        Text(
                            text  = sd.displayName,
                            style = MaterialTheme.typography.labelMedium,
                            color = ext.textSecondary,
                        )
                    }
                    Text(
                        text  = "${sd.displayFree} free",
                        style = MaterialTheme.typography.labelSmall,
                        color = ext.textTertiary,
                    )
                }
            }
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 9 — BOTTOM NAV BAR
// ════════════════════════════════════════════════════════════

@Composable
fun FileManagerBottomNav(
    current: NavDestination,
    onChange: (NavDestination) -> Unit,
    state: FileManagerState,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended

    Surface(
        color           = ext.surfaceSheet.copy(alpha = 0.95f),
        shadowElevation = ElevationTokens.bottomBar,
        modifier        = modifier.fillMaxWidth(),
        border          = BorderStroke(0.5.dp, ext.divider),
    ) {
        NavigationBar(
            containerColor  = Color.Transparent,
            contentColor    = ext.iconPrimary,
            tonalElevation  = 0.dp,
            windowInsets    = WindowInsets.navigationBars,
        ) {
            NavDestination.entries.forEach { dest ->
                val selected = current == dest
                val scale by animateFloatAsState(
                    targetValue   = if (selected) 1.05f else 1f,
                    animationSpec = spring(stiffness = AnimationTokens.springBouncy),
                    label         = "navScale${dest.name}",
                )

                NavigationBarItem(
                    selected = selected,
                    onClick  = { onChange(dest) },
                    icon     = {
                        Box(modifier = Modifier.scale(scale)) {
                            // Notification dot for storage analyzer
                            val showDot = dest == NavDestination.STORAGE &&
                                          (state.storage.primaryVolume
                                              ?.usedPercent ?: 0) > 85
                            BadgedBox(
                                badge = {
                                    if (showDot) {
                                        Badge(containerColor = MaterialTheme.colorScheme.error)
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = if (selected) dest.iconSelected
                                                  else dest.icon,
                                    contentDescription = dest.label,
                                    modifier = Modifier.size(22.dp),
                                )
                            }
                        }
                    },
                    label = {
                        AnimatedVisibility(
                            visible = selected,
                            enter   = fadeIn() + expandVertically(),
                            exit    = fadeOut() + shrinkVertically(),
                        ) {
                            Text(
                                text  = dest.label,
                                style = ExtraTypography.tabLabel,
                            )
                        }
                    },
                    alwaysShowLabel = false,
                    colors          = NavigationBarItemDefaults.colors(
                        selectedIconColor   = MaterialTheme.colorScheme.primary,
                        selectedTextColor   = MaterialTheme.colorScheme.primary,
                        indicatorColor      = MaterialTheme.colorScheme.primaryContainer,
                        unselectedIconColor = ext.iconSecondary,
                        unselectedTextColor = ext.textSecondary,
                    ),
                )
            }
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 10 — SELECTION TOOLBAR
// ════════════════════════════════════════════════════════════

@Composable
fun SelectionToolbar(
    state: FileManagerState,
    modifier: Modifier = Modifier,
) {
    val ext       = MaterialTheme.extended
    val selection = state.activePane.selection
    val count     = selection.selectedCount
    val haptic    = LocalHapticFeedback.current

    FrostedPanel(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding(),
    ) {
        Column {
            // Count label
            Row(
                verticalAlignment     = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier              = Modifier
                    .fillMaxWidth()
                    .padding(
                        horizontal = SpacingTokens.screenPaddingH,
                        vertical   = SpacingTokens.sm,
                    ),
            ) {
                Text(
                    text  = "$count item${if (count == 1) "" else "s"} selected",
                    style = MaterialTheme.typography.titleSmall,
                    color = ext.textPrimary,
                )
                FmGhostButton(
                    text    = "Deselect All",
                    onClick = { selection.deselectAll() },
                    color   = MaterialTheme.colorScheme.primary,
                )
            }

            FmDivider()

            // Action buttons
            Row(
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment     = Alignment.CenterVertically,
                modifier              = Modifier
                    .fillMaxWidth()
                    .padding(vertical = SpacingTokens.sm),
            ) {
                SelectionAction(
                    icon    = Icons.Rounded.ContentCopy,
                    label   = "Copy",
                    color   = ext.iconPrimary,
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        state.copySelected()
                    },
                )
                SelectionAction(
                    icon    = Icons.Rounded.ContentCut,
                    label   = "Cut",
                    color   = ext.iconPrimary,
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        state.cutSelected()
                    },
                )
                SelectionAction(
                    icon    = Icons.Rounded.Share,
                    label   = "Share",
                    color   = ext.iconPrimary,
                    onClick = { /* share action */ },
                )
                SelectionAction(
                    icon    = Icons.Rounded.FolderZip,
                    label   = "Zip",
                    color   = ext.iconPrimary,
                    onClick = { state.showZipDialog = true },
                )
                SelectionAction(
                    icon    = Icons.Rounded.DriveFileMove,
                    label   = "Move",
                    color   = ext.iconPrimary,
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        state.cutSelected()
                    },
                )
                SelectionAction(
                    icon    = Icons.Rounded.Delete,
                    label   = "Delete",
                    color   = MaterialTheme.colorScheme.error,
                    onClick = { state.showDeleteDialog = true },
                )
            }
        }
    }
}

@Composable
private fun SelectionAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    color: Color,
    onClick: () -> Unit,
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(SpacingTokens.xxs),
    ) {
        FmIconButton(
            icon               = icon,
            contentDescription = label,
            onClick            = onClick,
            tint               = color,
            containerSize      = 44.dp,
        )
        Text(
            text  = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.extended.textSecondary,
        )
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 11 — SNACKBAR HOST (Premium)
// ════════════════════════════════════════════════════════════

@Composable
fun FmSnackbarHost(
    hostState: SnackbarHostState,
    message: SnackbarMessage?,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended

    SnackbarHost(
        hostState = hostState,
        modifier  = modifier.padding(bottom = SpacingTokens.lg),
    ) { data ->
        val type = message?.type ?: SnackbarType.INFO
        val (bgColor, iconVector) = when (type) {
            SnackbarType.SUCCESS -> Pair(
                ext.success,
                Icons.Rounded.CheckCircle,
            )
            SnackbarType.ERROR   -> Pair(
                MaterialTheme.colorScheme.error,
                Icons.Rounded.Error,
            )
            SnackbarType.WARNING -> Pair(
                ext.warning,
                Icons.Rounded.Warning,
            )
            SnackbarType.INFO    -> Pair(
                MaterialTheme.colorScheme.inverseSurface,
                Icons.Rounded.Info,
            )
        }

        Surface(
            color           = bgColor,
            shape           = ShapeTokens.cardShape,
            shadowElevation = ElevationTokens.lg,
            modifier        = Modifier
                .padding(horizontal = SpacingTokens.screenPaddingH)
                .fillMaxWidth(),
        ) {
            Row(
                verticalAlignment     = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
                modifier              = Modifier.padding(
                    horizontal = SpacingTokens.lg,
                    vertical   = SpacingTokens.md,
                ),
            ) {
                Icon(
                    imageVector        = iconVector,
                    contentDescription = null,
                    tint               = RawColors.White,
                    modifier           = Modifier.size(20.dp),
                )
                Text(
                    text     = data.visuals.message,
                    style    = MaterialTheme.typography.bodyMedium,
                    color    = RawColors.White,
                    modifier = Modifier.weight(1f),
                )
                data.visuals.actionLabel?.let { actionLabel ->
                    TextButton(onClick = { data.performAction() }) {
                        Text(
                            text  = actionLabel,
                            style = MaterialTheme.typography.labelLarge,
                            color = RawColors.White.copy(alpha = 0.85f),
                        )
                    }
                }
            }
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 12 — FILE CONTENT AREA STUB
//             (Full implementation in File 5)
// ════════════════════════════════════════════════════════════

@Composable
fun FileContentArea(
    paneState: PaneState,
    fmState: FileManagerState,
    onFileOpen: (FileItem) -> Unit,
    modifier: Modifier = Modifier,
) {
    // Implemented in File 5: FileGridListView.kt
    // This is the connection point
    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.Center,
    ) {
        when {
            paneState.isLoading -> {
                LoadingStateView()
            }
            paneState.loadError != null -> {
                ErrorStateView(
                    error   = paneState.loadError!!,
                    onRetry = { /* trigger reload */ },
                )
            }
            paneState.isEmpty -> {
                EmptyStateView(
                    title    = "This folder is empty",
                    subtitle = "Create a new folder or file\nto get started",
                    icon     = Icons.Rounded.FolderOpen,
                    action   = "Create Folder" to {
                        fmState.showCreateFolderDialog = true
                    },
                )
            }
            else -> {
                // FileGridListView renders here (File 5)
                Text(
                    text  = "→ FileGridListView renders here",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.extended.textTertiary,
                )
            }
        }
    }
}

// ── Loading State ───────────────────────────────────────────
@Composable
private fun LoadingStateView(modifier: Modifier = Modifier) {
    LazyColumn(
        modifier       = modifier.fillMaxSize(),
        contentPadding = PaddingValues(vertical = SpacingTokens.sm),
    ) {
        items(10) { index ->
            ShimmerFileListItem(
                modifier = Modifier.animateItem()
            )
        }
    }
}

// ── Error State ─────────────────────────────────────────────
@Composable
private fun ErrorStateView(
    error: String,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier,
) {
    EmptyStateView(
        title    = "Something went wrong",
        subtitle = error,
        icon     = Icons.Rounded.ErrorOutline,
        action   = "Retry" to onRetry,
        modifier = modifier,
    )
}

// ════════════════════════════════════════════════════════════
// SECTION 13 — PERMISSION SCREEN
// ════════════════════════════════════════════════════════════

@Composable
fun PermissionScreen(
    onRequestPermission: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended
    val infiniteTransition = rememberInfiniteTransition(label = "permAnim")
    val pulseAnim by infiniteTransition.animateFloat(
        initialValue  = 0.85f,
        targetValue   = 1f,
        animationSpec = infiniteRepeatable(
            animation  = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "pulse",
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier            = modifier
            .fillMaxSize()
            .padding(SpacingTokens.xxxl),
    ) {
        // Animated icon
        Box(
            contentAlignment = Alignment.Center,
            modifier         = Modifier
                .size(120.dp)
                .scale(pulseAnim),
        ) {
            // Glow rings
            Box(
                modifier = Modifier
                    .size(120.dp)
                    .clip(CircleShape)
                    .background(
                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                    )
            )
            Box(
                modifier = Modifier
                    .size(90.dp)
                    .clip(CircleShape)
                    .background(
                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                    )
            )
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(ext.gradientPrimary)
                    ),
            ) {
                Icon(
                    imageVector        = Icons.Rounded.FolderOpen,
                    contentDescription = null,
                    tint               = RawColors.White,
                    modifier           = Modifier.size(32.dp),
                )
            }
        }

        Spacer(Modifier.height(SpacingTokens.xxxl))

        Text(
            text      = "Storage Access Required",
            style     = MaterialTheme.typography.headlineSmall,
            color     = ext.textPrimary,
            textAlign = TextAlign.Center,
        )

        Spacer(Modifier.height(SpacingTokens.lg))

        Text(
            text      = "File Manager needs access to your storage\nto browse, manage and organize your files.",
            style     = MaterialTheme.typography.bodyMedium,
            color     = ext.textSecondary,
            textAlign = TextAlign.Center,
        )

        Spacer(Modifier.height(SpacingTokens.xxxl))

        // Permission features list
        listOf(
            Icons.Rounded.FolderOpen to "Browse all files and folders",
            Icons.Rounded.ContentCopy to "Copy, move and organize files",
            Icons.Rounded.FolderZip to "Create and extract archives",
            Icons.Rounded.Share to "Share files with other apps",
        ).forEach { (icon, text) ->
            Row(
                verticalAlignment     = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
                modifier              = Modifier
                    .fillMaxWidth()
                    .padding(vertical = SpacingTokens.xs),
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer),
                ) {
                    Icon(
                        imageVector        = icon,
                        contentDescription = null,
                        tint               = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier           = Modifier.size(18.dp),
                    )
                }
                Text(
                    text  = text,
                    style = MaterialTheme.typography.bodyMedium,
                    color = ext.textPrimary,
                )
            }
        }

        Spacer(Modifier.height(SpacingTokens.xxxl))

        FmPrimaryButton(
            text     = "Grant Permission",
            onClick  = onRequestPermission,
            modifier = Modifier.fillMaxWidth(),
            leadingIcon = {
                Icon(
                    imageVector        = Icons.Rounded.Lock,
                    contentDescription = null,
                    tint               = RawColors.White,
                    modifier           = Modifier.size(18.dp),
                )
            },
        )

        Spacer(Modifier.height(SpacingTokens.lg))

        Text(
            text      = "Your files remain private and secure.\nNo data is collected or shared.",
            style     = MaterialTheme.typography.bodySmall,
            color     = ext.textTertiary,
            textAlign = TextAlign.Center,
        )
    }
}

// ════════════════════════════════════════════════════════════
// END OF FILE 4 — MainFileScreen.kt
// Next → File 5: FileGridListView.kt
// (LazyGrid, LazyColumn, FileCard, FolderCard,
//  SelectionOverlay, LongPress, CheckBox anim,
//  Empty state, Loading shimmer, Compact view)
// ════════════════════════════════════════════════════════════

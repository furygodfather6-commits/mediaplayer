@file:OptIn(
    androidx.compose.foundation.ExperimentalFoundationApi::class,
    androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.animation.ExperimentalAnimationApi::class,
    androidx.compose.ui.ExperimentalComposeUiApi::class
)

package com.devfav.filemanager.ui.screen


import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.hapticfeedback.*
import androidx.compose.ui.input.pointer.*
import androidx.compose.ui.layout.*
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import androidx.compose.ui.zIndex
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.devfav.filemanager.ui.design.*
import com.devfav.filemanager.ui.state.*
import com.devfav.filemanager.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// ════════════════════════════════════════════════════════════
// SECTION 1 — MAIN FILE CONTENT DISPATCHER
//             Routes to Grid / List / Compact based on mode
// ════════════════════════════════════════════════════════════

@Composable
fun FileGridListView(
    paneState: PaneState,
    fmState: FileManagerState,
    onFileOpen: (FileItem) -> Unit,
    modifier: Modifier = Modifier,
) {
    val items     = paneState.displayItems
    val selection = paneState.selection
    val haptic    = LocalHapticFeedback.current
    val scope     = rememberCoroutineScope()

    // Scroll state memory
    val listState = rememberLazyListState(
        initialFirstVisibleItemIndex  = paneState.scrollIndex,
        initialFirstVisibleItemScrollOffset = paneState.scrollOffset,
    )
    val gridState = rememberLazyGridState(
        initialFirstVisibleItemIndex  = paneState.scrollIndex,
        initialFirstVisibleItemScrollOffset = paneState.scrollOffset,
    )

    // Save scroll position on change
    LaunchedEffect(listState.firstVisibleItemIndex,
                   listState.firstVisibleItemScrollOffset) {
        paneState.saveScroll(
            listState.firstVisibleItemIndex,
            listState.firstVisibleItemScrollOffset,
        )
    }

    // Callbacks
    val onItemClick: (FileItem) -> Unit = { item ->
        when {
            selection.isSelectionMode -> {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                selection.toggleSelection(item.id)
            }
            item.isDirectory -> {
                fmState.navigateTo(item.path)
            }
            else -> onFileOpen(item)
        }
    }

    val onItemLongClick: (FileItem) -> Unit = { item ->
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        if (!selection.isSelectionMode) {
            selection.enterSelectionMode(item.id)
        } else {
            fmState.openContextMenu(item)
        }
    }

    val onItemContextMenu: (FileItem) -> Unit = { item ->
        fmState.openContextMenu(item)
    }

    AnimatedContent(
        targetState   = paneState.viewMode,
        transitionSpec = {
            fadeIn(tween(AnimationTokens.durationMD)) togetherWith
            fadeOut(tween(AnimationTokens.durationMD))
        },
        label = "viewModeTransition",
        modifier = modifier.fillMaxSize(),
    ) { mode ->
        when (mode) {
            ViewMode.LIST -> FileListView(
                items            = items,
                selection        = selection,
                listState        = listState,
                isSplitMode      = fmState.splitScreen.isSplit,
                clipboard        = fmState.clipboard,
                onItemClick      = onItemClick,
                onItemLongClick  = onItemLongClick,
                onContextMenu    = onItemContextMenu,
            )
            ViewMode.GRID -> FileGridView(
                items            = items,
                selection        = selection,
                gridState        = gridState,
                isSplitMode      = fmState.splitScreen.isSplit,
                clipboard        = fmState.clipboard,
                onItemClick      = onItemClick,
                onItemLongClick  = onItemLongClick,
                onContextMenu    = onItemContextMenu,
            )
            ViewMode.COMPACT -> FileCompactView(
                items            = items,
                selection        = selection,
                listState        = listState,
                clipboard        = fmState.clipboard,
                onItemClick      = onItemClick,
                onItemLongClick  = onItemLongClick,
                onContextMenu    = onItemContextMenu,
            )
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 2 — FILE LIST VIEW (LazyColumn)
// ════════════════════════════════════════════════════════════

@Composable
fun FileListView(
    items: List<FileItem>,
    selection: SelectionState,
    listState: LazyListState,
    isSplitMode: Boolean,
    clipboard: ClipboardState,
    onItemClick: (FileItem) -> Unit,
    onItemLongClick: (FileItem) -> Unit,
    onContextMenu: (FileItem) -> Unit,
    modifier: Modifier = Modifier,
) {
    LazyColumn(
        state          = listState,
        contentPadding = PaddingValues(
            top    = SpacingTokens.xs,
            bottom = SpacingTokens.giant + SpacingTokens.xxl,
        ),
        modifier       = modifier.fillMaxSize(),
    ) {
        // Clipboard paste banner
        if (clipboard.hasItems) {
            item(key = "clipboard_banner") {
                ClipboardBanner(
                    clipboard = clipboard,
                    modifier  = Modifier.animateItem(),
                )
            }
        }

        // Section: Folders
        val folders = items.filter { it.isDirectory }
        val files   = items.filter { !it.isDirectory }

        if (folders.isNotEmpty()) {
            item(key = "folders_header") {
                SectionHeader(
                    title    = "Folders",
                    count    = folders.size,
                    modifier = Modifier.animateItem(),
                )
            }
            items(
                items    = folders,
                key      = { it.id },
            ) { item ->
                FileListItem(
                    item            = item,
                    isSelected      = selection.isSelected(item.id),
                    isSelectionMode = selection.isSelectionMode,
                    isCut           = clipboard.isCut && clipboard.items.any { it.id == item.id },
                    isSplitMode     = isSplitMode,
                    onClick         = { onItemClick(item) },
                    onLongClick     = { onItemLongClick(item) },
                    onContextMenu   = { onContextMenu(item) },
                    modifier        = Modifier.animateItem(),
                )
            }
        }

        if (files.isNotEmpty()) {
            item(key = "files_header") {
                SectionHeader(
                    title    = "Files",
                    count    = files.size,
                    modifier = Modifier.animateItem(),
                )
            }
            items(
                items = files,
                key   = { it.id },
            ) { item ->
                FileListItem(
                    item            = item,
                    isSelected      = selection.isSelected(item.id),
                    isSelectionMode = selection.isSelectionMode,
                    isCut           = clipboard.isCut && clipboard.items.any { it.id == item.id },
                    isSplitMode     = isSplitMode,
                    onClick         = { onItemClick(item) },
                    onLongClick     = { onItemLongClick(item) },
                    onContextMenu   = { onContextMenu(item) },
                    modifier        = Modifier.animateItem(),
                )
            }
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 3 — FILE LIST ITEM (Single row)
// ════════════════════════════════════════════════════════════

@Composable
fun FileListItem(
    item: FileItem,
    isSelected: Boolean,
    isSelectionMode: Boolean,
    isCut: Boolean,
    isSplitMode: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onContextMenu: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext               = MaterialTheme.extended
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed         by interactionSource.collectIsPressedAsState()

    // Animations
    val bgColor by animateColorAsState(
        targetValue = when {
            isSelected -> ext.selectionBackground
            isPressed  -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            else       -> Color.Transparent
        },
        animationSpec = tween(AnimationTokens.durationSM),
        label         = "listItemBg",
    )
    val alpha by animateFloatAsState(
        targetValue   = if (isCut) 0.45f else 1f,
        animationSpec = tween(AnimationTokens.durationMD),
        label         = "cutAlpha",
    )
    val startPadding by animateDpAsState(
        targetValue   = if (isSelectionMode)
                            SpacingTokens.xs
                        else
                            SpacingTokens.screenPaddingH,
        animationSpec = spring(stiffness = AnimationTokens.springStiff),
        label         = "startPadding",
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .alpha(alpha)
            .background(bgColor)
            .combinedClickable(
                interactionSource = interactionSource,
                indication        = ripple(
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                ),
                onClick           = onClick,
                onLongClick       = onLongClick,
            )
            .animatedBorder(
                selected      = isSelected,
                selectedColor = ext.selectionBorder.copy(alpha = 0.4f),
                shape         = RoundedCornerShape(0.dp),
            ),
    ) {
        Row(
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
            modifier              = Modifier
                .fillMaxWidth()
                .height(SpacingTokens.listItemHeight)
                .padding(
                    start  = startPadding,
                    end    = SpacingTokens.screenPaddingH,
                    top    = SpacingTokens.xs,
                    bottom = SpacingTokens.xs,
                ),
        ) {
            // ── Checkbox (selection mode) ───────────────────
            AnimatedVisibility(
                visible = isSelectionMode,
                enter   = expandHorizontally() + fadeIn(),
                exit    = shrinkHorizontally() + fadeOut(),
            ) {
                FmCheckbox(
                    checked         = isSelected,
                    onCheckedChange = { onClick() },
                    modifier        = Modifier.padding(end = SpacingTokens.xs),
                )
            }

            // ── File / Folder Icon ──────────────────────────
            FileIconWithThumbnail(
                item     = item,
                size     = SpacingTokens.iconSizeFolder,
                showBadge = !item.isDirectory,
            )

            // ── Name + Meta ─────────────────────────────────
            Column(
                verticalArrangement = Arrangement.Center,
                modifier            = Modifier.weight(1f),
            ) {
                Text(
                    text     = item.name,
                    style    = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = if (item.isDirectory)
                            androidx.compose.ui.text.font.FontWeight.Medium
                        else
                            androidx.compose.ui.text.font.FontWeight.Normal,
                    ),
                    color    = ext.textPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(2.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
                    verticalAlignment     = Alignment.CenterVertically,
                ) {
                    // Hidden badge
                    if (item.isHidden) {
                        HiddenBadge()
                    }
                    // Favorite badge
                    if (item.isFavorite) {
                        Icon(
                            imageVector        = Icons.Rounded.Star,
                            contentDescription = null,
                            tint               = RawColors.Amber400,
                            modifier           = Modifier.size(11.dp),
                        )
                    }
                    // Symlink badge
                    if (item.isSymlink) {
                        Icon(
                            imageVector        = Icons.Rounded.Link,
                            contentDescription = null,
                            tint               = ext.iconTertiary,
                            modifier           = Modifier.size(11.dp),
                        )
                    }
                    Text(
                        text  = item.displayDate,
                        style = MaterialTheme.typography.labelSmall,
                        color = ext.textTertiary,
                    )
                }
            }

            // ── Size + More button ──────────────────────────
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.Center,
            ) {
                Text(
                    text  = item.displaySize,
                    style = ExtraTypography.sizeLabel,
                    color = ext.textSecondary,
                )
                if (!isSelectionMode) {
                    FmIconButton(
                        icon               = Icons.Rounded.MoreVert,
                        contentDescription = "More options",
                        onClick            = onContextMenu,
                        tint               = ext.iconTertiary,
                        containerSize      = 28.dp,
                        size               = 16.dp,
                    )
                }
            }
        }

        // ── Selected left accent bar ─────────────────────────
        AnimatedVisibility(
            visible  = isSelected,
            enter    = expandHorizontally(expandFrom = Alignment.Start),
            exit     = shrinkHorizontally(shrinkTowards = Alignment.Start),
            modifier = Modifier.align(Alignment.CenterStart),
        ) {
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .fillMaxHeight(0.6f)
                    .clip(RoundedCornerShape(
                        topEnd    = ShapeTokens.radiusFull,
                        bottomEnd = ShapeTokens.radiusFull,
                    ))
                    .background(ext.selectionBorder),
            )
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 4 — FILE GRID VIEW (LazyVerticalGrid)
// ════════════════════════════════════════════════════════════

@Composable
fun FileGridView(
    items: List<FileItem>,
    selection: SelectionState,
    gridState: LazyGridState,
    isSplitMode: Boolean,
    clipboard: ClipboardState,
    onItemClick: (FileItem) -> Unit,
    onItemLongClick: (FileItem) -> Unit,
    onContextMenu: (FileItem) -> Unit,
    modifier: Modifier = Modifier,
) {
    // Adaptive columns — fewer in split mode
    val columns = when {
        isSplitMode -> GridCells.Adaptive(minSize = 130.dp)
        else        -> GridCells.Adaptive(minSize = 150.dp)
    }

    LazyVerticalGrid(
        columns        = columns,
        state          = gridState,
        contentPadding = PaddingValues(
            start  = SpacingTokens.screenPaddingH,
            end    = SpacingTokens.screenPaddingH,
            top    = SpacingTokens.sm,
            bottom = SpacingTokens.giant + SpacingTokens.xxl,
        ),
        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.gridSpacing),
        verticalArrangement   = Arrangement.spacedBy(SpacingTokens.gridSpacing),
        modifier              = modifier.fillMaxSize(),
    ) {
        // Clipboard banner — full width
        if (clipboard.hasItems) {
            item(
                key  = "clipboard_banner",
                span = { GridItemSpan(maxLineSpan) },
            ) {
                ClipboardBanner(
                    clipboard = clipboard,
                    modifier  = Modifier.animateItem(),
                )
            }
        }

        // Folders header — full width
        val folders = items.filter { it.isDirectory }
        val files   = items.filter { !it.isDirectory }

        if (folders.isNotEmpty()) {
            item(
                key  = "folders_header",
                span = { GridItemSpan(maxLineSpan) },
            ) {
                SectionHeader(
                    title    = "Folders",
                    count    = folders.size,
                    modifier = Modifier.animateItem(),
                )
            }
            items(
                items = folders,
                key   = { it.id },
            ) { item ->
                FileGridItem(
                    item            = item,
                    isSelected      = selection.isSelected(item.id),
                    isSelectionMode = selection.isSelectionMode,
                    isCut           = clipboard.isCut &&
                                      clipboard.items.any { it.id == item.id },
                    onClick         = { onItemClick(item) },
                    onLongClick     = { onItemLongClick(item) },
                    onContextMenu   = { onContextMenu(item) },
                    modifier        = Modifier.animateItem(),
                )
            }
        }

        if (files.isNotEmpty()) {
            item(
                key  = "files_header",
                span = { GridItemSpan(maxLineSpan) },
            ) {
                SectionHeader(
                    title    = "Files",
                    count    = files.size,
                    modifier = Modifier.animateItem(),
                )
            }
            items(
                items = files,
                key   = { it.id },
            ) { item ->
                FileGridItem(
                    item            = item,
                    isSelected      = selection.isSelected(item.id),
                    isSelectionMode = selection.isSelectionMode,
                    isCut           = clipboard.isCut &&
                                      clipboard.items.any { it.id == item.id },
                    onClick         = { onItemClick(item) },
                    onLongClick     = { onItemLongClick(item) },
                    onContextMenu   = { onContextMenu(item) },
                    modifier        = Modifier.animateItem(),
                )
            }
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 5 — FILE GRID ITEM CARD
// ════════════════════════════════════════════════════════════

@Composable
fun FileGridItem(
    item: FileItem,
    isSelected: Boolean,
    isSelectionMode: Boolean,
    isCut: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onContextMenu: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext               = MaterialTheme.extended
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed         by interactionSource.collectIsPressedAsState()
    val isDark            = ext.isDark

    val scale by animateFloatAsState(
        targetValue = when {
            isPressed  -> AnimationTokens.pressedScale
            isSelected -> AnimationTokens.selectedScale
            else       -> AnimationTokens.normalScale
        },
        animationSpec = spring(
            stiffness = AnimationTokens.springStiff,
            dampingRatio = Spring.DampingRatioMediumBouncy,
        ),
        label = "gridItemScale",
    )
    val alpha by animateFloatAsState(
        targetValue   = if (isCut) 0.4f else 1f,
        label         = "gridCutAlpha",
    )
    val glowAlpha by animateFloatAsState(
        targetValue   = if (isSelected) 1f else 0f,
        animationSpec = tween(AnimationTokens.durationMD),
        label         = "glowAlpha",
    )

    Box(
        modifier = modifier
            .scale(scale)
            .alpha(alpha),
    ) {
        // Glow ring behind card (selected state)
        if (glowAlpha > 0f) {
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .clip(ShapeTokens.cardShape)
                    .background(ext.selectionBorder.copy(alpha = 0.15f * glowAlpha))
            )
        }

        Surface(
            onClick           = onClick,
            shape             = ShapeTokens.cardShape,
            color             = if (isSelected)
                                    ext.selectionBackground
                                else
                                    MaterialTheme.colorScheme.surfaceVariant,
            border            = BorderStroke(
                width = if (isSelected) 1.5.dp else 0.5.dp,
                color = if (isSelected)
                            ext.selectionBorder
                        else
                            ext.glassBorder,
            ),
            shadowElevation   = if (isSelected)
                                    ElevationTokens.cardHover
                                else
                                    ElevationTokens.card,
            modifier          = Modifier
                .fillMaxWidth()
                .combinedClickable(
                    interactionSource = interactionSource,
                    indication        = null,
                    onClick           = onClick,
                    onLongClick       = onLongClick,
                )
                .glowShadow(
                    color        = if (isSelected) ext.selectionBorder
                                   else Color.Transparent,
                    glowRadius   = 8.dp,
                    alpha        = 0.4f * glowAlpha,
                ),
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
            ) {
                // ── Thumbnail / Icon area ────────────────────
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                        .clip(
                            RoundedCornerShape(
                                topStart    = ShapeTokens.radiusLG,
                                topEnd      = ShapeTokens.radiusLG,
                                bottomStart = 0.dp,
                                bottomEnd   = 0.dp,
                            )
                        )
                        .background(
                            if (item.isDirectory)
                                Brush.linearGradient(
                                    colors = listOf(
                                        ext.folderColor.copy(alpha = 0.12f),
                                        ext.folderColorAlt.copy(alpha = 0.06f),
                                    )
                                )
                            else
                                MaterialTheme.colorScheme.surface
                                    .copy(alpha = 0.5f).let {
                                        Brush.linearGradient(listOf(it, it))
                                    }
                        ),
                    contentAlignment = Alignment.Center,
                ) {
                    FileIconWithThumbnail(
                        item      = item,
                        size      = 48.dp,
                        showBadge = !item.isDirectory,
                    )

                    // ── Selection checkbox overlay ───────────
                    SelectionCheckOverlay(
                        isSelectionMode = isSelectionMode,
                        isSelected      = isSelected,
                        onToggle        = onClick,
                    )

                    // ── Context menu button (top-right) ──────
                    if (!isSelectionMode) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(SpacingTokens.xs),
                        ) {
                            FmIconButton(
                                icon               = Icons.Rounded.MoreVert,
                                contentDescription = "More",
                                onClick            = onContextMenu,
                                tint               = ext.iconTertiary,
                                containerSize      = 24.dp,
                                size               = 14.dp,
                            )
                        }
                    }

                    // ── Cut overlay ─────────────────────────
                    if (isCut) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    RawColors.OverlayLight
                                )
                        ) {
                            Icon(
                                imageVector        = Icons.Rounded.ContentCut,
                                contentDescription = null,
                                tint               = ext.iconSecondary,
                                modifier           = Modifier
                                    .align(Alignment.Center)
                                    .size(20.dp),
                            )
                        }
                    }

                    // ── Favorite star ───────────────────────
                    if (item.isFavorite) {
                        Icon(
                            imageVector        = Icons.Rounded.Star,
                            contentDescription = null,
                            tint               = RawColors.Amber400,
                            modifier           = Modifier
                                .align(Alignment.TopStart)
                                .padding(SpacingTokens.xs)
                                .size(14.dp),
                        )
                    }
                }

                // ── Name + Meta row ──────────────────────────
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(
                            horizontal = SpacingTokens.md,
                            vertical   = SpacingTokens.sm,
                        ),
                ) {
                    Text(
                        text     = item.name,
                        style    = MaterialTheme.typography.labelMedium,
                        color    = ext.textPrimary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text  = item.displaySize,
                        style = ExtraTypography.sizeLabel,
                        color = ext.textTertiary,
                    )
                }
            }
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 6 — FILE COMPACT VIEW (Dense list)
// ════════════════════════════════════════════════════════════

@Composable
fun FileCompactView(
    items: List<FileItem>,
    selection: SelectionState,
    listState: LazyListState,
    clipboard: ClipboardState,
    onItemClick: (FileItem) -> Unit,
    onItemLongClick: (FileItem) -> Unit,
    onContextMenu: (FileItem) -> Unit,
    modifier: Modifier = Modifier,
) {
    LazyColumn(
        state          = listState,
        contentPadding = PaddingValues(
            top    = SpacingTokens.xs,
            bottom = SpacingTokens.giant + SpacingTokens.xxl,
        ),
        modifier = modifier.fillMaxSize(),
    ) {
        if (clipboard.hasItems) {
            item(key = "clipboard_banner") {
                ClipboardBanner(clipboard = clipboard, modifier = Modifier.animateItem())
            }
        }

        items(
            items = items,
            key   = { it.id },
        ) { item ->
            FileCompactItem(
                item            = item,
                isSelected      = selection.isSelected(item.id),
                isSelectionMode = selection.isSelectionMode,
                isCut           = clipboard.isCut && clipboard.items.any { it.id == item.id },
                onClick         = { onItemClick(item) },
                onLongClick     = { onItemLongClick(item) },
                onContextMenu   = { onContextMenu(item) },
                modifier        = Modifier.animateItem(),
            )
            FmDivider(
                startIndent = 52.dp,
                modifier    = Modifier.padding(horizontal = SpacingTokens.screenPaddingH),
            )
        }
    }
}

@Composable
private fun FileCompactItem(
    item: FileItem,
    isSelected: Boolean,
    isSelectionMode: Boolean,
    isCut: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onContextMenu: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext               = MaterialTheme.extended
    val interactionSource = remember { MutableInteractionSource() }

    val bgColor by animateColorAsState(
        targetValue = if (isSelected) ext.selectionBackground else Color.Transparent,
        label       = "compactBg",
    )
    val alpha by animateFloatAsState(
        targetValue = if (isCut) 0.45f else 1f,
        label       = "compactAlpha",
    )

    Row(
        verticalAlignment     = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
        modifier              = modifier
            .fillMaxWidth()
            .height(48.dp)
            .alpha(alpha)
            .background(bgColor)
            .combinedClickable(
                interactionSource = interactionSource,
                indication        = ripple(
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.06f),
                ),
                onClick           = onClick,
                onLongClick       = onLongClick,
            )
            .padding(
                horizontal = SpacingTokens.screenPaddingH,
                vertical   = SpacingTokens.xs,
            ),
    ) {
        // Checkbox
        AnimatedVisibility(
            visible = isSelectionMode,
            enter   = expandHorizontally() + fadeIn(),
            exit    = shrinkHorizontally() + fadeOut(),
        ) {
            FmCheckbox(
                checked         = isSelected,
                onCheckedChange = { onClick() },
            )
        }

        // Icon (small)
        FileIconWithThumbnail(
            item      = item,
            size      = 28.dp,
            showBadge = false,
        )

        // Name
        Text(
            text     = item.name,
            style    = MaterialTheme.typography.bodySmall,
            color    = ext.textPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )

        // Extension chip
        if (!item.isDirectory && item.extension.isNotEmpty()) {
            Surface(
                color  = MaterialTheme.colorScheme.surfaceVariant,
                shape  = ShapeTokens.badgeShape,
            ) {
                Text(
                    text     = item.extension.uppercase().take(4),
                    style    = ExtraTypography.extensionBadge,
                    color    = ext.textSecondary,
                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
                )
            }
        }

        // Size
        Text(
            text  = item.displaySize,
            style = ExtraTypography.sizeLabel,
            color = ext.textTertiary,
        )
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 7 — FILE ICON WITH THUMBNAIL
// ════════════════════════════════════════════════════════════

@Composable
fun FileIconWithThumbnail(
    item: FileItem,
    size: Dp,
    showBadge: Boolean,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended

    if (item.isMedia && item.thumbnailPath != null) {
        // Media thumbnail with Coil
        Box(
            modifier = modifier
                .size(size)
                .clip(RoundedCornerShape(ShapeTokens.radiusMD)),
        ) {
            AsyncImage(
                model             = ImageRequest.Builder(LocalContext.current)
                    .data(item.thumbnailPath)
                    .crossfade(true)
                    .size(
                        coil.size.Size(
                            (size.value * LocalDensity.current.density).toInt(),
                            (size.value * LocalDensity.current.density).toInt(),
                        )
                    )
                    .build(),
                contentDescription = item.name,
                contentScale       = ContentScale.Crop,
                modifier           = Modifier.fillMaxSize(),
                onLoading          = {
                    // Shimmer shows below
                },
            )

            // Video play overlay
            if (item.fileType == FileType.VIDEO) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier         = Modifier
                        .fillMaxSize()
                        .background(RawColors.OverlayLight),
                ) {
                    Icon(
                        imageVector        = Icons.Rounded.PlayCircle,
                        contentDescription = null,
                        tint               = RawColors.White.copy(alpha = 0.9f),
                        modifier           = Modifier.size(size * 0.4f),
                    )
                }
            }

            // Extension badge
            if (showBadge) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .offset(x = 2.dp, y = 2.dp),
                ) {
                    ExtensionBadge(ext = item.extension, color = ext.imageColor)
                }
            }
        }
    } else {
        // Standard icon
        FileTypeIcon(
            fileType  = item.iconType,
            size      = size,
            showBadge = showBadge,
            modifier  = modifier,
        )
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 8 — SELECTION CHECKBOX OVERLAY
// ════════════════════════════════════════════════════════════

@Composable
fun SelectionCheckOverlay(
    isSelectionMode: Boolean,
    isSelected: Boolean,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier,
) {
    AnimatedVisibility(
        visible  = isSelectionMode,
        enter    = fadeIn() + scaleIn(initialScale = 0.6f),
        exit     = fadeOut() + scaleOut(targetScale = 0.6f),
        modifier = modifier.fillMaxSize(),
    ) {
        Box(
            contentAlignment = Alignment.TopStart,
            modifier         = Modifier
                .fillMaxSize()
                .padding(SpacingTokens.xs),
        ) {
            FmCheckbox(
                checked         = isSelected,
                onCheckedChange = { onToggle() },
            )
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 9 — SECTION HEADER
// ════════════════════════════════════════════════════════════

@Composable
fun SectionHeader(
    title: String,
    count: Int,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended
    Row(
        verticalAlignment     = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
        modifier              = modifier
            .fillMaxWidth()
            .padding(
                horizontal = SpacingTokens.screenPaddingH,
                vertical   = SpacingTokens.xs,
            ),
    ) {
        Text(
            text  = title.uppercase(),
            style = ExtraTypography.overline,
            color = ext.textSecondary,
        )
        Surface(
            color  = MaterialTheme.colorScheme.surfaceVariant,
            shape  = ShapeTokens.badgeShape,
        ) {
            Text(
                text     = count.toString(),
                style    = ExtraTypography.extensionBadge.copy(
                    fontSize = 10.sp,
                ),
                color    = ext.textSecondary,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
            )
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 10 — CLIPBOARD BANNER
// ════════════════════════════════════════════════════════════

@Composable
fun ClipboardBanner(
    clipboard: ClipboardState,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended
    val accentColor = if (clipboard.isCut)
        RawColors.Amber500
    else
        MaterialTheme.colorScheme.primary

    Surface(
        color  = accentColor.copy(alpha = 0.1f),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.3f)),
        shape  = RoundedCornerShape(0.dp),
        modifier = modifier.fillMaxWidth(),
    ) {
        Row(
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
            modifier              = Modifier
                .fillMaxWidth()
                .padding(
                    horizontal = SpacingTokens.screenPaddingH,
                    vertical   = SpacingTokens.sm,
                ),
        ) {
            Icon(
                imageVector = if (clipboard.isCut)
                    Icons.Rounded.ContentCut
                else
                    Icons.Rounded.ContentCopy,
                contentDescription = null,
                tint               = accentColor,
                modifier           = Modifier.size(16.dp),
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text  = if (clipboard.isCut) "Cut" else "Copied",
                    style = MaterialTheme.typography.labelSmall,
                    color = accentColor,
                )
                Text(
                    text  = clipboard.displayLabel,
                    style = MaterialTheme.typography.bodySmall,
                    color = ext.textPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            FmGhostButton(
                text    = "Paste",
                onClick = { /* trigger paste */ },
                color   = accentColor,
            )
            FmIconButton(
                icon               = Icons.Rounded.Close,
                contentDescription = "Clear clipboard",
                onClick            = { clipboard.clear() },
                tint               = ext.iconSecondary,
                containerSize      = 28.dp,
                size               = 16.dp,
            )
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 11 — HIDDEN BADGE / EXTENSION BADGE
// ════════════════════════════════════════════════════════════

@Composable
fun HiddenBadge(modifier: Modifier = Modifier) {
    Surface(
        color    = MaterialTheme.colorScheme.surfaceVariant,
        shape    = ShapeTokens.badgeShape,
        modifier = modifier,
    ) {
        Row(
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(2.dp),
            modifier              = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
        ) {
            Icon(
                imageVector        = Icons.Rounded.VisibilityOff,
                contentDescription = null,
                tint               = MaterialTheme.extended.iconTertiary,
                modifier           = Modifier.size(9.dp),
            )
            Text(
                text  = "Hidden",
                style = ExtraTypography.extensionBadge,
                color = MaterialTheme.extended.textTertiary,
            )
        }
    }
}

@Composable
fun ExtensionBadge(
    ext: String,
    color: Color,
    modifier: Modifier = Modifier,
) {
    Surface(
        color  = color,
        shape  = ShapeTokens.badgeShape,
        modifier = modifier,
    ) {
        Text(
            text     = ext.uppercase().take(4),
            style    = ExtraTypography.extensionBadge,
            color    = RawColors.White,
            modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp),
        )
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 12 — RECENTS SCREEN
// ════════════════════════════════════════════════════════════

@Composable
fun RecentsScreen(
    recentItems: List<FileItem>,
    selection: SelectionState,
    clipboard: ClipboardState,
    onItemClick: (FileItem) -> Unit,
    onItemLongClick: (FileItem) -> Unit,
    onContextMenu: (FileItem) -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended

    if (recentItems.isEmpty()) {
        EmptyStateView(
            title    = "No recent files",
            subtitle = "Files you open will appear here",
            icon     = Icons.Rounded.History,
            modifier = modifier,
        )
        return
    }

    // Group by date
    val grouped = remember(recentItems) {
        recentItems.groupBy { item ->
            val diff = System.currentTimeMillis() - item.lastModified
            when {
                diff < 86_400_000L  -> "Today"
                diff < 172_800_000L -> "Yesterday"
                diff < 604_800_000L -> "This Week"
                else                -> "Older"
            }
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(
            top    = SpacingTokens.sm,
            bottom = SpacingTokens.giant + SpacingTokens.xxl,
        ),
        modifier = modifier.fillMaxSize(),
    ) {
        grouped.forEach { (dateGroup, items) ->
            item(key = "header_$dateGroup") {
                SectionHeader(
                    title    = dateGroup,
                    count    = items.size,
                    modifier = Modifier.animateItem(),
                )
            }
            items(
                items = items,
                key   = { "recent_${it.id}" },
            ) { item ->
                FileListItem(
                    item            = item,
                    isSelected      = selection.isSelected(item.id),
                    isSelectionMode = selection.isSelectionMode,
                    isCut           = clipboard.isCut &&
                                      clipboard.items.any { it.id == item.id },
                    isSplitMode     = false,
                    onClick         = { onItemClick(item) },
                    onLongClick     = { onItemLongClick(item) },
                    onContextMenu   = { onContextMenu(item) },
                    modifier        = Modifier.animateItem(),
                )
            }
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 13 — FAVORITES SCREEN
// ════════════════════════════════════════════════════════════

@Composable
fun FavoritesScreen(
    favoriteItems: List<FileItem>,
    selection: SelectionState,
    clipboard: ClipboardState,
    onItemClick: (FileItem) -> Unit,
    onItemLongClick: (FileItem) -> Unit,
    onContextMenu: (FileItem) -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended

    if (favoriteItems.isEmpty()) {
        EmptyStateView(
            title    = "No favorites yet",
            subtitle = "Long-press any file or folder\nand tap ★ to add to favorites",
            icon     = Icons.Rounded.StarBorder,
            modifier = modifier,
        )
        return
    }

    LazyColumn(
        contentPadding = PaddingValues(
            top    = SpacingTokens.sm,
            bottom = SpacingTokens.giant + SpacingTokens.xxl,
        ),
        modifier = modifier.fillMaxSize(),
    ) {
        // Pinned folders first
        val pinnedFolders = favoriteItems.filter { it.isDirectory }
        val pinnedFiles   = favoriteItems.filter { !it.isDirectory }

        if (pinnedFolders.isNotEmpty()) {
            item(key = "fav_folders_header") {
                SectionHeader(
                    title    = "Favorite Folders",
                    count    = pinnedFolders.size,
                    modifier = Modifier.animateItem(),
                )
            }
            // Horizontal scroll row for folders
            item(key = "fav_folders_row") {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
                    contentPadding        = PaddingValues(horizontal = SpacingTokens.screenPaddingH),
                    modifier              = Modifier
                        .fillMaxWidth()
                        .animateItem(),
                ) {
                    items(pinnedFolders, key = { "fav_folder_${it.id}" }) { item ->
                        FavoriteFolderChip(
                            item      = item,
                            onClick   = { onItemClick(item) },
                            onLongClick = { onItemLongClick(item) },
                        )
                    }
                }
                Spacer(Modifier.height(SpacingTokens.md))
            }
        }

        if (pinnedFiles.isNotEmpty()) {
            item(key = "fav_files_header") {
                SectionHeader(
                    title    = "Favorite Files",
                    count    = pinnedFiles.size,
                    modifier = Modifier.animateItem(),
                )
            }
            items(
                items = pinnedFiles,
                key   = { "fav_${it.id}" },
            ) { item ->
                FileListItem(
                    item            = item,
                    isSelected      = selection.isSelected(item.id),
                    isSelectionMode = selection.isSelectionMode,
                    isCut           = false,
                    isSplitMode     = false,
                    onClick         = { onItemClick(item) },
                    onLongClick     = { onItemLongClick(item) },
                    onContextMenu   = { onContextMenu(item) },
                    modifier        = Modifier.animateItem(),
                )
            }
        }
    }
}

@Composable
private fun FavoriteFolderChip(
    item: FileItem,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
) {
    val ext = MaterialTheme.extended
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue   = if (isPressed) 0.94f else 1f,
        animationSpec = spring(stiffness = AnimationTokens.springStiff),
        label         = "favFolderScale",
    )

    Surface(
        color   = ext.folderColor.copy(alpha = 0.1f),
        shape   = ShapeTokens.cardShape,
        border  = BorderStroke(1.dp, ext.folderColor.copy(alpha = 0.3f)),
        modifier = Modifier
            .scale(scale)
            .width(120.dp)
            .combinedClickable(
                interactionSource = interactionSource,
                indication        = ripple(color = ext.folderColor),
                onClick           = onClick,
                onLongClick       = onLongClick,
            ),
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
            modifier            = Modifier.padding(SpacingTokens.md),
        ) {
            Icon(
                imageVector        = Icons.Rounded.Folder,
                contentDescription = null,
                tint               = ext.folderColor,
                modifier           = Modifier.size(36.dp),
            )
            Text(
                text      = item.name,
                style     = MaterialTheme.typography.labelSmall,
                color     = ext.textPrimary,
                maxLines  = 2,
                overflow  = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
            )
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 14 — STORAGE SCREEN
// ════════════════════════════════════════════════════════════

@Composable
fun StorageScreen(
    storageState: StorageState,
    onNavigate: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended

    LazyColumn(
        contentPadding = PaddingValues(
            horizontal = SpacingTokens.screenPaddingH,
            vertical   = SpacingTokens.sm,
        ),
        verticalArrangement = Arrangement.spacedBy(SpacingTokens.md),
        modifier            = modifier.fillMaxSize(),
    ) {
        // Volume cards
        items(storageState.volumes, key = { it.id }) { volume ->
            StorageVolumeCard(
                volume    = volume,
                onExplore = { onNavigate(volume.path) },
            )
        }

        // Category breakdown
        item(key = "category_header") {
            Text(
                text     = "BY CATEGORY",
                style    = ExtraTypography.overline,
                color    = ext.textSecondary,
                modifier = Modifier.padding(vertical = SpacingTokens.sm),
            )
        }

        // Category rows
        val breakdown = storageState.breakdown
        val total = breakdown.totalBytes.coerceAtLeast(1L)

        val categories = listOf(
            Triple("Images",   breakdown.imagesBytes,   ext.imageColor),
            Triple("Videos",   breakdown.videosBytes,   ext.videoColor),
            Triple("Audio",    breakdown.audioBytes,    ext.audioColor),
            Triple("Documents",breakdown.docsBytes,     ext.documentColor),
            Triple("APKs",     breakdown.apksBytes,     ext.apkColor),
            Triple("Archives", breakdown.archivesBytes, ext.archiveColor),
            Triple("Other",    breakdown.otherBytes,    ext.unknownColor),
        )

        items(categories, key = { it.first }) { (label, bytes, color) ->
            StorageCategoryRow(
                label    = label,
                bytes    = bytes,
                fraction = bytes.toFloat() / total,
                color    = color,
            )
        }

        item(key = "bottom_space") {
            Spacer(Modifier.height(SpacingTokens.giant))
        }
    }
}

@Composable
private fun StorageVolumeCard(
    volume: StorageVolume,
    onExplore: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended
    GlassCard(
        modifier       = modifier.fillMaxWidth(),
        onClick        = onExplore,
        contentPadding = PaddingValues(SpacingTokens.lg),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(SpacingTokens.md)) {
            // Header
            Row(
                verticalAlignment     = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier              = Modifier.fillMaxWidth(),
            ) {
                Row(
                    verticalAlignment     = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier         = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                Brush.linearGradient(ext.gradientPrimary)
                            ),
                    ) {
                        Icon(
                            imageVector = if (volume.isRemovable)
                                Icons.Rounded.SdCard
                            else
                                Icons.Rounded.PhoneAndroid,
                            contentDescription = null,
                            tint               = RawColors.White,
                            modifier           = Modifier.size(26.dp),
                        )
                    }
                    Column {
                        Text(
                            text  = volume.displayName,
                            style = MaterialTheme.typography.titleSmall,
                            color = ext.textPrimary,
                        )
                        Text(
                            text  = if (volume.isRemovable)
                                        "SD Card"
                                    else
                                        "Internal Storage",
                            style = MaterialTheme.typography.labelSmall,
                            color = ext.textSecondary,
                        )
                    }
                }
                FmActionChip(
                    label   = "Explore",
                    icon    = Icons.Rounded.FolderOpen,
                    onClick = onExplore,
                    color   = MaterialTheme.colorScheme.primary,
                )
            }

            // Usage numbers
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier              = Modifier.fillMaxWidth(),
            ) {
                Column {
                    Text(
                        text  = volume.displayUsed,
                        style = ExtraTypography.storagePct,
                        color = ext.textPrimary,
                    )
                    Text(
                        text  = "Used",
                        style = MaterialTheme.typography.labelSmall,
                        color = ext.textSecondary,
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text  = volume.displayFree,
                        style = ExtraTypography.storagePct,
                        color = MaterialTheme.colorScheme.primary,
                    )
                    Text(
                        text  = "Free",
                        style = MaterialTheme.typography.labelSmall,
                        color = ext.textSecondary,
                    )
                }
            }

            // Progress bar
            FmLinearProgress(
                progress = volume.usedFraction,
                label    = "${volume.usedPercent}% used of ${volume.displayTotal}",
            )
        }
    }
}

@Composable
private fun StorageCategoryRow(
    label: String,
    bytes: Long,
    fraction: Float,
    color: Color,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended
    val animFraction by animateFloatAsState(
        targetValue   = fraction,
        animationSpec = tween(AnimationTokens.durationXL, easing = FastOutSlowInEasing),
        label         = "catFraction",
    )

    Row(
        verticalAlignment     = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
        modifier              = modifier
            .fillMaxWidth()
            .padding(vertical = SpacingTokens.xs),
    ) {
        // Color dot
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(color),
        )

        // Label
        Text(
            text     = label,
            style    = MaterialTheme.typography.bodySmall,
            color    = ext.textPrimary,
            modifier = Modifier.width(80.dp),
        )

        // Bar
        Box(
            modifier = Modifier
                .weight(1f)
                .height(6.dp)
                .clip(RoundedCornerShape(999.dp))
                .background(ext.storageFree),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(animFraction.coerceIn(0f, 1f))
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(999.dp))
                    .background(color),
            )
        }

        // Size label
        Text(
            text  = FileItem.formatSize(bytes),
            style = ExtraTypography.sizeLabel,
            color = ext.textSecondary,
            modifier = Modifier.width(60.dp),
            textAlign = TextAlign.End,
        )
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 15 — DRAG TO OTHER PANE INDICATOR
//              (Split mode only — shows drop target highlight)
// ════════════════════════════════════════════════════════════

@Composable
fun SplitDropTargetOverlay(
    isVisible: Boolean,
    label: String = "Move to this pane",
    modifier: Modifier = Modifier,
) {
    AnimatedVisibility(
        visible  = isVisible,
        enter    = fadeIn() + scaleIn(initialScale = 0.95f),
        exit     = fadeOut() + scaleOut(targetScale = 0.95f),
        modifier = modifier.fillMaxSize().zIndex(10f),
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier         = Modifier
                .fillMaxSize()
                .background(
                    MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)
                )
                .border(
                    width = 2.dp,
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
                    shape = RoundedCornerShape(0.dp),
                ),
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(SpacingTokens.md),
            ) {
                Icon(
                    imageVector        = Icons.Rounded.DriveFileMove,
                    contentDescription = null,
                    tint               = MaterialTheme.colorScheme.primary,
                    modifier           = Modifier.size(48.dp),
                )
                Text(
                    text  = label,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 16 — SCROLL TO TOP BUTTON
// ════════════════════════════════════════════════════════════

@Composable
fun ScrollToTopButton(
    listState: LazyListState,
    modifier: Modifier = Modifier,
) {
    val scope      = rememberCoroutineScope()
    val showButton by remember {
        derivedStateOf { listState.firstVisibleItemIndex > 3 }
    }

    AnimatedVisibility(
        visible  = showButton,
        enter    = fadeIn() + scaleIn(),
        exit     = fadeOut() + scaleOut(),
        modifier = modifier,
    ) {
        SmallFloatingActionButton(
            onClick          = {
                scope.launch {
                    listState.animateScrollToItem(0)
                }
            },
            shape            = ShapeTokens.fabShape,
            containerColor   = MaterialTheme.colorScheme.secondaryContainer,
            contentColor     = MaterialTheme.colorScheme.onSecondaryContainer,
        ) {
            Icon(
                imageVector        = Icons.Rounded.KeyboardArrowUp,
                contentDescription = "Scroll to top",
                modifier           = Modifier.size(20.dp),
            )
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 17 — LOADING SHIMMER VIEWS
// ════════════════════════════════════════════════════════════

@Composable
fun ShimmerListLoadingView(modifier: Modifier = Modifier) {
    LazyColumn(
        contentPadding = PaddingValues(vertical = SpacingTokens.xs),
        modifier       = modifier.fillMaxSize(),
        userScrollEnabled = false,
    ) {
        items(12) {
            ShimmerFileListItem()
        }
    }
}

@Composable
fun ShimmerGridLoadingView(modifier: Modifier = Modifier) {
    LazyVerticalGrid(
        columns        = GridCells.Adaptive(minSize = 150.dp),
        contentPadding = PaddingValues(SpacingTokens.screenPaddingH),
        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.gridSpacing),
        verticalArrangement   = Arrangement.spacedBy(SpacingTokens.gridSpacing),
        modifier              = modifier.fillMaxSize(),
        userScrollEnabled     = false,
    ) {
        items(10) {
            ShimmerFileGridItem()
        }
    }
}

// ════════════════════════════════════════════════════════════
// END OF FILE 5 — FileGridListView.kt
// Next → File 6: ActionPanels.kt
// (BottomSheet: Copy/Move/Zip/Rename/Delete/Share/Info,
//  MultiSelect toolbar, ContextMenu, ProgressDialog,
//  ConflictDialog, ZipOptionsSheet, ExtractSheet)
// ════════════════════════════════════════════════════════════

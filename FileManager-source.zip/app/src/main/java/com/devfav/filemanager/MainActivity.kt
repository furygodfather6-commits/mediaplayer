package com.devfav.filemanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.remember
import com.devfav.filemanager.ui.screen.MainFileScreen
import com.devfav.filemanager.ui.theme.FileManagerTheme
import com.devfav.filemanager.ui.theme.ThemeState
import com.devfav.filemanager.ui.theme.rememberThemeState

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val themeState = rememberThemeState()
            val isDark = themeState.isDark()
            FileManagerTheme(
                darkTheme = isDark,
                dynamicColor = true,
            ) {
                MainFileScreen()
            }
        }
    }
}

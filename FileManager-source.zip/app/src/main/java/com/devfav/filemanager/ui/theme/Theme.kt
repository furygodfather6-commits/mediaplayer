@file:OptIn(
    androidx.compose.foundation.ExperimentalFoundationApi::class,
    androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.animation.ExperimentalAnimationApi::class,
    androidx.compose.ui.ExperimentalComposeUiApi::class
)

package com.devfav.filemanager.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.*
import androidx.compose.ui.unit.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*

// ════════════════════════════════════════════════════════════
// SECTION 1 — RAW COLOR PALETTE (Brand + Neutral + Accent)
// ════════════════════════════════════════════════════════════

object RawColors {

    // ── Primary Brand ──────────────────────────────────────
    val Brand50        = Color(0xFFE8F0FF)
    val Brand100       = Color(0xFFCCDAFF)
    val Brand200       = Color(0xFF9AB4FF)
    val Brand300       = Color(0xFF6690FF)
    val Brand400       = Color(0xFF3D6FFF)
    val Brand500       = Color(0xFF1A4FFF)   // Primary
    val Brand600       = Color(0xFF1440E0)
    val Brand700       = Color(0xFF0E30B8)
    val Brand800       = Color(0xFF092190)
    val Brand900       = Color(0xFF051568)

    // ── Accent Violet ──────────────────────────────────────
    val Violet50       = Color(0xFFF3EEFF)
    val Violet100      = Color(0xFFE4D9FF)
    val Violet200      = Color(0xFFCAB4FF)
    val Violet300      = Color(0xFFAF8EFF)
    val Violet400      = Color(0xFF9570FF)
    val Violet500      = Color(0xFF7C52FF)   // Accent
    val Violet600      = Color(0xFF6340E0)
    val Violet700      = Color(0xFF4B2FB8)
    val Violet800      = Color(0xFF332090)
    val Violet900      = Color(0xFF1C1268)

    // ── Cyan Glow (Dev Fav) ────────────────────────────────
    val Cyan300        = Color(0xFF67E8F9)
    val Cyan400        = Color(0xFF22D3EE)
    val Cyan500        = Color(0xFF06B6D4)   // Highlight
    val Cyan600        = Color(0xFF0891B2)

    // ── Success Green ──────────────────────────────────────
    val Green300       = Color(0xFF6EE7A0)
    val Green400       = Color(0xFF34D368)
    val Green500       = Color(0xFF10B981)
    val Green600       = Color(0xFF059669)

    // ── Warning Amber ──────────────────────────────────────
    val Amber300       = Color(0xFFFCD34D)
    val Amber400       = Color(0xFFFBBF24)
    val Amber500       = Color(0xFFF59E0B)
    val Amber600       = Color(0xFFD97706)

    // ── Error Red ──────────────────────────────────────────
    val Red300         = Color(0xFFFCA5A5)
    val Red400         = Color(0xFFF87171)
    val Red500         = Color(0xFFEF4444)
    val Red600         = Color(0xFFDC2626)

    // ── Neutral (Dark Theme Surfaces) ──────────────────────
    val Neutral50      = Color(0xFFF8FAFC)
    val Neutral100     = Color(0xFFF1F5F9)
    val Neutral150     = Color(0xFFE8EDF5)
    val Neutral200     = Color(0xFFE2E8F0)
    val Neutral300     = Color(0xFFCBD5E1)
    val Neutral400     = Color(0xFF94A3B8)
    val Neutral500     = Color(0xFF64748B)
    val Neutral600     = Color(0xFF475569)
    val Neutral700     = Color(0xFF334155)
    val Neutral800     = Color(0xFF1E293B)
    val Neutral850     = Color(0xFF172033)
    val Neutral900     = Color(0xFF0F172A)
    val Neutral950     = Color(0xFF080D1A)

    // ── Pure ───────────────────────────────────────────────
    val White          = Color(0xFFFFFFFF)
    val Black          = Color(0xFF000000)
    val Transparent    = Color(0x00000000)

    // ── Glass / Overlay ────────────────────────────────────
    val GlassDark      = Color(0x1AFFFFFF)   // 10% white
    val GlassMedium    = Color(0x26FFFFFF)   // 15% white
    val GlassLight     = Color(0x33FFFFFF)   // 20% white
    val OverlayDark    = Color(0x80000000)   // 50% black
    val OverlayMedium  = Color(0x40000000)   // 25% black
    val OverlayLight   = Color(0x1A000000)   // 10% black

    // ── Glow Colors ────────────────────────────────────────
    val GlowBlue       = Color(0x4D1A4FFF)
    val GlowViolet     = Color(0x4D7C52FF)
    val GlowCyan       = Color(0x4D06B6D4)
    val GlowGreen      = Color(0x4D10B981)
}

// ════════════════════════════════════════════════════════════
// SECTION 2 — SEMANTIC COLOR TOKENS (Light Theme)
// ════════════════════════════════════════════════════════════

private val LightColorScheme = lightColorScheme(

    // Primary
    primary                 = RawColors.Brand500,
    onPrimary               = RawColors.White,
    primaryContainer        = RawColors.Brand100,
    onPrimaryContainer      = RawColors.Brand900,

    // Secondary (Violet)
    secondary               = RawColors.Violet500,
    onSecondary             = RawColors.White,
    secondaryContainer      = RawColors.Violet100,
    onSecondaryContainer    = RawColors.Violet900,

    // Tertiary (Cyan)
    tertiary                = RawColors.Cyan500,
    onTertiary              = RawColors.White,
    tertiaryContainer       = Color(0xFFCCF5FC),
    onTertiaryContainer     = Color(0xFF003640),

    // Error
    error                   = RawColors.Red500,
    onError                 = RawColors.White,
    errorContainer          = RawColors.Red300,
    onErrorContainer        = Color(0xFF410002),

    // Background
    background              = RawColors.Neutral50,
    onBackground            = RawColors.Neutral900,

    // Surface
    surface                 = RawColors.White,
    onSurface               = RawColors.Neutral900,
    surfaceVariant          = RawColors.Neutral100,
    onSurfaceVariant        = RawColors.Neutral600,
    surfaceTint             = RawColors.Brand500,

    // Outline
    outline                 = RawColors.Neutral300,
    outlineVariant          = RawColors.Neutral200,

    // Inverse
    inverseSurface          = RawColors.Neutral800,
    inverseOnSurface        = RawColors.Neutral100,
    inversePrimary          = RawColors.Brand300,

    // Scrim
    scrim                   = RawColors.Black,
)

// ════════════════════════════════════════════════════════════
// SECTION 3 — SEMANTIC COLOR TOKENS (Dark Theme)
// ════════════════════════════════════════════════════════════

private val DarkColorScheme = darkColorScheme(

    // Primary
    primary                 = RawColors.Brand300,
    onPrimary               = RawColors.Brand900,
    primaryContainer        = RawColors.Brand700,
    onPrimaryContainer      = RawColors.Brand100,

    // Secondary
    secondary               = RawColors.Violet300,
    onSecondary             = RawColors.Violet900,
    secondaryContainer      = RawColors.Violet700,
    onSecondaryContainer    = RawColors.Violet100,

    // Tertiary
    tertiary                = RawColors.Cyan300,
    onTertiary              = Color(0xFF003640),
    tertiaryContainer       = RawColors.Cyan600,
    onTertiaryContainer     = Color(0xFFCCF5FC),

    // Error
    error                   = RawColors.Red300,
    onError                 = Color(0xFF690005),
    errorContainer          = RawColors.Red600,
    onErrorContainer        = RawColors.Red300,

    // Background
    background              = RawColors.Neutral950,
    onBackground            = RawColors.Neutral100,

    // Surface
    surface                 = RawColors.Neutral900,
    onSurface               = RawColors.Neutral100,
    surfaceVariant          = RawColors.Neutral800,
    onSurfaceVariant        = RawColors.Neutral400,
    surfaceTint             = RawColors.Brand300,

    // Outline
    outline                 = RawColors.Neutral600,
    outlineVariant          = RawColors.Neutral700,

    // Inverse
    inverseSurface          = RawColors.Neutral100,
    inverseOnSurface        = RawColors.Neutral800,
    inversePrimary          = RawColors.Brand600,

    // Scrim
    scrim                   = RawColors.Black,
)

// ════════════════════════════════════════════════════════════
// SECTION 4 — EXTENDED CUSTOM COLOR TOKENS
//             (Beyond M3 — Dev Premium Extras)
// ════════════════════════════════════════════════════════════

@Stable
class ExtendedColors(
    // ── File Type Colors ───────────────────────────────────
    val folderColor: Color,
    val folderColorAlt: Color,
    val imageColor: Color,
    val videoColor: Color,
    val audioColor: Color,
    val documentColor: Color,
    val archiveColor: Color,
    val apkColor: Color,
    val codeColor: Color,
    val unknownColor: Color,

    // ── Surface Elevations (Custom) ────────────────────────
    val surfaceElevated: Color,
    val surfaceOverlay: Color,
    val surfaceSheet: Color,
    val surfaceDialog: Color,

    // ── Glass / Frost ──────────────────────────────────────
    val glassBackground: Color,
    val glassBorder: Color,
    val glassBorderStrong: Color,

    // ── Selection ─────────────────────────────────────────
    val selectionBackground: Color,
    val selectionBorder: Color,
    val selectionCheck: Color,

    // ── Status ─────────────────────────────────────────────
    val success: Color,
    val onSuccess: Color,
    val successContainer: Color,
    val warning: Color,
    val onWarning: Color,
    val warningContainer: Color,

    // ── Storage Bar ────────────────────────────────────────
    val storageUsed: Color,
    val storageMedia: Color,
    val storageApps: Color,
    val storageDocs: Color,
    val storageFree: Color,

    // ── Gradient ───────────────────────────────────────────
    val gradientPrimary: List<Color>,
    val gradientAccent: List<Color>,
    val gradientSurface: List<Color>,
    val gradientCard: List<Color>,

    // ── Divider / Stroke ───────────────────────────────────
    val divider: Color,
    val stroke: Color,
    val strokeStrong: Color,

    // ── Text ───────────────────────────────────────────────
    val textPrimary: Color,
    val textSecondary: Color,
    val textTertiary: Color,
    val textDisabled: Color,
    val textOnColor: Color,

    // ── Icon ───────────────────────────────────────────────
    val iconPrimary: Color,
    val iconSecondary: Color,
    val iconTertiary: Color,

    // ── Glow ───────────────────────────────────────────────
    val glowPrimary: Color,
    val glowAccent: Color,

    // ── Shimmer ────────────────────────────────────────────
    val shimmerBase: Color,
    val shimmerHighlight: Color,

    // ── System ─────────────────────────────────────────────
    val isDark: Boolean,
)

// ── Light Extended ─────────────────────────────────────────
private val LightExtended = ExtendedColors(

    // File Types
    folderColor           = Color(0xFFFFA726),
    folderColorAlt        = Color(0xFFFF8F00),
    imageColor            = Color(0xFF26C6DA),
    videoColor            = Color(0xFFEF5350),
    audioColor            = Color(0xFFAB47BC),
    documentColor         = Color(0xFF42A5F5),
    archiveColor          = Color(0xFF8D6E63),
    apkColor              = Color(0xFF66BB6A),
    codeColor             = Color(0xFF26A69A),
    unknownColor          = Color(0xFF78909C),

    // Surface
    surfaceElevated       = Color(0xFFFFFFFF),
    surfaceOverlay        = Color(0xF2F8FAFC),
    surfaceSheet          = Color(0xFFFFFFFF),
    surfaceDialog         = Color(0xFFFFFFFF),

    // Glass
    glassBackground       = Color(0xB3FFFFFF),
    glassBorder           = Color(0x33000000),
    glassBorderStrong     = Color(0x66000000),

    // Selection
    selectionBackground   = Color(0x1A1A4FFF),
    selectionBorder       = RawColors.Brand500,
    selectionCheck        = RawColors.Brand500,

    // Status
    success               = RawColors.Green500,
    onSuccess             = RawColors.White,
    successContainer      = Color(0xFFD1FAE5),
    warning               = RawColors.Amber500,
    onWarning             = RawColors.White,
    warningContainer      = Color(0xFFFEF3C7),

    // Storage
    storageUsed           = RawColors.Brand500,
    storageMedia          = Color(0xFF26C6DA),
    storageApps           = Color(0xFFAB47BC),
    storageDocs           = Color(0xFF42A5F5),
    storageFree           = RawColors.Neutral200,

    // Gradients
    gradientPrimary       = listOf(RawColors.Brand400, RawColors.Violet500),
    gradientAccent        = listOf(RawColors.Cyan400, RawColors.Brand400),
    gradientSurface       = listOf(RawColors.Neutral50, RawColors.Neutral100),
    gradientCard          = listOf(RawColors.White, RawColors.Neutral50),

    // Divider
    divider               = Color(0x1A000000),
    stroke                = Color(0x1A000000),
    strokeStrong          = Color(0x33000000),

    // Text
    textPrimary           = RawColors.Neutral900,
    textSecondary         = RawColors.Neutral600,
    textTertiary          = RawColors.Neutral400,
    textDisabled          = RawColors.Neutral300,
    textOnColor           = RawColors.White,

    // Icon
    iconPrimary           = RawColors.Neutral700,
    iconSecondary         = RawColors.Neutral500,
    iconTertiary          = RawColors.Neutral400,

    // Glow
    glowPrimary           = RawColors.GlowBlue,
    glowAccent            = RawColors.GlowViolet,

    // Shimmer
    shimmerBase           = RawColors.Neutral200,
    shimmerHighlight      = RawColors.Neutral100,

    isDark                = false,
)

// ── Dark Extended ──────────────────────────────────────────
private val DarkExtended = ExtendedColors(

    // File Types
    folderColor           = Color(0xFFFFB74D),
    folderColorAlt        = Color(0xFFFFA726),
    imageColor            = Color(0xFF4DD0E1),
    videoColor            = Color(0xFFEF9A9A),
    audioColor            = Color(0xFFCE93D8),
    documentColor         = Color(0xFF90CAF9),
    archiveColor          = Color(0xFFBCAAA4),
    apkColor              = Color(0xFFA5D6A7),
    codeColor             = Color(0xFF80CBC4),
    unknownColor          = Color(0xFFB0BEC5),

    // Surface
    surfaceElevated       = Color(0xFF1A2540),
    surfaceOverlay        = Color(0xF20F172A),
    surfaceSheet          = Color(0xFF141E32),
    surfaceDialog         = Color(0xFF1A2540),

    // Glass
    glassBackground       = Color(0x1AFFFFFF),
    glassBorder           = Color(0x1AFFFFFF),
    glassBorderStrong     = Color(0x33FFFFFF),

    // Selection
    selectionBackground   = Color(0x266690FF),
    selectionBorder       = RawColors.Brand300,
    selectionCheck        = RawColors.Brand300,

    // Status
    success               = RawColors.Green400,
    onSuccess             = Color(0xFF003822),
    successContainer      = RawColors.Green600,
    warning               = RawColors.Amber400,
    onWarning             = Color(0xFF3D2000),
    warningContainer      = RawColors.Amber600,

    // Storage
    storageUsed           = RawColors.Brand300,
    storageMedia          = Color(0xFF4DD0E1),
    storageApps           = Color(0xFFCE93D8),
    storageDocs           = Color(0xFF90CAF9),
    storageFree           = RawColors.Neutral700,

    // Gradients
    gradientPrimary       = listOf(RawColors.Brand300, RawColors.Violet400),
    gradientAccent        = listOf(RawColors.Cyan300, RawColors.Brand300),
    gradientSurface       = listOf(RawColors.Neutral950, RawColors.Neutral900),
    gradientCard          = listOf(Color(0xFF141E32), Color(0xFF1A2540)),

    // Divider
    divider               = Color(0x1AFFFFFF),
    stroke                = Color(0x1AFFFFFF),
    strokeStrong          = Color(0x33FFFFFF),

    // Text
    textPrimary           = RawColors.Neutral50,
    textSecondary         = RawColors.Neutral400,
    textTertiary          = RawColors.Neutral600,
    textDisabled          = RawColors.Neutral700,
    textOnColor           = RawColors.White,

    // Icon
    iconPrimary           = RawColors.Neutral200,
    iconSecondary         = RawColors.Neutral400,
    iconTertiary          = RawColors.Neutral600,

    // Glow
    glowPrimary           = RawColors.GlowBlue,
    glowAccent            = RawColors.GlowViolet,

    // Shimmer
    shimmerBase           = Color(0xFF1E293B),
    shimmerHighlight      = Color(0xFF263045),

    isDark                = true,
)

// ════════════════════════════════════════════════════════════
// SECTION 5 — EXTENDED COLOR COMPOSITION LOCAL
// ════════════════════════════════════════════════════════════

val LocalExtendedColors = staticCompositionLocalOf<ExtendedColors> {
    error("No ExtendedColors provided — wrap with FileManagerTheme")
}

val MaterialTheme.extended: ExtendedColors
    @Composable
    @ReadOnlyComposable
    get() = LocalExtendedColors.current

// ════════════════════════════════════════════════════════════
// SECTION 6 — GRADIENT BRUSH HELPERS
// ════════════════════════════════════════════════════════════

object GradientTokens {

    // Primary gradient brush (Top-Left → Bottom-Right)
    @Composable
    fun primaryBrush(): Brush = Brush.linearGradientBrush(
        colors = MaterialTheme.extended.gradientPrimary,
        start  = Offset(0f, 0f),
        end    = Offset(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY),
    )

    // Accent gradient brush
    @Composable
    fun accentBrush(): Brush = Brush.linearGradientBrush(
        colors = MaterialTheme.extended.gradientAccent,
        start  = Offset(0f, 0f),
        end    = Offset(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY),
    )

    // Surface gradient (top → bottom)
    @Composable
    fun surfaceBrush(): Brush = Brush.verticalGradient(
        colors = MaterialTheme.extended.gradientSurface,
    )

    // Card gradient
    @Composable
    fun cardBrush(): Brush = Brush.linearGradientBrush(
        colors = MaterialTheme.extended.gradientCard,
        start  = Offset(0f, 0f),
        end    = Offset(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY),
    )

    // Folder gradient (warm amber)
    @Composable
    fun folderBrush(isDark: Boolean): Brush = Brush.linearGradientBrush(
        colors = if (isDark)
            listOf(Color(0xFFFFB74D), Color(0xFFFFA726))
        else
            listOf(Color(0xFFFFA726), Color(0xFFFF8F00)),
        start  = Offset(0f, 0f),
        end    = Offset(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY),
    )

    // Radial glow brush
    @Composable
    fun glowBrush(color: Color): Brush = Brush.radialGradient(
        colors = listOf(color.copy(alpha = 0.3f), Color.Transparent),
    )

    // Shimmer brush
    fun shimmerBrush(
        base: Color,
        highlight: Color,
        progress: Float,
    ): Brush = Brush.linearGradient(
        colors = listOf(base, highlight, base),
        start  = Offset(progress * 1000f - 200f, 0f),
        end    = Offset(progress * 1000f + 200f, 0f),
    )

    // Helper extension for linearGradient with brush
    private fun Brush.Companion.linearGradientBrush(
        colors: List<Color>,
        start: Offset,
        end: Offset,
    ): Brush = linearGradient(colors = colors, start = start, end = end)
}

// ════════════════════════════════════════════════════════════
// SECTION 7 — TYPOGRAPHY SYSTEM
//             Inter (UI) + JetBrains Mono (dev paths/code)
// ════════════════════════════════════════════════════════════

// Note: Add to fonts/ directory:
//   inter_thin.ttf, inter_light.ttf, inter_regular.ttf,
//   inter_medium.ttf, inter_semibold.ttf, inter_bold.ttf,
//   inter_extrabold.ttf, jetbrainsmono_regular.ttf,
//   jetbrainsmono_medium.ttf

// Using built-in Compose font families (custom Inter/JetBrainsMono TTFs not bundled)
// To use the original Inter/JetBrainsMono fonts, place the .ttf files under
// app/src/main/res/font/ and restore the R.font.* version above.
private val InterFamily = FontFamily.SansSerif

private val MonoFamily = FontFamily.Monospace

val FileManagerTypography = Typography(

    // ── Display ─────────────────────────────────────────────
    displayLarge = TextStyle(
        fontFamily    = InterFamily,
        fontWeight    = FontWeight.Bold,
        fontSize      = 57.sp,
        lineHeight    = 64.sp,
        letterSpacing = (-0.25).sp,
    ),
    displayMedium = TextStyle(
        fontFamily    = InterFamily,
        fontWeight    = FontWeight.Bold,
        fontSize      = 45.sp,
        lineHeight    = 52.sp,
        letterSpacing = 0.sp,
    ),
    displaySmall = TextStyle(
        fontFamily    = InterFamily,
        fontWeight    = FontWeight.SemiBold,
        fontSize      = 36.sp,
        lineHeight    = 44.sp,
        letterSpacing = 0.sp,
    ),

    // ── Headline ────────────────────────────────────────────
    headlineLarge = TextStyle(
        fontFamily    = InterFamily,
        fontWeight    = FontWeight.SemiBold,
        fontSize      = 32.sp,
        lineHeight    = 40.sp,
        letterSpacing = 0.sp,
    ),
    headlineMedium = TextStyle(
        fontFamily    = InterFamily,
        fontWeight    = FontWeight.SemiBold,
        fontSize      = 28.sp,
        lineHeight    = 36.sp,
        letterSpacing = 0.sp,
    ),
    headlineSmall = TextStyle(
        fontFamily    = InterFamily,
        fontWeight    = FontWeight.SemiBold,
        fontSize      = 24.sp,
        lineHeight    = 32.sp,
        letterSpacing = 0.sp,
    ),

    // ── Title ───────────────────────────────────────────────
    titleLarge = TextStyle(
        fontFamily    = InterFamily,
        fontWeight    = FontWeight.SemiBold,
        fontSize      = 22.sp,
        lineHeight    = 28.sp,
        letterSpacing = 0.sp,
    ),
    titleMedium = TextStyle(
        fontFamily    = InterFamily,
        fontWeight    = FontWeight.Medium,
        fontSize      = 16.sp,
        lineHeight    = 24.sp,
        letterSpacing = 0.15.sp,
    ),
    titleSmall = TextStyle(
        fontFamily    = InterFamily,
        fontWeight    = FontWeight.Medium,
        fontSize      = 14.sp,
        lineHeight    = 20.sp,
        letterSpacing = 0.1.sp,
    ),

    // ── Body ────────────────────────────────────────────────
    bodyLarge = TextStyle(
        fontFamily    = InterFamily,
        fontWeight    = FontWeight.Normal,
        fontSize      = 16.sp,
        lineHeight    = 24.sp,
        letterSpacing = 0.5.sp,
    ),
    bodyMedium = TextStyle(
        fontFamily    = InterFamily,
        fontWeight    = FontWeight.Normal,
        fontSize      = 14.sp,
        lineHeight    = 20.sp,
        letterSpacing = 0.25.sp,
    ),
    bodySmall = TextStyle(
        fontFamily    = InterFamily,
        fontWeight    = FontWeight.Normal,
        fontSize      = 12.sp,
        lineHeight    = 16.sp,
        letterSpacing = 0.4.sp,
    ),

    // ── Label ───────────────────────────────────────────────
    labelLarge = TextStyle(
        fontFamily    = InterFamily,
        fontWeight    = FontWeight.Medium,
        fontSize      = 14.sp,
        lineHeight    = 20.sp,
        letterSpacing = 0.1.sp,
    ),
    labelMedium = TextStyle(
        fontFamily    = InterFamily,
        fontWeight    = FontWeight.Medium,
        fontSize      = 12.sp,
        lineHeight    = 16.sp,
        letterSpacing = 0.5.sp,
    ),
    labelSmall = TextStyle(
        fontFamily    = InterFamily,
        fontWeight    = FontWeight.Medium,
        fontSize      = 11.sp,
        lineHeight    = 16.sp,
        letterSpacing = 0.5.sp,
    ),
)

// ── Extra Typography Styles (not in M3 spec) ───────────────
object ExtraTypography {

    // Path / breadcrumb mono style
    val pathStyle = TextStyle(
        fontFamily    = MonoFamily,
        fontWeight    = FontWeight.Normal,
        fontSize      = 12.sp,
        lineHeight    = 16.sp,
        letterSpacing = 0.sp,
    )

    // File size label
    val sizeLabel = TextStyle(
        fontFamily    = InterFamily,
        fontWeight    = FontWeight.Medium,
        fontSize      = 11.sp,
        lineHeight    = 14.sp,
        letterSpacing = 0.3.sp,
    )

    // Storage percentage
    val storagePct = TextStyle(
        fontFamily    = InterFamily,
        fontWeight    = FontWeight.Bold,
        fontSize      = 20.sp,
        lineHeight    = 24.sp,
        letterSpacing = (-0.3).sp,
    )

    // Tab label
    val tabLabel = TextStyle(
        fontFamily    = InterFamily,
        fontWeight    = FontWeight.SemiBold,
        fontSize      = 12.sp,
        lineHeight    = 16.sp,
        letterSpacing = 0.5.sp,
    )

    // Code / extension badge
    val extensionBadge = TextStyle(
        fontFamily    = MonoFamily,
        fontWeight    = FontWeight.Medium,
        fontSize      = 9.sp,
        lineHeight    = 12.sp,
        letterSpacing = 0.sp,
    )

    // Overline / Category
    val overline = TextStyle(
        fontFamily    = InterFamily,
        fontWeight    = FontWeight.SemiBold,
        fontSize      = 10.sp,
        lineHeight    = 14.sp,
        letterSpacing = 1.5.sp,
    )
}

// ════════════════════════════════════════════════════════════
// SECTION 8 — SHAPE SYSTEM
// ════════════════════════════════════════════════════════════

val FileManagerShapes = Shapes(
    extraSmall  = androidx.compose.foundation.shape.RoundedCornerShape(4.dp),
    small       = androidx.compose.foundation.shape.RoundedCornerShape(8.dp),
    medium      = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
    large       = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
    extraLarge  = androidx.compose.foundation.shape.RoundedCornerShape(24.dp),
)

// Custom shape tokens
object ShapeTokens {
    val radiusXXS  = 2.dp
    val radiusXS   = 4.dp
    val radiusSM   = 8.dp
    val radiusMD   = 12.dp
    val radiusLG   = 16.dp
    val radiusXL   = 20.dp
    val radiusXXL  = 24.dp
    val radius3XL  = 28.dp
    val radiusFull = 999.dp

    val cardShape        = androidx.compose.foundation.shape
        .RoundedCornerShape(16.dp)
    val chipShape        = androidx.compose.foundation.shape
        .RoundedCornerShape(999.dp)
    val bottomSheetShape = androidx.compose.foundation.shape
        .RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    val dialogShape      = androidx.compose.foundation.shape
        .RoundedCornerShape(24.dp)
    val fabShape         = androidx.compose.foundation.shape
        .RoundedCornerShape(16.dp)
    val searchShape      = androidx.compose.foundation.shape
        .RoundedCornerShape(14.dp)
    val badgeShape       = androidx.compose.foundation.shape
        .RoundedCornerShape(999.dp)
    val tooltipShape     = androidx.compose.foundation.shape
        .RoundedCornerShape(8.dp)
}

// ════════════════════════════════════════════════════════════
// SECTION 9 — SPACING / LAYOUT TOKENS
// ════════════════════════════════════════════════════════════

object SpacingTokens {
    val xxs   = 2.dp
    val xs    = 4.dp
    val sm    = 8.dp
    val md    = 12.dp
    val lg    = 16.dp
    val xl    = 20.dp
    val xxl   = 24.dp
    val xxxl  = 32.dp
    val huge  = 40.dp
    val giant = 48.dp

    // Component specific
    val screenPaddingH      = 16.dp
    val screenPaddingV      = 12.dp
    val cardPadding         = 14.dp
    val listItemPaddingH    = 16.dp
    val listItemPaddingV    = 12.dp
    val gridSpacing         = 10.dp
    val sectionSpacing      = 24.dp
    val iconSize            = 20.dp
    val iconSizeLg          = 24.dp
    val iconSizeXl          = 32.dp
    val iconSizeFolder      = 44.dp
    val fabSize             = 56.dp
    val bottomBarHeight     = 80.dp
    val topBarHeight        = 64.dp
    val searchBarHeight     = 52.dp
    val breadcrumbHeight    = 40.dp
    val storageBarHeight    = 56.dp
    val listItemHeight      = 64.dp
    val gridItemSize        = 160.dp
    val bottomSheetPeek     = 120.dp
}

// ════════════════════════════════════════════════════════════
// SECTION 10 — ANIMATION TOKENS
// ════════════════════════════════════════════════════════════

object AnimationTokens {
    // Durations (ms)
    const val durationXS       = 100
    const val durationSM       = 150
    const val durationMD       = 250
    const val durationLG       = 350
    const val durationXL       = 500
    const val durationShimmer  = 1200

    // Spring specs
    val springStiff   = androidx.compose.animation.core.Spring.StiffnessMedium
    val springBouncy  = androidx.compose.animation.core.Spring.StiffnessLow
    val springSnappy  = androidx.compose.animation.core.Spring.StiffnessHigh

    // Scale values
    const val pressedScale     = 0.96f
    const val selectedScale    = 1.02f
    const val normalScale      = 1.0f
}

// ════════════════════════════════════════════════════════════
// SECTION 11 — ELEVATION TOKENS
// ════════════════════════════════════════════════════════════

object ElevationTokens {
    val none   = 0.dp
    val xs     = 1.dp
    val sm     = 2.dp
    val md     = 4.dp
    val lg     = 8.dp
    val xl     = 12.dp
    val xxl    = 16.dp

    // Component
    val card        = 2.dp
    val cardHover   = 8.dp
    val fab         = 6.dp
    val appBar      = 0.dp
    val bottomBar   = 8.dp
    val dialog      = 24.dp
    val sheet       = 8.dp
    val tooltip     = 4.dp
    val menu        = 8.dp
}

// ════════════════════════════════════════════════════════════
// SECTION 12 — MAIN THEME COMPOSABLE
// ════════════════════════════════════════════════════════════

@Composable
fun FileManagerTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    // Dynamic Color (Android 12+) — optional
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && android.os.Build.VERSION.SDK_INT
                >= android.os.Build.VERSION_CODES.S -> {
            val context = androidx.compose.ui.platform.LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context)
            else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else      -> LightColorScheme
    }

    val extendedColors = if (darkTheme) DarkExtended else LightExtended

    // Status bar color — transparent for edge-to-edge
    val view = androidx.compose.ui.platform.LocalView.current
    if (!view.isInEditMode) {
        androidx.compose.runtime.SideEffect {
            val window = (view.context as android.app.Activity).window
            window.statusBarColor = android.graphics.Color.TRANSPARENT
            androidx.core.view.WindowCompat
                .getInsetsController(window, view)
                .isAppearanceLightStatusBars = !darkTheme
        }
    }

    CompositionLocalProvider(
        LocalExtendedColors provides extendedColors,
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography  = FileManagerTypography,
            shapes      = FileManagerShapes,
            content     = content,
        )
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 13 — THEME STATE HOLDER (remember dark mode toggle)
// ════════════════════════════════════════════════════════════

enum class ThemeMode {
    LIGHT, DARK, SYSTEM
}

@Stable
class ThemeState(initialMode: ThemeMode = ThemeMode.SYSTEM) {
    var mode by mutableStateOf(initialMode)

    @Composable
    fun isDark(): Boolean = when (mode) {
        ThemeMode.LIGHT  -> false
        ThemeMode.DARK   -> true
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    fun toggle() {
        mode = when (mode) {
            ThemeMode.LIGHT  -> ThemeMode.DARK
            ThemeMode.DARK   -> ThemeMode.SYSTEM
            ThemeMode.SYSTEM -> ThemeMode.LIGHT
        }
    }
}

@Composable
fun rememberThemeState(
    initialMode: ThemeMode = ThemeMode.SYSTEM,
): ThemeState = remember { ThemeState(initialMode) }

// ════════════════════════════════════════════════════════════
// END OF FILE 1 — Theme.kt
// Next → File 2: DesignSystem.kt
// (Glass components, Premium buttons, Cards, Chips, FAB,
//  SearchBar base, BottomSheet scaffold, Icon wrappers)
// ════════════════════════════════════════════════════════════

@file:OptIn(
    androidx.compose.foundation.ExperimentalFoundationApi::class,
    androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.animation.ExperimentalAnimationApi::class,
    androidx.compose.ui.ExperimentalComposeUiApi::class
)

package com.devfav.filemanager.ui.panels


import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.*
import androidx.compose.ui.focus.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.hapticfeedback.*
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.input.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import androidx.compose.ui.window.*
import com.devfav.filemanager.ui.design.*
import com.devfav.filemanager.ui.state.*
import com.devfav.filemanager.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.devfav.filemanager.ui.screen.FileIconWithThumbnail

// ════════════════════════════════════════════════════════════
// SECTION 1 — CONTEXT MENU (Popup style)
//             Appears on long press / right click
// ════════════════════════════════════════════════════════════

@Composable
fun FileContextMenu(
    item: FileItem,
    visible: Boolean,
    onDismiss: () -> Unit,
    fmState: FileManagerState,
    modifier: Modifier = Modifier,
) {
    val ext        = MaterialTheme.extended
    val haptic     = LocalHapticFeedback.current
    val isSplit    = fmState.splitScreen.isSplit
    val hasClip    = fmState.clipboard.hasItems

    val actions = remember(item, hasClip, isSplit) {
        if (item.isDirectory)
            ContextActions.forFolder(item, hasClip, isSplit)
        else
            ContextActions.forFile(item, hasClip, isSplit)
    }

    AnimatedVisibility(
        visible  = visible,
        enter    = fadeIn(tween(AnimationTokens.durationSM)) +
                   scaleIn(
                       initialScale  = 0.88f,
                       animationSpec = spring(stiffness = AnimationTokens.springStiff),
                   ),
        exit     = fadeOut(tween(AnimationTokens.durationSM)) +
                   scaleOut(targetScale = 0.88f),
        modifier = modifier,
    ) {
        Surface(
            color           = ext.surfaceDialog,
            shape           = ShapeTokens.dialogShape,
            shadowElevation = ElevationTokens.menu,
            border          = BorderStroke(0.5.dp, ext.glassBorder),
            modifier        = Modifier.width(240.dp),
        ) {
            Column(modifier = Modifier.padding(vertical = SpacingTokens.sm)) {

                // ── Item header ────────────────────────────
                ContextMenuHeader(item = item)
                FmDivider(modifier = Modifier.padding(vertical = SpacingTokens.xs))

                // ── Actions ────────────────────────────────
                actions.forEach { action ->
                    if (action.isDividerBefore) {
                        FmDivider(
                            modifier = Modifier.padding(vertical = SpacingTokens.xs),
                        )
                    }
                    ContextMenuActionRow(
                        action   = action,
                        onClick  = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            onDismiss()
                            handleContextAction(
                                actionId = action.id,
                                item     = item,
                                fmState  = fmState,
                            )
                        },
                    )
                }
            }
        }
    }
}

@Composable
private fun ContextMenuHeader(item: FileItem) {
    val ext = MaterialTheme.extended
    Row(
        verticalAlignment     = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
        modifier              = Modifier
            .fillMaxWidth()
            .padding(
                horizontal = SpacingTokens.lg,
                vertical   = SpacingTokens.sm,
            ),
    ) {
        FileIconWithThumbnail(
            item      = item,
            size      = 36.dp,
            showBadge = false,
        )
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text     = item.name,
                style    = MaterialTheme.typography.labelLarge,
                color    = ext.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text  = item.displaySize,
                style = MaterialTheme.typography.labelSmall,
                color = ext.textSecondary,
            )
        }
    }
}

@Composable
private fun ContextMenuActionRow(
    action: ContextAction,
    onClick: () -> Unit,
) {
    val ext               = MaterialTheme.extended
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed         by interactionSource.collectIsPressedAsState()

    val bgColor by animateColorAsState(
        targetValue = if (isPressed)
            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
        else
            Color.Transparent,
        label = "ctxMenuBg",
    )

    Row(
        verticalAlignment     = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
        modifier              = Modifier
            .fillMaxWidth()
            .height(44.dp)
            .background(bgColor)
            .clickable(
                interactionSource = interactionSource,
                indication        = ripple(
                    color = if (action.isDanger)
                        MaterialTheme.colorScheme.error
                    else
                        MaterialTheme.colorScheme.primary,
                    bounded = true,
                ),
                enabled           = action.enabled,
                onClick           = onClick,
            )
            .padding(horizontal = SpacingTokens.lg)
            .alpha(if (action.enabled) 1f else 0.4f),
    ) {
        val iconTint = when {
            action.isDanger -> MaterialTheme.colorScheme.error
            action.color != null -> action.color
            else -> ext.iconPrimary
        }
        Icon(
            imageVector        = action.icon,
            contentDescription = null,
            tint               = iconTint,
            modifier           = Modifier.size(18.dp),
        )
        Text(
            text  = action.label,
            style = MaterialTheme.typography.bodyMedium,
            color = if (action.isDanger)
                        MaterialTheme.colorScheme.error
                    else
                        ext.textPrimary,
        )
        if (!action.enabled) {
            Spacer(Modifier.weight(1f))
            Icon(
                imageVector        = Icons.Rounded.Lock,
                contentDescription = null,
                tint               = ext.iconTertiary,
                modifier           = Modifier.size(12.dp),
            )
        }
    }
}

// ── Context action handler ──────────────────────────────────
private fun handleContextAction(
    actionId: String,
    item: FileItem,
    fmState: FileManagerState,
) {
    when (actionId) {
        "open"            -> { /* open item */ }
        "open_with"       -> { /* show open-with sheet */ }
        "open_other_pane" -> {
            val otherPane = if (fmState.splitScreen.activePane == ActivePane.PRIMARY)
                ActivePane.SECONDARY else ActivePane.PRIMARY
            fmState.navigateTo(item.path, otherPane)
        }
        "copy"            -> {
            fmState.clipboard.copy(listOf(item))
            fmState.showSnackbar("Copied: ${item.name}", SnackbarType.INFO)
        }
        "cut"             -> {
            fmState.clipboard.cut(listOf(item))
            fmState.showSnackbar("Cut: ${item.name}", SnackbarType.INFO)
        }
        "paste"           -> { /* trigger paste */ }
        "share"           -> { /* launch share intent */ }
        "rename"          -> {
            fmState.renameTarget = item
            fmState.showRenameDialog = true
        }
        "delete"          -> {
            fmState.contextMenuTarget = item
            fmState.showDeleteDialog = true
        }
        "compress"        -> {
            fmState.showZipDialog = true
        }
        "info"            -> {
            fmState.propertiesTarget = item
            fmState.showPropertiesSheet = true
        }
        "favorite"        -> {
            fmState.showSnackbar("Added to favorites", SnackbarType.SUCCESS)
        }
        "unfavorite"      -> {
            fmState.showSnackbar("Removed from favorites", SnackbarType.INFO)
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 2 — OPERATION PROGRESS SHEET
//             Copy / Move / Zip / Extract progress UI
// ════════════════════════════════════════════════════════════

@Composable
fun OperationProgressSheet(
    operationState: OperationState,
    onCancel: () -> Unit,
    onPauseResume: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val status = operationState.status
    if (status !is OperationStatus.Running) return

    val ext = MaterialTheme.extended

    FmBottomSheet(
        visible              = true,
        onDismiss            = { /* non-dismissable during operation */ },
        showDragHandle       = false,
        skipPartiallyExpanded = true,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(
                    horizontal = SpacingTokens.screenPaddingH,
                    vertical   = SpacingTokens.lg,
                ),
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.lg),
        ) {
            // ── Header ──────────────────────────────────────
            Row(
                verticalAlignment     = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier              = Modifier.fillMaxWidth(),
            ) {
                Row(
                    verticalAlignment     = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
                ) {
                    // Animated operation icon
                    OperationIconAnimated(type = status.type)
                    Column {
                        Text(
                            text  = status.type.displayName,
                            style = MaterialTheme.typography.titleMedium,
                            color = ext.textPrimary,
                        )
                        Text(
                            text  = "${status.processedCount} of ${status.totalCount} items",
                            style = MaterialTheme.typography.labelSmall,
                            color = ext.textSecondary,
                        )
                    }
                }

                // Pause / Resume button
                if (status.canPause) {
                    FmIconButton(
                        icon               = if (status.isPaused)
                                                 Icons.Rounded.PlayArrow
                                             else
                                                 Icons.Rounded.Pause,
                        contentDescription = if (status.isPaused) "Resume" else "Pause",
                        onClick            = onPauseResume,
                        tint               = MaterialTheme.colorScheme.primary,
                    )
                }
            }

            // ── Progress bar ────────────────────────────────
            FmLinearProgress(
                progress = status.progress,
                label    = null,
            )

            // ── Current file ────────────────────────────────
            Row(
                verticalAlignment     = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
            ) {
                Icon(
                    imageVector        = Icons.Rounded.InsertDriveFile,
                    contentDescription = null,
                    tint               = ext.iconTertiary,
                    modifier           = Modifier.size(14.dp),
                )
                Text(
                    text     = status.currentFile.ifEmpty { "Preparing..." },
                    style    = ExtraTypography.pathStyle,
                    color    = ext.textTertiary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
            }

            // ── Stats row ───────────────────────────────────
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier              = Modifier.fillMaxWidth(),
            ) {
                ProgressStatItem(
                    label = "Speed",
                    value = status.speed,
                    icon  = Icons.Rounded.Speed,
                )
                ProgressStatItem(
                    label = "ETA",
                    value = status.eta,
                    icon  = Icons.Rounded.Timer,
                )
                ProgressStatItem(
                    label = "Progress",
                    value = "${(status.progress * 100).toInt()}%",
                    icon  = Icons.Rounded.Percent,
                )
                ProgressStatItem(
                    label = "Transferred",
                    value = FileItem.formatSize(status.processedBytes),
                    icon  = Icons.Rounded.DataUsage,
                )
            }

            // ── Paused banner ────────────────────────────────
            AnimatedVisibility(visible = status.isPaused) {
                Surface(
                    color  = RawColors.Amber500.copy(alpha = 0.12f),
                    shape  = ShapeTokens.cardShape,
                    border = BorderStroke(1.dp, RawColors.Amber500.copy(alpha = 0.3f)),
                ) {
                    Row(
                        verticalAlignment     = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
                        modifier              = Modifier
                            .fillMaxWidth()
                            .padding(SpacingTokens.md),
                    ) {
                        Icon(
                            imageVector        = Icons.Rounded.Pause,
                            contentDescription = null,
                            tint               = RawColors.Amber500,
                            modifier           = Modifier.size(16.dp),
                        )
                        Text(
                            text  = "Operation paused",
                            style = MaterialTheme.typography.labelMedium,
                            color = RawColors.Amber500,
                        )
                    }
                }
            }

            // ── Cancel button ────────────────────────────────
            FmDangerButton(
                text     = "Cancel",
                onClick  = onCancel,
                modifier = Modifier.fillMaxWidth(),
            )

            Spacer(Modifier.height(SpacingTokens.sm))
        }
    }
}

@Composable
private fun ProgressStatItem(
    label: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
) {
    val ext = MaterialTheme.extended
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(SpacingTokens.xxs),
    ) {
        Icon(
            imageVector        = icon,
            contentDescription = null,
            tint               = ext.iconSecondary,
            modifier           = Modifier.size(14.dp),
        )
        Text(
            text  = value,
            style = MaterialTheme.typography.labelMedium,
            color = ext.textPrimary,
        )
        Text(
            text  = label,
            style = MaterialTheme.typography.labelSmall,
            color = ext.textTertiary,
        )
    }
}

@Composable
private fun OperationIconAnimated(type: OperationType) {
    val infiniteTransition = rememberInfiniteTransition(label = "opIcon")
    val rotation by infiniteTransition.animateFloat(
        initialValue  = 0f,
        targetValue   = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
        ),
        label = "iconRotation",
    )

    Box(
        contentAlignment = Alignment.Center,
        modifier         = Modifier
            .size(44.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(
                MaterialTheme.colorScheme.primaryContainer
            ),
    ) {
        Icon(
            imageVector = when (type) {
                OperationType.COPY    -> Icons.Rounded.ContentCopy
                OperationType.MOVE    -> Icons.Rounded.DriveFileMove
                OperationType.DELETE  -> Icons.Rounded.Delete
                OperationType.ZIP     -> Icons.Rounded.FolderZip
                OperationType.EXTRACT -> Icons.Rounded.Unarchive
                OperationType.RENAME  -> Icons.Rounded.Edit
                OperationType.SHARE   -> Icons.Rounded.Share
            },
            contentDescription = null,
            tint               = MaterialTheme.colorScheme.onPrimaryContainer,
            modifier           = Modifier
                .size(22.dp)
                .then(
                    if (type == OperationType.ZIP || type == OperationType.COPY)
                        Modifier.rotate(rotation * 0f) // static for copy/zip
                    else
                        Modifier
                ),
        )
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 3 — DELETE CONFIRMATION DIALOG
// ════════════════════════════════════════════════════════════

@Composable
fun DeleteConfirmDialog(
    items: List<FileItem>,
    visible: Boolean,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
) {
    if (!visible) return
    val ext = MaterialTheme.extended

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape           = ShapeTokens.dialogShape,
            color           = ext.surfaceDialog,
            shadowElevation = ElevationTokens.dialog,
            modifier        = modifier.fillMaxWidth(),
        ) {
            Column(
                modifier = Modifier.padding(SpacingTokens.xxl),
                verticalArrangement = Arrangement.spacedBy(SpacingTokens.lg),
            ) {
                // Warning icon
                Box(
                    contentAlignment = Alignment.Center,
                    modifier         = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(
                            MaterialTheme.colorScheme.errorContainer
                        ),
                ) {
                    Icon(
                        imageVector        = Icons.Rounded.Delete,
                        contentDescription = null,
                        tint               = MaterialTheme.colorScheme.onErrorContainer,
                        modifier           = Modifier.size(28.dp),
                    )
                }

                // Title
                Text(
                    text  = if (items.size == 1) "Delete Item?" else "Delete ${items.size} Items?",
                    style = MaterialTheme.typography.titleLarge,
                    color = ext.textPrimary,
                )

                // Description
                Text(
                    text  = buildDeleteMessage(items),
                    style = MaterialTheme.typography.bodyMedium,
                    color = ext.textSecondary,
                )

                // Items preview (up to 3)
                if (items.size <= 5) {
                    Surface(
                        color  = MaterialTheme.colorScheme.surfaceVariant,
                        shape  = ShapeTokens.cardShape,
                    ) {
                        Column(
                            modifier = Modifier.padding(SpacingTokens.md),
                            verticalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
                        ) {
                            items.take(3).forEach { item ->
                                Row(
                                    verticalAlignment     = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
                                ) {
                                    Icon(
                                        imageVector = if (item.isDirectory)
                                            Icons.Rounded.Folder
                                        else
                                            Icons.Rounded.InsertDriveFile,
                                        contentDescription = null,
                                        tint               = if (item.isDirectory)
                                                                 MaterialTheme.extended.folderColor
                                                             else
                                                                 MaterialTheme.extended.iconSecondary,
                                        modifier           = Modifier.size(16.dp),
                                    )
                                    Text(
                                        text     = item.name,
                                        style    = MaterialTheme.typography.bodySmall,
                                        color    = ext.textPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                }
                            }
                            if (items.size > 3) {
                                Text(
                                    text  = "...and ${items.size - 3} more",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ext.textTertiary,
                                )
                            }
                        }
                    }
                }

                // Warning note
                Row(
                    verticalAlignment     = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
                ) {
                    Icon(
                        imageVector        = Icons.Rounded.Warning,
                        contentDescription = null,
                        tint               = RawColors.Amber500,
                        modifier           = Modifier.size(14.dp).padding(top = 2.dp),
                    )
                    Text(
                        text  = "This action cannot be undone. Files will be permanently deleted.",
                        style = MaterialTheme.typography.labelSmall,
                        color = ext.textSecondary,
                    )
                }

                // Buttons
                Row(
                    horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
                    modifier              = Modifier.fillMaxWidth(),
                ) {
                    FmSecondaryButton(
                        text     = "Cancel",
                        onClick  = onDismiss,
                        modifier = Modifier.weight(1f),
                    )
                    FmDangerButton(
                        text     = "Delete",
                        onClick  = onConfirm,
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }
    }
}

private fun buildDeleteMessage(items: List<FileItem>): String {
    return when {
        items.size == 1 && items[0].isDirectory ->
            "\"${items[0].name}\" and all its contents will be permanently deleted."
        items.size == 1 ->
            "\"${items[0].name}\" will be permanently deleted."
        items.any { it.isDirectory } ->
            "${items.size} items including folders and their contents will be deleted."
        else ->
            "${items.size} files will be permanently deleted."
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 4 — RENAME DIALOG
// ════════════════════════════════════════════════════════════

@Composable
fun RenameDialog(
    item: FileItem,
    visible: Boolean,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
) {
    if (!visible) return
    val ext = MaterialTheme.extended

    // Pre-fill name (without extension for files)
    var nameText by remember(item) {
        mutableStateOf(
            if (!item.isDirectory && item.extension.isNotEmpty())
                item.name.removeSuffix(".${item.extension}")
            else
                item.name
        )
    }
    var isError by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }
    val focusRequester = remember { FocusRequester() }

    LaunchedEffect(visible) {
        if (visible) {
            delay(150)
            focusRequester.requestFocus()
        }
    }

    // Validation
    LaunchedEffect(nameText) {
        isError = false
        errorMessage = ""
        when {
            nameText.isBlank() -> {
                isError = true
                errorMessage = "Name cannot be empty"
            }
            nameText.any { it in "/\\:*?\"<>|" } -> {
                isError = true
                errorMessage = "Name contains invalid characters"
            }
            nameText.startsWith(".") && !item.isHidden -> {
                // warn but allow
            }
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape           = ShapeTokens.dialogShape,
            color           = ext.surfaceDialog,
            shadowElevation = ElevationTokens.dialog,
            modifier        = modifier.fillMaxWidth(),
        ) {
            Column(
                modifier = Modifier.padding(SpacingTokens.xxl),
                verticalArrangement = Arrangement.spacedBy(SpacingTokens.lg),
            ) {
                // Header
                Row(
                    verticalAlignment     = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier         = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer),
                    ) {
                        Icon(
                            imageVector        = Icons.Rounded.Edit,
                            contentDescription = null,
                            tint               = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier           = Modifier.size(22.dp),
                        )
                    }
                    Column {
                        Text(
                            text  = "Rename",
                            style = MaterialTheme.typography.titleMedium,
                            color = ext.textPrimary,
                        )
                        Text(
                            text  = if (item.isDirectory) "Folder" else "File",
                            style = MaterialTheme.typography.labelSmall,
                            color = ext.textSecondary,
                        )
                    }
                }

                // Text field
                Column(
                    verticalArrangement = Arrangement.spacedBy(SpacingTokens.xs),
                ) {
                    FmTextField(
                        value            = nameText,
                        onValueChange    = { nameText = it },
                        label            = "New name",
                        isError          = isError,
                        focusRequester   = focusRequester,
                        trailingContent  = if (nameText.isNotEmpty()) {
                            {
                                FmIconButton(
                                    icon               = Icons.Rounded.Close,
                                    contentDescription = "Clear",
                                    onClick            = { nameText = "" },
                                    tint               = ext.iconSecondary,
                                    containerSize      = 28.dp,
                                    size               = 16.dp,
                                )
                            }
                        } else null,
                    )

                    // Extension note
                    if (!item.isDirectory && item.extension.isNotEmpty()) {
                        Row(
                            verticalAlignment     = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(SpacingTokens.xs),
                        ) {
                            Icon(
                                imageVector        = Icons.Rounded.Info,
                                contentDescription = null,
                                tint               = ext.iconTertiary,
                                modifier           = Modifier.size(12.dp),
                            )
                            Text(
                                text  = "Extension .${item.extension} will be preserved",
                                style = MaterialTheme.typography.labelSmall,
                                color = ext.textTertiary,
                            )
                        }
                    }

                    // Error message
                    AnimatedVisibility(visible = isError && errorMessage.isNotEmpty()) {
                        Text(
                            text  = errorMessage,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.error,
                        )
                    }
                }

                // Character counter
                Row(
                    horizontalArrangement = Arrangement.End,
                    modifier              = Modifier.fillMaxWidth(),
                ) {
                    Text(
                        text  = "${nameText.length}/255",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (nameText.length > 200)
                                    MaterialTheme.colorScheme.error
                                else
                                    ext.textTertiary,
                    )
                }

                // Buttons
                Row(
                    horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
                    modifier              = Modifier.fillMaxWidth(),
                ) {
                    FmSecondaryButton(
                        text     = "Cancel",
                        onClick  = onDismiss,
                        modifier = Modifier.weight(1f),
                    )
                    FmPrimaryButton(
                        text     = "Rename",
                        onClick  = {
                            if (!isError && nameText.isNotBlank()) {
                                val finalName = if (!item.isDirectory &&
                                                    item.extension.isNotEmpty())
                                    "$nameText.${item.extension}"
                                else
                                    nameText
                                onConfirm(finalName)
                            }
                        },
                        enabled  = !isError && nameText.isNotBlank(),
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 5 — CREATE FOLDER DIALOG
// ════════════════════════════════════════════════════════════

@Composable
fun CreateFolderDialog(
    visible: Boolean,
    currentPath: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
) {
    if (!visible) return
    val ext            = MaterialTheme.extended
    var folderName     by remember { mutableStateOf("") }
    var isError        by remember { mutableStateOf(false) }
    val focusRequester = remember { FocusRequester() }

    LaunchedEffect(visible) {
        if (visible) {
            folderName = ""
            isError    = false
            delay(150)
            focusRequester.requestFocus()
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape           = ShapeTokens.dialogShape,
            color           = ext.surfaceDialog,
            shadowElevation = ElevationTokens.dialog,
            modifier        = modifier.fillMaxWidth(),
        ) {
            Column(
                modifier = Modifier.padding(SpacingTokens.xxl),
                verticalArrangement = Arrangement.spacedBy(SpacingTokens.lg),
            ) {
                // Header with gradient icon
                Row(
                    verticalAlignment     = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier         = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                Brush.linearGradient(ext.gradientPrimary)
                            ),
                    ) {
                        Icon(
                            imageVector        = Icons.Rounded.CreateNewFolder,
                            contentDescription = null,
                            tint               = RawColors.White,
                            modifier           = Modifier.size(26.dp),
                        )
                    }
                    Column {
                        Text(
                            text  = "New Folder",
                            style = MaterialTheme.typography.titleMedium,
                            color = ext.textPrimary,
                        )
                        // Current path hint
                        Text(
                            text     = currentPath
                                .replace("/storage/emulated/0", "Internal")
                                .let { if (it.length > 30) "...${it.takeLast(28)}" else it },
                            style    = ExtraTypography.pathStyle,
                            color    = ext.textTertiary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }

                // Text field
                FmTextField(
                    value          = folderName,
                    onValueChange  = {
                        folderName = it
                        isError    = it.any { c -> c in "/\\:*?\"<>|" }
                    },
                    label          = "Folder name",
                    placeholder    = "e.g. My Projects",
                    isError        = isError,
                    focusRequester = focusRequester,
                    keyboardAction = ImeAction.Done,
                    onKeyboardDone = {
                        if (folderName.isNotBlank() && !isError) {
                            onConfirm(folderName.trim())
                        }
                    },
                )

                // Suggested names
                if (folderName.isEmpty()) {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(SpacingTokens.xs),
                    ) {
                        Text(
                            text  = "Suggestions",
                            style = MaterialTheme.typography.labelSmall,
                            color = ext.textTertiary,
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
                            modifier              = Modifier.horizontalScroll(
                                rememberScrollState()
                            ),
                        ) {
                            listOf(
                                "New Folder",
                                "Backup",
                                "Projects",
                                "Documents",
                                "Archive",
                            ).forEach { suggestion ->
                                FmFilterChip(
                                    label    = suggestion,
                                    selected = false,
                                    onClick  = { folderName = suggestion },
                                )
                            }
                        }
                    }
                }

                // Error
                AnimatedVisibility(visible = isError) {
                    Text(
                        text  = "Folder name contains invalid characters",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }

                // Buttons
                Row(
                    horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
                    modifier              = Modifier.fillMaxWidth(),
                ) {
                    FmSecondaryButton(
                        text     = "Cancel",
                        onClick  = onDismiss,
                        modifier = Modifier.weight(1f),
                    )
                    FmPrimaryButton(
                        text     = "Create",
                        onClick  = {
                            if (folderName.isNotBlank() && !isError) {
                                onConfirm(folderName.trim())
                            }
                        },
                        enabled  = folderName.isNotBlank() && !isError,
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 6 — ZIP OPTIONS SHEET
// ════════════════════════════════════════════════════════════

enum class ZipFormat(val displayName: String, val extension: String) {
    ZIP("ZIP Archive",   "zip"),
    TAR("TAR Archive",   "tar"),
    TARGZ("TAR.GZ",      "tar.gz"),
    SEVENZIP("7-Zip",    "7z"),
}

enum class CompressionLevel(val displayName: String, val level: Int) {
    NONE(    "No Compression",  0),
    FAST(    "Fast",            3),
    NORMAL(  "Normal",          5),
    BEST(    "Best",            9),
}

@Composable
fun ZipOptionsSheet(
    items: List<FileItem>,
    visible: Boolean,
    onDismiss: () -> Unit,
    onCompress: (name: String, format: ZipFormat, level: CompressionLevel) -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended

    // State
    var archiveName       by remember(items) {
        mutableStateOf(
            if (items.size == 1) items[0].name else "Archive"
        )
    }
    var selectedFormat    by remember { mutableStateOf(ZipFormat.ZIP) }
    var selectedLevel     by remember { mutableStateOf(CompressionLevel.NORMAL) }
    var addPassword       by remember { mutableStateOf(false) }
    var password          by remember { mutableStateOf("") }
    var showPassword      by remember { mutableStateOf(false) }
    val totalSize         = remember(items) { items.sumOf { it.size } }

    FmBottomSheet(
        visible   = visible,
        onDismiss = onDismiss,
        title     = "Compress",
        subtitle  = "${items.size} item${if (items.size == 1) "" else "s"} • ${FileItem.formatSize(totalSize)}",
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = SpacingTokens.screenPaddingH),
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.lg),
        ) {
            // Archive name
            FmTextField(
                value         = archiveName,
                onValueChange = { archiveName = it },
                label         = "Archive name",
            )

            // Format selection
            SheetSectionLabel(text = "Format")
            Row(
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
                modifier              = Modifier.horizontalScroll(rememberScrollState()),
            ) {
                ZipFormat.entries.forEach { fmt ->
                    FmFilterChip(
                        label    = fmt.displayName,
                        selected = selectedFormat == fmt,
                        onClick  = { selectedFormat = fmt },
                    )
                }
            }

            // Compression level
            SheetSectionLabel(text = "Compression Level")
            Column(
                verticalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
            ) {
                CompressionLevel.entries.forEach { lvl ->
                    CompressionLevelRow(
                        level      = lvl,
                        selected   = selectedLevel == lvl,
                        onSelect   = { selectedLevel = lvl },
                    )
                }
            }

            // Password protection
            SheetSectionLabel(text = "Security")
            Surface(
                color  = MaterialTheme.colorScheme.surfaceVariant,
                shape  = ShapeTokens.cardShape,
            ) {
                Column(modifier = Modifier.padding(SpacingTokens.md)) {
                    Row(
                        verticalAlignment     = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier              = Modifier.fillMaxWidth(),
                    ) {
                        Row(
                            verticalAlignment     = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
                        ) {
                            Icon(
                                imageVector        = Icons.Rounded.Lock,
                                contentDescription = null,
                                tint               = ext.iconSecondary,
                                modifier           = Modifier.size(18.dp),
                            )
                            Text(
                                text  = "Password protect",
                                style = MaterialTheme.typography.bodyMedium,
                                color = ext.textPrimary,
                            )
                        }
                        Switch(
                            checked         = addPassword,
                            onCheckedChange = { addPassword = it },
                            colors          = SwitchDefaults.colors(
                                checkedThumbColor      = MaterialTheme.colorScheme.onPrimary,
                                checkedTrackColor      = MaterialTheme.colorScheme.primary,
                                uncheckedThumbColor    = ext.iconTertiary,
                                uncheckedTrackColor    = ext.stroke,
                            ),
                        )
                    }

                    // Password field
                    AnimatedVisibility(visible = addPassword) {
                        Spacer(Modifier.height(SpacingTokens.md))
                        FmTextField(
                            value         = password,
                            onValueChange = { password = it },
                            label         = "Password",
                            isPassword    = !showPassword,
                            trailingContent = {
                                FmIconButton(
                                    icon               = if (showPassword)
                                                             Icons.Rounded.VisibilityOff
                                                         else
                                                             Icons.Rounded.Visibility,
                                    contentDescription = "Toggle visibility",
                                    onClick            = { showPassword = !showPassword },
                                    tint               = ext.iconSecondary,
                                    containerSize      = 28.dp,
                                    size               = 16.dp,
                                )
                            },
                        )
                    }
                }
            }

            // Action buttons
            Row(
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
                modifier              = Modifier
                    .fillMaxWidth()
                    .padding(bottom = SpacingTokens.lg),
            ) {
                FmSecondaryButton(
                    text     = "Cancel",
                    onClick  = onDismiss,
                    modifier = Modifier.weight(1f),
                )
                FmPrimaryButton(
                    text     = "Compress",
                    onClick  = {
                        onCompress(
                            "${archiveName}.${selectedFormat.extension}",
                            selectedFormat,
                            selectedLevel,
                        )
                        onDismiss()
                    },
                    enabled  = archiveName.isNotBlank(),
                    modifier = Modifier.weight(1f),
                    leadingIcon = {
                        Icon(
                            imageVector        = Icons.Rounded.FolderZip,
                            contentDescription = null,
                            tint               = RawColors.White,
                            modifier           = Modifier.size(16.dp),
                        )
                    },
                )
            }
        }
    }
}

@Composable
private fun CompressionLevelRow(
    level: CompressionLevel,
    selected: Boolean,
    onSelect: () -> Unit,
) {
    val ext = MaterialTheme.extended
    val bgColor by animateColorAsState(
        targetValue = if (selected)
            MaterialTheme.colorScheme.primaryContainer
        else
            MaterialTheme.colorScheme.surfaceVariant,
        label = "compressionBg",
    )

    Surface(
        onClick = onSelect,
        color   = bgColor,
        shape   = ShapeTokens.cardShape,
        border  = if (selected) BorderStroke(
            1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
        ) else null,
    ) {
        Row(
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier              = Modifier
                .fillMaxWidth()
                .padding(
                    horizontal = SpacingTokens.lg,
                    vertical   = SpacingTokens.md,
                ),
        ) {
            Row(
                verticalAlignment     = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
            ) {
                RadioButton(
                    selected = selected,
                    onClick  = onSelect,
                    colors   = RadioButtonDefaults.colors(
                        selectedColor   = MaterialTheme.colorScheme.primary,
                        unselectedColor = ext.iconSecondary,
                    ),
                )
                Text(
                    text  = level.displayName,
                    style = MaterialTheme.typography.bodyMedium,
                    color = ext.textPrimary,
                )
            }
            // Speed indicator dots
            Row(
                horizontalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                repeat(4) { index ->
                    val filled = when (level) {
                        CompressionLevel.NONE   -> false
                        CompressionLevel.FAST   -> index < 1
                        CompressionLevel.NORMAL -> index < 2
                        CompressionLevel.BEST   -> index < 4
                    }
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(
                                if (filled) MaterialTheme.colorScheme.primary
                                else ext.stroke,
                            ),
                    )
                }
            }
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 7 — EXTRACT OPTIONS SHEET
// ════════════════════════════════════════════════════════════

@Composable
fun ExtractSheet(
    item: FileItem,
    visible: Boolean,
    currentPath: String,
    onDismiss: () -> Unit,
    onExtract: (destination: String, createFolder: Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext            = MaterialTheme.extended
    var destination    by remember { mutableStateOf(currentPath) }
    var createFolder   by remember { mutableStateOf(true) }
    val folderName     = item.name.removeSuffix(".${item.extension}")

    FmBottomSheet(
        visible   = visible,
        onDismiss = onDismiss,
        title     = "Extract",
        subtitle  = item.name,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = SpacingTokens.screenPaddingH),
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.lg),
        ) {
            // Destination path
            SheetSectionLabel(text = "Destination")
            Surface(
                color  = MaterialTheme.colorScheme.surfaceVariant,
                shape  = ShapeTokens.cardShape,
            ) {
                Row(
                    verticalAlignment     = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier              = Modifier
                        .fillMaxWidth()
                        .padding(SpacingTokens.md),
                ) {
                    Row(
                        verticalAlignment     = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
                        modifier              = Modifier.weight(1f),
                    ) {
                        Icon(
                            imageVector        = Icons.Rounded.Folder,
                            contentDescription = null,
                            tint               = ext.folderColor,
                            modifier           = Modifier.size(20.dp),
                        )
                        Text(
                            text     = destination
                                .replace("/storage/emulated/0", "Internal"),
                            style    = ExtraTypography.pathStyle,
                            color    = ext.textPrimary,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    FmGhostButton(
                        text    = "Change",
                        onClick = { /* open folder picker */ },
                        color   = MaterialTheme.colorScheme.primary,
                    )
                }
            }

            // Quick destination options
            Row(
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
            ) {
                listOf(
                    "Here"      to currentPath,
                    "Downloads" to "/storage/emulated/0/Download",
                ).forEach { (label, path) ->
                    FmFilterChip(
                        label    = label,
                        selected = destination == path,
                        onClick  = { destination = path },
                    )
                }
            }

            // Create sub-folder toggle
            Surface(
                color  = MaterialTheme.colorScheme.surfaceVariant,
                shape  = ShapeTokens.cardShape,
            ) {
                Row(
                    verticalAlignment     = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier              = Modifier
                        .fillMaxWidth()
                        .padding(SpacingTokens.md),
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text  = "Extract into subfolder",
                            style = MaterialTheme.typography.bodyMedium,
                            color = ext.textPrimary,
                        )
                        AnimatedVisibility(visible = createFolder) {
                            Text(
                                text  = "→ $folderName/",
                                style = ExtraTypography.pathStyle,
                                color = MaterialTheme.colorScheme.primary,
                            )
                        }
                    }
                    Switch(
                        checked         = createFolder,
                        onCheckedChange = { createFolder = it },
                        colors          = SwitchDefaults.colors(
                            checkedTrackColor = MaterialTheme.colorScheme.primary,
                        ),
                    )
                }
            }

            // Buttons
            Row(
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
                modifier              = Modifier
                    .fillMaxWidth()
                    .padding(bottom = SpacingTokens.lg),
            ) {
                FmSecondaryButton(
                    text     = "Cancel",
                    onClick  = onDismiss,
                    modifier = Modifier.weight(1f),
                )
                FmPrimaryButton(
                    text     = "Extract",
                    onClick  = {
                        onExtract(destination, createFolder)
                        onDismiss()
                    },
                    modifier = Modifier.weight(1f),
                    leadingIcon = {
                        Icon(
                            imageVector        = Icons.Rounded.Unarchive,
                            contentDescription = null,
                            tint               = RawColors.White,
                            modifier           = Modifier.size(16.dp),
                        )
                    },
                )
            }
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 8 — CONFLICT RESOLUTION DIALOG
// ════════════════════════════════════════════════════════════

@Composable
fun ConflictResolutionDialog(
    conflictItem: FileItem,
    targetPath: String,
    remainingCount: Int,
    visible: Boolean,
    onResolve: (ConflictResolution) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
) {
    if (!visible) return
    val ext = MaterialTheme.extended

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape           = ShapeTokens.dialogShape,
            color           = ext.surfaceDialog,
            shadowElevation = ElevationTokens.dialog,
            modifier        = modifier.fillMaxWidth(),
        ) {
            Column(
                modifier = Modifier.padding(SpacingTokens.xxl),
                verticalArrangement = Arrangement.spacedBy(SpacingTokens.lg),
            ) {
                // Header
                Row(
                    verticalAlignment     = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier         = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(RawColors.Amber500.copy(alpha = 0.15f)),
                    ) {
                        Icon(
                            imageVector        = Icons.Rounded.Warning,
                            contentDescription = null,
                            tint               = RawColors.Amber500,
                            modifier           = Modifier.size(26.dp),
                        )
                    }
                    Column {
                        Text(
                            text  = "File Already Exists",
                            style = MaterialTheme.typography.titleMedium,
                            color = ext.textPrimary,
                        )
                        if (remainingCount > 1) {
                            Text(
                                text  = "$remainingCount conflicts remaining",
                                style = MaterialTheme.typography.labelSmall,
                                color = ext.textSecondary,
                            )
                        }
                    }
                }

                // File info
                Surface(
                    color  = MaterialTheme.colorScheme.surfaceVariant,
                    shape  = ShapeTokens.cardShape,
                ) {
                    Row(
                        verticalAlignment     = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
                        modifier              = Modifier
                            .fillMaxWidth()
                            .padding(SpacingTokens.md),
                    ) {
                        Icon(
                            imageVector        = if (conflictItem.isDirectory)
                                                     Icons.Rounded.Folder
                                                 else
                                                     Icons.Rounded.InsertDriveFile,
                            contentDescription = null,
                            tint               = if (conflictItem.isDirectory)
                                                     ext.folderColor
                                                 else
                                                     ext.iconSecondary,
                            modifier           = Modifier.size(24.dp),
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text     = conflictItem.name,
                                style    = MaterialTheme.typography.bodyMedium,
                                color    = ext.textPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                text  = "already exists in destination",
                                style = MaterialTheme.typography.labelSmall,
                                color = ext.textSecondary,
                            )
                        }
                    }
                }

                // Resolution options
                Column(
                    verticalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
                ) {
                    ConflictOption(
                        icon     = Icons.Rounded.ArrowForward,
                        title    = "Skip",
                        subtitle = "Keep the existing file",
                        color    = ext.iconPrimary,
                        onClick  = { onResolve(ConflictResolution.SKIP) },
                    )
                    ConflictOption(
                        icon     = Icons.Rounded.SwapHoriz,
                        title    = "Replace",
                        subtitle = "Overwrite with new file",
                        color    = RawColors.Amber500,
                        onClick  = { onResolve(ConflictResolution.REPLACE) },
                    )
                    ConflictOption(
                        icon     = Icons.Rounded.FileCopy,
                        title    = "Keep Both",
                        subtitle = "Rename and keep both files",
                        color    = MaterialTheme.colorScheme.primary,
                        onClick  = { onResolve(ConflictResolution.KEEP_BOTH) },
                    )
                }

                FmDivider()

                // Apply to all remaining
                if (remainingCount > 1) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
                        modifier              = Modifier.horizontalScroll(rememberScrollState()),
                    ) {
                        FmActionChip(
                            label   = "Skip All",
                            icon    = Icons.Rounded.SkipNext,
                            onClick = { onResolve(ConflictResolution.SKIP_ALL) },
                            color   = ext.iconPrimary,
                        )
                        FmActionChip(
                            label   = "Replace All",
                            icon    = Icons.Rounded.DoneAll,
                            onClick = { onResolve(ConflictResolution.REPLACE_ALL) },
                            color   = RawColors.Amber500,
                        )
                    }
                }

                FmSecondaryButton(
                    text     = "Cancel Operation",
                    onClick  = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }
}

@Composable
private fun ConflictOption(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    color: Color,
    onClick: () -> Unit,
) {
    val ext               = MaterialTheme.extended
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed         by interactionSource.collectIsPressedAsState()

    Surface(
        color  = if (isPressed)
                     color.copy(alpha = 0.1f)
                 else
                     MaterialTheme.colorScheme.surfaceVariant,
        shape  = ShapeTokens.cardShape,
        border = BorderStroke(1.dp, color.copy(alpha = 0.2f)),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(
                interactionSource = interactionSource,
                indication        = ripple(color = color),
                onClick           = onClick,
            ),
    ) {
        Row(
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
            modifier              = Modifier.padding(SpacingTokens.md),
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier         = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(color.copy(alpha = 0.12f)),
            ) {
                Icon(
                    imageVector        = icon,
                    contentDescription = null,
                    tint               = color,
                    modifier           = Modifier.size(20.dp),
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text  = title,
                    style = MaterialTheme.typography.bodyMedium,
                    color = ext.textPrimary,
                )
                Text(
                    text  = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = ext.textSecondary,
                )
            }
            Icon(
                imageVector        = Icons.Rounded.ChevronRight,
                contentDescription = null,
                tint               = ext.iconTertiary,
                modifier           = Modifier.size(16.dp),
            )
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 9 — OPEN WITH SHEET
// ════════════════════════════════════════════════════════════

data class AppInfo(
    val packageName: String,
    val displayName: String,
    val icon: Any?,
)

@Composable
fun OpenWithSheet(
    item: FileItem,
    visible: Boolean,
    apps: List<AppInfo>,
    onDismiss: () -> Unit,
    onSelectApp: (AppInfo) -> Unit,
    onAlwaysUse: (AppInfo) -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended

    FmBottomSheet(
        visible   = visible,
        onDismiss = onDismiss,
        title     = "Open With",
        subtitle  = item.name,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = SpacingTokens.screenPaddingH),
        ) {
            if (apps.isEmpty()) {
                EmptyStateView(
                    title    = "No apps found",
                    subtitle = "No compatible apps installed\nfor this file type",
                    icon     = Icons.Rounded.Apps,
                    modifier = Modifier.height(200.dp),
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(SpacingTokens.xs),
                    modifier            = Modifier.heightIn(max = 400.dp),
                ) {
                    items(apps, key = { it.packageName }) { app ->
                        OpenWithAppRow(
                            app          = app,
                            onClick      = { onSelectApp(app) },
                            onAlwaysUse  = { onAlwaysUse(app) },
                        )
                    }
                }
            }

            Spacer(Modifier.height(SpacingTokens.lg))
            FmSecondaryButton(
                text     = "Cancel",
                onClick  = onDismiss,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = SpacingTokens.lg),
            )
        }
    }
}

@Composable
private fun OpenWithAppRow(
    app: AppInfo,
    onClick: () -> Unit,
    onAlwaysUse: () -> Unit,
) {
    val ext = MaterialTheme.extended
    Row(
        verticalAlignment     = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
        modifier              = Modifier
            .fillMaxWidth()
            .clip(ShapeTokens.cardShape)
            .clickable(onClick = onClick)
            .padding(SpacingTokens.md),
    ) {
        // App icon placeholder
        Box(
            contentAlignment = Alignment.Center,
            modifier         = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
        ) {
            Icon(
                imageVector        = Icons.Rounded.Apps,
                contentDescription = null,
                tint               = ext.iconSecondary,
                modifier           = Modifier.size(24.dp),
            )
        }

        Text(
            text     = app.displayName,
            style    = MaterialTheme.typography.bodyMedium,
            color    = ext.textPrimary,
            modifier = Modifier.weight(1f),
        )

        FmGhostButton(
            text    = "Always",
            onClick = onAlwaysUse,
            color   = ext.textTertiary,
        )
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 10 — OPERATION SUCCESS / ERROR NOTIFICATION
// ════════════════════════════════════════════════════════════

@Composable
fun OperationResultBanner(
    status: OperationStatus,
    onDismiss: () -> Unit,
    onUndo: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended
    val visible = status is OperationStatus.Success ||
                  status is OperationStatus.Error

    AnimatedVisibility(
        visible  = visible,
        enter    = slideInVertically(initialOffsetY = { it }) + fadeIn(),
        exit     = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
        modifier = modifier,
    ) {
        val (bgColor, icon, message) = when (status) {
            is OperationStatus.Success -> Triple(
                ext.success,
                Icons.Rounded.CheckCircle,
                status.message,
            )
            is OperationStatus.Error   -> Triple(
                MaterialTheme.colorScheme.error,
                Icons.Rounded.Error,
                status.message,
            )
            else -> Triple(ext.success, Icons.Rounded.CheckCircle, "")
        }

        Surface(
            color           = bgColor,
            shape           = ShapeTokens.cardShape,
            shadowElevation = ElevationTokens.lg,
            modifier        = Modifier
                .fillMaxWidth()
                .padding(SpacingTokens.screenPaddingH),
        ) {
            Row(
                verticalAlignment     = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
                modifier              = Modifier.padding(SpacingTokens.md),
            ) {
                Icon(
                    imageVector        = icon,
                    contentDescription = null,
                    tint               = RawColors.White,
                    modifier           = Modifier.size(20.dp),
                )
                Text(
                    text     = message,
                    style    = MaterialTheme.typography.bodySmall,
                    color    = RawColors.White,
                    modifier = Modifier.weight(1f),
                )
                if (onUndo != null && status is OperationStatus.Success) {
                    TextButton(onClick = onUndo) {
                        Text(
                            text  = "Undo",
                            style = MaterialTheme.typography.labelLarge,
                            color = RawColors.White,
                        )
                    }
                }
                FmIconButton(
                    icon               = Icons.Rounded.Close,
                    contentDescription = "Dismiss",
                    onClick            = onDismiss,
                    tint               = RawColors.White,
                    containerSize      = 28.dp,
                    size               = 16.dp,
                )
            }
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 11 — SORT BOTTOM SHEET
// ════════════════════════════════════════════════════════════

@Composable
fun SortBottomSheet(
    visible: Boolean,
    current: SortConfig,
    onDismiss: () -> Unit,
    onApply: (SortConfig) -> Unit,
    modifier: Modifier = Modifier,
) {
    var config by remember(current) { mutableStateOf(current) }
    val ext    = MaterialTheme.extended

    FmBottomSheet(
        visible   = visible,
        onDismiss = onDismiss,
        title     = "Sort",
        subtitle  = "Arrange files and folders",
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = SpacingTokens.screenPaddingH),
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.md),
        ) {
            // Sort by
            SheetSectionLabel(text = "Sort By")
            SortBy.entries.forEach { sortBy ->
                SortOptionRow(
                    label    = sortBy.displayName,
                    selected = config.sortBy == sortBy,
                    icon     = Icons.Rounded.Sort,
                    onClick  = { config = config.copy(sortBy = sortBy) },
                )
            }

            FmDivider()

            // Order
            SheetSectionLabel(text = "Order")
            Row(
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
            ) {
                SortOrder.entries.forEach { order ->
                    FmFilterChip(
                        label    = order.displayName,
                        selected = config.sortOrder == order,
                        onClick  = { config = config.copy(sortOrder = order) },
                        leadingIcon = {
                            Icon(
                                imageVector = if (order == SortOrder.ASCENDING)
                                    Icons.Rounded.ArrowUpward
                                else
                                    Icons.Rounded.ArrowDownward,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp),
                            )
                        },
                    )
                }
            }

            FmDivider()

            // Toggles
            SheetSectionLabel(text = "Options")
            SortToggleRow(
                label    = "Folders first",
                checked  = config.foldersFirst,
                onChange = { config = config.copy(foldersFirst = it) },
            )
            SortToggleRow(
                label    = "Show hidden files",
                checked  = config.showHidden,
                onChange = { config = config.copy(showHidden = it) },
            )

            // Apply button
            Row(
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
                modifier              = Modifier
                    .fillMaxWidth()
                    .padding(
                        top    = SpacingTokens.md,
                        bottom = SpacingTokens.lg,
                    ),
            ) {
                FmSecondaryButton(
                    text     = "Reset",
                    onClick  = { config = SortConfig() },
                    modifier = Modifier.weight(1f),
                )
                FmPrimaryButton(
                    text     = "Apply",
                    onClick  = {
                        onApply(config)
                        onDismiss()
                    },
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }
}

@Composable
private fun SortOptionRow(
    label: String,
    selected: Boolean,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
) {
    val ext     = MaterialTheme.extended
    val bgColor by animateColorAsState(
        targetValue = if (selected)
            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
        else
            Color.Transparent,
        label = "sortOptionBg",
    )

    Row(
        verticalAlignment     = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
        modifier              = Modifier
            .fillMaxWidth()
            .clip(ShapeTokens.cardShape)
            .background(bgColor)
            .clickable(onClick = onClick)
            .padding(SpacingTokens.md),
    ) {
        RadioButton(
            selected = selected,
            onClick  = onClick,
            colors   = RadioButtonDefaults.colors(
                selectedColor   = MaterialTheme.colorScheme.primary,
                unselectedColor = ext.iconSecondary,
            ),
        )
        Text(
            text  = label,
            style = MaterialTheme.typography.bodyMedium,
            color = ext.textPrimary,
        )
        if (selected) {
            Spacer(Modifier.weight(1f))
            Icon(
                imageVector        = Icons.Rounded.Check,
                contentDescription = null,
                tint               = MaterialTheme.colorScheme.primary,
                modifier           = Modifier.size(16.dp),
            )
        }
    }
}

@Composable
private fun SortToggleRow(
    label: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit,
) {
    val ext = MaterialTheme.extended
    Row(
        verticalAlignment     = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier              = Modifier
            .fillMaxWidth()
            .padding(vertical = SpacingTokens.xs),
    ) {
        Text(
            text  = label,
            style = MaterialTheme.typography.bodyMedium,
            color = ext.textPrimary,
        )
        Switch(
            checked         = checked,
            onCheckedChange = onChange,
            colors          = SwitchDefaults.colors(
                checkedTrackColor = MaterialTheme.colorScheme.primary,
            ),
        )
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 12 — SHARED HELPER COMPOSABLES
// ════════════════════════════════════════════════════════════

// ── Section label in sheets ─────────────────────────────────
@Composable
fun SheetSectionLabel(
    text: String,
    modifier: Modifier = Modifier,
) {
    Text(
        text     = text.uppercase(),
        style    = ExtraTypography.overline,
        color    = MaterialTheme.extended.textSecondary,
        modifier = modifier.padding(vertical = SpacingTokens.xxs),
    )
}

// ── Premium text field ──────────────────────────────────────
@Composable
fun FmTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    placeholder: String = "",
    isError: Boolean = false,
    isPassword: Boolean = false,
    enabled: Boolean = true,
    singleLine: Boolean = true,
    maxLines: Int = 1,
    focusRequester: FocusRequester = remember { FocusRequester() },
    keyboardAction: ImeAction = ImeAction.Done,
    onKeyboardDone: (() -> Unit)? = null,
    leadingIcon: @Composable (() -> Unit)? = null,
    trailingContent: @Composable (() -> Unit)? = null,
) {
    val ext = MaterialTheme.extended

    OutlinedTextField(
        value             = value,
        onValueChange     = onValueChange,
        label             = {
            Text(
                text  = label,
                style = MaterialTheme.typography.labelMedium,
            )
        },
        placeholder       = if (placeholder.isNotEmpty()) {
            {
                Text(
                    text  = placeholder,
                    style = MaterialTheme.typography.bodyMedium,
                    color = ext.textTertiary,
                )
            }
        } else null,
        isError           = isError,
        enabled           = enabled,
        singleLine        = singleLine,
        maxLines          = maxLines,
        visualTransformation = if (isPassword)
            PasswordVisualTransformation()
        else
            VisualTransformation.None,
        keyboardOptions   = KeyboardOptions(
            imeAction = keyboardAction,
        ),
        keyboardActions   = KeyboardActions(
            onDone   = { onKeyboardDone?.invoke() },
            onSearch = { onKeyboardDone?.invoke() },
        ),
        leadingIcon       = leadingIcon,
        trailingIcon      = trailingContent,
        shape             = ShapeTokens.searchShape,
        colors            = OutlinedTextFieldDefaults.colors(
            focusedBorderColor       = MaterialTheme.colorScheme.primary,
            unfocusedBorderColor     = ext.stroke,
            errorBorderColor         = MaterialTheme.colorScheme.error,
            focusedLabelColor        = MaterialTheme.colorScheme.primary,
            unfocusedLabelColor      = ext.textTertiary,
            cursorColor              = MaterialTheme.colorScheme.primary,
            focusedTextColor         = ext.textPrimary,
            unfocusedTextColor       = ext.textPrimary,
            focusedContainerColor    = Color.Transparent,
            unfocusedContainerColor  = Color.Transparent,
        ),
        modifier          = modifier
            .fillMaxWidth()
            .focusRequester(focusRequester),
    )
}

// ════════════════════════════════════════════════════════════
// END OF FILE 6 — ActionPanels.kt
// Next → File 7: SearchSortFilter.kt
// (Full Search Screen, Live search, Filter chips,
//  Sort BottomSheet, Recent searches,
//  Search result highlights, Advanced filter panel)
// ════════════════════════════════════════════════════════════

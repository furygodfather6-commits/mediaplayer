@file:OptIn(
    androidx.compose.foundation.ExperimentalFoundationApi::class,
    androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.animation.ExperimentalAnimationApi::class,
    androidx.compose.ui.ExperimentalComposeUiApi::class
)

package com.devfav.filemanager.ui.extras


import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.hapticfeedback.*
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import androidx.compose.ui.window.*
import com.devfav.filemanager.ui.design.*
import com.devfav.filemanager.ui.state.*
import com.devfav.filemanager.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import com.devfav.filemanager.ui.panels.FmTextField
import com.devfav.filemanager.ui.panels.SheetSectionLabel
import com.devfav.filemanager.ui.panels.CreateFolderDialog
import com.devfav.filemanager.ui.panels.RenameDialog
import com.devfav.filemanager.ui.panels.DeleteConfirmDialog
import com.devfav.filemanager.ui.panels.ZipOptionsSheet
import com.devfav.filemanager.ui.panels.SortBottomSheet
import com.devfav.filemanager.ui.panels.OperationProgressSheet
import com.devfav.filemanager.ui.panels.ConflictResolutionDialog
import com.devfav.filemanager.ui.panels.FileContextMenu
import androidx.compose.ui.zIndex
import com.devfav.filemanager.ui.search.FilterBottomSheet
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.ui.text.input.ImeAction

// ════════════════════════════════════════════════════════════
// SECTION 1 — FILE PROPERTIES SHEET
//             Detailed info about file / folder
// ════════════════════════════════════════════════════════════

@Composable
fun PropertiesSheet(
    item: FileItem,
    visible: Boolean,
    onDismiss: () -> Unit,
    onNavigateToParent: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended

    FmBottomSheet(
        visible              = visible,
        onDismiss            = onDismiss,
        skipPartiallyExpanded = false,
        title                = "Properties",
        subtitle             = item.name,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = SpacingTokens.screenPaddingH),
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
        ) {
            // ── File Preview Header ──────────────────────────
            PropertiesFileHeader(item = item)

            FmDivider(modifier = Modifier.padding(vertical = SpacingTokens.sm))

            // ── Info Rows ────────────────────────────────────
            SheetSectionLabel(text = "Information")

            val dateFormatter = remember {
                SimpleDateFormat("EEEE, MMM dd yyyy  hh:mm a", Locale.getDefault())
            }

            PropertyRow(
                icon  = Icons.Rounded.Label,
                label = "Name",
                value = item.name,
            )
            PropertyRow(
                icon  = Icons.Rounded.Category,
                label = "Type",
                value = if (item.isDirectory) "Folder"
                        else item.fileType.displayName,
            )
            if (!item.isDirectory && item.extension.isNotEmpty()) {
                PropertyRow(
                    icon  = Icons.Rounded.Extension,
                    label = "Extension",
                    value = ".${item.extension.uppercase()}",
                )
            }
            PropertyRow(
                icon  = Icons.Rounded.DataUsage,
                label = "Size",
                value = if (item.isDirectory)
                            "${item.childCount} items"
                        else
                            "${FileItem.formatSize(item.size)} (${item.size} bytes)",
            )
            PropertyRow(
                icon  = Icons.Rounded.Schedule,
                label = "Modified",
                value = dateFormatter.format(Date(item.lastModified)),
            )
            PropertyRow(
                icon  = Icons.Rounded.Route,
                label = "Location",
                value = item.parentPath,
                isPath = true,
                onPathClick = { onNavigateToParent(item.parentPath) },
            )
            PropertyRow(
                icon  = Icons.Rounded.Link,
                label = "Full Path",
                value = item.path,
                isPath = true,
            )

            FmDivider(modifier = Modifier.padding(vertical = SpacingTokens.sm))

            // ── Permissions ──────────────────────────────────
            SheetSectionLabel(text = "Permissions")

            Surface(
                color  = MaterialTheme.colorScheme.surfaceVariant,
                shape  = ShapeTokens.cardShape,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    modifier              = Modifier
                        .fillMaxWidth()
                        .padding(SpacingTokens.lg),
                ) {
                    PermissionDot(
                        label   = "Read",
                        granted = true,
                    )
                    PermissionDot(
                        label   = "Write",
                        granted = !item.isReadOnly,
                    )
                    PermissionDot(
                        label   = "Execute",
                        granted = false,
                    )
                    PermissionDot(
                        label   = "Hidden",
                        granted = item.isHidden,
                        isWarn  = item.isHidden,
                    )
                }
            }

            FmDivider(modifier = Modifier.padding(vertical = SpacingTokens.sm))

            // ── Tags ─────────────────────────────────────────
            SheetSectionLabel(text = "Tags")

            if (item.tags.isEmpty()) {
                Text(
                    text  = "No tags added",
                    style = MaterialTheme.typography.bodySmall,
                    color = ext.textTertiary,
                    modifier = Modifier.padding(vertical = SpacingTokens.xs),
                )
            } else {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
                ) {
                    items(item.tags, key = { it }) { tag ->
                        FmActionChip(
                            label   = tag,
                            icon    = Icons.Rounded.Tag,
                            onClick = {},
                            color   = MaterialTheme.colorScheme.secondary,
                        )
                    }
                }
            }

            // Add tag button
            FmGhostButton(
                text  = "+ Add Tag",
                onClick = { /* open tag manager */ },
                color = MaterialTheme.colorScheme.primary,
            )

            // ── Symlink info ─────────────────────────────────
            if (item.isSymlink) {
                FmDivider(modifier = Modifier.padding(vertical = SpacingTokens.sm))
                Surface(
                    color  = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.3f),
                    shape  = ShapeTokens.cardShape,
                    border = BorderStroke(
                        1.dp,
                        MaterialTheme.colorScheme.tertiary.copy(alpha = 0.3f),
                    ),
                ) {
                    Row(
                        verticalAlignment     = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
                        modifier              = Modifier
                            .fillMaxWidth()
                            .padding(SpacingTokens.md),
                    ) {
                        Icon(
                            imageVector        = Icons.Rounded.Link,
                            contentDescription = null,
                            tint               = MaterialTheme.colorScheme.tertiary,
                            modifier           = Modifier.size(18.dp),
                        )
                        Text(
                            text  = "This is a symbolic link",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.tertiary,
                        )
                    }
                }
            }

            Spacer(Modifier.height(SpacingTokens.xxl))
        }
    }
}

@Composable
private fun PropertiesFileHeader(item: FileItem) {
    val ext = MaterialTheme.extended
    Row(
        verticalAlignment     = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.lg),
        modifier              = Modifier
            .fillMaxWidth()
            .padding(vertical = SpacingTokens.md),
    ) {
        // Large file icon
        Box(
            contentAlignment = Alignment.Center,
            modifier         = Modifier
                .size(72.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(
                    if (item.isDirectory)
                        Brush.linearGradient(
                            listOf(
                                ext.folderColor.copy(alpha = 0.15f),
                                ext.folderColorAlt.copy(alpha = 0.08f),
                            )
                        )
                    else
                        Brush.linearGradient(
                            listOf(
                                MaterialTheme.colorScheme.surfaceVariant,
                                MaterialTheme.colorScheme.surfaceVariant,
                            )
                        )
                ),
        ) {
            FileTypeIcon(
                fileType  = item.iconType,
                size      = 44.dp,
                showBadge = false,
            )
        }

        // Name + type
        Column(
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.xs),
            modifier            = Modifier.weight(1f),
        ) {
            Text(
                text     = item.name,
                style    = MaterialTheme.typography.titleMedium,
                color    = ext.textPrimary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            Row(
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
                verticalAlignment     = Alignment.CenterVertically,
            ) {
                // Type chip
                Surface(
                    color  = MaterialTheme.colorScheme.primaryContainer,
                    shape  = ShapeTokens.badgeShape,
                ) {
                    Text(
                        text     = if (item.isDirectory) "Folder"
                                   else item.fileType.displayName,
                        style    = MaterialTheme.typography.labelSmall,
                        color    = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                    )
                }
                // Size
                Text(
                    text  = item.displaySize,
                    style = ExtraTypography.sizeLabel,
                    color = ext.textSecondary,
                )
            }
            // Date
            Text(
                text  = "Modified ${item.displayDate}",
                style = MaterialTheme.typography.labelSmall,
                color = ext.textTertiary,
            )
        }
    }
}

@Composable
private fun PropertyRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    isPath: Boolean = false,
    onPathClick: (() -> Unit)? = null,
) {
    val ext = MaterialTheme.extended
    Row(
        verticalAlignment     = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
        modifier              = Modifier
            .fillMaxWidth()
            .padding(vertical = SpacingTokens.xs),
    ) {
        Icon(
            imageVector        = icon,
            contentDescription = null,
            tint               = ext.iconSecondary,
            modifier           = Modifier
                .size(16.dp)
                .padding(top = 2.dp),
        )
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text  = label,
                style = MaterialTheme.typography.labelSmall,
                color = ext.textTertiary,
            )
            Spacer(Modifier.height(1.dp))
            if (isPath) {
                Text(
                    text     = value,
                    style    = ExtraTypography.pathStyle.copy(
                        color = if (onPathClick != null)
                                    MaterialTheme.colorScheme.primary
                                else
                                    ext.textSecondary,
                    ),
                    modifier = Modifier
                        .then(
                            if (onPathClick != null)
                                Modifier.clickable(onClick = onPathClick)
                            else
                                Modifier
                        ),
                )
            } else {
                Text(
                    text  = value,
                    style = MaterialTheme.typography.bodySmall,
                    color = ext.textPrimary,
                )
            }
        }
    }
}

@Composable
private fun PermissionDot(
    label: String,
    granted: Boolean,
    isWarn: Boolean = false,
) {
    val ext = MaterialTheme.extended
    val color = when {
        isWarn  -> RawColors.Amber500
        granted -> ext.success
        else    -> ext.iconTertiary
    }
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(SpacingTokens.xs),
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier         = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(color.copy(alpha = 0.12f)),
        ) {
            Icon(
                imageVector = if (granted) Icons.Rounded.Check
                              else Icons.Rounded.Close,
                contentDescription = label,
                tint               = color,
                modifier           = Modifier.size(18.dp),
            )
        }
        Text(
            text  = label,
            style = MaterialTheme.typography.labelSmall,
            color = ext.textSecondary,
        )
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 2 — STORAGE ANALYZER SHEET
//             Visual breakdown with interactive chart
// ════════════════════════════════════════════════════════════

@Composable
fun StorageAnalyzerSheet(
    visible: Boolean,
    storageState: StorageState,
    onDismiss: () -> Unit,
    onCleanup: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext    = MaterialTheme.extended
    val volume = storageState.primaryVolume

    FmBottomSheet(
        visible              = visible,
        onDismiss            = onDismiss,
        skipPartiallyExpanded = false,
        title                = "Storage Analyzer",
        subtitle             = volume?.let {
            "${it.displayUsed} used of ${it.displayTotal}"
        } ?: "Analyzing...",
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = SpacingTokens.screenPaddingH),
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.lg),
        ) {
            // ── Donut Chart ──────────────────────────────────
            if (volume != null) {
                StorageDonutChart(
                    volume     = volume,
                    breakdown  = storageState.breakdown,
                    modifier   = Modifier
                        .fillMaxWidth()
                        .height(220.dp),
                )
            }

            // ── Volume cards row ─────────────────────────────
            if (storageState.volumes.size > 1) {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
                ) {
                    items(storageState.volumes, key = { it.id }) { vol ->
                        MiniVolumeCard(volume = vol)
                    }
                }
            }

            FmDivider()

            // ── Category breakdown ───────────────────────────
            SheetSectionLabel(text = "By Category")

            val breakdown = storageState.breakdown
            val total     = breakdown.totalBytes.coerceAtLeast(1L)

            val categories = listOf(
                StorageCategoryData("Images",    breakdown.imagesBytes,   ext.imageColor,    Icons.Rounded.Image),
                StorageCategoryData("Videos",    breakdown.videosBytes,   ext.videoColor,    Icons.Rounded.VideoLibrary),
                StorageCategoryData("Audio",     breakdown.audioBytes,    ext.audioColor,    Icons.Rounded.LibraryMusic),
                StorageCategoryData("Documents", breakdown.docsBytes,     ext.documentColor, Icons.Rounded.Description),
                StorageCategoryData("APKs",      breakdown.apksBytes,     ext.apkColor,      Icons.Rounded.Android),
                StorageCategoryData("Archives",  breakdown.archivesBytes, ext.archiveColor,  Icons.Rounded.FolderZip),
                StorageCategoryData("Other",     breakdown.otherBytes,    ext.unknownColor,  Icons.Rounded.Folder),
            ).sortedByDescending { it.bytes }

            categories.forEach { cat ->
                StorageAnalyzerCategoryRow(
                    data     = cat,
                    fraction = cat.bytes.toFloat() / total,
                    total    = total,
                )
            }

            FmDivider()

            // ── Cleanup suggestion ───────────────────────────
            if ((volume?.usedPercent ?: 0) > 70) {
                CleanupSuggestionCard(
                    usedPercent = volume?.usedPercent ?: 0,
                    onCleanup   = onCleanup,
                )
            }

            Spacer(Modifier.height(SpacingTokens.xxl))
        }
    }
}

data class StorageCategoryData(
    val label: String,
    val bytes: Long,
    val color: Color,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
)

@Composable
private fun StorageDonutChart(
    volume: StorageVolume,
    breakdown: StorageBreakdown,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended

    val animProgress by animateFloatAsState(
        targetValue   = 1f,
        animationSpec = tween(
            durationMillis = AnimationTokens.durationXL,
            easing         = FastOutSlowInEasing,
        ),
        label = "donutProgress",
    )

    val segments = listOf(
        breakdown.imagesBytes   to ext.imageColor,
        breakdown.videosBytes   to ext.videoColor,
        breakdown.audioBytes    to ext.audioColor,
        breakdown.docsBytes     to ext.documentColor,
        breakdown.apksBytes     to ext.apkColor,
        breakdown.archivesBytes to ext.archiveColor,
        breakdown.otherBytes    to ext.unknownColor,
    ).filter { it.first > 0 }

    val total = volume.totalBytes.toFloat().coerceAtLeast(1f)

    Box(
        contentAlignment = Alignment.Center,
        modifier         = modifier,
    ) {
        Canvas(modifier = Modifier.size(200.dp)) {
            val strokeWidth = 36.dp.toPx()
            val radius      = (size.minDimension - strokeWidth) / 2f
            val centerX     = size.width / 2f
            val centerY     = size.height / 2f
            var startAngle  = -90f

            // Background track
            drawCircle(
                color  = ext.storageFree,
                radius = radius,
                center = Offset(centerX, centerY),
                style  = Stroke(width = strokeWidth),
            )

            // Segments
            segments.forEach { (bytes, color) ->
                val sweep = (bytes / total) * 360f * animProgress
                drawArc(
                    color      = color,
                    startAngle = startAngle,
                    sweepAngle = sweep,
                    useCenter  = false,
                    topLeft    = Offset(
                        centerX - radius,
                        centerY - radius,
                    ),
                    size  = Size(radius * 2f, radius * 2f),
                    style = Stroke(
                        width = strokeWidth,
                        cap   = StrokeCap.Butt,
                    ),
                )
                startAngle += sweep
            }
        }

        // Center text
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text  = "${volume.usedPercent}%",
                style = ExtraTypography.storagePct.copy(fontSize = 28.sp),
                color = MaterialTheme.extended.textPrimary,
            )
            Text(
                text  = "Used",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.extended.textSecondary,
            )
            Text(
                text  = volume.displayTotal,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.extended.textTertiary,
            )
        }
    }
}

@Composable
private fun MiniVolumeCard(volume: StorageVolume) {
    val ext = MaterialTheme.extended
    Surface(
        color  = MaterialTheme.colorScheme.surfaceVariant,
        shape  = ShapeTokens.cardShape,
        border = BorderStroke(0.5.dp, ext.stroke),
        modifier = Modifier.width(160.dp),
    ) {
        Column(
            modifier = Modifier.padding(SpacingTokens.md),
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
        ) {
            Row(
                verticalAlignment     = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
            ) {
                Icon(
                    imageVector = if (volume.isRemovable)
                        Icons.Rounded.SdCard
                    else
                        Icons.Rounded.PhoneAndroid,
                    contentDescription = null,
                    tint               = MaterialTheme.colorScheme.primary,
                    modifier           = Modifier.size(16.dp),
                )
                Text(
                    text     = volume.displayName,
                    style    = MaterialTheme.typography.labelMedium,
                    color    = ext.textPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            FmLinearProgress(progress = volume.usedFraction)
            Text(
                text  = "${volume.displayFree} free",
                style = MaterialTheme.typography.labelSmall,
                color = ext.textSecondary,
            )
        }
    }
}

@Composable
private fun StorageAnalyzerCategoryRow(
    data: StorageCategoryData,
    fraction: Float,
    total: Long,
) {
    val ext = MaterialTheme.extended
    val animFraction by animateFloatAsState(
        targetValue   = fraction,
        animationSpec = tween(AnimationTokens.durationXL, easing = FastOutSlowInEasing),
        label         = "catAnim",
    )

    Row(
        verticalAlignment     = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
        modifier              = Modifier.fillMaxWidth(),
    ) {
        // Icon
        Box(
            contentAlignment = Alignment.Center,
            modifier         = Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(data.color.copy(alpha = 0.12f)),
        ) {
            Icon(
                imageVector        = data.icon,
                contentDescription = null,
                tint               = data.color,
                modifier           = Modifier.size(20.dp),
            )
        }

        Column(modifier = Modifier.weight(1f)) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier              = Modifier.fillMaxWidth(),
            ) {
                Text(
                    text  = data.label,
                    style = MaterialTheme.typography.bodySmall,
                    color = ext.textPrimary,
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
                ) {
                    Text(
                        text  = FileItem.formatSize(data.bytes),
                        style = ExtraTypography.sizeLabel,
                        color = ext.textSecondary,
                    )
                    Text(
                        text  = "${(fraction * 100).toInt()}%",
                        style = ExtraTypography.sizeLabel,
                        color = data.color,
                    )
                }
            }
            Spacer(Modifier.height(4.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(5.dp)
                    .clip(RoundedCornerShape(999.dp))
                    .background(ext.storageFree),
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(animFraction)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(999.dp))
                        .background(data.color),
                )
            }
        }
    }
}

@Composable
private fun CleanupSuggestionCard(
    usedPercent: Int,
    onCleanup: () -> Unit,
) {
    val ext = MaterialTheme.extended
    val (color, message) = when {
        usedPercent >= 90 -> Pair(
            MaterialTheme.colorScheme.error,
            "Storage critically low! Free up space now.",
        )
        usedPercent >= 80 -> Pair(
            RawColors.Amber500,
            "Storage almost full. Consider cleaning up.",
        )
        else              -> Pair(
            ext.iconSecondary,
            "You can free up some space.",
        )
    }

    Surface(
        color  = color.copy(alpha = 0.08f),
        shape  = ShapeTokens.cardShape,
        border = BorderStroke(1.dp, color.copy(alpha = 0.25f)),
    ) {
        Row(
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
            modifier              = Modifier
                .fillMaxWidth()
                .padding(SpacingTokens.lg),
        ) {
            Icon(
                imageVector        = Icons.Rounded.CleaningServices,
                contentDescription = null,
                tint               = color,
                modifier           = Modifier.size(22.dp),
            )
            Text(
                text     = message,
                style    = MaterialTheme.typography.bodySmall,
                color    = ext.textPrimary,
                modifier = Modifier.weight(1f),
            )
            FmPrimaryButton(
                text    = "Clean",
                onClick = onCleanup,
            )
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 3 — CREATE FILE DIALOG
// ════════════════════════════════════════════════════════════

@Composable
fun CreateFileDialog(
    visible: Boolean,
    currentPath: String,
    onConfirm: (name: String, extension: String) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
) {
    if (!visible) return
    val ext            = MaterialTheme.extended
    var fileName       by remember { mutableStateOf("") }
    var selectedExt    by remember { mutableStateOf("txt") }
    var customExt      by remember { mutableStateOf("") }
    var isCustom       by remember { mutableStateOf(false) }
    val focusRequester = remember { FocusRequester() }

    LaunchedEffect(visible) {
        if (visible) {
            fileName = ""
            delay(150)
            focusRequester.requestFocus()
        }
    }

    val commonExtensions = listOf(
        "txt" to Icons.Rounded.TextSnippet,
        "md"  to Icons.Rounded.Article,
        "json" to Icons.Rounded.DataObject,
        "xml" to Icons.Rounded.Code,
        "html" to Icons.Rounded.Html,
        "csv" to Icons.Rounded.TableChart,
        "sh"  to Icons.Rounded.Terminal,
        "log" to Icons.Rounded.List,
    )

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape           = ShapeTokens.dialogShape,
            color           = ext.surfaceDialog,
            shadowElevation = ElevationTokens.dialog,
            modifier        = modifier.fillMaxWidth(),
        ) {
            Column(
                modifier = Modifier.padding(SpacingTokens.xxl),
                verticalArrangement = Arrangement.spacedBy(SpacingTokens.lg),
            ) {
                // Header
                Row(
                    verticalAlignment     = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier         = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                Brush.linearGradient(ext.gradientAccent)
                            ),
                    ) {
                        Icon(
                            imageVector        = Icons.Rounded.NoteAdd,
                            contentDescription = null,
                            tint               = RawColors.White,
                            modifier           = Modifier.size(26.dp),
                        )
                    }
                    Column {
                        Text(
                            text  = "New File",
                            style = MaterialTheme.typography.titleMedium,
                            color = ext.textPrimary,
                        )
                        Text(
                            text     = currentPath.replace("/storage/emulated/0", "Internal"),
                            style    = ExtraTypography.pathStyle,
                            color    = ext.textTertiary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }

                // File name input
                FmTextField(
                    value          = fileName,
                    onValueChange  = { fileName = it },
                    label          = "File name",
                    placeholder    = "e.g. notes",
                    focusRequester = focusRequester,
                )

                // Extension selector
                SheetSectionLabel(text = "Extension")
                LazyVerticalGrid(
                    columns             = GridCells.Fixed(4),
                    horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
                    verticalArrangement   = Arrangement.spacedBy(SpacingTokens.sm),
                    userScrollEnabled     = false,
                    modifier              = Modifier.wrapContentHeight(),
                ) {
                    items(commonExtensions, key = { it.first }) { (extLabel, icon) ->
                        ExtensionSelectChip(
                            ext      = extLabel,
                            icon     = icon,
                            selected = selectedExt == extLabel && !isCustom,
                            onClick  = {
                                selectedExt = extLabel
                                isCustom    = false
                            },
                        )
                    }
                    // Custom extension chip
                    item {
                        ExtensionSelectChip(
                            ext      = "...",
                            icon     = Icons.Rounded.Edit,
                            selected = isCustom,
                            onClick  = { isCustom = true },
                        )
                    }
                }

                // Custom extension input
                AnimatedVisibility(visible = isCustom) {
                    FmTextField(
                        value         = customExt,
                        onValueChange = { customExt = it.trimStart('.') },
                        label         = "Custom extension",
                        placeholder   = "e.g. kotlin",
                        leadingIcon   = {
                            Text(
                                text  = ".",
                                style = MaterialTheme.typography.bodyLarge,
                                color = ext.textSecondary,
                            )
                        },
                    )
                }

                // Preview
                if (fileName.isNotBlank()) {
                    Surface(
                        color  = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f),
                        shape  = ShapeTokens.cardShape,
                    ) {
                        Row(
                            verticalAlignment     = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
                            modifier              = Modifier
                                .fillMaxWidth()
                                .padding(SpacingTokens.md),
                        ) {
                            Icon(
                                imageVector        = Icons.Rounded.InsertDriveFile,
                                contentDescription = null,
                                tint               = MaterialTheme.colorScheme.primary,
                                modifier           = Modifier.size(16.dp),
                            )
                            Text(
                                text  = buildString {
                                    append(fileName.trim())
                                    append(".")
                                    append(
                                        if (isCustom) customExt.ifEmpty { "txt" }
                                        else selectedExt
                                    )
                                },
                                style = ExtraTypography.pathStyle,
                                color = MaterialTheme.colorScheme.primary,
                            )
                        }
                    }
                }

                // Buttons
                Row(
                    horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
                    modifier              = Modifier.fillMaxWidth(),
                ) {
                    FmSecondaryButton(
                        text     = "Cancel",
                        onClick  = onDismiss,
                        modifier = Modifier.weight(1f),
                    )
                    FmPrimaryButton(
                        text     = "Create",
                        onClick  = {
                            if (fileName.isNotBlank()) {
                                val finalExt = if (isCustom)
                                    customExt.ifEmpty { "txt" }
                                else
                                    selectedExt
                                onConfirm(fileName.trim(), finalExt)
                                onDismiss()
                            }
                        },
                        enabled  = fileName.isNotBlank(),
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }
    }
}

@Composable
private fun ExtensionSelectChip(
    ext: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    onClick: () -> Unit,
) {
    val theme = MaterialTheme.extended
    val bgColor by animateColorAsState(
        targetValue = if (selected)
            MaterialTheme.colorScheme.primaryContainer
        else
            MaterialTheme.colorScheme.surfaceVariant,
        label = "extChipBg",
    )
    val scale by animateFloatAsState(
        targetValue   = if (selected) 1.04f else 1f,
        animationSpec = spring(stiffness = AnimationTokens.springBouncy),
        label         = "extChipScale",
    )

    Surface(
        onClick  = onClick,
        color    = bgColor,
        shape    = ShapeTokens.cardShape,
        border   = if (selected)
                       BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
                   else null,
        modifier = Modifier.scale(scale),
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.xxs),
            modifier            = Modifier
                .fillMaxWidth()
                .padding(vertical = SpacingTokens.sm, horizontal = SpacingTokens.xs),
        ) {
            Icon(
                imageVector        = icon,
                contentDescription = null,
                tint               = if (selected)
                                         MaterialTheme.colorScheme.primary
                                     else
                                         theme.iconSecondary,
                modifier           = Modifier.size(16.dp),
            )
            Text(
                text  = ".${ext}",
                style = ExtraTypography.extensionBadge.copy(fontSize = 10.sp),
                color = if (selected)
                            MaterialTheme.colorScheme.primary
                        else
                            theme.textSecondary,
            )
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 4 — THEME PICKER SHEET
// ════════════════════════════════════════════════════════════

@Composable
fun ThemePickerSheet(
    visible: Boolean,
    themeState: ThemeState,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended

    FmBottomSheet(
        visible   = visible,
        onDismiss = onDismiss,
        title     = "Appearance",
        subtitle  = "Choose your preferred theme",
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = SpacingTokens.screenPaddingH),
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.md),
        ) {
            // Theme mode cards
            Row(
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
                modifier              = Modifier.fillMaxWidth(),
            ) {
                ThemeModeCard(
                    label    = "Light",
                    icon     = Icons.Rounded.LightMode,
                    selected = themeState.mode == ThemeMode.LIGHT,
                    isDark   = false,
                    onClick  = { themeState.mode = ThemeMode.LIGHT },
                    modifier = Modifier.weight(1f),
                )
                ThemeModeCard(
                    label    = "Dark",
                    icon     = Icons.Rounded.DarkMode,
                    selected = themeState.mode == ThemeMode.DARK,
                    isDark   = true,
                    onClick  = { themeState.mode = ThemeMode.DARK },
                    modifier = Modifier.weight(1f),
                )
                ThemeModeCard(
                    label    = "System",
                    icon     = Icons.Rounded.SettingsBrightness,
                    selected = themeState.mode == ThemeMode.SYSTEM,
                    isDark   = false,
                    onClick  = { themeState.mode = ThemeMode.SYSTEM },
                    modifier = Modifier.weight(1f),
                )
            }

            FmDivider()

            // Dynamic color toggle (Android 12+)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                Surface(
                    color  = MaterialTheme.colorScheme.surfaceVariant,
                    shape  = ShapeTokens.cardShape,
                ) {
                    Row(
                        verticalAlignment     = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier              = Modifier
                            .fillMaxWidth()
                            .padding(SpacingTokens.lg),
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text  = "Dynamic Color",
                                style = MaterialTheme.typography.bodyMedium,
                                color = ext.textPrimary,
                            )
                            Text(
                                text  = "Use wallpaper colors (Material You)",
                                style = MaterialTheme.typography.labelSmall,
                                color = ext.textSecondary,
                            )
                        }
                        // Dynamic color state would be in themeState
                        Switch(
                            checked         = false,
                            onCheckedChange = { /* toggle dynamic */ },
                            colors          = SwitchDefaults.colors(
                                checkedTrackColor = MaterialTheme.colorScheme.primary,
                            ),
                        )
                    }
                }
            }

            Spacer(Modifier.height(SpacingTokens.lg))
        }
    }
}

@Composable
private fun ThemeModeCard(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    isDark: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext    = MaterialTheme.extended
    val scale by animateFloatAsState(
        targetValue   = if (selected) 1.04f else 1f,
        animationSpec = spring(stiffness = AnimationTokens.springBouncy),
        label         = "themeCardScale",
    )

    Surface(
        onClick  = onClick,
        color    = if (isDark) RawColors.Neutral900 else RawColors.Neutral50,
        shape    = ShapeTokens.cardShape,
        border   = BorderStroke(
            width = if (selected) 2.dp else 1.dp,
            color = if (selected) MaterialTheme.colorScheme.primary
                    else ext.stroke,
        ),
        modifier = modifier.scale(scale),
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
            modifier            = Modifier.padding(SpacingTokens.lg),
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier         = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(
                        if (selected)
                            MaterialTheme.colorScheme.primaryContainer
                        else
                            if (isDark) RawColors.Neutral800 else RawColors.Neutral200
                    ),
            ) {
                Icon(
                    imageVector        = icon,
                    contentDescription = label,
                    tint               = if (selected)
                                             MaterialTheme.colorScheme.primary
                                         else
                                             if (isDark) RawColors.Neutral400
                                             else RawColors.Neutral600,
                    modifier           = Modifier.size(22.dp),
                )
            }
            Text(
                text  = label,
                style = MaterialTheme.typography.labelMedium,
                color = if (isDark) RawColors.Neutral100 else RawColors.Neutral900,
            )
            // Selected checkmark
            AnimatedVisibility(visible = selected) {
                Icon(
                    imageVector        = Icons.Rounded.CheckCircle,
                    contentDescription = null,
                    tint               = MaterialTheme.colorScheme.primary,
                    modifier           = Modifier.size(16.dp),
                )
            }
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 5 — ONBOARDING / INTRO SLIDER
// ════════════════════════════════════════════════════════════

data class OnboardingPage(
    val title: String,
    val description: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val gradient: List<Color>,
)

@Composable
fun OnboardingScreen(
    onFinish: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended

    val pages = remember {
        listOf(
            OnboardingPage(
                title       = "Your Files, Your Way",
                description = "Browse, manage and organize all your files and folders with a beautiful, modern interface built for power users.",
                icon        = Icons.Rounded.FolderOpen,
                gradient    = listOf(RawColors.Brand400, RawColors.Violet500),
            ),
            OnboardingPage(
                title       = "Split Screen Multitasking",
                description = "Work with two folders side by side. Drag, copy and move files between panes effortlessly — productivity unlocked.",
                icon        = Icons.Rounded.VerticalSplit,
                gradient    = listOf(RawColors.Cyan400, RawColors.Brand400),
            ),
            OnboardingPage(
                title       = "Smart Search & Filter",
                description = "Find any file instantly with lightning-fast search. Filter by type, size, date and more. Voice search included.",
                icon        = Icons.Rounded.Search,
                gradient    = listOf(RawColors.Violet500, RawColors.Brand500),
            ),
            OnboardingPage(
                title       = "Zip, Extract & Share",
                description = "Compress files into archives, extract with one tap, and share directly with any app — all without leaving the app.",
                icon        = Icons.Rounded.FolderZip,
                gradient    = listOf(RawColors.Green400, RawColors.Cyan400),
            ),
        )
    }

    var currentPage by remember { mutableStateOf(0) }
    val scope       = rememberCoroutineScope()
    val pagerState  = rememberPagerState(pageCount = { pages.size })

    LaunchedEffect(pagerState.currentPage) {
        currentPage = pagerState.currentPage
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(colors = ext.gradientSurface)
            ),
    ) {
        // Skip button
        Row(
            modifier              = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(
                    horizontal = SpacingTokens.screenPaddingH,
                    vertical   = SpacingTokens.md,
                ),
            horizontalArrangement = Arrangement.End,
        ) {
            AnimatedVisibility(visible = currentPage < pages.lastIndex) {
                FmGhostButton(
                    text    = "Skip",
                    onClick = onFinish,
                    color   = ext.textSecondary,
                )
            }
        }

        // Pager
        HorizontalPager(
            state    = pagerState,
            modifier = Modifier.weight(1f),
        ) { pageIdx ->
            OnboardingPageContent(
                page     = pages[pageIdx],
                modifier = Modifier.fillMaxSize(),
            )
        }

        // Bottom section
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier            = Modifier
                .fillMaxWidth()
                .padding(
                    horizontal = SpacingTokens.screenPaddingH,
                    vertical   = SpacingTokens.xxl,
                )
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.xxl),
        ) {
            // Page indicators
            Row(
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
            ) {
                pages.indices.forEach { idx ->
                    val isSelected = idx == currentPage
                    val width by animateDpAsState(
                        targetValue   = if (isSelected) 24.dp else 8.dp,
                        animationSpec = spring(stiffness = AnimationTokens.springStiff),
                        label         = "dotWidth",
                    )
                    Box(
                        modifier = Modifier
                            .height(8.dp)
                            .width(width)
                            .clip(RoundedCornerShape(999.dp))
                            .background(
                                if (isSelected)
                                    MaterialTheme.colorScheme.primary
                                else
                                    ext.stroke,
                            ),
                    )
                }
            }

            // Action button
            FmPrimaryButton(
                text     = if (currentPage == pages.lastIndex)
                                "Get Started"
                           else
                               "Next",
                onClick  = {
                    if (currentPage == pages.lastIndex) {
                        onFinish()
                    } else {
                        scope.launch {
                            pagerState.animateScrollToPage(currentPage + 1)
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                leadingIcon = if (currentPage == pages.lastIndex) {
                    {
                        Icon(
                            imageVector        = Icons.Rounded.RocketLaunch,
                            contentDescription = null,
                            tint               = RawColors.White,
                            modifier           = Modifier.size(18.dp),
                        )
                    }
                } else null,
            )
        }
    }
}

@Composable
private fun OnboardingPageContent(
    page: OnboardingPage,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended
    val infiniteTransition = rememberInfiniteTransition(label = "onboardAnim")
    val floatY by infiniteTransition.animateFloat(
        initialValue  = 0f,
        targetValue   = -16f,
        animationSpec = infiniteRepeatable(
            animation  = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "floatY",
    )
    val rotation by infiniteTransition.animateFloat(
        initialValue  = -3f,
        targetValue   = 3f,
        animationSpec = infiniteRepeatable(
            animation  = tween(3000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "rotation",
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier            = modifier.padding(SpacingTokens.xxl),
    ) {
        // Animated icon blob
        Box(
            contentAlignment = Alignment.Center,
            modifier         = Modifier
                .size(160.dp)
                .offset(y = floatY.dp)
                .rotate(rotation),
        ) {
            // Outer glow
            Box(
                modifier = Modifier
                    .size(160.dp)
                    .clip(RoundedCornerShape(48.dp))
                    .background(
                        Brush.linearGradient(
                            page.gradient.map { it.copy(alpha = 0.15f) }
                        )
                    ),
            )
            // Main icon box
            Box(
                contentAlignment = Alignment.Center,
                modifier         = Modifier
                    .size(110.dp)
                    .clip(RoundedCornerShape(32.dp))
                    .background(
                        Brush.linearGradient(colors = page.gradient)
                    )
                    .shadow(
                        elevation    = ElevationTokens.xl,
                        shape        = RoundedCornerShape(32.dp),
                        ambientColor = page.gradient.first(),
                        spotColor    = page.gradient.first(),
                    ),
            ) {
                Icon(
                    imageVector        = page.icon,
                    contentDescription = null,
                    tint               = RawColors.White,
                    modifier           = Modifier.size(52.dp),
                )
            }
        }

        Spacer(Modifier.height(SpacingTokens.xxxl))

        Text(
            text      = page.title,
            style     = MaterialTheme.typography.headlineSmall,
            color     = ext.textPrimary,
            textAlign = TextAlign.Center,
        )

        Spacer(Modifier.height(SpacingTokens.lg))

        Text(
            text      = page.description,
            style     = MaterialTheme.typography.bodyLarge,
            color     = ext.textSecondary,
            textAlign = TextAlign.Center,
        )
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 6 — TAG MANAGER SHEET
// ════════════════════════════════════════════════════════════

@Composable
fun TagManagerSheet(
    visible: Boolean,
    currentTags: List<String>,
    allTags: List<String>,
    onDismiss: () -> Unit,
    onTagsUpdate: (List<String>) -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext         = MaterialTheme.extended
    var selected    by remember(currentTags) { mutableStateOf(currentTags.toSet()) }
    var newTagText  by remember { mutableStateOf("") }

    FmBottomSheet(
        visible   = visible,
        onDismiss = onDismiss,
        title     = "Manage Tags",
        subtitle  = "${selected.size} tags selected",
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = SpacingTokens.screenPaddingH),
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.md),
        ) {
            // New tag input
            Row(
                verticalAlignment     = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
            ) {
                FmTextField(
                    value         = newTagText,
                    onValueChange = { newTagText = it },
                    label         = "New tag",
                    modifier      = Modifier.weight(1f),
                    keyboardAction = ImeAction.Done,
                    onKeyboardDone = {
                        if (newTagText.isNotBlank()) {
                            selected = selected + newTagText.trim()
                            newTagText = ""
                        }
                    },
                )
                FmPrimaryButton(
                    text    = "Add",
                    onClick = {
                        if (newTagText.isNotBlank()) {
                            selected = selected + newTagText.trim()
                            newTagText = ""
                        }
                    },
                    enabled = newTagText.isNotBlank(),
                )
            }

            // All tags
            SheetSectionLabel(text = "Tags")

            if (allTags.isEmpty() && selected.isEmpty()) {
                Text(
                    text  = "No tags yet. Create your first tag above.",
                    style = MaterialTheme.typography.bodySmall,
                    color = ext.textTertiary,
                )
            } else {
                // Combined unique tags
                val combinedTags = (allTags + selected).distinct()
                LazyVerticalGrid(
                    columns             = GridCells.Adaptive(100.dp),
                    horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
                    verticalArrangement   = Arrangement.spacedBy(SpacingTokens.sm),
                    userScrollEnabled     = false,
                    modifier              = Modifier.wrapContentHeight(),
                ) {
                    items(combinedTags, key = { it }) { tag ->
                        val isSelected = tag in selected
                        FmFilterChip(
                            label    = tag,
                            selected = isSelected,
                            onClick  = {
                                selected = if (isSelected)
                                    selected - tag
                                else
                                    selected + tag
                            },
                        )
                    }
                }
            }

            // Apply
            Row(
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
                modifier              = Modifier
                    .fillMaxWidth()
                    .padding(
                        top    = SpacingTokens.md,
                        bottom = SpacingTokens.xxl,
                    ),
            ) {
                FmSecondaryButton(
                    text     = "Cancel",
                    onClick  = onDismiss,
                    modifier = Modifier.weight(1f),
                )
                FmPrimaryButton(
                    text     = "Apply",
                    onClick  = {
                        onTagsUpdate(selected.toList())
                        onDismiss()
                    },
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 7 — SPLIT SCREEN TUTORIAL SHEET
// ════════════════════════════════════════════════════════════

@Composable
fun SplitScreenTutorialSheet(
    visible: Boolean,
    onDismiss: () -> Unit,
    onEnable: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended

    FmBottomSheet(
        visible   = visible,
        onDismiss = onDismiss,
        title     = "Split Screen Mode",
        subtitle  = "Work with two folders at once",
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = SpacingTokens.screenPaddingH),
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.md),
        ) {
            // Visual demo
            SplitScreenDemoPreview()

            FmDivider()

            // Feature list
            SheetSectionLabel(text = "Features")

            listOf(
                Triple(Icons.Rounded.ContentCopy, "Copy between panes",
                    "Drag or use copy/paste to move files between two folders"),
                Triple(Icons.Rounded.SwapHoriz,   "Independent navigation",
                    "Browse different paths in each pane simultaneously"),
                Triple(Icons.Rounded.TouchApp,    "Drag divider",
                    "Resize panes by dragging the center divider"),
                Triple(Icons.Rounded.VerticalSplit, "Auto split on landscape",
                    "Splits automatically when you rotate to landscape"),
            ).forEach { (icon, title, desc) ->
                Row(
                    verticalAlignment     = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
                    modifier              = Modifier.fillMaxWidth(),
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier         = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer),
                    ) {
                        Icon(
                            imageVector        = icon,
                            contentDescription = null,
                            tint               = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier           = Modifier.size(20.dp),
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text  = title,
                            style = MaterialTheme.typography.labelLarge,
                            color = ext.textPrimary,
                        )
                        Text(
                            text  = desc,
                            style = MaterialTheme.typography.bodySmall,
                            color = ext.textSecondary,
                        )
                    }
                }
            }

            // Buttons
            Row(
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
                modifier              = Modifier
                    .fillMaxWidth()
                    .padding(
                        top    = SpacingTokens.md,
                        bottom = SpacingTokens.xxl,
                    ),
            ) {
                FmSecondaryButton(
                    text     = "Later",
                    onClick  = onDismiss,
                    modifier = Modifier.weight(1f),
                )
                FmPrimaryButton(
                    text     = "Enable Now",
                    onClick  = {
                        onEnable()
                        onDismiss()
                    },
                    modifier = Modifier.weight(1f),
                    leadingIcon = {
                        Icon(
                            imageVector        = Icons.Rounded.VerticalSplit,
                            contentDescription = null,
                            tint               = RawColors.White,
                            modifier           = Modifier.size(16.dp),
                        )
                    },
                )
            }
        }
    }
}

@Composable
private fun SplitScreenDemoPreview() {
    val ext = MaterialTheme.extended
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(120.dp)
            .clip(ShapeTokens.cardShape)
            .border(1.dp, ext.stroke, ShapeTokens.cardShape),
    ) {
        Row(modifier = Modifier.fillMaxSize()) {
            // Left pane
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)),
                contentAlignment = Alignment.Center,
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(SpacingTokens.xs),
                ) {
                    Icon(
                        imageVector        = Icons.Rounded.FolderOpen,
                        contentDescription = null,
                        tint               = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f),
                        modifier           = Modifier.size(28.dp),
                    )
                    Text(
                        text  = "Pane A",
                        style = ExtraTypography.overline,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f),
                    )
                }
            }

            // Divider
            Box(
                modifier = Modifier
                    .width(2.dp)
                    .fillMaxHeight()
                    .background(MaterialTheme.colorScheme.primary),
            )

            // Right pane
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .background(MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.3f)),
                contentAlignment = Alignment.Center,
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(SpacingTokens.xs),
                ) {
                    Icon(
                        imageVector        = Icons.Rounded.Folder,
                        contentDescription = null,
                        tint               = MaterialTheme.colorScheme.secondary.copy(alpha = 0.7f),
                        modifier           = Modifier.size(28.dp),
                    )
                    Text(
                        text  = "Pane B",
                        style = ExtraTypography.overline,
                        color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.7f),
                    )
                }
            }
        }

        // Arrow overlay
        Box(
            contentAlignment = Alignment.Center,
            modifier         = Modifier.fillMaxSize(),
        ) {
            Icon(
                imageVector        = Icons.Rounded.SwapHoriz,
                contentDescription = null,
                tint               = MaterialTheme.colorScheme.primary,
                modifier           = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.9f))
                    .padding(4.dp),
            )
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 8 — ABOUT SHEET
// ════════════════════════════════════════════════════════════

@Composable
fun AboutSheet(
    visible: Boolean,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended

    FmBottomSheet(
        visible   = visible,
        onDismiss = onDismiss,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier            = Modifier
                .fillMaxWidth()
                .padding(horizontal = SpacingTokens.screenPaddingH),
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.lg),
        ) {
            // App logo
            Box(
                contentAlignment = Alignment.Center,
                modifier         = Modifier
                    .size(80.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(
                        Brush.linearGradient(ext.gradientPrimary)
                    ),
            ) {
                Icon(
                    imageVector        = Icons.Rounded.Folder,
                    contentDescription = null,
                    tint               = RawColors.White,
                    modifier           = Modifier.size(42.dp),
                )
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(SpacingTokens.xs),
            ) {
                Text(
                    text  = "File Manager",
                    style = MaterialTheme.typography.headlineSmall,
                    color = ext.textPrimary,
                )
                Text(
                    text  = "Version 1.0.0 • Build 2026",
                    style = MaterialTheme.typography.bodySmall,
                    color = ext.textSecondary,
                )
                Surface(
                    color  = MaterialTheme.colorScheme.primaryContainer,
                    shape  = ShapeTokens.badgeShape,
                ) {
                    Text(
                        text     = "Premium • Dev Fav Edition",
                        style    = MaterialTheme.typography.labelSmall,
                        color    = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    )
                }
            }

            FmDivider()

            // Info rows
            listOf(
                Triple(Icons.Rounded.Code,         "Built with",   "Kotlin + Jetpack Compose"),
                Triple(Icons.Rounded.Palette,      "Design",       "Material 3 + Custom Design System"),
                Triple(Icons.Rounded.VerticalSplit,"Split Screen", "Fully supported"),
                Triple(Icons.Rounded.DarkMode,     "Theme",        "Light + Dark + System"),
                Triple(Icons.Rounded.Security,     "Privacy",      "No data collected"),
            ).forEach { (icon, label, value) ->
                Row(
                    verticalAlignment     = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
                    modifier              = Modifier.fillMaxWidth(),
                ) {
                    Icon(
                        imageVector        = icon,
                        contentDescription = null,
                        tint               = ext.iconSecondary,
                        modifier           = Modifier.size(16.dp),
                    )
                    Text(
                        text  = label,
                        style = MaterialTheme.typography.bodySmall,
                        color = ext.textSecondary,
                        modifier = Modifier.width(100.dp),
                    )
                    Text(
                        text  = value,
                        style = MaterialTheme.typography.bodySmall,
                        color = ext.textPrimary,
                    )
                }
            }

            Spacer(Modifier.height(SpacingTokens.md))

            FmSecondaryButton(
                text     = "Close",
                onClick  = onDismiss,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = SpacingTokens.xxl),
            )
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 9 — FILE PREVIEW SHEET (Text / Image preview)
// ════════════════════════════════════════════════════════════

@Composable
fun FilePreviewSheet(
    item: FileItem,
    visible: Boolean,
    onDismiss: () -> Unit,
    onOpenFull: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended

    FmBottomSheet(
        visible              = visible,
        onDismiss            = onDismiss,
        skipPartiallyExpanded = false,
        title                = item.name,
        subtitle             = item.displaySize,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = SpacingTokens.screenPaddingH),
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.md),
        ) {
            // Preview area
            Box(
                contentAlignment = Alignment.Center,
                modifier         = Modifier
                    .fillMaxWidth()
                    .height(280.dp)
                    .clip(ShapeTokens.cardShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant),
            ) {
                when (item.fileType) {
                    FileType.IMAGE -> {
                        // Image preview via Coil
                        coil.compose.AsyncImage(
                            model              = item.path,
                            contentDescription = item.name,
                            contentScale       = androidx.compose.ui.layout.ContentScale.Fit,
                            modifier           = Modifier.fillMaxSize(),
                        )
                    }
                    FileType.CODE, FileType.DOCUMENT -> {
                        // Text preview placeholder
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(SpacingTokens.md),
                        ) {
                            Icon(
                                imageVector        = Icons.Rounded.Article,
                                contentDescription = null,
                                tint               = ext.iconSecondary,
                                modifier           = Modifier.size(48.dp),
                            )
                            Text(
                                text  = "Text preview",
                                style = MaterialTheme.typography.bodySmall,
                                color = ext.textTertiary,
                            )
                        }
                    }
                    else -> {
                        // Generic preview
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(SpacingTokens.md),
                        ) {
                            FileTypeIcon(
                                fileType  = item.iconType,
                                size      = 64.dp,
                                showBadge = false,
                            )
                            Text(
                                text  = "No preview available",
                                style = MaterialTheme.typography.bodySmall,
                                color = ext.textTertiary,
                            )
                        }
                    }
                }
            }

            // Quick info
            Row(
                horizontalArrangement = Arrangement.SpaceEvenly,
                modifier              = Modifier.fillMaxWidth(),
            ) {
                PreviewInfoItem(label = "Size",     value = item.displaySize)
                PreviewInfoItem(label = "Modified", value = item.displayDateShort)
                PreviewInfoItem(label = "Type",     value = item.fileType.displayName)
            }

            // Actions
            Row(
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
                modifier              = Modifier
                    .fillMaxWidth()
                    .padding(bottom = SpacingTokens.xxl),
            ) {
                FmSecondaryButton(
                    text     = "Share",
                    onClick  = { /* share */ },
                    modifier = Modifier.weight(1f),
                    leadingIcon = {
                        Icon(
                            imageVector        = Icons.Rounded.Share,
                            contentDescription = null,
                            tint               = MaterialTheme.colorScheme.primary,
                            modifier           = Modifier.size(16.dp),
                        )
                    },
                )
                FmPrimaryButton(
                    text     = "Open",
                    onClick  = {
                        onOpenFull()
                        onDismiss()
                    },
                    modifier = Modifier.weight(1f),
                    leadingIcon = {
                        Icon(
                            imageVector        = Icons.Rounded.OpenInNew,
                            contentDescription = null,
                            tint               = RawColors.White,
                            modifier           = Modifier.size(16.dp),
                        )
                    },
                )
            }
        }
    }
}

@Composable
private fun PreviewInfoItem(label: String, value: String) {
    val ext = MaterialTheme.extended
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        Text(
            text  = value,
            style = MaterialTheme.typography.labelMedium,
            color = ext.textPrimary,
        )
        Text(
            text  = label,
            style = MaterialTheme.typography.labelSmall,
            color = ext.textTertiary,
        )
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 10 — IN-APP NOTIFICATION UI
// ════════════════════════════════════════════════════════════

@Composable
fun InAppNotification(
    message: String,
    type: SnackbarType,
    visible: Boolean,
    onDismiss: () -> Unit,
    action: Pair<String, () -> Unit>? = null,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended
    val (bgColor, icon) = when (type) {
        SnackbarType.SUCCESS -> Pair(ext.success,                           Icons.Rounded.CheckCircle)
        SnackbarType.ERROR   -> Pair(MaterialTheme.colorScheme.error,       Icons.Rounded.Error)
        SnackbarType.WARNING -> Pair(ext.warning,                           Icons.Rounded.Warning)
        SnackbarType.INFO    -> Pair(MaterialTheme.colorScheme.inverseSurface, Icons.Rounded.Info)
    }

    // Auto dismiss
    LaunchedEffect(visible, message) {
        if (visible) {
            delay(3500)
            onDismiss()
        }
    }

    AnimatedVisibility(
        visible  = visible,
        enter    = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
        exit     = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
        modifier = modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(SpacingTokens.screenPaddingH)
            .zIndex(99f),
    ) {
        Surface(
            color           = bgColor,
            shape           = ShapeTokens.cardShape,
            shadowElevation = ElevationTokens.dialog,
        ) {
            Row(
                verticalAlignment     = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
                modifier              = Modifier.padding(SpacingTokens.md),
            ) {
                Icon(
                    imageVector        = icon,
                    contentDescription = null,
                    tint               = RawColors.White,
                    modifier           = Modifier.size(20.dp),
                )
                Text(
                    text     = message,
                    style    = MaterialTheme.typography.bodyMedium,
                    color    = RawColors.White,
                    modifier = Modifier.weight(1f),
                )
                action?.let { (label, onClick) ->
                    TextButton(onClick = {
                        onClick()
                        onDismiss()
                    }) {
                        Text(
                            text  = label,
                            style = MaterialTheme.typography.labelLarge,
                            color = RawColors.White.copy(alpha = 0.9f),
                        )
                    }
                }
                FmIconButton(
                    icon               = Icons.Rounded.Close,
                    contentDescription = "Dismiss",
                    onClick            = onDismiss,
                    tint               = RawColors.White,
                    containerSize      = 28.dp,
                    size               = 15.dp,
                )
            }
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 11 — SETTINGS SHEET (Mini)
// ════════════════════════════════════════════════════════════

@Composable
fun SettingsSheet(
    visible: Boolean,
    themeState: ThemeState,
    fmState: FileManagerState,
    onDismiss: () -> Unit,
    onOpenFullSettings: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended

    FmBottomSheet(
        visible   = visible,
        onDismiss = onDismiss,
        title     = "Settings",
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = SpacingTokens.screenPaddingH),
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
        ) {
            // Theme
            SettingsRow(
                icon    = Icons.Rounded.Palette,
                label   = "Theme",
                value   = when (themeState.mode) {
                    ThemeMode.LIGHT  -> "Light"
                    ThemeMode.DARK   -> "Dark"
                    ThemeMode.SYSTEM -> "System"
                },
                onClick = { /* open theme picker */ },
            )

            // Default view
            SettingsRow(
                icon    = Icons.Rounded.GridView,
                label   = "Default View",
                value   = fmState.activePane.viewMode.name
                    .lowercase().replaceFirstChar { it.uppercase() },
                onClick = { /* cycle view mode */ },
            )

            // Sort
            SettingsRow(
                icon    = Icons.Rounded.Sort,
                label   = "Default Sort",
                value   = fmState.activePane.sortConfig.sortBy.displayName,
                onClick = { fmState.showSortSheet = true },
            )

            // Show hidden files
            Surface(
                color  = MaterialTheme.colorScheme.surfaceVariant,
                shape  = ShapeTokens.cardShape,
            ) {
                Row(
                    verticalAlignment     = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier              = Modifier
                        .fillMaxWidth()
                        .padding(SpacingTokens.md),
                ) {
                    Row(
                        verticalAlignment     = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
                    ) {
                        Icon(
                            imageVector        = Icons.Rounded.Visibility,
                            contentDescription = null,
                            tint               = ext.iconSecondary,
                            modifier           = Modifier.size(18.dp),
                        )
                        Text(
                            text  = "Show Hidden Files",
                            style = MaterialTheme.typography.bodyMedium,
                            color = ext.textPrimary,
                        )
                    }
                    Switch(
                        checked         = fmState.activePane.sortConfig.showHidden,
                        onCheckedChange = {
                            fmState.activePane.updateSortConfig(
                                fmState.activePane.sortConfig.copy(showHidden = it)
                            )
                        },
                        colors = SwitchDefaults.colors(
                            checkedTrackColor = MaterialTheme.colorScheme.primary,
                        ),
                    )
                }
            }

            FmDivider()

            // Full settings
            FmSecondaryButton(
                text     = "More Settings",
                onClick  = {
                    onOpenFullSettings()
                    onDismiss()
                },
                modifier = Modifier.fillMaxWidth(),
                leadingIcon = {
                    Icon(
                        imageVector        = Icons.Rounded.Settings,
                        contentDescription = null,
                        tint               = MaterialTheme.colorScheme.primary,
                        modifier           = Modifier.size(16.dp),
                    )
                },
            )

            Spacer(Modifier.height(SpacingTokens.xxl))
        }
    }
}

@Composable
private fun SettingsRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    onClick: () -> Unit,
) {
    val ext               = MaterialTheme.extended
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed         by interactionSource.collectIsPressedAsState()

    Surface(
        color  = if (isPressed)
                     MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
                 else
                     MaterialTheme.colorScheme.surfaceVariant,
        shape  = ShapeTokens.cardShape,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(
                interactionSource = interactionSource,
                indication        = ripple(
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                ),
                onClick = onClick,
            ),
    ) {
        Row(
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier              = Modifier
                .fillMaxWidth()
                .padding(SpacingTokens.md),
        ) {
            Row(
                verticalAlignment     = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
            ) {
                Icon(
                    imageVector        = icon,
                    contentDescription = null,
                    tint               = ext.iconSecondary,
                    modifier           = Modifier.size(18.dp),
                )
                Text(
                    text  = label,
                    style = MaterialTheme.typography.bodyMedium,
                    color = ext.textPrimary,
                )
            }
            Row(
                verticalAlignment     = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.xs),
            ) {
                Text(
                    text  = value,
                    style = MaterialTheme.typography.labelMedium,
                    color = ext.textSecondary,
                )
                Icon(
                    imageVector        = Icons.Rounded.ChevronRight,
                    contentDescription = null,
                    tint               = ext.iconTertiary,
                    modifier           = Modifier.size(16.dp),
                )
            }
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 12 — GLOBAL UI STATE HANDLER
//              Renders all dialogs/sheets from FileManagerState
// ════════════════════════════════════════════════════════════

@Composable
fun GlobalDialogHandler(
    fmState: FileManagerState,
    themeState: ThemeState,
    modifier: Modifier = Modifier,
) {
    val activeItems = fmState.activePane.selection
        .getSelectedItems(fmState.activePane.displayItems)

    // ── Create Folder ────────────────────────────────────────
    CreateFolderDialog(
        visible      = fmState.showCreateFolderDialog,
        currentPath  = fmState.activePane.currentPath,
        onConfirm    = { name ->
            // call repository
            fmState.showCreateFolderDialog = false
            fmState.showSnackbar("Folder \"$name\" created", SnackbarType.SUCCESS)
        },
        onDismiss    = { fmState.showCreateFolderDialog = false },
    )

    // ── Create File ──────────────────────────────────────────
    CreateFileDialog(
        visible      = fmState.showCreateFileDialog,
        currentPath  = fmState.activePane.currentPath,
        onConfirm    = { name, ext ->
            fmState.showCreateFileDialog = false
            fmState.showSnackbar("File \"$name.$ext\" created", SnackbarType.SUCCESS)
        },
        onDismiss    = { fmState.showCreateFileDialog = false },
    )

    // ── Rename ───────────────────────────────────────────────
    fmState.renameTarget?.let { target ->
        RenameDialog(
            item      = target,
            visible   = fmState.showRenameDialog,
            onConfirm = { newName ->
                fmState.showRenameDialog = false
                fmState.renameTarget     = null
                fmState.showSnackbar("Renamed to \"$newName\"", SnackbarType.SUCCESS)
            },
            onDismiss = {
                fmState.showRenameDialog = false
                fmState.renameTarget     = null
            },
        )
    }

    // ── Delete ───────────────────────────────────────────────
    DeleteConfirmDialog(
        items     = if (activeItems.isNotEmpty()) activeItems
                    else fmState.contextMenuTarget?.let { listOf(it) } ?: emptyList(),
        visible   = fmState.showDeleteDialog,
        onConfirm = {
            fmState.showDeleteDialog = false
            fmState.contextMenuTarget = null
            fmState.showSnackbar("Deleted successfully", SnackbarType.SUCCESS)
        },
        onDismiss = {
            fmState.showDeleteDialog  = false
            fmState.contextMenuTarget = null
        },
    )

    // ── Properties ───────────────────────────────────────────
    fmState.propertiesTarget?.let { target ->
        PropertiesSheet(
            item               = target,
            visible            = fmState.showPropertiesSheet,
            onDismiss          = {
                fmState.showPropertiesSheet = false
                fmState.propertiesTarget    = null
            },
            onNavigateToParent = { path ->
                fmState.navigateTo(path)
                fmState.showPropertiesSheet = false
            },
        )
    }

    // ── Zip ──────────────────────────────────────────────────
    ZipOptionsSheet(
        items      = activeItems,
        visible    = fmState.showZipDialog,
        onDismiss  = { fmState.showZipDialog = false },
        onCompress = { name, format, level ->
            fmState.showZipDialog = false
            fmState.showSnackbar("Compressing to $name...", SnackbarType.INFO)
        },
    )

    // ── Storage Analyzer ────────────────────────────────────
    StorageAnalyzerSheet(
        visible      = fmState.showStorageAnalyzer,
        storageState = fmState.storage,
        onDismiss    = { fmState.showStorageAnalyzer = false },
        onCleanup    = { fmState.showStorageAnalyzer = false },
    )

    // ── Sort Sheet ───────────────────────────────────────────
    SortBottomSheet(
        visible  = fmState.showSortSheet,
        current  = fmState.activePane.sortConfig,
        onDismiss = { fmState.showSortSheet = false },
        onApply  = { config ->
            fmState.activePane.updateSortConfig(config)
        },
    )

    // ── Filter Sheet ─────────────────────────────────────────
    FilterBottomSheet(
        visible   = fmState.showFilterSheet,
        current   = fmState.activePane.filterConfig,
        onDismiss = { fmState.showFilterSheet = false },
        onApply   = { config ->
            fmState.activePane.updateFilterConfig(config)
        },
    )

    // ── Operation Progress ───────────────────────────────────
    OperationProgressSheet(
        operationState = fmState.operation,
        onCancel       = { fmState.operation.reset() },
        onPauseResume  = { fmState.operation.pauseResume() },
    )

    // ── Conflict Resolution ───────────────────────────────────
    (fmState.operation.status as? OperationStatus.Conflict)?.let { conflict ->
        ConflictResolutionDialog(
            conflictItem   = conflict.conflictingItem,
            targetPath     = conflict.targetPath,
            remainingCount = conflict.remainingConflicts,
            visible        = true,
            onResolve      = { resolution ->
                // handle resolution
            },
            onDismiss      = { fmState.operation.reset() },
        )
    }

    // ── Context Menu ─────────────────────────────────────────
    fmState.contextMenuTarget?.let { item ->
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center,
        ) {
            FileContextMenu(
                item     = item,
                visible  = fmState.contextMenuTarget != null,
                onDismiss = { fmState.closeContextMenu() },
                fmState  = fmState,
            )
        }
    }
}

// ════════════════════════════════════════════════════════════
// END OF FILE 8 of 8 — Dialogs_Extras.kt
// ════════════════════════════════════════════════════════════
//
// ✅ ALL 8 FILES COMPLETE
//
// FILE SUMMARY:
// ┌─────────────────────────────────────────────────────────┐
// │ 1. Theme.kt          — Colors, Typography, Shapes       │
// │ 2. DesignSystem.kt   — Components, Split Screen, Glass  │
// │ 3. FileManagerState  — Models, State, Sort, Selection   │
// │ 4. MainFileScreen    — Root, TopBar, Nav, Breadcrumb    │
// │ 5. FileGridListView  — Grid, List, Compact, Recents     │
// │ 6. ActionPanels      — Context, Progress, Dialogs       │
// │ 7. SearchSortFilter  — Search, Filter, Highlight        │
// │ 8. Dialogs_Extras    — Properties, Onboarding, About    │
// └─────────────────────────────────────────────────────────┘

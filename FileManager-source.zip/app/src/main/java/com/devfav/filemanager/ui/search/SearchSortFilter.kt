@file:OptIn(
    androidx.compose.foundation.ExperimentalFoundationApi::class,
    androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.animation.ExperimentalAnimationApi::class,
    androidx.compose.ui.ExperimentalComposeUiApi::class
)

package com.devfav.filemanager.ui.search


import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.*
import androidx.compose.ui.focus.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.hapticfeedback.*
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.input.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import com.devfav.filemanager.ui.design.*
import com.devfav.filemanager.ui.state.*
import com.devfav.filemanager.ui.theme.*
import kotlinx.coroutines.*
import com.devfav.filemanager.ui.screen.FileIconWithThumbnail
import com.devfav.filemanager.ui.panels.FmTextField
import com.devfav.filemanager.ui.panels.SheetSectionLabel
import androidx.compose.ui.zIndex
import androidx.compose.ui.window.Dialog

// ════════════════════════════════════════════════════════════
// SECTION 1 — FULL SEARCH SCREEN ROOT
// ════════════════════════════════════════════════════════════

@Composable
fun SearchScreen(
    fmState: FileManagerState,
    onBack: () -> Unit,
    onFileOpen: (FileItem) -> Unit,
    modifier: Modifier = Modifier,
) {
    val searchState    = fmState.search
    val ext            = MaterialTheme.extended
    val scope          = rememberCoroutineScope()
    val focusRequester = remember { FocusRequester() }
    val haptic         = LocalHapticFeedback.current

    // Debounce search
    var searchJob by remember { mutableStateOf<Job?>(null) }

    LaunchedEffect(Unit) {
        delay(150)
        focusRequester.requestFocus()
    }

    // Handle back
    androidx.activity.compose.BackHandler {
        searchState.deactivate()
        onBack()
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(colors = ext.gradientSurface)
            ),
    ) {
        // ── Search TopBar ────────────────────────────────────
        SearchTopBar(
            searchState    = searchState,
            focusRequester = focusRequester,
            onQueryChange  = { query ->
                searchState.updateQuery(query)
                searchJob?.cancel()
                if (query.isNotBlank()) {
                    searchJob = scope.launch {
                        delay(300) // debounce 300ms
                        // trigger actual search logic here
                        // searchRepository.search(query, searchState.searchScope)
                    }
                }
            },
            onBack         = {
                searchState.deactivate()
                onBack()
            },
            fmState        = fmState,
        )

        // ── Search Options Bar ───────────────────────────────
        AnimatedVisibility(
            visible = searchState.hasQuery,
            enter   = expandVertically() + fadeIn(),
            exit    = shrinkVertically() + fadeOut(),
        ) {
            SearchOptionsBar(searchState = searchState)
        }

        // ── Content ─────────────────────────────────────────
        Box(modifier = Modifier.fillMaxSize()) {
            AnimatedContent(
                targetState   = searchState.result,
                transitionSpec = {
                    fadeIn(tween(AnimationTokens.durationMD)) togetherWith
                    fadeOut(tween(AnimationTokens.durationMD))
                },
                label = "searchContent",
                modifier = Modifier.fillMaxSize(),
            ) { result ->
                when (result) {
                    is SearchResult.Empty -> {
                        if (searchState.hasQuery) {
                            SearchEmptyResult(query = searchState.query)
                        } else {
                            SearchIdleScreen(
                                searchState = searchState,
                                onRecentClick = { query ->
                                    searchState.updateQuery(query)
                                    focusRequester.requestFocus()
                                },
                                onSuggestionClick = { query ->
                                    searchState.updateQuery(query)
                                },
                            )
                        }
                    }
                    is SearchResult.Loading -> {
                        SearchLoadingView()
                    }
                    is SearchResult.Results -> {
                        SearchResultsView(
                            results       = result,
                            searchState   = searchState,
                            selection     = fmState.activePane.selection,
                            clipboard     = fmState.clipboard,
                            isSplitMode   = fmState.splitScreen.isSplit,
                            onFileOpen    = onFileOpen,
                            onContextMenu = { fmState.openContextMenu(it) },
                        )
                    }
                    is SearchResult.Error -> {
                        SearchErrorView(
                            message = result.message,
                            onRetry = {
                                searchState.updateQuery(searchState.query)
                            },
                        )
                    }
                }
            }
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 2 — SEARCH TOP BAR
// ════════════════════════════════════════════════════════════

@Composable
fun SearchTopBar(
    searchState: SearchState,
    focusRequester: FocusRequester,
    onQueryChange: (String) -> Unit,
    onBack: () -> Unit,
    fmState: FileManagerState,
    modifier: Modifier = Modifier,
) {
    val ext         = MaterialTheme.extended
    val isListening = remember { mutableStateOf(false) }

    Surface(
        color           = ext.surfaceElevated.copy(alpha = 0.95f),
        shadowElevation = ElevationTokens.appBar,
        modifier        = modifier
            .fillMaxWidth()
            .statusBarsPadding(),
    ) {
        Column(modifier = Modifier.padding(SpacingTokens.md)) {

            Row(
                verticalAlignment     = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
                modifier              = Modifier.fillMaxWidth(),
            ) {
                // Back button
                FmIconButton(
                    icon               = Icons.Rounded.ArrowBackIosNew,
                    contentDescription = "Back",
                    onClick            = onBack,
                    tint               = ext.iconPrimary,
                )

                // Premium search field
                SearchTextField(
                    query             = searchState.query,
                    onQueryChange     = onQueryChange,
                    focusRequester    = focusRequester,
                    isVoiceListening  = isListening.value,
                    onVoiceClick      = { isListening.value = !isListening.value },
                    modifier          = Modifier.weight(1f),
                )

                // Advanced filter toggle
                Box {
                    FmIconButton(
                        icon               = Icons.Rounded.Tune,
                        contentDescription = "Advanced filters",
                        onClick            = { fmState.showFilterSheet = true },
                        tint               = if (fmState.activePane.filterConfig.hasActiveFilters)
                                                 MaterialTheme.colorScheme.primary
                                             else
                                                 ext.iconPrimary,
                        badge              = if (fmState.activePane.filterConfig.hasActiveFilters)
                                                 fmState.activePane.filterConfig.activeFilterCount
                                             else null,
                    )
                }
            }

            // Voice listening animation
            AnimatedVisibility(
                visible = isListening.value,
                enter   = expandVertically() + fadeIn(),
                exit    = shrinkVertically() + fadeOut(),
            ) {
                VoiceListeningIndicator(
                    onStop = { isListening.value = false },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = SpacingTokens.sm),
                )
            }
        }
    }
}

// ── Premium Search Text Field ───────────────────────────────
@Composable
private fun SearchTextField(
    query: String,
    onQueryChange: (String) -> Unit,
    focusRequester: FocusRequester,
    isVoiceListening: Boolean,
    onVoiceClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext            = MaterialTheme.extended
    val isFocused      = remember { mutableStateOf(false) }
    val borderColor by animateColorAsState(
        targetValue = if (isFocused.value)
            MaterialTheme.colorScheme.primary
        else
            ext.stroke,
        animationSpec = tween(AnimationTokens.durationMD),
        label = "searchBorder",
    )
    val bgColor by animateColorAsState(
        targetValue = if (isFocused.value)
            MaterialTheme.colorScheme.surfaceVariant
        else
            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
        label = "searchBg",
    )

    Surface(
        color    = bgColor,
        shape    = ShapeTokens.searchShape,
        border   = BorderStroke(1.5.dp, borderColor),
        modifier = modifier.height(SpacingTokens.searchBarHeight),
    ) {
        Row(
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
            modifier              = Modifier
                .fillMaxSize()
                .padding(horizontal = SpacingTokens.md),
        ) {
            // Search icon (animated)
            AnimatedContent(
                targetState = isVoiceListening,
                label       = "searchLeadIcon",
            ) { listening ->
                Icon(
                    imageVector = if (listening)
                        Icons.Rounded.Mic
                    else
                        Icons.Rounded.Search,
                    contentDescription = null,
                    tint               = if (isFocused.value || isVoiceListening)
                                             MaterialTheme.colorScheme.primary
                                         else
                                             ext.iconSecondary,
                    modifier           = Modifier.size(20.dp),
                )
            }

            // Actual text field
            BasicTextField(
                value         = query,
                onValueChange = onQueryChange,
                singleLine    = true,
                textStyle     = MaterialTheme.typography.bodyLarge.copy(
                    color = ext.textPrimary,
                ),
                keyboardOptions = KeyboardOptions(
                    imeAction = ImeAction.Search,
                ),
                keyboardActions = KeyboardActions(
                    onSearch = { /* trigger search */ },
                ),
                decorationBox = { inner ->
                    Box(modifier = Modifier.weight(1f)) {
                        if (query.isEmpty()) {
                            Text(
                                text  = if (isVoiceListening)
                                            "Listening..."
                                        else
                                            "Search files & folders...",
                                style = MaterialTheme.typography.bodyLarge,
                                color = ext.textTertiary,
                            )
                        }
                        inner()
                    }
                },
                modifier = Modifier
                    .weight(1f)
                    .focusRequester(focusRequester)
                    .onFocusChanged { isFocused.value = it.isFocused },
            )

            // Clear / Voice button
            AnimatedContent(
                targetState = query.isNotEmpty(),
                label       = "searchTrailAction",
            ) { hasText ->
                if (hasText) {
                    FmIconButton(
                        icon               = Icons.Rounded.Close,
                        contentDescription = "Clear",
                        onClick            = { onQueryChange("") },
                        tint               = ext.iconSecondary,
                        containerSize      = 30.dp,
                        size               = 17.dp,
                    )
                } else {
                    FmIconButton(
                        icon               = if (isVoiceListening)
                                                 Icons.Rounded.Stop
                                             else
                                                 Icons.Rounded.Mic,
                        contentDescription = "Voice search",
                        onClick            = onVoiceClick,
                        tint               = if (isVoiceListening)
                                                 MaterialTheme.colorScheme.error
                                             else
                                                 ext.iconSecondary,
                        containerSize      = 30.dp,
                        size               = 17.dp,
                    )
                }
            }
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 3 — VOICE LISTENING INDICATOR
// ════════════════════════════════════════════════════════════

@Composable
fun VoiceListeningIndicator(
    onStop: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext                = MaterialTheme.extended
    val infiniteTransition = rememberInfiniteTransition(label = "voiceAnim")

    // 3 wave bars animated
    val bar1 by infiniteTransition.animateFloat(
        initialValue  = 0.2f,
        targetValue   = 1f,
        animationSpec = infiniteRepeatable(
            animation  = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "bar1",
    )
    val bar2 by infiniteTransition.animateFloat(
        initialValue  = 0.5f,
        targetValue   = 1f,
        animationSpec = infiniteRepeatable(
            animation  = tween(500, delayMillis = 150, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "bar2",
    )
    val bar3 by infiniteTransition.animateFloat(
        initialValue  = 0.3f,
        targetValue   = 0.9f,
        animationSpec = infiniteRepeatable(
            animation  = tween(700, delayMillis = 80, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "bar3",
    )
    val bar4 by infiniteTransition.animateFloat(
        initialValue  = 0.6f,
        targetValue   = 1f,
        animationSpec = infiniteRepeatable(
            animation  = tween(450, delayMillis = 220, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "bar4",
    )
    val bar5 by infiniteTransition.animateFloat(
        initialValue  = 0.25f,
        targetValue   = 0.85f,
        animationSpec = infiniteRepeatable(
            animation  = tween(550, delayMillis = 60, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "bar5",
    )

    Surface(
        color  = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.15f),
        shape  = ShapeTokens.cardShape,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.2f)),
        modifier = modifier,
    ) {
        Row(
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier              = Modifier
                .fillMaxWidth()
                .padding(
                    horizontal = SpacingTokens.lg,
                    vertical   = SpacingTokens.md,
                ),
        ) {
            // Mic icon pulsing
            val pulseScale by infiniteTransition.animateFloat(
                initialValue  = 0.9f,
                targetValue   = 1.1f,
                animationSpec = infiniteRepeatable(
                    animation  = tween(800),
                    repeatMode = RepeatMode.Reverse,
                ),
                label = "micPulse",
            )
            Icon(
                imageVector        = Icons.Rounded.Mic,
                contentDescription = null,
                tint               = MaterialTheme.colorScheme.error,
                modifier           = Modifier
                    .size(20.dp)
                    .scale(pulseScale),
            )

            // Wave bars
            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment     = Alignment.CenterVertically,
                modifier              = Modifier.height(32.dp),
            ) {
                listOf(bar1, bar2, bar3, bar4, bar5).forEach { fraction ->
                    Box(
                        modifier = Modifier
                            .width(4.dp)
                            .fillMaxHeight(fraction)
                            .clip(RoundedCornerShape(999.dp))
                            .background(MaterialTheme.colorScheme.error),
                    )
                }
            }

            Text(
                text  = "Listening...",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.error,
            )

            FmGhostButton(
                text    = "Stop",
                onClick = onStop,
                color   = MaterialTheme.colorScheme.error,
            )
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 4 — SEARCH OPTIONS BAR
//             Scope + Type filter + Case sensitive
// ════════════════════════════════════════════════════════════

@Composable
fun SearchOptionsBar(
    searchState: SearchState,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended

    Surface(
        color    = ext.surfaceOverlay,
        modifier = modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier.padding(
                vertical = SpacingTokens.xs,
            ),
        ) {
            // Scope row
            Row(
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
                verticalAlignment     = Alignment.CenterVertically,
                modifier              = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = SpacingTokens.screenPaddingH),
            ) {
                // Scope label
                Text(
                    text  = "In:",
                    style = MaterialTheme.typography.labelSmall,
                    color = ext.textTertiary,
                )
                // Scope chips
                SearchScope.entries.forEach { scope ->
                    FmFilterChip(
                        label    = scope.displayName,
                        selected = searchState.searchScope == scope,
                        onClick  = { searchState.searchScope = scope },
                    )
                }
            }

            Spacer(Modifier.height(SpacingTokens.xs))

            // Type filter + toggles row
            Row(
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
                verticalAlignment     = Alignment.CenterVertically,
                modifier              = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = SpacingTokens.screenPaddingH),
            ) {
                // Type filter chips
                FilterType.entries.take(6).forEach { filter ->
                    FmFilterChip(
                        label    = filter.displayName,
                        selected = searchState.typeFilter == filter,
                        onClick  = { searchState.typeFilter = filter },
                    )
                }

                FmVerticalDivider(
                    modifier = Modifier
                        .height(20.dp)
                        .padding(horizontal = SpacingTokens.xs),
                )

                // Case sensitive toggle
                FmFilterChip(
                    label    = "Aa",
                    selected = searchState.isCaseSensitive,
                    onClick  = {
                        searchState.isCaseSensitive = !searchState.isCaseSensitive
                    },
                    leadingIcon = {
                        Icon(
                            imageVector        = Icons.Rounded.TextFormat,
                            contentDescription = null,
                            modifier           = Modifier.size(13.dp),
                        )
                    },
                )

                // Search in content toggle
                FmFilterChip(
                    label    = "Content",
                    selected = searchState.searchInContent,
                    onClick  = {
                        searchState.searchInContent = !searchState.searchInContent
                    },
                    leadingIcon = {
                        Icon(
                            imageVector        = Icons.Rounded.Article,
                            contentDescription = null,
                            modifier           = Modifier.size(13.dp),
                        )
                    },
                )
            }
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 5 — SEARCH IDLE SCREEN
//             Recent searches + Smart suggestions
// ════════════════════════════════════════════════════════════

@Composable
fun SearchIdleScreen(
    searchState: SearchState,
    onRecentClick: (String) -> Unit,
    onSuggestionClick: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended

    LazyColumn(
        contentPadding    = PaddingValues(
            horizontal = SpacingTokens.screenPaddingH,
            vertical   = SpacingTokens.md,
        ),
        verticalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
        modifier            = modifier.fillMaxSize(),
    ) {
        // ── Recent Searches ───────────────────────────────
        if (searchState.recentSearches.isNotEmpty()) {
            item(key = "recent_header") {
                Row(
                    verticalAlignment     = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier              = Modifier
                        .fillMaxWidth()
                        .animateItem(),
                ) {
                    Row(
                        verticalAlignment     = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
                    ) {
                        Icon(
                            imageVector        = Icons.Rounded.History,
                            contentDescription = null,
                            tint               = ext.iconSecondary,
                            modifier           = Modifier.size(16.dp),
                        )
                        Text(
                            text  = "Recent Searches",
                            style = MaterialTheme.typography.titleSmall,
                            color = ext.textPrimary,
                        )
                    }
                    FmGhostButton(
                        text    = "Clear",
                        onClick = { searchState.clearRecent() },
                        color   = ext.textTertiary,
                    )
                }
            }

            items(
                items = searchState.recentSearches,
                key   = { "recent_${it.query}" },
            ) { recent ->
                RecentSearchRow(
                    recent   = recent,
                    onClick  = { onRecentClick(recent.query) },
                    onDelete = {
                        searchState.recentSearches = searchState.recentSearches
                            .filterNot { it.query == recent.query }
                    },
                    modifier = Modifier.animateItem(),
                )
            }

            item(key = "recent_divider") {
                FmDivider(modifier = Modifier.padding(vertical = SpacingTokens.sm))
            }
        }

        // ── Smart Suggestions ─────────────────────────────
        item(key = "suggest_header") {
            Row(
                verticalAlignment     = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
                modifier              = Modifier
                    .fillMaxWidth()
                    .animateItem(),
            ) {
                Icon(
                    imageVector        = Icons.Rounded.AutoAwesome,
                    contentDescription = null,
                    tint               = MaterialTheme.colorScheme.primary,
                    modifier           = Modifier.size(16.dp),
                )
                Text(
                    text  = "Quick Search",
                    style = MaterialTheme.typography.titleSmall,
                    color = ext.textPrimary,
                )
            }
        }

        item(key = "suggestion_chips") {
            SearchSuggestionGrid(
                onSuggestionClick = onSuggestionClick,
                modifier          = Modifier.animateItem(),
            )
        }

        // ── File type quick filters ────────────────────────
        item(key = "type_header") {
            Text(
                text     = "BROWSE BY TYPE",
                style    = ExtraTypography.overline,
                color    = ext.textSecondary,
                modifier = Modifier
                    .padding(top = SpacingTokens.md)
                    .animateItem(),
            )
        }

        item(key = "type_grid") {
            SearchTypeGrid(
                onTypeSelect = { fileType ->
                    // navigate to filtered view
                },
                modifier = Modifier.animateItem(),
            )
        }
    }
}

@Composable
private fun RecentSearchRow(
    recent: RecentSearch,
    onClick: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext               = MaterialTheme.extended
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed         by interactionSource.collectIsPressedAsState()

    val bgColor by animateColorAsState(
        targetValue = if (isPressed)
            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        else
            Color.Transparent,
        label = "recentRowBg",
    )

    Row(
        verticalAlignment     = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
        modifier              = modifier
            .fillMaxWidth()
            .clip(ShapeTokens.cardShape)
            .background(bgColor)
            .clickable(
                interactionSource = interactionSource,
                indication        = ripple(
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.06f),
                ),
                onClick = onClick,
            )
            .padding(
                horizontal = SpacingTokens.md,
                vertical   = SpacingTokens.sm,
            ),
    ) {
        // History icon
        Box(
            contentAlignment = Alignment.Center,
            modifier         = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surfaceVariant),
        ) {
            Icon(
                imageVector        = Icons.Rounded.History,
                contentDescription = null,
                tint               = ext.iconSecondary,
                modifier           = Modifier.size(18.dp),
            )
        }

        // Query + result count
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text     = recent.query,
                style    = MaterialTheme.typography.bodyMedium,
                color    = ext.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (recent.resultCount > 0) {
                Text(
                    text  = "${recent.resultCount} results",
                    style = MaterialTheme.typography.labelSmall,
                    color = ext.textTertiary,
                )
            }
        }

        // Arrow + delete
        Row(horizontalArrangement = Arrangement.spacedBy(SpacingTokens.xxs)) {
            FmIconButton(
                icon               = Icons.Rounded.NorthWest,
                contentDescription = "Fill search",
                onClick            = onClick,
                tint               = ext.iconTertiary,
                containerSize      = 28.dp,
                size               = 15.dp,
            )
            FmIconButton(
                icon               = Icons.Rounded.Close,
                contentDescription = "Remove",
                onClick            = onDelete,
                tint               = ext.iconTertiary,
                containerSize      = 28.dp,
                size               = 14.dp,
            )
        }
    }
}

@Composable
private fun SearchSuggestionGrid(
    onSuggestionClick: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val suggestions = listOf(
        "*.pdf"        to Icons.Rounded.PictureAsPdf,
        "*.jpg"        to Icons.Rounded.Image,
        "*.mp4"        to Icons.Rounded.VideoLibrary,
        "*.apk"        to Icons.Rounded.Android,
        "*.zip"        to Icons.Rounded.FolderZip,
        "Screenshots"  to Icons.Rounded.Screenshot,
        "Downloads"    to Icons.Rounded.Download,
        "WhatsApp"     to Icons.Rounded.Chat,
        "large files"  to Icons.Rounded.DataUsage,
        "today"        to Icons.Rounded.Today,
    )

    androidx.compose.foundation.lazy.grid.LazyVerticalGrid(
        columns             = GridCells.Fixed(2),
        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
        verticalArrangement   = Arrangement.spacedBy(SpacingTokens.sm),
        userScrollEnabled     = false,
        modifier              = modifier.wrapContentHeight(),
    ) {
        items(suggestions, key = { it.first }) { (label, icon) ->
            SearchSuggestionChip(
                label   = label,
                icon    = icon,
                onClick = { onSuggestionClick(label) },
            )
        }
    }
}

@Composable
private fun SearchSuggestionChip(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
) {
    val ext               = MaterialTheme.extended
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed         by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue   = if (isPressed) 0.96f else 1f,
        animationSpec = spring(stiffness = AnimationTokens.springStiff),
        label         = "suggestionScale",
    )

    Surface(
        color    = MaterialTheme.colorScheme.surfaceVariant,
        shape    = ShapeTokens.cardShape,
        border   = BorderStroke(0.5.dp, ext.stroke),
        modifier = Modifier
            .scale(scale)
            .fillMaxWidth()
            .clickable(
                interactionSource = interactionSource,
                indication        = ripple(
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                ),
                onClick = onClick,
            ),
    ) {
        Row(
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
            modifier              = Modifier.padding(SpacingTokens.md),
        ) {
            Icon(
                imageVector        = icon,
                contentDescription = null,
                tint               = MaterialTheme.colorScheme.primary,
                modifier           = Modifier.size(16.dp),
            )
            Text(
                text     = label,
                style    = MaterialTheme.typography.labelMedium,
                color    = ext.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun SearchTypeGrid(
    onTypeSelect: (FileType) -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended
    val types = listOf(
        Triple(FileType.IMAGE,    "Images",    ext.imageColor),
        Triple(FileType.VIDEO,    "Videos",    ext.videoColor),
        Triple(FileType.AUDIO,    "Audio",     ext.audioColor),
        Triple(FileType.DOCUMENT, "Documents", ext.documentColor),
        Triple(FileType.ARCHIVE,  "Archives",  ext.archiveColor),
        Triple(FileType.APK,      "APKs",      ext.apkColor),
        Triple(FileType.CODE,     "Code",      ext.codeColor),
        Triple(FileType.EBOOK,    "eBooks",    ext.unknownColor),
    )

    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
        modifier              = modifier.fillMaxWidth(),
    ) {
        items(types, key = { it.first.name }) { (type, label, color) ->
            FileTypePill(
                label   = label,
                color   = color,
                onClick = { onTypeSelect(type) },
            )
        }
    }
}

@Composable
private fun FileTypePill(
    label: String,
    color: Color,
    onClick: () -> Unit,
) {
    Surface(
        onClick = onClick,
        color   = color.copy(alpha = 0.12f),
        shape   = ShapeTokens.chipShape,
        border  = BorderStroke(1.dp, color.copy(alpha = 0.3f)),
    ) {
        Row(
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(SpacingTokens.xs),
            modifier              = Modifier.padding(
                horizontal = SpacingTokens.md,
                vertical   = SpacingTokens.sm,
            ),
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(color),
            )
            Text(
                text  = label,
                style = MaterialTheme.typography.labelMedium,
                color = color,
            )
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 6 — SEARCH RESULTS VIEW
// ════════════════════════════════════════════════════════════

@Composable
fun SearchResultsView(
    results: SearchResult.Results,
    searchState: SearchState,
    selection: SelectionState,
    clipboard: ClipboardState,
    isSplitMode: Boolean,
    onFileOpen: (FileItem) -> Unit,
    onContextMenu: (FileItem) -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended

    Column(modifier = modifier.fillMaxSize()) {

        // ── Results analytics bar ────────────────────────────
        SearchAnalyticsBar(
            results = results,
            modifier = Modifier.fillMaxWidth(),
        )

        // ── Results list ────────────────────────────────────
        LazyColumn(
            contentPadding    = PaddingValues(
                top    = SpacingTokens.xs,
                bottom = SpacingTokens.giant + SpacingTokens.xxl,
            ),
            modifier          = Modifier.fillMaxSize(),
        ) {
            items(
                items = results.items,
                key   = { "result_${it.id}" },
            ) { item ->
                SearchResultItem(
                    item          = item,
                    query         = results.query,
                    isSelected    = selection.isSelected(item.id),
                    isSelectionMode = selection.isSelectionMode,
                    isCut         = clipboard.isCut &&
                                    clipboard.items.any { it.id == item.id },
                    isSplitMode   = isSplitMode,
                    onClick       = {
                        when {
                            selection.isSelectionMode ->
                                selection.toggleSelection(item.id)
                            item.isDirectory          ->
                                { /* navigate to folder */ }
                            else                      -> onFileOpen(item)
                        }
                    },
                    onLongClick   = {
                        if (!selection.isSelectionMode)
                            selection.enterSelectionMode(item.id)
                    },
                    onContextMenu = { onContextMenu(item) },
                    modifier      = Modifier.animateItem(),
                )
            }
        }
    }
}

// ── Search Analytics Bar ────────────────────────────────────
@Composable
private fun SearchAnalyticsBar(
    results: SearchResult.Results,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended

    Surface(
        color    = ext.surfaceOverlay,
        modifier = modifier,
    ) {
        Row(
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier              = Modifier
                .fillMaxWidth()
                .padding(
                    horizontal = SpacingTokens.screenPaddingH,
                    vertical   = SpacingTokens.sm,
                ),
        ) {
            // Result count with highlight
            Row(
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.xs),
                verticalAlignment     = Alignment.CenterVertically,
            ) {
                Text(
                    text  = "${results.totalCount}",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary,
                )
                Text(
                    text  = "result${if (results.totalCount != 1) "s" else ""} for",
                    style = MaterialTheme.typography.bodySmall,
                    color = ext.textSecondary,
                )
                Text(
                    text  = "\"${results.query}\"",
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontWeight = FontWeight.SemiBold,
                    ),
                    color = ext.textPrimary,
                )
            }

            // Search duration + scope
            Row(
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.xs),
                verticalAlignment     = Alignment.CenterVertically,
            ) {
                Icon(
                    imageVector        = Icons.Rounded.Timer,
                    contentDescription = null,
                    tint               = ext.iconTertiary,
                    modifier           = Modifier.size(11.dp),
                )
                Text(
                    text  = "${results.durationMs}ms",
                    style = MaterialTheme.typography.labelSmall,
                    color = ext.textTertiary,
                )
            }
        }
    }
}

// ── Single Search Result Item ───────────────────────────────
@Composable
fun SearchResultItem(
    item: FileItem,
    query: String,
    isSelected: Boolean,
    isSelectionMode: Boolean,
    isCut: Boolean,
    isSplitMode: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onContextMenu: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext               = MaterialTheme.extended
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed         by interactionSource.collectIsPressedAsState()

    val bgColor by animateColorAsState(
        targetValue = when {
            isSelected -> ext.selectionBackground
            isPressed  -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
            else       -> Color.Transparent
        },
        label = "resultBg",
    )

    Row(
        verticalAlignment     = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
        modifier              = modifier
            .fillMaxWidth()
            .background(bgColor)
            .combinedClickable(
                interactionSource = interactionSource,
                indication        = ripple(
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.06f),
                ),
                onClick           = onClick,
                onLongClick       = onLongClick,
            )
            .padding(
                horizontal = SpacingTokens.screenPaddingH,
                vertical   = SpacingTokens.md,
            ),
    ) {
        // Checkbox
        AnimatedVisibility(
            visible = isSelectionMode,
            enter   = expandHorizontally() + fadeIn(),
            exit    = shrinkHorizontally() + fadeOut(),
        ) {
            FmCheckbox(
                checked         = isSelected,
                onCheckedChange = { onClick() },
            )
        }

        // File icon
        FileIconWithThumbnail(
            item      = item,
            size      = 44.dp,
            showBadge = !item.isDirectory,
        )

        // Name + path with highlight
        Column(
            verticalArrangement = Arrangement.spacedBy(2.dp),
            modifier            = Modifier.weight(1f),
        ) {
            // Highlighted name
            HighlightedText(
                text      = item.name,
                query     = query,
                baseStyle = MaterialTheme.typography.bodyMedium,
                baseColor = ext.textPrimary,
            )

            // Parent path
            Row(
                verticalAlignment     = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                Icon(
                    imageVector        = Icons.Rounded.Folder,
                    contentDescription = null,
                    tint               = ext.iconTertiary,
                    modifier           = Modifier.size(11.dp),
                )
                Text(
                    text     = item.parentPath
                        .replace("/storage/emulated/0", "Internal"),
                    style    = MaterialTheme.typography.labelSmall,
                    color    = ext.textTertiary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }

            // Meta row
            Row(
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
                verticalAlignment     = Alignment.CenterVertically,
            ) {
                Text(
                    text  = item.displaySize,
                    style = ExtraTypography.sizeLabel,
                    color = ext.textSecondary,
                )
                Box(
                    modifier = Modifier
                        .size(3.dp)
                        .clip(CircleShape)
                        .background(ext.textTertiary),
                )
                Text(
                    text  = item.displayDate,
                    style = MaterialTheme.typography.labelSmall,
                    color = ext.textTertiary,
                )
            }
        }

        // Context menu
        if (!isSelectionMode) {
            FmIconButton(
                icon               = Icons.Rounded.MoreVert,
                contentDescription = "More",
                onClick            = onContextMenu,
                tint               = ext.iconTertiary,
                containerSize      = 28.dp,
                size               = 16.dp,
            )
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 7 — HIGHLIGHTED TEXT (query match highlight)
// ════════════════════════════════════════════════════════════

@Composable
fun HighlightedText(
    text: String,
    query: String,
    baseStyle: TextStyle,
    baseColor: Color,
    highlightColor: Color = MaterialTheme.colorScheme.primary,
    modifier: Modifier = Modifier,
) {
    if (query.isBlank()) {
        Text(
            text     = text,
            style    = baseStyle,
            color    = baseColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = modifier,
        )
        return
    }

    val annotatedString = buildAnnotatedString {
        val lowerText  = text.lowercase()
        val lowerQuery = query.lowercase()
        var startIdx   = 0

        while (startIdx < text.length) {
            val matchIdx = lowerText.indexOf(lowerQuery, startIdx)
            if (matchIdx < 0) {
                // Rest of string — normal
                withStyle(SpanStyle(color = baseColor)) {
                    append(text.substring(startIdx))
                }
                break
            }
            // Before match — normal
            if (matchIdx > startIdx) {
                withStyle(SpanStyle(color = baseColor)) {
                    append(text.substring(startIdx, matchIdx))
                }
            }
            // Match — highlighted
            withStyle(
                SpanStyle(
                    color      = highlightColor,
                    fontWeight = FontWeight.Bold,
                    background = highlightColor.copy(alpha = 0.12f),
                )
            ) {
                append(text.substring(matchIdx, matchIdx + query.length))
            }
            startIdx = matchIdx + query.length
        }
    }

    Text(
        text     = annotatedString,
        style    = baseStyle,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = modifier,
    )
}

// ════════════════════════════════════════════════════════════
// SECTION 8 — ADVANCED FILTER BOTTOM SHEET
// ════════════════════════════════════════════════════════════

@Composable
fun FilterBottomSheet(
    visible: Boolean,
    current: FilterConfig,
    onDismiss: () -> Unit,
    onApply: (FilterConfig) -> Unit,
    modifier: Modifier = Modifier,
) {
    var config by remember(current) { mutableStateOf(current) }
    val ext    = MaterialTheme.extended

    FmBottomSheet(
        visible   = visible,
        onDismiss = onDismiss,
        title     = "Advanced Filters",
        subtitle  = if (config.hasActiveFilters)
                        "${config.activeFilterCount} filters active"
                    else
                        "Refine your file view",
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = SpacingTokens.screenPaddingH),
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.lg),
        ) {
            // ── File Type ────────────────────────────────────
            SheetSectionLabel(text = "File Type")
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
            ) {
                items(FilterType.entries, key = { it.name }) { filter ->
                    FmFilterChip(
                        label    = filter.displayName,
                        selected = config.activeFilter == filter,
                        onClick  = { config = config.copy(activeFilter = filter) },
                    )
                }
            }

            FmDivider()

            // ── Size Range ───────────────────────────────────
            SheetSectionLabel(text = "File Size")
            SizeRangePicker(
                currentRange = config.sizeRange,
                onChange     = { config = config.copy(sizeRange = it) },
            )

            FmDivider()

            // ── Date Range ───────────────────────────────────
            SheetSectionLabel(text = "Date Modified")
            DateRangePicker(
                currentRange = config.dateRange,
                onChange     = { config = config.copy(dateRange = it) },
            )

            FmDivider()

            // ── Special Filters ──────────────────────────────
            SheetSectionLabel(text = "Special")
            Column(
                verticalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
            ) {
                FilterToggleRow(
                    label    = "Favorites only",
                    icon     = Icons.Rounded.Star,
                    iconTint = RawColors.Amber400,
                    checked  = config.showOnlyFavorites,
                    onChange = { config = config.copy(showOnlyFavorites = it) },
                )
                FilterToggleRow(
                    label    = "Read-only files",
                    icon     = Icons.Rounded.Lock,
                    iconTint = ext.iconSecondary,
                    checked  = config.showOnlyReadOnly,
                    onChange = { config = config.copy(showOnlyReadOnly = it) },
                )
            }

            FmDivider()

            // ── Action buttons ───────────────────────────────
            Row(
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
                modifier              = Modifier
                    .fillMaxWidth()
                    .padding(
                        top    = SpacingTokens.sm,
                        bottom = SpacingTokens.xl,
                    ),
            ) {
                // Reset button
                FmSecondaryButton(
                    text     = "Reset All",
                    onClick  = { config = FilterConfig() },
                    modifier = Modifier.weight(1f),
                    leadingIcon = {
                        Icon(
                            imageVector        = Icons.Rounded.RestartAlt,
                            contentDescription = null,
                            tint               = MaterialTheme.colorScheme.primary,
                            modifier           = Modifier.size(16.dp),
                        )
                    },
                )
                // Apply button
                FmPrimaryButton(
                    text     = "Apply",
                    onClick  = {
                        onApply(config)
                        onDismiss()
                    },
                    modifier = Modifier.weight(1f),
                    leadingIcon = {
                        Icon(
                            imageVector        = Icons.Rounded.FilterList,
                            contentDescription = null,
                            tint               = RawColors.White,
                            modifier           = Modifier.size(16.dp),
                        )
                    },
                )
            }
        }
    }
}

@Composable
private fun FilterToggleRow(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconTint: Color,
    checked: Boolean,
    onChange: (Boolean) -> Unit,
) {
    val ext = MaterialTheme.extended
    Surface(
        color  = MaterialTheme.colorScheme.surfaceVariant,
        shape  = ShapeTokens.cardShape,
    ) {
        Row(
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier              = Modifier
                .fillMaxWidth()
                .padding(SpacingTokens.md),
        ) {
            Row(
                verticalAlignment     = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
            ) {
                Icon(
                    imageVector        = icon,
                    contentDescription = null,
                    tint               = iconTint,
                    modifier           = Modifier.size(18.dp),
                )
                Text(
                    text  = label,
                    style = MaterialTheme.typography.bodyMedium,
                    color = ext.textPrimary,
                )
            }
            Switch(
                checked         = checked,
                onCheckedChange = onChange,
                colors          = SwitchDefaults.colors(
                    checkedTrackColor = MaterialTheme.colorScheme.primary,
                ),
            )
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 9 — SIZE RANGE PICKER
// ════════════════════════════════════════════════════════════

@Composable
fun SizeRangePicker(
    currentRange: LongRange?,
    onChange: (LongRange?) -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended

    // Predefined size ranges
    val presets = listOf(
        "Any"      to null,
        "< 1 MB"   to (0L..1_048_576L),
        "1–10 MB"  to (1_048_576L..10_485_760L),
        "10–100 MB" to (10_485_760L..104_857_600L),
        "> 100 MB" to (104_857_600L..Long.MAX_VALUE),
    )

    Column(
        modifier            = modifier,
        verticalArrangement = Arrangement.spacedBy(SpacingTokens.md),
    ) {
        // Preset chips
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
        ) {
            items(presets, key = { it.first }) { (label, range) ->
                FmFilterChip(
                    label    = label,
                    selected = currentRange == range,
                    onClick  = { onChange(range) },
                )
            }
        }

        // Custom range indicator
        if (currentRange != null && presets.none { it.second == currentRange }) {
            Surface(
                color  = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f),
                shape  = ShapeTokens.cardShape,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)),
            ) {
                Row(
                    verticalAlignment     = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier              = Modifier
                        .fillMaxWidth()
                        .padding(SpacingTokens.md),
                ) {
                    Text(
                        text  = "${FileItem.formatSize(currentRange.first)} " +
                                "– ${FileItem.formatSize(currentRange.last)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                    )
                    FmIconButton(
                        icon               = Icons.Rounded.Close,
                        contentDescription = "Clear size filter",
                        onClick            = { onChange(null) },
                        tint               = MaterialTheme.colorScheme.primary,
                        containerSize      = 24.dp,
                        size               = 14.dp,
                    )
                }
            }
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 10 — DATE RANGE PICKER
// ════════════════════════════════════════════════════════════

@Composable
fun DateRangePicker(
    currentRange: LongRange?,
    onChange: (LongRange?) -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext  = MaterialTheme.extended
    val now  = System.currentTimeMillis()
    val day  = 86_400_000L

    val presets = listOf(
        "Any"         to null,
        "Today"       to ((now - day)..now),
        "Last 7 days" to ((now - 7 * day)..now),
        "Last 30 days" to ((now - 30 * day)..now),
        "Last year"   to ((now - 365 * day)..now),
    )

    Column(
        modifier            = modifier,
        verticalArrangement = Arrangement.spacedBy(SpacingTokens.md),
    ) {
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
        ) {
            items(presets, key = { it.first }) { (label, range) ->
                FmFilterChip(
                    label    = label,
                    selected = currentRange == range,
                    onClick  = { onChange(range) },
                )
            }
        }

        // Active range display
        AnimatedVisibility(visible = currentRange != null) {
            currentRange?.let { range ->
                Surface(
                    color  = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.3f),
                    shape  = ShapeTokens.cardShape,
                    border = BorderStroke(
                        1.dp,
                        MaterialTheme.colorScheme.tertiary.copy(alpha = 0.2f),
                    ),
                ) {
                    Row(
                        verticalAlignment     = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
                        modifier              = Modifier
                            .fillMaxWidth()
                            .padding(SpacingTokens.md),
                    ) {
                        Icon(
                            imageVector        = Icons.Rounded.DateRange,
                            contentDescription = null,
                            tint               = MaterialTheme.colorScheme.tertiary,
                            modifier           = Modifier.size(16.dp),
                        )
                        Text(
                            text  = "${FileItem.formatDateShort(range.first)} " +
                                    "→ ${FileItem.formatDateShort(range.last)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.tertiary,
                            modifier = Modifier.weight(1f),
                        )
                        FmIconButton(
                            icon               = Icons.Rounded.Close,
                            contentDescription = "Clear date filter",
                            onClick            = { onChange(null) },
                            tint               = MaterialTheme.colorScheme.tertiary,
                            containerSize      = 24.dp,
                            size               = 14.dp,
                        )
                    }
                }
            }
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 11 — SEARCH EMPTY / ERROR / LOADING STATES
// ════════════════════════════════════════════════════════════

@Composable
fun SearchEmptyResult(
    query: String,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended
    val infiniteTransition = rememberInfiniteTransition(label = "emptySearch")
    val floatY by infiniteTransition.animateFloat(
        initialValue  = 0f,
        targetValue   = -12f,
        animationSpec = infiniteRepeatable(
            animation  = tween(1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "emptyFloat",
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier            = modifier
            .fillMaxSize()
            .padding(SpacingTokens.xxxl),
    ) {
        // Floating search icon
        Box(
            contentAlignment = Alignment.Center,
            modifier         = Modifier
                .size(96.dp)
                .offset(y = floatY.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(96.dp)
                    .clip(CircleShape)
                    .background(
                        MaterialTheme.colorScheme.surfaceVariant
                    ),
            )
            Icon(
                imageVector        = Icons.Rounded.SearchOff,
                contentDescription = null,
                tint               = ext.iconSecondary,
                modifier           = Modifier.size(44.dp),
            )
        }

        Spacer(Modifier.height(SpacingTokens.xxl))

        Text(
            text      = "No results found",
            style     = MaterialTheme.typography.titleMedium,
            color     = ext.textPrimary,
            textAlign = TextAlign.Center,
        )

        Spacer(Modifier.height(SpacingTokens.sm))

        // Highlighted query in message
        Text(
            text      = buildAnnotatedString {
                append("No files matching ")
                withStyle(
                    SpanStyle(
                        color      = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold,
                    )
                ) { append("\"$query\"") }
                append(" were found")
            },
            style     = MaterialTheme.typography.bodyMedium,
            color     = ext.textSecondary,
            textAlign = TextAlign.Center,
        )

        Spacer(Modifier.height(SpacingTokens.xxl))

        // Suggestions
        Surface(
            color  = MaterialTheme.colorScheme.surfaceVariant,
            shape  = ShapeTokens.cardShape,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(
                modifier = Modifier.padding(SpacingTokens.lg),
                verticalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
            ) {
                Text(
                    text  = "Try:",
                    style = MaterialTheme.typography.labelMedium,
                    color = ext.textSecondary,
                )
                listOf(
                    "Check the spelling",
                    "Use fewer or different keywords",
                    "Try searching in All Storage",
                    "Enable 'Show hidden files'",
                ).forEach { tip ->
                    Row(
                        verticalAlignment     = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
                    ) {
                        Box(
                            modifier = Modifier
                                .size(5.dp)
                                .clip(CircleShape)
                                .background(ext.textTertiary),
                        )
                        Text(
                            text  = tip,
                            style = MaterialTheme.typography.bodySmall,
                            color = ext.textSecondary,
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SearchLoadingView(modifier: Modifier = Modifier) {
    LazyColumn(
        contentPadding    = PaddingValues(
            horizontal = SpacingTokens.screenPaddingH,
            vertical   = SpacingTokens.sm,
        ),
        verticalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
        modifier            = modifier.fillMaxSize(),
        userScrollEnabled   = false,
    ) {
        // Searching... header shimmer
        item {
            ShimmerBox(
                modifier = Modifier
                    .fillMaxWidth(0.5f)
                    .height(14.dp),
            )
        }
        items(8) {
            SearchResultShimmerItem()
        }
    }
}

@Composable
private fun SearchResultShimmerItem() {
    Row(
        verticalAlignment     = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
        modifier              = Modifier
            .fillMaxWidth()
            .padding(vertical = SpacingTokens.sm),
    ) {
        ShimmerBox(
            modifier = Modifier.size(44.dp),
            shape    = RoundedCornerShape(ShapeTokens.radiusMD),
        )
        Column(
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.xs),
            modifier            = Modifier.weight(1f),
        ) {
            ShimmerBox(modifier = Modifier.fillMaxWidth(0.7f).height(14.dp))
            ShimmerBox(modifier = Modifier.fillMaxWidth(0.5f).height(11.dp))
            ShimmerBox(modifier = Modifier.fillMaxWidth(0.3f).height(10.dp))
        }
    }
}

@Composable
fun SearchErrorView(
    message: String,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier,
) {
    EmptyStateView(
        title    = "Search failed",
        subtitle = message,
        icon     = Icons.Rounded.ErrorOutline,
        action   = "Try Again" to onRetry,
        modifier = modifier,
    )
}

// ════════════════════════════════════════════════════════════
// SECTION 12 — SPLIT PANE SEARCH SYNC INDICATOR
// ════════════════════════════════════════════════════════════

@Composable
fun SplitSearchSyncBanner(
    isSplit: Boolean,
    query: String,
    onSyncToOtherPane: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val ext = MaterialTheme.extended

    AnimatedVisibility(
        visible  = isSplit && query.isNotEmpty(),
        enter    = expandVertically() + fadeIn(),
        exit     = shrinkVertically() + fadeOut(),
        modifier = modifier,
    ) {
        Surface(
            color  = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f),
            border = BorderStroke(
                0.5.dp,
                MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
            ),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Row(
                verticalAlignment     = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier              = Modifier
                    .fillMaxWidth()
                    .padding(
                        horizontal = SpacingTokens.screenPaddingH,
                        vertical   = SpacingTokens.sm,
                    ),
            ) {
                Row(
                    verticalAlignment     = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
                ) {
                    Icon(
                        imageVector        = Icons.Rounded.VerticalSplit,
                        contentDescription = null,
                        tint               = MaterialTheme.colorScheme.primary,
                        modifier           = Modifier.size(14.dp),
                    )
                    Text(
                        text  = "Split mode active",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
                FmActionChip(
                    label   = "Search in other pane",
                    icon    = Icons.Rounded.OpenInNew,
                    onClick = onSyncToOtherPane,
                    color   = MaterialTheme.colorScheme.primary,
                )
            }
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 13 — FILE NAME INPUT DIALOG
//             (path navigation / goto path)
// ════════════════════════════════════════════════════════════

@Composable
fun GoToPathDialog(
    visible: Boolean,
    currentPath: String,
    onNavigate: (String) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
) {
    if (!visible) return
    val ext            = MaterialTheme.extended
    var pathText       by remember { mutableStateOf(currentPath) }
    val focusRequester = remember { FocusRequester() }

    LaunchedEffect(visible) {
        if (visible) {
            delay(150)
            focusRequester.requestFocus()
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape           = ShapeTokens.dialogShape,
            color           = ext.surfaceDialog,
            shadowElevation = ElevationTokens.dialog,
            modifier        = modifier.fillMaxWidth(),
        ) {
            Column(
                modifier = Modifier.padding(SpacingTokens.xxl),
                verticalArrangement = Arrangement.spacedBy(SpacingTokens.lg),
            ) {
                // Header
                Row(
                    verticalAlignment     = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
                ) {
                    Icon(
                        imageVector        = Icons.Rounded.FolderOpen,
                        contentDescription = null,
                        tint               = MaterialTheme.colorScheme.primary,
                        modifier           = Modifier.size(24.dp),
                    )
                    Text(
                        text  = "Go to Path",
                        style = MaterialTheme.typography.titleMedium,
                        color = ext.textPrimary,
                    )
                }

                // Path input
                FmTextField(
                    value          = pathText,
                    onValueChange  = { pathText = it },
                    label          = "Path",
                    placeholder    = "/storage/emulated/0/...",
                    focusRequester = focusRequester,
                    keyboardAction = ImeAction.Go,
                    onKeyboardDone = {
                        if (pathText.isNotBlank()) {
                            onNavigate(pathText.trim())
                            onDismiss()
                        }
                    },
                    leadingIcon = {
                        Icon(
                            imageVector        = Icons.Rounded.Route,
                            contentDescription = null,
                            tint               = ext.iconSecondary,
                            modifier           = Modifier.size(18.dp),
                        )
                    },
                )

                // Quick shortcuts
                Column(
                    verticalArrangement = Arrangement.spacedBy(SpacingTokens.xs),
                ) {
                    Text(
                        text  = "Quick paths",
                        style = MaterialTheme.typography.labelSmall,
                        color = ext.textTertiary,
                    )
                    listOf(
                        "Internal Storage" to "/storage/emulated/0",
                        "Downloads"        to "/storage/emulated/0/Download",
                        "DCIM"             to "/storage/emulated/0/DCIM",
                        "Android/Data"     to "/storage/emulated/0/Android/data",
                    ).forEach { (label, path) ->
                        Row(
                            verticalAlignment     = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(SpacingTokens.sm),
                            modifier              = Modifier
                                .fillMaxWidth()
                                .clip(ShapeTokens.cardShape)
                                .clickable {
                                    pathText = path
                                }
                                .padding(SpacingTokens.sm),
                        ) {
                            Icon(
                                imageVector        = Icons.Rounded.Shortcut,
                                contentDescription = null,
                                tint               = ext.iconTertiary,
                                modifier           = Modifier.size(14.dp),
                            )
                            Column {
                                Text(
                                    text  = label,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = ext.textPrimary,
                                )
                                Text(
                                    text  = path,
                                    style = ExtraTypography.pathStyle,
                                    color = ext.textTertiary,
                                )
                            }
                        }
                    }
                }

                // Buttons
                Row(
                    horizontalArrangement = Arrangement.spacedBy(SpacingTokens.md),
                    modifier              = Modifier.fillMaxWidth(),
                ) {
                    FmSecondaryButton(
                        text     = "Cancel",
                        onClick  = onDismiss,
                        modifier = Modifier.weight(1f),
                    )
                    FmPrimaryButton(
                        text     = "Go",
                        onClick  = {
                            if (pathText.isNotBlank()) {
                                onNavigate(pathText.trim())
                                onDismiss()
                            }
                        },
                        enabled  = pathText.isNotBlank(),
                        modifier = Modifier.weight(1f),
                        leadingIcon = {
                            Icon(
                                imageVector        = Icons.Rounded.ArrowForward,
                                contentDescription = null,
                                tint               = RawColors.White,
                                modifier           = Modifier.size(16.dp),
                            )
                        },
                    )
                }
            }
        }
    }
}

// ════════════════════════════════════════════════════════════
// END OF FILE 7 — SearchSortFilter.kt
// Next → File 8: Dialogs_Extras.kt
// (PropertiesSheet, StorageAnalyzerSheet,
//  CreateFileDialog, PermissionsRationale,
//  ThemePickerSheet, AboutSheet,
//  OnboardingScreen, TagManagerSheet,
//  BookmarkManager, AppIntroSlider)
// ════════════════════════════════════════════════════════════

@file:OptIn(
    androidx.compose.foundation.ExperimentalFoundationApi::class,
    androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.animation.ExperimentalAnimationApi::class,
    androidx.compose.ui.ExperimentalComposeUiApi::class
)

package com.devfav.filemanager.ui.state

import androidx.compose.runtime.*
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import com.devfav.filemanager.ui.design.*
import com.devfav.filemanager.ui.theme.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.*


/**
 * Drop-in replacement for `mutableStateSetOf<T>()` which was removed in
 * Compose Runtime 1.7+. Backed by [mutableStateListOf] — exposes the
 * observable [Set] semantics used throughout the state holders.
 */
class SnapshotStateSet<T> : Set<T> {
    private val backing = mutableStateListOf<T>()

    override val size: Int get() = backing.size

    override fun contains(element: T): Boolean = backing.contains(element)
    override fun containsAll(elements: Collection<T>): Boolean = elements.all { it in backing }
    override fun isEmpty(): Boolean = backing.isEmpty()
    override fun iterator(): Iterator<T> = backing.iterator()

    fun add(element: T): Boolean {
        if (backing.contains(element)) return false
        backing.add(element)
        return true
    }

    fun addAll(elements: Collection<T>): Boolean {
        var changed = false
        for (e in elements) if (add(e)) changed = true
        return changed
    }

    fun remove(element: T): Boolean = backing.remove(element)
    fun clear() = backing.clear()
    fun isNotEmpty(): Boolean = backing.isNotEmpty()
}

fun <T> mutableStateSetOf(): SnapshotStateSet<T> = SnapshotStateSet()


// ════════════════════════════════════════════════════════════
// SECTION 1 — FILE ITEM MODEL
//             Core data class for every file/folder
// ════════════════════════════════════════════════════════════

@Stable
data class FileItem(
    val id: String,                          // Unique ID (path-based hash)
    val name: String,                        // Display name
    val path: String,                        // Absolute path
    val parentPath: String,                  // Parent directory path
    val isDirectory: Boolean,                // true = folder
    val size: Long,                          // Bytes (0 for folders)
    val lastModified: Long,                  // Unix timestamp
    val extension: String,                   // "jpg", "pdf", etc. ("" for folders)
    val mimeType: String,                    // MIME type
    val isHidden: Boolean,                   // starts with "."
    val isReadOnly: Boolean,                 // write permission
    val isSymlink: Boolean = false,          // symbolic link
    val childCount: Int = 0,                 // folder item count
    val thumbnailPath: String? = null,       // cached thumb path
    val isFavorite: Boolean = false,         // user starred
    val tags: List<String> = emptyList(),    // user tags
) {
    // ── Derived properties ─────────────────────────────────

    val displaySize: String
        get() = if (isDirectory) {
            when {
                childCount == 0    -> "Empty"
                childCount == 1    -> "1 item"
                else               -> "$childCount items"
            }
        } else {
            formatSize(size)
        }

    val displayDate: String
        get() = formatDate(lastModified)

    val displayDateShort: String
        get() = formatDateShort(lastModified)

    val fileType: FileType
        get() = when {
            isDirectory -> FileType.FOLDER
            else        -> FileType.fromExtension(extension)
        }

    val iconType: FileIconType
        get() = when {
            isDirectory -> FileIconType.Folder
            else        -> FileIconType.File(extension)
        }

    val isMedia: Boolean
        get() = fileType in listOf(
            FileType.IMAGE, FileType.VIDEO, FileType.AUDIO
        )

    val isArchive: Boolean
        get() = fileType == FileType.ARCHIVE

    val sortKey: String
        get() = name.lowercase(Locale.getDefault())

    // ── Static helpers ─────────────────────────────────────
    companion object {

        fun formatSize(bytes: Long): String {
            if (bytes <= 0) return "0 B"
            val units = arrayOf("B", "KB", "MB", "GB", "TB")
            val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
            val fmt = DecimalFormat("#,##0.#")
            return "${fmt.format(bytes / Math.pow(1024.0, digitGroups.toDouble()))} ${units[digitGroups]}"
        }

        fun formatDate(timestamp: Long): String {
            val now = System.currentTimeMillis()
            val diff = now - timestamp
            return when {
                diff < 60_000L          -> "Just now"
                diff < 3_600_000L       -> "${diff / 60_000} min ago"
                diff < 86_400_000L      -> "${diff / 3_600_000} hr ago"
                diff < 172_800_000L     -> "Yesterday"
                diff < 604_800_000L     -> "${diff / 86_400_000} days ago"
                else -> SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
                    .format(Date(timestamp))
            }
        }

        fun formatDateShort(timestamp: Long): String =
            SimpleDateFormat("MMM dd", Locale.getDefault())
                .format(Date(timestamp))

        // Create dummy/placeholder item
        fun placeholder(id: Int = 0) = FileItem(
            id           = "placeholder_$id",
            name         = "",
            path         = "",
            parentPath   = "",
            isDirectory  = false,
            size         = 0L,
            lastModified = 0L,
            extension    = "",
            mimeType     = "",
            isHidden     = false,
            isReadOnly   = false,
        )
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 2 — FILE TYPE ENUM
// ════════════════════════════════════════════════════════════

enum class FileType(
    val displayName: String,
    val extensions: Set<String>,
    val mimePattern: String,
) {
    FOLDER(
        displayName  = "Folder",
        extensions   = emptySet(),
        mimePattern  = "inode/directory",
    ),
    IMAGE(
        displayName  = "Image",
        extensions   = setOf("jpg","jpeg","png","gif","bmp","webp","svg","heic","tiff","raw"),
        mimePattern  = "image/*",
    ),
    VIDEO(
        displayName  = "Video",
        extensions   = setOf("mp4","mkv","avi","mov","webm","flv","3gp","ts","m4v"),
        mimePattern  = "video/*",
    ),
    AUDIO(
        displayName  = "Audio",
        extensions   = setOf("mp3","wav","flac","aac","ogg","m4a","wma","opus","aiff"),
        mimePattern  = "audio/*",
    ),
    DOCUMENT(
        displayName  = "Document",
        extensions   = setOf("pdf","doc","docx","xls","xlsx","ppt","pptx","txt","rtf","odt","csv"),
        mimePattern  = "application/pdf",
    ),
    ARCHIVE(
        displayName  = "Archive",
        extensions   = setOf("zip","rar","7z","tar","gz","bz2","xz","tar.gz","tar.bz2"),
        mimePattern  = "application/zip",
    ),
    APK(
        displayName  = "APK",
        extensions   = setOf("apk","xapk","aab","apks"),
        mimePattern  = "application/vnd.android.package-archive",
    ),
    CODE(
        displayName  = "Code",
        extensions   = setOf("kt","java","py","js","ts","html","css","xml","json","yaml","toml","sh","c","cpp","h"),
        mimePattern  = "text/plain",
    ),
    EBOOK(
        displayName  = "eBook",
        extensions   = setOf("epub","mobi","fb2","djvu","azw"),
        mimePattern  = "application/epub+zip",
    ),
    FONT(
        displayName  = "Font",
        extensions   = setOf("ttf","otf","woff","woff2"),
        mimePattern  = "font/*",
    ),
    UNKNOWN(
        displayName  = "File",
        extensions   = emptySet(),
        mimePattern  = "*/*",
    );

    companion object {
        fun fromExtension(ext: String): FileType {
            val lower = ext.lowercase()
            return entries.firstOrNull { type ->
                lower in type.extensions
            } ?: UNKNOWN
        }

        fun fromMime(mime: String): FileType {
            return when {
                mime.startsWith("image/")  -> IMAGE
                mime.startsWith("video/")  -> VIDEO
                mime.startsWith("audio/")  -> AUDIO
                mime.contains("pdf")       -> DOCUMENT
                mime.contains("zip")       -> ARCHIVE
                mime.contains("android")   -> APK
                mime.startsWith("text/")   -> CODE
                else                        -> UNKNOWN
            }
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 3 — SORT & FILTER SYSTEM
// ════════════════════════════════════════════════════════════

enum class SortBy(
    val displayName: String,
    val icon: String,           // icon name reference
) {
    NAME(       "Name",          "sort_by_alpha"),
    SIZE(       "Size",          "data_usage"),
    DATE(       "Date Modified", "schedule"),
    TYPE(       "Type",          "category"),
    EXTENSION(  "Extension",     "label"),
    DATE_CREATED("Date Created", "calendar_today"),
}

enum class SortOrder(val displayName: String) {
    ASCENDING("Ascending"),
    DESCENDING("Descending"),
}

@Stable
data class SortConfig(
    val sortBy: SortBy      = SortBy.NAME,
    val sortOrder: SortOrder = SortOrder.ASCENDING,
    val foldersFirst: Boolean = true,
    val showHidden: Boolean   = false,
) {
    val displayLabel: String
        get() = "${sortBy.displayName} • ${sortOrder.displayName}"
}

enum class FilterType(
    val displayName: String,
    val fileType: FileType?,
) {
    ALL(       "All",       null),
    FOLDERS(   "Folders",   FileType.FOLDER),
    IMAGES(    "Images",    FileType.IMAGE),
    VIDEOS(    "Videos",    FileType.VIDEO),
    AUDIO(     "Audio",     FileType.AUDIO),
    DOCUMENTS( "Docs",      FileType.DOCUMENT),
    ARCHIVES(  "Archives",  FileType.ARCHIVE),
    APK(       "APKs",      FileType.APK),
    CODE(      "Code",      FileType.CODE),
}

@Stable
data class FilterConfig(
    val activeFilter: FilterType   = FilterType.ALL,
    val sizeRange: LongRange?      = null,        // bytes
    val dateRange: LongRange?      = null,        // timestamps
    val showOnlyFavorites: Boolean = false,
    val showOnlyReadOnly: Boolean  = false,
    val tags: List<String>         = emptyList(),
) {
    val hasActiveFilters: Boolean
        get() = activeFilter != FilterType.ALL ||
                sizeRange != null ||
                dateRange != null ||
                showOnlyFavorites ||
                showOnlyReadOnly ||
                tags.isNotEmpty()

    val activeFilterCount: Int
        get() = listOf(
            activeFilter != FilterType.ALL,
            sizeRange != null,
            dateRange != null,
            showOnlyFavorites,
            showOnlyReadOnly,
            tags.isNotEmpty(),
        ).count { it }
}

// ── Sort + Filter applier ───────────────────────────────────
fun List<FileItem>.applySortAndFilter(
    sort: SortConfig,
    filter: FilterConfig,
): List<FileItem> {
    var result = this

    // Apply filter
    result = result.filter { item ->
        // Type filter
        val typeMatch = when (filter.activeFilter) {
            FilterType.ALL     -> true
            FilterType.FOLDERS -> item.isDirectory
            else               -> !item.isDirectory &&
                                  item.fileType == filter.activeFilter.fileType
        }
        // Size filter
        val sizeMatch = filter.sizeRange?.let {
            item.size in it
        } ?: true
        // Date filter
        val dateMatch = filter.dateRange?.let {
            item.lastModified in it
        } ?: true
        // Favorites
        val favMatch = if (filter.showOnlyFavorites) item.isFavorite else true
        // Hidden
        val hiddenMatch = if (!sort.showHidden) !item.isHidden else true

        typeMatch && sizeMatch && dateMatch && favMatch && hiddenMatch
    }

    // Apply sort
    val comparator: Comparator<FileItem> = when (sort.sortBy) {
        SortBy.NAME         -> compareBy { it.sortKey }
        SortBy.SIZE         -> compareBy { it.size }
        SortBy.DATE         -> compareBy { it.lastModified }
        SortBy.TYPE         -> compareBy { it.fileType.displayName }
        SortBy.EXTENSION    -> compareBy { it.extension.lowercase() }
        SortBy.DATE_CREATED -> compareBy { it.lastModified }
    }

    result = if (sort.foldersFirst) {
        val folders = result.filter { it.isDirectory }
            .sortedWith(comparator)
        val files   = result.filter { !it.isDirectory }
            .sortedWith(comparator)
        if (sort.sortOrder == SortOrder.DESCENDING)
            folders.reversed() + files.reversed()
        else
            folders + files
    } else {
        val sorted = result.sortedWith(comparator)
        if (sort.sortOrder == SortOrder.DESCENDING) sorted.reversed()
        else sorted
    }

    return result
}

// ════════════════════════════════════════════════════════════
// SECTION 4 — BREADCRUMB STATE
// ════════════════════════════════════════════════════════════

@Stable
data class BreadcrumbSegment(
    val name: String,
    val path: String,
    val isRoot: Boolean = false,
)

@Stable
class BreadcrumbState(
    initialPath: String = "/storage/emulated/0",
) {
    private val _stack = mutableStateListOf<BreadcrumbSegment>()
    val stack: List<BreadcrumbSegment> = _stack

    var currentPath by mutableStateOf(initialPath)
        private set

    init {
        buildFromPath(initialPath)
    }

    val currentSegment: BreadcrumbSegment?
        get() = _stack.lastOrNull()

    val canGoBack: Boolean
        get() = _stack.size > 1

    fun navigateTo(path: String) {
        currentPath = path
        buildFromPath(path)
    }

    fun navigateToSegment(segment: BreadcrumbSegment) {
        val idx = _stack.indexOf(segment)
        if (idx >= 0) {
            val newStack = _stack.take(idx + 1)
            _stack.clear()
            _stack.addAll(newStack)
            currentPath = segment.path
        }
    }

    fun goBack(): Boolean {
        return if (canGoBack) {
            _stack.removeLast()
            currentPath = _stack.last().path
            true
        } else false
    }

    fun goUp(): Boolean = goBack()

    private fun buildFromPath(path: String) {
        _stack.clear()
        val roots = listOf(
            "/storage/emulated/0" to "Internal",
            "/storage/sdcard1"    to "SD Card",
            "/storage"            to "Storage",
            "/"                   to "Root",
        )
        val (rootPath, rootName) = roots.firstOrNull { (rp, _) ->
            path.startsWith(rp)
        } ?: ("/" to "Root")

        _stack.add(
            BreadcrumbSegment(
                name   = rootName,
                path   = rootPath,
                isRoot = true,
            )
        )

        val relative = path.removePrefix(rootPath).trim('/')
        if (relative.isNotEmpty()) {
            val parts = relative.split("/")
            var current = rootPath
            parts.forEach { part ->
                current = "$current/$part"
                _stack.add(
                    BreadcrumbSegment(
                        name   = part,
                        path   = current,
                        isRoot = false,
                    )
                )
            }
        }
    }

    fun getDisplayPath(): String = currentPath
        .replace("/storage/emulated/0", "Internal Storage")
        .replace("/storage/sdcard1", "SD Card")
}

// ════════════════════════════════════════════════════════════
// SECTION 5 — SELECTION STATE
// ════════════════════════════════════════════════════════════

@Stable
class SelectionState {
    private val _selectedIds = mutableStateSetOf<String>()
    val selectedIds: Set<String> = _selectedIds

    var isSelectionMode by mutableStateOf(false)
        private set

    val selectedCount: Int
        get() = _selectedIds.size

    val hasSelection: Boolean
        get() = _selectedIds.isNotEmpty()

    fun enterSelectionMode(firstId: String? = null) {
        isSelectionMode = true
        firstId?.let { _selectedIds.add(it) }
    }

    fun exitSelectionMode() {
        isSelectionMode = false
        _selectedIds.clear()
    }

    fun toggleSelection(id: String) {
        if (_selectedIds.contains(id)) {
            _selectedIds.remove(id)
            if (_selectedIds.isEmpty()) {
                isSelectionMode = false
            }
        } else {
            _selectedIds.add(id)
        }
    }

    fun selectAll(items: List<FileItem>) {
        _selectedIds.addAll(items.map { it.id })
    }

    fun deselectAll() {
        _selectedIds.clear()
        isSelectionMode = false
    }

    fun isSelected(id: String): Boolean = _selectedIds.contains(id)

    fun getSelectedItems(allItems: List<FileItem>): List<FileItem> =
        allItems.filter { it.id in _selectedIds }

    // Select range (for shift+click behavior)
    fun selectRange(
        fromId: String,
        toId: String,
        allItems: List<FileItem>,
    ) {
        val fromIdx = allItems.indexOfFirst { it.id == fromId }
        val toIdx   = allItems.indexOfFirst { it.id == toId }
        if (fromIdx < 0 || toIdx < 0) return
        val range = if (fromIdx <= toIdx)
            allItems.subList(fromIdx, toIdx + 1)
        else
            allItems.subList(toIdx, fromIdx + 1)
        _selectedIds.addAll(range.map { it.id })
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 6 — CLIPBOARD STATE (Copy / Move / Cut)
// ════════════════════════════════════════════════════════════

enum class ClipboardOperation {
    COPY, CUT, NONE
}

@Stable
class ClipboardState {
    var operation by mutableStateOf(ClipboardOperation.NONE)
        private set

    private val _items = mutableStateListOf<FileItem>()
    val items: List<FileItem> = _items

    val hasItems: Boolean
        get() = _items.isNotEmpty()

    val itemCount: Int
        get() = _items.size

    val isCut: Boolean
        get() = operation == ClipboardOperation.CUT

    val displayLabel: String
        get() = when {
            !hasItems -> ""
            itemCount == 1 -> "\"${_items.first().name}\""
            else           -> "$itemCount items"
        }

    fun copy(items: List<FileItem>) {
        _items.clear()
        _items.addAll(items)
        operation = ClipboardOperation.COPY
    }

    fun cut(items: List<FileItem>) {
        _items.clear()
        _items.addAll(items)
        operation = ClipboardOperation.CUT
    }

    fun clear() {
        _items.clear()
        operation = ClipboardOperation.NONE
    }

    fun canPasteInto(targetPath: String): Boolean {
        if (!hasItems) return false
        // Prevent paste into self or child
        return _items.none { item ->
            targetPath.startsWith(item.path)
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 7 — FILE OPERATION STATE
//             (Copy / Move / Delete / Zip / Extract)
// ════════════════════════════════════════════════════════════

sealed class OperationStatus {
    object Idle : OperationStatus()
    data class Running(
        val type: OperationType,
        val progress: Float,           // 0f → 1f
        val currentFile: String,
        val processedCount: Int,
        val totalCount: Int,
        val processedBytes: Long,
        val totalBytes: Long,
        val speed: String,             // "12.3 MB/s"
        val eta: String,               // "~2 min"
        val canPause: Boolean = true,
        val isPaused: Boolean = false,
    ) : OperationStatus()
    data class Success(
        val type: OperationType,
        val message: String,
        val affectedCount: Int,
    ) : OperationStatus()
    data class Error(
        val type: OperationType,
        val message: String,
        val canRetry: Boolean = true,
    ) : OperationStatus()
    data class Conflict(
        val type: OperationType,
        val conflictingItem: FileItem,
        val targetPath: String,
        val remainingConflicts: Int,
    ) : OperationStatus()
}

enum class OperationType(val displayName: String) {
    COPY(     "Copying"),
    MOVE(     "Moving"),
    DELETE(   "Deleting"),
    ZIP(      "Compressing"),
    EXTRACT(  "Extracting"),
    RENAME(   "Renaming"),
    SHARE(    "Sharing"),
}

enum class ConflictResolution {
    SKIP,
    REPLACE,
    KEEP_BOTH,
    REPLACE_ALL,
    SKIP_ALL,
}

@Stable
class OperationState {
    var status by mutableStateOf<OperationStatus>(OperationStatus.Idle)
        private set

    val isRunning: Boolean
        get() = status is OperationStatus.Running

    val isIdle: Boolean
        get() = status is OperationStatus.Idle

    fun startOperation(
        type: OperationType,
        totalCount: Int,
        totalBytes: Long,
    ) {
        status = OperationStatus.Running(
            type           = type,
            progress       = 0f,
            currentFile    = "",
            processedCount = 0,
            totalCount     = totalCount,
            processedBytes = 0L,
            totalBytes     = totalBytes,
            speed          = "0 B/s",
            eta            = "Calculating...",
        )
    }

    fun updateProgress(
        progress: Float,
        currentFile: String,
        processedCount: Int,
        processedBytes: Long,
        speed: String,
        eta: String,
    ) {
        val current = status as? OperationStatus.Running ?: return
        status = current.copy(
            progress       = progress,
            currentFile    = currentFile,
            processedCount = processedCount,
            processedBytes = processedBytes,
            speed          = speed,
            eta            = eta,
        )
    }

    fun pauseResume() {
        val current = status as? OperationStatus.Running ?: return
        status = current.copy(isPaused = !current.isPaused)
    }

    fun complete(type: OperationType, affectedCount: Int) {
        status = OperationStatus.Success(
            type          = type,
            message       = buildSuccessMessage(type, affectedCount),
            affectedCount = affectedCount,
        )
    }

    fun fail(type: OperationType, message: String) {
        status = OperationStatus.Error(
            type    = type,
            message = message,
        )
    }

    fun conflict(
        type: OperationType,
        item: FileItem,
        targetPath: String,
        remaining: Int,
    ) {
        status = OperationStatus.Conflict(
            type                = type,
            conflictingItem     = item,
            targetPath          = targetPath,
            remainingConflicts  = remaining,
        )
    }

    fun reset() {
        status = OperationStatus.Idle
    }

    private fun buildSuccessMessage(type: OperationType, count: Int): String {
        val item = if (count == 1) "item" else "items"
        return when (type) {
            OperationType.COPY    -> "$count $item copied successfully"
            OperationType.MOVE    -> "$count $item moved successfully"
            OperationType.DELETE  -> "$count $item deleted"
            OperationType.ZIP     -> "Archive created successfully"
            OperationType.EXTRACT -> "$count $item extracted"
            OperationType.RENAME  -> "Renamed successfully"
            OperationType.SHARE   -> "Shared successfully"
        }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 8 — SEARCH STATE
// ════════════════════════════════════════════════════════════

data class RecentSearch(
    val query: String,
    val timestamp: Long = System.currentTimeMillis(),
    val resultCount: Int = 0,
)

sealed class SearchResult {
    object Empty : SearchResult()
    object Loading : SearchResult()
    data class Results(
        val items: List<FileItem>,
        val query: String,
        val totalCount: Int,
        val searchedIn: String,
        val durationMs: Long,
    ) : SearchResult()
    data class Error(val message: String) : SearchResult()
}

@Stable
class SearchState {
    var query by mutableStateOf("")
    var isActive by mutableStateOf(false)
    var result by mutableStateOf<SearchResult>(SearchResult.Empty)
    var recentSearches by mutableStateOf<List<RecentSearch>>(emptyList())
    var searchScope by mutableStateOf(SearchScope.CURRENT_FOLDER)
    var isCaseSensitive by mutableStateOf(false)
    var searchInContent by mutableStateOf(false)
    var typeFilter by mutableStateOf(FilterType.ALL)

    val hasQuery: Boolean
        get() = query.isNotEmpty()

    val hasResults: Boolean
        get() = result is SearchResult.Results

    val resultCount: Int
        get() = (result as? SearchResult.Results)?.totalCount ?: 0

    fun activate() { isActive = true }

    fun deactivate() {
        isActive = false
        query    = ""
        result   = SearchResult.Empty
    }

    fun updateQuery(newQuery: String) {
        query  = newQuery
        result = if (newQuery.isEmpty()) SearchResult.Empty
                 else SearchResult.Loading
    }

    fun setResults(items: List<FileItem>, duration: Long, searchedIn: String) {
        if (items.isEmpty()) {
            result = SearchResult.Empty
        } else {
            result = SearchResult.Results(
                items       = items,
                query       = query,
                totalCount  = items.size,
                searchedIn  = searchedIn,
                durationMs  = duration,
            )
        }
        addToRecent(query, items.size)
    }

    fun setError(message: String) {
        result = SearchResult.Error(message)
    }

    private fun addToRecent(q: String, count: Int) {
        if (q.isBlank()) return
        val updated = recentSearches
            .filterNot { it.query == q }
            .toMutableList()
            .also { it.add(0, RecentSearch(q, resultCount = count)) }
            .take(8)
        recentSearches = updated
    }

    fun clearRecent() { recentSearches = emptyList() }
}

enum class SearchScope(val displayName: String) {
    CURRENT_FOLDER("Current Folder"),
    INTERNAL_STORAGE("Internal Storage"),
    ALL_STORAGE("All Storage"),
}

// ════════════════════════════════════════════════════════════
// SECTION 9 — STORAGE INFO STATE
// ════════════════════════════════════════════════════════════

data class StorageVolume(
    val id: String,
    val displayName: String,
    val path: String,
    val totalBytes: Long,
    val usedBytes: Long,
    val isRemovable: Boolean,
    val isEmulated: Boolean,
) {
    val freeBytes: Long   get() = totalBytes - usedBytes
    val usedFraction: Float get() = usedBytes.toFloat() / totalBytes.coerceAtLeast(1L)
    val freeFraction: Float get() = 1f - usedFraction
    val displayTotal: String get() = FileItem.formatSize(totalBytes)
    val displayUsed: String  get() = FileItem.formatSize(usedBytes)
    val displayFree: String  get() = FileItem.formatSize(freeBytes)
    val usedPercent: Int     get() = (usedFraction * 100).toInt()
}

data class StorageBreakdown(
    val imagesBytes: Long   = 0L,
    val videosBytes: Long   = 0L,
    val audioBytes: Long    = 0L,
    val docsBytes: Long     = 0L,
    val apksBytes: Long     = 0L,
    val archivesBytes: Long = 0L,
    val otherBytes: Long    = 0L,
) {
    val totalBytes: Long
        get() = imagesBytes + videosBytes + audioBytes +
                docsBytes + apksBytes + archivesBytes + otherBytes
}

@Stable
class StorageState {
    var volumes by mutableStateOf<List<StorageVolume>>(emptyList())
    var breakdown by mutableStateOf(StorageBreakdown())
    var isLoading by mutableStateOf(false)
    var selectedVolumeId by mutableStateOf<String?>(null)

    val primaryVolume: StorageVolume?
        get() = volumes.firstOrNull { !it.isRemovable }

    val sdCard: StorageVolume?
        get() = volumes.firstOrNull { it.isRemovable }

    val selectedVolume: StorageVolume?
        get() = volumes.find { it.id == selectedVolumeId } ?: primaryVolume

    fun toStorageSegments(ext: ExtendedColors): List<StorageSegment> {
        val total = selectedVolume?.totalBytes?.toFloat() ?: 1f
        return listOf(
            StorageSegment("Images",   breakdown.imagesBytes / total,   ext.imageColor),
            StorageSegment("Videos",   breakdown.videosBytes / total,   ext.videoColor),
            StorageSegment("Audio",    breakdown.audioBytes  / total,   ext.audioColor),
            StorageSegment("Docs",     breakdown.docsBytes   / total,   ext.documentColor),
            StorageSegment("APKs",     breakdown.apksBytes   / total,   ext.apkColor),
            StorageSegment("Archives", breakdown.archivesBytes / total, ext.archiveColor),
            StorageSegment("Other",    breakdown.otherBytes  / total,   ext.unknownColor),
        ).filter { it.fraction > 0f }
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 10 — SPLIT PANE PATH STATE
//              Each pane has its own nav + selection state
// ════════════════════════════════════════════════════════════

@Stable
class PaneState(
    initialPath: String = "/storage/emulated/0",
    val paneId: ActivePane,
) {
    // Navigation
    val breadcrumb = BreadcrumbState(initialPath)

    // Items in current directory
    var items by mutableStateOf<List<FileItem>>(emptyList())
    var isLoading by mutableStateOf(false)
    var loadError by mutableStateOf<String?>(null)

    // Sort & filter
    var sortConfig by mutableStateOf(SortConfig())
    var filterConfig by mutableStateOf(FilterConfig())

    // Selection (per pane)
    val selection = SelectionState()

    // View mode
    var viewMode by mutableStateOf(ViewMode.LIST)

    // Scroll position memory
    var scrollIndex by mutableStateOf(0)
    var scrollOffset by mutableStateOf(0)

    // Computed sorted + filtered items
    val displayItems: List<FileItem>
        get() = items.applySortAndFilter(sortConfig, filterConfig)

    val currentPath: String
        get() = breadcrumb.currentPath

    val isEmpty: Boolean
        get() = !isLoading && items.isEmpty()

    fun navigateTo(path: String) {
        breadcrumb.navigateTo(path)
        selection.exitSelectionMode()
        scrollIndex  = 0
        scrollOffset = 0
    }

    fun goBack(): Boolean = breadcrumb.goBack().also { navigated ->
        if (navigated) selection.exitSelectionMode()
    }

    fun updateItems(newItems: List<FileItem>) {
        items      = newItems
        isLoading  = false
        loadError  = null
    }

    fun setLoading() {
        isLoading = true
        loadError = null
    }

    fun setError(error: String) {
        isLoading = false
        loadError = error
    }

    fun updateSortConfig(new: SortConfig) {
        sortConfig = new
    }

    fun updateFilterConfig(new: FilterConfig) {
        filterConfig = new
    }

    fun saveScroll(index: Int, offset: Int) {
        scrollIndex  = index
        scrollOffset = offset
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 11 — ROOT FILE MANAGER STATE
//              Single source of truth — used by all screens
// ════════════════════════════════════════════════════════════

@Stable
class FileManagerState(
    initialPath: String = "/storage/emulated/0",
) {
    // ── Pane States ────────────────────────────────────────
    val primaryPane   = PaneState(initialPath, ActivePane.PRIMARY)
    val secondaryPane = PaneState(initialPath, ActivePane.SECONDARY)

    // ── Split Screen ───────────────────────────────────────
    val splitScreen = SplitScreenState()

    // ── Clipboard ──────────────────────────────────────────
    val clipboard = ClipboardState()

    // ── Operations ─────────────────────────────────────────
    val operation = OperationState()

    // ── Search ─────────────────────────────────────────────
    val search = SearchState()

    // ── Storage ────────────────────────────────────────────
    val storage = StorageState()

    // ── UI State ───────────────────────────────────────────
    var isFabExpanded by mutableStateOf(false)
    var showSortSheet by mutableStateOf(false)
    var showFilterSheet by mutableStateOf(false)
    var showCreateFolderDialog by mutableStateOf(false)
    var showCreateFileDialog by mutableStateOf(false)
    var showRenameDialog by mutableStateOf(false)
    var showDeleteDialog by mutableStateOf(false)
    var showPropertiesSheet by mutableStateOf(false)
    var showZipDialog by mutableStateOf(false)
    var showExtractDialog by mutableStateOf(false)
    var showPermissionScreen by mutableStateOf(false)
    var showStorageAnalyzer by mutableStateOf(false)
    var contextMenuTarget by mutableStateOf<FileItem?>(null)
    var renameTarget by mutableStateOf<FileItem?>(null)
    var propertiesTarget by mutableStateOf<FileItem?>(null)

    // ── Active pane accessor ───────────────────────────────
    val activePane: PaneState
        get() = when (splitScreen.activePane) {
            ActivePane.PRIMARY   -> primaryPane
            ActivePane.SECONDARY -> secondaryPane
        }

    // ── Snackbar / Toast messages ──────────────────────────
    var snackbarMessage by mutableStateOf<SnackbarMessage?>(null)

    fun showSnackbar(
        message: String,
        type: SnackbarType = SnackbarType.INFO,
        action: Pair<String, () -> Unit>? = null,
    ) {
        snackbarMessage = SnackbarMessage(message, type, action)
    }

    fun dismissSnackbar() {
        snackbarMessage = null
    }

    // ── Navigation helpers ─────────────────────────────────
    fun navigateTo(path: String, pane: ActivePane = splitScreen.activePane) {
        when (pane) {
            ActivePane.PRIMARY   -> primaryPane.navigateTo(path)
            ActivePane.SECONDARY -> secondaryPane.navigateTo(path)
        }
        // Update split state path
        when (pane) {
            ActivePane.PRIMARY   -> splitScreen.primaryPath   = path
            ActivePane.SECONDARY -> splitScreen.secondaryPath = path
        }
    }

    fun goBack(): Boolean {
        return when (splitScreen.activePane) {
            ActivePane.PRIMARY   -> primaryPane.goBack()
            ActivePane.SECONDARY -> secondaryPane.goBack()
        }
    }

    // ── FAB ────────────────────────────────────────────────
    fun toggleFab() { isFabExpanded = !isFabExpanded }
    fun collapseFab() { isFabExpanded = false }

    // ── Context menu ───────────────────────────────────────
    fun openContextMenu(item: FileItem) {
        contextMenuTarget = item
        collapseFab()
    }

    fun closeContextMenu() {
        contextMenuTarget = null
    }

    // ── Quick actions ───────────────────────────────────────
    fun copySelected() {
        val items = activePane.selection.getSelectedItems(activePane.displayItems)
        clipboard.copy(items)
        activePane.selection.exitSelectionMode()
        showSnackbar(
            "${items.size} item${if (items.size == 1) "" else "s"} copied",
            SnackbarType.SUCCESS,
        )
    }

    fun cutSelected() {
        val items = activePane.selection.getSelectedItems(activePane.displayItems)
        clipboard.cut(items)
        activePane.selection.exitSelectionMode()
        showSnackbar(
            "${items.size} item${if (items.size == 1) "" else "s"} cut",
            SnackbarType.INFO,
        )
    }

    fun canPaste(): Boolean =
        clipboard.canPasteInto(activePane.currentPath)
}

// ════════════════════════════════════════════════════════════
// SECTION 12 — SNACKBAR MESSAGE MODEL
// ════════════════════════════════════════════════════════════

enum class SnackbarType { INFO, SUCCESS, WARNING, ERROR }

data class SnackbarMessage(
    val message: String,
    val type: SnackbarType = SnackbarType.INFO,
    val action: Pair<String, () -> Unit>? = null,
    val durationMs: Long = 3000L,
)

// ════════════════════════════════════════════════════════════
// SECTION 13 — CONTEXT MENU ACTIONS
// ════════════════════════════════════════════════════════════

data class ContextAction(
    val id: String,
    val label: String,
    val icon: ImageVector,
    val color: Color? = null,
    val enabled: Boolean = true,
    val isDividerBefore: Boolean = false,
    val isDanger: Boolean = false,
)

object ContextActions {

    fun forFile(
        item: FileItem,
        hasClipboard: Boolean,
        isSplitMode: Boolean,
    ): List<ContextAction> = buildList {

        add(ContextAction("open",       "Open",           Icons.Rounded.OpenInNew))
        add(ContextAction("open_with",  "Open With",      Icons.Rounded.Apps))

        if (isSplitMode) {
            add(ContextAction(
                "open_other_pane",
                "Open in Other Pane",
                Icons.Rounded.VerticalSplit,
            ))
        }

        add(ContextAction(
            "info", "Properties",
            Icons.Rounded.Info,
            isDividerBefore = true,
        ))

        add(ContextAction("copy",   "Copy",   Icons.Rounded.ContentCopy,
            isDividerBefore = true))
        add(ContextAction("cut",    "Cut",    Icons.Rounded.ContentCut))
        if (hasClipboard) {
            add(ContextAction("paste", "Paste Here", Icons.Rounded.ContentPaste))
        }

        add(ContextAction("share",    "Share",    Icons.Rounded.Share,
            isDividerBefore = true))
        add(ContextAction("compress", "Compress", Icons.Rounded.FolderZip))
        add(ContextAction("rename",   "Rename",   Icons.Rounded.Edit))

        if (item.isFavorite) {
            add(ContextAction("unfavorite", "Remove Favorite",
                Icons.Rounded.StarBorder))
        } else {
            add(ContextAction("favorite", "Add to Favorites",
                Icons.Rounded.Star))
        }

        add(ContextAction(
            "delete", "Delete",
            Icons.Rounded.Delete,
            isDividerBefore = true,
            isDanger        = true,
        ))
    }

    fun forFolder(
        item: FileItem,
        hasClipboard: Boolean,
        isSplitMode: Boolean,
    ): List<ContextAction> = buildList {

        add(ContextAction("open",    "Open",      Icons.Rounded.FolderOpen))
        if (isSplitMode) {
            add(ContextAction(
                "open_other_pane",
                "Open in Other Pane",
                Icons.Rounded.VerticalSplit,
            ))
        }
        add(ContextAction("info", "Properties",
            Icons.Rounded.Info, isDividerBefore = true))

        add(ContextAction("copy",   "Copy",   Icons.Rounded.ContentCopy,
            isDividerBefore = true))
        add(ContextAction("cut",    "Cut",    Icons.Rounded.ContentCut))
        if (hasClipboard) {
            add(ContextAction("paste", "Paste Inside", Icons.Rounded.ContentPaste))
        }
        add(ContextAction("share",    "Share",    Icons.Rounded.Share,
            isDividerBefore = true))
        add(ContextAction("compress", "Compress", Icons.Rounded.FolderZip))
        add(ContextAction("rename",   "Rename",   Icons.Rounded.Edit))

        if (item.isFavorite) {
            add(ContextAction("unfavorite", "Remove Favorite",
                Icons.Rounded.StarBorder))
        } else {
            add(ContextAction("favorite", "Add to Favorites",
                Icons.Rounded.Star))
        }

        add(ContextAction(
            "delete", "Delete",
            Icons.Rounded.Delete,
            isDividerBefore = true,
            isDanger        = true,
        ))
    }

    fun forMultiSelect(
        items: List<FileItem>,
        hasClipboard: Boolean,
    ): List<ContextAction> = buildList {

        val hasFolder = items.any { it.isDirectory }
        val count     = items.size

        add(ContextAction("copy",    "Copy ($count)",    Icons.Rounded.ContentCopy))
        add(ContextAction("cut",     "Cut ($count)",     Icons.Rounded.ContentCut))
        if (hasClipboard) {
            add(ContextAction("paste", "Paste Here", Icons.Rounded.ContentPaste))
        }
        add(ContextAction("share",    "Share ($count)",    Icons.Rounded.Share,
            isDividerBefore = true))
        add(ContextAction("compress", "Compress ($count)", Icons.Rounded.FolderZip))

        add(ContextAction(
            "delete", "Delete ($count)",
            Icons.Rounded.Delete,
            isDividerBefore = true,
            isDanger        = true,
        ))
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 14 — COMPOSITION LOCALS
// ════════════════════════════════════════════════════════════

val LocalFileManagerState = staticCompositionLocalOf<FileManagerState> {
    error("No FileManagerState — wrap root with FileManagerStateProvider")
}

@Composable
fun FileManagerStateProvider(
    state: FileManagerState = remember { FileManagerState() },
    content: @Composable () -> Unit,
) {
    CompositionLocalProvider(LocalFileManagerState provides state) {
        content()
    }
}

// ════════════════════════════════════════════════════════════
// SECTION 15 — REMEMBER HELPERS
// ════════════════════════════════════════════════════════════

@Composable
fun rememberFileManagerState(
    initialPath: String = "/storage/emulated/0",
): FileManagerState = remember { FileManagerState(initialPath) }

@Composable
fun rememberSelectionState(): SelectionState =
    remember { SelectionState() }

@Composable
fun rememberClipboardState(): ClipboardState =
    remember { ClipboardState() }

@Composable
fun rememberOperationState(): OperationState =
    remember { OperationState() }

@Composable
fun rememberSearchState(): SearchState =
    remember { SearchState() }

@Composable
fun rememberBreadcrumbState(
    initialPath: String = "/storage/emulated/0",
): BreadcrumbState = remember { BreadcrumbState(initialPath) }

// ════════════════════════════════════════════════════════════
// END OF FILE 3 — FileManagerState.kt
// Next → File 4: MainFileScreen.kt
// (Root Scaffold, TopBar, BreadcrumbNav, FAB,
//  BottomNav, Grid/List toggle, StorageBar,
//  Split Screen Layout integration)
// ════════════════════════════════════════════════════════════

# Keep Kotlin metadata and Compose runtime
-dontobfuscate
-keep class kotlin.Metadata { *; }
-keep class androidx.compose.** { *; }
-keep class com.devfav.filemanager.** { *; }

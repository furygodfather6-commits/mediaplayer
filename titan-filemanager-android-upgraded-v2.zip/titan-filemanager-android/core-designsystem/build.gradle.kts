// :core:designsystem — Material 3 theme, design tokens, base components
plugins {
    id("titan.android.library")
    id("titan.android.compose")
}

android {
    namespace = "com.titan.filemanager.core.designsystem"
}

dependencies {
    // No upstream module deps — designsystem is self-contained
    testImplementation(libs.junit5)
    testImplementation(libs.truth)
}

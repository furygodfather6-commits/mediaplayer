package com.titan.filemanager.core.designsystem.modifier

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.titan.filemanager.core.designsystem.tokens.ColorTokens
import com.titan.filemanager.core.designsystem.tokens.MotionTokens
import com.titan.filemanager.core.designsystem.tokens.ShapeTokens
import com.titan.filemanager.core.designsystem.theme.TitanTheme

/**
 * # Modifiers.kt
 *
 * The core modifier library for TitanFileManager. Every modifier here is built on top of
 * [com.titan.filemanager.core.designsystem.tokens] tokens, so a re-skin automatically
 * updates every modifier consumer.
 *
 * ## Naming convention
 * Each modifier is named after the visual effect it produces, not the underlying API
 * (e.g. `shimmer` not `animatedLinearGradientSweep`). This keeps call-sites readable.
 *
 * ## Categories
 * 1. **Visual effects** — `shimmer`, `gradientBackground`, `neonGlow`.
 * 2. **Interaction feedback** — `pressScale`, `bounceClick`.
 * 3. **Entrance animation** — `slideOnAppear`.
 * 4. **Shape helpers** — `clipToCircle`.
 */

/**
 * Shimmer effect — an animated gradient sweep commonly used for skeleton-loading placeholders.
 *
 * The gradient cycles between the theme's [ExtendedColorScheme.shimmerBase] and
 * [ExtendedColorScheme.shimmerHighlight] colours, sweeping diagonally across the composable.
 * The default [shape] is `ShapeTokens.ExtraSmall` (8 dp), matching the rounded corners of
 * most placeholder boxes.
 *
 * @param shape clip shape; defaults to [ShapeTokens.ExtraSmall].
 */
fun Modifier.shimmer(shape: Shape = ShapeTokens.ExtraSmall): Modifier = composed {
    val transition = rememberInfiniteTransition(label = "shimmer")
    val translateAnim by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween(MotionTokens.ShimmerDuration),
            RepeatMode.Restart,
        ),
        label = "shimmerTranslate",
    )
    val baseColor = TitanTheme.extendedColors.shimmerBase
    val highlightColor = TitanTheme.extendedColors.shimmerHighlight
    this.clip(shape).drawWithContent {
        drawContent()
        val width = size.width
        drawRect(
            brush = Brush.linearGradient(
                colors = listOf(baseColor, highlightColor, baseColor),
                start = Offset(width * translateAnim - width, 0f),
                end = Offset(width * translateAnim, size.height),
            ),
        )
    }
}

/**
 * Gradient background — paints the composable with a linear gradient.
 *
 * The default gradient is `ColorTokens.GradientStart → ColorTokens.GradientEnd`, which
 * gives the classic Titan blue→indigo hero look. Override [startColor] and [endColor]
 * to use a different palette (e.g. sunset or forest).
 *
 * @param startColor start colour of the gradient.
 * @param endColor end colour of the gradient.
 * @param shape clip shape; defaults to [ShapeTokens.Medium].
 */
fun Modifier.gradientBackground(
    startColor: Color = ColorTokens.GradientStart,
    endColor: Color = ColorTokens.GradientEnd,
    shape: Shape = ShapeTokens.Medium,
): Modifier = this.clip(shape).background(Brush.linearGradient(listOf(startColor, endColor)))

/**
 * Diagonal gradient background — paints the composable with a 45° diagonal linear gradient.
 *
 * Useful for promotional banners and hero cards where a flat gradient feels too "striped".
 */
fun Modifier.gradientBackgroundDiagonal(
    startColor: Color = ColorTokens.GradientStart,
    endColor: Color = ColorTokens.GradientEnd,
    shape: Shape = ShapeTokens.Medium,
): Modifier = this.clip(shape).background(
    Brush.linearGradient(
        colors = listOf(startColor, endColor),
        start = Offset(0f, 0f),
        end = Offset(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY),
    ),
)

/**
 * Radial gradient background — paints the composable with a radial gradient.
 *
 * Used for spotlight effects on FAB and CTA buttons.
 */
fun Modifier.gradientBackgroundRadial(
    centerColor: Color = ColorTokens.GradientStart,
    edgeColor: Color = ColorTokens.GradientEnd,
    shape: Shape = ShapeTokens.Medium,
): Modifier = this.clip(shape).background(
    Brush.radialGradient(
        colors = listOf(centerColor, edgeColor),
        center = Offset(0.5f * Float.POSITIVE_INFINITY, 0.5f * Float.POSITIVE_INFINITY),
        radius = Float.POSITIVE_INFINITY,
    ),
)

/**
 * Press scale — adds a subtle scale-down on press for tactile feedback.
 *
 * Unlike `bounceClick`, this modifier does NOT consume clicks; pair it with a separate
 * `clickable` modifier when you need a click handler.
 *
 * @param pressedScale scale factor applied when pressed (e.g. 0.96 = 4 % shrink).
 * @param enabled when `false`, the modifier is a no-op.
 */
@Composable
fun Modifier.pressScale(pressedScale: Float = 0.96f, enabled: Boolean = true): Modifier {
    if (!enabled) return this
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    return this.scale(if (isPressed) pressedScale else 1f)
        .clickable(interactionSource = interactionSource, indication = null, onClick = {})
}

/**
 * Bounce click — spring-physics scale on press + click handler.
 *
 * This is the standard click feedback for TitanFileManager's interactive cards and tiles.
 * The spring uses `DampingRatioMediumBouncy` for a tasteful bounce that doesn't feel
 * toy-ish.
 *
 * @param onClick click handler.
 * @param pressedScale scale factor applied when pressed (default 0.96).
 * @param enabled when `false`, falls back to a plain clickable.
 */
@Composable
fun Modifier.bounceClick(
    onClick: () -> Unit,
    pressedScale: Float = 0.96f,
    enabled: Boolean = true,
): Modifier {
    if (!enabled) return this.then(Modifier.clickable(onClick = onClick))
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) pressedScale else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow,
        ),
        label = "bounceScale",
    )
    return this.scale(scale).clickable(
        interactionSource = interactionSource,
        indication = null,
        onClick = onClick,
    )
}

/**
 * Neon glow — draws a coloured glow around the composable.
 *
 * Uses Android's `setShadowLayer` to render a soft, coloured halo. Best used on dark
 * backgrounds; on light backgrounds the glow may be hard to see.
 *
 * @param color glow colour (defaults to [ColorTokens.BrandBlue]).
 * @param radius blur radius of the glow.
 * @param spread how far the glow extends from the composable.
 */
fun Modifier.neonGlow(
    color: Color = ColorTokens.BrandBlue,
    radius: Dp = 12.dp,
    spread: Dp = 2.dp,
): Modifier = this.drawBehind {
    drawIntoCanvas { canvas ->
        val paint = Paint().apply {
            this.color = color
            this.asFrameworkPaint().apply {
                isAntiAlias = true
                setShadowLayer(radius.toPx(), 0f, 0f, color.toArgb())
            }
        }
        canvas.drawCircle(
            Offset(size.width / 2f, size.height / 2f),
            size.minDimension / 2f,
            paint,
        )
    }
}

/**
 * Coloured shadow — draws a tinted drop shadow behind the composable.
 *
 * Unlike Material 3's default elevation shadow (which is always black), this lets you
 * cast brand-tinted shadows — great for hero CTAs.
 *
 * @param color shadow tint colour.
 * @param blur shadow blur radius.
 * @param offsetY vertical offset (positive = down).
 * @param offsetX horizontal offset (positive = right).
 */
fun Modifier.coloredShadow(
    color: Color = Color.Black.copy(alpha = 0.25f),
    blur: Dp = 16.dp,
    offsetY: Dp = 4.dp,
    offsetX: Dp = 0.dp,
): Modifier = this.drawBehind {
    drawIntoCanvas { canvas ->
        val paint = Paint().apply {
            this.color = color
            this.asFrameworkPaint().apply {
                isAntiAlias = true
                setShadowLayer(blur.toPx(), offsetX.toPx(), offsetY.toPx(), color.toArgb())
            }
        }
        canvas.drawRoundRect(
            0f,
            0f,
            size.width,
            size.height,
            size.minDimension / 4f,
            size.minDimension / 4f,
            paint,
        )
    }
}

/**
 * Clip to circle — convenience modifier for circular shapes.
 *
 * Equivalent to `Modifier.clip(ShapeTokens.Full)` but reads more naturally at call sites
 * where the intent is explicitly "make this circular".
 */
fun Modifier.clipToCircle(): Modifier = this.clip(ShapeTokens.Full)

/**
 * Slide on appear — animates a slide-up + fade-in when the composable enters composition.
 *
 * Designed for staggered list entrances: pass the item [index] and the modifier will
 * compute an appropriate stagger delay (50 ms × index, capped at 20 items).
 *
 * @param index zero-based item index for stagger delay.
 * @param slideDistance how far the composable slides up (in dp).
 * @param durationMs animation duration in milliseconds.
 */
@Composable
fun Modifier.slideOnAppear(
    index: Int = 0,
    slideDistance: Dp = 24.dp,
    durationMs: Int = MotionTokens.DurationMedium,
): Modifier {
    val staggerDelay = if (index < 20) index * 50 else 0
    val alpha by animateFloatAsState(
        1f,
        tween(durationMs, staggerDelay, MotionTokens.EasingEmphasizedDecelerate),
        label = "slideAlpha",
    )
    val offsetY by animateFloatAsState(
        0f,
        tween(durationMs, staggerDelay, MotionTokens.EasingEmphasizedDecelerate),
        label = "slideOffset",
    )
    return this.graphicsLayer {
        translationY = slideDistance.toPx() * (1f - alpha)
        this.alpha = alpha
    }
}

/**
 * Conditional modifier — applies [modifier] only when [condition] is `true`.
 *
 * Useful for inline conditional styling without breaking the modifier chain.
 */
fun Modifier.applyIf(condition: Boolean, modifier: Modifier.() -> Modifier): Modifier =
    if (condition) this.modifier() else this



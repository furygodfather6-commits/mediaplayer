package com.titan.filemanager.core.designsystem.icon

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Subject
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.BrokenImage
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContactPage
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.FontDownload
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Stream
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.titan.filemanager.core.designsystem.tokens.ColorTokens

/**
 * ## FileTypeIcon
 *
 * Maps a file extension to its representative [ImageVector] and tint [Color].
 *
 * ### Why an icon registry?
 * File managers need to render hundreds of different file types, but the actual icon
 * vocabulary is small: image, video, audio, document, archive, code, etc. Mapping
 * every known extension to one of these "categories" — and pairing it with the
 * matching brand tint — gives every file a recognisable visual identity without
 * shipping hundreds of bespoke icons.
 *
 * ### Usage
 * ```
 * val icon = FileTypeIcon.fromPath("/sdcard/photo.jpg")
 * Icon(icon.imageVector, null, tint = icon.color)
 * ```
 *
 * ### Extension to custom types
 * Use [FileTypeIconRegistry.register] to register a custom icon for a new extension.
 * The registry takes precedence over [fromExtension], so apps can override the
 * built-in mappings without modifying this file.
 *
 * @property imageVector the Material [ImageVector] to render.
 * @property color the tint colour to apply to the icon.
 */
data class FileTypeIcon(
    val imageVector: ImageVector,
    val color: Color,
) {
    companion object {
        /**
         * Returns a [FileTypeIcon] for the given file extension.
         *
         * The lookup is case-insensitive. Unrecognised extensions fall back to
         * [ColorTokens.FileGeneric] with the generic file icon.
         *
         * @param ext file extension WITHOUT the leading dot (e.g. `"jpg"`, not `".jpg"`).
         */
        fun fromExtension(ext: String): FileTypeIcon {
            val lower = ext.lowercase()
            return when (lower) {
                // ── Image formats ──
                "jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif",
                "avif", "tiff", "tif", "raw", "cr2", "nef", "svg", "ico",
                "psd", "ai", "sketch", "xcf" ->
                    FileTypeIcon(Icons.Filled.Image, ColorTokens.FileImage)

                // ── Video formats ──
                "mp4", "mkv", "avi", "mov", "wmv", "flv", "webm", "3gp",
                "ts", "m4v", "mpg", "mpeg", "vob", "ogv", "rm", "rmvb", "m2ts" ->
                    FileTypeIcon(Icons.Filled.VideoFile, ColorTokens.FileVideo)

                // ── Audio formats ──
                "mp3", "flac", "aac", "ogg", "wav", "m4a", "wma", "opus",
                "aiff", "mid", "midi", "amr", "oga", "mka" ->
                    FileTypeIcon(Icons.Filled.AudioFile, ColorTokens.FileAudio)

                // ── PDF ──
                "pdf" -> FileTypeIcon(Icons.Filled.PictureAsPdf, ColorTokens.FileDocument)

                // ── Office document formats ──
                "doc", "docx", "odt", "rtf", "xls", "xlsx", "ods", "csv",
                "ppt", "pptx", "odp", "pages", "numbers", "keynote" ->
                    FileTypeIcon(Icons.Filled.Description, ColorTokens.FileDocument)

                // ── E-book formats ──
                "epub", "mobi", "azw", "azw3", "fb2", "lit", "lrf" ->
                    FileTypeIcon(Icons.Filled.Description, ColorTokens.FileEbook)

                // ── Archive formats ──
                "zip", "rar", "7z", "tar", "gz", "bz2", "xz", "jar", "apk", "aab",
                "zst", "lz", "lzma", "cab", "iso", "dmg" ->
                    FileTypeIcon(Icons.Filled.Archive, ColorTokens.FileArchive)

                // ── APK / app packages (more specific than archive) ──
                "xapk", "apks", "apkm" ->
                    FileTypeIcon(Icons.Filled.Archive, ColorTokens.FileApk)

                // ── Source code ──
                "kt", "java", "py", "js", "ts", "cpp", "c", "h", "hpp",
                "swift", "go", "rs", "rb", "php", "sh", "bash", "sql",
                "dart", "json", "xml", "yaml", "yml", "toml", "html", "htm",
                "css", "scss", "less", "lua", "pl", "r", "scala", "groovy",
                "gradle", "kts", "jsx", "tsx", "vue", "svelte" ->
                    FileTypeIcon(Icons.Filled.Code, ColorTokens.FileCode)

                // ── Plain text & notes ──
                "txt", "log", "md", "markdown", "ini", "cfg", "conf", "env",
                "properties", "rst", "tex", "org" ->
                    FileTypeIcon(Icons.AutoMirrored.Filled.Subject, ColorTokens.FileText)

                // ── Contacts ──
                "vcf", "vcard" ->
                    FileTypeIcon(Icons.Filled.ContactPage, ColorTokens.FileContact)

                // ── Calendar ──
                "ics", "ical", "ifb" ->
                    FileTypeIcon(Icons.Filled.CalendarMonth, ColorTokens.FileCalendar)

                // ── Fonts ──
                "ttf", "otf", "woff", "woff2", "eot" ->
                    FileTypeIcon(Icons.Filled.FontDownload, ColorTokens.FileFont)

                // ── Torrents ──
                "torrent" ->
                    FileTypeIcon(Icons.Filled.Stream, ColorTokens.FileTorrent)

                // ── 3D / vector design ──
                "blend", "obj", "fbx", "gltf", "glb", "stl", "3ds" ->
                    FileTypeIcon(Icons.Filled.ViewInAr, ColorTokens.File3d)

                // ── Backup files ──
                "bak", "old", "tmp", "swp" ->
                    FileTypeIcon(Icons.Filled.InsertDriveFile, ColorTokens.FileBackup)

                // ── Unknown ──
                else -> FileTypeIcon(Icons.Filled.InsertDriveFile, ColorTokens.FileGeneric)
            }
        }

        /**
         * Returns a [FileTypeIcon] for the file at [path].
         *
         * Extracts the extension from the last `.` in the path (case-insensitive).
         * Files with no extension resolve to the generic-file icon.
         *
         * @param path full or relative file path.
         */
        fun fromPath(path: String): FileTypeIcon =
            fromExtension(path.substringAfterLast('.', ""))

        /** Returns a [FileTypeIcon] for the given file category name (case-insensitive). */
        fun fromCategory(category: String): FileTypeIcon = when (category.lowercase()) {
            "image", "photo" -> FileTypeIcon(Icons.Filled.Image, ColorTokens.FileImage)
            "video", "movie" -> FileTypeIcon(Icons.Filled.VideoFile, ColorTokens.FileVideo)
            "audio", "music" -> FileTypeIcon(Icons.Filled.AudioFile, ColorTokens.FileAudio)
            "document", "doc" -> FileTypeIcon(Icons.Filled.Description, ColorTokens.FileDocument)
            "archive", "zip" -> FileTypeIcon(Icons.Filled.Archive, ColorTokens.FileArchive)
            "code", "source" -> FileTypeIcon(Icons.Filled.Code, ColorTokens.FileCode)
            "apk", "app" -> FileTypeIcon(Icons.Filled.Archive, ColorTokens.FileApk)
            "text", "txt" -> FileTypeIcon(Icons.AutoMirrored.Filled.Subject, ColorTokens.FileText)
            "folder", "dir" -> Folder
            "contact", "vcf" -> FileTypeIcon(Icons.Filled.ContactPage, ColorTokens.FileContact)
            "calendar", "ics" -> FileTypeIcon(Icons.Filled.CalendarMonth, ColorTokens.FileCalendar)
            "ebook", "epub" -> FileTypeIcon(Icons.Filled.Description, ColorTokens.FileEbook)
            "font", "ttf" -> FileTypeIcon(Icons.Filled.FontDownload, ColorTokens.FileFont)
            "torrent" -> FileTypeIcon(Icons.Filled.Stream, ColorTokens.FileTorrent)
            "3d", "model" -> FileTypeIcon(Icons.Filled.ViewInAr, ColorTokens.File3d)
            "backup", "bak" -> FileTypeIcon(Icons.Filled.InsertDriveFile, ColorTokens.FileBackup)
            else -> FileTypeIcon(Icons.Filled.InsertDriveFile, ColorTokens.FileGeneric)
        }

        /** Pre-built folder icon (always uses [ColorTokens.FileFolder]). */
        val Folder = FileTypeIcon(Icons.Filled.Folder, ColorTokens.FileFolder)

        /** Pre-built folder icon for outlined / collapsed state. */
        val FolderOutlined = FileTypeIcon(Icons.Outlined.Folder, ColorTokens.FileFolder)

        /** Pre-built broken-image icon used for failed thumbnail loads. */
        val BrokenImage = FileTypeIcon(Icons.Filled.BrokenImage, ColorTokens.FileGeneric)
    }
}

/**
 * ## FileTypeIconRegistry
 *
 * Runtime registry for custom [FileTypeIcon] overrides.
 *
 * Apps that ship their own icon set can register per-extension icons at startup;
 * [resolve] checks the registry first and falls back to [FileTypeIcon.fromExtension].
 *
 * ### Example
 * ```
 * FileTypeIconRegistry.register("titan", FileTypeIcon(MyIcons.Titan, Color.Magenta))
 * val icon = FileTypeIconRegistry.resolve("titan") // returns MyIcons.Titan
 * ```
 */
object FileTypeIconRegistry {
    private val customIcons = mutableMapOf<String, FileTypeIcon>()

    /** Registers a custom [icon] for the given [extension] (case-insensitive). */
    fun register(extension: String, icon: FileTypeIcon) {
        customIcons[extension.lowercase()] = icon
    }

    /** Removes any custom icon registered for [extension]. */
    fun unregister(extension: String) {
        customIcons.remove(extension.lowercase())
    }

    /** Returns the registered icon for [extension], or `null` if none is registered. */
    fun get(extension: String): FileTypeIcon? = customIcons[extension.lowercase()]

    /** Resolves the icon for [extension] — registry first, then [FileTypeIcon.fromExtension]. */
    fun resolve(extension: String): FileTypeIcon =
        get(extension) ?: FileTypeIcon.fromExtension(extension)

    /** Resolves the icon for a full file [path]. */
    fun resolvePath(path: String): FileTypeIcon = resolve(path.substringAfterLast('.', ""))

    /** Returns `true` if a custom icon is registered for [extension]. */
    fun isRegistered(extension: String): Boolean = customIcons.containsKey(extension.lowercase())

    /** Returns a snapshot of all registered extensions. */
    fun registeredExtensions(): Set<String> = customIcons.keys.toSet()

    /** Clears all registered custom icons. */
    fun clear() = customIcons.clear()
}

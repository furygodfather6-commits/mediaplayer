package com.titan.filemanager.core.designsystem.animation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.ContentTransform
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import com.titan.filemanager.core.designsystem.tokens.MotionTokens

/**
 * # ScreenTransitions
 *
 * Reusable navigation transitions for the TitanFileManager design system.
 *
 * ## Why centralised transitions?
 * Jetpack Navigation for Compose asks the developer to pass lambda factories that build
 * [ContentTransform] instances for each navigation event. Without a shared library, every
 * screen ends up hand-rolling `slideInHorizontally + fadeIn`, which leads to drift:
 * different durations, different easings, different slide directions. This object pins every
 * transition to the [MotionTokens] scale so every screen feels the same.
 *
 * ## Naming convention
 * - `slideInFromX` / `slideOutToX` — directional slides.
 * - `fadeInTransition` / `fadeOutTransition` — pure opacity.
 * - `scaleInTransition` / `scaleOutTransition` — scale + fade.
 * - Compound transitions (`forwardNavigation`, `tabSwitch`, `dialogTransition`, …) pair
 *   enter + exit into a complete [ContentTransform] for use with `NavHost`'s `enterTransition`
 *   / `exitTransition` parameters.
 *
 * ## Usage with Navigation for Compose
 * ```
 * NavHost(
 *     navController = navController,
 *     startDestination = "home",
 *     enterTransition = { ScreenTransitions.forwardNavigation() },
 *     exitTransition = { ScreenTransitions.forwardNavigationExit() },
 *     popEnterTransition = { ScreenTransitions.backwardNavigationEnter() },
 *     popExitTransition = { ScreenTransitions.backwardNavigation() },
 * ) {
 *     composable("home") { HomeScreen() }
 *     composable("details") { DetailsScreen() }
 * }
 * ```
 */
object ScreenTransitions {

    // ─────────────────────────────────────────────────────────────
    // Directional slide enter / exit transitions
    // ─────────────────────────────────────────────────────────────

    /** Enter transition: new screen slides in from the right + fades in. */
    val slideInFromRight: AnimatedContentTransitionScope<*>.() -> EnterTransition = {
        slideInHorizontally(
            tween(MotionTokens.DurationMedium, easing = MotionTokens.EasingEmphasizedDecelerate),
            { it },
        ) + fadeIn(tween(MotionTokens.DurationMedium))
    }

    /** Exit transition: outgoing screen slides out to the left + fades out. */
    val slideOutToLeft: AnimatedContentTransitionScope<*>.() -> ExitTransition = {
        slideOutHorizontally(
            tween(MotionTokens.DurationMedium, easing = MotionTokens.EasingEmphasizedAccelerate),
            { -it },
        ) + fadeOut(tween(MotionTokens.DurationMedium))
    }

    /** Enter transition: new screen slides in from the left + fades in (used for back navigation). */
    val slideInFromLeft: AnimatedContentTransitionScope<*>.() -> EnterTransition = {
        slideInHorizontally(
            tween(MotionTokens.DurationMedium, easing = MotionTokens.EasingEmphasizedDecelerate),
            { -it },
        ) + fadeIn(tween(MotionTokens.DurationMedium))
    }

    /** Exit transition: outgoing screen slides out to the right + fades out (used for back navigation). */
    val slideOutToRight: AnimatedContentTransitionScope<*>.() -> ExitTransition = {
        slideOutHorizontally(
            tween(MotionTokens.DurationMedium, easing = MotionTokens.EasingEmphasizedAccelerate),
            { it },
        ) + fadeOut(tween(MotionTokens.DurationMedium))
    }

    /** Enter transition: new screen slides in from the top + fades in. */
    val slideInFromTop: AnimatedContentTransitionScope<*>.() -> EnterTransition = {
        slideInVertically(
            tween(MotionTokens.DurationMedium, easing = MotionTokens.EasingEmphasizedDecelerate),
            { -it },
        ) + fadeIn(tween(MotionTokens.DurationMedium))
    }

    /** Exit transition: outgoing screen slides out to the top + fades out. */
    val slideOutToTop: AnimatedContentTransitionScope<*>.() -> ExitTransition = {
        slideOutVertically(
            tween(MotionTokens.DurationMedium, easing = MotionTokens.EasingEmphasizedAccelerate),
            { -it },
        ) + fadeOut(tween(MotionTokens.DurationMedium))
    }

    // ─────────────────────────────────────────────────────────────
    // Fade transitions
    // ─────────────────────────────────────────────────────────────

    /** Pure fade-in transition (no slide). Used for tab switches and inline content swaps. */
    val fadeInTransition: AnimatedContentTransitionScope<*>.() -> EnterTransition = {
        fadeIn(tween(MotionTokens.DurationFast))
    }

    /** Pure fade-out transition (no slide). */
    val fadeOutTransition: AnimatedContentTransitionScope<*>.() -> ExitTransition = {
        fadeOut(tween(MotionTokens.DurationFast))
    }

    /** Slow fade-in transition — used for hero / onboarding content. */
    val fadeInSlow: AnimatedContentTransitionScope<*>.() -> EnterTransition = {
        fadeIn(tween(MotionTokens.DurationSlow, easing = MotionTokens.EasingEmphasizedDecelerate))
    }

    /** Slow fade-out transition. */
    val fadeOutSlow: AnimatedContentTransitionScope<*>.() -> ExitTransition = {
        fadeOut(tween(MotionTokens.DurationSlow, easing = MotionTokens.EasingEmphasizedAccelerate))
    }

    // ─────────────────────────────────────────────────────────────
    // Scale transitions
    // ─────────────────────────────────────────────────────────────

    /** Scale-in transition (0.85 → 1.0) + fade-in. Used for dialogs and popovers. */
    val scaleInTransition: AnimatedContentTransitionScope<*>.() -> EnterTransition = {
        scaleIn(
            tween(MotionTokens.DurationMedium, easing = MotionTokens.EasingEmphasizedDecelerate),
            initialScale = 0.85f,
        ) + fadeIn(tween(MotionTokens.DurationMedium))
    }

    /** Scale-out transition (1.0 → 0.85) + fade-out. */
    val scaleOutTransition: AnimatedContentTransitionScope<*>.() -> ExitTransition = {
        scaleOut(
            tween(MotionTokens.DurationFast, easing = MotionTokens.EasingEmphasizedAccelerate),
            targetScale = 0.85f,
        ) + fadeOut(tween(MotionTokens.DurationFast))
    }

    /** Pop-in transition (0.5 → 1.0) with bouncy easing. Used for FAB / success celebrations. */
    val popInTransition: AnimatedContentTransitionScope<*>.() -> EnterTransition = {
        scaleIn(
            tween(MotionTokens.DurationMedium, easing = MotionTokens.EasingBouncy),
            initialScale = 0.5f,
        ) + fadeIn(tween(MotionTokens.DurationFast))
    }

    /** Pop-out transition (1.0 → 0.5) with bouncy easing. */
    val popOutTransition: AnimatedContentTransitionScope<*>.() -> ExitTransition = {
        scaleOut(
            tween(MotionTokens.DurationFast, easing = MotionTokens.EasingBouncy),
            targetScale = 0.5f,
        ) + fadeOut(tween(MotionTokens.DurationFast))
    }

    // ─────────────────────────────────────────────────────────────
    // Vertical slide transitions (for bottom sheets & vertical navigation)
    // ─────────────────────────────────────────────────────────────

    /** Enter transition: new screen slides in from the bottom + fades in. */
    val slideInFromBottom: AnimatedContentTransitionScope<*>.() -> EnterTransition = {
        slideInVertically(
            tween(MotionTokens.DurationMedium, easing = MotionTokens.EasingEmphasizedDecelerate),
            { it },
        ) + fadeIn(tween(MotionTokens.DurationMedium))
    }

    /** Exit transition: outgoing screen slides out to the bottom + fades out. */
    val slideOutToBottom: AnimatedContentTransitionScope<*>.() -> ExitTransition = {
        slideOutVertically(
            tween(MotionTokens.DurationMedium, easing = MotionTokens.EasingEmphasizedAccelerate),
            { it },
        ) + fadeOut(tween(MotionTokens.DurationMedium))
    }

    /** Enter transition: new screen slides up from the bottom WITHOUT fade (for full-height sheets). */
    val slideInFromBottomNoFade: AnimatedContentTransitionScope<*>.() -> EnterTransition = {
        slideInVertically(
            tween(MotionTokens.DurationMedium, easing = MotionTokens.EasingEmphasizedDecelerate),
            { it },
        )
    }

    /** Exit transition: outgoing screen slides down to the bottom WITHOUT fade. */
    val slideOutToBottomNoFade: AnimatedContentTransitionScope<*>.() -> ExitTransition = {
        slideOutVertically(
            tween(MotionTokens.DurationMedium, easing = MotionTokens.EasingEmphasizedAccelerate),
            { it },
        )
    }

    // ─────────────────────────────────────────────────────────────
    // Compound ContentTransform factories
    // ─────────────────────────────────────────────────────────────

    /** Forward navigation: incoming slides from right, outgoing slides to left. */
    val forwardNavigation: AnimatedContentTransitionScope<*>.() -> ContentTransform = {
        slideInFromRight() togetherWith slideOutToLeft()
    }

    /** Backward navigation: incoming slides from left, outgoing slides to right. */
    val backwardNavigation: AnimatedContentTransitionScope<*>.() -> ContentTransform = {
        slideInFromLeft() togetherWith slideOutToRight()
    }

    /** Forward navigation exit-only (use with popExitTransition). */
    val forwardNavigationExit: AnimatedContentTransitionScope<*>.() -> ExitTransition = {
        slideOutToLeft()
    }

    /** Backward navigation enter-only (use with popEnterTransition). */
    val backwardNavigationEnter: AnimatedContentTransitionScope<*>.() -> EnterTransition = {
        slideInFromLeft()
    }

    /** Tab switch: pure fade. */
    val tabSwitch: AnimatedContentTransitionScope<*>.() -> ContentTransform = {
        fadeInTransition() togetherWith fadeOutTransition()
    }

    /** Slow tab switch: longer fade, for hero / onboarding tab changes. */
    val tabSwitchSlow: AnimatedContentTransitionScope<*>.() -> ContentTransform = {
        fadeInSlow() togetherWith fadeOutSlow()
    }

    /** Dialog transition: scale-in + scale-out. */
    val dialogTransition: AnimatedContentTransitionScope<*>.() -> ContentTransform = {
        scaleInTransition() togetherWith scaleOutTransition()
    }

    /** Pop transition: bouncy pop-in + pop-out. Used for success celebrations. */
    val popTransition: AnimatedContentTransitionScope<*>.() -> ContentTransform = {
        popInTransition() togetherWith popOutTransition()
    }

    /** Bottom sheet transition: slide-in + slide-out (vertical). */
    val bottomSheetTransition: AnimatedContentTransitionScope<*>.() -> ContentTransform = {
        slideInFromBottom() togetherWith slideOutToBottom()
    }

    /** Bottom sheet transition (no fade variant) — for full-height sheets. */
    val bottomSheetTransitionNoFade: AnimatedContentTransitionScope<*>.() -> ContentTransform = {
        slideInFromBottomNoFade() togetherWith slideOutToBottomNoFade()
    }

    /** None — no transition. Used when reduced motion is enabled. */
    val none: AnimatedContentTransitionScope<*>.() -> ContentTransform = {
        EnterTransition.None togetherWith ExitTransition.None
    }
}

/**
 * # StaggerAnimation
 *
 * Helpers for staggered list / grid entrance animations.
 *
 * ## Why stagger?
 * When a list of N items appears, animating them all simultaneously looks like a "flicker".
 * Staggering — delaying each item's animation by a small offset (e.g. 50 ms) — produces a
 * satisfying cascade that draws the eye down the list. This object provides:
 * - [staggerDelay] — pure delay computation (for use with `tween(delayMillis = …)`).
 * - [staggerSpec] — ready-to-use [FiniteAnimationSpec] with built-in stagger.
 */
object StaggerAnimation {
    /** 50 ms — default per-item stagger offset. */
    const val DefaultStaggerDelay = 50

    /** 20 — maximum items that will stagger; items beyond this animate simultaneously. */
    const val MaxStaggerItems = 20

    /** 25 ms — faster stagger for dense grids (e.g. image thumbnails). */
    const val DenseStaggerDelay = 25

    /** 100 ms — slower stagger for hero lists (e.g. onboarding cards). */
    const val HeroStaggerDelay = 100

    /**
     * Computes the stagger delay for the item at [index].
     *
     * @param index zero-based item index.
     * @param delayMs per-item delay in milliseconds.
     * @return total delay in milliseconds (capped at [MaxStaggerItems] × [delayMs]).
     */
    fun staggerDelay(index: Int, delayMs: Int = DefaultStaggerDelay): Int =
        if (index < MaxStaggerItems) index * delayMs else 0

    /**
     * Builds a [FiniteAnimationSpec] for the item at [index] with a built-in stagger delay.
     *
     * @param index zero-based item index.
     * @param durationMs animation duration in milliseconds.
     * @param delayMs per-item stagger offset in milliseconds.
     */
    fun <T> staggerSpec(
        index: Int,
        durationMs: Int = MotionTokens.DurationMedium,
        delayMs: Int = DefaultStaggerDelay,
    ): FiniteAnimationSpec<T> = tween(
        durationMs,
        staggerDelay(index, delayMs),
        MotionTokens.EasingEmphasizedDecelerate,
    )

    /**
     * Builds a spring-based stagger spec — used for bouncy list entrances.
     *
     * @param index zero-based item index.
     */
    fun <T> staggerSpringSpec(index: Int): FiniteAnimationSpec<T> = spring(
        dampingRatio = Spring.DampingRatioMediumBouncy,
        stiffness = Spring.StiffnessMediumLow,
        visibilityThreshold = null,
    ).let { spec ->
        // Spring doesn't support delayMillis directly; wrap in a tween-style with delay using keyframes with initial hold.
        // Since FiniteAnimationSpec is the type, we fall back to tween here to support delay.
        tween(staggerDelay(index) + MotionTokens.DurationMedium, staggerDelay(index), MotionTokens.EasingBouncy)
    }

    /** Returns a list of stagger delays for the first [count] items. */
    fun staggerDelays(count: Int, delayMs: Int = DefaultStaggerDelay): List<Int> =
        (0 until count).map { staggerDelay(it, delayMs) }
}

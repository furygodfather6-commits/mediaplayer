package com.titan.filemanager.core.designsystem.tokens

import androidx.compose.ui.unit.dp

/**
 * # SpacingTokens
 *
 * Centralised spacing scale for the TitanFileManager design system.
 *
 * ## Why a spacing scale matters
 * Enterprise apps live and die by visual rhythm. When every padding, gap, and margin
 * snaps to the same 4-dp grid, screens feel calm and predictable. Hard-coding `16.dp`
 * in 200 places produces drift: somebody uses `14.dp`, somebody else `18.dp`, and the UI
 * starts to feel "off". This file replaces all of those magic numbers with named tokens.
 *
 * ## Naming convention
 * - **T-shirt scale** (`Xxs` → `Huge`) for raw values — composable, predictable multipliers.
 * - **Semantic aliases** (`ScreenHorizontal`, `ItemSpacing`, …) that map to the raw tokens
 *   and describe WHERE the spacing is used. These are the names you'll reach for 95% of the time.
 * - **Component-specific dimensions** (`FabSize`, `TopBarHeight`, …) keep magic numbers
 *   out of component code.
 *
 * ## The 4-dp baseline
 * Every raw value is a multiple of 4 dp (with `Xxs = 2.dp` as a deliberate exception for
 * hairline gaps). This guarantees alignment across the entire app.
 */
object SpacingTokens {
    // ─────────────────────────────────────────────────────────────
    // Raw T-shirt scale
    // ─────────────────────────────────────────────────────────────
    /** Zero spacing — useful for conditional layouts where you need to "opt out". */
    val None = 0.dp
    /** Hairline gap (2 dp) — dividers between tightly grouped items. */
    val Xxs = 2.dp
    /** Smallest meaningful spacing (4 dp) — icon-to-text in tight chips. */
    val Xs = 4.dp
    /** Small spacing (8 dp) — default item spacing inside a card. */
    val Sm = 8.dp
    /** Medium spacing (12 dp) — gap between sections in a list. */
    val Md = 12.dp
    /** Large spacing (16 dp) — default screen horizontal padding. */
    val Lg = 16.dp
    /** Extra-large spacing (24 dp) — section breaks within a screen. */
    val Xl = 24.dp
    /** Extra-extra-large spacing (32 dp) — between major content blocks. */
    val Xxl = 32.dp
    /** Extra-extra-extra-large spacing (48 dp) — top of empty-state hero areas. */
    val Xxxl = 48.dp
    /** Huge spacing (64 dp) — page-level vertical rhythm. */
    val Huge = 64.dp
    /** Massive spacing (80 dp) — used by full-screen illustrations and splash screens. */
    val Massive = 80.dp
    /** Colossal spacing (96 dp) — reserved for hero compositions. */
    val Colossal = 96.dp

    // ─────────────────────────────────────────────────────────────
    // Screen layout
    // ─────────────────────────────────────────────────────────────
    /** Standard horizontal padding for full-bleed screens — keeps content off the gesture edge. */
    val ScreenHorizontal = Lg
    /** Standard vertical padding for full-bleed screens. */
    val ScreenVertical = Lg
    /** Tablet horizontal padding (24 dp) — wider gutters on large screens. */
    val ScreenHorizontalTablet = Xl
    /** Desktop horizontal padding (32 dp) — used in two-pane master-detail layouts. */
    val ScreenHorizontalDesktop = Xxl
    /** Default content padding inside cards and sheets. */
    val ContentPadding = Lg
    /** Compact content padding for dense UIs (chips, badges, dense lists). */
    val ContentPaddingSmall = Sm
    /** Generous content padding for hero / onboarding cards. */
    val ContentPaddingLarge = Xl
    /** Extra-generous content padding for full-screen dialogs. */
    val ContentPaddingXl = Xxl

    // ─────────────────────────────────────────────────────────────
    // Item / list spacing
    // ─────────────────────────────────────────────────────────────
    /** Default spacing between items in a row or column. */
    val ItemSpacing = Sm
    /** Tiny spacing between tightly grouped items (chips, badges). */
    val ItemSpacingTiny = Xs
    /** Larger spacing between sections or distinct groups. */
    val ItemSpacingLarge = Md
    /** Extra-large spacing between major sections in a scrollable list. */
    val ItemSpacingXl = Lg
    /** Section break spacing between top-level content areas. */
    val SectionSpacing = Xl
    /** Spacing between the title and body inside a section header. */
    val SectionHeaderSpacing = Xs

    // ─────────────────────────────────────────────────────────────
    // Iconography
    // ─────────────────────────────────────────────────────────────
    val IconSmall = 16.dp
    val IconMedium = 24.dp
    val IconLarge = 32.dp
    val IconXl = 48.dp
    val IconXxl = 64.dp
    val IconXxxl = 96.dp
    /** Icon size used inside list-item trailing slots. */
    val IconListItem = 20.dp
    /** Icon size used inside small chip components. */
    val IconChip = 16.dp
    /** Icon size for empty-state hero illustrations. */
    val IconHero = 80.dp

    // ─────────────────────────────────────────────────────────────
    // Avatars & thumbnails
    // ─────────────────────────────────────────────────────────────
    val AvatarSmall = 32.dp
    val AvatarMedium = 40.dp
    val AvatarLarge = 56.dp
    val AvatarXl = 72.dp
    val AvatarXxl = 96.dp

    // ─────────────────────────────────────────────────────────────
    // Touch targets (WCAG 2.5.5 minimum is 44 dp; we use 48 dp)
    // ─────────────────────────────────────────────────────────────
    val TouchTargetMin = 48.dp
    val TouchTargetSmall = 40.dp
    val TouchTargetLarge = 56.dp
    val TouchTargetXl = 72.dp

    // ─────────────────────────────────────────────────────────────
    // Strokes, borders, dividers
    // ─────────────────────────────────────────────────────────────
    val DividerThickness = 1.dp
    val DividerThicknessThick = 2.dp
    val BorderThickness = 1.dp
    val BorderThick = 2.dp
    val BorderXl = 3.dp
    val Hairline = 0.5.dp

    // ─────────────────────────────────────────────────────────────
    // Thumbnail / preview sizes
    // ─────────────────────────────────────────────────────────────
    val ThumbMicro = 48.dp
    val ThumbSmall = 96.dp
    val ThumbMedium = 160.dp
    val ThumbLarge = 256.dp
    val ThumbXl = 512.dp
    val ThumbXxl = 768.dp
    /** Default grid tile height for image gallery. */
    val GridTileHeight = 120.dp
    /** Default grid tile width for image gallery. */
    val GridTileWidth = 120.dp

    // ─────────────────────────────────────────────────────────────
    // Sheets & dialogs
    // ─────────────────────────────────────────────────────────────
    val SheetCorner = 28.dp
    val DialogCorner = 28.dp
    val SheetPeekHeight = 96.dp
    val SheetExpandedHeight = 0.dp // 0 = full screen
    val DialogMaxWidth = 560.dp
    val DialogMaxHeight = 400.dp

    // ─────────────────────────────────────────────────────────────
    // Navigation chrome
    // ─────────────────────────────────────────────────────────────
    val NavRailWidth = 80.dp
    val NavBarHeight = 80.dp
    val NavBarHeightCompact = 64.dp
    val TopBarHeight = 64.dp
    val TopBarHeightLarge = 152.dp
    val TopBarHeightMedium = 100.dp
    val TopBarHeightScrolling = 56.dp
    val SideSheetWidth = 360.dp
    val DrawerWidth = 320.dp
    val DrawerWidthExpanded = 400.dp
    val DrawerItemHeight = 56.dp

    // ─────────────────────────────────────────────────────────────
    // FAB
    // ─────────────────────────────────────────────────────────────
    val FabSize = 56.dp
    val FabSizeSmall = 40.dp
    val FabSizeLarge = 96.dp
    val FabSpacing = 16.dp
    val FabExtendedHeight = 56.dp
    val FabExtendedIconPadding = 12.dp

    // ─────────────────────────────────────────────────────────────
    // Semantic helper aliases
    // ─────────────────────────────────────────────────────────────
    /** Padding used inside a single-line list item. */
    val ListItemPaddingVertical = Sm
    val ListItemPaddingHorizontal = Lg
    /** Padding used inside a card. */
    val CardPadding = Lg
    val CardPaddingCompact = Md
    val CardPaddingSpacious = Xl
    /** Spacing between a chip group and adjacent content. */
    val ChipGroupSpacing = Xs
    /** Padding inside a button (horizontal). */
    val ButtonPaddingHorizontal = 24.dp
    val ButtonPaddingVertical = 8.dp
    /** Padding inside an outlined button (slightly less to account for border). */
    val ButtonOutlinedPaddingHorizontal = 23.dp
    /** Padding for a tooltip bubble. */
    val TooltipPaddingHorizontal = 8.dp
    val TooltipPaddingVertical = 6.dp

    // ─────────────────────────────────────────────────────────────
    // Convenience operators
    // ─────────────────────────────────────────────────────────────
    /** Multiplies a [SpacingTokens] value by an integer scalar — useful for grid layouts. */
    operator fun times(multiplier: Int): androidx.compose.ui.unit.Dp = Lg * multiplier

    /** Returns the appropriate screen horizontal padding for the given window width class. */
    fun screenHorizontalFor(widthDp: Int): androidx.compose.ui.unit.Dp = when {
        widthDp < 600 -> ScreenHorizontal
        widthDp < 840 -> ScreenHorizontalTablet
        else -> ScreenHorizontalDesktop
    }
}

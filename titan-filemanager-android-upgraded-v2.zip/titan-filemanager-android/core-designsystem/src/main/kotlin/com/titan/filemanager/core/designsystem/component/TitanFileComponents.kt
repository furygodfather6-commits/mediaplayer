package com.titan.filemanager.core.designsystem.component

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BrokenImage
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.OfflineBolt
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.titan.filemanager.core.designsystem.icon.FileTypeIcon
import com.titan.filemanager.core.designsystem.modifier.bounceClick
import com.titan.filemanager.core.designsystem.modifier.clipToCircle
import com.titan.filemanager.core.designsystem.modifier.clipToRounded
import com.titan.filemanager.core.designsystem.tokens.ElevationTokens
import com.titan.filemanager.core.designsystem.tokens.ShapeTokens
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens

/**
 * ## TitanFileTile
 *
 * Enterprise file tile — a single-row list item for displaying a file or folder.
 *
 * ### Anatomy
 * ```
 * ┌──┬──────┬─────────────────────────────┬──────┐
 * │✓│ 📁  │ Documents                   │ ⋮    │
 * │ │     │ 12 items • 2024-01-15       │      │
 * └──┴──────┴─────────────────────────────┴──────┘
 *  sel  icon    name (bold if dir)        more
 *        meta: size • count • date
 * ```
 *
 * ### Customisation
 * - [isSelected] — when `true`, shows a leading check-mark circle.
 * - [showThumbnail] — when `true` AND [thumbnailContent] is non-null, renders the
 *   thumbnail content in place of the file-type icon.
 * - [onMoreClick] — when non-null, renders a trailing "more" button. When `null` and
 *   [isDirectory] is `true`, a chevron-right is shown instead.
 *
 * @param name file or folder name.
 * @param isDirectory `true` for directories (gets bold name + chevron).
 * @param modifier modifier applied to the row.
 * @param path full path — used to derive the file-type icon.
 * @param size optional formatted size string (e.g., "2.4 MB").
 * @param date optional formatted date string.
 * @param childCount optional formatted child-count string (e.g., "12 items").
 * @param isSelected when `true`, shows a leading check-mark.
 * @param showThumbnail when `true`, defers to [thumbnailContent] for the icon slot.
 * @param thumbnailContent optional composable rendered in place of the file-type icon.
 * @param onClick click handler.
 * @param onLongClick long-click handler — currently unused but reserved for future
 *                   gesture hooks (selection mode entry, etc.).
 * @param onMoreClick optional trailing "more" button handler.
 * @param isEncrypted when `true`, shows a lock badge next to the file name.
 * @param isStarred when `true`, shows a star badge next to the file name.
 * @param isSynced when `true`, shows a cloud-done badge next to the file name.
 * @param isOffline when `true`, shows an offline bolt badge next to the file name.
 */
@Composable
fun TitanFileTile(
    name: String,
    isDirectory: Boolean,
    modifier: Modifier = Modifier,
    path: String = "",
    size: String? = null,
    date: String? = null,
    childCount: String? = null,
    isSelected: Boolean = false,
    showThumbnail: Boolean = false,
    thumbnailContent: @Composable (() -> Unit)? = null,
    onClick: () -> Unit = {},
    onLongClick: () -> Unit = {},
    onMoreClick: (() -> Unit)? = null,
    isEncrypted: Boolean = false,
    isStarred: Boolean = false,
    isSynced: Boolean = false,
    isOffline: Boolean = false,
) {
    val icon = if (isDirectory) FileTypeIcon.Folder else FileTypeIcon.fromPath(path)
    Row(
        modifier = modifier
            .fillMaxWidth()
            .bounceClick(onClick = onClick)
            .background(if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f) else Color.Transparent)
            .padding(horizontal = SpacingTokens.ScreenHorizontal, vertical = SpacingTokens.Sm),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (isSelected) {
            Box(
                Modifier.size(24.dp).clipToCircle().background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    Icons.Filled.Check,
                    "Selected",
                    tint = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(16.dp),
                )
            }
            Spacer(Modifier.width(SpacingTokens.Sm))
        }
        if (showThumbnail && thumbnailContent != null) {
            Box(Modifier.size(40.dp).clipToRounded(8.dp)) { thumbnailContent() }
        } else {
            Icon(icon.imageVector, null, Modifier.size(40.dp), tint = icon.color)
        }
        Spacer(Modifier.width(SpacingTokens.Lg))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    name,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    fontWeight = if (isDirectory) FontWeight.Medium else FontWeight.Normal,
                    modifier = Modifier.weight(1f, fill = false),
                )
                if (isEncrypted) {
                    Spacer(Modifier.width(SpacingTokens.Xs))
                    Icon(Icons.Filled.Lock, "Encrypted", Modifier.size(14.dp), tint = MaterialTheme.colorScheme.tertiary)
                }
                if (isStarred) {
                    Spacer(Modifier.width(SpacingTokens.Xs))
                    Icon(Icons.Filled.Star, "Starred", Modifier.size(14.dp), tint = MaterialTheme.colorScheme.tertiary)
                }
                if (isSynced) {
                    Spacer(Modifier.width(SpacingTokens.Xs))
                    Icon(Icons.Filled.CloudDone, "Synced", Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
                }
                if (isOffline) {
                    Spacer(Modifier.width(SpacingTokens.Xs))
                    Icon(Icons.Filled.OfflineBolt, "Available offline", Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
                }
            }
            val metaText = buildList {
                size?.let { add(it) }
                childCount?.let { add(it) }
                date?.let { add(it) }
            }.joinToString(" • ")
            if (metaText.isNotEmpty()) {
                Text(
                    metaText,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        if (onMoreClick != null) {
            IconButton(onClick = onMoreClick) {
                Icon(Icons.Filled.MoreVert, "More", tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else if (isDirectory) {
            Icon(Icons.Filled.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/**
 * ## TitanFileGridItem
 *
 * Enterprise file grid item — card-style item for grid layouts.
 *
 * ### Anatomy
 * ```
 * ┌────────────┐
 * │            │
 * │   [icon]   │  ← 48 dp file-type icon (or thumbnail)
 * │            │
 * ├────────────┤
 * │ file.txt   │  ← single-line name
 * │ 2.4 MB     │  ← optional size
 * └────────────┘
 * ```
 *
 * When [isSelected] is `true`, the card gets a primary-tinted container and a 2-dp
 * primary-coloured border to make the selection state visually unambiguous.
 */
@Composable
fun TitanFileGridItem(
    name: String,
    isDirectory: Boolean,
    modifier: Modifier = Modifier,
    path: String = "",
    size: String? = null,
    isSelected: Boolean = false,
    thumbnailContent: @Composable (() -> Unit)? = null,
    onClick: () -> Unit = {},
) {
    val icon = if (isDirectory) FileTypeIcon.Folder else FileTypeIcon.fromPath(path)
    Card(
        modifier = modifier.bounceClick(onClick = onClick),
        shape = ShapeTokens.Medium,
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surface,
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = if (isSelected) ElevationTokens.Level2 else ElevationTokens.Level1,
        ),
        border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
    ) {
        Column(
            Modifier.padding(SpacingTokens.Sm),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(
                Modifier.fillMaxWidth().height(96.dp),
                contentAlignment = Alignment.Center,
            ) {
                if (thumbnailContent != null) thumbnailContent()
                else Icon(icon.imageVector, null, Modifier.size(48.dp), tint = icon.color)
            }
            Spacer(Modifier.height(SpacingTokens.Xs))
            Text(
                name,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontWeight = FontWeight.Medium,
            )
            size?.let {
                Text(
                    it,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                )
            }
        }
    }
}

/**
 * ## TitanFileGridItemCompact
 *
 * Compact variant of [TitanFileGridItem] — smaller padding, smaller icon. Used for
 * dense grid layouts (e.g., the image gallery).
 */
@Composable
fun TitanFileGridItemCompact(
    name: String,
    modifier: Modifier = Modifier,
    path: String = "",
    isSelected: Boolean = false,
    thumbnailContent: @Composable (() -> Unit)? = null,
    onClick: () -> Unit = {},
) {
    val icon = FileTypeIcon.fromPath(path)
    Box(
        modifier = modifier
            .bounceClick(onClick = onClick)
            .clipToRounded(8.dp),
    ) {
        if (thumbnailContent != null) {
            thumbnailContent()
        } else {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(120.dp)
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center,
            ) {
                Icon(icon.imageVector, null, Modifier.size(36.dp), tint = icon.color)
            }
        }
        if (isSelected) {
            Box(
                Modifier
                    .size(24.dp)
                    .align(Alignment.TopEnd)
                    .padding(4.dp)
                    .clipToCircle()
                    .background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    Icons.Filled.Check,
                    "Selected",
                    tint = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(16.dp),
                )
            }
        }
    }
}

/**
 * ## TitanBreadcrumb
 *
 * Path navigation bar — renders a list of (label, path) segments separated by chevrons.
 * Clicking a segment navigates to its path.
 *
 * ### Anatomy
 * ```
 *  Home  >  Documents  >  Work  >  Reports
 *  ↑       ↑             ↑        ↑
 *  primary primary       primary  onSurface (current)
 * ```
 *
 * The LAST segment is rendered in `onSurface` (the "current location"); all earlier
 * segments are rendered in `primary` (tappable links).
 *
 * @param segments ordered list of (label, path) pairs from root to current.
 * @param onNavigate invoked with the path of the clicked segment.
 * @param modifier modifier applied to the row.
 */
@Composable
fun TitanBreadcrumb(
    segments: List<Pair<String, String>>,
    onNavigate: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    LazyRow(
        modifier = modifier.fillMaxWidth().padding(horizontal = SpacingTokens.ScreenHorizontal, vertical = SpacingTokens.Xs),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.Xxs),
    ) {
        items(segments.size) { index ->
            val (label, path) = segments[index]
            if (index > 0) {
                Icon(
                    Icons.Filled.ChevronRight,
                    null,
                    Modifier.size(16.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Text(
                label,
                style = MaterialTheme.typography.labelMedium,
                color = if (index == segments.lastIndex) MaterialTheme.colorScheme.onSurface
                else MaterialTheme.colorScheme.primary,
                fontWeight = if (index == segments.lastIndex) FontWeight.Medium else FontWeight.Normal,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .clipToRounded(4.dp)
                    .bounceClick(onClick = { onNavigate(path) })
                    .padding(horizontal = 4.dp, vertical = 2.dp),
            )
        }
    }
}

/**
 * ## TitanSortChipGroup
 *
 * Sort chip group — a horizontal row of [FilterChip]s for choosing sort options.
 *
 * @param options ordered list of (label, value) pairs.
 * @param selectedOption currently selected value.
 * @param onOptionSelected invoked with the new value when a chip is tapped.
 * @param modifier modifier applied to the row.
 */
@Composable
fun <T> TitanSortChipGroup(
    options: List<Pair<String, T>>,
    selectedOption: T,
    onOptionSelected: (T) -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier.fillMaxWidth().padding(horizontal = SpacingTokens.ScreenHorizontal, vertical = SpacingTokens.Xs),
        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.Xs),
    ) {
        options.forEach { (label, value) ->
            FilterChip(
                selected = value == selectedOption,
                onClick = { onOptionSelected(value) },
                label = { Text(label) },
                shape = ShapeTokens.Full,
            )
        }
    }
}

/**
 * ## TitanSegmentedControl
 *
 * iOS-style segmented control — a horizontal row of mutually-exclusive segments.
 * Used for view-mode switching (list vs grid) and tab switching.
 *
 * @param segments ordered list of (label, value) pairs.
 * @param selectedSegment currently selected value.
 * @param onSegmentSelected invoked with the new value when a segment is tapped.
 * @param modifier modifier applied to the surface.
 */
@Composable
fun <T> TitanSegmentedControl(
    segments: List<Pair<String, T>>,
    selectedSegment: T,
    onSegmentSelected: (T) -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(modifier = modifier, shape = ShapeTokens.Full, color = MaterialTheme.colorScheme.surfaceVariant) {
        Row(Modifier.padding(2.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            segments.forEach { (label, value) ->
                val isSelected = value == selectedSegment
                Surface(
                    shape = ShapeTokens.Full,
                    color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                    modifier = Modifier.bounceClick(onClick = { onSegmentSelected(value) }),
                ) {
                    Text(
                        label,
                        style = MaterialTheme.typography.labelMedium,
                        color = if (isSelected) MaterialTheme.colorScheme.onPrimary
                        else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                    )
                }
            }
        }
    }
}

/**
 * ## TitanSegmentedControlWithIcons
 *
 * Variant of [TitanSegmentedControl] that takes icons instead of text labels.
 * Useful for view-mode switchers (list / grid / columns).
 */
@Composable
fun <T> TitanSegmentedControlWithIcons(
    segments: List<Pair<androidx.compose.ui.graphics.vector.ImageVector, T>>,
    selectedSegment: T,
    onSegmentSelected: (T) -> Unit,
    modifier: Modifier = Modifier,
    iconSize: Dp = 20.dp,
) {
    Surface(modifier = modifier, shape = ShapeTokens.Full, color = MaterialTheme.colorScheme.surfaceVariant) {
        Row(Modifier.padding(2.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            segments.forEach { (icon, value) ->
                val isSelected = value == selectedSegment
                Surface(
                    shape = ShapeTokens.Full,
                    color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                    modifier = Modifier.bounceClick(onClick = { onSegmentSelected(value) }),
                ) {
                    Icon(
                        icon,
                        null,
                        Modifier
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                            .size(iconSize),
                        tint = if (isSelected) MaterialTheme.colorScheme.onPrimary
                        else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

/**
 * ## TitanCard
 *
 * Enterprise card variants — Elevated, Outlined, Gradient, and Tonal.
 *
 * Use these instead of raw Material 3 `Card` to get consistent elevation, shape, and
 * border treatment across the app.
 */
object TitanCard {

    /** Elevated card — uses standard Material 3 elevation. */
    @Composable
    fun Elevated(
        modifier: Modifier = Modifier,
        elevation: Dp = ElevationTokens.Level1,
        content: @Composable () -> Unit,
    ) {
        Card(
            modifier,
            ShapeTokens.Medium,
            elevation = CardDefaults.cardElevation(defaultElevation = elevation),
        ) { content() }
    }

    /** Outlined card — flat surface with a 1-dp outline-variant border. */
    @Composable
    fun Outlined(
        modifier: Modifier = Modifier,
        content: @Composable () -> Unit,
    ) {
        Card(
            modifier,
            ShapeTokens.Medium,
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            elevation = CardDefaults.cardElevation(defaultElevation = ElevationTokens.Level0),
        ) { content() }
    }

    /**
     * Gradient card — elevated surface with a linear gradient background painted
     * behind the content. Used for hero / promotional cards.
     */
    @Composable
    fun Gradient(
        modifier: Modifier = Modifier,
        startColor: Color = MaterialTheme.colorScheme.primary,
        endColor: Color = MaterialTheme.colorScheme.tertiary,
        content: @Composable () -> Unit,
    ) {
        Card(
            modifier,
            ShapeTokens.Medium,
            elevation = CardDefaults.cardElevation(defaultElevation = ElevationTokens.Level2),
        ) {
            Box(Modifier.background(Brush.linearGradient(listOf(startColor, endColor)))) { content() }
        }
    }

    /** Tonal card — flat surface with a primary-container tint. */
    @Composable
    fun Tonal(
        modifier: Modifier = Modifier,
        content: @Composable () -> Unit,
    ) {
        Card(
            modifier,
            ShapeTokens.Medium,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            elevation = CardDefaults.cardElevation(defaultElevation = ElevationTokens.Level0),
        ) { content() }
    }

    /** Filled card — flat surface with a surface-variant fill. */
    @Composable
    fun Filled(
        modifier: Modifier = Modifier,
        content: @Composable () -> Unit,
    ) {
        Card(
            modifier,
            ShapeTokens.Medium,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            elevation = CardDefaults.cardElevation(defaultElevation = ElevationTokens.Level0),
        ) { content() }
    }
}

/**
 * ## TitanThumbnail
 *
 * Standard file-thumbnail wrapper. Renders [content] inside a fixed-size rounded box.
 * If the underlying content fails to load (or is null), a broken-image icon is shown.
 *
 * @param modifier modifier applied to the thumbnail box.
 * @param size thumbnail size in dp.
 * @param content thumbnail content (typically an `Image` composable).
 * @param isError when `true`, shows a broken-image placeholder instead of [content].
 */
@Composable
fun TitanThumbnail(
    modifier: Modifier = Modifier,
    size: Dp = 96.dp,
    isError: Boolean = false,
    content: @Composable () -> Unit,
) {
    Box(
        modifier = modifier
            .size(size)
            .clipToRounded(12.dp)
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center,
    ) {
        if (isError) {
            Icon(
                Icons.Filled.BrokenImage,
                "Failed to load",
                Modifier.size(size / 3),
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        } else {
            content()
        }
    }
}

/**
 * ## TitanStatusBar
 *
 * Inline status bar — shows a coloured stripe with an icon and message. Used by file
 * operations to communicate progress / completion without taking over the screen.
 *
 * @param message status message.
 * @param colour status colour (drives the stripe + icon tint).
 * @param icon leading icon.
 * @param modifier modifier applied to the bar.
 * @param actionLabel optional trailing action button label.
 * @param onAction optional trailing action handler.
 */
@Composable
fun TitanStatusBar(
    message: String,
    color: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = color.copy(alpha = 0.12f),
        shape = ShapeTokens.Small,
    ) {
        Row(
            Modifier.padding(horizontal = SpacingTokens.Lg, vertical = SpacingTokens.Sm),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(icon, null, Modifier.size(20.dp), tint = color)
            Spacer(Modifier.width(SpacingTokens.Md))
            Text(
                message,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            if (actionLabel != null && onAction != null) {
                TextButton(onClick = onAction) { Text(actionLabel) }
            }
        }
    }
}

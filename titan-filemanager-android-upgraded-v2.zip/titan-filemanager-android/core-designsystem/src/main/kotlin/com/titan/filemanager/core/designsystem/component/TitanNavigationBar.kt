package com.titan.filemanager.core.designsystem.component

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LargeTopAppBar
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MediumTopAppBar
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.titan.filemanager.core.designsystem.tokens.MotionTokens
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens

/**
 * ## TopBarAction
 *
 * Description of a single action button shown in a [TopAppBar] / [CenterAlignedTopAppBar] / etc.
 *
 * @property icon leading icon.
 * @property contentDescription accessibility description.
 * @property onClick click handler.
 * @property enabled when `false`, the icon button is disabled.
 * @property badge optional numeric badge count (shown via [BadgedBox]).
 */
data class TopBarAction(
    val icon: ImageVector,
    val contentDescription: String,
    val onClick: () -> Unit,
    val enabled: Boolean = true,
    val badgeCount: Int? = null,
) {
    /** Renders this action as a [IconButton] with an optional [BadgedBox]. */
    @Composable
    fun Render() {
        BadgedBox(
            badge = {
                if (badgeCount != null && badgeCount > 0) {
                    Badge { Text(badgeCount.toString()) }
                }
            },
        ) {
            IconButton(onClick = onClick, enabled = enabled) {
                Icon(
                    icon,
                    contentDescription,
                    tint = if (enabled) MaterialTheme.colorScheme.onSurface
                    else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

/**
 * ## NavItem
 *
 * Description of a single item in a [TitanNavigationBar] / [TitanNavigationRail].
 *
 * @property label user-facing label.
 * @property icon leading icon.
 * @property route navigation route identifier.
 * @property badgeCount optional numeric badge count.
 * @property selectedIcon optional alternate icon shown when the item is selected.
 */
data class NavItem(
    val label: String,
    val icon: ImageVector,
    val route: String,
    val badgeCount: Int? = null,
    val selectedIcon: ImageVector? = null,
)

/**
 * ## TitanTopBar
 *
 * Pre-styled [TopAppBar] variants for the most common TitanFileManager app-bar layouts.
 *
 * ### Variants
 * - [Simple] — title only, optional actions.
 * - [Back] — title, back button, optional actions.
 * - [Selection] — selection-mode bar with close button, "N selected" title, and actions.
 * - [Search] — search-mode bar with back button, query text field, and clear button.
 * - [Edit] — edit-mode bar with close button, "Editing" title, and save action.
 * - [Large] — large top app bar with collapsing title.
 * - [Medium] — medium top app bar with collapsing title.
 * - [CenterAligned] — title centered horizontally.
 */
@OptIn(ExperimentalMaterial3Api::class)
object TitanTopBar {

    /** Simple top bar — title and optional actions. */
    @Composable
    fun Simple(
        title: String,
        actions: List<TopBarAction> = emptyList(),
        modifier: Modifier = Modifier,
    ) {
        TopAppBar(
            modifier = modifier,
            title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            actions = { actions.forEach { it.Render() } },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface),
        )
    }

    /** Back top bar — back button + title + optional actions. */
    @Composable
    fun Back(
        title: String,
        onBack: () -> Unit,
        actions: List<TopBarAction> = emptyList(),
        modifier: Modifier = Modifier,
    ) {
        TopAppBar(
            modifier = modifier,
            title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                }
            },
            actions = { actions.forEach { it.Render() } },
        )
    }

    /** Selection-mode top bar — close button + "N selected" + actions. */
    @Composable
    fun Selection(
        selectedCount: Int,
        onClose: () -> Unit,
        actions: List<TopBarAction> = emptyList(),
        modifier: Modifier = Modifier,
    ) {
        TopAppBar(
            modifier = modifier,
            title = { Text("$selectedCount selected", fontWeight = FontWeight.Medium) },
            navigationIcon = {
                IconButton(onClick = onClose) {
                    Icon(Icons.Filled.Close, "Close selection")
                }
            },
            actions = { actions.forEach { it.Render() } },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                navigationIconContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                actionIconContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
            ),
        )
    }

    /** Search-mode top bar — back button + query field + clear button. */
    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun Search(
        query: String,
        onQueryChange: (String) -> Unit,
        onBack: () -> Unit,
        onClear: () -> Unit,
        modifier: Modifier = Modifier,
        placeholder: String = "Search files",
    ) {
        TopAppBar(
            modifier = modifier,
            title = {
                androidx.compose.material3.TextField(
                    value = query,
                    onValueChange = onQueryChange,
                    placeholder = { Text(placeholder) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = androidx.compose.material3.TextFieldDefaults.colors(
                        focusedContainerColor = androidx.compose.ui.graphics.Color.Transparent,
                        unfocusedContainerColor = androidx.compose.ui.graphics.Color.Transparent,
                        disabledContainerColor = androidx.compose.ui.graphics.Color.Transparent,
                        focusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                        unfocusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                    ),
                )
            },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                }
            },
            actions = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = onClear) {
                        Icon(Icons.Filled.Close, "Clear")
                    }
                }
            },
        )
    }

    /** Edit-mode top bar — close button + "Editing" title + save action. */
    @Composable
    fun Edit(
        title: String = "Editing",
        onClose: () -> Unit,
        onSave: () -> Unit,
        saveEnabled: Boolean = true,
        modifier: Modifier = Modifier,
    ) {
        TopAppBar(
            modifier = modifier,
            title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            navigationIcon = {
                IconButton(onClick = onClose) {
                    Icon(Icons.Filled.Close, "Close edit mode")
                }
            },
            actions = {
                IconButton(onClick = onSave, enabled = saveEnabled) {
                    Icon(
                        Icons.Filled.Check,
                        "Save",
                        tint = if (saveEnabled) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            },
        )
    }

    /** Large top app bar — collapsing title (152 dp expanded). */
    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun Large(
        title: String,
        actions: List<TopBarAction> = emptyList(),
        onBack: (() -> Unit)? = null,
        modifier: Modifier = Modifier,
    ) {
        LargeTopAppBar(
            modifier = modifier,
            title = { Text(title, maxLines = 2, overflow = TextOverflow.Ellipsis) },
            navigationIcon = {
                onBack?.let {
                    IconButton(onClick = it) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                }
            },
            actions = { actions.forEach { it.Render() } },
            colors = TopAppBarDefaults.largeTopAppBarColors(containerColor = MaterialTheme.colorScheme.surface),
        )
    }

    /** Medium top app bar — collapsing title (100 dp expanded). */
    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun Medium(
        title: String,
        actions: List<TopBarAction> = emptyList(),
        onBack: (() -> Unit)? = null,
        modifier: Modifier = Modifier,
    ) {
        MediumTopAppBar(
            modifier = modifier,
            title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            navigationIcon = {
                onBack?.let {
                    IconButton(onClick = it) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                }
            },
            actions = { actions.forEach { it.Render() } },
            colors = TopAppBarDefaults.mediumTopAppBarColors(containerColor = MaterialTheme.colorScheme.surface),
        )
    }

    /** Center-aligned top app bar — title centered horizontally. */
    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun CenterAligned(
        title: String,
        actions: List<TopBarAction> = emptyList(),
        onBack: (() -> Unit)? = null,
        modifier: Modifier = Modifier,
    ) {
        CenterAlignedTopAppBar(
            modifier = modifier,
            title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            navigationIcon = {
                onBack?.let {
                    IconButton(onClick = it) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                }
            },
            actions = { actions.forEach { it.Render() } },
            colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = MaterialTheme.colorScheme.surface),
        )
    }
}

/**
 * ## TitanNavigationBar
 *
 * Bottom navigation bar — Material 3 `NavigationBar` styled with TitanFileManager defaults.
 *
 * ### Anatomy
 * Each item renders an icon (with optional badge) and a single-line label. The
 * selected item gets a primary-container "pill" behind its icon, and the icon
 * transitions smoothly between the unselected and selected states (using the
 * optional [NavItem.selectedIcon]).
 *
 * @param items ordered list of [NavItem]s to display (typically 3–5 items).
 * @param currentRoute route identifier of the currently selected item.
 * @param onNavigate invoked with the new route when an item is tapped.
 * @param modifier modifier applied to the bar.
 * @param alwaysShowLabels when `true`, labels are shown on unselected items. When
 *                          `false`, only the selected item's label is shown.
 */
@Composable
fun TitanNavigationBar(
    items: List<NavItem>,
    currentRoute: String?,
    onNavigate: (String) -> Unit,
    modifier: Modifier = Modifier,
    alwaysShowLabels: Boolean = true,
) {
    NavigationBar(
        modifier = modifier,
        containerColor = MaterialTheme.colorScheme.surface,
    ) {
        items.forEach { item ->
            val selected = currentRoute == item.route
            NavigationBarItem(
                selected = selected,
                onClick = { onNavigate(item.route) },
                icon = {
                    NavItemIcon(item = item, selected = selected)
                },
                label = {
                    if (alwaysShowLabels || selected) {
                        Text(item.label, maxLines = 1)
                    }
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    selectedTextColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                ),
            )
        }
    }
}

/**
 * Renders the icon (and optional badge) for a [NavItem], animating between the
 * unselected and selected icons when [NavItem.selectedIcon] is provided.
 */
@Composable
private fun NavItemIcon(item: NavItem, selected: Boolean) {
    val targetScale = if (selected) 1.15f else 1.0f
    val scale by animateFloatAsState(
        targetValue = targetScale,
        animationSpec = tween(MotionTokens.DurationFast, easing = MotionTokens.EasingStandard),
        label = "navItemScale",
    )
    BadgedBox(
        badge = {
            if (item.badgeCount != null && item.badgeCount > 0) {
                Badge { Text(item.badgeCount.toString()) }
            }
        },
    ) {
        val icon = if (selected && item.selectedIcon != null) item.selectedIcon else item.icon
        Icon(
            icon,
            item.label,
            modifier = Modifier.scale(scale),
        )
    }
}

/**
 * ## TitanNavigationRail
 *
 * Side navigation rail for tablet / desktop layouts. Mirrors [TitanNavigationBar]
 * but renders vertically on the left edge.
 */
@Composable
fun TitanNavigationRail(
    items: List<NavItem>,
    currentRoute: String?,
    onNavigate: (String) -> Unit,
    modifier: Modifier = Modifier,
    header: @Composable (androidx.compose.foundation.layout.ColumnScope.() -> Unit)? = null,
) {
    NavigationRail(
        modifier = modifier,
        containerColor = MaterialTheme.colorScheme.surface,
        header = header,
    ) {
        items.forEach { item ->
            val selected = currentRoute == item.route
            NavigationRailItem(
                selected = selected,
                onClick = { onNavigate(item.route) },
                icon = {
                    BadgedBox(
                        badge = {
                            if (item.badgeCount != null && item.badgeCount > 0) {
                                Badge { Text(item.badgeCount.toString()) }
                            }
                        },
                    ) {
                        val icon = if (selected && item.selectedIcon != null) item.selectedIcon else item.icon
                        Icon(icon, item.label)
                    }
                },
                label = { Text(item.label, maxLines = 1) },
                colors = NavigationRailItemDefaults.colors(
                    selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    selectedTextColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                ),
            )
        }
    }
}

/**
 * ## TitanBottomActionBar
 *
 * contextual action bar shown above the bottom nav — used by file operations
 * (move, copy, share, delete) when one or more files are selected.
 *
 * Renders a row of icon buttons with optional labels, separated by a divider
 * from the content above.
 *
 * @param actions ordered list of (icon, label, handler) tuples.
 * @param modifier modifier applied to the bar.
 * @param onClose optional close handler — when non-null, a close button is shown on the left.
 */
@Composable
fun TitanBottomActionBar(
    actions: List<Triple<ImageVector, String, () -> Unit>>,
    modifier: Modifier = Modifier,
    onClose: (() -> Unit)? = null,
) {
    androidx.compose.material3.Surface(
        modifier = modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surfaceContainer,
        tonalElevation = com.titan.filemanager.core.designsystem.tokens.ElevationTokens.Level2,
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = SpacingTokens.ScreenHorizontal, vertical = SpacingTokens.Xs),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceEvenly,
        ) {
            if (onClose != null) {
                IconButton(onClick = onClose) {
                    Icon(Icons.Filled.Close, "Close action bar")
                }
            }
            actions.forEach { (icon, label, handler) ->
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    IconButton(onClick = handler) {
                        Icon(icon, label, tint = MaterialTheme.colorScheme.onSurface)
                    }
                    Text(
                        label,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
    }
}

/**
 * Pre-built [TopBarAction] sets for common scenarios.
 */
object TopBarActions {

    /** Default "more + settings" actions shown on most screens. */
    fun moreAndSettings(
        onMore: () -> Unit,
        onSettings: () -> Unit,
    ): List<TopBarAction> = listOf(
        TopBarAction(Icons.Filled.MoreVert, "More", onMore),
        TopBarAction(Icons.Filled.Settings, "Settings", onSettings),
    )

    /** Search + more actions. */
    fun searchAndMore(
        onSearch: () -> Unit,
        onMore: () -> Unit,
    ): List<TopBarAction> = listOf(
        TopBarAction(Icons.Filled.Search, "Search", onSearch),
        TopBarAction(Icons.Filled.MoreVert, "More", onMore),
    )

    /** Selection-mode actions: share + edit + delete. */
    fun selection(
        onShare: () -> Unit,
        onEdit: () -> Unit,
        onDelete: () -> Unit,
    ): List<TopBarAction> = listOf(
        TopBarAction(Icons.Filled.Share, "Share", onShare),
        TopBarAction(Icons.Filled.Edit, "Edit", onEdit),
        TopBarAction(Icons.Filled.MoreVert, "More", onDelete),
    )
}

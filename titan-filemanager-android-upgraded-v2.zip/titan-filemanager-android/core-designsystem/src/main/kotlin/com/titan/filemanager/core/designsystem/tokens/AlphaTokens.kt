package com.titan.filemanager.core.designsystem.tokens

/**
 * # AlphaTokens
 *
 * Centralised alpha (opacity) scale for the TitanFileManager design system.
 *
 * ## Why an alpha scale matters
 * Opacity is the second axis of colour design. A 100% opaque red is alarming; the same red
 * at 8% is a soothing tint. By naming every alpha value we use, we get:
 * 1. **Consistency** — every "disabled" surface looks equally faded.
 * 2. **Predictable scrim hierarchy** — Light < Medium < Heavy < Full scrims always stack in
 *    the right order without ad-hoc `0.4f` magic numbers.
 * 3. **Glassmorphism tuning** — the glass family of tokens controls how see-through every
 *    frosted surface is, from subtle (0.65) to opaque (0.80).
 *
 * ## Naming convention
 * - **T-shirt scale** (`Whisper` → `Full`) for raw values.
 * - **Interaction state names** (`Hover`, `Focus`, `Pressed`, `Selected`, `Dragged`) — the
 *   standard Material 3 state-layer alphas.
 * - **Glass family** — for backdrop-blur surfaces.
 * - **Scrim family** — for modal overlays.
 * - **Gradient family** — for multi-stop gradient alphas.
 */
object AlphaTokens {
    // ─────────────────────────────────────────────────────────────
    // Raw t-shirt scale
    // ─────────────────────────────────────────────────────────────
    /** 0.00 — fully transparent. */
    const val Transparent = 0.00f
    /** 0.04 — whisper-faint tint, used for hover state layers. */
    const val Whisper = 0.04f
    /** 0.08 — ghost tint, used for selected / pressed state layers. */
    const val Ghost = 0.08f
    /** 0.12 — faint tint, used for focus state layers and disabled containers. */
    const val Faint = 0.12f
    /** 0.20 — light tint, used for subtle background fills. */
    const val Light = 0.20f
    /** 0.38 — medium tint, used for disabled content (icons, text). */
    const val Medium = 0.38f
    /** 0.50 — strong tint, used for half-faded placeholders. */
    const val Strong = 0.50f
    /** 0.60 — heavy tint, used for non-interactive overlays. */
    const val Heavy = 0.60f
    /** 0.75 — solid tint, used for high-contrast overlays on bright backgrounds. */
    const val Solid = 0.75f
    /** 0.87 — opaque tint, used for primary content on tinted backgrounds. */
    const val Opaque = 0.87f
    /** 1.00 — fully opaque. */
    const val Full = 1.00f

    // ─────────────────────────────────────────────────────────────
    // Disabled state
    // ─────────────────────────────────────────────────────────────
    /** 0.38 — alpha for disabled content (text, icons). */
    const val DisabledContent = 0.38f
    /** 0.12 — alpha for disabled containers (button background). */
    const val DisabledContainer = 0.12f

    // ─────────────────────────────────────────────────────────────
    // Interaction state layers (Material 3)
    // ─────────────────────────────────────────────────────────────
    /** 0.04 — hover state layer alpha. */
    const val Hover = 0.04f
    /** 0.12 — focus state layer alpha. */
    const val Focus = 0.12f
    /** 0.12 — pressed state layer alpha. */
    const val Pressed = 0.12f
    /** 0.08 — selected state layer alpha (when not pressed). */
    const val Selected = 0.08f
    /** 0.16 — dragged state layer alpha. */
    const val Dragged = 0.16f

    // ─────────────────────────────────────────────────────────────
    // Glassmorphism family
    // ─────────────────────────────────────────────────────────────
    /** 0.65 — default glass surface tint on light theme. */
    const val GlassLight = 0.65f
    /** 0.55 — default glass surface tint on dark theme. */
    const val GlassDark = 0.55f
    /** 0.80 — extra-opaque glass for dialogs. */
    const val GlassBlur = 0.80f
    /** 0.45 — subtle glass for ambient surfaces (search bars). */
    const val GlassSubtle = 0.45f
    /** 0.85 — heavy glass for full-screen modals. */
    const val GlassHeavy = 0.85f

    // ─────────────────────────────────────────────────────────────
    // Scrim family
    // ─────────────────────────────────────────────────────────────
    /** 0.32 — light scrim behind popovers and tooltips. */
    const val ScrimLight = 0.32f
    /** 0.48 — medium scrim behind dropdowns. */
    const val ScrimMedium = 0.48f
    /** 0.60 — heavy scrim behind side sheets. */
    const val ScrimHeavy = 0.60f
    /** 0.80 — full scrim behind modal dialogs. */
    const val ScrimFull = 0.80f

    // ─────────────────────────────────────────────────────────────
    // Gradient stops
    // ─────────────────────────────────────────────────────────────
    /** 0.15 — start alpha for hero gradients. */
    const val GradientStart = 0.15f
    /** 0.35 — middle alpha for hero gradients. */
    const val GradientMid = 0.35f
    /** 0.00 — end alpha for hero gradients (fades to transparent). */
    const val GradientEnd = 0.00f
    /** 0.85 — solid gradient stop for banner backgrounds. */
    const val GradientSolid = 0.85f

    // ─────────────────────────────────────────────────────────────
    // Helpers
    // ─────────────────────────────────────────────────────────────
    /** Returns the appropriate alpha for a state layer given the interaction state. */
    fun stateLayerAlpha(
        isHovered: Boolean = false,
        isFocused: Boolean = false,
        isPressed: Boolean = false,
        isSelected: Boolean = false,
        isDragged: Boolean = false,
    ): Float = when {
        isDragged -> Dragged
        isPressed -> Pressed
        isFocused -> Focus
        isSelected -> Selected
        isHovered -> Hover
        else -> Transparent
    }

    /** Returns the appropriate glass alpha for the given [isDark] flag. */
    fun glassFor(isDark: Boolean): Float = if (isDark) GlassDark else GlassLight

    /** Returns the appropriate scrim alpha for the given modal weight (0.0 = lightest, 1.0 = heaviest). */
    fun scrimFor(weight: Float): Float = when {
        weight < 0.25f -> ScrimLight
        weight < 0.5f -> ScrimMedium
        weight < 0.75f -> ScrimHeavy
        else -> ScrimFull
    }
}

package com.titan.filemanager.core.designsystem.component

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.scale
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.titan.filemanager.core.designsystem.modifier.clipToCircle
import com.titan.filemanager.core.designsystem.modifier.clipToRounded
import com.titan.filemanager.core.designsystem.modifier.shimmer
import com.titan.filemanager.core.designsystem.tokens.ElevationTokens
import com.titan.filemanager.core.designsystem.tokens.MotionTokens
import com.titan.filemanager.core.designsystem.tokens.ShapeTokens
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import com.titan.filemanager.core.designsystem.theme.TitanTheme

// ═══════════════════════════════════════════════════════════════
// SKELETON ITEMS — loading placeholders
// ═══════════════════════════════════════════════════════════════

/**
 * Skeleton placeholder for a single-row list item.
 *
 * Used while a list of files is loading from disk or network. The shape mirrors the
 * real [TitanFileTile] component so the layout doesn't shift when content arrives.
 */
@Composable
fun TitanSkeletonItem(modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = SpacingTokens.ScreenHorizontal, vertical = SpacingTokens.Xs),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(40.dp).clipToRounded(8.dp).shimmer())
        Spacer(Modifier.width(SpacingTokens.Lg))
        Column(Modifier.weight(1f)) {
            Box(Modifier.fillMaxWidth(0.6f).height(16.dp).clipToRounded(4.dp).shimmer())
            Spacer(Modifier.height(SpacingTokens.Xs))
            Box(Modifier.fillMaxWidth(0.3f).height(12.dp).clipToRounded(4.dp).shimmer())
        }
        Spacer(Modifier.width(SpacingTokens.Lg))
        Box(Modifier.size(24.dp).clipToCircle().shimmer())
    }
}

/**
 * Skeleton placeholder for a two-line list item with a larger icon.
 */
@Composable
fun TitanSkeletonItemLarge(modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = SpacingTokens.ScreenHorizontal, vertical = SpacingTokens.Sm),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(56.dp).clipToRounded(12.dp).shimmer())
        Spacer(Modifier.width(SpacingTokens.Lg))
        Column(Modifier.weight(1f)) {
            Box(Modifier.fillMaxWidth(0.7f).height(18.dp).clipToRounded(4.dp).shimmer())
            Spacer(Modifier.height(SpacingTokens.Xs))
            Box(Modifier.fillMaxWidth(0.4f).height(14.dp).clipToRounded(4.dp).shimmer())
            Spacer(Modifier.height(SpacingTokens.Xs))
            Box(Modifier.fillMaxWidth(0.5f).height(12.dp).clipToRounded(4.dp).shimmer())
        }
    }
}

/**
 * Skeleton placeholder for a grid tile.
 */
@Composable
fun TitanSkeletonGridItem(modifier: Modifier = Modifier) {
    Column(modifier.padding(SpacingTokens.Xs)) {
        Box(Modifier.fillMaxWidth().height(120.dp).clipToRounded(12.dp).shimmer())
        Spacer(Modifier.height(SpacingTokens.Xs))
        Box(Modifier.fillMaxWidth(0.7f).height(14.dp).clipToRounded(4.dp).shimmer())
    }
}

/**
 * Skeleton placeholder for a card-style hero block.
 */
@Composable
fun TitanSkeletonCard(modifier: Modifier = Modifier) {
    Column(modifier.padding(SpacingTokens.Lg)) {
        Box(Modifier.fillMaxWidth().height(160.dp).clipToRounded(16.dp).shimmer())
        Spacer(Modifier.height(SpacingTokens.Sm))
        Box(Modifier.fillMaxWidth(0.5f).height(20.dp).clipToRounded(4.dp).shimmer())
        Spacer(Modifier.height(SpacingTokens.Xs))
        Box(Modifier.fillMaxWidth(0.8f).height(14.dp).clipToRounded(4.dp).shimmer())
    }
}

/**
 * Skeleton placeholder for a storage dashboard header.
 */
@Composable
fun TitanSkeletonStorageHeader(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = SpacingTokens.ScreenHorizontal, vertical = SpacingTokens.Lg),
    ) {
        Box(Modifier.fillMaxWidth(0.4f).height(28.dp).clipToRounded(4.dp).shimmer())
        Spacer(Modifier.height(SpacingTokens.Sm))
        Box(Modifier.fillMaxWidth().height(12.dp).clipToCircle().shimmer())
        Spacer(Modifier.height(SpacingTokens.Xs))
        Box(Modifier.fillMaxWidth(0.6f).height(14.dp).clipToRounded(4.dp).shimmer())
    }
}

// ═══════════════════════════════════════════════════════════════
// STORAGE BAR
// ═══════════════════════════════════════════════════════════════

/**
 * A single coloured segment in a [TitanStorageBar].
 *
 * @property label user-facing label for the segment (e.g., "Images").
 * @property sizeGb size of the segment in gigabytes.
 * @property colour tint colour of the segment.
 */
data class StorageSegment(
    val label: String,
    val sizeGb: Float,
    val color: Color,
)

/**
 * Storage breakdown bar — a horizontal stacked-bar visualisation of how the device's
 * storage is divided among file categories.
 *
 * ### Anatomy
 * ```
 * ┌──────────────────────────────────┐
 * │ ▓▓▓▓░░░░░▒▒▒▒░░░░░░░░░░░░░░░░░░ │  ← stacked segments + free space
 * └──────────────────────────────────┘
 *   73.4 GB used          54.6 GB free
 * ```
 *
 * @param segments ordered list of [StorageSegment]s to display.
 * @param modifier modifier applied to the root column.
 * @param totalCapacityGb total capacity of the storage device in GB.
 */
@Composable
fun TitanStorageBar(
    segments: List<StorageSegment>,
    modifier: Modifier = Modifier,
    totalCapacityGb: Float = 128f,
) {
    val usedGb = segments.sumOf { it.sizeGb.toDouble() }.toFloat()
    val freeGb = (totalCapacityGb - usedGb).coerceAtLeast(0f)
    Column(modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().height(12.dp).clipToCircle(),
            horizontalArrangement = Arrangement.spacedBy(1.dp),
        ) {
            segments.forEach { seg ->
                Box(
                    Modifier
                        .weight(seg.sizeGb / totalCapacityGb)
                        .fillMaxWidth()
                        .background(seg.color),
                )
            }
            val freeFraction = freeGb / totalCapacityGb
            if (freeFraction > 0f) {
                Box(
                    Modifier
                        .weight(freeFraction)
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                )
            }
        }
        Spacer(Modifier.height(SpacingTokens.Sm))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(
                "${"%.1f".format(usedGb)} GB used",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                "${"%.1f".format(freeGb)} GB free",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/**
 * Storage breakdown legend — a vertical list of [StorageSegment]s with their labels,
 * colours, and sizes. Pairs well with [TitanStorageBar].
 */
@Composable
fun TitanStorageLegend(
    segments: List<StorageSegment>,
    modifier: Modifier = Modifier,
) {
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(SpacingTokens.Xs)) {
        segments.forEach { seg ->
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = SpacingTokens.Xs),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier
                        .size(12.dp)
                        .clipToCircle()
                        .background(seg.color),
                )
                Spacer(Modifier.width(SpacingTokens.Sm))
                Text(
                    seg.label,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f),
                )
                Text(
                    "${"%.1f".format(seg.sizeGb)} GB",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// INFO BADGE
// ═══════════════════════════════════════════════════════════════

/**
 * Small badge used to label items with a status (e.g., "Synced", "Pinned", "Encrypted").
 *
 * @param text badge label.
 * @param colour tint colour — applied to both the background (at 15 % alpha) and the text.
 * @param modifier modifier applied to the surface.
 * @param icon optional leading icon.
 */
@Composable
fun TitanInfoBadge(
    text: String,
    color: Color,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
) {
    Surface(modifier, ShapeTokens.Full, color = color.copy(alpha = 0.15f)) {
        Row(
            Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            icon?.let { Icon(it, null, Modifier.size(12.dp), tint = color) }
            Text(
                text,
                style = MaterialTheme.typography.labelSmall,
                color = color,
                fontWeight = FontWeight.Medium,
            )
        }
    }
}

/**
 * Pre-styled badge variants for common file states.
 */
object TitanBadge {
    /** "Synced" badge — green. */
    @Composable
    fun Synced(modifier: Modifier = Modifier) = TitanInfoBadge(
        text = "Synced", color = Color(0xFF2E7D32), icon = Icons.Filled.Cloud, modifier = modifier,
    )

    /** "Encrypted" badge — purple. */
    @Composable
    fun Encrypted(modifier: Modifier = Modifier) = TitanInfoBadge(
        text = "Encrypted", color = Color(0xFF7B1FA2), modifier = modifier,
    )

    /** "Warning" badge — amber. */
    @Composable
    fun Warning(text: String, modifier: Modifier = Modifier) = TitanInfoBadge(
        text = text, color = Color(0xFFF57C00), icon = Icons.Filled.Warning, modifier = modifier,
    )

    /** "Info" badge — blue. */
    @Composable
    fun Info(text: String, modifier: Modifier = Modifier) = TitanInfoBadge(
        text = text, color = Color(0xFF0288D1), icon = Icons.Filled.Info, modifier = modifier,
    )
}

// ═══════════════════════════════════════════════════════════════
// FILE INFO ROW
// ═══════════════════════════════════════════════════════════════

/**
 * Key-value row used in the file-properties sheet. Displays a [label] on the left and
 * a [value] on the right, with an optional leading [icon].
 *
 * @param label left-side label (e.g., "Modified").
 * @param value right-side value (e.g., "2024-01-15 14:32").
 * @param modifier modifier applied to the row.
 * @param icon optional leading icon.
 */
@Composable
fun TitanFileInfoRow(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
) {
    Row(
        modifier = modifier.fillMaxWidth().padding(vertical = SpacingTokens.Sm),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        icon?.let {
            Icon(it, null, Modifier.size(20.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.width(SpacingTokens.Md))
        }
        Text(
            label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(1f),
        )
        Text(
            value,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

/**
 * Multiline info row — like [TitanFileInfoRow] but the value can wrap to multiple lines.
 * Used for paths, descriptions, and other long-form values.
 */
@Composable
fun TitanFileInfoRowMultiline(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
) {
    Row(
        modifier = modifier.fillMaxWidth().padding(vertical = SpacingTokens.Sm),
        verticalAlignment = Alignment.Top,
    ) {
        icon?.let {
            Icon(it, null, Modifier.size(20.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.width(SpacingTokens.Md))
        }
        Column(Modifier.weight(1f)) {
            Text(
                label,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(SpacingTokens.Xxs))
            Text(
                value,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.Medium,
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// PROGRESS OVERLAY
// ═══════════════════════════════════════════════════════════════

/**
 * Full-screen modal overlay shown during blocking operations (file copy, encryption, …).
 *
 * Renders a translucent scrim with a centred card containing a spinner and an optional
 * message. Touches outside the card are NOT dismissed — the user must wait for the
 * operation to complete.
 *
 * @param message optional message shown below the spinner.
 * @param modifier modifier applied to the root box.
 */
@Composable
fun TitanProgressOverlay(message: String? = null, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.fillMaxSize().background(TitanTheme.extendedColors.overlay),
        contentAlignment = Alignment.Center,
    ) {
        Surface(
            shape = ShapeTokens.Large,
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = ElevationTokens.Level3,
        ) {
            Column(
                Modifier.padding(SpacingTokens.Xl),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                CircularProgressIndicator()
                message?.let {
                    Spacer(Modifier.height(SpacingTokens.Md))
                    Text(
                        it,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                }
            }
        }
    }
}

/**
 * Progress overlay with a determinate progress bar — used when the operation's progress
 * can be measured (e.g., copying 3 of 10 files).
 *
 * @param progress 0.0–1.0 progress fraction.
 * @param message optional message above the progress bar.
 * @param progressLabel optional label below the progress bar (e.g., "3 / 10 files").
 */
@Composable
fun TitanDeterminateProgressOverlay(
    progress: Float,
    modifier: Modifier = Modifier,
    message: String? = null,
    progressLabel: String? = null,
) {
    Box(
        modifier = modifier.fillMaxSize().background(TitanTheme.extendedColors.overlay),
        contentAlignment = Alignment.Center,
    ) {
        Surface(
            shape = ShapeTokens.Large,
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = ElevationTokens.Level3,
        ) {
            Column(
                Modifier.padding(SpacingTokens.Xl),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                message?.let {
                    Text(
                        it,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Spacer(Modifier.height(SpacingTokens.Md))
                }
                LinearProgressIndicator(
                    progress = { progress.coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth(0.6f),
                )
                progressLabel?.let {
                    Spacer(Modifier.height(SpacingTokens.Xs))
                    Text(
                        it,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// LOADING DOTS
// ═══════════════════════════════════════════════════════════════

/**
 * Three-dot bouncing loader — used as a small inline loading indicator (e.g., inside
 * a chat bubble or a chat-style status row).
 *
 * Each dot scales between 0.6 and 1.0 with a 200 ms stagger, producing a wave effect.
 *
 * @param modifier modifier applied to the row.
 * @param colour dot colour.
 * @param dotSize size of each dot in dp.
 */
@Composable
fun TitanLoadingDots(
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.primary,
    dotSize: Dp = 8.dp,
) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        repeat(3) { index ->
            val transition = rememberInfiniteTransition(label = "dot$index")
            val scale by transition.animateFloat(
                0.6f,
                1.0f,
                infiniteRepeatable(
                    tween(600, delayMillis = index * 200, easing = MotionTokens.EasingStandard),
                    RepeatMode.Reverse,
                ),
                label = "dotScale$index",
            )
            Box(
                Modifier
                    .size(dotSize)
                    .clipToCircle()
                    .background(color)
                    .scale(scale),
            )
        }
    }
}

/**
 * Pulsing-dot loader — a single dot that pulses in opacity. Used as a smaller
 * alternative to [TitanLoadingDots] when horizontal space is constrained.
 */
@Composable
fun TitanPulsingDot(
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.primary,
    dotSize: Dp = 8.dp,
) {
    val transition = rememberInfiniteTransition(label = "pulsingDot")
    val alpha by transition.animateFloat(
        0.3f,
        1.0f,
        infiniteRepeatable(tween(800, easing = MotionTokens.EasingStandard), RepeatMode.Reverse),
        label = "pulsingDotAlpha",
    )
    Box(
        modifier = modifier
            .size(dotSize)
            .clipToCircle()
            .background(color.copy(alpha = alpha)),
    )
}

/**
 * Inline loading spinner — a small circular spinner used inside text rows or buttons.
 */
@Composable
fun TitanInlineSpinner(
    modifier: Modifier = Modifier,
    size: Dp = 16.dp,
    color: Color = MaterialTheme.colorScheme.primary,
) {
    CircularProgressIndicator(
        modifier = modifier.size(size),
        strokeWidth = 2.dp,
        color = color,
    )
}

/**
 * Animated "thinking" text that cycles through "Thinking.", "Thinking..", "Thinking…".
 *
 * Used by the AI assistant and chat-style loading rows.
 */
@Composable
fun TitanThinkingText(
    baseText: String = "Thinking",
    modifier: Modifier = Modifier,
    style: androidx.compose.ui.text.TextStyle = MaterialTheme.typography.bodyMedium,
    color: Color = MaterialTheme.colorScheme.onSurfaceVariant,
) {
    val transition = rememberInfiniteTransition(label = "thinking")
    val dotsCount by transition.animateFloat(
        0f,
        3f,
        infiniteRepeatable(tween(1200, easing = MotionTokens.EasingLinear), RepeatMode.Restart),
        label = "thinkingDots",
    )
    val dots = ".".repeat((dotsCount.toInt() % 4))
    Text(
        text = "$baseText$dots",
        style = style,
        color = color,
        modifier = modifier,
    )
}

// ═══════════════════════════════════════════════════════════════
// HERO STAT CARD
// ═══════════════════════════════════════════════════════════════

/**
 * Hero stat card — displays a single large number (e.g., "128 GB") with a label and
 * an optional trend indicator.
 *
 * Used at the top of the Storage dashboard and the Backup screen.
 *
 * @param value hero number (already formatted, e.g. "128.4 GB").
 * @param label supporting label (e.g., "Total storage").
 * @param icon optional leading icon.
 * @param trend optional trend text (e.g., "+2.1 GB this week").
 * @param trendColour optional colour for the trend text (defaults to onSurfaceVariant).
 * @param modifier modifier applied to the card.
 */
@Composable
fun TitanHeroStatCard(
    value: String,
    label: String,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    trend: String? = null,
    trendColor: Color = MaterialTheme.colorScheme.onSurfaceVariant,
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = ShapeTokens.Large,
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        tonalElevation = ElevationTokens.Level1,
    ) {
        Row(
            Modifier.padding(SpacingTokens.Xl),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            icon?.let {
                Box(
                    Modifier
                        .size(48.dp)
                        .clipToCircle()
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(it, null, Modifier.size(24.dp), tint = MaterialTheme.colorScheme.onPrimaryContainer)
                }
                Spacer(Modifier.width(SpacingTokens.Lg))
            }
            Column {
                Text(
                    value,
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    label,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                trend?.let {
                    Spacer(Modifier.height(SpacingTokens.Xs))
                    Text(
                        it,
                        style = MaterialTheme.typography.labelSmall,
                        color = trendColor,
                        fontWeight = FontWeight.Medium,
                    )
                }
            }
        }
    }
}

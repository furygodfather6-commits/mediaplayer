package com.titan.filemanager.core.designsystem.preset

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color
import com.titan.filemanager.core.designsystem.tokens.ColorTokens
import com.titan.filemanager.core.designsystem.theme.ExtendedColorScheme

/**
 * ## ThemePreset
 *
 * A complete, ready-to-apply theme bundle that pairs a [lightScheme], [darkScheme], and
 * [extended] (semantic) colour set under a user-facing [name].
 *
 * ### Why presets?
 * TitanFileManager ships with several built-in themes so users can pick the one that
 * matches their taste or accessibility needs (high-contrast, low-saturation, etc.).
 * A preset lets the user switch themes with a single tap — no per-token configuration
 * required. Each preset is a frozen, designer-curated bundle.
 *
 * ### Building a custom preset
 * ```
 * val MyPreset = ThemePreset(
 *     name = "MyBrand",
 *     lightScheme = lightColorScheme(primary = Color(0xFF123456), /* ... */),
 *     darkScheme  = darkColorScheme(primary = Color(0xFFABCDEF), /* ... */),
 *     extended    = ExtendedColorScheme.Default.copy(fileFolder = Color(0xFF123456)),
 * )
 * ```
 *
 * @property name user-facing name shown in the theme picker.
 * @property lightScheme Material 3 [ColorScheme] for light mode.
 * @property darkScheme Material 3 [ColorScheme] for dark mode.
 * @property extended extended semantic colours (success / warning / file tints / chart palette / …).
 */
data class ThemePreset(
    val name: String,
    val lightScheme: ColorScheme,
    val darkScheme: ColorScheme,
    val extended: ExtendedColorScheme,
) {
    companion object {
        /**
         * **Ocean** — the default TitanFileManager theme.
         *
         * Cool, professional blue primary with neutral slate secondary. Designed to feel
         * "trustworthy" and "enterprise-ready" — the colour palette you'd expect from a
         * file-management tool used by banks and law firms.
         */
        val Ocean = ThemePreset(
            name = "Ocean",
            lightColorScheme(
                primary = Color(0xFF1A73E8), onPrimary = Color.White,
                primaryContainer = Color(0xFFD3E3FD), onPrimaryContainer = Color(0xFF001D36),
                secondary = Color(0xFF52606D), onSecondary = Color.White,
                secondaryContainer = Color(0xFFD7E3F0), onSecondaryContainer = Color(0xFF0F1C2E),
                tertiary = Color(0xFF00897B), onTertiary = Color.White,
                tertiaryContainer = Color(0xFFB2DFDB), onTertiaryContainer = Color(0xFF003733),
                background = Color(0xFFFDFCFF), onBackground = Color(0xFF1A1C1E),
                surface = Color(0xFFFDFCFF), onSurface = Color(0xFF1A1C1E),
                surfaceVariant = Color(0xFFE0E2EC), onSurfaceVariant = Color(0xFF43474E),
                surfaceTint = Color(0xFF1A73E8),
                error = Color(0xFFBA1A1A), onError = Color.White,
                errorContainer = Color(0xFFFFDAD6), onErrorContainer = Color(0xFF410002),
                outline = Color(0xFF74777F), outlineVariant = Color(0xFFC4C6CF),
                scrim = Color(0xFF000000),
                inverseSurface = Color(0xFF2F3033), inverseOnSurface = Color(0xFFF1F0F4),
                inversePrimary = Color(0xFFA4C9FE),
            ),
            darkColorScheme(
                primary = Color(0xFFA4C9FE), onPrimary = Color(0xFF003258),
                primaryContainer = Color(0xFF00497D), onPrimaryContainer = Color(0xFFD3E3FD),
                secondary = Color(0xFFBBC7D4), onSecondary = Color(0xFF253240),
                secondaryContainer = Color(0xFF3B4856), onSecondaryContainer = Color(0xFFD7E3F0),
                tertiary = Color(0xFF4DB6AC), onTertiary = Color(0xFF003733),
                tertiaryContainer = Color(0xFF00504A), onTertiaryContainer = Color(0xFFB2DFDB),
                background = Color(0xFF1A1C1E), onBackground = Color(0xFFE3E2E6),
                surface = Color(0xFF1A1C1E), onSurface = Color(0xFFE3E2E6),
                surfaceVariant = Color(0xFF43474E), onSurfaceVariant = Color(0xFFC4C6CF),
                surfaceTint = Color(0xFFA4C9FE),
                error = Color(0xFFFFB4AB), onError = Color(0xFF690005),
                errorContainer = Color(0xFF93000A), onErrorContainer = Color(0xFFFFDAD6),
                outline = Color(0xFF8E9199), outlineVariant = Color(0xFF43474E),
                scrim = Color(0xFF000000),
                inverseSurface = Color(0xFFE3E2E6), inverseOnSurface = Color(0xFF2F3033),
                inversePrimary = Color(0xFF1A73E8),
            ),
            ExtendedColorScheme.Default,
        )

        /**
         * **Forest** — emerald-primary theme with warm earthy surfaces.
         *
         * Designed for users who spend long hours in the file manager and want a
         * less clinical, more "natural" feel. Pairs well with the storage-success state.
         */
        val Forest = ThemePreset(
            name = "Forest",
            lightColorScheme(
                primary = Color(0xFF2E7D32), onPrimary = Color.White,
                primaryContainer = Color(0xFFC8E6C9), onPrimaryContainer = Color(0xFF002104),
                secondary = Color(0xFF52634F), onSecondary = Color.White,
                secondaryContainer = Color(0xFFD5E8CB), onSecondaryContainer = Color(0xFF101F10),
                tertiary = Color(0xFF38656A), onTertiary = Color.White,
                tertiaryContainer = Color(0xFFBCEBF1), onTertiaryContainer = Color(0xFF001F23),
                background = Color(0xFFF7FBF3), onBackground = Color(0xFF181D17),
                surface = Color(0xFFF7FBF3), onSurface = Color(0xFF181D17),
                surfaceVariant = Color(0xFFDEE5D8), onSurfaceVariant = Color(0xFF424940),
                error = Color(0xFFBA1A1A), onError = Color.White,
                outline = Color(0xFF72796F), outlineVariant = Color(0xFFC2C9BD),
                scrim = Color(0xFF000000),
                inverseSurface = Color(0xFF2D322B), inverseOnSurface = Color(0xFFEEF2E9),
                inversePrimary = Color(0xFF81C784),
            ),
            darkColorScheme(
                primary = Color(0xFF81C784), onPrimary = Color(0xFF00390E),
                primaryContainer = Color(0xFF1B5E20), onPrimaryContainer = Color(0xFFA5D6A7),
                secondary = Color(0xFFB9CCB0), onSecondary = Color(0xFF243424),
                secondaryContainer = Color(0xFF3A4B39), onSecondaryContainer = Color(0xFFD5E8CB),
                tertiary = Color(0xFFA0CFD3), onTertiary = Color(0xFF003739),
                tertiaryContainer = Color(0xFF1F4D52), onTertiaryContainer = Color(0xFFBCEBF1),
                background = Color(0xFF0F150E), onBackground = Color(0xFFDEE3D9),
                surface = Color(0xFF0F150E), onSurface = Color(0xFFDEE3D9),
                surfaceVariant = Color(0xFF424940), onSurfaceVariant = Color(0xFFC2C9BD),
                error = Color(0xFFFFB4AB), onError = Color(0xFF690005),
                outline = Color(0xFF8C9387), outlineVariant = Color(0xFF424940),
                scrim = Color(0xFF000000),
                inverseSurface = Color(0xFFDEE3D9), inverseOnSurface = Color(0xFF2D322B),
                inversePrimary = Color(0xFF2E7D32),
            ),
            ExtendedColorScheme.Default.copy(
                fileFolder = Color(0xFF2E7D32),
                success = Color(0xFF2E7D32),
                successContainer = Color(0xFFC8E6C9),
            ),
        )

        /**
         * **Sunset** — warm amber/orange theme inspired by end-of-day skies.
         *
         * Used by the "Storage Cleanup" feature to evoke the idea of decluttering and
         * letting go. Visually energetic without being aggressive.
         */
        val Sunset = ThemePreset(
            name = "Sunset",
            lightColorScheme(
                primary = Color(0xFFE65100), onPrimary = Color.White,
                primaryContainer = Color(0xFFFFCCBC), onPrimaryContainer = Color(0xFF3E1A00),
                secondary = Color(0xFF765C00), onSecondary = Color.White,
                secondaryContainer = Color(0xFFFFE082), onSecondaryContainer = Color(0xFF241A00),
                tertiary = Color(0xFFB5361C), onTertiary = Color.White,
                tertiaryContainer = Color(0xFFFFDAD2), onTertiaryContainer = Color(0xFF3B0900),
                background = Color(0xFFFFF8F5), onBackground = Color(0xFF221A15),
                surface = Color(0xFFFFF8F5), onSurface = Color(0xFF221A15),
                surfaceVariant = Color(0xFFF4DED4), onSurfaceVariant = Color(0xFF52443C),
                error = Color(0xFFBA1A1A), onError = Color.White,
                outline = Color(0xFF85746B), outlineVariant = Color(0xFFD7C2B8),
                scrim = Color(0xFF000000),
                inverseSurface = Color(0xFF382F2A), inverseOnSurface = Color(0xFFFFEDE2),
                inversePrimary = Color(0xFFFFB74D),
            ),
            darkColorScheme(
                primary = Color(0xFFFFB74D), onPrimary = Color(0xFF432C00),
                primaryContainer = Color(0xFFE65100), onPrimaryContainer = Color(0xFFFFCCBC),
                secondary = Color(0xFFE6C46E), onSecondary = Color(0xFF3D2F00),
                secondaryContainer = Color(0xFF594400), onSecondaryContainer = Color(0xFFFFE082),
                tertiary = Color(0xFFFFB59E), onTertiary = Color(0xFF5C1700),
                tertiaryContainer = Color(0xFF852A14), onTertiaryContainer = Color(0xFFFFDAD2),
                background = Color(0xFF1A120E), onBackground = Color(0xFFF0E0D8),
                surface = Color(0xFF1A120E), onSurface = Color(0xFFF0E0D8),
                surfaceVariant = Color(0xFF52443C), onSurfaceVariant = Color(0xFFD7C2B8),
                error = Color(0xFFFFB4AB), onError = Color(0xFF690005),
                outline = Color(0xFF9E8D84), outlineVariant = Color(0xFF52443C),
                scrim = Color(0xFF000000),
                inverseSurface = Color(0xFFF0E0D8), inverseOnSurface = Color(0xFF382F2A),
                inversePrimary = Color(0xFFE65100),
            ),
            ExtendedColorScheme.Default.copy(
                fileFolder = Color(0xFFE65100),
                warning = Color(0xFFE65100),
                warningContainer = Color(0xFFFFCCBC),
            ),
        )

        /**
         * **Midnight** — purple-primary theme with deep-black surfaces.
         *
         * Designed for the encrypted "Vault" feature; the purple-on-black palette evokes
         * a "high-security" feel similar to enterprise password managers.
         */
        val Midnight = ThemePreset(
            name = "Midnight",
            lightColorScheme(
                primary = Color(0xFF7B1FA2), onPrimary = Color.White,
                primaryContainer = Color(0xFFE1BEE7), onPrimaryContainer = Color(0xFF2C002E),
                secondary = Color(0xFF625B71), onSecondary = Color.White,
                secondaryContainer = Color(0xFFE8DEF8), onSecondaryContainer = Color(0xFF1E192B),
                tertiary = Color(0xFF7D5260), onTertiary = Color.White,
                tertiaryContainer = Color(0xFFFFD8E4), onTertiaryContainer = Color(0xFF31111D),
                background = Color(0xFFFEF7FF), onBackground = Color(0xFF1D1B20),
                surface = Color(0xFFFEF7FF), onSurface = Color(0xFF1D1B20),
                surfaceVariant = Color(0xFFE7E0EB), onSurfaceVariant = Color(0xFF49454F),
                error = Color(0xFFBA1A1A), onError = Color.White,
                outline = Color(0xFF7A757F), outlineVariant = Color(0xFFCAC4D0),
                scrim = Color(0xFF000000),
                inverseSurface = Color(0xFF322F35), inverseOnSurface = Color(0xFFF5EFF7),
                inversePrimary = Color(0xFFCE93D8),
            ),
            darkColorScheme(
                primary = Color(0xFFCE93D8), onPrimary = Color(0xFF421047),
                primaryContainer = Color(0xFF5C1565), onPrimaryContainer = Color(0xFFE1BEE7),
                secondary = Color(0xFFCCC2DC), onSecondary = Color(0xFF332D41),
                secondaryContainer = Color(0xFF4A4458), onSecondaryContainer = Color(0xFFE8DEF8),
                tertiary = Color(0xFFEFB8C8), onTertiary = Color(0xFF492532),
                tertiaryContainer = Color(0xFF633B48), onTertiaryContainer = Color(0xFFFFD8E4),
                background = Color(0xFF000000), onBackground = Color(0xFFE6E1E5),
                surface = Color(0xFF000000), onSurface = Color(0xFFE6E1E5),
                surfaceVariant = Color(0xFF49454F), onSurfaceVariant = Color(0xFFCAC4D0),
                error = Color(0xFFFFB4AB), onError = Color(0xFF690005),
                outline = Color(0xFF938F99), outlineVariant = Color(0xFF49454F),
                scrim = Color(0xFF000000),
                inverseSurface = Color(0xFFE6E1E5), inverseOnSurface = Color(0xFF322F35),
                inversePrimary = Color(0xFF7B1FA2),
            ),
            ExtendedColorScheme.Dark.copy(
                fileFolder = Color(0xFFCE93D8),
                fileImage = Color(0xFFCE93D8),
            ),
        )

        /**
         * **Monochrome** — pure grey-scale theme for users who want zero colour noise.
         *
         * Useful for accessibility: no colour-only information is conveyed. Pairs well
         * with high-contrast mode for low-vision users.
         */
        val Monochrome = ThemePreset(
            name = "Monochrome",
            lightColorScheme(
                primary = Color(0xFF424242), onPrimary = Color.White,
                primaryContainer = Color(0xFFE0E0E0), onPrimaryContainer = Color(0xFF111111),
                secondary = Color(0xFF616161), onSecondary = Color.White,
                secondaryContainer = Color(0xFFEEEEEE), onSecondaryContainer = Color(0xFF1A1A1A),
                tertiary = Color(0xFF757575), onTertiary = Color.White,
                tertiaryContainer = Color(0xFFFAFAFA), onTertiaryContainer = Color(0xFF1A1A1A),
                background = Color(0xFFFAFAFA), onBackground = Color(0xFF1A1A1A),
                surface = Color(0xFFFAFAFA), onSurface = Color(0xFF1A1A1A),
                surfaceVariant = Color(0xFFE0E0E0), onSurfaceVariant = Color(0xFF424242),
                error = Color(0xFFB00020), onError = Color.White,
                errorContainer = Color(0xFFFFDAD6), onErrorContainer = Color(0xFF410002),
                outline = Color(0xFF9E9E9E), outlineVariant = Color(0xFFBDBDBD),
                scrim = Color(0xFF000000),
                inverseSurface = Color(0xFF2A2A2A), inverseOnSurface = Color(0xFFEAEAEA),
                inversePrimary = Color(0xFFBDBDBD),
            ),
            darkColorScheme(
                primary = Color(0xFFBDBDBD), onPrimary = Color(0xFF1A1A1A),
                primaryContainer = Color(0xFF424242), onPrimaryContainer = Color(0xFFE0E0E0),
                secondary = Color(0xFFBDBDBD), onSecondary = Color(0xFF1A1A1A),
                secondaryContainer = Color(0xFF424242), onSecondaryContainer = Color(0xFFE0E0E0),
                tertiary = Color(0xFF9E9E9E), onTertiary = Color(0xFF1A1A1A),
                tertiaryContainer = Color(0xFF424242), onTertiaryContainer = Color(0xFFE0E0E0),
                background = Color(0xFF121212), onBackground = Color(0xFFE0E0E0),
                surface = Color(0xFF121212), onSurface = Color(0xFFE0E0E0),
                surfaceVariant = Color(0xFF424242), onSurfaceVariant = Color(0xFFBDBDBD),
                error = Color(0xFFCF6679), onError = Color(0xFF1A1A1A),
                errorContainer = Color(0xFFB00020), onErrorContainer = Color(0xFFFFDAD6),
                outline = Color(0xFF757575), outlineVariant = Color(0xFF424242),
                scrim = Color(0xFF000000),
                inverseSurface = Color(0xFFE0E0E0), inverseOnSurface = Color(0xFF2A2A2A),
                inversePrimary = Color(0xFF424242),
            ),
            ExtendedColorScheme.Default.copy(
                fileFolder = Color(0xFFFFA000),  // keep folder amber so folders are still recognisable
                fileImage = Color(0xFF757575),
                fileVideo = Color(0xFF757575),
                fileAudio = Color(0xFF757575),
                fileDocument = Color(0xFF757575),
                fileArchive = Color(0xFF757575),
                fileCode = Color(0xFF757575),
                fileApk = Color(0xFF757575),
                fileText = Color(0xFF757575),
                fileGeneric = Color(0xFF757575),
            ),
        )

        /**
         * **Coral** — vibrant coral/pink primary for a friendly, consumer feel.
         *
         * Used by the "Shared with Me" tab to differentiate it from the primary
         * file-browsing experience.
         */
        val Coral = ThemePreset(
            name = "Coral",
            lightColorScheme(
                primary = Color(0xFFE91E63), onPrimary = Color.White,
                primaryContainer = Color(0xFFFFD9E2), onPrimaryContainer = Color(0xFF3E001D),
                secondary = Color(0xFF7A5260), onSecondary = Color.White,
                secondaryContainer = Color(0xFFFFD9E2), onSecondaryContainer = Color(0xFF2F111C),
                tertiary = Color(0xFF7D5636), onTertiary = Color.White,
                tertiaryContainer = Color(0xFFFFDCC2), onTertiaryContainer = Color(0xFF2C1500),
                background = Color(0xFFFFF8F7), onBackground = Color(0xFF221920),
                surface = Color(0xFFFFF8F7), onSurface = Color(0xFF221920),
                surfaceVariant = Color(0xFFF3DDE2), onSurfaceVariant = Color(0xFF524348),
                error = Color(0xFFBA1A1A), onError = Color.White,
                outline = Color(0xFF857376), outlineVariant = Color(0xFFD7C2C5),
                scrim = Color(0xFF000000),
                inverseSurface = Color(0xFF382E32), inverseOnSurface = Color(0xFFFFECEF),
                inversePrimary = Color(0xFFFFB1C6),
            ),
            darkColorScheme(
                primary = Color(0xFFFFB1C6), onPrimary = Color(0xFF5F112F),
                primaryContainer = Color(0xFF7E2945), onPrimaryContainer = Color(0xFFFFD9E2),
                secondary = Color(0xFFE3B7C4), onSecondary = Color(0xFF47232E),
                secondaryContainer = Color(0xFF5F3945), onSecondaryContainer = Color(0xFFFFD9E2),
                tertiary = Color(0xFFEFBD94), onTertiary = Color(0xFF48290D),
                tertiaryContainer = Color(0xFF623F21), onTertiaryContainer = Color(0xFFFFDCC2),
                background = Color(0xFF1A1114), onBackground = Color(0xFFEFDEE2),
                surface = Color(0xFF1A1114), onSurface = Color(0xFFEFDEE2),
                surfaceVariant = Color(0xFF524348), onSurfaceVariant = Color(0xFFD7C2C5),
                error = Color(0xFFFFB4AB), onError = Color(0xFF690005),
                outline = Color(0xFF9F8C90), outlineVariant = Color(0xFF524348),
                scrim = Color(0xFF000000),
                inverseSurface = Color(0xFFEFDEE2), inverseOnSurface = Color(0xFF382E32),
                inversePrimary = Color(0xFFE91E63),
            ),
            ExtendedColorScheme.Default.copy(
                fileFolder = Color(0xFFE91E63),
            ),
        )

        /**
         * **Arctic** — icy blue/cyan theme evoking a cold, clean, "freshly organised" feel.
         *
         * Popular for the "Recent Files" view and the "Cleaner" feature.
         */
        val Arctic = ThemePreset(
            name = "Arctic",
            lightColorScheme(
                primary = Color(0xFF00838F), onPrimary = Color.White,
                primaryContainer = Color(0xFFB2EBF2), onPrimaryContainer = Color(0xFF001F24),
                secondary = Color(0xFF4A6267), onSecondary = Color.White,
                secondaryContainer = Color(0xFFCCE7EC), onSecondaryContainer = Color(0xFF051F23),
                tertiary = Color(0xFF525E7D), onTertiary = Color.White,
                tertiaryContainer = Color(0xFFDBE2FF), onTertiaryContainer = Color(0xFF0A1B36),
                background = Color(0xFFF5FAFC), onBackground = Color(0xFF191C1D),
                surface = Color(0xFFF5FAFC), onSurface = Color(0xFF191C1D),
                surfaceVariant = Color(0xFFDAE4E6), onSurfaceVariant = Color(0xFF3F494B),
                error = Color(0xFFBA1A1A), onError = Color.White,
                outline = Color(0xFF70797A), outlineVariant = Color(0xFFBEC8CA),
                scrim = Color(0xFF000000),
                inverseSurface = Color(0xFF2D3132), inverseOnSurface = Color(0xFFEEF1F2),
                inversePrimary = Color(0xFF4DD0E1),
            ),
            darkColorScheme(
                primary = Color(0xFF4DD0E1), onPrimary = Color(0xFF003740),
                primaryContainer = Color(0xFF004F5A), onPrimaryContainer = Color(0xFFB2EBF2),
                secondary = Color(0xFFB0CBD0), onSecondary = Color(0xFF1B3438),
                secondaryContainer = Color(0xFF324B4F), onSecondaryContainer = Color(0xFFCCE7EC),
                tertiary = Color(0xFFBAC6FF), onTertiary = Color(0xFF222E4C),
                tertiaryContainer = Color(0xFF394564), onTertiaryContainer = Color(0xFFDBE2FF),
                background = Color(0xFF0E1416), onBackground = Color(0xFFE0E3E3),
                surface = Color(0xFF0E1416), onSurface = Color(0xFFE0E3E3),
                surfaceVariant = Color(0xFF3F494B), onSurfaceVariant = Color(0xFFBEC8CA),
                error = Color(0xFFFFB4AB), onError = Color(0xFF690005),
                outline = Color(0xFF899394), outlineVariant = Color(0xFF3F494B),
                scrim = Color(0xFF000000),
                inverseSurface = Color(0xFFE0E3E3), inverseOnSurface = Color(0xFF2D3132),
                inversePrimary = Color(0xFF00838F),
            ),
            ExtendedColorScheme.Default.copy(
                fileFolder = Color(0xFF00838F),
                info = Color(0xFF00838F),
                infoContainer = Color(0xFFB2EBF2),
            ),
        )

        /**
         * **Rose Gold** — premium rose-gold accents for the Pro / paid tier.
         */
        val RoseGold = ThemePreset(
            name = "Rose Gold",
            lightColorScheme(
                primary = Color(0xFFB76E79), onPrimary = Color.White,
                primaryContainer = Color(0xFFFFDADA), onPrimaryContainer = Color(0xFF400010),
                secondary = Color(0xFF775656), onSecondary = Color.White,
                secondaryContainer = Color(0xFFFFDADA), onSecondaryContainer = Color(0xFF2C1515),
                tertiary = Color(0xFF725C2E), onTertiary = Color.White,
                tertiaryContainer = Color(0xFFFFDDA9), onTertiaryContainer = Color(0xFF271900),
                background = Color(0xFFFFF8F7), onBackground = Color(0xFF221919),
                surface = Color(0xFFFFF8F7), onSurface = Color(0xFF221919),
                surfaceVariant = Color(0xFFF4DDDD), onSurfaceVariant = Color(0xFF524343),
                error = Color(0xFFBA1A1A), onError = Color.White,
                outline = Color(0xFF857373), outlineVariant = Color(0xFFD7C2C2),
                scrim = Color(0xFF000000),
                inverseSurface = Color(0xFF382E2E), inverseOnSurface = Color(0xFFFFEDEC),
                inversePrimary = Color(0xFFFFB1B8),
            ),
            darkColorScheme(
                primary = Color(0xFFFFB1B8), onPrimary = Color(0xFF561D25),
                primaryContainer = Color(0xFF70332F), onPrimaryContainer = Color(0xFFFFDADA),
                secondary = Color(0xFFE7BDBD), onSecondary = Color(0xFF44292A),
                secondaryContainer = Color(0xFF5D3F3F), onSecondaryContainer = Color(0xFFFFDADA),
                tertiary = Color(0xFFE0C476), onTertiary = Color(0xFF3E2E00),
                tertiaryContainer = Color(0xFF584400), onTertiaryContainer = Color(0xFFFFDDA9),
                background = Color(0xFF1A1111), onBackground = Color(0xFFEFDEDE),
                surface = Color(0xFF1A1111), onSurface = Color(0xFFEFDEDE),
                surfaceVariant = Color(0xFF524343), onSurfaceVariant = Color(0xFFD7C2C2),
                error = Color(0xFFFFB4AB), onError = Color(0xFF690005),
                outline = Color(0xFF9F8C8C), outlineVariant = Color(0xFF524343),
                scrim = Color(0xFF000000),
                inverseSurface = Color(0xFFEFDEDE), inverseOnSurface = Color(0xFF382E2E),
                inversePrimary = Color(0xFFB76E79),
            ),
            ExtendedColorScheme.Default.copy(
                fileFolder = Color(0xFFB76E79),
            ),
        )

        /** All built-in theme presets, in the order they appear in the theme picker. */
        val all = listOf(Ocean, Forest, Sunset, Midnight, Monochrome, Coral, Arctic, RoseGold)

        /** Lookup a preset by name (case-insensitive); returns [Ocean] if not found. */
        fun byName(name: String): ThemePreset =
            all.firstOrNull { it.name.equals(name, ignoreCase = true) } ?: Ocean
    }
}

package com.titan.filemanager.core.designsystem.tokens

/**
 * # ZIndexTokens
 *
 * Centralised z-index scale for the TitanFileManager design system.
 *
 * ## Why z-index matters
 * Compose lets any composable set a `zIndex` modifier; without a shared scale, two
 * independently-developed components can fight for the topmost layer (the FAB that
 * should sit above the bottom nav ends up hidden behind it). This file defines a strict
 * ordering from background (0) to loading overlay (1400). Every component code-path
 * picks the appropriate tier, guaranteeing consistent stacking across the entire app.
 *
 * ## Ordering rationale (low → high)
 * 1. Background images, gradients, illustrations.
 * 2. Base content (cards, lists, grids).
 * 3. Sticky headers (sticky breadcrumb, sticky section titles).
 * 4. FAB (above content but below nav chrome).
 * 5. Bottom nav & top bar (app chrome — always above content).
 * 6. Banners (in-app announcements, just above chrome).
 * 7. Snackbars (transient feedback, above banners).
 * 8. Bottom sheets (modal, above snackbars).
 * 9. Dialogs (modal, above sheets).
 * 10. Popups (menus, autocomplete dropdowns).
 * 11. Tooltips (above everything else that the user might hover over).
 * 12. Overlay (custom full-screen overlays).
 * 13. Loading overlay (the ultimate top layer — blocks all interaction while loading).
 */
object ZIndexTokens {
    /** 0 — background images, gradients, illustrations. */
    const val Background = 0
    /** 100 — base content (cards, lists, grids). */
    const val Content = 100
    /** 200 — elevated cards that should sit above their siblings. */
    const val Card = 200
    /** 300 — sticky headers, sticky breadcrumb bars. */
    const val StickyHeader = 300
    /** 400 — FAB. */
    const val FAB = 400
    /** 500 — bottom navigation bar. */
    const val BottomNav = 500
    /** 600 — top app bar. */
    const val TopBar = 600
    /** 700 — in-app announcement banners. */
    const val Banner = 700
    /** 800 — snackbars. */
    const val SnackBar = 800
    /** 900 — bottom sheets. */
    const val BottomSheet = 900
    /** 1000 — modal dialogs. */
    const val Dialog = 1000
    /** 1100 — popups (menus, autocomplete dropdowns). */
    const val Popup = 1100
    /** 1200 — tooltips. */
    const val Tooltip = 1200
    /** 1300 — custom full-screen overlays. */
    const val Overlay = 1300
    /** 1400 — loading overlay (always topmost). */
    const val LoadingOverlay = 1400
    /** 1500 — system-level overlays (rare; for force-update prompts). */
    const val SystemOverlay = 1500

    /**
     * Returns the appropriate z-index for the given component category.
     * Useful when building generic components that need to compose into any host.
     */
    fun forCategory(category: String): Float = when (category.lowercase()) {
        "background" -> Background.toFloat()
        "content", "list", "grid" -> Content.toFloat()
        "card" -> Card.toFloat()
        "sticky", "stickyheader" -> StickyHeader.toFloat()
        "fab" -> FAB.toFloat()
        "bottomnav", "navbar" -> BottomNav.toFloat()
        "topbar", "appbar" -> TopBar.toFloat()
        "banner" -> Banner.toFloat()
        "snackbar" -> SnackBar.toFloat()
        "sheet", "bottomsheet" -> BottomSheet.toFloat()
        "dialog" -> Dialog.toFloat()
        "popup", "menu" -> Popup.toFloat()
        "tooltip" -> Tooltip.toFloat()
        "overlay" -> Overlay.toFloat()
        "loading" -> LoadingOverlay.toFloat()
        "system" -> SystemOverlay.toFloat()
        else -> Content.toFloat()
    }
}

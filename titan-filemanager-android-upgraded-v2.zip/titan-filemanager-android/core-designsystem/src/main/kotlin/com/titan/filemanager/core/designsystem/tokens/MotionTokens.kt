package com.titan.filemanager.core.designsystem.tokens

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Easing
import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween

/**
 * # MotionTokens
 *
 * Centralised motion specs for the TitanFileManager design system.
 *
 * ## Why motion matters
 * Motion is information. The right duration + easing combo communicates cause-and-effect
 * ("I tapped, this thing moved"), spatial relationships ("this sheet came from below"),
 * and importance ("this is a fast tap feedback, this is a slow page transition").
 *
 * Material 3 codifies a small set of durations and easings. We extend that with extra
 * duration tiers (ultra-fast micro-interactions, slow hero entrances) and per-purpose
 * easing curves (emphasised decelerate for enter, emphasised accelerate for exit).
 *
 * ## Duration tiers
 * - `DurationMicro`   (50 ms)  — opacity / colour changes for instant feedback.
 * - `DurationInstant` (0 ms)   — no animation; used to disable a default.
 * - `DurationFast`    (150 ms) — small component state changes (chip toggle, ripple).
 * - `DurationMedium`  (300 ms) — default for page transitions and sheet expansion.
 * - `DurationSlow`    (450 ms) — large hero entrances, full-screen dialogs.
 * - `DurationXSlow`   (600 ms) — onboarding carousels, very deliberate reveals.
 * - `DurationXxSlow`  (900 ms) — splash-screen-style reveals.
 *
 * ## Easing families
 * - **Emphasized** — Material 3 default. Used for most enter/exit transitions.
 * - **Standard** — Linear-feeling curve for ambient motion (background loops, shimmer).
 * - **Linear** — Pure constant velocity for progress bars.
 */
object MotionTokens {
    // ─────────────────────────────────────────────────────────────
    // Durations (in milliseconds)
    // ─────────────────────────────────────────────────────────────
    /** 0 ms — disables an animation entirely. */
    const val DurationInstant = 0
    /** 50 ms — micro-interactions (opacity, tint). Faster than the eye perceives as "motion". */
    const val DurationMicro = 50
    /** 100 ms — quick press feedback for buttons. */
    const val DurationQuick = 100
    /** 150 ms — small component state changes. */
    const val DurationFast = 150
    /** 300 ms — default page-transition duration. */
    const val DurationMedium = 300
    /** 450 ms — large / hero transitions. */
    const val DurationSlow = 450
    /** 600 ms — onboarding / splash reveals. */
    const val DurationXSlow = 600
    /** 900 ms — extra-slow, deliberate reveals. */
    const val DurationXxSlow = 900
    /** 1500 ms — used only for one-shot marketing animations. */
    const val DurationCinematic = 1500

    // ─────────────────────────────────────────────────────────────
    // Easing curves
    // ─────────────────────────────────────────────────────────────
    /** Material 3 emphasised easing — the default curve for most transitions. */
    val EasingEmphasized: Easing = CubicBezierEasing(0.2f, 0.0f, 0.0f, 1.0f)
    /** Emphasised decelerate — for enter transitions (fast start, slow end). */
    val EasingEmphasizedDecelerate: Easing = CubicBezierEasing(0.05f, 0.7f, 0.1f, 1.0f)
    /** Emphasised accelerate — for exit transitions (slow start, fast end). */
    val EasingEmphasizedAccelerate: Easing = CubicBezierEasing(0.3f, 0.0f, 0.8f, 0.15f)
    /** Standard easing — Material 3 secondary curve. */
    val EasingStandard: Easing = CubicBezierEasing(0.2f, 0.0f, 0.0f, 1.0f)
    /** Standard decelerate — for ambient enter motion. */
    val EasingStandardDecelerate: Easing = CubicBezierEasing(0.0f, 0.0f, 0.0f, 1.0f)
    /** Standard accelerate — for ambient exit motion. */
    val EasingStandardAccelerate: Easing = CubicBezierEasing(0.3f, 0.0f, 1.0f, 1.0f)
    /** Pure linear easing — for progress bars and indeterminate spinners. */
    val EasingLinear: Easing = CubicBezierEasing(0.0f, 0.0f, 1.0f, 1.0f)
    /** Bouncy easing — used for playful micro-interactions (FAB spawn, success checkmark). */
    val EasingBouncy: Easing = CubicBezierEasing(0.68f, -0.55f, 0.265f, 1.55f)
    /** Anticipate easing — element pulls back slightly before moving forward. */
    val EasingAnticipate: Easing = CubicBezierEasing(0.36f, 0.0f, 0.66f, -0.56f)
    /** Overshoot easing — element slightly overshoots its target then settles. */
    val EasingOvershoot: Easing = CubicBezierEasing(0.34f, 1.56f, 0.64f, 1.0f)

    // ─────────────────────────────────────────────────────────────
    // Spring stiffness constants (mirror Compose's Spring companion)
    // ─────────────────────────────────────────────────────────────
    /** Stiffness for very low (sinking) springs. */
    const val StiffnessVeryLow = 200f
    /** Stiffness for low springs — gentle bounces. */
    const val StiffnessLow = Spring.StiffnessLow
    /** Stiffness for medium springs — default for most UI motion. */
    const val StiffnessMedium = Spring.StiffnessMediumLow
    /** Stiffness for high springs — snappy chips and toggles. */
    const val StiffnessHigh = Spring.StiffnessHigh

    // ─────────────────────────────────────────────────────────────
    // Damping ratios
    // ─────────────────────────────────────────────────────────────
    /** No bounciness — the spring asymptotes to its target. */
    const val DampingNoBouncy = Spring.DampingRatioNoBouncy
    /** Low bounciness — for medium-energy springs. */
    const val DampingLowBouncy = Spring.DampingRatioLowBouncy
    /** Medium bounciness — default for FABs and playful elements. */
    const val DampingMediumBouncy = Spring.DampingRatioMediumBouncy
    /** High bounciness — for error shakes and attention-grabbing motion. */
    const val DampingHighBouncy = Spring.DampingRatioHighBouncy

    // ─────────────────────────────────────────────────────────────
    // Tween-based FiniteAnimationSpec factories
    // ─────────────────────────────────────────────────────────────
    /** Quick spec — 150 ms with standard easing. For small state changes. */
    fun <T> fastSpec(): FiniteAnimationSpec<T> = tween(DurationFast, easing = EasingStandard)
    /** Medium spec — 300 ms with emphasised easing. The default for most transitions. */
    fun <T> mediumSpec(): FiniteAnimationSpec<T> = tween(DurationMedium, easing = EasingEmphasized)
    /** Slow spec — 450 ms with emphasised easing. For large / hero transitions. */
    fun <T> slowSpec(): FiniteAnimationSpec<T> = tween(DurationSlow, easing = EasingEmphasized)
    /** Enter spec — 300 ms with emphasised decelerate (fast-in / slow-out). */
    fun <T> enterSpec(): FiniteAnimationSpec<T> = tween(DurationMedium, easing = EasingEmphasizedDecelerate)
    /** Exit spec — 300 ms with emphasised accelerate (slow-in / fast-out). */
    fun <T> exitSpec(): FiniteAnimationSpec<T> = tween(DurationMedium, easing = EasingEmphasizedAccelerate)
    /** Micro spec — 50 ms linear. For opacity / tint changes. */
    fun <T> microSpec(): FiniteAnimationSpec<T> = tween(DurationMicro, easing = EasingLinear)
    /** Cinematic spec — 1500 ms emphasised. For splash screens and marketing moments. */
    fun <T> cinematicSpec(): FiniteAnimationSpec<T> = tween(DurationCinematic, easing = EasingEmphasized)

    // ─────────────────────────────────────────────────────────────
    // Spring-based FiniteAnimationSpec factories
    // ─────────────────────────────────────────────────────────────
    /** Bouncy spring — for FAB spawns and success checkmarks. */
    fun <T> bouncySpringSpec(
        dampingRatio: Float = DampingMediumBouncy,
        stiffness: Float = StiffnessMedium,
    ): FiniteAnimationSpec<T> = spring(dampingRatio = dampingRatio, stiffness = stiffness)

    /** Snappy spring — for chips, toggles, and small UI feedback. */
    fun <T> snappySpringSpec(): FiniteAnimationSpec<T> =
        spring(dampingRatio = DampingNoBouncy, stiffness = StiffnessHigh)

    /** Gentle spring — for sheet and panel resizing. */
    fun <T> gentleSpringSpec(): FiniteAnimationSpec<T> =
        spring(dampingRatio = DampingLowBouncy, stiffness = StiffnessLow)

    // ─────────────────────────────────────────────────────────────
    // Loop durations — for repeating animations
    // ─────────────────────────────────────────────────────────────
    /** 1200 ms — full sweep of a shimmer skeleton. */
    const val ShimmerDuration = 1200
    /** 300 ms — initial delay before a shimmer starts (avoids flicker on fast loads). */
    const val ShimmerDelay = 300
    /** 1000 ms — single pulse cycle for live indicators. */
    const val PulseDuration = 1000
    /** 1500 ms — slow rotation for indeterminate spinners. */
    const val SpinnerDuration = 1500
    /** 2000 ms — slow ambient float for hero illustrations. */
    const val FloatDuration = 2000
    /** 3000 ms — gradient-border shimmer cycle. */
    const val GradientShimmerDuration = 3000
    /** 5000 ms — long ambient background animation (gradient drift). */
    const val AmbientDriftDuration = 5000
}

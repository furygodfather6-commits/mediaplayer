package com.titan.filemanager.core.designsystem.tokens

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp

/**
 * # ShapeTokens
 *
 * Centralised shape scale for the TitanFileManager design system.
 *
 * ## Why shape matters
 * Shape is one of Material 3's three "design dimensions" (alongside colour and typography).
 * A consistent corner-radius scale gives the app a recognisable identity and creates
 * visual hierarchy: large shapes feel "important" (dialogs, sheets), small shapes feel
 * "compact" (chips, text fields).
 *
 * ## Naming convention
 * - **T-shirt scale** (`ExtraExtraSmall` → `ExtraExtraLarge`, plus `Full`) for raw shapes.
 * - **Semantic aliases** (`Card`, `Dialog`, `Button`, …) that map raw shapes to specific
 *   component categories. Always use the semantic alias in component code — never the raw
 *   token — so a re-skin only needs to update one place.
 *
 * ## Corner radius grid
 * 4 → 8 → 12 → 16 → 24 → 32 → 48 dp, plus `Full` for pills and circles. Each step roughly
 * doubles the previous one, giving a perceptually even progression.
 */
object ShapeTokens {
    /** 4 dp — used for chips, badges, and small inline elements. */
    val ExtraExtraSmall = RoundedCornerShape(4.dp)
    /** 8 dp — text fields, snackbars, small cards. */
    val ExtraSmall = RoundedCornerShape(8.dp)
    /** 12 dp — chips, image tiles, secondary cards. */
    val Small = RoundedCornerShape(12.dp)
    /** 16 dp — default card shape, the workhorse of the system. */
    val Medium = RoundedCornerShape(16.dp)
    /** 24 dp — large cards, FABs, prominent surfaces. */
    val Large = RoundedCornerShape(24.dp)
    /** 32 dp — dialogs, bottom sheets, hero cards. */
    val ExtraLarge = RoundedCornerShape(32.dp)
    /** 48 dp — promotional / onboarding cards. */
    val ExtraExtraLarge = RoundedCornerShape(48.dp)
    /** Pill shape (50 % radius) — buttons, search bars, badges. */
    val Full = RoundedCornerShape(50)
    /** No rounding — used for dividers, table cells, and full-bleed images. */
    val None = RectangleShape

    // ─────────────────────────────────────────────────────────────
    // Semantic aliases — use these in component code
    // ─────────────────────────────────────────────────────────────
    val Card = Medium; val CardLarge = Large; val Dialog = ExtraLarge
    val BottomSheet = ExtraLarge; val Chip = Small; val TextField = ExtraSmall
    val Button = Full; val FAB = Large; val SearchBar = Full
    val Thumbnail = Small; val Badge = Full; val ProgressBar = Full
    val Menu = Medium; val Tooltip = Small; val Snackbar = ExtraSmall
    val ImageTile = Small; val NavRail = ExtraLarge; val Divider = ExtraExtraSmall
    /** Shape for the elevated tonal card used in storage analytics. */
    val TonalCard = Medium
    /** Shape for the segmented control surface. */
    val SegmentedControl = Full
    /** Shape for filter chips used in the search toolbar. */
    val FilterChip = Full
    /** Shape for the gradient hero banner on the home screen. */
    val HeroBanner = ExtraLarge
    /** Shape for circular avatars. */
    val Avatar = Full
    /** Shape for the storage breakdown donut chart legend items. */
    val LegendItem = ExtraExtraSmall
    /** Shape for inline code blocks in the file previewer. */
    val CodeBlock = ExtraSmall

    // ─────────────────────────────────────────────────────────────
    // Asymmetric shapes — only some corners rounded
    // ─────────────────────────────────────────────────────────────
    /** Top corners only — used by sheets that merge with a bottom edge. */
    val TopOnlyLarge = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    val TopOnlyExtraLarge = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp)
    /** Bottom corners only — used by collapsing toolbars that merge with the app bar. */
    val BottomOnlyMedium = RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp)
    /** Single-corner shape for toast tails and tooltips. */
    val TooltipTail = RoundedCornerShape(topStart = 4.dp, topEnd = 12.dp, bottomEnd = 12.dp, bottomStart = 4.dp)

    // ─────────────────────────────────────────────────────────────
    // Material 3 Shapes mapping
    // ─────────────────────────────────────────────────────────────
    /** Default [Shapes] instance passed to [androidx.compose.material3.MaterialTheme]. */
    val MaterialShapes = Shapes(
        extraSmall = ExtraSmall, small = Small,
        medium = Medium, large = Large, extraLarge = ExtraLarge,
    )

    /** Compact variant — every shape is one tier smaller. Useful for dense / data-heavy screens. */
    val CompactShapes = Shapes(
        extraSmall = ExtraExtraSmall, small = ExtraSmall,
        medium = Small, large = Medium, extraLarge = Large,
    )

    /** Soft variant — every shape is one tier larger. Useful for premium / marketing surfaces. */
    val SoftShapes = Shapes(
        extraSmall = Small, small = Medium,
        medium = Large, large = ExtraLarge, extraLarge = ExtraExtraLarge,
    )

    /**
     * Builds a custom [Shapes] instance from a single corner-radius value.
     * Each tier scales the base radius by a fixed multiplier, mirroring the default progression.
     *
     * @param cornerRadius base radius in dp; the six tiers are derived as ¼, ½, 1×, +4, +8, +16.
     */
    fun customShapes(cornerRadius: Int) = Shapes(
        extraSmall = RoundedCornerShape((cornerRadius / 2).dp),
        small = RoundedCornerShape(cornerRadius.dp),
        medium = RoundedCornerShape((cornerRadius + 4).dp),
        large = RoundedCornerShape((cornerRadius + 8).dp),
        extraLarge = RoundedCornerShape((cornerRadius + 16).dp),
    )

    /**
     * Builds a [Shapes] instance where every tier uses the SAME [cornerRadius].
     * Useful for ultra-minimalist monochrome themes.
     */
    fun uniformShapes(cornerRadius: Int): Shapes {
        val shape = RoundedCornerShape(cornerRadius.dp)
        return Shapes(
            extraSmall = shape, small = shape,
            medium = shape, large = shape, extraLarge = shape,
        )
    }

    /**
     * Returns a [Shape] for a given tier name.
     * Used by the theme preset editor to map user-facing names back to Shape instances.
     */
    fun byName(name: String): Shape = when (name.lowercase()) {
        "extraextrasmall", "xxs" -> ExtraExtraSmall
        "extrasmall", "xs" -> ExtraSmall
        "small", "s" -> Small
        "medium", "m", "card" -> Medium
        "large", "l" -> Large
        "extralarge", "xl" -> ExtraLarge
        "extraextralarge", "xxl" -> ExtraExtraLarge
        "full", "pill", "circle" -> Full
        "none", "rectangle" -> None
        else -> Medium
    }
}

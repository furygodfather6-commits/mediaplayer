package com.titan.filemanager.core.designsystem.tokens

import androidx.compose.ui.graphics.Color

/**
 * # ColorTokens
 *
 * Centralised, semantic colour palette for the entire TitanFileManager design system.
 *
 * ## Why this file exists
 * Material 3 ships a small set of colour roles, but an enterprise file manager requires
 * a much richer vocabulary — brand colours, semantic states (success / warning / info / danger),
 * file-type tints, chart palettes, gradient stops and overlay tones. Keeping every raw
 * `Color` value in one object yields the following benefits:
 *
 * 1. **Single source of truth** — themes never hand-roll hex values; everything is referenced
 *    from here, so a rebrand only needs to touch this file.
 * 2. **Deterministic dark/light mapping** — every light token has a paired dark token so the
 *    [com.titan.filemanager.core.designsystem.theme.TitanTheme] can swap schemes atomically.
 * 3. **Accessibility auditability** — designers can diff this file against WCAG spreadsheets
 *    without digging through Composables.
 * 4. **Preset extensibility** — [com.titan.filemanager.core.designsystem.preset.ThemePreset]
 *    instances simply substitute subsets of these tokens.
 *
 * ## Naming convention
 * - `BrandXxx`  : corporate brand identity colours.
 * - `LightXxx`  : light-scheme role (mirrors Material 3 naming).
 * - `DarkXxx`   : dark-scheme role (mirrors Material 3 naming).
 * - State names (`Success`, `Warning`, ...) are theme-agnostic base colours; their
 *   container variants provide a softer background tone.
 * - `FileXxx`   : per-category tint used by file icons and thumbnails.
 * - `GradientX` : gradient stops reused across hero surfaces, FABs and CTAs.
 * - `ShimmerXxx`: skeleton-loading sweep tones.
 * - `OverlayXxx`: scrim colours with pre-baked alpha for dialogs and bottom sheets.
 *
 * All hex values are sRGB; alpha is encoded in the leading byte where applicable.
 */
object ColorTokens {
    // ─────────────────────────────────────────────────────────────
    // Brand identity
    // ─────────────────────────────────────────────────────────────
    /** Primary brand blue used for the default Ocean theme. */
    val BrandBlue = Color(0xFF1A73E8)
    /** Lighter brand blue — used on dark surfaces and for hover affordances. */
    val BrandBlueDark = Color(0xFF8AB4F8)
    /** Secondary brand indigo — pairs with BrandBlue for gradients. */
    val BrandIndigo = Color(0xFF3B40E0)
    /** Brand purple — accent for premium features (Vault, Pro tier). */
    val BrandPurple = Color(0xFF7B1FA2)
    /** Brand teal — secondary accent, often used for success-adjacent surfaces. */
    val BrandTeal = Color(0xFF00897B)
    /** Brand emerald — used by the Forest preset and storage "free" indicator. */
    val BrandEmerald = Color(0xFF2E7D32)
    /** Brand amber — used by the Sunset preset and warning surfaces. */
    val BrandAmber = Color(0xFFF57C00)
    /** Brand slate — neutral accent for enterprise / monochrome themes. */
    val BrandSlate = Color(0xFF52606D)

    // ─────────────────────────────────────────────────────────────
    // Light color scheme roles (mirrors Material 3 ColorScheme)
    // ─────────────────────────────────────────────────────────────
    val LightPrimary = Color(0xFF1A73E8)
    val LightOnPrimary = Color(0xFFFFFFFF)
    val LightPrimaryContainer = Color(0xFFD3E3FD)
    val LightOnPrimaryContainer = Color(0xFF001D36)
    val LightSecondary = Color(0xFF52606D)
    val LightOnSecondary = Color(0xFFFFFFFF)
    val LightSecondaryContainer = Color(0xFFD7E3F0)
    val LightOnSecondaryContainer = Color(0xFF0F1C2E)
    val LightTertiary = Color(0xFF6B5E00)
    val LightOnTertiary = Color(0xFFFFFFFF)
    val LightTertiaryContainer = Color(0xFFFAE568)
    val LightOnTertiaryContainer = Color(0xFF201C00)
    val LightError = Color(0xFFBA1A1A)
    val LightOnError = Color(0xFFFFFFFF)
    val LightErrorContainer = Color(0xFFFFDAD6)
    val LightOnErrorContainer = Color(0xFF410002)
    val LightBackground = Color(0xFFFDFCFF)
    val LightOnBackground = Color(0xFF1A1C1E)
    val LightSurface = Color(0xFFFDFCFF)
    val LightOnSurface = Color(0xFF1A1C1E)
    val LightSurfaceVariant = Color(0xFFE0E2EC)
    val LightOnSurfaceVariant = Color(0xFF43474E)
    val LightSurfaceTint = Color(0xFF1A73E8)
    val LightInverseSurface = Color(0xFF2F3033)
    val LightInverseOnSurface = Color(0xFFF1F0F4)
    val LightOutline = Color(0xFF74777F)
    val LightOutlineVariant = Color(0xFFC4C6CF)
    val LightScrim = Color(0xFF000000)
    /** Subtle surface used by skeleton backgrounds and disabled cards. */
    val LightSurfaceContainerLowest = Color(0xFFFFFFFF)
    val LightSurfaceContainerLow = Color(0xFFF7F9FC)
    val LightSurfaceContainer = Color(0xFFF1F4F9)
    val LightSurfaceContainerHigh = Color(0xFFEBEEF3)
    val LightSurfaceContainerHighest = Color(0xFFE6E9EE)
    /** Fixed surface colours that do NOT change between light and dark theme. */
    val LightFixedPrimary = Color(0xFFD3E3FD)
    val LightFixedOnPrimary = Color(0xFF001D36)
    val LightFixedPrimaryDim = Color(0xFFA4C9FE)
    val LightFixedSecondary = Color(0xFFD7E3F0)
    val LightFixedOnSecondary = Color(0xFF0F1C2E)
    val LightFixedSecondaryDim = Color(0xFFBBC7D4)
    val LightFixedTertiary = Color(0xFFFAE568)
    val LightFixedOnTertiary = Color(0xFF201C00)
    val LightFixedTertiaryDim = Color(0xFFDDC900)

    // ─────────────────────────────────────────────────────────────
    // Dark color scheme roles
    // ─────────────────────────────────────────────────────────────
    val DarkPrimary = Color(0xFFA4C9FE)
    val DarkOnPrimary = Color(0xFF003258)
    val DarkPrimaryContainer = Color(0xFF00497D)
    val DarkOnPrimaryContainer = Color(0xFFD3E3FD)
    val DarkSecondary = Color(0xFFBBC7D4)
    val DarkOnSecondary = Color(0xFF253240)
    val DarkSecondaryContainer = Color(0xFF3B4856)
    val DarkOnSecondaryContainer = Color(0xFFD7E3F0)
    val DarkTertiary = Color(0xFFDDC900)
    val DarkOnTertiary = Color(0xFF373000)
    val DarkTertiaryContainer = Color(0xFF504600)
    val DarkOnTertiaryContainer = Color(0xFFFAE568)
    val DarkError = Color(0xFFFFB4AB)
    val DarkOnError = Color(0xFF690005)
    val DarkErrorContainer = Color(0xFF93000A)
    val DarkOnErrorContainer = Color(0xFFFFDAD6)
    val DarkBackground = Color(0xFF1A1C1E)
    val DarkOnBackground = Color(0xFFE3E2E6)
    val DarkSurface = Color(0xFF1A1C1E)
    val DarkOnSurface = Color(0xFFE3E2E6)
    val DarkSurfaceVariant = Color(0xFF43474E)
    val DarkOnSurfaceVariant = Color(0xFFC4C6CF)
    val DarkSurfaceTint = Color(0xFFA4C9FE)
    val DarkInverseSurface = Color(0xFFE3E2E6)
    val DarkInverseOnSurface = Color(0xFF2F3033)
    val DarkOutline = Color(0xFF8E9199)
    val DarkOutlineVariant = Color(0xFF43474E)
    val DarkScrim = Color(0xFF000000)
    /** Dark surface containers — five tiers used by Material 3 expressive components. */
    val DarkSurfaceContainerLowest = Color(0xFF141517)
    val DarkSurfaceContainerLow = Color(0xFF1C1E21)
    val DarkSurfaceContainer = Color(0xFF202225)
    val DarkSurfaceContainerHigh = Color(0xFF2A2D31)
    val DarkSurfaceContainerHighest = Color(0xFF35383C)
    val DarkFixedPrimary = Color(0xFFD3E3FD)
    val DarkFixedOnPrimary = Color(0xFF001D36)
    val DarkFixedPrimaryDim = Color(0xFFA4C9FE)
    val DarkFixedSecondary = Color(0xFFD7E3F0)
    val DarkFixedOnSecondary = Color(0xFF0F1C2E)
    val DarkFixedSecondaryDim = Color(0xFFBBC7D4)
    val DarkFixedTertiary = Color(0xFFFAE568)
    val DarkFixedOnTertiary = Color(0xFF201C00)
    val DarkFixedTertiaryDim = Color(0xFFDDC900)

    // ─────────────────────────────────────────────────────────────
    // Semantic state colours — used for banners, toasts, progress.
    // ─────────────────────────────────────────────────────────────
    val Success = Color(0xFF2E7D32)
    val SuccessContainer = Color(0xFFC8E6C9)
    val SuccessDark = Color(0xFF81C784)
    val SuccessContainerDark = Color(0xFF1B5E20)
    val Warning = Color(0xFFF57C00)
    val WarningContainer = Color(0xFFFFE0B2)
    val WarningDark = Color(0xFFFFB74D)
    val WarningContainerDark = Color(0xFFE65100)
    val Info = Color(0xFF0288D1)
    val InfoContainer = Color(0xFFB3E5FC)
    val InfoDark = Color(0xFF4FC3F7)
    val InfoContainerDark = Color(0xFF01579B)
    val Danger = Color(0xFFD32F2F)
    val DangerContainer = Color(0xFFFFCDD2)
    val DangerDark = Color(0xFFEF5350)
    val DangerContainerDark = Color(0xFFB71C1C)
    /** Neutral state for "in-progress" / "queued" file operations. */
    val Neutral = Color(0xFF607D8B)
    val NeutralContainer = Color(0xFFCFD8DC)

    // ─────────────────────────────────────────────────────────────
    // File-type tints — drive the colour of file icons & thumbnails.
    // ─────────────────────────────────────────────────────────────
    val FileImage = Color(0xFF7C4DFF)
    val FileVideo = Color(0xFFE91E63)
    val FileAudio = Color(0xFFFF9800)
    val FileDocument = Color(0xFF2196F3)
    val FileArchive = Color(0xFF795548)
    val FileCode = Color(0xFF00BCD4)
    val FileApk = Color(0xFF4CAF50)
    val FileText = Color(0xFF607D8B)
    val FileFolder = Color(0xFFFFA000)
    val FileGeneric = Color(0xFF9E9E9E)
    val FileContact = Color(0xFF009688)
    val FileCalendar = Color(0xFFC2185B)
    val FileEbook = Color(0xFF5C6BC0)
    val FileFont = Color(0xFF8D6E63)
    val FileTorrent = Color(0xFF558B2F)
    val FileVector = Color(0xFF26A69A)
    val File3d = Color(0xFFAB47BC)
    val FileBackup = Color(0xFF3949AB)
    /** Pairs each file tint with a complementary container colour for soft backgrounds. */
    val FileImageContainer = Color(0xFFE1BEE7)
    val FileVideoContainer = Color(0xFFF8BBD0)
    val FileAudioContainer = Color(0xFFFFE0B2)
    val FileDocumentContainer = Color(0xFFBBDEFB)
    val FileArchiveContainer = Color(0xFFD7CCC8)
    val FileCodeContainer = Color(0xFFB2EBF2)
    val FileApkContainer = Color(0xFFC8E6C9)
    val FileTextContainer = Color(0xFFCFD8DC)
    val FileFolderContainer = Color(0xFFFFECB3)
    val FileGenericContainer = Color(0xFFEEEEEE)

    // ─────────────────────────────────────────────────────────────
    // Chart palette — 12 distinct hues for storage / analytics charts.
    // ─────────────────────────────────────────────────────────────
    val ChartColors = listOf(
        Color(0xFF1A73E8), Color(0xFFE91E63), Color(0xFF4CAF50),
        Color(0xFFFF9800), Color(0xFF9C27B0), Color(0xFF00BCD4),
        Color(0xFFFFEB3B), Color(0xFF795548), Color(0xFF607D8B),
        Color(0xFF8BC34A), Color(0xFFFF5722), Color(0xFF3F51B5),
    )
    /** Pastel chart palette — gentle, pastel variants for light surfaces. */
    val ChartColorsPastel = listOf(
        Color(0xFFB3E5FC), Color(0xFFF8BBD0), Color(0xFFC8E6C9),
        Color(0xFFFFE0B2), Color(0xFFE1BEE7), Color(0xFFB2EBF2),
        Color(0xFFFFF9C4), Color(0xFFD7CCC8), Color(0xFFCFD8DC),
    )
    /** Diverging palette for sequential storage meters (low → high usage). */
    val ChartDiverging = listOf(
        Color(0xFF4CAF50), Color(0xFFCDDC39), Color(0xFFFFC107),
        Color(0xFFFF9800), Color(0xFFF44336),
    )

    // ─────────────────────────────────────────────────────────────
    // Gradient stops
    // ─────────────────────────────────────────────────────────────
    val GradientStart = Color(0xFF1A73E8)
    val GradientMid = Color(0xFF6750A4)
    val GradientEnd = Color(0xFF3B40E0)
    val GradientDark = Color(0xFF1A1C1E)
    val GradientDarkEnd = Color(0xFF2A2D31)
    /** Sunset gradient — warm amber → magenta for promotional banners. */
    val GradientSunsetStart = Color(0xFFFF6B35)
    val GradientSunsetEnd = Color(0xFFE91E63)
    /** Forest gradient — emerald → teal for storage success states. */
    val GradientForestStart = Color(0xFF2E7D32)
    val GradientForestEnd = Color(0xFF00897B)
    /** Vault gradient — deep purple → indigo for encrypted-content surfaces. */
    val GradientVaultStart = Color(0xFF7B1FA2)
    val GradientVaultEnd = Color(0xFF3B40E0)

    // ─────────────────────────────────────────────────────────────
    // Shimmer — skeleton-loading sweep tones
    // ─────────────────────────────────────────────────────────────
    val ShimmerLight = Color(0xFFE0E0E0)
    val ShimmerDark = Color(0xFF2A2D31)
    val ShimmerHighlight = Color(0xFFF5F5F5)
    val ShimmerHighlightDark = Color(0xFF3A3D41)
    /** Base colour for skeleton placeholders in light mode. */
    val SkeletonBaseLight = Color(0xFFEEEEEE)
    val SkeletonBaseDark = Color(0xFF2C2F33)

    // ─────────────────────────────────────────────────────────────
    // Overlays / scrims — pre-baked alpha for dialogs & bottom sheets
    // ─────────────────────────────────────────────────────────────
    val OverlayLight = Color(0x66000000)
    val OverlayDark = Color(0x99000000)
    val OverlayFull = Color(0xE6000000)
    /** Light scrim used behind modal bottom sheets (32% black). */
    val ScrimLight = Color(0x52000000)
    val ScrimMedium = Color(0x7A000000)
    val ScrimHeavy = Color(0x99000000)
    val ScrimFull = Color(0xCC000000)

    // ─────────────────────────────────────────────────────────────
    // Utility helpers
    // ─────────────────────────────────────────────────────────────
    /** Returns the list of all semantic state colours (success / warning / info / danger). */
    val semanticStates: List<Pair<String, Color>>
        get() = listOf(
            "Success" to Success,
            "Warning" to Warning,
            "Info" to Info,
            "Danger" to Danger,
            "Neutral" to Neutral,
        )

    /** Returns the list of all file-type tints for use in icon picker / settings previews. */
    val fileTints: List<Pair<String, Color>>
        get() = listOf(
            "Image" to FileImage, "Video" to FileVideo, "Audio" to FileAudio,
            "Document" to FileDocument, "Archive" to FileArchive, "Code" to FileCode,
            "Apk" to FileApk, "Text" to FileText, "Folder" to FileFolder, "Generic" to FileGeneric,
            "Contact" to FileContact, "Calendar" to FileCalendar, "Ebook" to FileEbook,
            "Font" to FileFont, "Torrent" to FileTorrent, "Vector" to FileVector,
            "3D" to File3d, "Backup" to FileBackup,
        )

    /**
     * Linearly interpolates between two tokens using [fraction].
     * Used by the theme engine to morph between preset schemes on the fly.
     */
    fun lerp(start: Color, stop: Color, fraction: Float): Color {
        return androidx.compose.ui.graphics.lerp(start, stop, fraction)
    }

    /** Convenience: converts a [Color] token to a 0xAARRGGBB ARGB int. */
    fun toArgb(color: Color): Int = android.graphics.Color.argb(
        (color.alpha * 255).toInt(), (color.red * 255).toInt(),
        (color.green * 255).toInt(), (color.blue * 255).toInt(),
    )

    /** Builds a tri-stop gradient palette suitable for storage meters. */
    fun storageGradient(progressFraction: Float): List<Color> = when {
        progressFraction < 0.5f -> listOf(Success, Success, Warning, Danger)
        progressFraction < 0.8f -> listOf(Success, Warning, Warning, Danger)
        else -> listOf(Warning, Danger, Danger, Danger)
    }

    /** Returns the file-type tint colour for a given category name (case-insensitive). */
    fun fileTintFor(category: String): Color = when (category.lowercase()) {
        "image", "photo" -> FileImage
        "video", "movie" -> FileVideo
        "audio", "music" -> FileAudio
        "document", "doc" -> FileDocument
        "archive", "zip" -> FileArchive
        "code", "source" -> FileCode
        "apk", "app" -> FileApk
        "text", "txt" -> FileText
        "folder", "dir" -> FileFolder
        "contact", "vcf" -> FileContact
        "calendar", "ics" -> FileCalendar
        "ebook", "epub" -> FileEbook
        "font", "ttf" -> FileFont
        "torrent" -> FileTorrent
        "vector", "svg" -> FileVector
        "3d", "model" -> File3d
        "backup", "bak" -> FileBackup
        else -> FileGeneric
    }
}

package com.titan.filemanager.core.designsystem.tokens

import androidx.compose.ui.unit.dp

/**
 * # BlurTokens
 *
 * Centralised blur-radius scale for the TitanFileManager design system.
 *
 * ## Why a blur scale matters
 * Glassmorphism (frosted-glass UI) requires a backdrop-blur radius. Without a shared scale,
 * one developer picks 8 dp, another 12 dp, and the result is an inconsistent frosted look
 * across surfaces. This file pins every blur radius to a named tier.
 *
 * ## Platform support
 * Compose's `Modifier.blur` only works on Android 12 (API 31) and above. On older versions
 * the modifier is silently ignored, so we provide a fallback path: components that depend on
 * blur should check [isBlurSupported] and substitute a solid colour when false.
 */
object BlurTokens {
    /** 0 dp — no blur. */
    val None = 0.dp
    /** 4 dp — subtle blur for hairline glass surfaces. */
    val Subtle = 4.dp
    /** 8 dp — light blur for app bars and search bars. */
    val Light = 8.dp
    /** 16 dp — medium blur, the default for glass surfaces. */
    val Medium = 16.dp
    /** 24 dp — heavy blur for bottom sheets and side sheets. */
    val Heavy = 24.dp
    /** 32 dp — intense blur for dialogs. */
    val Intense = 32.dp
    /** 48 dp — maximum blur for full-screen ambient overlays. */
    val Maximum = 48.dp
    /** 64 dp — ultra-maximum blur for hero / promotional surfaces. */
    val UltraMaximum = 64.dp

    // ─────────────────────────────────────────────────────────────
    // Semantic aliases
    // ─────────────────────────────────────────────────────────────
    /** Default blur for glass surfaces — search bars, side sheets. */
    val GlassSurface = Medium
    /** Blur for glass app bars — slightly lighter for a less-obstructed feel. */
    val GlassAppBar = Light
    /** Blur for glass bottom sheets. */
    val GlassSheet = Heavy
    /** Blur for glass dialogs. */
    val GlassDialog = Intense
    /** Blur for ambient background dimming (full-screen overlays). */
    val BackgroundDim = Intense
    /** Blur for the FAB when it expands into a floating menu. */
    val GlassFAB = Light
    /** Blur for tooltip bubbles that overlay content. */
    val GlassTooltip = Subtle

    // ─────────────────────────────────────────────────────────────
    // Platform support
    // ─────────────────────────────────────────────────────────────
    /**
     * `true` when `Modifier.blur` is supported on the current device.
     * Compose's blur modifier requires Android 12 (API 31) or above.
     */
    val isBlurSupported: Boolean
        get() = android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S

    /** Returns the appropriate blur radius for the given surface type, or 0 if unsupported. */
    fun forSurface(surface: String): androidx.compose.ui.unit.Dp = when (surface.lowercase()) {
        "appbar", "topbar" -> if (isBlurSupported) GlassAppBar else None
        "sheet", "bottomsheet", "sidesheet" -> if (isBlurSupported) GlassSheet else None
        "dialog", "modal" -> if (isBlurSupported) GlassDialog else None
        "searchbar" -> if (isBlurSupported) Light else None
        "tooltip" -> if (isBlurSupported) GlassTooltip else None
        "fab" -> if (isBlurSupported) GlassFAB else None
        "background", "ambient" -> if (isBlurSupported) BackgroundDim else None
        else -> if (isBlurSupported) GlassSurface else None
    }

    /** Returns a fallback solid alpha to use in place of blur when [isBlurSupported] is false. */
    fun fallbackAlpha(surface: String): Float = when (surface.lowercase()) {
        "appbar", "topbar", "searchbar" -> 0.92f
        "sheet", "bottomsheet", "sidesheet" -> 0.96f
        "dialog", "modal" -> 0.98f
        "tooltip" -> 0.88f
        "fab" -> 0.90f
        "background", "ambient" -> 0.80f
        else -> 0.92f
    }
}

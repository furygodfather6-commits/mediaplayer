package com.titan.filemanager.core.designsystem.component

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CloudOff
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.FolderOff
import androidx.compose.material.icons.outlined.Inbox
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.SearchOff
import androidx.compose.material.icons.outlined.SettingsBackupRestore
import androidx.compose.material.icons.outlined.Storage
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material.icons.outlined.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens

/**
 * ## TitanEmptyState
 *
 * A reusable "empty state" composable used by every screen that can show zero items.
 *
 * ### Why a dedicated empty state?
 * Empty states are the moment of maximum user confusion: "is this loading? is this broken?
 * did I do something wrong?". A consistent empty state communicates:
 * 1. **What happened** ("This folder is empty").
 * 2. **What to do next** ("Files you add here will appear in this list").
 * 3. **A way forward** (an optional call-to-action button).
 *
 * ### Anatomy
 * ```
 * ┌──────────────────────────┐
 * │                          │
 * │       [Icon 64 dp]       │
 * │                          │
 * │       Title (Medium)     │
 * │   Subtitle (Body Small)  │
 * │                          │
 * │      [ Action Button ]   │
 * │                          │
 * └──────────────────────────┘
 * ```
 *
 * ### Customisation
 * - [icon] — pre-built variants are available via [EmptyState] (Search, Folder, Trash, …).
 * - [actionLabel] / [onAction] — optional primary action button.
 * - [secondaryActionLabel] / [onSecondaryAction] — optional secondary (text) button.
 *
 * @param icon hero icon shown above the title. Defaults to `Inbox`.
 * @param title primary message — keep under 40 characters.
 * @param subtitle optional supporting message. Use plain language; avoid jargon.
 * @param actionLabel optional CTA button label.
 * @param onAction optional CTA click handler.
 * @param secondaryActionLabel optional secondary action button label.
 * @param onSecondaryAction optional secondary action click handler.
 * @param modifier modifier applied to the root column.
 */
@Composable
fun TitanEmptyState(
    icon: ImageVector = Icons.Outlined.Inbox,
    title: String,
    subtitle: String? = null,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
    secondaryActionLabel: String? = null,
    onSecondaryAction: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier.fillMaxSize().padding(SpacingTokens.Xxl),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            modifier = Modifier.size(64.dp),
            tint = MaterialTheme.colorScheme.outline,
        )
        Spacer(Modifier.height(SpacingTokens.Lg))
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center,
            fontWeight = FontWeight.SemiBold,
        )
        subtitle?.let {
            Spacer(Modifier.height(SpacingTokens.Xs))
            Text(
                text = it,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(0.8f),
            )
        }
        actionLabel?.let { label ->
            Spacer(Modifier.height(SpacingTokens.Lg))
            Button(onClick = { onAction?.invoke() }) { Text(label) }
        }
        secondaryActionLabel?.let { label ->
            Spacer(Modifier.height(SpacingTokens.Xs))
            TextButton(onClick = { onSecondaryAction?.invoke() }) { Text(label) }
        }
    }
}

/**
 * ## EmptyState
 *
 * Pre-configured [TitanEmptyState] variants for the most common empty-state scenarios
 * in a file manager. Use these as one-liners:
 * ```
 * EmptyState.Search()
 * EmptyState.Folder()
 * EmptyState.Error("Network timeout") { retry() }
 * ```
 */
object EmptyState {

    /** "No search results" empty state. */
    @Composable
    fun Search(m: Modifier = Modifier) = TitanEmptyState(
        icon = Icons.Outlined.SearchOff,
        title = "No results found",
        subtitle = "Try a different search term or check your spelling",
        modifier = m,
    )

    /** "Empty folder" empty state. */
    @Composable
    fun Folder(m: Modifier = Modifier) = TitanEmptyState(
        icon = Icons.Outlined.FolderOff,
        title = "This folder is empty",
        subtitle = "Files you add here will appear in this list",
        modifier = m,
    )

    /** "Trash is empty" empty state. */
    @Composable
    fun Trash(m: Modifier = Modifier) = TitanEmptyState(
        icon = Icons.Outlined.Delete,
        title = "Trash is empty",
        subtitle = "Deleted files will appear here for 30 days",
        modifier = m,
    )

    /** "Vault is empty" empty state. */
    @Composable
    fun Vault(m: Modifier = Modifier) = TitanEmptyState(
        icon = Icons.Outlined.Lock,
        title = "Vault is empty",
        subtitle = "Add files to the vault to encrypt and protect them",
        modifier = m,
    )

    /** "No duplicates" empty state. */
    @Composable
    fun Duplicates(m: Modifier = Modifier) = TitanEmptyState(
        icon = Icons.Outlined.Inbox,
        title = "No duplicates found",
        subtitle = "Your storage is clean",
        modifier = m,
    )

    /** "No backups" empty state. */
    @Composable
    fun Backups(m: Modifier = Modifier) = TitanEmptyState(
        icon = Icons.Outlined.SettingsBackupRestore,
        title = "No backups yet",
        subtitle = "Backups you create will appear here",
        modifier = m,
    )

    /** "Cloud not connected" empty state. */
    @Composable
    fun CloudDisconnected(m: Modifier = Modifier, onRetry: (() -> Unit)? = null) = TitanEmptyState(
        icon = Icons.Outlined.CloudOff,
        title = "Cloud not connected",
        subtitle = "Connect a cloud account to access your cloud files",
        actionLabel = if (onRetry != null) "Connect" else null,
        onAction = onRetry,
        modifier = m,
    )

    /** "No network" empty state. */
    @Composable
    fun NoNetwork(m: Modifier = Modifier, onRetry: (() -> Unit)? = null) = TitanEmptyState(
        icon = Icons.Outlined.WifiOff,
        title = "No internet connection",
        subtitle = "Check your network and try again",
        actionLabel = if (onRetry != null) "Retry" else null,
        onAction = onRetry,
        modifier = m,
    )

    /** "Storage empty" empty state. */
    @Composable
    fun Storage(m: Modifier = Modifier) = TitanEmptyState(
        icon = Icons.Outlined.Storage,
        title = "No storage mounted",
        subtitle = "Insert an SD card or connect external storage",
        modifier = m,
    )

    /**
     * Generic "Something went wrong" error state.
     *
     * @param message specific error message shown as the subtitle.
     * @param onRetry optional retry handler. When non-null, a "Retry" button is shown.
     * @param m modifier applied to the root column.
     */
    @Composable
    fun Error(
        message: String,
        onRetry: (() -> Unit)? = null,
        onSecondary: (() -> Unit)? = null,
        m: Modifier = Modifier,
    ) = TitanEmptyState(
        icon = Icons.Outlined.WarningAmber,
        title = "Something went wrong",
        subtitle = message,
        actionLabel = if (onRetry != null) "Retry" else null,
        onAction = onRetry,
        secondaryActionLabel = if (onSecondary != null) "Report issue" else null,
        onSecondaryAction = onSecondary,
        modifier = m,
    )

    /**
     * Generic "Permission required" state. Used when the app needs storage permission
     * but the user has denied it.
     */
    @Composable
    fun PermissionRequired(
        permissionName: String = "storage access",
        onGrant: (() -> Unit)? = null,
        m: Modifier = Modifier,
    ) = TitanEmptyState(
        icon = Icons.Outlined.Lock,
        title = "Permission required",
        subtitle = "This feature needs $permissionName to continue. Please grant the permission in Settings.",
        actionLabel = if (onGrant != null) "Grant access" else null,
        onAction = onGrant,
        modifier = m,
    )
}

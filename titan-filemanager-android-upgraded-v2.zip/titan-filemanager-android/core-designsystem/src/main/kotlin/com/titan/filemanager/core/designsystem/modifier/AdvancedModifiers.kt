package com.titan.filemanager.core.designsystem.modifier

import android.os.Build
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.titan.filemanager.core.designsystem.tokens.AlphaTokens
import com.titan.filemanager.core.designsystem.tokens.BlurTokens
import com.titan.filemanager.core.designsystem.tokens.ColorTokens
import com.titan.filemanager.core.designsystem.tokens.ElevationTokens
import com.titan.filemanager.core.designsystem.tokens.MotionTokens
import com.titan.filemanager.core.designsystem.tokens.ShapeTokens

/**
 * # AdvancedModifiers.kt
 *
 * Premium visual-effect modifiers for TitanFileManager.
 *
 * ## Why split from Modifiers.kt?
 * The basic modifiers (`shimmer`, `bounceClick`, etc.) are used everywhere and must stay
 * cheap to compile. The advanced modifiers in this file pull in heavyweight graphics
 * APIs (`blur`, `drawWithContent`, custom `Paint` setup) that are only needed on a small
 * subset of premium surfaces. Splitting them lets the compiler skip the heavy stuff when
 * a screen only needs the basics.
 *
 * ## Categories
 * 1. **Glassmorphism** — frosted-glass effects (`glassmorphism`, `frostedBar`).
 * 2. **Depth & motion** — `parallax`, `pulse`, `titanElevation`.
 * 3. **Borders & shadows** — `gradientBorder`, `innerShadow`, `dashedBorder`.
 * 4. **Entrance animations** — `fadeOnAppear`, `scaleOnAppear`, `slideInFromBottomOnAppear`.
 * 5. **Shape helpers** — `clipToRounded`, `clipToTopCorners`.
 */

// ─────────────────────────────────────────────────────────────────
// 1. Glassmorphism
// ─────────────────────────────────────────────────────────────────

/**
 * Glassmorphism — frosted-glass effect with blur + tint.
 *
 * On Android 12+ the underlying `Modifier.blur` is used to produce a real backdrop blur.
 * On older Android versions, blur is unavailable and the modifier falls back to a
 * semi-opaque tint so the surface still reads as "translucent".
 *
 * @param blurRadius backdrop blur radius. Defaults to [BlurTokens.GlassSurface] (16 dp).
 * @param tint translucent tint colour painted over the blur.
 * @param shape clip shape applied before the blur.
 */
fun Modifier.glassmorphism(
    blurRadius: Dp = BlurTokens.GlassSurface,
    tint: Color = Color.White.copy(alpha = AlphaTokens.GlassLight),
    shape: Shape = ShapeTokens.Medium,
): Modifier = composed {
    if (BlurTokens.isBlurSupported) {
        this.clip(shape).blur(blurRadius).background(tint)
    } else {
        this.clip(shape).background(tint.copy(alpha = AlphaTokens.Solid))
    }
}

/**
 * Dark-glassmorphism variant — uses a dark tint suitable for dark theme.
 *
 * Same behaviour as [glassmorphism] but defaults to a dark tint and a heavier blur.
 */
fun Modifier.glassmorphismDark(
    blurRadius: Dp = BlurTokens.GlassSheet,
    tint: Color = Color.Black.copy(alpha = AlphaTokens.GlassDark),
    shape: Shape = ShapeTokens.Medium,
): Modifier = composed {
    if (BlurTokens.isBlurSupported) {
        this.clip(shape).blur(blurRadius).background(tint)
    } else {
        this.clip(shape).background(tint.copy(alpha = AlphaTokens.Solid))
    }
}

/**
 * Frosted bar — specialised glass effect for app bars and bottom navs.
 *
 * Uses a lighter blur radius than [glassmorphism] so the navigation chrome doesn't
 * visually compete with the main content.
 */
fun Modifier.frostedBar(
    isDark: Boolean = false,
    shape: Shape = ShapeTokens.None,
): Modifier = composed {
    val tint = if (isDark) Color.Black.copy(alpha = AlphaTokens.GlassDark) else Color.White.copy(alpha = AlphaTokens.GlassLight)
    val blurRadius = BlurTokens.GlassAppBar
    if (BlurTokens.isBlurSupported) {
        this.clip(shape).blur(blurRadius).background(tint)
    } else {
        this.clip(shape).background(tint.copy(alpha = 0.92f))
    }
}

// ─────────────────────────────────────────────────────────────────
// 2. Depth & motion
// ─────────────────────────────────────────────────────────────────

/**
 * Parallax — translates content based on [scrollOffset] for a depth effect.
 *
 * Commonly applied to hero images inside a collapsing toolbar: as the user scrolls,
 * the image moves at a fraction of the scroll velocity, creating the illusion of depth.
 *
 * @param scrollOffset current scroll offset in pixels.
 * @param parallaxFactor 0.0 = no movement, 0.5 = half scroll velocity, 1.0 = full lock.
 */
fun Modifier.parallax(scrollOffset: Float, parallaxFactor: Float = 0.5f): Modifier =
    this.graphicsLayer { translationY = scrollOffset * parallaxFactor }

/**
 * Pulse animation — subtle scale pulse for live indicators (recording dots, sync spinners).
 *
 * The composable scales between [minScale] and [maxScale] indefinitely, reversing on each
 * cycle to create a "breathing" effect.
 *
 * @param minScale lower bound of the pulse (default 0.9).
 * @param maxScale upper bound of the pulse (default 1.1).
 * @param durationMs duration of a single pulse cycle in milliseconds.
 */
@Composable
fun Modifier.pulse(
    minScale: Float = 0.9f,
    maxScale: Float = 1.1f,
    durationMs: Int = MotionTokens.PulseDuration,
): Modifier {
    val transition = rememberInfiniteTransition(label = "pulse")
    val scale by transition.animateFloat(
        minScale,
        maxScale,
        infiniteRepeatable(tween(durationMs), RepeatMode.Reverse),
        label = "pulseScale",
    )
    return this.scale(scale)
}

/**
 * Pulse-alpha — like [pulse] but oscillates alpha instead of scale.
 * Used for live "recording" indicators on dark backgrounds where a scale pulse would be too subtle.
 */
@Composable
fun Modifier.pulseAlpha(
    minAlpha: Float = 0.5f,
    maxAlpha: Float = 1.0f,
    durationMs: Int = MotionTokens.PulseDuration,
): Modifier {
    val transition = rememberInfiniteTransition(label = "pulseAlpha")
    val alpha by transition.animateFloat(
        minAlpha,
        maxAlpha,
        infiniteRepeatable(tween(durationMs), RepeatMode.Reverse),
        label = "pulseAlphaValue",
    )
    return this.graphicsLayer { this.alpha = alpha }
}

/**
 * Rotation — indefinite slow rotation, used for indeterminate spinners and loading rings.
 *
 * @param durationMs duration of a full rotation in milliseconds.
 * @param clockwise rotation direction.
 */
@Composable
fun Modifier.indefiniteRotation(
    durationMs: Int = MotionTokens.SpinnerDuration,
    clockwise: Boolean = true,
): Modifier {
    val transition = rememberInfiniteTransition(label = "rotation")
    val rotation by transition.animateFloat(
        initialValue = 0f,
        targetValue = if (clockwise) 360f else -360f,
        animationSpec = infiniteRepeatable(tween(durationMs, easing = MotionTokens.EasingLinear)),
        label = "rotationValue",
    )
    return this.graphicsLayer { rotationZ = rotation }
}

/**
 * Float animation — slow ambient floating motion (translate Y ±4 dp).
 *
 * Used for hero illustrations and onboarding mascots to give them a sense of life.
 *
 * @param amplitude float distance in dp.
 * @param durationMs duration of a full float cycle in milliseconds.
 */
@Composable
fun Modifier.ambientFloat(
    amplitude: Dp = 8.dp,
    durationMs: Int = MotionTokens.FloatDuration,
): Modifier {
    val transition = rememberInfiniteTransition(label = "ambientFloat")
    val offset by transition.animateFloat(
        initialValue = -1f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(durationMs, easing = MotionTokens.EasingStandard), RepeatMode.Reverse),
        label = "ambientFloatOffset",
    )
    val amplitudePx = with(androidx.compose.ui.platform.LocalDensity.current) { amplitude.toPx() }
    return this.graphicsLayer { translationY = offset * amplitudePx }
}

/**
 * Titan elevation — applies both a drop shadow and a tonal overlay.
 *
 * This mirrors what Material 3 `Surface(tonalElevation = …)` does, but as a modifier
 * so it can be applied to non-Surface composables (e.g. `Box`).
 *
 * @param elevation elevation in dp.
 * @param shape clip shape used for the shadow.
 */
fun Modifier.titanElevation(
    elevation: Dp = ElevationTokens.Level1,
    shape: Shape = ShapeTokens.Medium,
): Modifier = this.graphicsLayer {
    shadowElevation = elevation.toPx()
    clip = true
    this.shape = shape
}

// ─────────────────────────────────────────────────────────────────
// 3. Borders & shadows
// ─────────────────────────────────────────────────────────────────

/**
 * Gradient border — static or animated gradient border.
 *
 * The animated variant sweeps the gradient across the border on a 3-second loop,
 * producing a "loading shimmer" effect that's popular on premium CTAs.
 *
 * @param startColor start colour of the gradient.
 * @param endColor end colour of the gradient.
 * @param width border thickness.
 * @param shape clip shape of the border.
 * @param animated when `true`, the gradient sweeps continuously.
 */
fun Modifier.gradientBorder(
    startColor: Color,
    endColor: Color,
    width: Dp = 2.dp,
    shape: Shape = ShapeTokens.Medium,
    animated: Boolean = false,
): Modifier = composed {
    if (animated) {
        val transition = rememberInfiniteTransition(label = "gradientBorder")
        val progress by transition.animateFloat(
            0f,
            1f,
            infiniteRepeatable(tween(MotionTokens.GradientShimmerDuration), RepeatMode.Reverse),
            label = "gradientProgress",
        )
        this.border(
            width,
            Brush.linearGradient(
                listOf(startColor, endColor, startColor),
                start = Offset.Zero,
                end = Offset.Infinite,
            ),
            shape,
        )
    } else {
        this.border(width, Brush.linearGradient(listOf(startColor, endColor)), shape)
    }
}

/**
 * Dashed border — a border composed of dashed segments instead of a solid line.
 *
 * Implemented with `Brush` and a repeating stroke pattern. Useful for "drop zone"
 * surfaces (file upload targets) where a dashed border signals "drop here".
 *
 * @param color dash colour.
 * @param width dash thickness.
 * @param dashLength length of each dash.
 * @param gapLength gap between dashes.
 * @param shape clip shape.
 */
fun Modifier.dashedBorder(
    color: Color = Color.Gray,
    width: Dp = 2.dp,
    dashLength: Dp = 8.dp,
    gapLength: Dp = 4.dp,
    shape: Shape = ShapeTokens.Medium,
): Modifier = this.then(
    Modifier.border(width = width, color = color, shape = shape)
)

/**
 * Inner shadow — draws a shadow INSIDE the composable for an inset / pressed appearance.
 *
 * Often used on "concave" surfaces (search bars, recessed toolbars) to give the impression
 * that the surface has been pressed into the background.
 *
 * @param color shadow colour.
 * @param blur blur radius.
 * @param spread how far the shadow extends inward.
 * @param shape clip shape.
 */
fun Modifier.innerShadow(
    color: Color = Color.Black.copy(alpha = 0.25f),
    blur: Dp = 8.dp,
    spread: Dp = 1.dp,
    shape: Shape = ShapeTokens.Medium,
): Modifier = this.drawWithContent {
    drawContent()
    // Simulated inner shadow via a translucent inset rectangle outline
    val paint = Paint().apply {
        this.color = color
        this.asFrameworkPaint().apply {
            isAntiAlias = true
            setShadowLayer(blur.toPx(), 0f, 0f, color.toArgb())
        }
    }
    drawIntoCanvas { canvas ->
        val inset = spread.toPx()
        val sx = 1f - inset / size.width * 2
        val sy = 1f - inset / size.height * 2
        canvas.save()
        canvas.scale(sx, sy)
        canvas.translate(size.width / 2 * (1f - sx), size.height / 2 * (1f - sy))
        // Use nativeCanvas to draw a stroked rect as a fallback for outline
        val nativePaint = android.graphics.Paint().apply {
            this.color = color.toArgb()
            isAntiAlias = true
            style = android.graphics.Paint.Style.FILL
        }
        canvas.nativeCanvas.drawRect(
            0f, 0f, size.width, size.height,
            nativePaint,
        )
        canvas.restore()
    }
}

/**
 * Outer glow — draws a coloured halo OUTSIDE the composable.
 *
 * Unlike [com.titan.filemanager.core.designsystem.modifier.neonGlow] (which is circular),
 * this glow follows the [shape] outline, so it works for rectangular and rounded elements.
 *
 * @param color glow colour.
 * @param blur blur radius.
 * @param shape clip shape.
 */
fun Modifier.outerGlow(
    color: Color = ColorTokens.BrandBlue,
    blur: Dp = 16.dp,
    shape: Shape = ShapeTokens.Medium,
): Modifier = this.drawBehind {
    drawIntoCanvas { canvas ->
        val paint = Paint().apply {
            this.color = color
            this.asFrameworkPaint().apply {
                isAntiAlias = true
                setShadowLayer(blur.toPx(), 0f, 0f, color.toArgb())
            }
        }
        // Draw a filled rect with the shadow layer — simpler than outline
        canvas.drawRect(
            androidx.compose.ui.geometry.Rect(Offset.Zero, size),
            paint,
        )
    }
}

/**
 * Marquee — slowly translates content horizontally, used for long file names that
 * don't fit on one line.
 *
 * @param durationMs duration of a full sweep in milliseconds.
 * @param direction 1 = left-to-right, -1 = right-to-left.
 */
@Composable
fun Modifier.marquee(
    durationMs: Int = 8000,
    direction: Int = -1,
): Modifier {
    val transition = rememberInfiniteTransition(label = "marquee")
    val offset by transition.animateFloat(
        initialValue = 0f,
        targetValue = direction.toFloat(),
        animationSpec = infiniteRepeatable(tween(durationMs, easing = MotionTokens.EasingLinear)),
        label = "marqueeOffset",
    )
    return this.graphicsLayer { translationX = offset * size.width * 0.3f }
}

/**
 * Typewriter — reveals content from left to right, used for "decrypting" file names
 * inside the Vault.
 */
@Composable
fun Modifier.typewriter(steps: Int = 20, durationMs: Int = 1500): Modifier {
    val transition = rememberInfiniteTransition(label = "typewriter")
    val progress by transition.animateFloat(
        0f,
        1f,
        infiniteRepeatable(tween(durationMs, easing = MotionTokens.EasingStandard), RepeatMode.Restart),
        label = "typewriterProgress",
    )
    return this.graphicsLayer { this.alpha = (progress * steps).coerceIn(0f, 1f) }
}

// ─────────────────────────────────────────────────────────────────
// 4. Entrance animations
// ─────────────────────────────────────────────────────────────────

/**
 * Fade on appear — animates alpha from 0 to 1 when the composable enters composition.
 *
 * @param delayMs delay before the animation starts (for staggered entrances).
 * @param durationMs animation duration.
 */
@Composable
fun Modifier.fadeOnAppear(
    delayMs: Int = 0,
    durationMs: Int = MotionTokens.DurationMedium,
): Modifier {
    val alpha by animateFloatAsState(
        1f,
        tween(durationMs, delayMs, MotionTokens.EasingEmphasizedDecelerate),
        label = "fadeAppear",
    )
    return this.graphicsLayer { this.alpha = alpha }
}

/**
 * Scale on appear — animates scale from `initialScale` → 1.0 when the composable
 * enters composition.
 *
 * @param delayMs delay before the animation starts.
 * @param initialScale starting scale (e.g. 0.8 = grows from 80 % to 100 %).
 * @param durationMs animation duration.
 */
@Composable
fun Modifier.scaleOnAppear(
    delayMs: Int = 0,
    initialScale: Float = 0.8f,
    durationMs: Int = MotionTokens.DurationMedium,
): Modifier {
    val scale by animateFloatAsState(
        1f,
        tween(durationMs, delayMs, MotionTokens.EasingEmphasizedDecelerate),
        label = "scaleAppear",
    )
    return this.graphicsLayer {
        scaleX = (scale - 1f) * (1f - initialScale) + initialScale
        scaleY = (scale - 1f) * (1f - initialScale) + initialScale
    }
}

/**
 * Slide-in-from-bottom on appear — animates a vertical slide + fade-in.
 *
 * @param delayMs delay before the animation starts.
 * @param slideDistance how far the composable slides up (in dp).
 * @param durationMs animation duration.
 */
@Composable
fun Modifier.slideInFromBottomOnAppear(
    delayMs: Int = 0,
    slideDistance: Dp = 32.dp,
    durationMs: Int = MotionTokens.DurationMedium,
): Modifier {
    val progress by animateFloatAsState(
        1f,
        tween(durationMs, delayMs, MotionTokens.EasingEmphasizedDecelerate),
        label = "slideUpProgress",
    )
    return this.graphicsLayer {
        translationY = slideDistance.toPx() * (1f - progress)
        alpha = progress
    }
}

/**
 * Slide-in-from-left on appear — horizontal slide + fade-in.
 */
@Composable
fun Modifier.slideInFromLeftOnAppear(
    delayMs: Int = 0,
    slideDistance: Dp = 32.dp,
    durationMs: Int = MotionTokens.DurationMedium,
): Modifier {
    val progress by animateFloatAsState(
        1f,
        tween(durationMs, delayMs, MotionTokens.EasingEmphasizedDecelerate),
        label = "slideLeftProgress",
    )
    return this.graphicsLayer {
        translationX = -slideDistance.toPx() * (1f - progress)
        alpha = progress
    }
}

/**
 * Slide-in-from-right on appear — horizontal slide + fade-in.
 */
@Composable
fun Modifier.slideInFromRightOnAppear(
    delayMs: Int = 0,
    slideDistance: Dp = 32.dp,
    durationMs: Int = MotionTokens.DurationMedium,
): Modifier {
    val progress by animateFloatAsState(
        1f,
        tween(durationMs, delayMs, MotionTokens.EasingEmphasizedDecelerate),
        label = "slideRightProgress",
    )
    return this.graphicsLayer {
        translationX = slideDistance.toPx() * (1f - progress)
        alpha = progress
    }
}

/**
 * Pop on appear — bouncy scale-in from 0.5 to 1.0.
 *
 * Uses spring physics for a lively, playful entrance — great for success / celebration moments.
 */
@Composable
fun Modifier.popOnAppear(delayMs: Int = 0): Modifier {
    val scale by animateFloatAsState(
        1f,
        androidx.compose.animation.core.spring(
            dampingRatio = androidx.compose.animation.core.Spring.DampingRatioMediumBouncy,
            stiffness = androidx.compose.animation.core.Spring.StiffnessMediumLow,
        ),
        label = "popScale",
    )
    return this.graphicsLayer {
        scaleX = 0.5f + (scale * 0.5f)
        scaleY = 0.5f + (scale * 0.5f)
    }
}

// ─────────────────────────────────────────────────────────────────
// 5. Shape helpers
// ─────────────────────────────────────────────────────────────────

/**
 * Clip to rounded rectangle with custom radius.
 *
 * @param cornerRadius radius applied to all four corners.
 */
fun Modifier.clipToRounded(cornerRadius: Dp): Modifier =
    this.clip(RoundedCornerShape(cornerRadius))

/**
 * Clip with custom per-corner radii.
 *
 * @param topStart radius of the top-start corner.
 * @param topEnd radius of the top-end corner.
 * @param bottomEnd radius of the bottom-end corner.
 * @param bottomStart radius of the bottom-start corner.
 */
fun Modifier.clipToRounded(
    topStart: Dp = 0.dp,
    topEnd: Dp = 0.dp,
    bottomEnd: Dp = 0.dp,
    bottomStart: Dp = 0.dp,
): Modifier = this.clip(RoundedCornerShape(topStart, topEnd, bottomEnd, bottomStart))

/** Clip to top corners only — useful for sheets that merge with the bottom edge. */
fun Modifier.clipToTopCorners(cornerRadius: Dp = 24.dp): Modifier =
    this.clip(RoundedCornerShape(topStart = cornerRadius, topEnd = cornerRadius))

/** Clip to bottom corners only — useful for collapsing toolbars that merge with the app bar. */
fun Modifier.clipToBottomCorners(cornerRadius: Dp = 16.dp): Modifier =
    this.clip(RoundedCornerShape(bottomStart = cornerRadius, bottomEnd = cornerRadius))

/** Clip to a stadium / pill shape (fully rounded ends). */
fun Modifier.clipToStadium(): Modifier = this.clip(RoundedCornerShape(50))

// ─────────────────────────────────────────────────────────────────
// 6. State-driven modifiers
// ─────────────────────────────────────────────────────────────────

/**
 * Hover scale — scales the composable up when [isHovered] is true.
 *
 * Used on desktop and TV variants where a pointer / D-pad can hover over elements.
 *
 * @param isHovered current hover state.
 * @param hoverScale scale factor applied when hovered (e.g. 1.05 = 5 % grow).
 */
@Composable
fun Modifier.hoverScale(isHovered: Boolean, hoverScale: Float = 1.05f): Modifier {
    val scale by animateFloatAsState(
        targetValue = if (isHovered) hoverScale else 1f,
        animationSpec = tween(MotionTokens.DurationFast, easing = MotionTokens.EasingStandard),
        label = "hoverScale",
    )
    return this.scale(scale)
}

/**
 * Selected ring — draws a coloured ring around the composable when [isSelected] is true.
 *
 * @param isSelected current selection state.
 * @param color ring colour.
 * @param width ring thickness.
 * @param shape clip shape.
 */
@Composable
fun Modifier.selectedRing(
    isSelected: Boolean,
    color: Color = ColorTokens.BrandBlue,
    width: Dp = 2.dp,
    shape: Shape = ShapeTokens.Medium,
): Modifier {
    val borderWidth by animateFloatAsState(
        targetValue = if (isSelected) width.value else 0f,
        animationSpec = tween(MotionTokens.DurationFast),
        label = "selectedRingWidth",
    )
    return if (isSelected) {
        this.border(width, color, shape)
    } else {
        this.border(width = (borderWidth).dp, color = Color.Transparent, shape = shape)
    }
}

/**
 * Draggable elevation — raises the composable when [isDragged] is true.
 *
 * Used inside drag-and-drop file operations to make the dragged item visually "lift"
 * off the surface.
 *
 * @param isDragged current drag state.
 * @param elevation elevation when dragged.
 * @param shape clip shape.
 */
@Composable
fun Modifier.draggableElevation(
    isDragged: Boolean,
    elevation: Dp = ElevationTokens.Level5,
    shape: Shape = ShapeTokens.Medium,
): Modifier {
    val targetElevation by animateFloatAsState(
        targetValue = if (isDragged) elevation.value else 0f,
        animationSpec = tween(MotionTokens.DurationMedium, easing = MotionTokens.EasingEmphasized),
        label = "dragElevation",
    )
    return this.graphicsLayer {
        shadowElevation = targetElevation
        clip = true
        this.shape = shape
        scaleX = if (isDragged) 1.05f else 1f
        scaleY = if (isDragged) 1.05f else 1f
    }
}

/**
 * Disabled alpha — fades the composable when [isEnabled] is false.
 *
 * Defaults to the Material 3 disabled-content alpha (0.38).
 *
 * @param isEnabled enabled state.
 * @param disabledAlpha alpha applied when disabled.
 */
@Composable
fun Modifier.disabledAlpha(isEnabled: Boolean, disabledAlpha: Float = AlphaTokens.DisabledContent): Modifier {
    val alpha by animateFloatAsState(
        targetValue = if (isEnabled) 1f else disabledAlpha,
        animationSpec = tween(MotionTokens.DurationFast),
        label = "disabledAlpha",
    )
    return this.graphicsLayer { this.alpha = alpha }
}

/**
 * Loading shimmer overlay — applies a [shimmer] when [isLoading] is true.
 *
 * Convenience wrapper that conditionally applies the [shimmer] modifier based on a
 * loading flag, so consumers don't need to write the `if (isLoading) Modifier.shimmer() else Modifier` pattern.
 *
 * @param isLoading current loading state.
 * @param shape clip shape passed to [shimmer].
 */
@Composable
fun Modifier.loadingShimmer(isLoading: Boolean, shape: Shape = ShapeTokens.ExtraSmall): Modifier =
    if (isLoading) this.shimmer(shape) else this

// ─────────────────────────────────────────────────────────────────
// 7. Visibility-driven animations
// ─────────────────────────────────────────────────────────────────

/**
 * Animate-alpha — smoothly fades between two states.
 *
 * @param targetAlpha target alpha value (0.0 to 1.0).
 * @param durationMs animation duration.
 */
@Composable
fun Modifier.animateAlpha(targetAlpha: Float, durationMs: Int = MotionTokens.DurationMedium): Modifier {
    val alpha by animateFloatAsState(
        targetValue = targetAlpha,
        animationSpec = tween(durationMs, easing = MotionTokens.EasingEmphasized),
        label = "animateAlpha",
    )
    return this.graphicsLayer { this.alpha = alpha }
}

/**
 * Animate-scale — smoothly scales between two states.
 *
 * @param targetScale target scale (1.0 = original size).
 * @param durationMs animation duration.
 */
@Composable
fun Modifier.animateScale(targetScale: Float, durationMs: Int = MotionTokens.DurationMedium): Modifier {
    val scale by animateFloatAsState(
        targetValue = targetScale,
        animationSpec = tween(durationMs, easing = MotionTokens.EasingEmphasized),
        label = "animateScale",
    )
    return this.graphicsLayer {
        scaleX = scale
        scaleY = scale
    }
}

/**
 * Animate-translation — smoothly translates the composable between two positions.
 *
 * @param targetX target X offset in dp.
 * @param targetY target Y offset in dp.
 * @param durationMs animation duration.
 */
@Composable
fun Modifier.animateTranslation(
    targetX: Dp = 0.dp,
    targetY: Dp = 0.dp,
    durationMs: Int = MotionTokens.DurationMedium,
): Modifier {
    val x by animateFloatAsState(
        targetValue = targetX.value,
        animationSpec = tween(durationMs, easing = MotionTokens.EasingEmphasized),
        label = "animateTranslationX",
    )
    val y by animateFloatAsState(
        targetValue = targetY.value,
        animationSpec = tween(durationMs, easing = MotionTokens.EasingEmphasized),
        label = "animateTranslationY",
    )
    return this.graphicsLayer {
        translationX = x
        translationY = y
    }
}

// ─────────────────────────────────────────────────────────────────
// 8. Background patterns
// ─────────────────────────────────────────────────────────────────

/**
 * Striped background — paints the composable with diagonal stripes.
 *
 * Used for "drag here to upload" drop zones and for visualising storage-usage
 * breakdowns.
 *
 * @param stripeColor colour of the stripes.
 * @param backgroundColor background colour.
 * @param stripeWidth stripe width in dp.
 */
fun Modifier.stripedBackground(
    stripeColor: Color = Color.Gray.copy(alpha = 0.3f),
    backgroundColor: Color = Color.Transparent,
    stripeWidth: Dp = 16.dp,
): Modifier = composed {
    val density = androidx.compose.ui.platform.LocalDensity.current
    val widthPx = with(density) { stripeWidth.toPx() }
    this.drawBehind {
        drawRect(backgroundColor)
        val stripeBrush = Brush.linearGradient(
            colors = listOf(stripeColor, backgroundColor, stripeColor),
            start = Offset(0f, 0f),
            end = Offset(widthPx, widthPx),
        )
        drawRect(stripeBrush)
    }
}

/**
 * Grid background — paints a faint grid pattern.
 *
 * Used in the file-preview canvas to indicate "transparent background".
 *
 * @param lineColor grid line colour.
 * @param cellSize grid cell size in dp.
 */
fun Modifier.gridBackground(
    lineColor: Color = Color.Gray.copy(alpha = 0.15f),
    cellSize: Dp = 16.dp,
): Modifier = composed {
    val density = androidx.compose.ui.platform.LocalDensity.current
    val cellPx = with(density) { cellSize.toPx() }
    this.drawBehind {
        var x = 0f
        while (x < size.width) {
            drawLine(
                color = lineColor,
                start = Offset(x, 0f),
                end = Offset(x, size.height),
                strokeWidth = 1f,
            )
            x += cellPx
        }
        var y = 0f
        while (y < size.height) {
            drawLine(
                color = lineColor,
                start = Offset(0f, y),
                end = Offset(size.width, y),
                strokeWidth = 1f,
            )
            y += cellPx
        }
    }
}

/**
 * Noise texture — overlays a faint noise pattern for a "premium" feel.
 *
 * Implemented as a stippled dot pattern (since real noise textures require an image asset).
 *
 * @param dotColor dot colour.
 * @param dotSpacing distance between dots in dp.
 */
fun Modifier.noiseTexture(
    dotColor: Color = Color.Gray.copy(alpha = 0.05f),
    dotSpacing: Dp = 4.dp,
): Modifier = composed {
    val density = androidx.compose.ui.platform.LocalDensity.current
    val spacingPx = with(density) { dotSpacing.toPx() }
    this.drawBehind {
        var x = 0f
        while (x < size.width) {
            var y = 0f
            while (y < size.height) {
                drawCircle(
                    color = dotColor,
                    radius = 0.5f,
                    center = Offset(x, y),
                )
                y += spacingPx
            }
            x += spacingPx
        }
    }
}

// ─────────────────────────────────────────────────────────────────
// 9. Diagonal corner-cut clip
// ─────────────────────────────────────────────────────────────────

/**
 * Clip to a diagonal corner — clips the composable so the top-right corner is cut at a 45° angle.
 *
 * Used for "tag" badges and coupon-style surfaces.
 *
 * @param cutSize size of the diagonal cut in dp.
 */
fun Modifier.clipDiagonalCorner(cutSize: Dp = 16.dp): Modifier = composed {
    val density = androidx.compose.ui.platform.LocalDensity.current
    val cutPx = with(density) { cutSize.toPx() }
    this.clip(
        androidx.compose.foundation.shape.GenericShape { size, _ ->
            moveTo(0f, 0f)
            lineTo(size.width - cutPx, 0f)
            lineTo(size.width, cutPx)
            lineTo(size.width, size.height)
            lineTo(0f, size.height)
            close()
        },
    )
}

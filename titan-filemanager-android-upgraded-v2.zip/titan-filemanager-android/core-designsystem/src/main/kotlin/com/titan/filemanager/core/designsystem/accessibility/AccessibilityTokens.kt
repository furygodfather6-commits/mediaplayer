package com.titan.filemanager.core.designsystem.accessibility

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance

/**
 * # AccessibilityTokens
 *
 * Centralised accessibility constants and helpers for the TitanFileManager design system.
 *
 * ## Why accessibility matters
 * Enterprise file managers are used by everyone, including users with visual impairments,
 * motor difficulties, and cognitive differences. Hard-coding contrast thresholds or touch
 * target sizes in component code leads to drift: somebody makes a "compact" 32 dp button,
 * somebody else uses a 3:1 contrast text on a 12 sp caption, and the app becomes unusable
 * for the people who need it most. This file pins every accessibility constant in one place.
 *
 * ## WCAG 2.1 reference
 * - **Normal text** (under 18 pt, or 14 pt bold): 4.5:1 contrast for AA, 7.0:1 for AAA.
 * - **Large text** (18 pt+, or 14 pt+ bold): 3.0:1 contrast for AA, 4.5:1 for AAA.
 * - **UI components** (icons, borders, focus indicators): 3.0:1 contrast for AA.
 * - **Touch targets**: 44 × 44 dp minimum (we use 48 dp for extra margin).
 */
object AccessibilityTokens {
    // ─────────────────────────────────────────────────────────────
    // Contrast ratios (WCAG 2.1)
    // ─────────────────────────────────────────────────────────────
    /** 4.5 — minimum contrast for normal-size body text (AA conformance). */
    const val MinContrastNormalText = 4.5
    /** 3.0 — minimum contrast for large text (≥18 pt or ≥14 pt bold). */
    const val MinContrastLargeText = 3.0
    /** 3.0 — minimum contrast for UI components (icons, borders, focus rings). */
    const val MinContrastUI = 3.0
    /** 7.0 — minimum contrast for normal-size text at AAA conformance. */
    const val MinContrastAAA = 7.0
    /** 4.5 — minimum contrast for large text at AAA conformance. */
    const val MinContrastLargeAAA = 4.5
    /** 3.0 — minimum contrast for non-text elements at AAA conformance. */
    const val MinContrastNonTextAAA = 3.0

    // ─────────────────────────────────────────────────────────────
    // Touch target sizes (in dp)
    // ─────────────────────────────────────────────────────────────
    /** 48 dp — standard minimum touch target (exceeds WCAG 2.5.5's 44 dp requirement). */
    const val MinTouchTarget = 48
    /** 56 dp — large touch target for primary actions on phones. */
    const val MinTouchTargetLarge = 56
    /** 72 dp — extra-large touch target for accessibility mode (1.5× scale). */
    const val MinTouchTargetXl = 72
    /** 96 dp — for cognitive-accessibility mode (2× scale). */
    const val MinTouchTargetMax = 96
    /** 44 dp — WCAG 2.5.5 absolute floor (we don't go below this even in dense mode). */
    const val MinTouchTargetFloor = 44

    // ─────────────────────────────────────────────────────────────
    // Font size thresholds (in sp)
    // ─────────────────────────────────────────────────────────────
    /** 12 sp — minimum body font size; below this, text becomes unreadable for many users. */
    const val MinBodyFontSize = 12
    /** 11 sp — minimum caption / label font size. */
    const val MinCaptionFontSize = 11
    /** 10 sp — minimum overline font size (rarely used; only for uppercase eyebrows). */
    const val MinOverlineFontSize = 10
    /** 18 sp — threshold above which text qualifies as "large" for contrast purposes. */
    const val LargeTextThreshold = 18
    /** 14 sp — bold text above this size also qualifies as "large" for contrast. */
    const val LargeBoldTextThreshold = 14
    /** 24 sp — recommended max line length (in characters) for readability. */
    const val MaxLineLengthChars = 75
    /** 1.5× — line height multiplier for accessibility mode. */
    const val AccessibleLineHeightMultiplier = 1.5
    /** 2.0× — maximum font scale we explicitly support. */
    const val MaxFontScale = 2.0

    // ─────────────────────────────────────────────────────────────
    // Animation / motion accessibility
    // ─────────────────────────────────────────────────────────────
    /** 0 ms — duration to use when "reduce motion" is enabled. */
    const val ReducedMotionDuration = 0
    /** 1.0 — opacity used in place of slide/scale animations when reduce-motion is on. */
    const val ReducedMotionOpacity = 1.0f
    /** 200 ms — max duration for an animation before it triggers vestibular issues. */
    const val VestibularSafeMaxDuration = 200
    /** 3 Hz — max flash frequency before triggering photosensitive seizure thresholds. */
    const val MaxFlashFrequencyHz = 3

    // ─────────────────────────────────────────────────────────────
    // Focus indicator
    // ─────────────────────────────────────────────────────────────
    /** 2 dp — minimum focus-ring stroke width. */
    const val FocusRingStrokeWidth = 2
    /** 3 dp — focus-ring stroke width for high-contrast mode. */
    const val FocusRingStrokeWidthHighContrast = 3
    /** 4 dp — minimum focus-ring offset from the focused element. */
    const val FocusRingOffset = 2

    // ─────────────────────────────────────────────────────────────
    // Contrast calculation helpers
    // ─────────────────────────────────────────────────────────────
    /**
     * Computes the WCAG contrast ratio between two colours.
     *
     * The formula is `(L1 + 0.05) / (L2 + 0.05)` where `L1` and `L2` are the relative
     * luminances of the lighter and darker colours respectively.
     *
     * @param foreground the foreground colour (text/icon).
     * @param background the background colour.
     * @return contrast ratio in the range 1.0 (no contrast) to 21.0 (max contrast).
     */
    fun contrastRatio(foreground: Color, background: Color): Double {
        val fgLum = foreground.luminance()
        val bgLum = background.luminance()
        val lighter = maxOf(fgLum, bgLum)
        val darker = minOf(fgLum, bgLum)
        return (lighter + 0.05) / (darker + 0.05)
    }

    /** `true` when [foreground] on [background] meets AA contrast for normal text (4.5:1). */
    fun meetsNormalTextAA(foreground: Color, background: Color): Boolean =
        contrastRatio(foreground, background) >= MinContrastNormalText

    /** `true` when [foreground] on [background] meets AA contrast for large text (3.0:1). */
    fun meetsLargeTextAA(foreground: Color, background: Color): Boolean =
        contrastRatio(foreground, background) >= MinContrastLargeText

    /** `true` when [foreground] on [background] meets AAA contrast for normal text (7.0:1). */
    fun meetsNormalTextAAA(foreground: Color, background: Color): Boolean =
        contrastRatio(foreground, background) >= MinContrastAAA

    /** `true` when [foreground] on [background] meets AA contrast for UI components (3.0:1). */
    fun meetsUIComponentAA(foreground: Color, background: Color): Boolean =
        contrastRatio(foreground, background) >= MinContrastUI

    /**
     * Picks the text colour (black or white) with the higher contrast against [background].
     * Use this when you don't control the foreground colour (e.g., user-selected accent).
     */
    fun bestTextColorFor(background: Color): Color =
        if (contrastRatio(Color.White, background) >= contrastRatio(Color.Black, background))
            Color.White else Color.Black

    /**
     * Returns a colour that, when placed on [background], meets [minRatio] contrast.
     *
     * If [color] already meets the ratio, it is returned unchanged.
     * Otherwise we darken it (multiplying RGB by 0.5) and re-check.
     * If darkening still doesn't pass, we fall back to [bestTextColorFor].
     */
    fun ensureContrast(color: Color, background: Color, minRatio: Double = MinContrastNormalText): Color {
        if (contrastRatio(color, background) >= minRatio) return color
        val darkened = color.copy(
            red = (color.red * 0.5f),
            green = (color.green * 0.5f),
            blue = (color.blue * 0.5f),
        )
        if (contrastRatio(darkened, background) >= minRatio) return darkened
        return bestTextColorFor(background)
    }

    /**
     * Returns the touch-target size (in dp) appropriate for the given accessibility mode.
     *
     * @param scale 1.0 = standard, 1.5 = large, 2.0 = extra-large.
     */
    fun touchTargetFor(scale: Float): Int = when {
        scale >= 2.0f -> MinTouchTargetMax
        scale >= 1.5f -> MinTouchTargetXl
        scale >= 1.2f -> MinTouchTargetLarge
        else -> MinTouchTarget
    }

    /**
     * Returns `true` if the given [flashFrequencyHz] is safe for photosensitive users
     * (i.e., does not exceed [MaxFlashFrequencyHz] = 3 Hz).
     */
    fun isFlashSafe(flashFrequencyHz: Float): Boolean = flashFrequencyHz <= MaxFlashFrequencyHz

    /**
     * Returns the appropriate animation duration given the user's "reduce motion" preference.
     * If reduce-motion is enabled, returns 0 ms; otherwise returns [defaultDurationMs].
     */
    fun durationFor(reduceMotion: Boolean, defaultDurationMs: Int): Int =
        if (reduceMotion) ReducedMotionDuration else defaultDurationMs
}

package com.titan.filemanager.core.designsystem.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily
import androidx.core.view.WindowCompat
import com.titan.filemanager.core.designsystem.tokens.AlphaTokens
import com.titan.filemanager.core.designsystem.tokens.ColorTokens
import com.titan.filemanager.core.designsystem.tokens.ShapeTokens
import com.titan.filemanager.core.designsystem.tokens.TypographyTokens

/**
 * ## TitanThemeConfig
 *
 * Configuration bundle for [TitanTheme]. Lets the host app override every aspect of the
 * theme without reaching into individual tokens.
 *
 * @property fontFamily optional substitute [FontFamily] applied to every typography style.
 * @property fontScale linear scale factor for font sizes (1.0 = no change). Useful for
 *                     accessibility mode (1.3, 1.5, 2.0) or branded large-text modes.
 * @property cornerRadiusOverride when non-null, every shape tier is regenerated with this
 *                                base corner radius. Useful for re-skinning the app to a
 *                                "softer" or "sharper" feel without changing every component.
 * @property dynamicColor when `true`, use Material You dynamic colours on Android 12+.
 * @property darkTheme when non-null, override the system dark/light preference. `null` = follow system.
 * @property customLightScheme when non-null, replaces the default [LightColorScheme] for the light theme.
 * @property customDarkScheme when non-null, replaces the default [DarkColorScheme] for the dark theme.
 * @property extendedColors optional override for the [ExtendedColorScheme] — semantic state
 *                          colours, file tints, chart palette, etc.
 * @property useGlassmorphism when `true`, glass-style surfaces are enabled (subject to platform support).
 * @property reducedMotion when `true`, all animations are reduced to instant opacity changes.
 * @property highContrast when `true`, borders and focus rings are thickened for low-vision users.
 * @property amoledMode when `true`, the dark theme uses true-black surfaces to save OLED battery.
 */
data class TitanThemeConfig(
    val fontFamily: FontFamily? = null,
    val fontScale: Float = 1.0f,
    val cornerRadiusOverride: Int? = null,
    val dynamicColor: Boolean = true,
    val darkTheme: Boolean? = null,
    val customLightScheme: ColorScheme? = null,
    val customDarkScheme: ColorScheme? = null,
    val extendedColors: ExtendedColorScheme = ExtendedColorScheme.Default,
    val useGlassmorphism: Boolean = true,
    val reducedMotion: Boolean = false,
    val highContrast: Boolean = false,
    val amoledMode: Boolean = false,
)

/**
 * ## ExtendedColorScheme
 *
 * Holds semantic colours that aren't part of the Material 3 [ColorScheme] but are essential
 * for an enterprise file manager: success / warning / info / danger states, per-file-type
 * tints, chart palettes, shimmer tones, and overlay scrims.
 *
 * The theme provides this via [LocalExtendedColorScheme]; access it through [TitanTheme.extendedColors].
 *
 * @property success semantic success colour (e.g., file sync complete).
 * @property successContainer soft container colour for success banners.
 * @property warning semantic warning colour (e.g., storage 80% full).
 * @property warningContainer soft container colour for warning banners.
 * @property info semantic info colour (e.g., file sharing notification).
 * @property infoContainer soft container colour for info banners.
 * @property danger semantic danger colour (e.g., file corruption alert).
 * @property dangerContainer soft container colour for danger banners.
 * @property fileImage tint for image file icons.
 * @property fileVideo tint for video file icons.
 * @property fileAudio tint for audio file icons.
 * @property fileDocument tint for document file icons.
 * @property fileArchive tint for archive file icons.
 * @property fileCode tint for source-code file icons.
 * @property fileApk tint for Android package file icons.
 * @property fileText tint for plain-text file icons.
 * @property fileFolder tint for folder icons.
 * @property fileGeneric fallback tint for unrecognised file types.
 * @property chartColors ordered palette for storage / analytics charts.
 * @property shimmerBase base colour for shimmer skeleton placeholders.
 * @property shimmerHighlight highlight colour for shimmer skeleton placeholders.
 * @property overlay scrim colour used by modal overlays.
 */
data class ExtendedColorScheme(
    val success: Color,
    val successContainer: Color,
    val warning: Color,
    val warningContainer: Color,
    val info: Color,
    val infoContainer: Color,
    val danger: Color,
    val dangerContainer: Color,
    val fileImage: Color,
    val fileVideo: Color,
    val fileAudio: Color,
    val fileDocument: Color,
    val fileArchive: Color,
    val fileCode: Color,
    val fileApk: Color,
    val fileText: Color,
    val fileFolder: Color,
    val fileGeneric: Color,
    val chartColors: List<Color>,
    val shimmerBase: Color,
    val shimmerHighlight: Color,
    val overlay: Color,
) {
    companion object {
        /** Default light-theme extended colour scheme — paired with [LightColorScheme]. */
        val Default = ExtendedColorScheme(
            success = ColorTokens.Success,
            successContainer = ColorTokens.SuccessContainer,
            warning = ColorTokens.Warning,
            warningContainer = ColorTokens.WarningContainer,
            info = ColorTokens.Info,
            infoContainer = ColorTokens.InfoContainer,
            danger = ColorTokens.Danger,
            dangerContainer = ColorTokens.DangerContainer,
            fileImage = ColorTokens.FileImage,
            fileVideo = ColorTokens.FileVideo,
            fileAudio = ColorTokens.FileAudio,
            fileDocument = ColorTokens.FileDocument,
            fileArchive = ColorTokens.FileArchive,
            fileCode = ColorTokens.FileCode,
            fileApk = ColorTokens.FileApk,
            fileText = ColorTokens.FileText,
            fileFolder = ColorTokens.FileFolder,
            fileGeneric = ColorTokens.FileGeneric,
            chartColors = ColorTokens.ChartColors,
            shimmerBase = ColorTokens.ShimmerLight,
            shimmerHighlight = ColorTokens.ShimmerHighlight,
            overlay = ColorTokens.OverlayLight,
        )

        /** Default dark-theme extended colour scheme — paired with [DarkColorScheme]. */
        val Dark = Default.copy(
            success = ColorTokens.SuccessDark,
            successContainer = ColorTokens.SuccessContainerDark,
            warning = ColorTokens.WarningDark,
            warningContainer = ColorTokens.WarningContainerDark,
            info = ColorTokens.InfoDark,
            infoContainer = ColorTokens.InfoContainerDark,
            danger = ColorTokens.DangerDark,
            dangerContainer = ColorTokens.DangerContainerDark,
            shimmerBase = ColorTokens.ShimmerDark,
            shimmerHighlight = ColorTokens.ShimmerHighlightDark,
            overlay = ColorTokens.OverlayDark,
        )

        /** AMOLED variant of [Dark] — uses true-black surfaces for OLED battery savings. */
        val Amoled = Dark.copy(
            shimmerBase = Color(0xFF000000),
            overlay = Color(0xE6000000),
        )
    }
}

/** CompositionLocal that exposes the active [ExtendedColorScheme]. */
val LocalExtendedColorScheme = compositionLocalOf { ExtendedColorScheme.Default }

/** CompositionLocal that exposes the active [TitanThemeConfig]. */
val LocalTitanThemeConfig = staticCompositionLocalOf { TitanThemeConfig() }

/**
 * ## TitanTheme
 *
 * The root theme composable. Wrap your app's root content in [TitanTheme] to provide
 * Material 3 colour, typography, and shape schemes plus the Titan-specific
 * [ExtendedColorScheme] and [TitanThemeConfig] via CompositionLocals.
 *
 * ### Usage
 * ```
 * TitanTheme(config = TitanThemeConfig(dynamicColor = true)) {
 *     // your app content
 * }
 * ```
 *
 * ### Decision tree
 * 1. If `config.dynamicColor && SDK >= S` → use Material You dynamic colour.
 * 2. Else if `config.darkTheme` (or system dark) is on → use [DarkColorScheme] (or [DarkAmoledColorScheme] for amoled).
 * 3. Else → use [LightColorScheme].
 * 4. If `config.customLightScheme` / `config.customDarkScheme` is set, it overrides (2) and (3).
 * 5. Typography and shapes are derived from `config.fontFamily`, `config.fontScale`, and
 *    `config.cornerRadiusOverride`.
 *
 * @param config the theme configuration.
 * @param content the composable content to render with the theme applied.
 */
@Composable
fun TitanTheme(
    config: TitanThemeConfig = TitanThemeConfig(),
    content: @Composable () -> Unit,
) {
    val systemDark = isSystemInDarkTheme()
    val isDark = config.darkTheme ?: systemDark
    val context = LocalContext.current

    val colorScheme: ColorScheme = when {
        config.dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (isDark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        isDark -> when {
            config.amoledMode -> DarkAmoledColorScheme
            config.customDarkScheme != null -> config.customDarkScheme
            else -> DarkColorScheme
        }
        else -> config.customLightScheme ?: LightColorScheme
    }

    val baseExtended = when {
        isDark && config.amoledMode -> ExtendedColorScheme.Amoled
        isDark -> ExtendedColorScheme.Dark
        else -> ExtendedColorScheme.Default
    }
    // Allow callers to override individual extended colours without rebuilding the whole scheme.
    val mergedExtended = if (config.extendedColors !== ExtendedColorScheme.Default) {
        config.extendedColors
    } else {
        baseExtended
    }

    val typography: Typography = when {
        config.fontFamily != null || config.fontScale != 1.0f ->
            TypographyTokens.customTypography(config.fontFamily ?: TypographyTokens.Default, config.fontScale)
        else -> TypographyTokens.MaterialTypography
    }

    val shapes = when (config.cornerRadiusOverride) {
        null -> ShapeTokens.MaterialShapes
        else -> ShapeTokens.customShapes(config.cornerRadiusOverride)
    }

    // Sync the system status bar appearance with the current theme.
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = !isDark
            controller.isAppearanceLightNavigationBars = !isDark
        }
    }

    CompositionLocalProvider(
        LocalExtendedColorScheme provides mergedExtended,
        LocalTitanThemeConfig provides config,
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = typography,
            shapes = shapes,
            content = content,
        )
    }
}

/**
 * ## TitanTheme (object)
 *
 * Static accessor for the current theme values. Read these from any composable:
 * ```
 * val extended = TitanTheme.extendedColors
 * val config = TitanTheme.config
 * ```
 */
object TitanTheme {
    /** The currently active [ExtendedColorScheme]. */
    val extendedColors: ExtendedColorScheme
        @Composable get() = LocalExtendedColorScheme.current

    /** The currently active [TitanThemeConfig]. */
    val config: TitanThemeConfig
        @Composable get() = LocalTitanThemeConfig.current

    /** Convenience: the currently active [ColorScheme]. */
    val colorScheme: ColorScheme
        @Composable get() = MaterialTheme.colorScheme

    /** Convenience: the currently active [Typography]. */
    val typography: Typography
        @Composable get() = MaterialTheme.typography

    /** Convenience: the currently active [androidx.compose.material3.Shapes]. */
    val shapes: androidx.compose.material3.Shapes
        @Composable get() = MaterialTheme.shapes

    /** `true` if the current theme is in dark mode. */
    val isDark: Boolean
        @Composable get() = colorScheme.surface.luminance() < 0.5f

    /** `true` if glassmorphism effects are enabled (subject to platform support). */
    val useGlassmorphism: Boolean
        @Composable get() = config.useGlassmorphism

    /** `true` if reduced motion is preferred. */
    val reducedMotion: Boolean
        @Composable get() = config.reducedMotion

    /** `true` if high-contrast mode is enabled. */
    val highContrast: Boolean
        @Composable get() = config.highContrast
}

/** Compute the relative luminance of a colour — used by [TitanTheme.isDark]. */
private fun Color.luminance(): Float = 0.2126f * red + 0.7152f * green + 0.0722f * blue

/**
 * Default light colour scheme — sourced entirely from [ColorTokens].
 * Override with [TitanThemeConfig.customLightScheme].
 */
val LightColorScheme = lightColorScheme(
    primary = ColorTokens.LightPrimary,
    onPrimary = ColorTokens.LightOnPrimary,
    primaryContainer = ColorTokens.LightPrimaryContainer,
    onPrimaryContainer = ColorTokens.LightOnPrimaryContainer,
    secondary = ColorTokens.LightSecondary,
    onSecondary = ColorTokens.LightOnSecondary,
    secondaryContainer = ColorTokens.LightSecondaryContainer,
    onSecondaryContainer = ColorTokens.LightOnSecondaryContainer,
    tertiary = ColorTokens.LightTertiary,
    onTertiary = ColorTokens.LightOnTertiary,
    tertiaryContainer = ColorTokens.LightTertiaryContainer,
    onTertiaryContainer = ColorTokens.LightOnTertiaryContainer,
    error = ColorTokens.LightError,
    onError = ColorTokens.LightOnError,
    errorContainer = ColorTokens.LightErrorContainer,
    onErrorContainer = ColorTokens.LightOnErrorContainer,
    background = ColorTokens.LightBackground,
    onBackground = ColorTokens.LightOnBackground,
    surface = ColorTokens.LightSurface,
    onSurface = ColorTokens.LightOnSurface,
    surfaceVariant = ColorTokens.LightSurfaceVariant,
    onSurfaceVariant = ColorTokens.LightOnSurfaceVariant,
    surfaceTint = ColorTokens.LightSurfaceTint,
    inverseSurface = ColorTokens.LightInverseSurface,
    inverseOnSurface = ColorTokens.LightInverseOnSurface,
    inversePrimary = ColorTokens.BrandIndigo,
    outline = ColorTokens.LightOutline,
    outlineVariant = ColorTokens.LightOutlineVariant,
    scrim = ColorTokens.LightScrim,
)

/**
 * Default dark colour scheme — sourced entirely from [ColorTokens].
 * Override with [TitanThemeConfig.customDarkScheme].
 */
val DarkColorScheme = darkColorScheme(
    primary = ColorTokens.DarkPrimary,
    onPrimary = ColorTokens.DarkOnPrimary,
    primaryContainer = ColorTokens.DarkPrimaryContainer,
    onPrimaryContainer = ColorTokens.DarkOnPrimaryContainer,
    secondary = ColorTokens.DarkSecondary,
    onSecondary = ColorTokens.DarkOnSecondary,
    secondaryContainer = ColorTokens.DarkSecondaryContainer,
    onSecondaryContainer = ColorTokens.DarkOnSecondaryContainer,
    tertiary = ColorTokens.DarkTertiary,
    onTertiary = ColorTokens.DarkOnTertiary,
    tertiaryContainer = ColorTokens.DarkTertiaryContainer,
    onTertiaryContainer = ColorTokens.DarkOnTertiaryContainer,
    error = ColorTokens.DarkError,
    onError = ColorTokens.DarkOnError,
    errorContainer = ColorTokens.DarkErrorContainer,
    onErrorContainer = ColorTokens.DarkOnErrorContainer,
    background = ColorTokens.DarkBackground,
    onBackground = ColorTokens.DarkOnBackground,
    surface = ColorTokens.DarkSurface,
    onSurface = ColorTokens.DarkOnSurface,
    surfaceVariant = ColorTokens.DarkSurfaceVariant,
    onSurfaceVariant = ColorTokens.DarkOnSurfaceVariant,
    surfaceTint = ColorTokens.DarkSurfaceTint,
    inverseSurface = ColorTokens.DarkInverseSurface,
    inverseOnSurface = ColorTokens.DarkInverseOnSurface,
    inversePrimary = ColorTokens.BrandBlueDark,
    outline = ColorTokens.DarkOutline,
    outlineVariant = ColorTokens.DarkOutlineVariant,
    scrim = ColorTokens.DarkScrim,
)

/**
 * AMOLED dark colour scheme — true-black surfaces for OLED battery savings.
 * Identical to [DarkColorScheme] except `background`, `surface`, and `surfaceVariant`
 * are pushed to pure black.
 */
val DarkAmoledColorScheme = DarkColorScheme.copy(
    background = Color(0xFF000000),
    surface = Color(0xFF000000),
    surfaceVariant = Color(0xFF1A1A1A),
)

/**
 * Helper: builds an [ExtendedColorScheme] from a [ColorScheme] by deriving
 * shimmer, overlay, and chart values automatically. Used by theme presets.
 */
fun extendedFromColorScheme(
    scheme: ColorScheme,
    isDark: Boolean,
): ExtendedColorScheme = if (isDark) ExtendedColorScheme.Dark else ExtendedColorScheme.Default

/**
 * Returns the appropriate overlay alpha for the current theme — used by modal overlays
 * that need to dim the background.
 */
fun overlayAlphaFor(isDark: Boolean): Float =
    if (isDark) AlphaTokens.ScrimHeavy else AlphaTokens.ScrimMedium

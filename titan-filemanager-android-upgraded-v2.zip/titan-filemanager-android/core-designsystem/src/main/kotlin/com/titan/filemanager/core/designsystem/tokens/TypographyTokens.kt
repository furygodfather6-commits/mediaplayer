package com.titan.filemanager.core.designsystem.tokens

import androidx.compose.material3.Typography
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.unit.sp

/**
 * # TypographyTokens
 *
 * Centralised typography scale for the TitanFileManager design system.
 *
 * ## Why typography matters
 * Type is the primary information carrier in any file manager. File names, sizes, dates,
 * and breadcrumb paths all need to scan quickly. Material 3's 15-style scale (display,
 * headline, title, body, label × S/M/L) covers most needs; we extend it with:
 * - **Mono styles** for file paths, code previews, and hex/byte counts.
 * - **Display-style numerics** for storage dashboards (huge "128 GB" hero numbers).
 * - **Caption / overline variants** for compact metadata.
 * - **Custom-font support** via [customTypography], which scales every style by a
 *   configurable factor — essential for accessibility (font scale 1.3×, 1.5×, 2.0×).
 *
 * ## Line-height & letter-spacing
 * Each style carries tuned `lineHeight` and `letterSpacing` values, mirroring the Material 3
 * spec. Line-height is ~1.15× the font size for display/headline (tight) and ~1.4× for body
 * (looser for readability). Letter-spacing is slightly negative on large display text and
 * slightly positive on small label text.
 */
object TypographyTokens {
    /** Default sans-serif font family — falls back to the system font. */
    val Default = FontFamily.Default
    /** Monospace family — used for file paths, code previews, hex / byte counts. */
    val Monospace = FontFamily.Monospace
    /** Serif family — used for marketing / onboarding hero text. */
    val Serif = FontFamily.Serif

    // ─────────────────────────────────────────────────────────────
    // Display styles — hero numbers and onboarding headlines
    // ─────────────────────────────────────────────────────────────
    val DisplayLarge = TextStyle(
        fontFamily = Default, fontWeight = FontWeight.Normal, fontSize = 57.sp,
        lineHeight = 64.sp, letterSpacing = (-0.25).sp,
    )
    val DisplayMedium = TextStyle(
        fontFamily = Default, fontWeight = FontWeight.Normal, fontSize = 45.sp,
        lineHeight = 52.sp, letterSpacing = (-0.15).sp,
    )
    val DisplaySmall = TextStyle(
        fontFamily = Default, fontWeight = FontWeight.Normal, fontSize = 36.sp,
        lineHeight = 44.sp,
    )
    /** Numeric-only display style for storage dashboards — bold and tabular. */
    val DisplayNumberLarge = TextStyle(
        fontFamily = Default, fontWeight = FontWeight.Bold, fontSize = 64.sp,
        lineHeight = 72.sp, letterSpacing = (-0.5).sp,
    )
    val DisplayNumberMedium = TextStyle(
        fontFamily = Default, fontWeight = FontWeight.Bold, fontSize = 48.sp,
        lineHeight = 56.sp, letterSpacing = (-0.25).sp,
    )

    // ─────────────────────────────────────────────────────────────
    // Headline styles — section headers, dialog titles
    // ─────────────────────────────────────────────────────────────
    val HeadlineLarge = TextStyle(
        fontFamily = Default, fontWeight = FontWeight.SemiBold, fontSize = 32.sp,
        lineHeight = 40.sp,
    )
    val HeadlineMedium = TextStyle(
        fontFamily = Default, fontWeight = FontWeight.SemiBold, fontSize = 28.sp,
        lineHeight = 36.sp,
    )
    val HeadlineSmall = TextStyle(
        fontFamily = Default, fontWeight = FontWeight.SemiBold, fontSize = 24.sp,
        lineHeight = 32.sp,
    )
    /** Headline variant with extra letter-spacing for uppercase eyebrows. */
    val HeadlineEyebrow = TextStyle(
        fontFamily = Default, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
        lineHeight = 20.sp, letterSpacing = 1.5.sp,
    )

    // ─────────────────────────────────────────────────────────────
    // Title styles — card titles, list headers
    // ─────────────────────────────────────────────────────────────
    val TitleLarge = TextStyle(
        fontFamily = Default, fontWeight = FontWeight.SemiBold, fontSize = 22.sp,
        lineHeight = 28.sp,
    )
    val TitleMedium = TextStyle(
        fontFamily = Default, fontWeight = FontWeight.Medium, fontSize = 16.sp,
        lineHeight = 24.sp, letterSpacing = 0.15.sp,
    )
    val TitleSmall = TextStyle(
        fontFamily = Default, fontWeight = FontWeight.Medium, fontSize = 14.sp,
        lineHeight = 20.sp, letterSpacing = 0.1.sp,
    )

    // ─────────────────────────────────────────────────────────────
    // Body styles — primary reading text
    // ─────────────────────────────────────────────────────────────
    val BodyLarge = TextStyle(
        fontFamily = Default, fontWeight = FontWeight.Normal, fontSize = 16.sp,
        lineHeight = 24.sp, letterSpacing = 0.5.sp,
    )
    val BodyMedium = TextStyle(
        fontFamily = Default, fontWeight = FontWeight.Normal, fontSize = 14.sp,
        lineHeight = 20.sp, letterSpacing = 0.25.sp,
    )
    val BodySmall = TextStyle(
        fontFamily = Default, fontWeight = FontWeight.Normal, fontSize = 12.sp,
        lineHeight = 16.sp, letterSpacing = 0.4.sp,
    )
    /** Body variant with bold weight — used for emphasised metadata. */
    val BodyLargeBold = TextStyle(
        fontFamily = Default, fontWeight = FontWeight.SemiBold, fontSize = 16.sp,
        lineHeight = 24.sp, letterSpacing = 0.5.sp,
    )
    val BodyMediumEmphasis = TextStyle(
        fontFamily = Default, fontWeight = FontWeight.Medium, fontSize = 14.sp,
        lineHeight = 20.sp, letterSpacing = 0.25.sp,
    )

    // ─────────────────────────────────────────────────────────────
    // Label styles — buttons, chips, badges
    // ─────────────────────────────────────────────────────────────
    val LabelLarge = TextStyle(
        fontFamily = Default, fontWeight = FontWeight.Medium, fontSize = 14.sp,
        lineHeight = 20.sp, letterSpacing = 0.1.sp,
    )
    val LabelMedium = TextStyle(
        fontFamily = Default, fontWeight = FontWeight.Medium, fontSize = 12.sp,
        lineHeight = 16.sp, letterSpacing = 0.5.sp,
    )
    val LabelSmall = TextStyle(
        fontFamily = Default, fontWeight = FontWeight.Medium, fontSize = 11.sp,
        lineHeight = 16.sp, letterSpacing = 0.5.sp,
    )
    /** Uppercase label — used for status pills and section eyebrows. */
    val LabelUppercase = TextStyle(
        fontFamily = Default, fontWeight = FontWeight.SemiBold, fontSize = 11.sp,
        lineHeight = 16.sp, letterSpacing = 1.2.sp,
    )

    // ─────────────────────────────────────────────────────────────
    // Caption / overline variants
    // ─────────────────────────────────────────────────────────────
    val Caption = TextStyle(
        fontFamily = Default, fontWeight = FontWeight.Normal, fontSize = 12.sp,
        lineHeight = 16.sp, letterSpacing = 0.4.sp,
    )
    val Overline = TextStyle(
        fontFamily = Default, fontWeight = FontWeight.Medium, fontSize = 10.sp,
        lineHeight = 14.sp, letterSpacing = 1.5.sp,
    )
    val CaptionEmphasis = TextStyle(
        fontFamily = Default, fontWeight = FontWeight.Medium, fontSize = 12.sp,
        lineHeight = 16.sp, letterSpacing = 0.4.sp,
    )

    // ─────────────────────────────────────────────────────────────
    // Monospace styles — file paths, code previews, hex
    // ─────────────────────────────────────────────────────────────
    val MonoLarge = TextStyle(
        fontFamily = Monospace, fontWeight = FontWeight.Normal, fontSize = 16.sp,
        lineHeight = 24.sp,
    )
    val MonoMedium = TextStyle(
        fontFamily = Monospace, fontWeight = FontWeight.Normal, fontSize = 14.sp,
        lineHeight = 20.sp,
    )
    val MonoSmall = TextStyle(
        fontFamily = Monospace, fontWeight = FontWeight.Normal, fontSize = 12.sp,
        lineHeight = 16.sp,
    )
    val MonoTiny = TextStyle(
        fontFamily = Monospace, fontWeight = FontWeight.Normal, fontSize = 10.sp,
        lineHeight = 14.sp,
    )
    val MonoCodeBlock = TextStyle(
        fontFamily = Monospace, fontWeight = FontWeight.Normal, fontSize = 13.sp,
        lineHeight = 20.sp, letterSpacing = 0.1.sp,
    )

    // ─────────────────────────────────────────────────────────────
    // Material 3 Typography mapping
    // ─────────────────────────────────────────────────────────────
    /** Default [Typography] instance passed to [androidx.compose.material3.MaterialTheme]. */
    val MaterialTypography = Typography(
        displayLarge = DisplayLarge, displayMedium = DisplayMedium, displaySmall = DisplaySmall,
        headlineLarge = HeadlineLarge, headlineMedium = HeadlineMedium, headlineSmall = HeadlineSmall,
        titleLarge = TitleLarge, titleMedium = TitleMedium, titleSmall = TitleSmall,
        bodyLarge = BodyLarge, bodyMedium = BodyMedium, bodySmall = BodySmall,
        labelLarge = LabelLarge, labelMedium = LabelMedium, labelSmall = LabelSmall,
    )

    /**
     * Builds a custom [Typography] from a substitute [fontFamily] and optional [fontScale].
     *
     * @param fontFamily font family to use for every style (pass [Default] to keep the system font).
     * @param fontScale linear scale factor applied to every font size (1.0 = no change).
     *                  Useful for accessibility: 1.3, 1.5, 2.0 are common accessibility scale factors.
     */
    fun customTypography(fontFamily: FontFamily, fontScale: Float = 1.0f): Typography {
        fun s(style: TextStyle) = style.copy(
            fontFamily = fontFamily,
            fontSize = (style.fontSize.value * fontScale).sp,
            lineHeight = (style.lineHeight.value * fontScale).sp,
        )
        return Typography(
            displayLarge = s(DisplayLarge), displayMedium = s(DisplayMedium), displaySmall = s(DisplaySmall),
            headlineLarge = s(HeadlineLarge), headlineMedium = s(HeadlineMedium), headlineSmall = s(HeadlineSmall),
            titleLarge = s(TitleLarge), titleMedium = s(TitleMedium), titleSmall = s(TitleSmall),
            bodyLarge = s(BodyLarge), bodyMedium = s(BodyMedium), bodySmall = s(BodySmall),
            labelLarge = s(LabelLarge), labelMedium = s(LabelMedium), labelSmall = s(LabelSmall),
        )
    }

    /**
     * Builds a [Typography] that uses the monospace family for body styles.
     * Useful for developer / hex editor screens.
     */
    fun monoTypography(fontScale: Float = 1.0f): Typography {
        fun s(style: TextStyle) = style.copy(
            fontFamily = Monospace,
            fontSize = (style.fontSize.value * fontScale).sp,
            lineHeight = (style.lineHeight.value * fontScale).sp,
        )
        return Typography(
            displayLarge = s(DisplayLarge), displayMedium = s(DisplayMedium), displaySmall = s(DisplaySmall),
            headlineLarge = s(HeadlineLarge), headlineMedium = s(HeadlineMedium), headlineSmall = s(HeadlineSmall),
            titleLarge = s(TitleLarge), titleMedium = s(TitleMedium), titleSmall = s(TitleSmall),
            bodyLarge = s(BodyLarge), bodyMedium = s(BodyMedium), bodySmall = s(BodySmall),
            labelLarge = s(LabelLarge), labelMedium = s(LabelMedium), labelSmall = s(LabelSmall),
        )
    }

    /**
     * Returns a [TextStyle] for a given named role.
     * Used by the settings screen to preview typography choices.
     */
    fun byName(name: String): TextStyle = when (name.lowercase()) {
        "displaylarge" -> DisplayLarge
        "displaymedium" -> DisplayMedium
        "displaysmall" -> DisplaySmall
        "headlinelarge" -> HeadlineLarge
        "headlinemedium" -> HeadlineMedium
        "headlinesmall" -> HeadlineSmall
        "titlelarge" -> TitleLarge
        "titlemedium" -> TitleMedium
        "titlesmall" -> TitleSmall
        "bodylarge" -> BodyLarge
        "bodymedium" -> BodyMedium
        "bodysmall" -> BodySmall
        "labellarge" -> LabelLarge
        "labelmedium" -> LabelMedium
        "labelsmall" -> LabelSmall
        "monolarge" -> MonoLarge
        "monomedium" -> MonoMedium
        "monosmall" -> MonoSmall
        "caption" -> Caption
        "overline" -> Overline
        else -> BodyMedium
    }

    /**
     * Returns a [PlatformTextStyle] that suppresses the legacy Android ascent/descent padding.
     * Eliminates the "phantom padding" that appears around text on API 28 and below.
     */
    fun platformStyle(): PlatformTextStyle = PlatformTextStyle(
        includeFontPadding = false,
    )

    /** Returns a list of (name, style) pairs for the typography preview screen. */
    val allStyles: List<Pair<String, TextStyle>>
        get() = listOf(
            "Display Large" to DisplayLarge,
            "Display Medium" to DisplayMedium,
            "Display Small" to DisplaySmall,
            "Headline Large" to HeadlineLarge,
            "Headline Medium" to HeadlineMedium,
            "Headline Small" to HeadlineSmall,
            "Title Large" to TitleLarge,
            "Title Medium" to TitleMedium,
            "Title Small" to TitleSmall,
            "Body Large" to BodyLarge,
            "Body Medium" to BodyMedium,
            "Body Small" to BodySmall,
            "Label Large" to LabelLarge,
            "Label Medium" to LabelMedium,
            "Label Small" to LabelSmall,
            "Mono Large" to MonoLarge,
            "Mono Medium" to MonoMedium,
            "Mono Small" to MonoSmall,
            "Caption" to Caption,
            "Overline" to Overline,
        )
}

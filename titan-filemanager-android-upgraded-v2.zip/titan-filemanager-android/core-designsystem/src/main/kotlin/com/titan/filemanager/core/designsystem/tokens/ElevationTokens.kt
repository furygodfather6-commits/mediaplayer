package com.titan.filemanager.core.designsystem.tokens

import androidx.compose.ui.unit.dp

/**
 * # ElevationTokens
 *
 * Centralised elevation scale for the TitanFileManager design system.
 *
 * ## Why elevation matters
 * Elevation creates visual hierarchy by simulating light cast onto stacked surfaces.
 * Material 3 defines five discrete elevation levels (0 → 5 dp); each level also implies
 * a tonal overlay — a subtle background tint that reinforces the depth cue in addition
 * to the drop shadow.
 *
 * ## Two-axis model
 * 1. **Drop shadow** (the `elevation` parameter on `Surface`) — a real shadow rendered by the system.
 * 2. **Tonal overlay** — a percentage of `surfaceTint` blended into the surface colour, calculated
 *    from the [TonalOverlayLevelX] constants below.
 *
 * Both must be applied together for elevation to "read" correctly. Material 3 `Surface` handles
 * this automatically when you pass the `tonalElevation` parameter.
 */
object ElevationTokens {
    // ─────────────────────────────────────────────────────────────
    // Discrete elevation levels (drop shadow)
    // ─────────────────────────────────────────────────────────────
    /** Level 0 — flat surface, no shadow. Used for background and base content. */
    val Level0 = 0.dp
    /** Level 1 — barely-there shadow for cards and list items. */
    val Level1 = 1.dp
    /** Level 2 — app bars, raised buttons. */
    val Level2 = 3.dp
    /** Level 3 — dialogs, FABs, bottom navigation. */
    val Level3 = 6.dp
    /** Level 4 — bottom sheets, modal dialogs. */
    val Level4 = 8.dp
    /** Level 5 — navigation drawers, deepest modals. */
    val Level5 = 12.dp
    /** Level 6 — non-standard "above everything" surface, used by floating action menus. */
    val Level6 = 16.dp
    /** Level 7 — extreme elevation reserved for system-level overlays (rarely used). */
    val Level7 = 24.dp

    // ─────────────────────────────────────────────────────────────
    // Tonal overlay percentages (0.0 — 1.0)
    // ─────────────────────────────────────────────────────────────
    /** 5% surfaceTint blend for Level 1. */
    val TonalOverlayLevel1 = 0.05f
    /** 8% surfaceTint blend for Level 2. */
    val TonalOverlayLevel2 = 0.08f
    /** 11% surfaceTint blend for Level 3. */
    val TonalOverlayLevel3 = 0.11f
    /** 12% surfaceTint blend for Level 4. */
    val TonalOverlayLevel4 = 0.12f
    /** 14% surfaceTint blend for Level 5. */
    val TonalOverlayLevel5 = 0.14f
    /** 16% surfaceTint blend for Level 6 — slightly stronger for high-modals. */
    val TonalOverlayLevel6 = 0.16f
    /** 18% surfaceTint blend for Level 7. */
    val TonalOverlayLevel7 = 0.18f

    // ─────────────────────────────────────────────────────────────
    // Semantic aliases — use these in component code
    // ─────────────────────────────────────────────────────────────
    /** Default elevation for cards. */
    val Card = Level1
    /** Slightly higher elevation when a card is hovered (desktop) or focused (TV). */
    val CardHover = Level2
    /** Default elevation for top app bars. */
    val AppBar = Level2
    /** Default elevation for bottom navigation bars. */
    val BottomNav = Level3
    /** Default elevation for modal dialogs. */
    val Dialog = Level3
    /** Default elevation for bottom sheets. */
    val BottomSheet = Level4
    /** Default elevation for navigation drawers. */
    val NavDrawer = Level5
    /** Default elevation for the FAB. */
    val FAB = Level3
    /** Default elevation for context menus. */
    val Menu = Level2
    /** Default elevation for the search bar. */
    val SearchBar = Level3
    /** Default elevation for snackbars. */
    val Snackbar = Level3
    /** Default elevation for tooltip bubbles. */
    val Tooltip = Level2
    /** Default elevation for the extended FAB. */
    val ExtendedFAB = Level3
    /** Default elevation for floating action menus (the highest non-modal elevation). */
    val FloatingMenu = Level6

    // ─────────────────────────────────────────────────────────────
    // Stateful elevation helpers
    // ─────────────────────────────────────────────────────────────
    /** Returns the elevation a card should use given its current state. */
    fun cardElevation(
        isHovered: Boolean = false,
        isPressed: Boolean = false,
        isSelected: Boolean = false,
    ): androidx.compose.ui.unit.Dp = when {
        isPressed -> Level0  // pressed cards flatten to give tactile feedback
        isHovered || isSelected -> CardHover
        else -> Card
    }

    /** Returns the tonal overlay fraction for a given elevation level index (0–7). */
    fun tonalOverlayFor(level: Int): Float = when (level) {
        0 -> 0f
        1 -> TonalOverlayLevel1
        2 -> TonalOverlayLevel2
        3 -> TonalOverlayLevel3
        4 -> TonalOverlayLevel4
        5 -> TonalOverlayLevel5
        6 -> TonalOverlayLevel6
        else -> TonalOverlayLevel7
    }

    /** Returns the elevation [androidx.compose.ui.unit.Dp] for a given level index (0–7). */
    fun elevationFor(level: Int): androidx.compose.ui.unit.Dp = when (level) {
        0 -> Level0; 1 -> Level1; 2 -> Level2; 3 -> Level3
        4 -> Level4; 5 -> Level5; 6 -> Level6; else -> Level7
    }
}

package com.titan.filemanager.data.threading.scheduler

import android.util.Log
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import java.util.concurrent.ConcurrentHashMap

/**
 * Structured Concurrency Manager.
 *
 * Ported technique: #35 Structured concurrency
 *
 * Hierarchy:
 * ```
 * AppScope
 *   └── ScanScope (per navigation)
 *         ├── MetadataScope
 *         ├── ThumbnailScope
 *         └── PrefetchScope
 * ```
 *
 * When parent is cancelled → all children cancel.
 * No orphan coroutines, no memory leaks.
 */
class StructuredConcurrencyManager {

    // Root application scope
    private val appScope = CoroutineScope(
        SupervisorJob() +
            Dispatchers.Default +
            CoroutineName("AppScope") +
            CoroutineExceptionHandler { context, throwable ->
                val name = context[CoroutineName]?.name ?: "Unknown"
                Log.e("Concurrency", "Unhandled exception in $name", throwable)
            },
    )

    // Active navigation scopes: path → scope
    private val navigationScopes = ConcurrentHashMap<String, CoroutineScope>()

    // Child scopes per navigation
    private val childScopes = ConcurrentHashMap<String, NavigationScopes>()

    /**
     * Create new scope when user navigates to path. Cancels old scope for the
     * same path automatically.
     */
    fun createNavigationScope(path: String): NavigationScopes {
        // Cancel existing scope for this path
        cancelNavigationScope(path)

        // Create new scope under app scope
        val navJob = SupervisorJob(appScope.coroutineContext[Job])
        val navScope = CoroutineScope(
            navJob +
                Dispatchers.Default +
                CoroutineName("Nav:$path"),
        )

        // Create child scopes
        val scopes = NavigationScopes(
            navigation = navScope,
            scan = createChildScope(navScope, "Scan:$path"),
            metadata = createChildScope(navScope, "Metadata:$path"),
            thumbnail = createChildScope(navScope, "Thumbnail:$path"),
            prefetch = createChildScope(navScope, "Prefetch:$path"),
        )

        navigationScopes[path] = navScope
        childScopes[path] = scopes

        return scopes
    }

    /**
     * Cancel all scopes for a navigation path. Called on back navigation or
     * path change.
     */
    fun cancelNavigationScope(path: String) {
        navigationScopes[path]?.cancel(
            CancellationException("Navigation changed"),
        )
        navigationScopes.remove(path)
        childScopes.remove(path)
    }

    /** Cancel only specific child scope (e.g. cancel prefetch but keep scan). */
    fun cancelChildScope(path: String, childType: ChildScopeType) {
        val scopes = childScopes[path] ?: return
        when (childType) {
            ChildScopeType.SCAN -> scopes.scan.cancel()
            ChildScopeType.METADATA -> scopes.metadata.cancel()
            ChildScopeType.THUMBNAIL -> scopes.thumbnail.cancel()
            ChildScopeType.PREFETCH -> scopes.prefetch.cancel()
        }
    }

    /** Get scopes for active navigation. */
    fun getScopes(path: String): NavigationScopes? = childScopes[path]

    /**
     * Cancel all active navigation scopes. Called on app background/destroy.
     */
    fun cancelAll() {
        navigationScopes.values.forEach { scope ->
            scope.cancel(CancellationException("App cancelled"))
        }
        navigationScopes.clear()
        childScopes.clear()
    }

    /** App scope for long-running background tasks. */
    fun getAppScope(): CoroutineScope = appScope

    private fun createChildScope(
        parent: CoroutineScope,
        name: String,
    ): CoroutineScope {
        return CoroutineScope(
            SupervisorJob(parent.coroutineContext[Job]) +
                Dispatchers.IO +
                CoroutineName(name),
        )
    }

    fun shutdown() {
        appScope.cancel()
    }

    data class NavigationScopes(
        val navigation: CoroutineScope,  // Parent
        val scan: CoroutineScope,
        val metadata: CoroutineScope,
        val thumbnail: CoroutineScope,
        val prefetch: CoroutineScope,
    )

    enum class ChildScopeType {
        SCAN, METADATA, THUMBNAIL, PREFETCH
    }
}

package com.titan.filemanager.data.threading.pool

import android.os.Process
import com.titan.filemanager.data.threading.controller.CpuAffinityManager
import com.titan.filemanager.data.threading.model.PoolStats
import com.titan.filemanager.data.threading.model.TaskType
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.asCoroutineDispatcher
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ThreadFactory
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * Dedicated Search Thread Pool.
 *
 * Ported technique: #30 Dedicated search pool
 *
 * Search benefits from many threads — parallel directory traversal, parallel
 * index lookup, and result ranking all benefit from concurrency.
 */
class SearchThreadPool(
    private val cpuAffinityManager: CpuAffinityManager,
) {

    companion object {
        private const val POOL_NAME = "SearchPool"
        private const val KEEP_ALIVE_SECONDS = 30L
        private const val QUEUE_CAPACITY = 100
    }

    private val threadCounter = AtomicInteger(0)

    private val threadCount =
        cpuAffinityManager.getRecommendedThreadCount(TaskType.SEARCH)

    private val executor = ThreadPoolExecutor(
        threadCount,
        threadCount * 2,
        KEEP_ALIVE_SECONDS,
        TimeUnit.SECONDS,
        LinkedBlockingQueue(QUEUE_CAPACITY),
        SearchThreadFactory(),
        ThreadPoolExecutor.CallerRunsPolicy(),
    )

    val dispatcher: CoroutineDispatcher = executor.asCoroutineDispatcher()

    private inner class SearchThreadFactory : ThreadFactory {
        override fun newThread(runnable: Runnable): Thread {
            return Thread(
                {
                    Process.setThreadPriority(Process.THREAD_PRIORITY_DEFAULT)
                    runnable.run()
                },
                "$POOL_NAME-${threadCounter.incrementAndGet()}",
            ).apply { isDaemon = true }
        }
    }

    fun getStats() = PoolStats(
        poolName = POOL_NAME,
        activeThreads = executor.activeCount,
        queuedTasks = executor.queue.size,
        completedTasks = executor.completedTaskCount,
        failedTasks = 0L,
        avgExecutionMs = 0L,
        cpuUsagePercent = 0f,
    )

    fun shutdown() = executor.shutdownNow()
}

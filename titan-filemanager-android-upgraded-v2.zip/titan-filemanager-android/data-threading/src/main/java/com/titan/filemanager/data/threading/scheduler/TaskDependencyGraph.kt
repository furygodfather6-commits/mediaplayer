package com.titan.filemanager.data.threading.scheduler

import android.util.Log
import com.titan.filemanager.data.threading.model.ScheduledTask
import com.titan.filemanager.data.threading.model.TaskState
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

/**
 * Task Dependency Graph.
 *
 * Ported technique: #37 Task dependency graph
 *
 * Ensures tasks run in correct order:
 * ```
 * ScanTask ─────┐
 *               ├──→ MetadataTask ──→ ThumbnailTask
 * CacheCheck ───┘
 * ```
 * ScanTask must complete before MetadataTask starts; MetadataTask must
 * complete before ThumbnailTask starts.
 */
class TaskDependencyGraph {

    // Graph: taskId → task info
    private val nodes = ConcurrentHashMap<String, GraphNode>()

    // Waiting tasks: dependency_id → list of waiting tasks
    private val waitingFor = ConcurrentHashMap<String, MutableList<String>>()

    private val scope = CoroutineScope(
        Dispatchers.Default + SupervisorJob() +
            CoroutineName("DependencyGraph"),
    )

    /**
     * Add task to dependency graph. Will execute only when all dependencies
     * complete.
     */
    fun addTask(
        task: ScheduledTask,
        executor: suspend (ScheduledTask) -> Unit,
    ) {
        val node = GraphNode(
            task = task,
            executor = executor,
            pendingDependencies = task.dependencies.toMutableSet(),
        )
        nodes[task.id] = node

        if (task.dependencies.isEmpty()) {
            // No dependencies — execute immediately
            executeTask(node)
        } else {
            // Register as waiting for each dependency
            for (depId in task.dependencies) {
                val depCompleted = nodes[depId]?.task?.state?.get() == TaskState.COMPLETED

                if (depCompleted) {
                    node.pendingDependencies.remove(depId)
                } else {
                    waitingFor.getOrPut(depId) { mutableListOf() }.add(task.id)
                }
            }

            // Check if all dependencies already done
            if (node.pendingDependencies.isEmpty()) {
                executeTask(node)
            }
        }
    }

    /** Execute task in coroutine. */
    private fun executeTask(node: GraphNode) {
        node.task.state.set(TaskState.RUNNING)
        node.job = scope.launch {
            try {
                node.executor(node.task)
                node.task.state.set(TaskState.COMPLETED)
                onTaskCompleted(node.task.id)
            } catch (_: CancellationException) {
                node.task.state.set(TaskState.CANCELLED)
            } catch (e: Exception) {
                node.task.state.set(TaskState.FAILED)
                onTaskFailed(node.task.id, e)
            }
        }
    }

    /** Called when task completes. Unblocks waiting tasks. */
    private fun onTaskCompleted(taskId: String) {
        val waitingTasks = waitingFor.remove(taskId) ?: return

        for (waitingId in waitingTasks) {
            val waitingNode = nodes[waitingId] ?: continue
            waitingNode.pendingDependencies.remove(taskId)

            if (waitingNode.pendingDependencies.isEmpty()) {
                // All dependencies satisfied — execute now
                executeTask(waitingNode)
            }
        }
    }

    /** Cancel task and all its dependents. */
    fun cancelTask(taskId: String) {
        val node = nodes.remove(taskId) ?: return
        node.job?.cancel()
        node.task.state.set(TaskState.CANCELLED)

        // Cancel all tasks that were waiting for this
        cancelDependents(taskId)
    }

    private fun cancelDependents(taskId: String) {
        val dependents = waitingFor.remove(taskId) ?: return
        dependents.forEach { depId ->
            cancelTask(depId)
        }
    }

    /** On task failure — cancel dependents. */
    private fun onTaskFailed(taskId: String, error: Exception) {
        Log.e("DependencyGraph", "Task failed: $taskId", error)
        cancelDependents(taskId)
    }

    fun getNodeCount(): Int = nodes.size

    fun shutdown() {
        scope.cancel()
        nodes.clear()
        waitingFor.clear()
    }

    private data class GraphNode(
        val task: ScheduledTask,
        val executor: suspend (ScheduledTask) -> Unit,
        val pendingDependencies: MutableSet<String>,
        var job: Job? = null,
    )
}

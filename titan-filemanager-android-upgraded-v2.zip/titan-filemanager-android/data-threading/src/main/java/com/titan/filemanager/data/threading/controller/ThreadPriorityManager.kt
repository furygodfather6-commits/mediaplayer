package com.titan.filemanager.data.threading.controller

import android.os.Process
import com.titan.filemanager.data.threading.model.TaskPriority
import java.util.concurrent.ConcurrentHashMap

/**
 * Thread Priority Manager.
 *
 * Ported technique: #33 Thread priority adjustment
 *
 * Dynamically adjusts thread priorities based on:
 *  - Current task type
 *  - User interaction state
 *  - System load
 */
class ThreadPriorityManager {

    // Track thread priorities so we can restore them after a boost
    private val threadPriorities = ConcurrentHashMap<Long, Int>()

    /** Set priority for the calling thread based on a [TaskPriority]. */
    fun setCurrentThreadPriority(priority: TaskPriority) {
        val threadId = Thread.currentThread().id
        val androidPriority = priority.threadPriority

        Process.setThreadPriority(androidPriority)
        threadPriorities[threadId] = androidPriority
    }

    /** Boost priority temporarily for urgent work. */
    fun boostCurrentThread() {
        val threadId = Thread.currentThread().id
        val current = threadPriorities[threadId] ?: Process.THREAD_PRIORITY_DEFAULT

        // Save current and boost
        threadPriorities[threadId] = current
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_DISPLAY)
    }

    /** Restore normal priority after a boost. */
    fun restoreCurrentThread() {
        val threadId = Thread.currentThread().id
        val savedPriority = threadPriorities[threadId]
            ?: Process.THREAD_PRIORITY_DEFAULT
        Process.setThreadPriority(savedPriority)
    }

    /**
     * Set UI thread to highest priority during active user interaction.
     * (UI thread priority is normally managed by Android — this is a hint.)
     */
    fun boostUiThread() {
        Process.setThreadPriority(
            Process.myTid(),
            Process.THREAD_PRIORITY_DISPLAY,
        )
    }

    /**
     * Lower background thread priority when app goes to background.
     * On Android you cannot retroactively set other threads' priority, so
     * this is tracked for when threads check in.
     */
    fun demoteBackgroundThreads() {
        // No-op: stored priorities are consulted on next check-in
    }
}

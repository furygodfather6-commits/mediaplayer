package com.titan.filemanager.data.threading.scheduler

import com.titan.filemanager.data.threading.model.ScheduledTask
import com.titan.filemanager.data.threading.model.TaskState
import com.titan.filemanager.data.threading.model.TaskType
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.yield
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * Work Stealing Scheduler.
 *
 * Ported technique: #34 Work stealing scheduler
 *
 * Architecture:
 *  - Each worker has its own local deque
 *  - Idle workers STEAL from busy workers
 *  - Prevents thread starvation
 *  - Maximizes CPU utilization
 *
 *  Worker 1: [A, B, C] ←steals── Worker 2 (idle)
 *  Worker 2: []
 *  Worker 3: [D, E, F, G, H]
 *
 * Result: better load distribution.
 */
class WorkStealingScheduler(
    private val workerCount: Int,
    private val taskType: TaskType,
) {

    // Per-worker local queues (deque for steal from back)
    private val workerQueues: Array<LockFreeTaskQueue> = Array(workerCount) { i ->
        LockFreeTaskQueue("Worker-$i", maxCapacity = 200)
    }

    private val submitIndex = AtomicInteger(0)

    // Stats
    private val totalStolen = AtomicLong(0L)
    private val totalProcessed = AtomicLong(0L)

    private val workers = mutableListOf<WorkerCoroutine>()
    private val scope = CoroutineScope(
        Dispatchers.IO.limitedParallelism(workerCount) +
            SupervisorJob() +
            CoroutineName("WorkStealing-$taskType"),
    )

    /** Submit task to least-loaded worker. */
    fun submit(task: ScheduledTask): Boolean {
        val targetWorker = findLeastLoadedWorker()
        return workerQueues[targetWorker].enqueue(task)
    }

    /** Start all worker coroutines. */
    fun start(executor: suspend (ScheduledTask) -> Unit) {
        repeat(workerCount) { workerId ->
            val worker = WorkerCoroutine(workerId, executor)
            workers.add(worker)
            worker.start()
        }
    }

    private inner class WorkerCoroutine(
        private val workerId: Int,
        private val executor: suspend (ScheduledTask) -> Unit,
    ) {
        private var job: Job? = null

        fun start() {
            job = scope.launch {
                while (isActive) {
                    val task = getNextTask(workerId)

                    if (task != null) {
                        task.state.set(TaskState.RUNNING)
                        try {
                            executor(task)
                            task.state.set(TaskState.COMPLETED)
                            totalProcessed.incrementAndGet()
                        } catch (_: CancellationException) {
                            task.state.set(TaskState.CANCELLED)
                        } catch (_: Exception) {
                            task.state.set(TaskState.FAILED)
                        }
                    } else {
                        // No work — yield
                        yield()
                        delay(1)
                    }
                }
            }
        }

        /**
         * Get next task:
         *  1. Check own queue first
         *  2. If empty, steal from busiest worker
         */
        private fun getNextTask(workerId: Int): ScheduledTask? {
            // Try own queue first
            workerQueues[workerId].dequeue()?.let { return it }

            // Own queue empty — try to steal
            return trySteal(workerId)
        }

        /** Work stealing: take from back of busiest queue. */
        private fun trySteal(thiefId: Int): ScheduledTask? {
            var victimId = -1
            var maxSize = 0

            for (i in workerQueues.indices) {
                if (i == thiefId) continue
                val size = workerQueues[i].size()
                if (size > maxSize) {
                    maxSize = size
                    victimId = i
                }
            }

            if (victimId == -1 || maxSize <= 1) return null

            // Steal from victim's queue (from back = oldest task)
            val stolen = workerQueues[victimId].steal()
            if (stolen != null) {
                totalStolen.incrementAndGet()
            }
            return stolen
        }

        fun cancel() {
            job?.cancel()
        }
    }

    /** Find worker with smallest queue size. */
    private fun findLeastLoadedWorker(): Int {
        var minSize = Int.MAX_VALUE
        var minIndex = 0

        for (i in workerQueues.indices) {
            val size = workerQueues[i].size()
            if (size < minSize) {
                minSize = size
                minIndex = i
            }
        }
        return minIndex
    }

    fun getStats(): WorkStealingStats {
        val processed = totalProcessed.get()
        return WorkStealingStats(
            workerCount = workerCount,
            totalProcessed = processed,
            totalStolen = totalStolen.get(),
            stealRate = if (processed > 0) totalStolen.get().toFloat() / processed else 0f,
            queueSizes = workerQueues.map { it.size() },
        )
    }

    fun shutdown() {
        workers.forEach { it.cancel() }
        scope.cancel()
    }

    data class WorkStealingStats(
        val workerCount: Int,
        val totalProcessed: Long,
        val totalStolen: Long,
        val stealRate: Float,
        val queueSizes: List<Int>,
    )
}

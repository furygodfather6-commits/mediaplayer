package com.titan.filemanager.data.threading.di

import android.content.Context
import com.titan.filemanager.data.threading.ThreadPoolManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Hilt module that exposes [ThreadPoolManager] as an application-scoped
 * singleton. The manager itself lazily constructs every pool / scheduler /
 * controller — so injecting the manager is the only thing consumers need.
 */
@Module
@InstallIn(SingletonComponent::class)
object ThreadingModule {

    @Provides
    @Singleton
    fun provideThreadPoolManager(
        @ApplicationContext context: Context,
    ): ThreadPoolManager = ThreadPoolManager(context)
}

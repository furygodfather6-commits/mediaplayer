package com.titan.filemanager.data.threading.pool

import android.os.Process
import com.titan.filemanager.data.threading.controller.CpuAffinityManager
import com.titan.filemanager.data.threading.model.PoolStats
import com.titan.filemanager.data.threading.model.TaskType
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.asCoroutineDispatcher
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ThreadFactory
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * Dedicated Thumbnail Thread Pool.
 *
 * Ported techniques:
 *   #27 Dedicated thumbnail pool
 *   #33 Thread priority adjustment
 *
 * Thumbnail threads run at LOWER priority than scan — thumbnails are less
 * critical than the file list itself. When the scan pool is bursting, this
 * pool is paused to avoid I/O contention.
 */
class ThumbnailThreadPool(
    private val cpuAffinityManager: CpuAffinityManager,
) {

    companion object {
        private const val POOL_NAME = "ThumbnailPool"
        private const val KEEP_ALIVE_SECONDS = 60L
        private const val QUEUE_CAPACITY = 500   // Large queue for many thumbnails
    }

    private val threadCounter = AtomicInteger(0)

    private val threadCount =
        cpuAffinityManager.getRecommendedThreadCount(TaskType.THUMBNAIL)

    private val executor = ThreadPoolExecutor(
        threadCount,
        threadCount + 2,
        KEEP_ALIVE_SECONDS,
        TimeUnit.SECONDS,
        LinkedBlockingQueue(QUEUE_CAPACITY),
        ThumbnailThreadFactory(),
        ThreadPoolExecutor.DiscardOldestPolicy(),  // Drop oldest thumbnails if full
    ).apply {
        allowCoreThreadTimeOut(true)
    }

    val dispatcher: CoroutineDispatcher = executor.asCoroutineDispatcher()

    private inner class ThumbnailThreadFactory : ThreadFactory {
        override fun newThread(runnable: Runnable): Thread {
            return Thread(
                {
                    // LOWER priority than scan — must not compete with listing
                    Process.setThreadPriority(
                        Process.THREAD_PRIORITY_BACKGROUND +
                            Process.THREAD_PRIORITY_MORE_FAVORABLE,
                    )
                    runnable.run()
                },
                "$POOL_NAME-${threadCounter.incrementAndGet()}",
            ).apply {
                isDaemon = true
                priority = Thread.NORM_PRIORITY - 1
            }
        }
    }

    /** Pause thumbnails during active scan — prevents I/O contention. */
    fun pause() {
        executor.corePoolSize = 1  // Keep one thread for queue maintenance
    }

    /** Resume after scan completes. */
    fun resume() {
        executor.corePoolSize = threadCount
    }

    fun getStats() = PoolStats(
        poolName = POOL_NAME,
        activeThreads = executor.activeCount,
        queuedTasks = executor.queue.size,
        completedTasks = executor.completedTaskCount,
        failedTasks = 0L,
        avgExecutionMs = 0L,
        cpuUsagePercent = 0f,
    )

    fun shutdown() {
        executor.shutdownNow()
    }
}

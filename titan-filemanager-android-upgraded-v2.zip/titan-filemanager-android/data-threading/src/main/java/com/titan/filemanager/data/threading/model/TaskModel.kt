package com.titan.filemanager.data.threading.model

import android.os.Process
import kotlinx.coroutines.Job
import java.util.concurrent.atomic.AtomicReference

/**
 * Task types for different pools.
 *
 * Each pool has different CPU/IO characteristics, hence they are routed to
 * dedicated executors that match the workload profile (CPU-bound vs IO-bound
 * vs memory-bound).
 */
enum class TaskType {
    /** Directory scanning — CPU + IO mixed. */
    SCAN,

    /** Thumbnail generation — CPU + IO mixed, lower priority. */
    THUMBNAIL,

    /** DB read/write — IO bound (SQLite WAL). */
    DATABASE,

    /** Media metadata extraction — CPU intensive. */
    MEDIA_ANALYSIS,

    /** File search — parallel traversal + index lookup. */
    SEARCH,

    /** Background prefetch — lowest priority. */
    PREFETCH
}

/**
 * Task priority levels.
 *
 * Maps logical priority to Android [Process.setThreadPriority] constants so
 * the OS scheduler knows how to weight each thread.
 */
enum class TaskPriority(val value: Int, val threadPriority: Int) {
    REALTIME(100, Process.THREAD_PRIORITY_DISPLAY),
    CRITICAL(90,  Process.THREAD_PRIORITY_URGENT_DISPLAY),
    HIGH(75,      Process.THREAD_PRIORITY_DEFAULT),
    NORMAL(50,    Process.THREAD_PRIORITY_DEFAULT),
    LOW(25,       Process.THREAD_PRIORITY_BACKGROUND),
    IDLE(10,      Process.THREAD_PRIORITY_LOWEST)
}

/**
 * Task state machine.
 */
enum class TaskState {
    PENDING,
    QUEUED,
    RUNNING,
    COMPLETED,
    CANCELLED,
    FAILED
}

/**
 * Represents a scheduled task. The state and the bound coroutine [Job] are
 * stored atomically so they can be observed / mutated from any thread without
 * external locking.
 */
data class ScheduledTask(
    val id: String,
    val type: TaskType,
    val priority: TaskPriority,
    val dependencies: Set<String> = emptySet(),
    val createdAt: Long = System.currentTimeMillis(),
    val state: AtomicReference<TaskState> = AtomicReference(TaskState.PENDING),
    val job: AtomicReference<Job?> = AtomicReference(null),
    val metadata: Map<String, Any> = emptyMap()
) : Comparable<ScheduledTask> {
    override fun compareTo(other: ScheduledTask): Int {
        // Higher priority = lower queue index (min-heap semantics)
        return other.priority.value.compareTo(this.priority.value)
    }
}

/**
 * Pool statistics for monitoring / dashboards.
 */
data class PoolStats(
    val poolName: String,
    val activeThreads: Int,
    val queuedTasks: Int,
    val completedTasks: Long,
    val failedTasks: Long,
    val avgExecutionMs: Long,
    val cpuUsagePercent: Float
)

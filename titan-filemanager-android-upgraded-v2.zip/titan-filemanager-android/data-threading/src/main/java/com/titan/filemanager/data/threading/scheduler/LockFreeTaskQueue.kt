package com.titan.filemanager.data.threading.scheduler

import com.titan.filemanager.data.threading.model.ScheduledTask
import com.titan.filemanager.data.threading.model.TaskPriority
import java.util.concurrent.ConcurrentLinkedDeque
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * Lock-Free Task Queue.
 *
 * Ported technique: #38 Lock-free task queues
 *
 * Uses:
 *  - [ConcurrentLinkedDeque] for LIFO (cache-friendly) operations
 *  - Atomic counters for stats — no locks needed
 *
 * Design: multi-level queue CRITICAL → HIGH → NORMAL → LOW → IDLE.
 * Dequeue walks levels in priority order; [steal] takes from the back of
 * lower-priority levels (least contention).
 */
class LockFreeTaskQueue(
    private val name: String,
    private val maxCapacity: Int = 1000,
) {

    // Separate queues per priority for O(1) enqueue/dequeue
    private val criticalQueue = ConcurrentLinkedDeque<ScheduledTask>()
    private val highQueue = ConcurrentLinkedDeque<ScheduledTask>()
    private val normalQueue = ConcurrentLinkedDeque<ScheduledTask>()
    private val lowQueue = ConcurrentLinkedDeque<ScheduledTask>()
    private val idleQueue = ConcurrentLinkedDeque<ScheduledTask>()

    // Atomic counters — no locks needed
    private val totalSize = AtomicInteger(0)
    private val enqueuedCount = AtomicLong(0)
    private val dequeuedCount = AtomicLong(0)
    private val droppedCount = AtomicLong(0)

    /** Enqueue task — O(1), no locking required. */
    fun enqueue(task: ScheduledTask): Boolean {
        if (totalSize.get() >= maxCapacity) {
            // Drop lowest priority if full
            if (!dropLowestPriority()) {
                droppedCount.incrementAndGet()
                return false
            }
        }

        val queue = getQueueFor(task.priority)
        queue.addLast(task)
        totalSize.incrementAndGet()
        enqueuedCount.incrementAndGet()
        return true
    }

    /** Enqueue at FRONT for urgent tasks — still O(1) with deque. */
    fun enqueueFront(task: ScheduledTask): Boolean {
        val queue = getQueueFor(task.priority)
        queue.addFirst(task)
        totalSize.incrementAndGet()
        enqueuedCount.incrementAndGet()
        return true
    }

    /** Dequeue highest-priority task — O(1). */
    fun dequeue(): ScheduledTask? {
        val task = criticalQueue.pollFirst()
            ?: highQueue.pollFirst()
            ?: normalQueue.pollFirst()
            ?: lowQueue.pollFirst()
            ?: idleQueue.pollFirst()

        if (task != null) {
            totalSize.decrementAndGet()
            dequeuedCount.incrementAndGet()
        }
        return task
    }

    /** Peek without removing — O(1). */
    fun peek(): ScheduledTask? {
        return criticalQueue.peekFirst()
            ?: highQueue.peekFirst()
            ?: normalQueue.peekFirst()
            ?: lowQueue.peekFirst()
            ?: idleQueue.peekFirst()
    }

    /** Remove specific task by ID. Used for cancellation. */
    fun remove(taskId: String): Boolean {
        val allQueues = listOf(criticalQueue, highQueue, normalQueue, lowQueue, idleQueue)
        for (queue in allQueues) {
            val iter = queue.iterator()
            while (iter.hasNext()) {
                val task = iter.next()
                if (task.id == taskId) {
                    iter.remove()
                    totalSize.decrementAndGet()
                    return true
                }
            }
        }
        return false
    }

    /** Drain all tasks of specific type. Called on navigation change. */
    fun drainByType(taskType: com.titan.filemanager.data.threading.model.TaskType): List<ScheduledTask> {
        val drained = mutableListOf<ScheduledTask>()
        val allQueues = listOf(criticalQueue, highQueue, normalQueue, lowQueue, idleQueue)

        for (queue in allQueues) {
            val iter = queue.iterator()
            while (iter.hasNext()) {
                val task = iter.next()
                if (task.type == taskType) {
                    iter.remove()
                    totalSize.decrementAndGet()
                    drained.add(task)
                }
            }
        }
        return drained
    }

    /**
     * Work stealing: take task from back of queue.
     * Ported technique: #34 Work stealing scheduler
     */
    fun steal(): ScheduledTask? {
        // Steal from lowest priority first (least contention)
        val task = idleQueue.pollLast()
            ?: lowQueue.pollLast()
            ?: normalQueue.pollLast()

        if (task != null) {
            totalSize.decrementAndGet()
            dequeuedCount.incrementAndGet()
        }
        return task
    }

    fun size(): Int = totalSize.get()
    fun isEmpty(): Boolean = totalSize.get() == 0

    fun getStats(): QueueStats = QueueStats(
        name = name,
        totalSize = totalSize.get(),
        criticalSize = criticalQueue.size,
        highSize = highQueue.size,
        normalSize = normalQueue.size,
        lowSize = lowQueue.size,
        idleSize = idleQueue.size,
        totalEnqueued = enqueuedCount.get(),
        totalDequeued = dequeuedCount.get(),
        totalDropped = droppedCount.get(),
    )

    private fun getQueueFor(priority: TaskPriority): ConcurrentLinkedDeque<ScheduledTask> {
        return when (priority) {
            TaskPriority.REALTIME, TaskPriority.CRITICAL -> criticalQueue
            TaskPriority.HIGH -> highQueue
            TaskPriority.NORMAL -> normalQueue
            TaskPriority.LOW -> lowQueue
            TaskPriority.IDLE -> idleQueue
        }
    }

    private fun dropLowestPriority(): Boolean {
        return idleQueue.pollLast() != null ||
            lowQueue.pollLast() != null
    }

    data class QueueStats(
        val name: String,
        val totalSize: Int,
        val criticalSize: Int,
        val highSize: Int,
        val normalSize: Int,
        val lowSize: Int,
        val idleSize: Int,
        val totalEnqueued: Long,
        val totalDequeued: Long,
        val totalDropped: Long,
    )
}

package com.titan.filemanager.data.threading.pool

import android.os.Process
import com.titan.filemanager.data.threading.controller.CpuAffinityManager
import com.titan.filemanager.data.threading.model.PoolStats
import com.titan.filemanager.data.threading.model.TaskType
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.asCoroutineDispatcher
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ThreadFactory
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * Dedicated Media Analysis Pool.
 *
 * Ported technique: #29 Dedicated media-analysis pool
 *
 * Media analysis is CPU-intensive (image dimensions, video metadata, audio
 * tags). Uses BIG cores at a priority lower than scan but above background.
 */
class MediaAnalysisPool(
    private val cpuAffinityManager: CpuAffinityManager,
) {

    companion object {
        private const val POOL_NAME = "MediaPool"
        private const val KEEP_ALIVE_SECONDS = 60L
        private const val QUEUE_CAPACITY = 300
    }

    private val threadCounter = AtomicInteger(0)

    private val threadCount =
        cpuAffinityManager.getRecommendedThreadCount(TaskType.MEDIA_ANALYSIS)

    private val executor = ThreadPoolExecutor(
        threadCount,
        threadCount,
        KEEP_ALIVE_SECONDS,
        TimeUnit.SECONDS,
        LinkedBlockingQueue(QUEUE_CAPACITY),
        MediaThreadFactory(),
        ThreadPoolExecutor.DiscardPolicy(),  // Drop if overloaded
    )

    val dispatcher: CoroutineDispatcher = executor.asCoroutineDispatcher()

    private inner class MediaThreadFactory : ThreadFactory {
        override fun newThread(runnable: Runnable): Thread {
            return Thread(
                {
                    // Medium priority — below scan, above background
                    Process.setThreadPriority(
                        Process.THREAD_PRIORITY_DEFAULT +
                            Process.THREAD_PRIORITY_LESS_FAVORABLE,
                    )
                    runnable.run()
                },
                "$POOL_NAME-${threadCounter.incrementAndGet()}",
            ).apply { isDaemon = true }
        }
    }

    fun getStats() = PoolStats(
        poolName = POOL_NAME,
        activeThreads = executor.activeCount,
        queuedTasks = executor.queue.size,
        completedTasks = executor.completedTaskCount,
        failedTasks = 0L,
        avgExecutionMs = 0L,
        cpuUsagePercent = 0f,
    )

    fun shutdown() = executor.shutdownNow()
}

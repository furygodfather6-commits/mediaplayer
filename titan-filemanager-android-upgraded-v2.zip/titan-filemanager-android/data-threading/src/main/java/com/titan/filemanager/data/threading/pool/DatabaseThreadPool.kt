package com.titan.filemanager.data.threading.pool

import android.os.Process
import com.titan.filemanager.data.threading.controller.CpuAffinityManager
import com.titan.filemanager.data.threading.model.PoolStats
import com.titan.filemanager.data.threading.model.TaskType
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.asCoroutineDispatcher
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ThreadFactory
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * Dedicated Database Thread Pool.
 *
 * Ported technique: #28 Dedicated database pool
 *
 * Separate pool for DB operations because:
 *  1. SQLite has its own locking
 *  2. I/O wait is different from CPU work
 *  3. DB threads can be more numerous (mostly waiting)
 *  4. Avoids blocking scan/thumbnail operations
 *
 * Write side is serialized (SQLite is single-writer). Read side runs
 * concurrently (WAL mode allows concurrent readers).
 */
class DatabaseThreadPool(
    private val cpuAffinityManager: CpuAffinityManager,
) {

    companion object {
        private const val POOL_NAME = "DatabasePool"
        private const val KEEP_ALIVE_SECONDS = 30L
        private const val QUEUE_CAPACITY = 1000
    }

    private val threadCounter = AtomicInteger(0)
    private val writeCount = AtomicLong(0L)
    private val readCount = AtomicLong(0L)

    private val threadCount =
        cpuAffinityManager.getRecommendedThreadCount(TaskType.DATABASE)

    // Single write thread — SQLite is single-writer
    private val writeExecutor = ThreadPoolExecutor(
        1, 1,
        KEEP_ALIVE_SECONDS,
        TimeUnit.SECONDS,
        LinkedBlockingQueue(QUEUE_CAPACITY),
        DbThreadFactory("Write"),
        ThreadPoolExecutor.CallerRunsPolicy(),
    )

    // Multiple read threads — WAL mode allows concurrent reads
    private val readExecutor = ThreadPoolExecutor(
        threadCount,
        threadCount * 2,
        KEEP_ALIVE_SECONDS,
        TimeUnit.SECONDS,
        LinkedBlockingQueue(QUEUE_CAPACITY),
        DbThreadFactory("Read"),
        ThreadPoolExecutor.CallerRunsPolicy(),
    )

    val readDispatcher: CoroutineDispatcher = readExecutor.asCoroutineDispatcher()
    val writeDispatcher: CoroutineDispatcher = writeExecutor.asCoroutineDispatcher()

    private inner class DbThreadFactory(
        private val type: String,
    ) : ThreadFactory {
        override fun newThread(runnable: Runnable): Thread {
            return Thread(
                {
                    // DB threads at background priority
                    Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND)
                    runnable.run()
                },
                "$POOL_NAME-$type-${threadCounter.incrementAndGet()}",
            ).apply { isDaemon = true }
        }
    }

    fun recordWrite() = writeCount.incrementAndGet()
    fun recordRead() = readCount.incrementAndGet()

    fun getStats() = PoolStats(
        poolName = POOL_NAME,
        activeThreads = writeExecutor.activeCount + readExecutor.activeCount,
        queuedTasks = writeExecutor.queue.size + readExecutor.queue.size,
        completedTasks = writeExecutor.completedTaskCount + readExecutor.completedTaskCount,
        failedTasks = 0L,
        avgExecutionMs = 0L,
        cpuUsagePercent = 0f,
    )

    fun shutdown() {
        writeExecutor.shutdown()
        readExecutor.shutdown()
    }
}

package com.titan.filemanager.data.threading.controller

import android.app.ActivityManager
import android.content.Context
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.util.Log
import com.titan.filemanager.data.threading.pool.ScanThreadPool
import com.titan.filemanager.data.threading.pool.ThumbnailThreadPool
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.atomic.AtomicInteger

/**
 * Adaptive Thread Controller.
 *
 * Ported techniques:
 *   #31 Adaptive thread count
 *   #156 Battery-aware scheduling
 *   #157 Thermal-aware scheduling
 *   #158 Low-memory mode
 *
 * Dynamically adjusts thread counts based on:
 *   1. CPU load
 *   2. Battery level / charging state
 *   3. Thermal state
 *   4. Available memory
 *   5. Current app workload
 */
class AdaptiveThreadController(
    private val context: Context,
    private val scanPool: ScanThreadPool,
    private val thumbnailPool: ThumbnailThreadPool,
) {

    companion object {
        private const val TAG = "AdaptiveThread"
        private const val CHECK_INTERVAL_MS = 5000L   // Check every 5 seconds
        private const val MIN_THREADS = 1
        private const val MAX_THREADS = 8

        // Thresholds
        private const val CPU_HIGH_THRESHOLD = 80f    // Reduce if CPU > 80%
        private const val CPU_LOW_THRESHOLD = 30f     // Increase if CPU < 30%
        private const val BATTERY_LOW_PERCENT = 20    // Low battery threshold
        private const val THERMAL_SEVERE_TEMP = 45    // Celsius
    }

    private val scope = CoroutineScope(
        Dispatchers.Default +
            SupervisorJob() +
            CoroutineName("AdaptiveThreadController"),
    )

    private val currentMode = AtomicInteger(Mode.NORMAL.value)

    enum class Mode(val value: Int) {
        PERFORMANCE(3),   // Max threads, high priority
        NORMAL(2),        // Balanced
        POWER_SAVER(1),   // Fewer threads
        EMERGENCY(0),     // Minimum threads
    }

    /** Start adaptive monitoring loop. */
    fun start() {
        scope.launch {
            while (isActive) {
                try {
                    adjustThreadCounts()
                } catch (e: Exception) {
                    Log.e(TAG, "Error in adaptive control", e)
                }
                delay(CHECK_INTERVAL_MS)
            }
        }
        Log.d(TAG, "Adaptive thread controller started")
    }

    private fun adjustThreadCounts() {
        val systemState = gatherSystemState()
        val newMode = determineMode(systemState)

        val oldMode = Mode.entries.find { it.value == currentMode.get() } ?: Mode.NORMAL
        if (newMode != oldMode) {
            Log.d(TAG, "Mode change: $oldMode → $newMode (state=$systemState)")
            currentMode.set(newMode.value)
            applyMode(newMode)
        }
    }

    private fun gatherSystemState(): SystemState {
        return SystemState(
            cpuUsage = getCpuUsage(),
            availableMemoryMb = getAvailableMemoryMb(),
            batteryPercent = getBatteryPercent(),
            isCharging = isCharging(),
            thermalState = getThermalState(),
            isLowPowerMode = isLowPowerMode(),
        )
    }

    private fun determineMode(state: SystemState): Mode {
        // Emergency: thermal throttling or very low memory
        if (state.thermalState == ThermalState.SEVERE ||
            state.availableMemoryMb < 50
        ) {
            return Mode.EMERGENCY
        }

        // Power saver: low battery + not charging
        if (state.batteryPercent < BATTERY_LOW_PERCENT && !state.isCharging) {
            return Mode.POWER_SAVER
        }

        // Power saver: low power mode enabled
        if (state.isLowPowerMode) {
            return Mode.POWER_SAVER
        }

        // Performance: charging + ample resources
        if (state.isCharging &&
            state.cpuUsage < CPU_LOW_THRESHOLD &&
            state.availableMemoryMb > 200
        ) {
            return Mode.PERFORMANCE
        }

        // High CPU: reduce threads
        if (state.cpuUsage > CPU_HIGH_THRESHOLD) {
            return Mode.POWER_SAVER
        }

        return Mode.NORMAL
    }

    private fun applyMode(mode: Mode) {
        val cpuCount = Runtime.getRuntime().availableProcessors()

        val scanThreads = when (mode) {
            Mode.PERFORMANCE -> minOf(cpuCount, MAX_THREADS)
            Mode.NORMAL -> minOf(cpuCount / 2 + 1, 6)
            Mode.POWER_SAVER -> minOf(cpuCount / 4 + 1, 3)
            Mode.EMERGENCY -> MIN_THREADS
        }

        scanPool.updateThreadCount(scanThreads)

        // Thumbnail pool adjustment
        when (mode) {
            Mode.PERFORMANCE, Mode.NORMAL -> thumbnailPool.resume()
            Mode.EMERGENCY, Mode.POWER_SAVER -> thumbnailPool.pause()
        }

        Log.d(TAG, "Applied mode $mode: scanThreads=$scanThreads")
    }

    /** CPU usage from /proc/stat. */
    private fun getCpuUsage(): Float {
        return try {
            val stat1 = readCpuStat()
            Thread.sleep(200)
            val stat2 = readCpuStat()

            val total = (stat2.total - stat1.total).toFloat()
            val idle = (stat2.idle - stat1.idle).toFloat()

            if (total > 0) ((total - idle) / total) * 100f else 0f
        } catch (_: Exception) {
            50f  // Assume medium usage on error
        }
    }

    private fun readCpuStat(): CpuStat {
        val line = File("/proc/stat").readLines().firstOrNull()
            ?: return CpuStat(0, 0)
        val parts = line.split("\\s+".toRegex())
        val values = parts.drop(1).mapNotNull { it.toLongOrNull() }

        val idle = values.getOrElse(3) { 0L }
        val total = values.sum()
        return CpuStat(total, idle)
    }

    private fun getAvailableMemoryMb(): Long {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        return info.availMem / (1024 * 1024)
    }

    private fun getBatteryPercent(): Int {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    }

    private fun isCharging(): Boolean {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        return bm.isCharging
    }

    private fun getThermalState(): ThermalState {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            when (pm.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> ThermalState.NORMAL
                PowerManager.THERMAL_STATUS_LIGHT -> ThermalState.LIGHT
                PowerManager.THERMAL_STATUS_MODERATE -> ThermalState.MODERATE
                PowerManager.THERMAL_STATUS_SEVERE,
                PowerManager.THERMAL_STATUS_CRITICAL,
                PowerManager.THERMAL_STATUS_EMERGENCY,
                PowerManager.THERMAL_STATUS_SHUTDOWN -> ThermalState.SEVERE
                else -> ThermalState.NORMAL
            }
        } else {
            readThermalFromSys()
        }
    }

    private fun readThermalFromSys(): ThermalState {
        return try {
            val tempFile = File("/sys/class/thermal/thermal_zone0/temp")
            val temp = tempFile.readText().trim().toIntOrNull() ?: 0
            // temp is in milli-celsius
            val celsius = temp / 1000
            when {
                celsius > THERMAL_SEVERE_TEMP -> ThermalState.SEVERE
                celsius > 40 -> ThermalState.MODERATE
                celsius > 35 -> ThermalState.LIGHT
                else -> ThermalState.NORMAL
            }
        } catch (_: Exception) {
            ThermalState.NORMAL
        }
    }

    private fun isLowPowerMode(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            pm.isPowerSaveMode
        } else false
    }

    fun getCurrentMode(): Mode =
        Mode.entries.find { it.value == currentMode.get() } ?: Mode.NORMAL

    fun stop() {
        scope.cancel()
    }

    private data class CpuStat(val total: Long, val idle: Long)

    data class SystemState(
        val cpuUsage: Float,
        val availableMemoryMb: Long,
        val batteryPercent: Int,
        val isCharging: Boolean,
        val thermalState: ThermalState,
        val isLowPowerMode: Boolean,
    )

    enum class ThermalState { NORMAL, LIGHT, MODERATE, SEVERE }
}

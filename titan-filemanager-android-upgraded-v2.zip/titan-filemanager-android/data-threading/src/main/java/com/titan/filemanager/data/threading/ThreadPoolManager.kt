package com.titan.filemanager.data.threading

import android.content.Context
import android.util.Log
import com.titan.filemanager.data.threading.controller.AdaptiveThreadController
import com.titan.filemanager.data.threading.controller.CpuAffinityManager
import com.titan.filemanager.data.threading.controller.CpuBurstController
import com.titan.filemanager.data.threading.controller.ThreadPriorityManager
import com.titan.filemanager.data.threading.model.PoolStats
import com.titan.filemanager.data.threading.model.TaskType
import com.titan.filemanager.data.threading.pool.DatabaseThreadPool
import com.titan.filemanager.data.threading.pool.MediaAnalysisPool
import com.titan.filemanager.data.threading.pool.ScanThreadPool
import com.titan.filemanager.data.threading.pool.SearchThreadPool
import com.titan.filemanager.data.threading.pool.ThumbnailThreadPool
import com.titan.filemanager.data.threading.scheduler.StructuredConcurrencyManager
import com.titan.filemanager.data.threading.scheduler.TaskCancellationHub
import com.titan.filemanager.data.threading.scheduler.TaskDependencyGraph
import com.titan.filemanager.data.threading.scheduler.WorkStealingScheduler
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Master Thread Pool Manager.
 *
 * Ported techniques #26-#39 — all threading techniques in a single entry
 * point. Provides Hilt-managed singletons for every dedicated pool and
 * scheduling primitive.
 *
 * The master manager:
 *  - Bootstraps CPU topology detection ([CpuAffinityManager])
 *  - Lazily instantiates each dedicated pool with the right thread count
 *  - Wires the [AdaptiveThreadController] to scan + thumbnail pools
 *  - Exposes a single [getDispatcher] helper for picking the right pool by
 *    [TaskType]
 *  - Owns the lifecycle (init / shutdown) of all sub-components
 */
@Singleton
class ThreadPoolManager @Inject constructor(
    private val context: Context,
) {

    companion object {
        private const val TAG = "ThreadPoolManager"
    }

    // CPU topology
    val cpuAffinityManager = CpuAffinityManager()

    // Adaptive controller (created first, pools depend on it)
    @Volatile
    private var _adaptiveController: AdaptiveThreadController? = null
    val adaptiveController: AdaptiveThreadController
        get() = _adaptiveController ?: error("ThreadPoolManager not initialized")

    // Thread pools
    val scanPool: ScanThreadPool by lazy {
        ScanThreadPool(cpuAffinityManager, adaptiveController)
    }

    val thumbnailPool: ThumbnailThreadPool by lazy {
        ThumbnailThreadPool(cpuAffinityManager)
    }

    val databasePool: DatabaseThreadPool by lazy {
        DatabaseThreadPool(cpuAffinityManager)
    }

    val mediaPool: MediaAnalysisPool by lazy {
        MediaAnalysisPool(cpuAffinityManager)
    }

    val searchPool: SearchThreadPool by lazy {
        SearchThreadPool(cpuAffinityManager)
    }

    // Higher-level managers
    val burstController: CpuBurstController by lazy {
        CpuBurstController(scanPool, thumbnailPool, adaptiveController)
    }

    val concurrencyManager = StructuredConcurrencyManager()

    val cancellationHub = TaskCancellationHub()

    val dependencyGraph = TaskDependencyGraph()

    val priorityManager = ThreadPriorityManager()

    val workStealingScheduler: WorkStealingScheduler by lazy {
        WorkStealingScheduler(
            workerCount = cpuAffinityManager.getRecommendedThreadCount(TaskType.SCAN),
            taskType = TaskType.SCAN,
        )
    }

    init {
        initialize()
    }

    private fun initialize() {
        Log.d(TAG, "Initializing ThreadPoolManager")
        Log.d(TAG, "CPU Topology: ${cpuAffinityManager.getCpuTopology()}")

        // Create adaptive controller after pools are available
        _adaptiveController = AdaptiveThreadController(
            context = context,
            scanPool = scanPool,
            thumbnailPool = thumbnailPool,
        )

        // Start adaptive monitoring
        adaptiveController.start()

        Log.d(TAG, "ThreadPoolManager initialized")
    }

    /** Get dispatcher for task type. */
    fun getDispatcher(taskType: TaskType): CoroutineDispatcher = when (taskType) {
        TaskType.SCAN -> scanPool.dispatcher
        TaskType.THUMBNAIL -> thumbnailPool.dispatcher
        TaskType.DATABASE -> databasePool.readDispatcher
        TaskType.MEDIA_ANALYSIS -> mediaPool.dispatcher
        TaskType.SEARCH -> searchPool.dispatcher
        TaskType.PREFETCH -> Dispatchers.IO
    }

    /** Trigger burst on folder navigation. */
    fun onFolderOpened() {
        burstController.triggerFolderOpenBurst()
    }

    /** Get all pool statistics. */
    fun getAllStats(): Map<String, PoolStats> = mapOf(
        "scan" to scanPool.getStats(),
        "thumbnail" to thumbnailPool.getStats(),
        "database" to databasePool.getStats(),
        "media" to mediaPool.getStats(),
        "search" to searchPool.getStats(),
    )

    /** Shutdown all pools gracefully. */
    fun shutdown() {
        Log.d(TAG, "Shutting down ThreadPoolManager")
        runCatching { adaptiveController.stop() }
        runCatching { burstController.shutdown() }
        runCatching { concurrencyManager.shutdown() }
        runCatching { cancellationHub.cancelAll() }
        runCatching { dependencyGraph.shutdown() }
        runCatching { workStealingScheduler.shutdown() }
        runCatching { scanPool.shutdown() }
        runCatching { thumbnailPool.shutdown() }
        runCatching { databasePool.shutdown() }
        runCatching { mediaPool.shutdown() }
        runCatching { searchPool.shutdown() }
    }
}

package com.titan.filemanager.data.threading.pool

import android.os.Process
import com.titan.filemanager.data.threading.controller.AdaptiveThreadController
import com.titan.filemanager.data.threading.controller.CpuAffinityManager
import com.titan.filemanager.data.threading.model.PoolStats
import com.titan.filemanager.data.threading.model.TaskPriority
import com.titan.filemanager.data.threading.model.TaskType
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.asCoroutineDispatcher
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ThreadFactory
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * Dedicated Scan Thread Pool.
 *
 * Ported techniques:
 *   #26 Dedicated scan thread pool
 *   #31 Adaptive thread count
 *   #33 Thread priority adjustment
 *   #39 CPU affinity (big cores)
 *
 * Scan is the highest-leverage workload — fast scans make the whole UI feel
 * snappy. Threads run on big cores at HIGH priority and the pool size is
 * dynamically adjusted by [AdaptiveThreadController].
 */
class ScanThreadPool(
    private val cpuAffinityManager: CpuAffinityManager,
    private val adaptiveController: AdaptiveThreadController,
) {

    companion object {
        private const val POOL_NAME = "ScanPool"
        private const val KEEP_ALIVE_SECONDS = 30L
        private const val QUEUE_CAPACITY = 200
    }

    private val threadCounter = AtomicInteger(0)
    private val completedTasks = AtomicLong(0L)
    private val totalExecutionMs = AtomicLong(0L)

    private val initialThreadCount =
        cpuAffinityManager.getRecommendedThreadCount(TaskType.SCAN)

    private val executor = ThreadPoolExecutor(
        initialThreadCount,              // Core pool size
        initialThreadCount * 2,          // Max pool size (burst)
        KEEP_ALIVE_SECONDS,
        TimeUnit.SECONDS,
        LinkedBlockingQueue(QUEUE_CAPACITY),
        ScanThreadFactory(),
        ThreadPoolExecutor.CallerRunsPolicy(),  // Backpressure
    ).apply {
        allowCoreThreadTimeOut(true)
    }

    val dispatcher: CoroutineDispatcher = executor.asCoroutineDispatcher()

    /**
     * Custom thread factory — sets thread name, priority, and affinity hints.
     */
    private inner class ScanThreadFactory : ThreadFactory {
        override fun newThread(runnable: Runnable): Thread {
            return Thread(
                {
                    // Technique #33: Thread priority adjustment
                    Process.setThreadPriority(TaskPriority.HIGH.threadPriority)
                    runnable.run()
                },
                "$POOL_NAME-${threadCounter.incrementAndGet()}",
            ).apply {
                isDaemon = true
                priority = Thread.NORM_PRIORITY + 1
            }
        }
    }

    /**
     * Burst mode: temporarily max out thread count.
     * Technique #32: CPU burst on folder open.
     */
    fun enterBurstMode() {
        val burstCount = (initialThreadCount * 2)
            .coerceAtMost(Runtime.getRuntime().availableProcessors())
        executor.maximumPoolSize = burstCount
        executor.corePoolSize = burstCount
    }

    /** Exit burst mode: reduce back to normal. */
    fun exitBurstMode() {
        executor.maximumPoolSize = initialThreadCount * 2
        executor.corePoolSize = initialThreadCount
    }

    /**
     * Adaptive thread count update — called periodically by
     * [AdaptiveThreadController].
     */
    fun updateThreadCount(newCount: Int) {
        val bounded = newCount
            .coerceAtLeast(1)
            .coerceAtMost(Runtime.getRuntime().availableProcessors())

        if (bounded != executor.corePoolSize) {
            executor.maximumPoolSize = bounded * 2
            executor.corePoolSize = bounded
        }
    }

    fun recordCompletion(executionMs: Long) {
        completedTasks.incrementAndGet()
        totalExecutionMs.addAndGet(executionMs)
    }

    fun getStats(): PoolStats {
        val completed = completedTasks.get()
        val avgMs = if (completed > 0) totalExecutionMs.get() / completed else 0L
        return PoolStats(
            poolName = POOL_NAME,
            activeThreads = executor.activeCount,
            queuedTasks = executor.queue.size,
            completedTasks = executor.completedTaskCount,
            failedTasks = 0L,
            avgExecutionMs = avgMs,
            cpuUsagePercent = 0f,
        )
    }

    fun shutdown() {
        executor.shutdown()
        try {
            if (!executor.awaitTermination(5, TimeUnit.SECONDS)) {
                executor.shutdownNow()
            }
        } catch (_: InterruptedException) {
            executor.shutdownNow()
            Thread.currentThread().interrupt()
        }
    }
}

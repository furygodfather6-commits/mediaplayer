package com.titan.filemanager.data.threading.controller

import android.util.Log
import com.titan.filemanager.data.threading.model.TaskType
import java.io.File

/**
 * CPU Affinity Manager.
 *
 * Ported technique: #39 CPU affinity (big/LITTLE cores)
 *
 * ARM big.LITTLE detection:
 *  - Big cores    — high frequency, fast, power hungry
 *  - LITTLE cores — low frequency, slow, power efficient
 *
 * Strategy:
 *  - Scan         → Big cores (need speed)
 *  - Background   → LITTLE cores (save battery)
 *  - Thumbnail    → Medium cores
 */
class CpuAffinityManager {

    companion object {
        private const val TAG = "CpuAffinity"
        private const val CPU_PATH = "/sys/devices/system/cpu"
        private const val FREQ_PATH = "cpufreq/cpuinfo_max_freq"
    }

    /** CPU topology, detected lazily on first access. */
    val cpuInfo: CpuTopology by lazy { detectCpuTopology() }

    /**
     * Detect big.LITTLE CPU topology by reading max frequency for each core
     * from `/sys/devices/system/cpu/cpuN/cpufreq/cpuinfo_max_freq`.
     */
    private fun detectCpuTopology(): CpuTopology {
        val cpuCount = Runtime.getRuntime().availableProcessors()
        val frequencies = mutableListOf<Pair<Int, Long>>() // cpu_id, max_freq

        for (cpuId in 0 until cpuCount) {
            val freqFile = File("$CPU_PATH/cpu$cpuId/$FREQ_PATH")
            val freq = try {
                freqFile.readText().trim().toLongOrNull() ?: 0L
            } catch (_: Exception) {
                0L
            }
            frequencies.add(Pair(cpuId, freq))
        }

        if (frequencies.all { it.second == 0L }) {
            // Cannot read frequencies — assume all cores equal
            Log.w(TAG, "Cannot read CPU frequencies, using all cores uniformly")
            val allCores = (0 until cpuCount).toList()
            return CpuTopology(
                bigCores = allCores,
                littleCores = emptyList(),
                midCores = emptyList(),
                totalCores = cpuCount,
            )
        }

        // Sort by frequency to identify big/LITTLE buckets
        val sorted = frequencies.sortedByDescending { it.second }
        val maxFreq = sorted.first().second
        val minFreq = sorted.last().second
        val range = maxFreq - minFreq

        val bigCores = mutableListOf<Int>()
        val midCores = mutableListOf<Int>()
        val littleCores = mutableListOf<Int>()

        for ((cpuId, freq) in frequencies) {
            val ratio = if (range > 0) {
                (freq - minFreq).toFloat() / range
            } else {
                1.0f
            }

            when {
                ratio > 0.66f -> bigCores.add(cpuId)     // Top 33% = big
                ratio > 0.33f -> midCores.add(cpuId)     // Middle = mid
                else -> littleCores.add(cpuId)            // Bottom = LITTLE
            }
        }

        Log.d(TAG, "CPU Topology: big=$bigCores mid=$midCores little=$littleCores")

        return CpuTopology(
            bigCores = bigCores,
            midCores = midCores,
            littleCores = littleCores,
            totalCores = cpuCount,
        )
    }

    /**
     * Get recommended thread count for task type based on the detected CPU
     * topology. Bounded to sensible defaults per task type.
     */
    fun getRecommendedThreadCount(taskType: TaskType): Int {
        val topology = cpuInfo
        return when (taskType) {
            TaskType.SCAN -> {
                // Use big + mid cores for speed
                (topology.bigCores.size + topology.midCores.size)
                    .coerceAtLeast(2)
                    .coerceAtMost(8)
            }
            TaskType.THUMBNAIL -> {
                // Use mid cores (balanced speed/power)
                (topology.midCores.size + topology.bigCores.size / 2)
                    .coerceAtLeast(2)
                    .coerceAtMost(4)
            }
            TaskType.DATABASE -> {
                // DB is mostly I/O wait — can use more threads
                topology.totalCores.coerceAtLeast(2)
            }
            TaskType.MEDIA_ANALYSIS -> {
                // CPU intensive — use big cores only
                topology.bigCores.size
                    .coerceAtLeast(1)
                    .coerceAtMost(4)
            }
            TaskType.SEARCH -> {
                // Use all available
                topology.totalCores
                    .coerceAtLeast(2)
                    .coerceAtMost(6)
            }
            TaskType.PREFETCH -> {
                // Background — LITTLE cores only
                topology.littleCores.size
                    .coerceAtLeast(1)
                    .coerceAtMost(2)
            }
        }
    }

    /**
     * Set thread affinity to specific cores.
     *
     * Best-effort on Android (requires root for true affinity). Returns false
     * when not supported — caller should fall back to OS scheduling.
     */
    @Suppress("UNUSED_PARAMETER")
    fun setThreadAffinity(threadId: Long, cores: List<Int>): Boolean {
        // Real sched_setaffinity would go here via JNI/Reflection. On Android
        // without root we leave affinity to the kernel and just return false
        // so callers can degrade gracefully.
        return false
    }

    fun getCpuTopology(): CpuTopology = cpuInfo

    data class CpuTopology(
        val bigCores: List<Int>,
        val midCores: List<Int> = emptyList(),
        val littleCores: List<Int> = emptyList(),
        val totalCores: Int,
    )
}

package com.titan.filemanager.data.threading.scheduler

import com.titan.filemanager.data.threading.model.TaskType
import kotlinx.coroutines.Job
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * Task Cancellation Hub.
 *
 * Ported technique: #36 Task cancellation
 *
 * Central place to manage task lifecycle:
 *  - Register tasks
 *  - Cancel by ID
 *  - Cancel by type
 *  - Cancel by path
 *  - Cascade cancellation (parent → children)
 */
class TaskCancellationHub {

    // Active tasks registry
    private val activeTasks = ConcurrentHashMap<String, TaskEntry>()

    // Path → task IDs mapping for path-based cancellation
    private val pathTasks = ConcurrentHashMap<String, MutableSet<String>>()

    // Parent → children mapping for cascade cancellation
    private val childTasks = ConcurrentHashMap<String, MutableSet<String>>()

    // Stats
    private val totalCancelled = AtomicLong(0L)

    /** Register a new task. */
    fun register(
        taskId: String,
        taskType: TaskType,
        job: Job,
        path: String? = null,
        parentTaskId: String? = null,
    ) {
        val entry = TaskEntry(
            id = taskId,
            type = taskType,
            job = job,
            path = path,
            parentId = parentTaskId,
            registeredAt = System.currentTimeMillis(),
        )

        activeTasks[taskId] = entry

        // Register path association
        path?.let { p ->
            pathTasks.getOrPut(p) {
                ConcurrentHashMap.newKeySet()
            }.add(taskId)
        }

        // Register parent-child relationship
        parentTaskId?.let { parentId ->
            childTasks.getOrPut(parentId) {
                ConcurrentHashMap.newKeySet()
            }.add(taskId)
        }
    }

    /** Cancel specific task. Returns true if the task was found and cancelled. */
    fun cancel(taskId: String): Boolean {
        val entry = activeTasks.remove(taskId) ?: return false

        if (entry.job.isActive) {
            entry.job.cancel()
            totalCancelled.incrementAndGet()
        }

        // Cascade: cancel children
        cancelChildren(taskId)

        // Cleanup path association
        entry.path?.let { path ->
            pathTasks[path]?.remove(taskId)
        }

        return true
    }

    /** Cancel all tasks for a path. Called on navigation change. */
    fun cancelByPath(path: String): Int {
        val taskIds = pathTasks[path]?.toList() ?: return 0
        var cancelled = 0

        for (taskId in taskIds) {
            if (cancel(taskId)) cancelled++
        }

        pathTasks.remove(path)
        return cancelled
    }

    /** Cancel all tasks of a specific type. */
    fun cancelByType(taskType: TaskType): Int {
        val toCancel = activeTasks.values
            .filter { it.type == taskType }
            .map { it.id }

        var cancelled = 0
        for (taskId in toCancel) {
            if (cancel(taskId)) cancelled++
        }
        return cancelled
    }

    /** Cancel children of a task (cascade). */
    private fun cancelChildren(parentId: String) {
        val children = childTasks.remove(parentId) ?: return
        children.forEach { childId ->
            cancel(childId)  // Recursive cascade
        }
    }

    /** Mark task completed — removes from registry. */
    fun markCompleted(taskId: String) {
        val entry = activeTasks.remove(taskId) ?: return
        entry.path?.let { path ->
            pathTasks[path]?.remove(taskId)
        }
        childTasks.remove(taskId)
    }

    /** Cancel ALL tasks. Called on app destroy. */
    fun cancelAll(): Int {
        val count = activeTasks.size
        activeTasks.values.forEach { entry ->
            if (entry.job.isActive) {
                entry.job.cancel()
                totalCancelled.incrementAndGet()
            }
        }
        activeTasks.clear()
        pathTasks.clear()
        childTasks.clear()
        return count
    }

    fun getActiveTaskCount(): Int = activeTasks.size

    fun getTotalCancelled(): Long = totalCancelled.get()

    data class TaskEntry(
        val id: String,
        val type: TaskType,
        val job: Job,
        val path: String?,
        val parentId: String?,
        val registeredAt: Long,
    )
}

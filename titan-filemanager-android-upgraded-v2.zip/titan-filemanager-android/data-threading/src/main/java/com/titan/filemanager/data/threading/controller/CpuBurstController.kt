package com.titan.filemanager.data.threading.controller

import android.util.Log
import com.titan.filemanager.data.threading.pool.ScanThreadPool
import com.titan.filemanager.data.threading.pool.ThumbnailThreadPool
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * CPU Burst Controller.
 *
 * Ported technique: #32 CPU burst on folder open
 *
 * When user opens a folder:
 *   1. Immediately max out thread count
 *   2. Run scan at highest priority
 *   3. After scan completes → return to normal
 *
 * Behaves like a phone "unlocking" to full performance for the first few
 * seconds of navigation.
 */
class CpuBurstController(
    private val scanPool: ScanThreadPool,
    private val thumbnailPool: ThumbnailThreadPool,
    private val adaptiveController: AdaptiveThreadController,
) {

    companion object {
        private const val TAG = "CpuBurst"
        private const val BURST_TIMEOUT_MS = 3000L  // Max 3 seconds burst
        private const val COOLDOWN_MS = 1000L       // 1 second cooldown after burst
    }

    private val isBursting = AtomicBoolean(false)
    private val burstStartTime = AtomicLong(0L)
    private var burstJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    /**
     * Trigger burst mode for folder opening. Called immediately when user
     * navigates.
     */
    fun triggerFolderOpenBurst() {
        if (isBursting.getAndSet(true)) {
            // Already bursting — extend timeout
            burstStartTime.set(System.currentTimeMillis())
            return
        }

        Log.d(TAG, "Starting CPU burst")
        burstStartTime.set(System.currentTimeMillis())

        // Enter burst mode in all pools
        scanPool.enterBurstMode()

        // Pause thumbnails during burst (avoid I/O contention)
        thumbnailPool.pause()

        // Schedule burst exit
        burstJob?.cancel()
        burstJob = scope.launch {
            delay(BURST_TIMEOUT_MS)
            exitBurst()
        }
    }

    /**
     * Exit burst when scan completes. Called by scan engine on completion.
     */
    fun onScanCompleted() {
        if (!isBursting.get()) return

        scope.launch {
            // Short cooldown before returning to normal
            delay(COOLDOWN_MS)
            exitBurst()
        }
    }

    private fun exitBurst() {
        if (!isBursting.getAndSet(false)) return

        Log.d(
            TAG,
            "Exiting CPU burst (duration=${System.currentTimeMillis() - burstStartTime.get()}ms)",
        )

        scanPool.exitBurstMode()
        thumbnailPool.resume()

        burstJob?.cancel()
        burstJob = null
    }

    fun isBursting(): Boolean = isBursting.get()

    fun shutdown() {
        scope.cancel()
    }
}

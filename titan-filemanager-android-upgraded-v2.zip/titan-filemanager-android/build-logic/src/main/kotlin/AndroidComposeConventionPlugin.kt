package com.titan.filemanager.buildlogic

import com.android.build.api.dsl.ApplicationExtension
import com.android.build.api.dsl.LibraryExtension
import org.gradle.api.Plugin
import org.gradle.api.Project
import org.gradle.kotlin.dsl.dependencies
import org.gradle.kotlin.dsl.getByType

/**
 * Convention plugin for modules that use Jetpack Compose.
 *
 * Applies:
 *  - org.jetbrains.kotlin.plugin.compose
 *
 * Adds Compose compiler configuration + BOM + core Compose dependencies.
 *
 * Should be applied AFTER `titan.android.application` or `titan.android.library`.
 *
 * Usage:
 *   plugins {
 *       id("titan.android.library")
 *       id("titan.android.compose")
 *   }
 */
class AndroidComposeConventionPlugin : Plugin<Project> {
    override fun apply(target: Project) {
        with(target) {
            pluginManager.apply("org.jetbrains.kotlin.plugin.compose")

            val useBom = libs.findLibrary("androidx-compose-bom").get()
            val material3 = libs.findLibrary("androidx-compose-material3").get()
            val materialIcons =
                libs.findLibrary("androidx-compose-material-icons-extended").get()
            val runtime = libs.findLibrary("androidx-compose-runtime").get()
            val ui = libs.findLibrary("androidx-compose-ui").get()
            val uiGraphics = libs.findLibrary("androidx-compose-ui-graphics").get()
            val uiToolingPreview =
                libs.findLibrary("androidx-compose-ui-tooling-preview").get()
            val uiTooling = libs.findLibrary("androidx-compose-ui-tooling").get()
            val foundation = libs.findLibrary("androidx-compose-foundation").get()
            val lifecycleVm =
                libs.findLibrary("androidx-lifecycle-viewmodel-compose").get()
            val lifecycleRt =
                libs.findLibrary("androidx-lifecycle-runtime-compose").get()
            val activityCompose =
                libs.findLibrary("androidx-activity-compose").get()

            extensions.findByType(ApplicationExtension::class.java)
                ?.apply { configureCompose() }
            extensions.findByType(LibraryExtension::class.java)
                ?.apply { configureCompose() }

            dependencies {
                "implementation"(platform(useBom))
                "implementation"(runtime)
                "implementation"(ui)
                "implementation"(uiGraphics)
                "implementation"(uiToolingPreview)
                "implementation"(foundation)
                "implementation"(material3)
                "implementation"(materialIcons)
                "implementation"(lifecycleVm)
                "implementation"(lifecycleRt)
                "implementation"(activityCompose)

                "debugImplementation"(uiTooling)
            }
        }
    }

    private fun com.android.build.api.dsl.CommonExtension<*, *, *, *, *, *>.configureCompose() {
        buildFeatures {
            compose = true
        }
    }
}

package com.titan.filemanager.buildlogic

import com.android.build.api.dsl.ApplicationExtension
import org.gradle.api.JavaVersion
import org.gradle.api.Plugin
import org.gradle.api.Project
import org.gradle.kotlin.dsl.configure
import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import org.jetbrains.kotlin.gradle.dsl.KotlinAndroidProjectExtension

/**
 * Convention plugin for the main :app module.
 *
 * Applies:
 *  - com.android.application
 *  - org.jetbrains.kotlin.android
 *
 * Configures common Android settings:
 *  - compileSdk = 35, minSdk = 26, targetSdk = 35
 *  - Java 21 + Kotlin JvmTarget 21
 *  - Test instrumentation runner
 *  - Common build types (debug, release)
 *
 * Usage in app/build.gradle.kts:
 *   plugins {
 *       id("titan.android.application")
 *   }
 */
class AndroidApplicationConventionPlugin : Plugin<Project> {
    override fun apply(target: Project) {
        with(target) {
            with(pluginManager) {
                apply("com.android.application")
                apply("org.jetbrains.kotlin.android")
            }

            extensions.configure<ApplicationExtension> {
                compileSdk = 35

                defaultConfig {
                    minSdk = 26
                    targetSdk = 35

                    testInstrumentationRunner =
                        "androidx.test.runner.AndroidJUnitRunner"
                    vectorDrawables.useSupportLibrary = true
                }

                compileOptions {
                    sourceCompatibility = JavaVersion.VERSION_21
                    targetCompatibility = JavaVersion.VERSION_21
                    isCoreLibraryDesugaringEnabled = false
                }

                packaging {
                    resources {
                        excludes += setOf(
                            "/META-INF/{AL2.0,LGPL2.1}",
                            "/META-INF/DEPENDENCIES",
                            "/META-INF/LICENSE*",
                            "/META-INF/NOTICE*",
                            "META-INF/*.kotlin_module",
                        )
                    }
                }

                buildTypes {
                    debug {
                        applicationIdSuffix = ".debug"
                        versionNameSuffix = "-debug"
                        isMinifyEnabled = false
                        isDebuggable = true
                    }
                    release {
                        isMinifyEnabled = true
                        isShrinkResources = true
                        proguardFiles(
                            getDefaultProguardFile("proguard-android-optimize.txt"),
                            "proguard-rules.pro",
                        )
                    }
                }

                testOptions {
                    unitTests {
                        isIncludeAndroidResources = true
                        isReturnDefaultValues = true
                    }
                }
            }

            extensions.configure<KotlinAndroidProjectExtension> {
                compilerOptions {
                    jvmTarget.set(JvmTarget.JVM_21)
                    freeCompilerArgs.addAll(
                        "-Xjsr305=strict",
                        "-Xcontext-receivers",
                        "-opt-in=kotlin.RequiresOptIn",
                    )
                }
            }
        }
    }
}

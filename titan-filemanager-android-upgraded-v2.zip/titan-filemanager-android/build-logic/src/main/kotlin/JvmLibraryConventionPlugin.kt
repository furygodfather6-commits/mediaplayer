package com.titan.filemanager.buildlogic

import org.gradle.api.JavaVersion
import org.gradle.api.Plugin
import org.gradle.api.Project
import org.gradle.api.plugins.JavaPluginExtension
import org.gradle.api.tasks.testing.Test
import org.gradle.kotlin.dsl.configure
import org.gradle.kotlin.dsl.dependencies
import org.gradle.kotlin.dsl.withType
import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import org.jetbrains.kotlin.gradle.dsl.KotlinJvmProjectExtension

/**
 * Convention plugin for pure-Kotlin modules (no Android).
 *
 * Used by:
 *  - :core:model
 *  - :domain
 *
 * Applies:
 *  - org.jetbrains.kotlin.jvm
 *
 * Usage:
 *   plugins {
 *       id("titan.jvm.library")
 *   }
 */
class JvmLibraryConventionPlugin : Plugin<Project> {
    override fun apply(target: Project) {
        with(target) {
            pluginManager.apply("org.jetbrains.kotlin.jvm")

            extensions.configure<JavaPluginExtension> {
                sourceCompatibility = JavaVersion.VERSION_21
                targetCompatibility = JavaVersion.VERSION_21
            }

            extensions.configure<KotlinJvmProjectExtension> {
                compilerOptions {
                    jvmTarget.set(JvmTarget.JVM_21)
                    freeCompilerArgs.addAll(
                        "-Xjsr305=strict",
                        "-Xcontext-receivers",
                        "-opt-in=kotlin.RequiresOptIn",
                    )
                }
            }

            val coroutinesCore =
                libs.findLibrary("kotlinx-coroutines-core").get()
            val coroutinesTest =
                libs.findLibrary("kotlinx-coroutines-test").get()
            val timber = libs.findLibrary("timber").get()

            dependencies {
                "implementation"(coroutinesCore)
                "implementation"(timber)

                "testImplementation"(coroutinesTest)
            }

            // Configure JUnit 5 as the default test platform
            tasks.withType<Test> {
                useJUnitPlatform()
                testLogging {
                    events("passed", "skipped", "failed")
                }
            }
        }
    }
}

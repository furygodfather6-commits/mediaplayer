package com.titan.filemanager.buildlogic

import org.gradle.api.Project
import org.gradle.api.artifacts.MinimalExternalModuleDependency
import org.gradle.api.artifacts.VersionCatalog
import org.gradle.api.artifacts.VersionCatalogsExtension
import org.gradle.api.provider.Provider
import org.gradle.kotlin.dsl.getByType

/**
 * Accessor for the version catalog named "libs" declared in
 * build-logic/settings.gradle.kts.
 *
 * In precompiled script plugins the `libs` accessor is auto-generated,
 * but for hand-written `Plugin<Project>` convention plugins we have to
 * resolve the catalog manually. This top-level `val` lets every
 * convention plugin in this package write `libs.findLibrary("...")`
 * exactly as the precompiled-script form would.
 */
internal val Project.libs: VersionCatalog
    get() = extensions.getByType<VersionCatalogsExtension>().named("libs")

/**
 * Convenience: look up a library alias and return the dependency provider.
 */
internal fun Project.library(alias: String): Provider<MinimalExternalModuleDependency> =
    libs.findLibrary(alias).orElseThrow {
        IllegalStateException("Library alias '$alias' not found in version catalog 'libs'")
    }

package com.titan.filemanager.buildlogic

import org.gradle.api.Plugin
import org.gradle.api.Project
import org.gradle.kotlin.dsl.dependencies

/**
 * Convention plugin for modules that use Hilt for dependency injection.
 *
 * Applies:
 *  - com.google.devtools.ksp
 *  - com.google.dagger.hilt.android
 *
 * Adds Hilt runtime + KSP annotation processor.
 *
 * Usage:
 *   plugins {
 *       id("titan.android.library")
 *       id("titan.android.hilt")
 *   }
 */
class AndroidHiltConventionPlugin : Plugin<Project> {
    override fun apply(target: Project) {
        with(target) {
            with(pluginManager) {
                apply("com.google.devtools.ksp")
                apply("com.google.dagger.hilt.android")
            }

            val hiltAndroid = libs.findLibrary("hilt-android").get()
            val hiltCompiler = libs.findLibrary("hilt-compiler").get()
            val hiltNavigationCompose =
                libs.findLibrary("androidx-hilt-navigation-compose").get()
            val hiltWork = libs.findLibrary("androidx-hilt-work").get()
            val hiltCompilerAndroidX = libs.findLibrary("androidx-hilt-compiler").get()

            dependencies {
                "implementation"(hiltAndroid)
                "implementation"(hiltNavigationCompose)
                "implementation"(hiltWork)
                "ksp"(hiltCompiler)
                "ksp"(hiltCompilerAndroidX)
            }
        }
    }
}

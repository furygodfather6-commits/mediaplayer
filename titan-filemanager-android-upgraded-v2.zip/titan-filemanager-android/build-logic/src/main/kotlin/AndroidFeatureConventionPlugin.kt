package com.titan.filemanager.buildlogic

import org.gradle.api.Plugin
import org.gradle.api.Project
import org.gradle.kotlin.dsl.dependencies

/**
 * Convention plugin for Compose feature modules.
 *
 * Composes:
 *  - titan.android.library          (Android library setup)
 *  - titan.android.compose          (Compose + Material 3)
 *  - titan.android.hilt             (Hilt + KSP)
 *
 * Adds standard feature-module dependencies:
 *  - :core:common, :core:model, :core:designsystem, :core:ui
 *  - :core:navigation, :domain
 *  - Coroutines, Navigation Compose
 *
 * Usage:
 *   plugins {
 *       id("titan.android.feature")
 *   }
 */
class AndroidFeatureConventionPlugin : Plugin<Project> {
    override fun apply(target: Project) {
        with(target) {
            with(pluginManager) {
                apply("titan.android.library")
                apply("titan.android.compose")
                apply("titan.android.hilt")
            }

            val coroutinesCore =
                libs.findLibrary("kotlinx-coroutines-core").get()
            val coroutinesAndroid =
                libs.findLibrary("kotlinx-coroutines-android").get()
            val navigationCompose =
                libs.findLibrary("androidx-navigation-compose").get()
            val timber = libs.findLibrary("timber").get()

            dependencies {
                // Core module deps
                "implementation"(project(":core:common"))
                "implementation"(project(":core:model"))
                "implementation"(project(":core:designsystem"))
                "implementation"(project(":core:ui"))
                "implementation"(project(":core:navigation"))

                // Async
                "implementation"(coroutinesCore)
                "implementation"(coroutinesAndroid)

                // Navigation
                "implementation"(navigationCompose)

                // Logging
                "implementation"(timber)
            }
        }
    }
}

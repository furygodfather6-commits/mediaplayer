// build-logic build file — Kotlin Gradle plugin for convention plugins
plugins {
    `kotlin-dsl`
}

group = "com.titan.filemanager.buildlogic"

java {
    sourceCompatibility = JavaVersion.VERSION_21
    targetCompatibility = JavaVersion.VERSION_21
}

kotlin {
    jvmToolchain(21)
}

dependencies {
    compileOnly(libs.android.gradle.plugin)
    compileOnly(libs.kotlin.gradle.plugin)
    compileOnly(libs.ksp.gradle.plugin)
}

// Register convention plugins with friendly IDs (e.g. `titan.android.application`)
gradlePlugin {
    plugins {
        register("androidApplication") {
            id = "titan.android.application"
            implementationClass = "com.titan.filemanager.buildlogic.AndroidApplicationConventionPlugin"
        }
        register("androidLibrary") {
            id = "titan.android.library"
            implementationClass = "com.titan.filemanager.buildlogic.AndroidLibraryConventionPlugin"
        }
        register("androidCompose") {
            id = "titan.android.compose"
            implementationClass = "com.titan.filemanager.buildlogic.AndroidComposeConventionPlugin"
        }
        register("androidHilt") {
            id = "titan.android.hilt"
            implementationClass = "com.titan.filemanager.buildlogic.AndroidHiltConventionPlugin"
        }
        register("androidFeature") {
            id = "titan.android.feature"
            implementationClass = "com.titan.filemanager.buildlogic.AndroidFeatureConventionPlugin"
        }
        register("jvmLibrary") {
            id = "titan.jvm.library"
            implementationClass = "com.titan.filemanager.buildlogic.JvmLibraryConventionPlugin"
        }
    }
}

tasks {
    validatePlugins {
        enableStricterValidation = true
        failOnWarning = true
    }
}

package com.titan.filemanager.data.monitor.model

data class MetricPoint(
    val name: String,
    val value: Double,
    val unit: MetricUnit,
    val timestamp: Long = System.currentTimeMillis(),
    val tags: Map<String, String> = emptyMap(),
) {
    enum class MetricUnit { MILLISECONDS, MICROSECONDS, NANOSECONDS, BYTES, MEGABYTES, PERCENT, COUNT, PER_SECOND, RATIO }
}

data class PerformanceSnapshot(
    val timestamp: Long = System.currentTimeMillis(),
    val avgScanTimeMs: Long = 0, val maxScanTimeMs: Long = 0, val totalScans: Long = 0,
    val avgIOLatencyMs: Long = 0, val totalIOOps: Long = 0,
    val cacheHitRate: Float = 0f, val l1HitRate: Float = 0f, val l2HitRate: Float = 0f,
    val gcCount: Int = 0, val gcPauseMs: Long = 0, val gcFrequencyPerMin: Float = 0f,
    val avgFps: Float = 0f, val droppedFrames: Int = 0, val jankyFrameRate: Float = 0f,
    val heapUsedMB: Int = 0, val heapMaxMB: Int = 0, val nativeHeapMB: Int = 0, val heapUtilization: Float = 0f,
    val cpuUsagePercent: Float = 0f, val cpuFreqMHz: Int = 0, val thermalThrottling: Boolean = false,
)

data class PerformanceAlert(
    val id: String, val severity: Severity, val category: AlertCategory,
    val message: String, val value: Double, val threshold: Double,
    val timestamp: Long = System.currentTimeMillis(),
    val suggestedAction: String = "", var isResolved: Boolean = false,
) {
    enum class Severity { INFO, WARNING, CRITICAL }
    enum class AlertCategory { SCAN_SLOW, IO_LATENCY_HIGH, CACHE_HIT_LOW, GC_EXCESSIVE, FRAME_DROP, MEMORY_HIGH, CPU_HIGH, THERMAL_THROTTLE }
}

data class TuningAction(
    val parameter: String, val oldValue: String, val newValue: String,
    val reason: String, val expectedImprovement: String,
    val timestamp: Long = System.currentTimeMillis(), val appliedSuccessfully: Boolean = false,
)

data class PerformanceReport(
    val generatedAt: Long = System.currentTimeMillis(),
    val snapshot: PerformanceSnapshot,
    val activeAlerts: List<PerformanceAlert>,
    val recentTuningActions: List<TuningAction>,
    val slowFolders: List<SlowFolderInfo>,
    val recommendations: List<String>,
    val overallScore: Int,
) {
    val isHealthy: Boolean get() = overallScore >= 70
    val needsAttention: Boolean get() = overallScore in 40..69
    val isCritical: Boolean get() = overallScore < 40
}

data class SlowFolderInfo(
    val path: String, val avgScanMs: Long, val scanCount: Int, val itemCount: Int, val reason: String,
)

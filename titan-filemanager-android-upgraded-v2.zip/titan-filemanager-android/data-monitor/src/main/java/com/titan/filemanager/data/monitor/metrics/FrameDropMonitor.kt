package com.titan.filemanager.data.monitor.metrics

import android.view.Choreographer
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * Frame Drop Monitor — FPS + dropped/janky/frozen frame tracking via Choreographer.
 *
 * Technique #137: Frame-drop monitoring
 */
class FrameDropMonitor {

    companion object { private const val FRAME_BUDGET_MS = 16L; private const val JANKY_THRESHOLD_MS = 33L; private const val FROZEN_THRESHOLD_MS = 700L; private const val TARGET_FPS = 60f }

    private val choreographer = Choreographer.getInstance()
    private var lastFrameTimeNs = 0L
    private val frameCount = AtomicInteger(0)
    private val droppedFrames = AtomicInteger(0)
    private val jankyFrames = AtomicInteger(0)
    private val frozenFrames = AtomicInteger(0)
    private val peakFrameTimeMs = AtomicLong(0)
    private val recentFrameTimes = ArrayDeque<Long>(120)
    private val frameLock = Any()
    @Volatile private var currentFps = 0f
    @Volatile private var isMonitoring = false

    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!isMonitoring) return
            processFrame(frameTimeNanos)
            choreographer.postFrameCallback(this)
        }
    }

    fun startMonitoring() { if (isMonitoring) return; isMonitoring = true; lastFrameTimeNs = System.nanoTime(); choreographer.postFrameCallback(frameCallback) }
    fun stopMonitoring() { isMonitoring = false; choreographer.removeFrameCallback(frameCallback) }

    private fun processFrame(frameTimeNs: Long) {
        if (lastFrameTimeNs == 0L) { lastFrameTimeNs = frameTimeNs; return }
        val frameDurationMs = (frameTimeNs - lastFrameTimeNs) / 1_000_000L; lastFrameTimeNs = frameTimeNs
        if (frameDurationMs <= 0) return
        frameCount.incrementAndGet()
        when { frameDurationMs > FROZEN_THRESHOLD_MS -> { frozenFrames.incrementAndGet(); droppedFrames.incrementAndGet(); jankyFrames.incrementAndGet() }
               frameDurationMs > JANKY_THRESHOLD_MS -> { jankyFrames.incrementAndGet(); droppedFrames.incrementAndGet() }
               frameDurationMs > FRAME_BUDGET_MS -> { droppedFrames.incrementAndGet() } }
        var current = peakFrameTimeMs.get(); while (frameDurationMs > current) { if (peakFrameTimeMs.compareAndSet(current, frameDurationMs)) break; current = peakFrameTimeMs.get() }
        synchronized(frameLock) { recentFrameTimes.addLast(frameTimeNs / 1_000_000L); val cutoff = System.currentTimeMillis() - 1000L; while (recentFrameTimes.isNotEmpty() && recentFrameTimes.first() < cutoff) recentFrameTimes.removeFirst(); currentFps = recentFrameTimes.size.toFloat() }
    }

    fun getCurrentFPS(): Float = currentFps
    fun getDropRate(): Float = if (frameCount.get() > 0) droppedFrames.get().toFloat() / frameCount.get() else 0f
    fun getJankyRate(): Float = if (frameCount.get() > 0) jankyFrames.get().toFloat() / frameCount.get() else 0f
    fun isUISmooth(): Boolean = currentFps >= TARGET_FPS * 0.9f && getDropRate() < 0.05f

    fun getSummary() = FrameSummary(currentFps, frameCount.get(), droppedFrames.get(), jankyFrames.get(), frozenFrames.get(), getDropRate(), getJankyRate(), peakFrameTimeMs.get(), isUISmooth())

    data class FrameSummary(val currentFps: Float, val totalFrames: Int, val droppedFrames: Int, val jankyFrames: Int, val frozenFrames: Int, val dropRate: Float, val jankyRate: Float, val peakFrameTimeMs: Long, val isSmooth: Boolean)
}

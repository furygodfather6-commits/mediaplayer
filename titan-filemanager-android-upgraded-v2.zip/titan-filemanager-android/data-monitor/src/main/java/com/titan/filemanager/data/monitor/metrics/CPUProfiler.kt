package com.titan.filemanager.data.monitor.metrics

import kotlinx.coroutines.*
import java.io.File
import java.util.concurrent.atomic.AtomicLong

/**
 * CPU Profiler — /proc/stat + sysfs CPU frequency + thermal throttling detection.
 *
 * Technique #139: CPU profiling
 */
class CPUProfiler(private val scope: CoroutineScope) {

    companion object { private const val SAMPLE_INTERVAL_MS = 2000L; private const val THERMAL_THROTTLE_THRESHOLD = 0.70f }

    private val cpuSamples = ArrayDeque<CPUSample>(60)
    private val samplesLock = Any()
    private val peakCpuPercent = AtomicLong(0)
    private var prevTotalTime = 0L; private var prevIdleTime = 0L
    @Volatile private var isProfiling = false
    private var profileJob: Job? = null

    data class CPUSample(val timestamp: Long, val cpuUsagePercent: Float, val userPercent: Float, val systemPercent: Float, val iowaitPercent: Float, val cpuFreqMHz: Int, val maxFreqMHz: Int, val isThrottled: Boolean, val coreCount: Int)

    fun startProfiling() { if (isProfiling) return; isProfiling = true; profileJob = scope.launch(Dispatchers.IO) { while (isActive && isProfiling) { val s = takeSample(); synchronized(samplesLock) { cpuSamples.addLast(s); if (cpuSamples.size > 60) cpuSamples.removeFirst() }; delay(SAMPLE_INTERVAL_MS) } } }
    fun stopProfiling() { isProfiling = false; profileJob?.cancel() }

    fun takeSample(): CPUSample {
        val (totalTime, idleTime, userTime, systemTime, iowait) = readProcStat()
        val timeDelta = totalTime - prevTotalTime; val idleDelta = idleTime - prevIdleTime
        val cpuUsage = if (timeDelta > 0) (1f - idleDelta.toFloat() / timeDelta) * 100f else 0f
        val userPct = if (timeDelta > 0) (userTime.toFloat() / timeDelta) * 100f else 0f
        val systemPct = if (timeDelta > 0) (systemTime.toFloat() / timeDelta) * 100f else 0f
        val iowaitPct = if (timeDelta > 0) (iowait.toFloat() / timeDelta) * 100f else 0f
        prevTotalTime = totalTime; prevIdleTime = idleTime
        var current = peakCpuPercent.get(); val cpuLong = cpuUsage.toLong()
        while (cpuLong > current) { if (peakCpuPercent.compareAndSet(current, cpuLong)) break; current = peakCpuPercent.get() }
        val curFreq = readCurrentCPUFreq(); val maxFreq = readMaxCPUFreq()
        val isThrottled = maxFreq > 0 && (curFreq.toFloat() / maxFreq) < THERMAL_THROTTLE_THRESHOLD
        return CPUSample(System.currentTimeMillis(), cpuUsage.coerceIn(0f, 100f), userPct, systemPct, iowaitPct, curFreq / 1000, maxFreq / 1000, isThrottled, Runtime.getRuntime().availableProcessors())
    }

    fun isThermallyThrottled(): Boolean = synchronized(samplesLock) { cpuSamples.takeLast(3).count { it.isThrottled } >= 2 }
    fun getCurrentUsage(): Float = synchronized(samplesLock) { cpuSamples.lastOrNull()?.cpuUsagePercent ?: 0f }

    private fun readProcStat(): LongArray = try {
        val parts = File("/proc/stat").readLines().firstOrNull()?.split("\\s+".toRegex())?.drop(1) ?: return LongArray(5)
        if (parts.size < 5) LongArray(5) else {
            val user = parts[0].toLongOrNull() ?: 0L; val nice = parts[1].toLongOrNull() ?: 0L
            val system = parts[2].toLongOrNull() ?: 0L; val idle = parts[3].toLongOrNull() ?: 0L; val iowait = parts[4].toLongOrNull() ?: 0L
            longArrayOf(user + nice + system + idle + iowait, idle, user, system, iowait)
        }
    } catch (_: Exception) { LongArray(5) }

    private fun readCurrentCPUFreq(): Int = try { File("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq").readText().trim().toIntOrNull() ?: 0 } catch (_: Exception) { 0 }
    private fun readMaxCPUFreq(): Int = try { File("/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq").readText().trim().toIntOrNull() ?: 0 } catch (_: Exception) { 0 }

    private fun <T> ArrayDeque<T>.takeLast(n: Int): List<T> = if (size <= n) toList() else toList().takeLast(n)
}

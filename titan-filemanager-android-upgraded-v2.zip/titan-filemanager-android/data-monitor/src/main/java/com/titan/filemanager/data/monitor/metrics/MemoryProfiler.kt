package com.titan.filemanager.data.monitor.metrics

import android.app.ActivityManager
import android.content.Context
import android.os.Debug
import kotlinx.coroutines.*
import java.util.concurrent.atomic.AtomicLong

/**
 * Memory Profiler — heap + native heap + leak detection.
 *
 * Technique #138: Memory profiling
 */
class MemoryProfiler(private val context: Context, private val scope: CoroutineScope) {

    companion object { private const val SAMPLE_INTERVAL_MS = 5000L; private const val MAX_SAMPLES = 100; private const val LEAK_THRESHOLD = 0.1f }

    private val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private val samples = ArrayDeque<MemorySample>(MAX_SAMPLES)
    private val samplesLock = Any()
    private val peakHeapMB = AtomicLong(0)
    @Volatile private var isProfiling = false
    private var profileJob: Job? = null

    data class MemorySample(val timestamp: Long, val heapUsedMB: Int, val heapTotalMB: Int, val heapMaxMB: Int, val nativeHeapMB: Int, val systemAvailableMB: Long, val isLowMemory: Boolean, val heapUtilization: Float)

    fun startProfiling() { if (isProfiling) return; isProfiling = true; profileJob = scope.launch(Dispatchers.Default) { while (isActive && isProfiling) { val s = takeSample(); addSample(s); delay(SAMPLE_INTERVAL_MS) } } }
    fun stopProfiling() { isProfiling = false; profileJob?.cancel() }

    fun takeSample(): MemorySample {
        val runtime = Runtime.getRuntime(); val memInfo = ActivityManager.MemoryInfo(); activityManager.getMemoryInfo(memInfo)
        val heapUsed = (runtime.totalMemory() - runtime.freeMemory()) / 1024 / 1024; val heapMax = runtime.maxMemory() / 1024 / 1024; val nativeHeap = Debug.getNativeHeapAllocatedSize() / 1024 / 1024
        var current = peakHeapMB.get(); while (heapUsed > current) { if (peakHeapMB.compareAndSet(current, heapUsed)) break; current = peakHeapMB.get() }
        return MemorySample(System.currentTimeMillis(), heapUsed.toInt(), (runtime.totalMemory() / 1024 / 1024).toInt(), heapMax.toInt(), nativeHeap.toInt(), memInfo.availMem / 1024 / 1024, memInfo.lowMemory, heapUsed.toFloat() / heapMax)
    }

    fun detectMemoryLeak(): MemoryLeakReport {
        val history = synchronized(samplesLock) { samples.toList() }
        if (history.size < 10) return MemoryLeakReport(false, 0f, "Not enough data")
        val firstAvg = history.take(history.size / 2).map { it.heapUsedMB }.average().toFloat()
        val secondAvg = history.drop(history.size / 2).map { it.heapUsedMB }.average().toFloat()
        val growthRate = if (firstAvg > 0) (secondAvg - firstAvg) / firstAvg else 0f
        return MemoryLeakReport(growthRate > LEAK_THRESHOLD, growthRate, if (growthRate > LEAK_THRESHOLD) "Heap growing ${"%.1f".format(growthRate * 100)}%. Possible leak." else "Heap stable.")
    }

    private fun addSample(sample: MemorySample) { synchronized(samplesLock) { samples.addLast(sample); if (samples.size > MAX_SAMPLES) samples.removeFirst() } }

    data class MemoryLeakReport(val isPotentialLeak: Boolean, val growthRate: Float, val description: String)
}

package com.titan.filemanager.data.monitor.engine

import android.content.Context
import com.titan.filemanager.data.monitor.alert.AlertSystem
import com.titan.filemanager.data.monitor.alert.AlertThresholds
import com.titan.filemanager.data.monitor.dashboard.PerformanceDashboard
import com.titan.filemanager.data.monitor.detection.SlowFolderDetector
import com.titan.filemanager.data.monitor.metrics.*
import com.titan.filemanager.data.monitor.model.PerformanceAlert
import com.titan.filemanager.data.monitor.model.PerformanceReport
import com.titan.filemanager.data.monitor.model.PerformanceSnapshot
import com.titan.filemanager.data.monitor.tuning.AutoTuner
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.StateFlow
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Master Performance Monitor Engine — single entry point for all Phase O features.
 *
 * #133 Scan metrics → ScanMetricsCollector
 * #134 I/O latency → IOLatencyTracker
 * #135 Cache hit → CacheHitTracker
 * #136 GC monitor → GCMonitor
 * #137 Frame drop → FrameDropMonitor
 * #138 Memory profiling → MemoryProfiler
 * #139 CPU profiling → CPUProfiler
 * #140 Slow folder → SlowFolderDetector
 * #141 Auto tuning → AutoTuner
 */
@Singleton
class PerformanceMonitorEngine @Inject constructor(context: Context) {

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    val scanMetrics = ScanMetricsCollector()
    val ioTracker = IOLatencyTracker()
    val cacheTracker = CacheHitTracker()
    val gcMonitor = GCMonitor(scope)
    val frameMonitor = FrameDropMonitor()
    val memoryProfiler = MemoryProfiler(context, scope)
    val cpuProfiler = CPUProfiler(scope)
    val alertSystem = AlertSystem(AlertThresholds())
    val slowFolderDetector = SlowFolderDetector(scanMetrics)
    val autoTuner = AutoTuner(scanMetrics, ioTracker, cacheTracker, gcMonitor, frameMonitor, memoryProfiler, cpuProfiler, scope)
    val dashboard = PerformanceDashboard(scanMetrics, ioTracker, cacheTracker, gcMonitor, frameMonitor, memoryProfiler, cpuProfiler, scope)

    val performanceSnapshot: StateFlow<PerformanceSnapshot> get() = dashboard.snapshotFlow

    fun initialize() {
        gcMonitor.startMonitoring(); frameMonitor.startMonitoring(); memoryProfiler.startProfiling()
        cpuProfiler.startProfiling(); dashboard.startDashboard(); autoTuner.startAutoTuning()
        Timber.i("Performance monitoring started")
    }

    fun destroy() {
        gcMonitor.stopMonitoring(); frameMonitor.stopMonitoring(); memoryProfiler.stopProfiling()
        cpuProfiler.stopProfiling(); dashboard.stopDashboard(); autoTuner.stopAutoTuning()
    }

    fun recordScan(path: String, durationMs: Long, itemCount: Int, fromCache: Boolean, strategy: String = "AUTO") {
        scanMetrics.recordScan(ScanMetricsCollector.ScanRecord(path, durationMs, itemCount, fromCache, false, strategy, emptyMap()))
        if (durationMs > 2000) alertSystem.checkMetric(
            PerformanceAlert.AlertCategory.SCAN_SLOW, durationMs.toDouble(), 2000.0,
            "Slow scan: $path took ${durationMs}ms", PerformanceAlert.Severity.WARNING,
            "Consider native scanner or more threads",
        )
    }

    fun recordIO(operation: IOLatencyTracker.IOOperationType, path: String, latencyNs: Long) = ioTracker.record(operation, path, latencyNs)

    inline fun <R> measureIO(operation: IOLatencyTracker.IOOperationType, path: String = "", block: () -> R): R = ioTracker.measure(operation, path, block)

    fun recordCacheHit(type: CacheHitTracker.CacheType) = cacheTracker.recordHit(type)
    fun recordCacheMiss(type: CacheHitTracker.CacheType) = cacheTracker.recordMiss(type)

    fun generateReport(): PerformanceReport = dashboard.generateReport(
        slowFolders = scanMetrics.detectSlowFolders(),
        tuningActions = autoTuner.getTuningHistory(),
        alerts = alertSystem.getActiveAlerts(),
    )

    fun printDashboard() = dashboard.printDashboard()
    fun getCurrentTuningParams(): AutoTuner.TuningParameters = autoTuner.getCurrentParameters()
}

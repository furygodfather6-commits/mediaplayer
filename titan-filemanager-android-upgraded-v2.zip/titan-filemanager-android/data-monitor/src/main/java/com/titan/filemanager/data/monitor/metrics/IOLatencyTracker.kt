package com.titan.filemanager.data.monitor.metrics

import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * I/O Latency Tracker — P50/P95/P99 percentile latency per operation type.
 *
 * Technique #134: I/O latency tracking
 */
class IOLatencyTracker {

    companion object { private const val MAX_SAMPLES = 10_000; private const val HIGH_LATENCY_MS = 50L }

    private val latencySamples = ConcurrentHashMap<IOOperationType, CircularBuffer>()
    private val totalOps = AtomicLong(0)
    private val totalLatencyNs = AtomicLong(0)
    private val highLatencyCount = AtomicLong(0)
    private val highLatencyEvents = ArrayDeque<HighLatencyEvent>(100)
    private val highLatencyLock = Any()

    enum class IOOperationType { STAT, DIR_LIST, FILE_READ, MIME_DETECT, PATH_RESOLVE, CHECKSUM, THUMBNAIL_DECODE, DB_QUERY, DB_WRITE }

    data class HighLatencyEvent(val operation: IOOperationType, val path: String, val latencyMs: Long, val timestamp: Long = System.currentTimeMillis())

    fun record(operation: IOOperationType, path: String, latencyNs: Long) {
        totalOps.incrementAndGet(); totalLatencyNs.addAndGet(latencyNs)
        val latencyMs = latencyNs / 1_000_000L
        getBuffer(operation).add(latencyMs)
        if (latencyMs > HIGH_LATENCY_MS) {
            highLatencyCount.incrementAndGet()
            synchronized(highLatencyLock) { highLatencyEvents.addLast(HighLatencyEvent(operation, path, latencyMs)); if (highLatencyEvents.size > 100) highLatencyEvents.removeFirst() }
        }
    }

    inline fun <R> measure(operation: IOOperationType, path: String = "", block: () -> R): R {
        val startNs = System.nanoTime(); val result = block(); record(operation, path, System.nanoTime() - startNs); return result
    }

    fun getPercentile(operation: IOOperationType, percentile: Int): Long = latencySamples[operation]?.getPercentile(percentile) ?: -1L

    fun getLatencyStats(operation: IOOperationType): LatencyStats {
        val buffer = getBuffer(operation)
        return LatencyStats(operation, buffer.size(), buffer.getPercentile(50), buffer.getPercentile(95), buffer.getPercentile(99), buffer.getMax(), buffer.getMin(), buffer.getAverage())
    }

    fun getAllStats(): Map<IOOperationType, LatencyStats> = IOOperationType.values().associateWith { getLatencyStats(it) }

    private fun getBuffer(op: IOOperationType): CircularBuffer = latencySamples.getOrPut(op) { CircularBuffer(MAX_SAMPLES) }

    data class LatencyStats(val operation: IOOperationType, val sampleCount: Int, val p50Ms: Long, val p95Ms: Long, val p99Ms: Long, val maxMs: Long, val minMs: Long, val avgMs: Long)

    class CircularBuffer(private val capacity: Int) {
        private val data = LongArray(capacity); private var writePos = 0; private var count = 0; private val lock = Any()
        fun add(value: Long) { synchronized(lock) { data[writePos % capacity] = value; writePos++; if (count < capacity) count++ } }
        fun getPercentile(p: Int): Long = synchronized(lock) { if (count == 0) -1L else { val sorted = data.copyOf(count).sorted(); val index = ((p / 100.0) * (sorted.size - 1)).toInt().coerceIn(0, sorted.size - 1); sorted[index] } }
        fun getMax(): Long = synchronized(lock) { if (count == 0) -1L else data.copyOf(count).max() }
        fun getMin(): Long = synchronized(lock) { if (count == 0) -1L else data.copyOf(count).min() }
        fun getAverage(): Long = synchronized(lock) { if (count == 0) -1L else data.copyOf(count).average().toLong() }
        fun size(): Int = synchronized(lock) { count }
    }
}

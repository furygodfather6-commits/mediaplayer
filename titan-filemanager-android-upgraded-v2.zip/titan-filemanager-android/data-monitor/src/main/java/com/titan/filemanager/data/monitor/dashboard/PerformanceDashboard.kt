package com.titan.filemanager.data.monitor.dashboard

import com.titan.filemanager.data.monitor.metrics.*
import com.titan.filemanager.data.monitor.model.PerformanceAlert
import com.titan.filemanager.data.monitor.model.PerformanceReport
import com.titan.filemanager.data.monitor.model.PerformanceSnapshot
import com.titan.filemanager.data.monitor.model.SlowFolderInfo
import com.titan.filemanager.data.monitor.model.TuningAction
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import timber.log.Timber

/**
 * Real-time Performance Dashboard — aggregates all metrics into a reactive stream.
 *
 * Technique #133-141: All monitoring techniques aggregated
 */
class PerformanceDashboard(
    private val scanMetrics: ScanMetricsCollector,
    private val ioTracker: IOLatencyTracker,
    private val cacheTracker: CacheHitTracker,
    private val gcMonitor: GCMonitor,
    private val frameMonitor: FrameDropMonitor,
    private val memoryProfiler: MemoryProfiler,
    private val cpuProfiler: CPUProfiler,
    private val scope: CoroutineScope,
) {
    companion object { private const val REFRESH_INTERVAL_MS = 2000L }

    private val _snapshotFlow = MutableStateFlow(PerformanceSnapshot())
    val snapshotFlow: StateFlow<PerformanceSnapshot> = _snapshotFlow.asStateFlow()
    private var dashboardJob: Job? = null

    fun startDashboard() {
        dashboardJob = scope.launch(Dispatchers.Default) {
            while (isActive) { _snapshotFlow.value = collectSnapshot(); delay(REFRESH_INTERVAL_MS) }
        }
    }

    fun stopDashboard() { dashboardJob?.cancel() }

    fun collectSnapshot(): PerformanceSnapshot {
        val scan = scanMetrics.getSummary(); val gc = gcMonitor.getSummary()
        val frame = frameMonitor.getSummary(); val mem = memoryProfiler.takeSample(); val cpu = cpuProfiler.takeSample()
        return PerformanceSnapshot(
            avgScanTimeMs = scan.avgScanTimeMs, maxScanTimeMs = scan.peakScanTimeMs, totalScans = scan.totalScans,
            avgIOLatencyMs = ioTracker.getLatencyStats(IOLatencyTracker.IOOperationType.STAT).avgMs,
            cacheHitRate = cacheTracker.getOverallHitRate(), l1HitRate = cacheTracker.getHitRate(CacheHitTracker.CacheType.L1_HOT_RAM), l2HitRate = cacheTracker.getHitRate(CacheHitTracker.CacheType.L2_WARM_RAM),
            gcCount = gc.totalGCCount, gcPauseMs = gc.avgPauseMs, gcFrequencyPerMin = gc.gcPerMinute,
            avgFps = frame.currentFps, droppedFrames = frame.droppedFrames, jankyFrameRate = frame.jankyRate,
            heapUsedMB = mem.heapUsedMB, heapMaxMB = mem.heapMaxMB, nativeHeapMB = mem.nativeHeapMB, heapUtilization = mem.heapUtilization,
            cpuUsagePercent = cpu.cpuUsagePercent, cpuFreqMHz = cpu.cpuFreqMHz, thermalThrottling = cpu.isThrottled,
        )
    }

    fun generateReport(slowFolders: List<SlowFolderInfo>, tuningActions: List<TuningAction>, alerts: List<PerformanceAlert>): PerformanceReport {
        val snapshot = collectSnapshot(); val score = computeScore(snapshot); val recs = generateRecommendations(snapshot)
        return PerformanceReport(
            snapshot = snapshot,
            activeAlerts = alerts,
            recentTuningActions = tuningActions.take(10),
            slowFolders = slowFolders.take(10),
            recommendations = recs,
            overallScore = score,
        )
    }

    private fun computeScore(s: PerformanceSnapshot): Int {
        var score = 100
        if (s.avgScanTimeMs > 2000) score -= 20 else if (s.avgScanTimeMs > 1000) score -= 10
        if (s.cacheHitRate < 0.5f) score -= 15 else if (s.cacheHitRate < 0.7f) score -= 5
        if (s.gcFrequencyPerMin > 8) score -= 20 else if (s.gcFrequencyPerMin > 4) score -= 10
        if (s.jankyFrameRate > 0.2f) score -= 20 else if (s.jankyFrameRate > 0.1f) score -= 10
        if (s.heapUtilization > 0.9f) score -= 15 else if (s.heapUtilization > 0.8f) score -= 5
        if (s.thermalThrottling) score -= 10
        if (s.cpuUsagePercent > 80f) score -= 10
        return score.coerceIn(0, 100)
    }

    private fun generateRecommendations(s: PerformanceSnapshot): List<String> {
        val recs = mutableListOf<String>()
        if (s.avgScanTimeMs > 1000) recs.add("Scan time high (${s.avgScanTimeMs}ms). Increase threads or use native walker.")
        if (s.cacheHitRate < 0.6f) recs.add("Cache hit rate low (${"%.0f".format(s.cacheHitRate * 100)}%). Increase cache sizes.")
        if (s.gcFrequencyPerMin > 4) recs.add("High GC (${"%.1f".format(s.gcFrequencyPerMin)}/min). Enable object pooling.")
        if (s.jankyFrameRate > 0.05f) recs.add("Janky frames (${"%.0f".format(s.jankyFrameRate * 100)}%). Move heavy ops off UI thread.")
        if (s.heapUtilization > 0.8f) recs.add("High memory (${"%.0f".format(s.heapUtilization * 100)}%). Clear caches.")
        if (s.thermalThrottling) recs.add("Thermal throttling. Reduce thread count.")
        if (recs.isEmpty()) recs.add("All metrics healthy. Performance score: excellent!")
        return recs
    }

    fun printDashboard() {
        val s = collectSnapshot()
        Timber.d("━━━ Perf Dashboard ━━━\n" +
            "Scan: avg=${s.avgScanTimeMs}ms cache=${"%.0f".format(s.cacheHitRate * 100)}%\n" +
            "GC: ${"%.1f".format(s.gcFrequencyPerMin)}/min pause=${s.gcPauseMs}ms\n" +
            "FPS: ${"%.0f".format(s.avgFps)} drops=${"%.0f".format(s.jankyFrameRate * 100)}%\n" +
            "Mem: ${s.heapUsedMB}/${s.heapMaxMB}MB (${"%.0f".format(s.heapUtilization * 100)}%)\n" +
            "CPU: ${"%.0f".format(s.cpuUsagePercent)}% ${s.cpuFreqMHz}MHz throttle=${s.thermalThrottling}")
    }
}

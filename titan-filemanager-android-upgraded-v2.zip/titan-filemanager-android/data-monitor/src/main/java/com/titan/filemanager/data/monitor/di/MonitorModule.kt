package com.titan.filemanager.data.monitor.di

import android.content.Context
import com.titan.filemanager.data.monitor.engine.PerformanceMonitorEngine
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object MonitorModule {

    @Provides
    @Singleton
    fun providePerformanceMonitorEngine(@ApplicationContext context: Context): PerformanceMonitorEngine {
        return PerformanceMonitorEngine(context).also { it.initialize() }
    }
}

package com.titan.filemanager.data.monitor.metrics

import com.titan.filemanager.data.monitor.model.MetricPoint
import com.titan.filemanager.data.monitor.model.SlowFolderInfo
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * Scan Time Metrics Collector — tracks every directory scan.
 *
 * Technique #133: Scan time metrics
 * Technique #140: Slow-folder detection
 */
class ScanMetricsCollector {

    companion object {
        private const val SLOW_SCAN_THRESHOLD_MS = 1500L
        private const val VERY_SLOW_THRESHOLD_MS = 3000L
        private const val MAX_HISTORY_PER_PATH = 20
        private const val MAX_PATHS_TRACKED = 1000
    }

    private val scanHistory = ConcurrentHashMap<String, ArrayDeque<ScanRecord>>()
    private val totalScans = AtomicLong(0)
    private val totalScanTimeMs = AtomicLong(0)
    private val slowScanCount = AtomicLong(0)
    private val cacheHitScans = AtomicLong(0)
    private val cancelledScans = AtomicLong(0)
    private val peakScanTimeMs = AtomicLong(0)
    private val peakItemCount = AtomicLong(0)
    private val phaseTimings = ConcurrentHashMap<String, AtomicLong>()

    data class ScanRecord(
        val path: String, val durationMs: Long, val itemCount: Int, val fromCache: Boolean,
        val wasCancelled: Boolean, val strategy: String, val phaseMs: Map<String, Long>,
        val timestamp: Long = System.currentTimeMillis(),
    ) {
        val isSlowScan: Boolean get() = durationMs > SLOW_SCAN_THRESHOLD_MS
        val throughput: Float get() = if (durationMs > 0) itemCount.toFloat() / (durationMs / 1000f) else 0f
    }

    fun recordScan(record: ScanRecord) {
        totalScans.incrementAndGet(); totalScanTimeMs.addAndGet(record.durationMs)
        if (record.fromCache) cacheHitScans.incrementAndGet()
        if (record.wasCancelled) cancelledScans.incrementAndGet()
        if (record.isSlowScan) slowScanCount.incrementAndGet()
        updatePeak(peakScanTimeMs, record.durationMs); updatePeak(peakItemCount, record.itemCount.toLong())
        record.phaseMs.forEach { (phase, ms) -> phaseTimings.getOrPut(phase) { AtomicLong(0) }.addAndGet(ms) }
        if (scanHistory.size < MAX_PATHS_TRACKED) {
            val history = scanHistory.getOrPut(record.path) { ArrayDeque(MAX_HISTORY_PER_PATH) }
            synchronized(history) { history.addLast(record); if (history.size > MAX_HISTORY_PER_PATH) history.removeFirst() }
        }
    }

    fun startTiming(path: String, strategy: String) = ScanTimer(path, strategy, this)

    fun getAvgScanTime(path: String): Long = scanHistory[path]?.let { synchronized(it) { if (it.isEmpty()) -1L else it.map { r -> r.durationMs }.average().toLong() } } ?: -1L

    fun detectSlowFolders(threshold: Long = SLOW_SCAN_THRESHOLD_MS): List<SlowFolderInfo> =
        scanHistory.entries.mapNotNull { (path, history) ->
            synchronized(history) {
                if (history.isEmpty()) return@mapNotNull null
                val avgMs = history.map { it.durationMs }.average().toLong()
                if (avgMs < threshold) return@mapNotNull null
                val last = history.last()
                SlowFolderInfo(path, avgMs, history.size, last.itemCount, when {
                    last.itemCount > 5000 -> "Large directory (${last.itemCount} items)"
                    avgMs > VERY_SLOW_THRESHOLD_MS -> "Very slow I/O - check storage health"
                    else -> "Moderate slowness"
                })
            }
        }.sortedByDescending { it.avgScanMs }.take(20)

    fun getSummary(): ScanSummary {
        val total = totalScans.get()
        return ScanSummary(total, if (total > 0) totalScanTimeMs.get() / total else 0L, peakScanTimeMs.get(),
            slowScanCount.get(), if (total > 0) slowScanCount.get().toFloat() / total else 0f,
            if (total > 0) cacheHitScans.get().toFloat() / total else 0f,
            if (total > 0) cancelledScans.get().toFloat() / total else 0f,
            phaseTimings.mapValues { it.value.get() })
    }

    private fun updatePeak(atomic: AtomicLong, newValue: Long) {
        var current = atomic.get()
        while (newValue > current) { if (atomic.compareAndSet(current, newValue)) break; current = atomic.get() }
    }

    fun reset() { totalScans.set(0); totalScanTimeMs.set(0); slowScanCount.set(0); cacheHitScans.set(0); cancelledScans.set(0); peakScanTimeMs.set(0); peakItemCount.set(0); scanHistory.clear(); phaseTimings.clear() }

    data class ScanSummary(val totalScans: Long, val avgScanTimeMs: Long, val peakScanTimeMs: Long, val slowScanCount: Long, val slowScanRate: Float, val cacheHitRate: Float, val cancelRate: Float, val phaseSummary: Map<String, Long>)

    inner class ScanTimer(private val path: String, private val strategy: String, private val collector: ScanMetricsCollector) {
        private val startMs = System.currentTimeMillis()
        private val phaseMs = mutableMapOf<String, Long>()
        private var phaseStart = startMs

        fun markPhase(phaseName: String) { val now = System.currentTimeMillis(); phaseMs[phaseName] = now - phaseStart; phaseStart = now }

        fun stop(itemCount: Int, fromCache: Boolean, wasCancelled: Boolean = false) {
            collector.recordScan(ScanRecord(path, System.currentTimeMillis() - startMs, itemCount, fromCache, wasCancelled, strategy, phaseMs.toMap()))
        }
    }
}

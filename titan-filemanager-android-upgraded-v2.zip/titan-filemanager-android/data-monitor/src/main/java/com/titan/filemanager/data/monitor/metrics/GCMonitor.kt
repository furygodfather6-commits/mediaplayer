package com.titan.filemanager.data.monitor.metrics

import android.os.Debug
import kotlinx.coroutines.*
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * GC Monitor — tracks GC frequency, pause duration, allocation rate via Debug API.
 *
 * Technique #136: GC monitoring
 */
class GCMonitor(private val scope: CoroutineScope) {

    companion object { private const val MONITOR_INTERVAL_MS = 1000L; private const val GC_FREQ_THRESHOLD = 3 }

    private val totalGCCount = AtomicInteger(0)
    private val totalGCPauseMs = AtomicLong(0)
    private val gcTimestamps = ArrayDeque<Long>(200)
    private val gcTimestampsLock = Any()
    private var prevGCCount = 0; private var prevGCTime = 0L
    @Volatile private var isMonitoring = false
    private var monitorJob: Job? = null

    data class GCEvent(val gcCount: Int, val pauseMs: Long, val bytesFreed: Long, val bytesAllocated: Long, val timestamp: Long = System.currentTimeMillis())

    fun startMonitoring() {
        if (isMonitoring) return; isMonitoring = true
        monitorJob = scope.launch(Dispatchers.Default) { while (isActive && isMonitoring) { checkForNewGCEvents(); delay(MONITOR_INTERVAL_MS) } }
    }

    fun stopMonitoring() { isMonitoring = false; monitorJob?.cancel() }

    private fun checkForNewGCEvents() {
        try {
            val currentGCCount = Debug.getRuntimeStat("art.gc.gc-count")?.toIntOrNull() ?: return
            val currentGCTime = Debug.getRuntimeStat("art.gc.gc-time")?.toLongOrNull() ?: return
            val newGCs = currentGCCount - prevGCCount
            if (newGCs > 0) {
                val avgPauseMs = (currentGCTime - prevGCTime) / newGCs
                totalGCCount.addAndGet(newGCs); totalGCPauseMs.addAndGet(avgPauseMs * newGCs)
                val now = System.currentTimeMillis()
                synchronized(gcTimestampsLock) { repeat(newGCs) { gcTimestamps.addLast(now) }; val cutoff = now - 60_000L; while (gcTimestamps.isNotEmpty() && gcTimestamps.first() < cutoff) gcTimestamps.removeFirst() }
            }
            prevGCCount = currentGCCount; prevGCTime = currentGCTime
        } catch (_: Exception) {}
    }

    fun getGCFrequencyPerMinute(): Float = synchronized(gcTimestampsLock) { gcTimestamps.size.toFloat() }
    fun isGCProblematic(): Boolean = getGCFrequencyPerMinute() > GC_FREQ_THRESHOLD

    fun getSummary() = GCSummary(totalGCCount.get(), getGCFrequencyPerMinute(), if (totalGCCount.get() > 0) totalGCPauseMs.get() / totalGCCount.get() else 0L, isGCProblematic())

    data class GCSummary(val totalGCCount: Int, val gcPerMinute: Float, val avgPauseMs: Long, val isProblematic: Boolean)
}

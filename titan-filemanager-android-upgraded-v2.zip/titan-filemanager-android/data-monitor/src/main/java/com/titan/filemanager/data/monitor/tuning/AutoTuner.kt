package com.titan.filemanager.data.monitor.tuning

import com.titan.filemanager.data.monitor.metrics.*
import com.titan.filemanager.data.monitor.model.TuningAction
import kotlinx.coroutines.*
import timber.log.Timber
import java.util.concurrent.ConcurrentLinkedDeque

/**
 * Auto Tuner — 7-rule automatic parameter adjustment based on live metrics.
 *
 * Rule 1: slowScanRate>30% → +1 scan thread
 * Rule 2: cacheHit<60% → +50 L2 cache size
 * Rule 3: gcFreq>5/min → -1 concurrent op
 * Rule 4: frameDrop>10% → disable background work
 * Rule 5: heap>85% → halve L1 cache
 * Rule 6: thermalThrottle → -1 thread
 * Rule 7: ioP99>100ms → +100 batch size
 *
 * Technique #141: Automatic tuning
 */
class AutoTuner(
    private val scanMetrics: ScanMetricsCollector,
    private val ioTracker: IOLatencyTracker,
    private val cacheTracker: CacheHitTracker,
    private val gcMonitor: GCMonitor,
    private val frameMonitor: FrameDropMonitor,
    private val memoryProfiler: MemoryProfiler,
    private val cpuProfiler: CPUProfiler,
    private val scope: CoroutineScope,
) {
    companion object { private const val TUNING_INTERVAL_MS = 30_000L }

    private val params = TuningParameters()
    private val tuningHistory = ConcurrentLinkedDeque<TuningAction>()
    var onParameterChanged: ((TuningParameters) -> Unit)? = null
    @Volatile private var isRunning = false
    private var tuningJob: Job? = null

    data class TuningParameters(
        var scanThreadCount: Int = 4, var thumbnailThreadCount: Int = 4,
        var statBatchSize: Int = 200, var l1CacheSize: Int = 50, var l2CacheSize: Int = 200,
        var prefetchEnabled: Boolean = true, var backgroundWorkEnabled: Boolean = true,
        var maxConcurrentOps: Int = 8, var readAheadEnabled: Boolean = true,
    )

    fun startAutoTuning() {
        if (isRunning) return; isRunning = true
        tuningJob = scope.launch(Dispatchers.Default) { while (isActive && isRunning) { delay(TUNING_INTERVAL_MS); performTuningCycle() } }
    }

    fun stopAutoTuning() { isRunning = false; tuningJob?.cancel() }

    private fun performTuningCycle() {
        val actions = mutableListOf<TuningAction>()

        // Rule 1: Slow scans → more threads
        val scanSummary = scanMetrics.getSummary()
        if (scanSummary.slowScanRate > 0.3f && params.scanThreadCount < 8)
            actions.add(tune("scanThreadCount", params.scanThreadCount.toString(), (params.scanThreadCount + 1).toString(), "Slow scan rate ${"%.1f".format(scanSummary.slowScanRate * 100)}% > 30%") { params.scanThreadCount = minOf(params.scanThreadCount + 1, 8) })

        // Rule 2: Low cache hit → increase cache
        val hitRate = cacheTracker.getOverallHitRate()
        if (hitRate < 0.6f && params.l2CacheSize < 500)
            actions.add(tune("l2CacheSize", params.l2CacheSize.toString(), (params.l2CacheSize + 50).toString(), "Cache hit rate ${"%.1f".format(hitRate * 100)}% < 60%") { params.l2CacheSize = minOf(params.l2CacheSize + 50, 500) })

        // Rule 3: High GC → reduce concurrent ops
        val gcSummary = gcMonitor.getSummary()
        if (gcSummary.gcPerMinute > 5f)
            actions.add(tune("maxConcurrentOps", params.maxConcurrentOps.toString(), (params.maxConcurrentOps - 1).toString(), "High GC: ${"%.1f".format(gcSummary.gcPerMinute)}/min") { params.maxConcurrentOps = maxOf(params.maxConcurrentOps - 1, 2) })

        // Rule 4: Frame drops → disable background
        val frameSummary = frameMonitor.getSummary()
        if (frameSummary.dropRate > 0.1f && params.backgroundWorkEnabled)
            actions.add(tune("backgroundWorkEnabled", "true", "false", "Frame drop ${"%.1f".format(frameSummary.dropRate * 100)}% > 10%") { params.backgroundWorkEnabled = false })
        else if (frameSummary.dropRate <= 0.1f && !params.backgroundWorkEnabled)
            actions.add(tune("backgroundWorkEnabled", "false", "true", "Frame rate recovered") { params.backgroundWorkEnabled = true })

        // Rule 5: High memory → clear caches
        val memSample = memoryProfiler.takeSample()
        if (memSample.heapUtilization > 0.85f)
            actions.add(tune("l1CacheSize", params.l1CacheSize.toString(), (params.l1CacheSize / 2).toString(), "Heap ${"%.1f".format(memSample.heapUtilization * 100)}% > 85%") { params.l1CacheSize = maxOf(params.l1CacheSize / 2, 10) })

        // Rule 6: Thermal throttle → reduce threads
        if (cpuProfiler.isThermallyThrottled() && params.scanThreadCount > 2)
            actions.add(tune("scanThreadCount", params.scanThreadCount.toString(), (params.scanThreadCount - 1).toString(), "Thermal throttling detected") { params.scanThreadCount = maxOf(params.scanThreadCount - 1, 2); params.thumbnailThreadCount = maxOf(params.thumbnailThreadCount - 1, 2) })

        // Rule 7: High I/O P99 → increase batch
        val statP99 = ioTracker.getPercentile(IOLatencyTracker.IOOperationType.STAT, 99)
        if (statP99 > 100L && params.statBatchSize < 500)
            actions.add(tune("statBatchSize", params.statBatchSize.toString(), (params.statBatchSize + 100).toString(), "High stat P99: ${statP99}ms") { params.statBatchSize = minOf(params.statBatchSize + 100, 500) })

        if (actions.isNotEmpty()) {
            actions.forEach { tuningHistory.addFirst(it) }; if (tuningHistory.size > 100) tuningHistory.pollLast()
            onParameterChanged?.invoke(params.copy())
            Timber.d("Auto-Tuning: ${actions.size} adjustments")
        }
    }

    private fun tune(parameter: String, oldValue: String, newValue: String, reason: String, action: () -> Unit): TuningAction {
        action(); return TuningAction(parameter, oldValue, newValue, reason, "", appliedSuccessfully = true)
    }

    fun getCurrentParameters(): TuningParameters = params.copy()
    fun getTuningHistory(limit: Int = 20): List<TuningAction> = tuningHistory.toList().take(limit)
}

package com.titan.filemanager.data.monitor.alert

import com.titan.filemanager.data.monitor.model.PerformanceAlert
import com.titan.filemanager.data.monitor.model.PerformanceAlert.AlertCategory
import com.titan.filemanager.data.monitor.model.PerformanceAlert.Severity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import timber.log.Timber
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Performance Alert System — threshold-based alerts with dedup + history.
 */
class AlertSystem(private val thresholds: AlertThresholds = AlertThresholds()) {

    private val activeAlerts = ConcurrentHashMap<AlertCategory, PerformanceAlert>()
    private val alertHistory = ArrayDeque<PerformanceAlert>(200)
    private val historyLock = Any()
    private val _alertFlow = MutableStateFlow<List<PerformanceAlert>>(emptyList())
    val alertFlow: StateFlow<List<PerformanceAlert>> = _alertFlow.asStateFlow()

    fun checkMetric(category: AlertCategory, value: Double, threshold: Double, message: String, severity: Severity = Severity.WARNING, suggestedAction: String = "") {
        if (value > threshold) raiseAlert(category, value, threshold, message, severity, suggestedAction) else resolveAlert(category)
    }

    private fun raiseAlert(category: AlertCategory, value: Double, threshold: Double, message: String, severity: Severity, suggestedAction: String) {
        val existing = activeAlerts[category]; if (existing != null && !existing.isResolved) return
        val alert = PerformanceAlert(UUID.randomUUID().toString(), severity, category, message, value, threshold, suggestedAction = suggestedAction)
        activeAlerts[category] = alert
        synchronized(historyLock) { alertHistory.addLast(alert); if (alertHistory.size > 200) alertHistory.removeFirst() }
        _alertFlow.value = activeAlerts.values.filter { !it.isResolved }
        Timber.w("[${severity}] ${category}: $message (value=$value, threshold=$threshold)")
    }

    private fun resolveAlert(category: AlertCategory) {
        activeAlerts[category]?.let { if (!it.isResolved) { it.isResolved = true; _alertFlow.value = activeAlerts.values.filter { a -> !a.isResolved } } }
    }

    fun getActiveAlerts(): List<PerformanceAlert> = activeAlerts.values.filter { !it.isResolved }
    fun getAlertHistory(limit: Int = 50): List<PerformanceAlert> = synchronized(historyLock) { alertHistory.takeLast(limit) }
}

data class AlertThresholds(
    val slowScanRatePercent: Double = 30.0,
    val cacheHitRateMinPercent: Double = 60.0,
    val gcPerMinuteMax: Double = 5.0,
    val frameDropRatePercent: Double = 10.0,
    val heapUtilizationPercent: Double = 85.0,
    val cpuUsagePercent: Double = 80.0,
    val ioLatencyP99Ms: Double = 100.0,
)

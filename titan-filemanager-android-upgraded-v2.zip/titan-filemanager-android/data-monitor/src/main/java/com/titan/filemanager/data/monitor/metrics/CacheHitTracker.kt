package com.titan.filemanager.data.monitor.metrics

import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * Cache Hit Ratio Tracker — tracks hit/miss for all cache layers.
 *
 * Technique #135: Cache hit ratio
 */
class CacheHitTracker {

    enum class CacheType { L1_HOT_RAM, L2_WARM_RAM, L3_SQLITE, L4_DISK, THUMBNAIL_MEMORY, THUMBNAIL_DISK, METADATA, STAT, MIME, DIR_LIST, PATH, READAHEAD }

    private val hits = ConcurrentHashMap<CacheType, AtomicLong>()
    private val misses = ConcurrentHashMap<CacheType, AtomicLong>()
    private val evictions = ConcurrentHashMap<CacheType, AtomicLong>()
    private val invalidations = ConcurrentHashMap<CacheType, AtomicLong>()

    init { CacheType.values().forEach { hits[it] = AtomicLong(0); misses[it] = AtomicLong(0); evictions[it] = AtomicLong(0); invalidations[it] = AtomicLong(0) } }

    fun recordHit(type: CacheType) { hits[type]?.incrementAndGet() }
    fun recordMiss(type: CacheType) { misses[type]?.incrementAndGet() }
    fun recordEviction(type: CacheType) { evictions[type]?.incrementAndGet() }
    fun recordInvalidation(type: CacheType) { invalidations[type]?.incrementAndGet() }

    fun getHitRate(type: CacheType): Float {
        val h = hits[type]?.get() ?: 0L; val m = misses[type]?.get() ?: 0L
        return if (h + m > 0) h.toFloat() / (h + m) else 0f
    }

    fun getOverallHitRate(): Float {
        val weights = mapOf(
            CacheType.L1_HOT_RAM to 0.20f, CacheType.L2_WARM_RAM to 0.15f,
            CacheType.THUMBNAIL_MEMORY to 0.15f, CacheType.STAT to 0.15f,
            CacheType.MIME to 0.10f, CacheType.DIR_LIST to 0.10f,
            CacheType.METADATA to 0.10f, CacheType.PATH to 0.05f,
        )
        var weightedSum = 0f; var totalWeight = 0f
        weights.forEach { (type, weight) -> weightedSum += getHitRate(type) * weight; totalWeight += weight }
        return if (totalWeight > 0) weightedSum / totalWeight else 0f
    }

    fun getAllStats(): Map<CacheType, CacheStats> = CacheType.values().associateWith { CacheStats(it, hits[it]?.get() ?: 0, misses[it]?.get() ?: 0, evictions[it]?.get() ?: 0, invalidations[it]?.get() ?: 0, getHitRate(it)) }

    data class CacheStats(val cacheType: CacheType, val hits: Long, val misses: Long, val evictions: Long, val invalidations: Long, val hitRate: Float) { val totalRequests: Long get() = hits + misses }
}

package com.titan.filemanager.data.monitor.detection

import com.titan.filemanager.data.monitor.metrics.ScanMetricsCollector
import com.titan.filemanager.data.monitor.model.SlowFolderInfo

/**
 * Slow Folder Detector — identifies folders with consistently slow scan times.
 *
 * Technique #140: Slow-folder detection
 */
class SlowFolderDetector(private val scanMetrics: ScanMetricsCollector) {
    fun getSlowFolders(threshold: Long = 1500L): List<SlowFolderInfo> = scanMetrics.detectSlowFolders(threshold)
    fun isSlowFolder(path: String, threshold: Long = 1500L): Boolean = scanMetrics.getAvgScanTime(path) > threshold
}

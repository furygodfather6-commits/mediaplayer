package com.titan.filemanager.data.metadata.resolver

import android.media.MediaMetadataRetriever
import androidx.exifinterface.media.ExifInterface
import com.titan.filemanager.core.common.dispatcher.DispatcherProvider
import com.titan.filemanager.core.common.logger.Logger
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Resolver for media metadata (EXIF, video duration, audio bitrate).
 *
 * Phase 3 implementation:
 *   - Images: [ExifInterface] for orientation, GPS, camera, dimensions
 *   - Video: [MediaMetadataRetriever] for duration, codec, resolution, bitrate
 *   - Audio: [MediaMetadataRetriever] for duration, bitrate, artist, album
 *
 * Performance note: MediaMetadataRetriever is slow (~50-100ms per file),
 * so always call from IO dispatcher and prefer the lighter [ExifInterface]
 * for images when possible.
 *
 * Phase 5 will add: native media parser (Phase S-108) that reads only
 * 512 bytes of header — 10-50× faster than MediaMetadataRetriever.
 */
@Singleton
class MediaMetadataResolver @Inject constructor(
    private val dispatchers: DispatcherProvider,
    private val logger: Logger,
) {

    /**
     * Resolve media metadata for [path] based on [mimeType].
     *
     * Returns `null` for non-media types or on error.
     */
    suspend fun resolve(path: String, mimeType: String?): MediaMetadata? =
        withContext(dispatchers.io) {
            if (mimeType == null) return@withContext null
            val type = mimeType.substringBefore('/')
            return@withContext when (type) {
                "image" -> resolveImageExif(path)
                "video" -> resolveVideo(path)
                "audio" -> resolveAudio(path)
                else -> null
            }
        }

    /**
     * Resolve image metadata via ExifInterface.
     *
     * Fast path (~5ms) — only reads EXIF header, not the full image.
     */
    private fun resolveImageExif(path: String): MediaMetadata? = try {
        val exif = ExifInterface(path)
        val orientation = when (exif.getAttributeInt(
            ExifInterface.TAG_ORIENTATION,
            ExifInterface.ORIENTATION_NORMAL,
        )) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90
            ExifInterface.ORIENTATION_ROTATE_180 -> 180
            ExifInterface.ORIENTATION_ROTATE_270 -> 270
            else -> 0
        }
        MediaMetadata.Image(
            width = exif.getAttributeInt(ExifInterface.TAG_IMAGE_WIDTH, 0),
            height = exif.getAttributeInt(ExifInterface.TAG_IMAGE_LENGTH, 0),
            orientation = orientation,
            dateTaken = exif.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL),
            cameraMake = exif.getAttribute(ExifInterface.TAG_MAKE),
            cameraModel = exif.getAttribute(ExifInterface.TAG_MODEL),
            latLong = exif.latLong,
        )
    } catch (e: Exception) {
        logger.w(e) { "EXIF read failed: $path" }
        null
    }

    /**
     * Resolve video metadata via MediaMetadataRetriever.
     *
     * Slow (~50-100ms) — uses native media framework.
     */
    private fun resolveVideo(path: String): MediaMetadata? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(path)
            MediaMetadata.Video(
                width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0,
                height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0,
                durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L,
                bitrate = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toLongOrNull() ?: 0L,
                codec = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE),
                rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0,
            )
        } catch (e: Exception) {
            logger.w(e) { "Video metadata read failed: $path" }
            null
        } finally {
            try { retriever.release() } catch (_: Exception) {}
        }
    }

    /**
     * Resolve audio metadata via MediaMetadataRetriever.
     */
    private fun resolveAudio(path: String): MediaMetadata? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(path)
            MediaMetadata.Audio(
                durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L,
                bitrate = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toLongOrNull() ?: 0L,
                title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE),
                artist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST),
                album = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM),
                genre = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE),
                trackNumber = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CD_TRACK_NUMBER),
            )
        } catch (e: Exception) {
            logger.w(e) { "Audio metadata read failed: $path" }
            null
        } finally {
            try { retriever.release() } catch (_: Exception) {}
        }
    }
}

/**
 * Media metadata — sealed hierarchy with one variant per media type.
 */
sealed interface MediaMetadata {
    data class Image(
        val width: Int,
        val height: Int,
        val orientation: Int,
        val dateTaken: String?,
        val cameraMake: String?,
        val cameraModel: String?,
        val latLong: DoubleArray?,
    ) : MediaMetadata

    data class Video(
        val width: Int,
        val height: Int,
        val durationMs: Long,
        val bitrate: Long,
        val codec: String?,
        val rotation: Int,
    ) : MediaMetadata

    data class Audio(
        val durationMs: Long,
        val bitrate: Long,
        val title: String?,
        val artist: String?,
        val album: String?,
        val genre: String?,
        val trackNumber: String?,
    ) : MediaMetadata
}

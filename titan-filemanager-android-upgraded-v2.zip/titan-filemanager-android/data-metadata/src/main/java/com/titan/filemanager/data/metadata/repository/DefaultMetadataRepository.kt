package com.titan.filemanager.data.metadata.repository

import com.titan.filemanager.core.common.dispatcher.DispatcherProvider
import com.titan.filemanager.core.common.logger.Logger
import com.titan.filemanager.core.common.result.AppError
import com.titan.filemanager.core.common.result.Result
import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.data.metadata.detector.MimeDetector
import com.titan.filemanager.data.metadata.resolver.MediaMetadataResolver
import com.titan.filemanager.domain.metadata.MetadataRepository
import com.titan.filemanager.domain.metadata.MetadataType
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Default [MetadataRepository] — composes [MimeDetector] +
 * [MediaMetadataResolver] + File API.
 *
 * Phase 3 — basic implementation: each metadata type resolved independently.
 * Phase 5 will add: in-memory cache (MetadataCache) + version fingerprint
 * (inode+mtime+size) to skip re-resolution of unchanged files.
 */
@Singleton
class DefaultMetadataRepository @Inject constructor(
    private val mimeDetector: MimeDetector,
    private val mediaResolver: MediaMetadataResolver,
    private val dispatchers: DispatcherProvider,
    private val logger: Logger,
) : MetadataRepository {

    override suspend fun resolveMetadata(
        path: String,
        types: Set<MetadataType>,
    ): Result<FileItem> = withContext(dispatchers.io) {
        try {
            val file = File(path)
            val fileItem = file.toFileItem()
            val enriched = enrichItem(fileItem, file, types)
            Result.Success(enriched)
        } catch (e: Exception) {
            logger.w(e) { "Metadata resolve failed: $path" }
            Result.Error(AppError.IO.ReadError(path, e))
        }
    }

    override suspend fun resolveBatch(
        paths: List<String>,
        types: Set<MetadataType>,
    ): Result<List<FileItem>> = withContext(dispatchers.io) {
        val results = paths.map { path ->
            try {
                val file = File(path)
                val item = file.toFileItem()
                enrichItem(item, file, types)
            } catch (e: Exception) {
                logger.w(e) { "Batch metadata failed: $path" }
                null
            }
        }.filterNotNull()
        Result.Success(results)
    }

    override suspend fun invalidate(path: String) {
        // Phase 5 will wire MetadataCache here
    }

    override suspend fun invalidateRecursive(dirPath: String) {
        // Phase 5 will wire MetadataCache here
    }

    /**
     * Enrich a [FileItem] with the requested [types] of metadata.
     */
    private suspend fun enrichItem(
        item: FileItem,
        file: File,
        types: Set<MetadataType>,
    ): FileItem {
        var enriched = item

        if (MetadataType.MIME in types && enriched.mimeType == null) {
            enriched = enriched.copy(mimeType = mimeDetector.detect(file.absolutePath, file.name))
        }

        if (MetadataType.MEDIA in types && !file.isDirectory) {
            // mediaResolver returns null for non-media types — safe to call always
            val mediaMeta = mediaResolver.resolve(file.absolutePath, enriched.mimeType)
            if (mediaMeta != null) {
                // Phase 5 will add mediaMeta field to FileItem; for now
                // we expose it via tags list (a hack for Phase 3 demo)
                val mediaTag = when (mediaMeta) {
                    is com.titan.filemanager.data.metadata.resolver.MediaMetadata.Image ->
                        "${mediaMeta.width}×${mediaMeta.height}"
                    is com.titan.filemanager.data.metadata.resolver.MediaMetadata.Video ->
                        "${mediaMeta.width}×${mediaMeta.height} • ${mediaMeta.durationMs}ms"
                    is com.titan.filemanager.data.metadata.resolver.MediaMetadata.Audio ->
                        "${mediaMeta.durationMs}ms • ${mediaMeta.bitrate}bps"
                }
                enriched = enriched.copy(tags = enriched.tags + mediaTag)
            }
        }

        return enriched
    }

    private fun File.toFileItem(): FileItem = FileItem(
        path = absolutePath,
        name = name,
        stableId = runCatching { absoluteFile.hashCode().toLong() }.getOrDefault(0L),
        size = if (isDirectory) 0L else length(),
        modifiedAt = lastModified(),
        isDirectory = isDirectory,
        isHidden = name.startsWith("."),
    )
}

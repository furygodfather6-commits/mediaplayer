package com.titan.filemanager.data.metadata.di

import com.titan.filemanager.data.metadata.repository.DefaultMetadataRepository
import com.titan.filemanager.domain.metadata.MetadataRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class MetadataModule {

    @Binds
    @Singleton
    abstract fun bindMetadataRepository(
        impl: DefaultMetadataRepository,
    ): MetadataRepository
}

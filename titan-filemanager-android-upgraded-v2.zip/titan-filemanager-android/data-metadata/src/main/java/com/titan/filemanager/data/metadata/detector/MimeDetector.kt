package com.titan.filemanager.data.metadata.detector

import android.webkit.MimeTypeMap
import com.titan.filemanager.core.common.logger.Logger
import java.io.File
import java.io.FileInputStream
import javax.inject.Inject
import javax.inject.Singleton

/**
 * 3-tier MIME type detector:
 *
 *   1. **Extension lookup** (~1µs) — fast path, covers 90%+ of cases
 *   2. **Magic bytes** (~1ms) — reads first 16 bytes, matches signatures
 *   3. **System MimeTypeMap** (~5ms) — fallback for unknown extensions
 *
 * Returns `application/octet-stream` if all three fail.
 *
 * Phase 3 — pure implementation. Phase 5 will add: content-based detection
 * for ambiguous files (e.g. `.bin` that's actually a PDF).
 */
@Singleton
class MimeDetector @Inject constructor(
    private val logger: Logger,
) {

    /**
     * Detect MIME type for [path] using the 3-tier strategy.
     *
     * @param path File path (must exist for tier 2 to work)
     * @param name Optional name override (defaults to last segment of path)
     * @return MIME type string (never null)
     */
    suspend fun detect(path: String, name: String = File(path).name): String {
        // ── Tier 1: Extension lookup ──────────────────────────────
        val ext = name.substringAfterLast('.', "").lowercase()
        if (ext.isNotEmpty()) {
            EXTENSION_MAP[ext]?.let { return it }
        }

        // ── Tier 2: Magic bytes (only if file exists) ────────────
        val file = File(path)
        if (file.exists() && file.isFile && file.length() >= 4) {
            try {
                val magic = readMagicBytes(file, 16)
                MAGIC_BYTES_MAP.entries.firstOrNull { (signature, _) ->
                    magic.size >= signature.size &&
                        magic.copyOfRange(0, signature.size).contentEquals(signature)
                }?.value?.let { return it }
            } catch (e: Exception) {
                logger.w(e) { "Magic byte read failed: $path" }
            }
        }

        // ── Tier 3: System MimeTypeMap ───────────────────────────
        if (ext.isNotEmpty()) {
            MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)?.let { return it }
        }

        return "application/octet-stream"
    }

    private fun readMagicBytes(file: File, count: Int): ByteArray {
        val buffer = ByteArray(count)
        FileInputStream(file).use { stream ->
            val read = stream.read(buffer)
            if (read < count) return buffer.copyOf(read)
        }
        return buffer
    }

    companion object {
        /**
         * Extension → MIME map for the most common file types.
         *
         * Curated list — MimeTypeMap misses some types (e.g. `.ts`, `.kt`)
         * and is inconsistent across Android versions.
         */
        val EXTENSION_MAP: Map<String, String> = mapOf(
            // Images
            "jpg" to "image/jpeg", "jpeg" to "image/jpeg", "png" to "image/png",
            "gif" to "image/gif", "webp" to "image/webp", "bmp" to "image/bmp",
            "svg" to "image/svg+xml", "heic" to "image/heic", "heif" to "image/heif",
            "tiff" to "image/tiff", "tif" to "image/tiff",
            // Videos
            "mp4" to "video/mp4", "mkv" to "video/x-matroska", "avi" to "video/x-msvideo",
            "mov" to "video/quicktime", "wmv" to "video/x-ms-wmv", "flv" to "video/x-flv",
            "webm" to "video/webm", "3gp" to "video/3gpp", "mpeg" to "video/mpeg",
            "mpg" to "video/mpeg",
            // Audio
            "mp3" to "audio/mpeg", "wav" to "audio/wav", "flac" to "audio/flac",
            "aac" to "audio/aac", "ogg" to "audio/ogg", "m4a" to "audio/mp4",
            "wma" to "audio/x-ms-wma", "opus" to "audio/ogg", "amr" to "audio/amr",
            "m3u" to "audio/x-mpegurl", "m3u8" to "application/vnd.apple.mpegurl",
            // Documents
            "pdf" to "application/pdf",
            "doc" to "application/msword",
            "docx" to "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "xls" to "application/vnd.ms-excel",
            "xlsx" to "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "ppt" to "application/vnd.ms-powerpoint",
            "pptx" to "application/vnd.openxmlformats-officedocument.presentationml.presentation",
            "odt" to "application/vnd.oasis.opendocument.text",
            "ods" to "application/vnd.oasis.opendocument.spreadsheet",
            "odp" to "application/vnd.oasis.opendocument.presentation",
            "rtf" to "application/rtf",
            "txt" to "text/plain", "md" to "text/markdown",
            // Archives
            "zip" to "application/zip", "rar" to "application/x-rar-compressed",
            "7z" to "application/x-7z-compressed", "tar" to "application/x-tar",
            "gz" to "application/gzip", "bz2" to "application/x-bzip2",
            "xz" to "application/x-xz", "tgz" to "application/x-compressed-tar",
            // Code
            "kt" to "text/x-kotlin", "java" to "text/x-java-source",
            "c" to "text/x-c", "cpp" to "text/x-c++", "h" to "text/x-c",
            "hpp" to "text/x-c++", "py" to "text/x-python", "js" to "text/javascript",
            "ts" to "application/typescript", "tsx" to "text/tsx", "jsx" to "text/jsx",
            "html" to "text/html", "htm" to "text/html", "css" to "text/css",
            "xml" to "application/xml", "json" to "application/json",
            "yaml" to "application/x-yaml", "yml" to "application/x-yaml",
            "toml" to "application/toml", "sh" to "application/x-sh",
            "go" to "text/x-go", "rs" to "text/rust", "swift" to "text/swift",
            "rb" to "text/x-ruby", "php" to "application/x-httpd-php",
            "sql" to "application/sql", "gradle" to "text/x-groovy",
            // Web
            "htm" to "text/html", "xhtml" to "application/xhtml+xml",
            // APK / App
            "apk" to "application/vnd.android.package-archive",
            "apks" to "application/vnd.android.package-archive",
            "apkm" to "application/vnd.android.package-archive",
            "xapk" to "application/vnd.android.package-archive",
            // Fonts
            "ttf" to "font/ttf", "otf" to "font/otf",
            "woff" to "font/woff", "woff2" to "font/woff2",
            // eBooks
            "epub" to "application/epub+zip", "mobi" to "application/x-mobipocket-ebook",
            "azw" to "application/x-mobipocket-ebook", "azw3" to "application/x-mobipocket-ebook",
            // Database
            "db" to "application/x-sqlite3", "sqlite" to "application/x-sqlite3",
            "sqlite3" to "application/x-sqlite3",
            // Misc
            "log" to "text/plain", "csv" to "text/csv", "tsv" to "text/tab-separated-values",
            "torrent" to "application/x-bittorrent",
            "ico" to "image/x-icon", "cur" to "image/x-icon",
        )

        /**
         * Magic-byte signatures — first 16 bytes of common file types.
         *
         * Used when the extension is missing or unreliable (e.g. downloaded
         * file with wrong extension).
         */
        val MAGIC_BYTES_MAP: Map<ByteArray, String> = mapOf(
            // Images
            byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte()) to "image/jpeg",
            byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A) to "image/png",
            byteArrayOf(0x47, 0x49, 0x46, 0x38) to "image/gif",  // "GIF8"
            byteArrayOf(0x42, 0x4D) to "image/bmp",  // "BM"
            byteArrayOf(0x52, 0x49, 0x46, 0x46) to "image/webp",  // "RIFF" (also WAV, AVI — Phase 5 will refine)
            // Archives
            byteArrayOf(0x50, 0x4B, 0x03, 0x04) to "application/zip",  // "PK\x03\x04" (also jar, docx, xlsx, apk)
            byteArrayOf(0x52, 0x61, 0x72, 0x21, 0x1A, 0x07) to "application/x-rar-compressed",
            byteArrayOf(0x37, 0x7A, 0xBC.toByte(), 0xAF.toByte(), 0x27, 0x1C) to "application/x-7z-compressed",
            byteArrayOf(0x1F, 0x8B.toByte()) to "application/gzip",
            byteArrayOf(0x42, 0x5A, 0x68) to "application/x-bzip2",  // "BZh"
            // Documents
            byteArrayOf(0x25, 0x50, 0x44, 0x46) to "application/pdf",  // "%PDF"
            // Media
            byteArrayOf(0x49, 0x44, 0x33) to "audio/mpeg",  // "ID3" (MP3)
            byteArrayOf(0x66, 0x4C, 0x61, 0x43) to "audio/flac",  // "fLaC"
            byteArrayOf(0x4F, 0x67, 0x67, 0x53) to "audio/ogg",  // "OggS" (also video/ogg)
            // Android
            byteArrayOf(0x50, 0x4B, 0x03, 0x04) to "application/vnd.android.package-archive",
        )
    }
}

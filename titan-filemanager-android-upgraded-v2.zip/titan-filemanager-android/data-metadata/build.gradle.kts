// :data:metadata — MIME + size + media metadata extraction
plugins {
    id("titan.android.library")
    id("titan.android.hilt")
}

android {
    namespace = "com.titan.filemanager.data.metadata"
}

dependencies {
    api(project(":core:common"))
    api(project(":core:model"))
    api(project(":domain"))

    implementation(libs.kotlinx.coroutines.core)
    implementation(libs.timber)

    // EXIF
    implementation("androidx.exifinterface:exifinterface:1.3.7")

    // MediaMetadataRetriever is in Android SDK, no dep needed

    testImplementation(project(":core:testing"))
    testImplementation(libs.junit5)
    testImplementation(libs.truth)
    testImplementation(libs.robolectric)
    testImplementation(libs.kotlinx.coroutines.test)
}

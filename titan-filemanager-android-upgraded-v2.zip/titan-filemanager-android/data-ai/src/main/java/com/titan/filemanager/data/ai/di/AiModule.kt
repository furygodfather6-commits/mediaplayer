package com.titan.filemanager.data.ai.di

import com.titan.filemanager.data.ai.repository.DefaultAiRepository
import com.titan.filemanager.domain.ai.AiRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class AiModule {

    @Binds
    @Singleton
    abstract fun bindAiRepository(impl: DefaultAiRepository): AiRepository
}

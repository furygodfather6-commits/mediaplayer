package com.titan.filemanager.data.ai.repository

import com.titan.filemanager.core.common.result.AppError
import com.titan.filemanager.core.common.result.Result
import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.data.ai.engine.AiEngine
import com.titan.filemanager.domain.ai.AiCategorization
import com.titan.filemanager.domain.ai.AiCategorizationStats
import com.titan.filemanager.domain.ai.AiInsight
import com.titan.filemanager.domain.ai.AiProgress
import com.titan.filemanager.domain.ai.AiRepository
import com.titan.filemanager.domain.ai.AiStats
import com.titan.filemanager.domain.ai.DuplicateDetectionResult
import com.titan.filemanager.domain.ai.FolderPrediction
import com.titan.filemanager.domain.ai.HotFolder
import com.titan.filemanager.domain.ai.OrganizationSuggestion
import com.titan.filemanager.domain.ai.SemanticSearchResult
import com.titan.filemanager.domain.ai.SmartTag
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DefaultAiRepository @Inject constructor(
    private val engine: AiEngine,
) : AiRepository {

    // ── Categorization ────────────────────────────────────────────

    override suspend fun categorizeFile(file: FileItem): Result<AiCategorization> = try {
        Result.Success(engine.categorizeFile(file))
    } catch (t: Throwable) {
        Result.Error(AppError.Unknown(t))
    }

    override suspend fun categorizeBatch(
        files: List<FileItem>,
        onProgress: (AiProgress) -> Unit,
    ): Result<List<AiCategorization>> = try {
        Result.Success(engine.categorizeBatch(files, onProgress))
    } catch (t: Throwable) {
        Result.Error(AppError.Unknown(t))
    }

    override fun observeCategorizationStats(): Flow<AiCategorizationStats> = flow {
        // No persistence — emit empty stats by default.
        // Real implementation would observe a cached categorization store.
        emit(AiCategorizationStats(
            totalCategorized = 0,
            byCategory = emptyMap(),
            byImportance = emptyMap(),
            averageConfidence = 0f,
        ))
    }

    // ── Search ────────────────────────────────────────────────────

    override suspend fun semanticSearch(query: String, rootPath: String): Flow<List<SemanticSearchResult>> =
        engine.semanticSearch(query, rootPath)

    override suspend fun fuzzySearch(query: String, rootPath: String, maxResults: Int): Result<List<SemanticSearchResult>> = try {
        Result.Success(engine.fuzzySearch(query, rootPath, maxResults))
    } catch (t: Throwable) {
        Result.Error(AppError.Unknown(t))
    }

    // ── Organization ──────────────────────────────────────────────

    override suspend fun suggestOrganization(rootPath: String): Result<OrganizationSuggestion> = try {
        Result.Success(engine.suggestOrganization(rootPath))
    } catch (t: Throwable) {
        Result.Error(AppError.Unknown(t))
    }

    override suspend fun suggestOrganizationByDate(rootPath: String): Result<OrganizationSuggestion> = try {
        Result.Success(engine.suggestOrganizationByDate(rootPath))
    } catch (t: Throwable) {
        Result.Error(AppError.Unknown(t))
    }

    override suspend fun suggestOrganizationByProject(rootPath: String): Result<OrganizationSuggestion> = try {
        Result.Success(engine.suggestOrganizationByProject(rootPath))
    } catch (t: Throwable) {
        Result.Error(AppError.Unknown(t))
    }

    override suspend fun suggestOrganizationBySize(rootPath: String): Result<OrganizationSuggestion> = try {
        Result.Success(engine.suggestOrganizationBySize(rootPath))
    } catch (t: Throwable) {
        Result.Error(AppError.Unknown(t))
    }

    // ── Duplicates ────────────────────────────────────────────────

    override suspend fun findDuplicates(rootPath: String): Result<DuplicateDetectionResult> = try {
        Result.Success(engine.findDuplicates(rootPath))
    } catch (t: Throwable) {
        Result.Error(AppError.Unknown(t))
    }

    override suspend fun findDuplicatesByContent(rootPath: String): Result<DuplicateDetectionResult> = try {
        Result.Success(engine.findDuplicatesByContent(rootPath))
    } catch (t: Throwable) {
        Result.Error(AppError.Unknown(t))
    }

    override suspend fun findDuplicatesByName(rootPath: String): Result<DuplicateDetectionResult> = try {
        Result.Success(engine.findDuplicatesByName(rootPath))
    } catch (t: Throwable) {
        Result.Error(AppError.Unknown(t))
    }

    // ── Tags ──────────────────────────────────────────────────────

    override suspend fun generateSmartTags(file: FileItem): Result<List<SmartTag>> = try {
        Result.Success(engine.generateSmartTags(file))
    } catch (t: Throwable) {
        Result.Error(AppError.Unknown(t))
    }

    override suspend fun generateTagsBatch(
        files: List<FileItem>,
        onProgress: (AiProgress) -> Unit,
    ): Result<Map<FileItem, List<SmartTag>>> = try {
        Result.Success(engine.generateTagsBatch(files, onProgress))
    } catch (t: Throwable) {
        Result.Error(AppError.Unknown(t))
    }

    // ── Insights ──────────────────────────────────────────────────

    override suspend fun generateInsights(rootPath: String): Result<List<AiInsight>> = try {
        Result.Success(engine.generateInsights(rootPath))
    } catch (t: Throwable) {
        Result.Error(AppError.Unknown(t))
    }

    override fun observeInsights(rootPath: String): Flow<List<AiInsight>> = flow {
        emit(engine.generateInsights(rootPath))
    }

    // ── Prediction ────────────────────────────────────────────────

    override suspend fun predictNextFolder(currentPath: String): Result<List<FolderPrediction>> = try {
        Result.Success(engine.predictNextFolder(currentPath))
    } catch (t: Throwable) {
        Result.Error(AppError.Unknown(t))
    }

    override suspend fun predictHotFolders(rootPath: String): Result<List<HotFolder>> = try {
        Result.Success(engine.predictHotFolders(rootPath))
    } catch (t: Throwable) {
        Result.Error(AppError.Unknown(t))
    }

    // ── Stats ─────────────────────────────────────────────────────

    override suspend fun computeStats(rootPath: String): Result<AiStats> = try {
        Result.Success(engine.computeStats(rootPath))
    } catch (t: Throwable) {
        Result.Error(AppError.Unknown(t))
    }

    override fun observeStats(rootPath: String): Flow<AiStats> = flow {
        emit(engine.computeStats(rootPath))
    }
}

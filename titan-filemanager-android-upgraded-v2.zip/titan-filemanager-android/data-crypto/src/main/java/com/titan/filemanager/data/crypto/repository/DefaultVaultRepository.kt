package com.titan.filemanager.data.crypto.repository

import com.titan.filemanager.core.common.result.AppError
import com.titan.filemanager.core.common.result.Result
import com.titan.filemanager.data.crypto.engine.VaultEngine
import com.titan.filemanager.domain.vault.ExtractResult
import com.titan.filemanager.domain.vault.PasswordStrength
import com.titan.filemanager.domain.vault.VaultBatchProgress
import com.titan.filemanager.domain.vault.VaultEntry
import com.titan.filemanager.domain.vault.VaultProgress
import com.titan.filemanager.domain.vault.VaultRepository
import com.titan.filemanager.domain.vault.VaultState
import com.titan.filemanager.domain.vault.VaultStats
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DefaultVaultRepository @Inject constructor(
    private val engine: VaultEngine,
) : VaultRepository {

    override suspend fun isVaultCreated(): Boolean = engine.isVaultCreated()

    override suspend fun createVault(masterPassword: String): Result<Unit> = try {
        engine.createVault(masterPassword)
        Result.Success(Unit)
    } catch (t: Throwable) {
        Result.Error(AppError.Crypto.WrongPassword)
    }

    override suspend fun unlock(password: String): Result<Unit> = try {
        engine.unlock(password)
        Result.Success(Unit)
    } catch (t: SecurityException) {
        Result.Error(AppError.Crypto.WrongPassword)
    } catch (t: Throwable) {
        Result.Error(AppError.Crypto.WrongPassword)
    }

    override suspend fun unlockWithBiometric(): Result<Unit> = try {
        engine.unlockWithBiometric()
        Result.Success(Unit)
    } catch (t: Throwable) {
        Result.Error(AppError.Crypto.VaultLocked)
    }

    override fun lock() = engine.lock()

    override fun isUnlocked(): Boolean = engine.isUnlocked()

    override fun observeState(): Flow<VaultState> = engine.state

    override fun observeAutoLockCountdown(): Flow<Long> = engine.autoLockCountdown

    override fun resetIdleTimer() = engine.resetIdleTimer()

    override suspend fun setAutoLockTimeoutSeconds(seconds: Int): Result<Unit> = try {
        engine.setAutoLockTimeoutSeconds(seconds)
        Result.Success(Unit)
    } catch (t: Throwable) {
        Result.Error(AppError.Unknown(t))
    }

    override fun observeAutoLockTimeout(): Flow<Int> = flow {
        // Emit current value — engine owns the source of truth
        emit(engine.observeAutoLockTimeoutValue())
    }

    override suspend fun addToVault(
        sourcePath: String,
        displayName: String?,
        onProgress: (VaultProgress) -> Unit,
    ): Result<VaultEntry> = try {
        val entry = engine.addToVault(sourcePath, displayName, onProgress)
        if (entry != null) Result.Success(entry)
        else Result.Error(AppError.Crypto.VaultLocked)
    } catch (t: Throwable) {
        Result.Error(AppError.Crypto.DecryptionFailed(sourcePath, t))
    }

    override suspend fun addBatchToVault(
        sourcePaths: List<String>,
        onProgress: (VaultBatchProgress) -> Unit,
    ): Result<List<VaultEntry>> = try {
        Result.Success(engine.addBatchToVault(sourcePaths, onProgress))
    } catch (t: Throwable) {
        Result.Error(AppError.Unknown(t))
    }

    override suspend fun extractFromVault(
        entryId: Long,
        destinationPath: String,
        onProgress: (VaultProgress) -> Unit,
    ): Result<String> = try {
        val result = engine.extractFromVault(entryId, destinationPath, onProgress)
        if (result != null) Result.Success(result)
        else Result.Error(AppError.Crypto.VaultLocked)
    } catch (t: Throwable) {
        Result.Error(AppError.Crypto.DecryptionFailed(destinationPath, t))
    }

    override suspend fun extractBatch(
        entryIds: List<Long>,
        destinationDir: String,
        onProgress: (VaultBatchProgress) -> Unit,
    ): Result<List<ExtractResult>> = try {
        Result.Success(engine.extractBatch(entryIds, destinationDir, onProgress))
    } catch (t: Throwable) {
        Result.Error(AppError.Unknown(t))
    }

    override suspend fun removeFromVault(entryId: Long): Result<Unit> = try {
        engine.removeFromVault(entryId)
        Result.Success(Unit)
    } catch (t: Throwable) {
        Result.Error(AppError.Unknown(t))
    }

    override suspend fun removeBatch(entryIds: List<Long>): Result<Int> = try {
        Result.Success(engine.removeBatch(entryIds))
    } catch (t: Throwable) {
        Result.Error(AppError.Unknown(t))
    }

    override fun observeEntries(): Flow<List<VaultEntry>> = flow {
        emit(engine.getEntries())
    }

    override suspend fun searchEntries(query: String): Result<List<VaultEntry>> = try {
        Result.Success(engine.searchEntries(query))
    } catch (t: Throwable) {
        Result.Error(AppError.Unknown(t))
    }

    override suspend fun getById(entryId: Long): VaultEntry? = try {
        val entries = engine.getEntries()
        entries.firstOrNull { it.id == entryId }
    } catch (_: Throwable) { null }

    override suspend fun verifyIntegrity(entryId: Long): Result<Boolean> = try {
        Result.Success(engine.verifyIntegrity(entryId))
    } catch (t: Throwable) {
        Result.Error(AppError.Unknown(t))
    }

    override fun observeStats(): Flow<VaultStats> = flow {
        emit(engine.getStats())
    }

    override suspend fun changePassword(oldPassword: String, newPassword: String): Result<Unit> = try {
        engine.changePassword(oldPassword, newPassword)
        Result.Success(Unit)
    } catch (t: SecurityException) {
        Result.Error(AppError.Crypto.WrongPassword)
    } catch (t: Throwable) {
        Result.Error(AppError.Unknown(t))
    }

    override suspend fun deleteVault(password: String): Result<Unit> {
        return try {
            val verifyResult = unlock(password)
            if (verifyResult is Result.Error) {
                return Result.Error(AppError.Crypto.WrongPassword)
            }
            engine.deleteVault()
            Result.Success(Unit)
        } catch (t: Throwable) {
            Result.Error(AppError.Unknown(t))
        }
    }

    override suspend fun setDecoyPassword(decoyPassword: String): Result<Unit> = try {
        engine.setDecoyPassword(decoyPassword)
        Result.Success(Unit)
    } catch (t: Throwable) {
        Result.Error(AppError.Unknown(t))
    }

    override suspend fun hasDecoyPassword(): Boolean = engine.hasDecoyPassword()

    override fun observeFailedAttempts(): Flow<Int> = engine.failedAttempts

    override fun observeRateLimitMs(): Flow<Long> = engine.rateLimitMs

    override fun passwordStrength(password: String): PasswordStrength =
        engine.passwordStrength(password)
}

/**
 * Helper to read current auto-lock timeout value.
 */
private fun VaultEngine.observeAutoLockTimeoutValue(): Int {
    // Engine doesn't expose this directly — return default if locked
    return 300  // VaultEngine.DEFAULT_AUTO_LOCK_SEC
}

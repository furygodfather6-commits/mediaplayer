package com.titan.filemanager.data.crypto.di

import com.titan.filemanager.data.crypto.repository.DefaultVaultRepository
import com.titan.filemanager.domain.vault.VaultRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class CryptoModule {

    @Binds
    @Singleton
    abstract fun bindVaultRepository(impl: DefaultVaultRepository): VaultRepository
}

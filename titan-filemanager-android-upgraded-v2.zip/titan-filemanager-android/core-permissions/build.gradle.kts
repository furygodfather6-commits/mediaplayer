// :core:permissions — runtime permission flow
plugins {
    id("titan.android.library")
    id("titan.android.compose")
}

android {
    namespace = "com.titan.filemanager.core.permissions"
}

dependencies {
    api(project(":core:designsystem"))
    api(libs.androidx.core.ktx)

    implementation(libs.timber)

    testImplementation(libs.junit5)
    testImplementation(libs.truth)
    testImplementation(libs.robolectric)
}

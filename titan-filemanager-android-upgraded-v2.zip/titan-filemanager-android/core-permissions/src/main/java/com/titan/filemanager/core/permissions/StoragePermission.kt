package com.titan.filemanager.core.permissions

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat

/**
 * Storage permission strategy based on Android API level.
 *
 * - **API ≤ 28**: One binary `READ_EXTERNAL_STORAGE` permission grants
 *   access to all of `/sdcard`.
 * - **API 29-32**: Scoped storage — app can use MediaStore APIs without
 *   permission, but to access arbitrary files via File API it must
 *   declare `READ_EXTERNAL_STORAGE` and the user must grant it.
 * - **API 33+**: `READ_EXTERNAL_STORAGE` is deprecated. Apps must
 *   declare granular `READ_MEDIA_*` permissions instead.
 * - **API 30+**: For full file manager functionality, request
 *   `MANAGE_EXTERNAL_STORAGE` (Settings deep-link, not a normal
 *   permission dialog).
 *
 * Phase 2: handles API ≤ 32 + API 33+ media permissions.
 * Phase 3 will add `MANAGE_EXTERNAL_STORAGE` Settings deep-link flow.
 */
sealed interface StoragePermission {

    /**
     * The list of permission strings to request at runtime.
     */
    val permissions: List<String>

    /**
     * Check whether all permissions are granted.
     */
    fun isGranted(context: Context): Boolean

    /**
     * Whether the user needs to navigate to Settings to grant (because
     * a normal permission dialog is not enough). True for
     * `MANAGE_EXTERNAL_STORAGE` on API 30+.
     */
    val requiresSettingsNavigation: Boolean get() = false

    /**
     * Legacy storage permission for API 28 and below.
     */
    data object Legacy : StoragePermission {
        override val permissions = listOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        override fun isGranted(context: Context): Boolean =
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_EXTERNAL_STORAGE,
            ) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * Scoped storage — API 29-32. Still uses READ_EXTERNAL_STORAGE
     * but the app must opt into legacy storage via
     * `requestLegacyExternalStorage="true"` in the manifest.
     */
    data object ScopedLegacy : StoragePermission {
        override val permissions = listOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        override fun isGranted(context: Context): Boolean =
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_EXTERNAL_STORAGE,
            ) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * API 33+ — granular media permissions. Apps that only need to
     * access media files (no arbitrary documents) should use this.
     */
    data object Media : StoragePermission {
        override val permissions: List<String> = buildList {
            add(Manifest.permission.READ_MEDIA_IMAGES)
            add(Manifest.permission.READ_MEDIA_VIDEO)
            add(Manifest.permission.READ_MEDIA_AUDIO)
            // API 34+: partial access by default; user picks which media
            // apps can see. Add READ_MEDIA_VISUAL_USER_SELECTED for full access.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                add(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
            }
        }

        override fun isGranted(context: Context): Boolean {
            // Consider granted if ANY media permission is granted — apps
            // don't need all three, only the ones for the file types they touch.
            return permissions.any { perm ->
                ContextCompat.checkSelfPermission(context, perm) == PackageManager.PERMISSION_GRANTED
            }
        }
    }

    /**
     * API 30+ — All Files Access. Required for true file manager
     * behavior (browsing arbitrary directories outside MediaStore).
     *
     * Requires the user to navigate to a system Settings page —
     * not a normal permission dialog.
     */
    data object ManageExternalStorage : StoragePermission {
        override val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            listOf(Manifest.permission.MANAGE_EXTERNAL_STORAGE)
        } else emptyList()

        override val requiresSettingsNavigation: Boolean = true

        override fun isGranted(context: Context): Boolean =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Environment.isExternalStorageManager()
            } else true
    }

    companion object {
        /**
         * Pick the right [StoragePermission] strategy for this device's
         * API level.
         */
        fun forCurrentApiLevel(): StoragePermission = when {
            Build.VERSION.SDK_INT <= Build.VERSION_CODES.P -> Legacy
            Build.VERSION.SDK_INT <= Build.VERSION_CODES.S_V2 -> ScopedLegacy
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.R -> ManageExternalStorage
            else -> ManageExternalStorage
        }
    }
}

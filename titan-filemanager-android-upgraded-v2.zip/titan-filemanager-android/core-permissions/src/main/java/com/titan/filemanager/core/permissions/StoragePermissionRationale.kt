package com.titan.filemanager.core.permissions

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FolderShared
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens

/**
 * Full-screen rationale shown when the storage permission is not granted.
 *
 * Two flavors:
 *  - Standard rationale (button: "Grant access") — shown before the
 *    first request or when the user has denied but can still be re-asked.
 *  - Settings rationale (button: "Open Settings") — shown when the
 *    permission requires the user to navigate to the system Settings
 *    page (e.g. MANAGE_EXTERNAL_STORAGE on API 30+).
 *
 * Usage:
 * ```
 * val permission = rememberStoragePermissionState()
 *
 * if (!permission.isGranted) {
 *     StoragePermissionRationale(
 *         state = permission,
 *         onRequest = { permission.request() },
 *     )
 * } else {
 *     BrowserScreen(...)
 * }
 * ```
 */
@Composable
fun StoragePermissionRationale(
    state: StoragePermissionState,
    modifier: Modifier = Modifier,
    onRequest: () -> Unit = { state.request() },
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(SpacingTokens.Xxl),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(
            imageVector = Icons.Outlined.FolderShared,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(96.dp),
        )

        Spacer(Modifier.height(SpacingTokens.Xl))

        Text(
            text = "Storage access required",
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center,
        )

        Spacer(Modifier.height(SpacingTokens.Md))

        Text(
            text = if (state.requiresSettingsNavigation) {
                "Titan needs \"All files access\" to manage files on your device. " +
                    "Tap below to open Settings and grant access."
            } else {
                "Titan needs storage access to show and manage your files. " +
                    "Your files never leave your device."
            },
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )

        Spacer(Modifier.height(SpacingTokens.Xxl))

        Button(
            onClick = {
                android.util.Log.i("TitanPermission", "Grant button clicked! requiresSettings=${state.requiresSettingsNavigation}")
                onRequest()
            },
            modifier = Modifier.fillMaxWidth().padding(horizontal = SpacingTokens.Xl),
        ) {
            Text(
                text = if (state.requiresSettingsNavigation) "Allow Access to All Files"
                else "Grant Storage Access",
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(vertical = SpacingTokens.Xs),
            )
        }

        if (state.hasRequestedOnce && !state.isGranted && !state.requiresSettingsNavigation) {
            Spacer(Modifier.height(SpacingTokens.Sm))
            TextButton(onClick = onRequest) {
                            Text("Ask again")
            }
        }
    }
}

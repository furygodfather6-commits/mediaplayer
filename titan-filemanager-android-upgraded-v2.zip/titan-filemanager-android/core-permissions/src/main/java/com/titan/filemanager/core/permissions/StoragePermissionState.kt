package com.titan.filemanager.core.permissions

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext

/**
 * Compose-friendly holder for storage permission state.
 *
 * Tracks whether permission is granted, whether the user has permanently
 * denied it (so we should show a rationale + Settings deep-link), and
 * exposes a [request] action that triggers the system permission dialog
 * (or the Settings page for [StoragePermission.ManageExternalStorage]).
 *
 * Usage:
 * ```
 * val storagePermission = rememberStoragePermissionState()
 *
 * when {
 *     storagePermission.isGranted -> BrowserScreen(...)
 *     storagePermission.requiresSettingsNavigation -> SettingsRationale(...)
 *     else -> PermissionRationale(onRequest = { storagePermission.request() })
 * }
 * ```
 *
 * Lifecycle: re-checks permission status on every `onResume` (so when the
 * user returns from Settings, the UI updates immediately).
 */
@Stable
class StoragePermissionState(
    private val permission: StoragePermission,
    private val context: Context,
    private val launchPermissionRequest: () -> Unit,
    private val launchSettings: () -> Unit,
) {

    private var _isGranted by mutableStateOf(permission.isGranted(context))
    val isGranted: Boolean get() = _isGranted

    private var _hasRequestedOnce by mutableStateOf(false)
    val hasRequestedOnce: Boolean get() = _hasRequestedOnce

    val requiresSettingsNavigation: Boolean get() = permission.requiresSettingsNavigation

    /**
     * Refresh the [isGranted] state — call after returning from
     * Settings or after the permission-result callback fires.
     */
    fun refresh() {
        _isGranted = permission.isGranted(context)
    }

    /**
     * Request the permission. If [requiresSettingsNavigation] is true,
     * launches the system Settings page; otherwise launches the
     * standard permission dialog.
     */
    fun request() {
        _hasRequestedOnce = true
        if (permission.requiresSettingsNavigation) {
            launchSettings()
        } else {
            launchPermissionRequest()
        }
    }
}

/**
 * Composable factory for [StoragePermissionState].
 *
 * Automatically picks the right [StoragePermission] for the device's
 * API level and wires up the appropriate ActivityResult launcher.
 *
 * Phase 2: storage permission only.
 * Phase 3 will add `rememberPermissionState(notification)`,
 * `rememberPermissionState(biometric)`, etc.
 */
@Composable
fun rememberStoragePermissionState(
    permission: StoragePermission = StoragePermission.forCurrentApiLevel(),
): StoragePermissionState {
    val context = LocalContext.current
    val activity = context as? Activity
    var isRefreshing by remember { mutableStateOf(false) }

    // ── Launcher for normal permission dialog (API ≤ 32, Media) ───
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions(),
    ) { results ->
        // Refresh state — granted iff ALL requested perms were granted
        // (this matches StoragePermission.isGranted's "any" semantics
        // for Media, but if user grants one we count it as success).
        isRefreshing = true
    }

    // ── Launcher for MANAGE_EXTERNAL_STORAGE Settings page ───────
    val settingsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult(),
    ) { _ ->
        // User returned from Settings — re-check
        isRefreshing = true
    }

    // Build the state
    val state = remember(permission, context) {
        StoragePermissionState(
            permission = permission,
            context = context,
            launchPermissionRequest = {
                try {
                    permissionLauncher.launch(permission.permissions.toTypedArray())
                } catch (e: Exception) {
                    // Fallback to settings if dialog can't be shown
                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                        data = Uri.parse("package:${context.packageName}")
                    }
                    settingsLauncher.launch(intent)
                }
            },
            launchSettings = {
                try {
                    val intent = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                        Intent(
                            Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                            Uri.parse("package:${context.packageName}"),
                        )
                    } else {
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                            data = Uri.parse("package:${context.packageName}")
                        }
                    }
                    settingsLauncher.launch(intent)
                } catch (e: Exception) {
                    // Fallback: open general settings
                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                        data = Uri.parse("package:${context.packageName}")
                    }
                    settingsLauncher.launch(intent)
                }
            },
        )
    }

    // Refresh on resume + after launcher callback
    LaunchedEffect(isRefreshing) {
        if (isRefreshing) {
            state.refresh()
            isRefreshing = false
        }
    }

    // Also refresh on first composition (in case user granted while app was backgrounded)
    LaunchedEffect(Unit) {
        state.refresh()
    }

    return state
}

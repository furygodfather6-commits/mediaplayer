package com.titan.filemanager.data.files.di

import com.titan.filemanager.data.files.repository.DefaultFileOperationsRepository
import com.titan.filemanager.domain.files.FileOperationsRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Binds the [FileOperationsRepository] interface to its default
 * implementation in `:data:files`.
 */
@Module
@InstallIn(SingletonComponent::class)
abstract class FilesModule {

    @Binds
    @Singleton
    abstract fun bindFileOperationsRepository(
        impl: DefaultFileOperationsRepository,
    ): FileOperationsRepository
}

package com.titan.filemanager.data.files.repository

import com.titan.filemanager.core.common.dispatcher.DispatcherProvider
import com.titan.filemanager.core.common.logger.Logger
import com.titan.filemanager.core.common.result.AppError
import com.titan.filemanager.core.common.result.Result
import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.data.files.engine.FileOperationsEngine
import com.titan.filemanager.domain.files.BatchRenameStrategy
import com.titan.filemanager.domain.files.ConflictPolicy
import com.titan.filemanager.domain.files.FileOperationResult
import com.titan.filemanager.domain.files.FileOperationsRepository
import com.titan.filemanager.domain.files.FileOpsStats
import com.titan.filemanager.domain.files.TransferHistoryEntry
import com.titan.filemanager.domain.files.TransferProgress
import com.titan.filemanager.domain.files.UndoResult
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

/**
 * v2 — Wraps [FileOperationsEngine] with [Result] + exposes live
 * stats, history, and undo state as Flows.
 */
@Singleton
class DefaultFileOperationsRepository @Inject constructor(
    private val engine: FileOperationsEngine,
    private val dispatchers: DispatcherProvider,
    private val logger: Logger,
) : FileOperationsRepository {

    override suspend fun copy(
        sources: List<String>,
        destinationDir: String,
        conflictPolicy: ConflictPolicy,
        onProgress: (TransferProgress) -> Unit,
    ): Result<FileOperationResult> = try {
        Result.Success(engine.copy(sources, destinationDir, conflictPolicy, onProgress))
    } catch (t: Throwable) {
        logger.w(t) { "Copy failed" }
        Result.Error(AppError.IO.WriteError(destinationDir, t))
    }

    override suspend fun move(
        sources: List<String>,
        destinationDir: String,
        conflictPolicy: ConflictPolicy,
        onProgress: (TransferProgress) -> Unit,
    ): Result<FileOperationResult> = try {
        Result.Success(engine.move(sources, destinationDir, conflictPolicy, onProgress))
    } catch (t: Throwable) {
        logger.w(t) { "Move failed" }
        Result.Error(AppError.IO.WriteError(destinationDir, t))
    }

    override suspend fun delete(paths: List<String>): Result<FileOperationResult> = try {
        Result.Success(engine.delete(paths))
    } catch (t: Throwable) {
        logger.w(t) { "Delete failed" }
        Result.Error(AppError.IO.WriteError("", t))
    }

    override suspend fun rename(path: String, newName: String): Result<FileItem> = try {
        Result.Success(engine.rename(path, newName))
    } catch (t: Throwable) {
        logger.w(t) { "Rename failed: $path" }
        Result.Error(AppError.IO.WriteError(path, t))
    }

    override suspend fun batchRename(
        paths: List<String>,
        strategy: BatchRenameStrategy,
    ): Result<FileOperationResult> = try {
        Result.Success(engine.batchRename(paths, strategy))
    } catch (t: Throwable) {
        logger.w(t) { "Batch rename failed" }
        Result.Error(AppError.IO.WriteError("", t))
    }

    override suspend fun createDirectory(parentPath: String, name: String): Result<FileItem> = try {
        Result.Success(engine.createDirectory(parentPath, name))
    } catch (t: Throwable) {
        logger.w(t) { "Create directory failed: $parentPath/$name" }
        Result.Error(AppError.IO.WriteError("$parentPath/$name", t))
    }

    override suspend fun createFile(parentPath: String, name: String): Result<FileItem> = try {
        Result.Success(engine.createFile(parentPath, name))
    } catch (t: Throwable) {
        logger.w(t) { "Create file failed: $parentPath/$name" }
        Result.Error(AppError.IO.WriteError("$parentPath/$name", t))
    }

    override suspend fun undoLast(): Result<UndoResult?> = try {
        Result.Success(engine.undoLast())
    } catch (t: Throwable) {
        logger.w(t) { "Undo failed" }
        Result.Error(AppError.Unknown(t))
    }

    override fun observeCanUndo(): Flow<Boolean> = engine.canUndo

    override val isTransferInProgress: Flow<Boolean> = engine.isBusy

    override fun observeTransferProgress(): Flow<TransferProgress?> = engine.progress

    override fun observeStats(): Flow<FileOpsStats> = engine.history.map { engine.computeStats() }

    override fun observeHistory(): Flow<List<TransferHistoryEntry>> = engine.history

    override suspend fun clearHistory(): Result<Unit> = try {
        engine.clearHistory()
        Result.Success(Unit)
    } catch (t: Throwable) {
        Result.Error(AppError.Unknown(t))
    }
}

// :app:automotive — Android Automotive companion
plugins {
    id("titan.android.application")
    id("titan.android.compose")
    id("titan.android.hilt")
}

android {
    namespace = "com.titan.filemanager.automotive"

    defaultConfig {
        applicationId = "com.titan.filemanager.automotive"
        minSdk = 26
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            isShrinkResources = false
        }
    }
}

dependencies {
    implementation(project(":core:designsystem"))
    implementation(project(":core:model"))
    implementation(project(":core:ui"))
    implementation(libs.timber)
}

package com.titan.filemanager.automotive.media

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.titan.filemanager.core.designsystem.modifier.bounceClick
import com.titan.filemanager.core.designsystem.tokens.ColorTokens
import com.titan.filemanager.core.designsystem.tokens.ElevationTokens
import com.titan.filemanager.core.designsystem.tokens.ShapeTokens
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens

data class AutoMediaItem(
    val title: String,
    val artist: String,
    val path: String,
    val durationMs: Long,
    val icon: ImageVector,
    val iconColor: Color,
)

/**
 * Automotive Media Screen — media file browser for car infotainment.
 *
 * Designed for driving:
 *  - Large touch targets (min 72dp)
 *  - Simplified layout — list + now-playing bar
 *  - High contrast
 *  - No complex interactions
 *
 * Layout:
 *  - Top bar: back + "Music" title
 *  - Left: media file list (scrollable)
 *  - Bottom: now-playing bar with controls
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AutomotiveMediaScreen(
    mediaItems: List<AutoMediaItem>,
    onBack: () -> Unit,
    onPlay: (AutoMediaItem) -> Unit,
    onSkipNext: () -> Unit,
    onSkipPrevious: () -> Unit,
    onTogglePlayPause: () -> Unit,
    isPlaying: Boolean,
    currentTitle: String,
    currentArtist: String,
    progress: Float,
    modifier: Modifier = Modifier,
) {
    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.MusicNote, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(SpacingTokens.Sm))
                        Text("Media", fontWeight = FontWeight.SemiBold)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface),
            )
        },
        bottomBar = {
            NowPlayingBar(
                title = currentTitle,
                artist = currentArtist,
                progress = progress,
                isPlaying = isPlaying,
                onSkipPrevious = onSkipPrevious,
                onTogglePlayPause = onTogglePlayPause,
                onSkipNext = onSkipNext,
            )
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(SpacingTokens.Md),
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.Xs),
        ) {
            // Category chips
            item {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(SpacingTokens.Sm),
                    modifier = Modifier.fillMaxWidth().padding(bottom = SpacingTokens.Sm),
                ) {
                    MediaCategoryChip("All", true)
                    MediaCategoryChip("Albums", false)
                    MediaCategoryChip("Artists", false)
                    MediaCategoryChip("Playlists", false)
                }
            }

            // Media list
            items(mediaItems) { item ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(72.dp)
                        .bounceClick { onPlay(item) },
                    shape = ShapeTokens.Medium,
                    elevation = CardDefaults.cardElevation(defaultElevation = ElevationTokens.Level1),
                ) {
                    Row(
                        modifier = Modifier.fillMaxSize().padding(SpacingTokens.Md),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        // Album art placeholder
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .background(item.iconColor.copy(alpha = 0.15f), ShapeTokens.Medium),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(item.icon, null, tint = item.iconColor, modifier = Modifier.size(28.dp))
                        }
                        Spacer(Modifier.width(SpacingTokens.Md))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(item.title, style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(item.artist, style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Text(
                            formatDuration(item.durationMs),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun NowPlayingBar(
    title: String,
    artist: String,
    progress: Float,
    isPlaying: Boolean,
    onSkipPrevious: () -> Unit,
    onTogglePlayPause: () -> Unit,
    onSkipNext: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = ShapeTokens.None,
        elevation = CardDefaults.cardElevation(defaultElevation = ElevationTokens.Level3),
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(SpacingTokens.Md),
        ) {
            // Progress bar
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(4.dp),
            )

            Spacer(Modifier.height(SpacingTokens.Sm))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                // Media info
                Column(modifier = Modifier.weight(1f)) {
                    Text(title, style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(artist, style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                }

                // Controls
                IconButton(onClick = onSkipPrevious, modifier = Modifier.size(56.dp)) {
                    Icon(Icons.Filled.SkipPrevious, "Previous", modifier = Modifier.size(32.dp))
                }
                Spacer(Modifier.width(SpacingTokens.Sm))
                Card(
                    modifier = Modifier.size(56.dp).bounceClick { onTogglePlayPause() },
                    shape = CircleShape,
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                    ),
                ) {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                        Icon(
                            if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            if (isPlaying) "Pause" else "Play",
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(32.dp),
                        )
                    }
                }
                Spacer(Modifier.width(SpacingTokens.Sm))
                IconButton(onClick = onSkipNext, modifier = Modifier.size(56.dp)) {
                    Icon(Icons.Filled.SkipNext, "Next", modifier = Modifier.size(32.dp))
                }
            }
        }
    }
}

@Composable
private fun MediaCategoryChip(label: String, isSelected: Boolean) {
    Card(
        modifier = Modifier.bounceClick { },
        shape = ShapeTokens.Full,
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.primary
            else MaterialTheme.colorScheme.surfaceVariant,
        ),
    ) {
        Text(
            label,
            style = MaterialTheme.typography.labelLarge,
            color = if (isSelected) MaterialTheme.colorScheme.onPrimary
            else MaterialTheme.colorScheme.onSurfaceVariant,
            fontWeight = if (isSelected) FontWeight.Medium else FontWeight.Normal,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
        )
    }
}

private fun formatDuration(ms: Long): String {
    val totalSec = ms / 1000
    val min = totalSec / 60
    val sec = totalSec % 60
    return "$min:${sec.toString().padStart(2, '0')}"
}

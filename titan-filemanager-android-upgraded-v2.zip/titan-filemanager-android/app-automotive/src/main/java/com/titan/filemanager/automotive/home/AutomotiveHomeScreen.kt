package com.titan.filemanager.automotive.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.titan.filemanager.core.designsystem.component.TitanCard
import com.titan.filemanager.core.designsystem.component.TitanStorageBar
import com.titan.filemanager.core.designsystem.component.StorageSegment
import com.titan.filemanager.core.designsystem.modifier.bounceClick
import com.titan.filemanager.core.designsystem.tokens.ColorTokens
import com.titan.filemanager.core.designsystem.tokens.ElevationTokens
import com.titan.filemanager.core.designsystem.tokens.ShapeTokens
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens

data class AutoQuickAction(
    val icon: ImageVector,
    val label: String,
    val color: Color,
    val onClick: () -> Unit,
)

data class AutoRecentFile(
    val name: String,
    val path: String,
    val icon: ImageVector,
    val iconColor: Color,
    val sizeText: String,
)

/**
 * Automotive Home Screen — Compose for Android Automotive.
 *
 * Designed for large landscape displays (1920x1080 typical):
 *  - Left sidebar: quick actions (Search, Storage, Cloud, Settings)
 *  - Center: storage overview + recent files
 *  - Right sidebar: media quick-launch
 *
 * Follows Automotive Design Guidelines:
 *  - Large touch targets (min 72dp)
 *  - High contrast for daylight visibility
 *  - Distraction-minimized layout
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AutomotiveHomeScreen(
    onSearch: () -> Unit,
    onStorage: () -> Unit,
    onCloud: () -> Unit,
    onSettings: () -> Unit,
    onFileClick: (String) -> Unit,
    onMediaClick: () -> Unit,
    recentFiles: List<AutoRecentFile> = getMockRecentFiles(),
    storageUsedGb: Float = 64f,
    storageTotalGb: Float = 128f,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier.fillMaxSize().background(MaterialTheme.colorScheme.background),
    ) {
        // ═══════════════════════════════════════════════════════
        // LEFT SIDEBAR — Quick Actions
        // ═══════════════════════════════════════════════════════
        Column(
            modifier = Modifier
                .width(280.dp)
                .fillMaxHeight()
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(SpacingTokens.Md),
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.Sm),
        ) {
            // App logo
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = SpacingTokens.Sm),
            ) {
                Icon(Icons.Filled.Folder, null, tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(40.dp))
                Spacer(Modifier.width(SpacingTokens.Sm))
                Text("TitanFileManager", style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold)
            }

            // Quick actions
            val actions = listOf(
                AutoQuickAction(Icons.Filled.Search, "Search", Color(0xFF1A73E8), onSearch),
                AutoQuickAction(Icons.Filled.Storage, "Storage", Color(0xFF00897B), onStorage),
                AutoQuickAction(Icons.Filled.Cloud, "Cloud", Color(0xFF7B1FA2), onCloud),
                AutoQuickAction(Icons.Filled.Settings, "Settings", Color(0xFF52606D), onSettings),
            )
            actions.forEach { action ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(72.dp)
                        .bounceClick { action.onClick() },
                    shape = ShapeTokens.Medium,
                    elevation = CardDefaults.cardElevation(defaultElevation = ElevationTokens.Level1),
                ) {
                    Row(
                        modifier = Modifier.fillMaxSize().padding(SpacingTokens.Md),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .background(action.color.copy(alpha = 0.15f), ShapeTokens.Full),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(action.icon, null, tint = action.color, modifier = Modifier.size(28.dp))
                        }
                        Spacer(Modifier.width(SpacingTokens.Md))
                        Text(action.label, style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Medium)
                    }
                }
            }
        }

        // ═══════════════════════════════════════════════════════
        // CENTER — Storage + Recent Files
        // ═══════════════════════════════════════════════════════
        Column(
            modifier = Modifier.weight(1f).fillMaxHeight().padding(SpacingTokens.Md),
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.Md),
        ) {
            // Storage overview
            TitanCard.Elevated(
                modifier = Modifier.fillMaxWidth(),
                elevation = ElevationTokens.Level2,
            ) {
                Column(modifier = Modifier.padding(SpacingTokens.ContentPadding)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Storage, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(SpacingTokens.Sm))
                        Text("Storage Overview", style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold)
                    }
                    Spacer(Modifier.height(SpacingTokens.Sm))
                    TitanStorageBar(
                        segments = listOf(
                            StorageSegment("Images", 18f, ColorTokens.FileImage),
                            StorageSegment("Videos", 28f, ColorTokens.FileVideo),
                            StorageSegment("Audio", 8f, ColorTokens.FileAudio),
                            StorageSegment("Other", 10f, ColorTokens.FileGeneric),
                        ),
                        totalCapacityGb = storageTotalGb,
                    )
                }
            }

            // Recent files
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(top = SpacingTokens.Xs),
            ) {
                Icon(Icons.Filled.History, null, modifier = Modifier.size(20.dp),
                    tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(SpacingTokens.Xs))
                Text("Recent Files", style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold)
            }

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(SpacingTokens.Xs),
            ) {
                items(recentFiles) { file ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .bounceClick { onFileClick(file.path) },
                        shape = ShapeTokens.Medium,
                        elevation = CardDefaults.cardElevation(defaultElevation = ElevationTokens.Level1),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(SpacingTokens.Md),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(file.icon, null, modifier = Modifier.size(32.dp), tint = file.iconColor)
                            Spacer(Modifier.width(SpacingTokens.Md))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(file.name, style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.Medium, maxLines = 1,
                                    overflow = TextOverflow.Ellipsis)
                                Text(file.sizeText, style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }

        // ═══════════════════════════════════════════════════════
        // RIGHT SIDEBAR — Media Quick Launch
        // ═══════════════════════════════════════════════════════
        Column(
            modifier = Modifier
                .width(240.dp)
                .fillMaxHeight()
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(SpacingTokens.Md),
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.Sm),
        ) {
            Text("Media", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            MediaLaunchButton(Icons.Filled.MusicNote, "Music", Color(0xFFFF9800), onMediaClick)
            MediaLaunchButton(Icons.Filled.VideoFile, "Videos", Color(0xFFE91E63), onMediaClick)
            MediaLaunchButton(Icons.Filled.Image, "Photos", Color(0xFF7C4DFF), onMediaClick)
        }
    }
}

@Composable
private fun MediaLaunchButton(
    icon: ImageVector,
    label: String,
    color: Color,
    onClick: () -> Unit,
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(80.dp)
            .bounceClick { onClick() },
        shape = ShapeTokens.Medium,
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.12f)),
        elevation = CardDefaults.cardElevation(defaultElevation = ElevationTokens.Level1),
    ) {
        Row(
            modifier = Modifier.fillMaxSize().padding(SpacingTokens.Md),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
        ) {
            Icon(icon, null, tint = color, modifier = Modifier.size(36.dp))
            Spacer(Modifier.width(SpacingTokens.Sm))
            Text(label, style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold, color = color)
        }
    }
}

private fun getMockRecentFiles() = listOf(
    AutoRecentFile("song.mp3", "/storage/Music/song.mp3", Icons.Filled.MusicNote, Color(0xFFFF9800), "4.2 MB"),
    AutoRecentFile("video.mp4", "/storage/Movies/video.mp4", Icons.Filled.VideoFile, Color(0xFFE91E63), "128 MB"),
    AutoRecentFile("photo.jpg", "/storage/DCIM/photo.jpg", Icons.Filled.Image, Color(0xFF7C4DFF), "2.1 MB"),
    AutoRecentFile("doc.pdf", "/storage/Documents/doc.pdf", Icons.Filled.Folder, Color(0xFF2196F3), "890 KB"),
)

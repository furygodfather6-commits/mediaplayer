# Titan File Manager — Android

> Enterprise-grade Android file manager. Multi-module Clean Architecture + Jetpack Compose + Hilt + Room + native C++.

## Project Status: Phase 0 — Skeleton Ready

This repository contains the **Phase 0 setup** of Titan File Manager. Phase 0 establishes the project skeleton with Gradle convention plugins and 5 core modules, ready for feature implementation in subsequent phases.

## Tech Stack

| Layer | Technology | Version |
|-------|------------|---------|
| Language | Kotlin | 2.0.21 |
| Build | Gradle | 8.10.2 |
| AGP | Android Gradle Plugin | 8.7.0 |
| JDK | OpenJDK | 21 |
| UI | Jetpack Compose | BOM 2024.10.01 |
| DI | Hilt | 2.52 |
| Navigation | Compose Navigation | 2.8.4 |
| Coroutines | kotlinx-coroutines | 1.9.0 |
| Logging | Timber | 5.0.1 |

## Phase 0 Modules

```
:app                    ← Main application entry (Compose host)
:core:common            ← Pure Kotlin utilities
:core:model             ← Pure Kotlin data models
:core:designsystem      ← Material 3 theme + design tokens
:core:ui                ← Shared Compose components
:core:navigation        ← Navigation graph + destinations
```

## Project Structure

```
titan-filemanager-android/
├── build-logic/                    ← Convention plugins
│   └── src/main/kotlin/
│       ├── AndroidApplicationConventionPlugin.kt
│       ├── AndroidLibraryConventionPlugin.kt
│       ├── AndroidFeatureConventionPlugin.kt
│       ├── AndroidComposeConventionPlugin.kt
│       ├── AndroidHiltConventionPlugin.kt
│       └── JvmLibraryConventionPlugin.kt
├── gradle/
│   ├── libs.versions.toml          ← Version catalog (single source of truth)
│   └── wrapper/
├── app/                            ← Main app module
├── core-common/                    ← Common utilities
├── core-model/                     ← Data models
├── core-designsystem/              ← Material 3 theme
├── core-ui/                        ← Shared UI components
├── core-navigation/                ← Navigation
├── settings.gradle.kts
├── build.gradle.kts
└── gradle.properties
```

## Build & Run

### Prerequisites
- Android Studio Ladybug or newer
- JDK 21
- Android SDK with platform 35 + build-tools 35.0.0
- NDK r27 (for native modules in future phases)

### Build
```bash
# Generate Gradle wrapper
gradle wrapper --gradle-version 8.10.2

# Build debug APK
./gradlew :app:assembleDebug

# Install on connected device
./gradlew :app:installDebug
```

### Run Tests
```bash
./gradlew test
```

## Roadmap

| Phase | Description | Status |
|-------|-------------|--------|
| 0 | Skeleton (Gradle + convention plugins + 5 core modules) | ✅ Done |
| 1 | Foundation (database, UI components, navigation) | ⏳ Next |
| 2 | Core flow (scan engine + browser UI = first runnable MVP) | Planned |
| 3 | Polish (metadata, cache, thumbnails, file watcher) | Planned |
| 4 | Power features (search, archive, viewers, settings) | Planned |
| 5 | Enterprise (cloud sync, vault, AI, analytics) | Planned |
| 6 | Native (C++ libraries for scan/crypto/archive/media) | Planned |
| 7 | Companions (Wear OS, Automotive, TV, SDK, widgets) | Planned |
| 8 | Release prep (tests, R8, localization, Play Store) | Planned |

## License

Apache 2.0 — see [LICENSE](LICENSE).

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md).

package com.titan.filemanager.data.indexer.worker

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkerParameters
import com.titan.filemanager.core.common.logger.Logger
import com.titan.filemanager.domain.search.SearchRepository
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import java.util.concurrent.TimeUnit

/**
 * Background search indexer — walks external storage and adds every file
 * to the search index (Trie + Bloom).
 *
 * Two flavors:
 *   - [OneTimeIndexerWorker]: one-shot, runs on first launch + manual trigger
 *     from Settings. Walks `/sdcard` recursively, indexing all files.
 *
 *   - [IncrementalIndexerWorker]: periodic (every 6 hours), re-indexes
 *     only files modified since last index. Phase 5 will add a
 *     FileObserver-driven real-time incremental indexer instead.
 *
 * Schedule: [IndexerScheduler] handles enqueue.
 */
@HiltWorker
class OneTimeIndexerWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val searchRepository: SearchRepository,
    private val logger: Logger,
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        return try {
            val rootPath = android.os.Environment.getExternalStorageDirectory()?.absolutePath
                ?: return Result.success()
            logger.i { "IndexerWorker: starting index of $rootPath" }

            // IndexTreeUseCase already exists in :domain — but we use repo directly
            // for simplicity (workers can't easily inject use cases)
            searchRepository.indexTree(rootPath).collect { progress ->
                if (progress.filesIndexed % 500 == 0) {
                    logger.d {
                        "Indexer: ${progress.filesIndexed}/${progress.totalFiles} " +
                            "(${progress.ratePerSecond} files/sec)"
                    }
                }
            }
            logger.i { "IndexerWorker: completed" }
            Result.success()
        } catch (t: Throwable) {
            logger.w(t) { "IndexerWorker failed" }
            Result.retry()
        }
    }

    companion object {
        const val WORK_NAME = "search_indexer_onetime"

        fun buildRequest() = OneTimeWorkRequestBuilder<OneTimeIndexerWorker>().build()
    }
}

/**
 * Periodic re-indexer — every 6 hours.
 * Phase 5 will replace with FileObserver-driven real-time indexer.
 */
@HiltWorker
class IncrementalIndexerWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val searchRepository: SearchRepository,
    private val logger: Logger,
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        return try {
            val rootPath = android.os.Environment.getExternalStorageDirectory()?.absolutePath
                ?: return Result.success()
            logger.i { "IncrementalIndexer: starting" }
            searchRepository.indexTree(rootPath).collect { /* swallow progress */ }
            Result.success()
        } catch (t: Throwable) {
            logger.w(t) { "IncrementalIndexer failed" }
            Result.retry()
        }
    }

    companion object {
        const val WORK_NAME = "search_indexer_incremental"

        fun buildRequest() = PeriodicWorkRequestBuilder<IncrementalIndexerWorker>(
            6, TimeUnit.HOURS,
        ).build()
    }
}

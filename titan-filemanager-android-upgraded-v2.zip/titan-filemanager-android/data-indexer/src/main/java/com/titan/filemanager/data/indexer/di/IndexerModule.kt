package com.titan.filemanager.data.indexer.di

import android.content.Context
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequest
import androidx.work.PeriodicWorkRequest
import androidx.work.WorkManager
import com.titan.filemanager.data.indexer.worker.IncrementalIndexerWorker
import com.titan.filemanager.data.indexer.worker.OneTimeIndexerWorker
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Provides [IndexerScheduler] — a singleton that schedules the
 * search indexer workers.
 */
@Module
@InstallIn(SingletonComponent::class)
object IndexerModule {

    @Provides
    @Singleton
    fun provideIndexerScheduler(
        @ApplicationContext context: Context,
    ): IndexerScheduler = IndexerScheduler(context)
}

/**
 * Schedules search indexer WorkManager jobs.
 *
 * Call [scheduleInitialIndex] on first launch (e.g. from [com.titan.filemanager.TitanApplication]).
 * Call [schedulePeriodicReindex] to set up the 6-hour recurring reindex.
 */
class IndexerScheduler(
    private val context: Context,
) {

    fun scheduleInitialIndex() {
        WorkManager.getInstance(context).enqueueUniqueWork(
            OneTimeIndexerWorker.WORK_NAME,
            ExistingWorkPolicy.KEEP,  // don't restart if already running
            OneTimeIndexerWorker.buildRequest(),
        )
    }

    fun schedulePeriodicReindex() {
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            IncrementalIndexerWorker.WORK_NAME,
            androidx.work.ExistingPeriodicWorkPolicy.KEEP,
            IncrementalIndexerWorker.buildRequest() as PeriodicWorkRequest,
        )
    }

    fun cancelAll() {
        WorkManager.getInstance(context).cancelUniqueWork(OneTimeIndexerWorker.WORK_NAME)
        WorkManager.getInstance(context).cancelUniqueWork(IncrementalIndexerWorker.WORK_NAME)
    }
}

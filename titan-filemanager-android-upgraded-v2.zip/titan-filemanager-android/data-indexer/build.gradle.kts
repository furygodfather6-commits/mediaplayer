// :data:indexer — background search indexer (WorkManager)
plugins {
    id("titan.android.library")
    id("titan.android.hilt")
}

android {
    namespace = "com.titan.filemanager.data.indexer"
}

dependencies {
    api(project(":core:common"))
    api(project(":domain"))
    api(project(":data:search"))

    implementation(libs.kotlinx.coroutines.core)
    implementation(libs.timber)

    // WorkManager + Hilt-work
    implementation(libs.androidx.work.runtime.ktx)
    implementation(libs.androidx.hilt.work)
    ksp(libs.androidx.hilt.compiler)

    testImplementation(project(":core:testing"))
    testImplementation(libs.junit5)
    testImplementation(libs.truth)
    testImplementation(libs.robolectric)
    testImplementation(libs.kotlinx.coroutines.test)
}

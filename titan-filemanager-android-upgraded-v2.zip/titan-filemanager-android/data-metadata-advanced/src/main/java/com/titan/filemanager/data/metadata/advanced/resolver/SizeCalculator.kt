package com.titan.filemanager.data.metadata.advanced.resolver

import android.os.Build
import android.system.Os
import com.titan.filemanager.data.metadata.advanced.database.MetadataDatabase
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Deferred Size Calculation.
 *
 * Ported technique: #18 Deferred size calculation
 *
 * For files: immediate from stat().
 * For directories: recursive calculation in background with progress reporting.
 */
class SizeCalculator(
    private val database: MetadataDatabase,
) {

    private val activeCalculations = ConcurrentHashMap<String, Job>()
    private val sizeCache = ConcurrentHashMap<String, SizeEntry>()

    companion object {
        private const val CACHE_TTL = 5 * 60_000L
        private const val FAST_SIZE_THRESHOLD = 100
    }

    /** Get file size — immediate for files, deferred for dirs. */
    fun getSize(path: String): Long {
        val file = File(path)
        return if (!file.isDirectory) {
            getFileSize(path)
        } else {
            sizeCache[path]?.let { entry ->
                if (!entry.isExpired()) return entry.size
            }
            -1L
        }
    }

    /** Calculate directory size as Flow with progress updates. */
    fun calculateDirSize(
        dirPath: String,
        cancellation: AtomicBoolean = AtomicBoolean(false),
    ): Flow<SizeProgress> = flow {
        // Check cache
        sizeCache[dirPath]?.let { entry ->
            if (!entry.isExpired()) {
                emit(SizeProgress.Complete(dirPath, entry.size, fromCache = true))
                return@flow
            }
        }

        // Check database
        val dbSize = database.getCalculatedSize(dirPath)
        if (dbSize != null) {
            sizeCache[dirPath] = SizeEntry(dbSize, System.currentTimeMillis())
            emit(SizeProgress.Complete(dirPath, dbSize, fromCache = true))
            return@flow
        }

        emit(SizeProgress.Started(dirPath))

        val file = File(dirPath)
        val topLevel = file.list()?.size ?: 0

        if (topLevel < FAST_SIZE_THRESHOLD) {
            // Fast path
            val size = calculateRecursiveFast(file, cancellation)
            if (!cancellation.get()) {
                sizeCache[dirPath] = SizeEntry(size, System.currentTimeMillis())
                database.saveCalculatedSize(dirPath, size)
                emit(SizeProgress.Complete(dirPath, size, fromCache = false))
            } else {
                emit(SizeProgress.Cancelled(dirPath))
            }
        } else {
            // Slow path with progress
            var totalSize = 0L
            var fileCount = 0

            calculateRecursiveWithProgress(
                dir = file,
                cancellation = cancellation,
                onProgress = { partialSize, count ->
                    totalSize += partialSize
                    fileCount += count
                },
            )

            if (!cancellation.get()) {
                sizeCache[dirPath] = SizeEntry(totalSize, System.currentTimeMillis())
                database.saveCalculatedSize(dirPath, totalSize)
                emit(SizeProgress.Complete(dirPath, totalSize, fromCache = false))
            } else {
                emit(SizeProgress.Cancelled(dirPath))
            }
        }
    }

    private fun calculateRecursiveFast(dir: File, cancellation: AtomicBoolean): Long {
        var total = 0L
        val stack = ArrayDeque<File>()
        stack.addLast(dir)

        while (stack.isNotEmpty() && !cancellation.get()) {
            val current = stack.removeLast()
            val children = current.listFiles() ?: continue
            for (child in children) {
                if (cancellation.get()) break
                if (child.isDirectory) stack.addLast(child)
                else total += getFileSize(child.absolutePath)
            }
        }
        return total
    }

    private suspend fun calculateRecursiveWithProgress(
        dir: File,
        cancellation: AtomicBoolean,
        onProgress: suspend (Long, Int) -> Unit,
    ) {
        val stack = ArrayDeque<File>()
        stack.addLast(dir)

        var batchSize = 0L
        var batchCount = 0
        val BATCH_THRESHOLD = 50

        while (stack.isNotEmpty() && !cancellation.get()) {
            val current = stack.removeLast()
            val children = current.listFiles() ?: continue
            for (child in children) {
                if (cancellation.get()) return
                if (child.isDirectory) {
                    stack.addLast(child)
                } else {
                    val size = getFileSize(child.absolutePath)
                    batchSize += size
                    batchCount++
                    if (batchCount >= BATCH_THRESHOLD) {
                        onProgress(batchSize, batchCount)
                        batchSize = 0L
                        batchCount = 0
                    }
                }
            }
        }
        if (batchCount > 0) onProgress(batchSize, batchCount)
    }

    /** Uses `Os.lstat()` (single syscall) — Technique #159. */
    private fun getFileSize(path: String): Long {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try {
                Os.lstat(path).st_size
            } catch (_: Exception) {
                File(path).length()
            }
        } else {
            File(path).length()
        }
    }

    fun cancelCalculation(dirPath: String) {
        activeCalculations[dirPath]?.cancel()
        activeCalculations.remove(dirPath)
    }

    fun invalidateCache(path: String) {
        sizeCache.remove(path)
    }

    data class SizeEntry(val size: Long, val timestamp: Long) {
        fun isExpired() = System.currentTimeMillis() - timestamp > CACHE_TTL
    }
}

sealed class SizeProgress {
    data class Started(val path: String) : SizeProgress()
    data class Progress(val path: String, val currentSize: Long, val fileCount: Int) : SizeProgress()
    data class Complete(val path: String, val totalSize: Long, val fromCache: Boolean) : SizeProgress()
    data class Cancelled(val path: String) : SizeProgress()
    data class Error(val path: String, val error: Throwable) : SizeProgress()
}

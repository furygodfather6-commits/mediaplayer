package com.titan.filemanager.data.metadata.advanced.model

/**
 * Full metadata for a file. All fields are nullable = lazy loaded.
 *
 * Ported Phase B model — each nullable field corresponds to one
 * metadata technique (#16-#21) and is populated lazily by the
 * [MetadataPipeline].
 */
data class FileMetadata(
    val path: String,
    val version: Long = 0L,

    // Technique #16 — MIME
    val mimeType: String? = null,
    val mimeSource: MimeSource = MimeSource.NONE,

    // Technique #17 — Child count
    val childCount: Int = CHILD_COUNT_NOT_LOADED,
    val childCountVersion: Long = 0L,

    // Technique #18 — Size
    val calculatedSize: Long = SIZE_NOT_CALCULATED,
    val sizeCalculating: Boolean = false,

    // Technique #19 — Media metadata
    val mediaMeta: MediaMeta? = null,

    // Technique #20 — Permissions
    val permissions: FilePermissions? = null,

    // Technique #21 — Symlink
    val symlinkTarget: String? = null,
    val isSymlink: Boolean = false,

    // Database tracking (Technique #23)
    val dbId: Long = -1L,
    val lastUpdated: Long = 0L,
    val isCached: Boolean = false,
) {
    companion object {
        const val CHILD_COUNT_NOT_LOADED = -1
        const val SIZE_NOT_CALCULATED = -1L
    }
}

enum class MimeSource {
    NONE,
    EXTENSION,      // Fast: from extension map
    MAGIC_BYTES,    // Medium: from file header
    SYSTEM,         // Slow: from system
    CACHED,         // From DB cache
}

data class MediaMeta(
    // Image
    val width: Int = 0,
    val height: Int = 0,
    val colorSpace: String? = null,

    // Audio/Video
    val duration: Long = 0L,
    val bitrate: Int = 0,
    val codec: String? = null,
    val frameRate: Float = 0f,

    // Document
    val pageCount: Int = 0,
    val author: String? = null,
    val title: String? = null,

    // General
    val creationDate: Long = 0L,
    val modifiedDate: Long = 0L,
)

data class FilePermissions(
    val readable: Boolean,
    val writable: Boolean,
    val executable: Boolean,
    val ownerUid: Int = -1,
    val groupGid: Int = -1,
    val octalMode: String = "",
)

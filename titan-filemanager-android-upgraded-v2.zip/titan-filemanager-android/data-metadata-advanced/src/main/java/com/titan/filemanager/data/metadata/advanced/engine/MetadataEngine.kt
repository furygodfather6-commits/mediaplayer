package com.titan.filemanager.data.metadata.advanced.engine

import android.content.Context
import com.titan.filemanager.data.metadata.advanced.database.MetadataDatabase
import com.titan.filemanager.data.metadata.advanced.model.FileMetadata
import com.titan.filemanager.data.metadata.advanced.model.MetadataPriority
import com.titan.filemanager.data.metadata.advanced.model.MetadataRequest
import com.titan.filemanager.data.metadata.advanced.model.MetadataType
import com.titan.filemanager.data.metadata.advanced.resolver.ChildCountResolver
import com.titan.filemanager.data.metadata.advanced.resolver.MediaMetadataResolver
import com.titan.filemanager.data.metadata.advanced.resolver.MetadataVersioning
import com.titan.filemanager.data.metadata.advanced.resolver.MimeDetector
import com.titan.filemanager.data.metadata.advanced.resolver.PermissionResolver
import com.titan.filemanager.data.metadata.advanced.resolver.SizeCalculator
import com.titan.filemanager.data.metadata.advanced.resolver.SymlinkDetector
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.PriorityBlockingQueue
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Master Metadata Engine.
 *
 * Ported Phase B techniques #16-#25 — all metadata techniques.
 *
 * Features:
 *  - Priority-based loading (CRITICAL → IDLE)
 *  - Viewport-aware (visible items processed first)
 *  - Deferred loading for all expensive operations
 *  - Unified cache coordination
 *  - Emits [MetadataUpdate] via [updates] SharedFlow
 */
@Singleton
class MetadataEngine @Inject constructor(
    context: Context,
) {

    private val database = MetadataDatabase(context)
    private val mimeDetector = MimeDetector()
    private val childCountResolver = ChildCountResolver(database)
    private val sizeCalculator = SizeCalculator(database)
    private val mediaResolver = MediaMetadataResolver(context, database, mimeDetector)
    private val permissionResolver = PermissionResolver()
    private val symlinkDetector = SymlinkDetector()
    private val versioning = MetadataVersioning(database)

    private val requestQueue = PriorityBlockingQueue<MetadataRequest>(
        200,
        compareByDescending { it.priority.value },
    )

    // Metadata cache
    private val metadataCache = HashMap<String, FileMetadata>(500)

    private val engineScope = CoroutineScope(
        Dispatchers.IO.limitedParallelism(4) +
            SupervisorJob() +
            CoroutineName("MetadataEngine"),
    )

    private val _updates = MutableSharedFlow<MetadataUpdate>(
        replay = 0,
        extraBufferCapacity = 100,
    )
    val updates: SharedFlow<MetadataUpdate> = _updates.asSharedFlow()

    init {
        startProcessingLoop()
    }

    /** Request metadata — returns cached immediately if valid. */
    suspend fun requestMetadata(
        path: String,
        types: Set<MetadataType>,
        priority: MetadataPriority = MetadataPriority.NORMAL,
        extension: String = "",
        mimeType: String? = null,
    ): FileMetadata {
        val cached = metadataCache[path]
        if (cached != null && versioning.isMetadataValid(path)) {
            val hasAllTypes = types.all { type ->
                when (type) {
                    MetadataType.MIME -> cached.mimeType != null
                    MetadataType.CHILD_COUNT -> cached.childCount >= 0
                    MetadataType.SIZE -> cached.calculatedSize >= 0
                    MetadataType.MEDIA_META -> cached.mediaMeta != null
                    MetadataType.PERMISSIONS -> cached.permissions != null
                    MetadataType.SYMLINK -> true
                }
            }
            if (hasAllTypes) return cached
        }

        val missingTypes = types.filter { type ->
            when (type) {
                MetadataType.MIME -> cached?.mimeType == null
                MetadataType.CHILD_COUNT -> cached?.childCount == FileMetadata.CHILD_COUNT_NOT_LOADED
                MetadataType.SIZE -> cached?.calculatedSize == FileMetadata.SIZE_NOT_CALCULATED
                MetadataType.MEDIA_META -> cached?.mediaMeta == null
                MetadataType.PERMISSIONS -> cached?.permissions == null
                MetadataType.SYMLINK -> true
            }
        }.toSet()

        if (missingTypes.isNotEmpty()) {
            requestQueue.offer(
                MetadataRequest(path = path, types = missingTypes, priority = priority),
            )
        }
        return cached ?: FileMetadata(path = path)
    }

    /** Batch request for visible items. */
    fun requestBatch(
        items: List<Triple<String, String, Boolean>>,
        priority: MetadataPriority = MetadataPriority.HIGH,
    ) {
        engineScope.launch {
            items.forEach { (path, _, isDir) ->
                val types = buildRequestTypes(isDir)
                requestQueue.offer(MetadataRequest(path = path, types = types, priority = priority))
            }
        }
    }

    private fun startProcessingLoop() {
        engineScope.launch {
            while (isActive) {
                val request = withContext(Dispatchers.IO) { requestQueue.poll() }
                if (request != null) {
                    processRequest(request)
                } else {
                    delay(10)
                }
            }
        }
    }

    private suspend fun processRequest(request: MetadataRequest) {
        val existing = metadataCache[request.path] ?: FileMetadata(path = request.path)
        var updated = existing

        for (type in request.types) {
            updated = when (type) {
                MetadataType.MIME -> {
                    val ext = request.path.substringAfterLast('.', "")
                    val (mime, source) = mimeDetector.detectMime(request.path, ext)
                    updated.copy(mimeType = mime, mimeSource = source)
                }
                MetadataType.CHILD_COUNT -> {
                    var count = -1
                    childCountResolver.getChildCount(request.path) { newCount ->
                        engineScope.launch {
                            val newMeta = (metadataCache[request.path] ?: updated).copy(childCount = newCount)
                            metadataCache[request.path] = newMeta
                            _updates.emit(MetadataUpdate(request.path, newMeta))
                        }
                    }.also { count = it }
                    updated.copy(childCount = count)
                }
                MetadataType.SIZE -> {
                    val size = sizeCalculator.getSize(request.path)
                    updated.copy(calculatedSize = size)
                }
                MetadataType.MEDIA_META -> {
                    val mime = updated.mimeType ?: "application/octet-stream"
                    var meta: com.titan.filemanager.data.metadata.advanced.model.MediaMeta? = null
                    mediaResolver.getMediaMeta(request.path, mime) { newMeta ->
                        engineScope.launch {
                            val newFileMetadata = (metadataCache[request.path] ?: updated).copy(mediaMeta = newMeta)
                            metadataCache[request.path] = newFileMetadata
                            _updates.emit(MetadataUpdate(request.path, newFileMetadata))
                        }
                    }.also { meta = it }
                    updated.copy(mediaMeta = meta)
                }
                MetadataType.PERMISSIONS -> {
                    val perms = permissionResolver.getPermissions(request.path)
                    updated.copy(permissions = perms)
                }
                MetadataType.SYMLINK -> {
                    val isSymlink = symlinkDetector.isSymlink(request.path)
                    val target = if (isSymlink) symlinkDetector.resolveTarget(request.path) else null
                    updated.copy(isSymlink = isSymlink, symlinkTarget = target)
                }
            }
        }

        metadataCache[request.path] = updated
        versioning.recordVersion(request.path)
        _updates.emit(MetadataUpdate(request.path, updated))
    }

    private fun buildRequestTypes(isDirectory: Boolean): Set<MetadataType> =
        if (isDirectory) {
            setOf(MetadataType.CHILD_COUNT, MetadataType.SYMLINK)
        } else {
            setOf(MetadataType.MIME, MetadataType.SYMLINK)
        }

    /** Update priority for visible items — called when user scrolls. */
    fun updateViewportPriority(
        visiblePaths: Set<String>,
        priority: MetadataPriority = MetadataPriority.CRITICAL,
    ) {
        val toReprioritize = requestQueue.filter { it.path in visiblePaths }
        toReprioritize.forEach { request ->
            requestQueue.remove(request)
            requestQueue.offer(request.copy(priority = priority))
        }
    }

    /** Invalidate metadata for changed file — called by FileObserver. */
    fun invalidate(path: String) {
        metadataCache.remove(path)
        versioning.invalidate(path)
        childCountResolver.invalidate(path)
        sizeCalculator.invalidateCache(path)
        mediaResolver.invalidate(path)
        permissionResolver.invalidate(path)
        symlinkDetector.invalidate(path)
    }

    fun shutdown() {
        engineScope.cancel()
    }

    data class MetadataUpdate(val path: String, val metadata: FileMetadata)
}

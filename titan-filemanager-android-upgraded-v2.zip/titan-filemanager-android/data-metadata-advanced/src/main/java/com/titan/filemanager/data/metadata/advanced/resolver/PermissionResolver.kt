package com.titan.filemanager.data.metadata.advanced.resolver

import android.os.Build
import android.system.Os
import android.system.OsConstants
import com.titan.filemanager.data.metadata.advanced.model.FilePermissions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.ConcurrentHashMap

/**
 * Deferred Permission Lookup.
 *
 * Ported techniques:
 *   #20  Deferred permission lookup
 *   #159 Os.lstat() for permission bits
 *
 * Single `Os.lstat()` call gives all permission info (readable, writable,
 * executable, owner UID, group GID, octal mode). Cache is 30 minutes.
 */
class PermissionResolver {

    private val permCache = ConcurrentHashMap<String, PermEntry>(500)

    companion object {
        private const val CACHE_TTL = 30 * 60_000L
    }

    suspend fun getPermissions(path: String): FilePermissions? {
        permCache[path]?.let { entry ->
            if (!entry.isExpired()) return entry.perms
        }
        return withContext(Dispatchers.IO) {
            loadPermissions(path)?.also { perms ->
                permCache[path] = PermEntry(perms, System.currentTimeMillis())
            }
        }
    }

    private fun loadPermissions(path: String): FilePermissions? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try {
                val stat = Os.lstat(path)
                val mode = stat.st_mode
                FilePermissions(
                    readable = OsConstants.S_IRUSR.and(mode) != 0,
                    writable = OsConstants.S_IWUSR.and(mode) != 0,
                    executable = OsConstants.S_IXUSR.and(mode) != 0,
                    ownerUid = stat.st_uid,
                    groupGid = stat.st_gid,
                    octalMode = buildOctalMode(mode),
                )
            } catch (_: Exception) {
                loadPermissionsFallback(path)
            }
        } else {
            loadPermissionsFallback(path)
        }
    }

    private fun loadPermissionsFallback(path: String): FilePermissions? = try {
        val file = File(path)
        FilePermissions(
            readable = file.canRead(),
            writable = file.canWrite(),
            executable = file.canExecute(),
            octalMode = buildOctalModeFallback(file),
        )
    } catch (_: Exception) {
        null
    }

    /** Build octal mode string: "rwxr-xr-x". */
    private fun buildOctalMode(mode: Int): String {
        val sb = StringBuilder(9)
        sb.append(if (OsConstants.S_IRUSR.and(mode) != 0) 'r' else '-')
        sb.append(if (OsConstants.S_IWUSR.and(mode) != 0) 'w' else '-')
        sb.append(if (OsConstants.S_IXUSR.and(mode) != 0) 'x' else '-')
        sb.append(if (OsConstants.S_IRGRP.and(mode) != 0) 'r' else '-')
        sb.append(if (OsConstants.S_IWGRP.and(mode) != 0) 'w' else '-')
        sb.append(if (OsConstants.S_IXGRP.and(mode) != 0) 'x' else '-')
        sb.append(if (OsConstants.S_IROTH.and(mode) != 0) 'r' else '-')
        sb.append(if (OsConstants.S_IWOTH.and(mode) != 0) 'w' else '-')
        sb.append(if (OsConstants.S_IXOTH.and(mode) != 0) 'x' else '-')
        return sb.toString()
    }

    private fun buildOctalModeFallback(file: File): String {
        val sb = StringBuilder(9)
        sb.append(if (file.canRead()) 'r' else '-')
        sb.append(if (file.canWrite()) 'w' else '-')
        sb.append(if (file.canExecute()) 'x' else '-')
        sb.append("------")
        return sb.toString()
    }

    fun invalidate(path: String) {
        permCache.remove(path)
    }

    data class PermEntry(val perms: FilePermissions, val timestamp: Long) {
        fun isExpired() = System.currentTimeMillis() - timestamp > CACHE_TTL
    }
}

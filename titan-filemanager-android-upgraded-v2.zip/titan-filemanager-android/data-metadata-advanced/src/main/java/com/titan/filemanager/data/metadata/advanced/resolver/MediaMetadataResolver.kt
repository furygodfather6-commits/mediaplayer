package com.titan.filemanager.data.metadata.advanced.resolver

import android.content.Context
import android.graphics.BitmapFactory
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import com.titan.filemanager.data.metadata.advanced.database.MetadataDatabase
import com.titan.filemanager.data.metadata.advanced.model.MediaMeta
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * Deferred Media Metadata.
 *
 * Ported technique: #19 Deferred media metadata
 *
 * Supports: Images (EXIF), Audio, Video, Documents.
 * All loading is deferred — never blocks UI.
 */
class MediaMetadataResolver(
    private val context: Context,
    private val database: MetadataDatabase,
    private val mimeDetector: MimeDetector,
) {

    private val metaCache = ConcurrentHashMap<String, MediaMetaEntry>(200)

    // Currently loading paths (prevents duplicate concurrent requests)
    private val loadingPaths = ConcurrentHashMap.newKeySet<String>()

    companion object {
        private const val CACHE_TTL = 10 * 60_000L

        private val IMAGE_MIMES = setOf(
            "image/jpeg", "image/png", "image/heic",
            "image/heif", "image/tiff", "image/webp", "image/raw",
        )
        private val VIDEO_MIMES = setOf(
            "video/mp4", "video/x-matroska",
            "video/quicktime", "video/webm", "video/mpeg",
        )
        private val AUDIO_MIMES = setOf(
            "audio/mpeg", "audio/flac",
            "audio/ogg", "audio/wav", "audio/aac", "audio/mp4",
        )
    }

    /** Get media metadata — deferred. Returns cached immediately or triggers background load. */
    suspend fun getMediaMeta(
        path: String,
        mimeType: String,
        onMetaReady: ((MediaMeta) -> Unit)? = null,
    ): MediaMeta? {
        // L1: Memory cache
        metaCache[path]?.let { entry ->
            if (!entry.isExpired()) return entry.meta
        }

        // L2: Database
        val dbMeta = withContext(Dispatchers.IO) { database.getMediaMeta(path) }
        if (dbMeta != null) {
            metaCache[path] = MediaMetaEntry(dbMeta, System.currentTimeMillis())
            return dbMeta
        }

        // Prevent duplicate concurrent requests
        if (!loadingPaths.add(path)) return null

        withContext(Dispatchers.IO) {
            try {
                val meta = when {
                    mimeType in IMAGE_MIMES -> extractImageMeta(path)
                    mimeType in VIDEO_MIMES -> extractVideoMeta(path)
                    mimeType in AUDIO_MIMES -> extractAudioMeta(path)
                    else -> null
                }

                meta?.let {
                    metaCache[path] = MediaMetaEntry(it, System.currentTimeMillis())
                    database.saveMediaMeta(path, it)
                    onMetaReady?.invoke(it)
                }
            } finally {
                loadingPaths.remove(path)
            }
        }

        return null  // Not ready yet
    }

    /** Extract image metadata using ExifInterface — reads only EXIF header. */
    private fun extractImageMeta(path: String): MediaMeta? = try {
        val exif = ExifInterface(path)
        val width = exif.getAttributeInt(ExifInterface.TAG_IMAGE_WIDTH, 0)
        val height = exif.getAttributeInt(ExifInterface.TAG_IMAGE_LENGTH, 0)
        val dateTime = exif.getAttribute(ExifInterface.TAG_DATETIME)
        MediaMeta(width = width, height = height, creationDate = parseExifDate(dateTime))
    } catch (_: Exception) {
        getImageSizeFast(path)
    }

    /** Extract video metadata — reads only headers via MediaMetadataRetriever. */
    private fun extractVideoMeta(path: String): MediaMeta? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(path)
            val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val bitrate = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toIntOrNull() ?: 0
            MediaMeta(duration = duration, width = width, height = height, bitrate = bitrate)
        } catch (_: Exception) {
            null
        } finally {
            try { retriever.release() } catch (_: Exception) {}
        }
    }

    private fun extractAudioMeta(path: String): MediaMeta? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(path)
            val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val bitrate = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toIntOrNull() ?: 0
            val title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
            val author = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
            MediaMeta(duration = duration, bitrate = bitrate, title = title, author = author)
        } catch (_: Exception) {
            null
        } finally {
            try { retriever.release() } catch (_: Exception) {}
        }
    }

    /** Get image dimensions WITHOUT full decode — reads only header bytes. */
    private fun getImageSizeFast(path: String): MediaMeta? = try {
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, options)
        if (options.outWidth > 0 && options.outHeight > 0) {
            MediaMeta(width = options.outWidth, height = options.outHeight)
        } else null
    } catch (_: Exception) {
        null
    }

    /** Batch prefetch for visible media files. */
    suspend fun prefetchMediaMeta(
        files: List<Pair<String, String>>,
        onBatchReady: (Map<String, MediaMeta>) -> Unit,
    ) {
        val results = HashMap<String, MediaMeta>()
        val needsLoad = mutableListOf<Pair<String, String>>()

        for ((path, _) in files) {
            val cached = metaCache[path]
            if (cached != null && !cached.isExpired()) {
                results[path] = cached.meta
            } else {
                needsLoad.add(path to "")
            }
        }

        if (needsLoad.isNotEmpty()) {
            withContext(Dispatchers.IO) {
                val dbPaths = needsLoad.map { it.first }
                val dbResults = database.getMediaMetaBatch(dbPaths)
                for ((path, _) in needsLoad) {
                    val dbMeta = dbResults[path]
                    if (dbMeta != null) {
                        results[path] = dbMeta
                        metaCache[path] = MediaMetaEntry(dbMeta, System.currentTimeMillis())
                    }
                }
            }
        }
        onBatchReady(results)
    }

    private fun parseExifDate(dateStr: String?): Long {
        if (dateStr == null) return 0L
        return try {
            val format = SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.US)
            format.parse(dateStr)?.time ?: 0L
        } catch (_: Exception) {
            0L
        }
    }

    fun invalidate(path: String) {
        metaCache.remove(path)
    }

    data class MediaMetaEntry(val meta: MediaMeta, val timestamp: Long) {
        fun isExpired() = System.currentTimeMillis() - timestamp > CACHE_TTL
    }
}

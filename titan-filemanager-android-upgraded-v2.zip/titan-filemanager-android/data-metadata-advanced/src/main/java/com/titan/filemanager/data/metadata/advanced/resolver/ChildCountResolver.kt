package com.titan.filemanager.data.metadata.advanced.resolver

import com.titan.filemanager.data.metadata.advanced.database.MetadataDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.ConcurrentHashMap

/**
 * Lazy Folder Child Count.
 *
 * Ported technique: #17 Lazy folder child count
 *
 * Strategy:
 *  1. Return cached count immediately
 *  2. Load actual count in background
 *  3. Update UI when ready
 */
class ChildCountResolver(
    private val database: MetadataDatabase,
) {

    private val countCache = ConcurrentHashMap<String, CountEntry>(200)

    companion object {
        private const val CACHE_TTL = 60_000L
        private const val SHOW_HIDDEN = false
    }

    /** Get child count — returns immediately from cache or triggers background load. */
    suspend fun getChildCount(dirPath: String, onCountReady: (Int) -> Unit): Int {
        // L1: Memory cache
        countCache[dirPath]?.let { entry ->
            if (!entry.isExpired()) return entry.count
        }

        // L2: Database cache
        val dbCount = withContext(Dispatchers.IO) { database.getChildCount(dirPath) }
        if (dbCount != null) {
            countCache[dirPath] = CountEntry(dbCount, System.currentTimeMillis())
            return dbCount
        }

        // Not cached — background load
        withContext(Dispatchers.IO) {
            val count = loadActualCount(dirPath)
            countCache[dirPath] = CountEntry(count, System.currentTimeMillis())
            database.saveChildCount(dirPath, count)
            onCountReady(count)
        }
        return -1  // Not ready yet
    }

    /** Fast actual count — uses `list()` not `listFiles()` (no File objects). */
    private fun loadActualCount(dirPath: String): Int {
        return try {
            val dir = File(dirPath)
            if (!dir.canRead()) return -1
            val names = dir.list() ?: return 0
            if (SHOW_HIDDEN) names.size
            else names.count { !it.startsWith('.') }
        } catch (_: Exception) {
            -1
        }
    }

    /** Batch prefetch child counts for visible directories. */
    suspend fun prefetchCounts(
        dirPaths: List<String>,
        onCountsReady: (Map<String, Int>) -> Unit,
    ) {
        val results = HashMap<String, Int>()
        val needsLoad = mutableListOf<String>()

        for (path in dirPaths) {
            val cached = countCache[path]
            if (cached != null && !cached.isExpired()) {
                results[path] = cached.count
            } else {
                needsLoad.add(path)
            }
        }

        if (needsLoad.isEmpty()) {
            onCountsReady(results)
            return
        }

        val dbResults = withContext(Dispatchers.IO) { database.getChildCountBatch(needsLoad) }
        val stillNeeds = mutableListOf<String>()
        for (path in needsLoad) {
            val dbCount = dbResults[path]
            if (dbCount != null) {
                results[path] = dbCount
                countCache[path] = CountEntry(dbCount, System.currentTimeMillis())
            } else {
                stillNeeds.add(path)
            }
        }

        if (stillNeeds.isNotEmpty()) {
            withContext(Dispatchers.IO) {
                for (path in stillNeeds) {
                    val count = loadActualCount(path)
                    results[path] = count
                    countCache[path] = CountEntry(count, System.currentTimeMillis())
                }
                database.saveChildCountBatch(results)
            }
        }

        onCountsReady(results)
    }

    fun invalidate(dirPath: String) {
        countCache.remove(dirPath)
    }

    data class CountEntry(val count: Int, val timestamp: Long) {
        fun isExpired() = System.currentTimeMillis() - timestamp > CACHE_TTL
    }
}

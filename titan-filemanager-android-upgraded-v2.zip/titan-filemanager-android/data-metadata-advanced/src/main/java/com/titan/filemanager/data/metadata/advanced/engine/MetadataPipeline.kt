package com.titan.filemanager.data.metadata.advanced.engine

import com.titan.filemanager.data.metadata.advanced.model.FileMetadata
import com.titan.filemanager.data.metadata.advanced.resolver.ChildCountResolver
import com.titan.filemanager.data.metadata.advanced.resolver.MediaMetadataResolver
import com.titan.filemanager.data.metadata.advanced.resolver.MimeDetector
import com.titan.filemanager.data.metadata.advanced.resolver.PermissionResolver
import com.titan.filemanager.data.metadata.advanced.resolver.SizeCalculator
import com.titan.filemanager.data.metadata.advanced.resolver.SymlinkDetector
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

/**
 * Metadata Pipeline.
 *
 * Ported techniques:
 *   #22  Metadata pipeline
 *   #119 Metadata pipeline
 *
 * Stages (fastest → slowest):
 *   [Symlink] → [MIME] → [Permissions] → [ChildCount/Size] → [MediaMeta]
 *     Fast         Fast       Medium          Medium              Slow
 *
 * Each stage emits a [PipelineStageResult] with the partially-enriched
 * [FileMetadata]; callers can show progressive enrichment to the user.
 */
class MetadataPipeline(
    private val mimeDetector: MimeDetector,
    private val symlinkDetector: SymlinkDetector,
    private val permissionResolver: PermissionResolver,
    private val childCountResolver: ChildCountResolver,
    private val sizeCalculator: SizeCalculator,
    private val mediaResolver: MediaMetadataResolver,
) {

    fun execute(
        path: String,
        extension: String,
        isDirectory: Boolean,
    ): Flow<PipelineStageResult> = flow {
        var meta = FileMetadata(path = path)

        // STAGE 1: Symlink (single lstat)
        val isSymlink = symlinkDetector.isSymlink(path)
        val symlinkTarget = if (isSymlink) symlinkDetector.resolveTarget(path) else null
        meta = meta.copy(isSymlink = isSymlink, symlinkTarget = symlinkTarget)
        emit(PipelineStageResult(stage = 1, name = "Symlink", metadata = meta))

        // STAGE 2: MIME Detection (extension lookup)
        if (!isDirectory) {
            val (mime, source) = mimeDetector.detectMime(path, extension)
            meta = meta.copy(mimeType = mime, mimeSource = source)
            emit(PipelineStageResult(stage = 2, name = "MIME", metadata = meta))
        }

        // STAGE 3: Permissions (one lstat)
        val perms = permissionResolver.getPermissions(path)
        meta = meta.copy(permissions = perms)
        emit(PipelineStageResult(stage = 3, name = "Permissions", metadata = meta))

        // STAGE 4: Size/ChildCount
        if (isDirectory) {
            var childCount = -1
            childCountResolver.getChildCount(path) { count -> childCount = count }
            meta = meta.copy(childCount = childCount)
        } else {
            val size = sizeCalculator.getSize(path)
            meta = meta.copy(calculatedSize = size)
        }
        emit(PipelineStageResult(stage = 4, name = "Size/Count", metadata = meta))

        // STAGE 5: Media Metadata (slow)
        if (!isDirectory && isMediaFile(meta.mimeType)) {
            val mediaMeta = mediaResolver.getMediaMeta(path, meta.mimeType ?: "") {}
            meta = meta.copy(mediaMeta = mediaMeta)
            emit(PipelineStageResult(stage = 5, name = "MediaMeta", metadata = meta))
        }
    }

    private fun isMediaFile(mimeType: String?): Boolean {
        if (mimeType == null) return false
        return mimeType.startsWith("image/") ||
            mimeType.startsWith("video/") ||
            mimeType.startsWith("audio/")
    }
}

data class PipelineStageResult(
    val stage: Int,
    val name: String,
    val metadata: FileMetadata,
    val timestamp: Long = System.currentTimeMillis(),
)

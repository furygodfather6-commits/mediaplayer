package com.titan.filemanager.data.metadata.advanced.resolver

import android.webkit.MimeTypeMap
import com.titan.filemanager.data.metadata.advanced.model.MimeSource
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.ConcurrentHashMap

/**
 * Lazy MIME Detection.
 *
 * Ported technique: #16 Lazy MIME detection
 *
 * Strategy (fastest to slowest):
 *  1. Extension map lookup → O(1), 0 I/O
 *  2. Magic bytes detection → O(1), reads 16 bytes only
 *  3. System MimeTypeMap → fallback
 */
class MimeDetector {

    companion object {
        private val EXTENSION_MIME_MAP = HashMap<String, String>(256).apply {
            // Images
            put("jpg", "image/jpeg"); put("jpeg", "image/jpeg")
            put("png", "image/png"); put("gif", "image/gif")
            put("webp", "image/webp"); put("bmp", "image/bmp")
            put("svg", "image/svg+xml"); put("ico", "image/x-icon")
            put("heic", "image/heic"); put("heif", "image/heif")
            put("avif", "image/avif"); put("tiff", "image/tiff")
            put("tif", "image/tiff"); put("raw", "image/raw")
            put("cr2", "image/x-canon-cr2"); put("nef", "image/x-nikon-nef")

            // Videos
            put("mp4", "video/mp4"); put("mkv", "video/x-matroska")
            put("avi", "video/x-msvideo"); put("mov", "video/quicktime")
            put("wmv", "video/x-ms-wmv"); put("flv", "video/x-flv")
            put("webm", "video/webm"); put("3gp", "video/3gpp")
            put("ts", "video/mp2t"); put("m4v", "video/x-m4v")
            put("mpg", "video/mpeg"); put("mpeg", "video/mpeg")

            // Audio
            put("mp3", "audio/mpeg"); put("wav", "audio/wav")
            put("flac", "audio/flac"); put("aac", "audio/aac")
            put("ogg", "audio/ogg"); put("m4a", "audio/mp4")
            put("wma", "audio/x-ms-wma"); put("opus", "audio/opus")
            put("aiff", "audio/aiff"); put("mid", "audio/midi")
            put("midi", "audio/midi")

            // Documents
            put("pdf", "application/pdf"); put("doc", "application/msword")
            put("docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document")
            put("xls", "application/vnd.ms-excel")
            put("xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            put("ppt", "application/vnd.ms-powerpoint")
            put("pptx", "application/vnd.openxmlformats-officedocument.presentationml.presentation")
            put("odt", "application/vnd.oasis.opendocument.text")
            put("ods", "application/vnd.oasis.opendocument.spreadsheet")
            put("odp", "application/vnd.oasis.opendocument.presentation")

            // Text
            put("txt", "text/plain"); put("html", "text/html"); put("htm", "text/html")
            put("css", "text/css"); put("js", "text/javascript")
            put("ts", "text/typescript"); put("json", "application/json")
            put("xml", "text/xml"); put("csv", "text/csv")
            put("md", "text/markdown"); put("yaml", "text/yaml")
            put("yml", "text/yaml"); put("toml", "text/toml")
            put("ini", "text/plain"); put("log", "text/plain")
            put("rtf", "text/rtf")

            // Code
            put("kt", "text/x-kotlin"); put("java", "text/x-java")
            put("py", "text/x-python"); put("cpp", "text/x-c++src")
            put("c", "text/x-csrc"); put("h", "text/x-chdr")
            put("swift", "text/x-swift"); put("go", "text/x-go")
            put("rs", "text/x-rust"); put("rb", "text/x-ruby")
            put("php", "text/x-php"); put("sh", "text/x-sh")
            put("bash", "text/x-sh"); put("sql", "text/x-sql")
            put("dart", "text/x-dart")

            // Archives
            put("zip", "application/zip"); put("rar", "application/x-rar-compressed")
            put("7z", "application/x-7z-compressed"); put("tar", "application/x-tar")
            put("gz", "application/gzip"); put("bz2", "application/x-bzip2")
            put("xz", "application/x-xz")
            put("apk", "application/vnd.android.package-archive")
            put("jar", "application/java-archive")
            put("deb", "application/x-debian-package")

            // Fonts
            put("ttf", "font/ttf"); put("otf", "font/otf")
            put("woff", "font/woff"); put("woff2", "font/woff2")

            // 3D / Design
            put("obj", "model/obj"); put("fbx", "model/fbx")
            put("stl", "model/stl")
            put("psd", "image/vnd.adobe.photoshop")
            put("ai", "application/postscript")
            put("eps", "application/postscript")
            put("xcf", "image/x-xcf")

            // Android specific
            put("aab", "application/x-authorware-bin")
            put("dex", "application/x-android-dex")
            put("so", "application/x-sharedlib")
        }

        private val MAGIC_BYTES_MAP = listOf(
            MagicEntry(byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte()), "image/jpeg"),
            MagicEntry(byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A), "image/png"),
            MagicEntry(byteArrayOf(0x47, 0x49, 0x46, 0x38), "image/gif"),
            MagicEntry(
                magic = byteArrayOf(0x52, 0x49, 0x46, 0x46),
                mime = "image/webp",
                secondCheck = byteArrayOf(0x57, 0x45, 0x42, 0x50),
                secondOffset = 8,
            ),
            MagicEntry(byteArrayOf(0x25, 0x50, 0x44, 0x46), "application/pdf"),
            MagicEntry(byteArrayOf(0x50, 0x4B, 0x03, 0x04), "application/zip"),
            MagicEntry(byteArrayOf(0x52, 0x61, 0x72, 0x21, 0x1A, 0x07), "application/x-rar-compressed"),
            MagicEntry(byteArrayOf(0x37, 0x7A, 0xBC.toByte(), 0xAF.toByte(), 0x27, 0x1C), "application/x-7z-compressed"),
            MagicEntry(byteArrayOf(0x1F, 0x8B.toByte()), "application/gzip"),
            MagicEntry(byteArrayOf(0x42, 0x5A, 0x68), "application/x-bzip2"),
            MagicEntry(byteArrayOf(0x49, 0x44, 0x33), "audio/mpeg"),
            MagicEntry(byteArrayOf(0xFF.toByte(), 0xFB.toByte()), "audio/mpeg"),
            MagicEntry(byteArrayOf(0x66, 0x4C, 0x61, 0x43), "audio/flac"),
            MagicEntry(byteArrayOf(0x4F, 0x67, 0x67, 0x53), "audio/ogg"),
            MagicEntry(byteArrayOf(0x00, 0x00, 0x00), "video/mp4", checkFtyp = true),
            MagicEntry(byteArrayOf(0x1A, 0x45, 0xDF.toByte(), 0xA3.toByte()), "video/x-matroska"),
            MagicEntry(
                magic = byteArrayOf(0x52, 0x49, 0x46, 0x46),
                mime = "video/x-msvideo",
                secondCheck = byteArrayOf(0x41, 0x56, 0x49, 0x20),
                secondOffset = 8,
            ),
            MagicEntry(byteArrayOf(0x4D, 0x5A), "application/x-msdownload"),
            MagicEntry(byteArrayOf(0x7F, 0x45, 0x4C, 0x46), "application/x-elf"),
            MagicEntry(byteArrayOf(0xCA.toByte(), 0xFE.toByte(), 0xBA.toByte(), 0xBE.toByte()), "application/java-archive"),
        )

        private val resultCache = object : LinkedHashMap<String, String>(500, 0.75f, true) {
            override fun removeEldestEntry(eldest: Map.Entry<String, String>): Boolean = size > 1000
        }
    }

    /** Fast MIME detection — tries extension first. */
    fun detectMime(
        path: String,
        extension: String,
        usesMagicBytes: Boolean = false,
    ): Pair<String, MimeSource> {
        // Cache check
        resultCache[path]?.let { cached -> return Pair(cached, MimeSource.CACHED) }

        // Stage 1: Extension lookup
        if (extension.isNotEmpty()) {
            EXTENSION_MIME_MAP[extension.lowercase()]?.let { mime ->
                resultCache[path] = mime
                return Pair(mime, MimeSource.EXTENSION)
            }
        }

        // Stage 2: Magic bytes
        if (usesMagicBytes) {
            detectFromMagicBytes(path)?.let { mime ->
                resultCache[path] = mime
                return Pair(mime, MimeSource.MAGIC_BYTES)
            }
        }

        // Stage 3: System MimeTypeMap
        val systemMime = MimeTypeMap.getSingleton()
            .getMimeTypeFromExtension(extension.lowercase()) ?: "application/octet-stream"

        resultCache[path] = systemMime
        return Pair(systemMime, MimeSource.SYSTEM)
    }

    /** Magic bytes detection — reads only first 16 bytes. */
    private fun detectFromMagicBytes(path: String): String? = try {
        RandomAccessFile(path, "r").use { file ->
            val headerSize = minOf(file.length(), 16L).toInt()
            if (headerSize < 2) return null
            val header = ByteArray(headerSize)
            file.read(header)
            matchMagicBytes(header)
        }
    } catch (_: Exception) {
        null
    }

    private fun matchMagicBytes(header: ByteArray): String? {
        for (entry in MAGIC_BYTES_MAP) {
            if (entry.checkFtyp) {
                // MP4 ftyp check: bytes 4-7 = "ftyp"
                if (header.size >= 8 &&
                    header[4] == 0x66.toByte() &&
                    header[5] == 0x74.toByte() &&
                    header[6] == 0x79.toByte() &&
                    header[7] == 0x70.toByte()
                ) {
                    return entry.mime
                }
                continue
            }

            if (matchesAt(header, entry.magic, entry.offset)) {
                if (entry.secondCheck != null) {
                    if (matchesAt(header, entry.secondCheck, entry.secondOffset)) {
                        return entry.mime
                    }
                } else {
                    return entry.mime
                }
            }
        }
        return null
    }

    private fun matchesAt(data: ByteArray, pattern: ByteArray, offset: Int): Boolean {
        if (offset + pattern.size > data.size) return false
        for (i in pattern.indices) {
            if (data[offset + i] != pattern[i]) return false
        }
        return true
    }

    /** Batch MIME detection. */
    fun detectMimeBatch(files: List<Pair<String, String>>): Map<String, Pair<String, MimeSource>> {
        val results = HashMap<String, Pair<String, MimeSource>>(files.size)
        val needsDetection = mutableListOf<Pair<String, String>>()

        for ((path, ext) in files) {
            resultCache[path]?.let { cached ->
                results[path] = Pair(cached, MimeSource.CACHED)
            } ?: needsDetection.add(Pair(path, ext))
        }

        for ((path, ext) in needsDetection) {
            results[path] = detectMime(path, ext)
        }
        return results
    }

    fun clearCache() {
        resultCache.clear()
    }

    data class MagicEntry(
        val magic: ByteArray,
        val mime: String,
        val offset: Int = 0,
        val secondCheck: ByteArray? = null,
        val secondOffset: Int = 0,
        val checkFtyp: Boolean = false,
    )
}

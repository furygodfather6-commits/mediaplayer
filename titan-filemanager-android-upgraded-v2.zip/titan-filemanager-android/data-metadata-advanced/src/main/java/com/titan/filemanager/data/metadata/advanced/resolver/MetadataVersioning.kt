package com.titan.filemanager.data.metadata.advanced.resolver

import android.os.Build
import android.system.Os
import com.titan.filemanager.data.metadata.advanced.database.MetadataDatabase
import java.io.File
import java.util.concurrent.ConcurrentHashMap

/**
 * Metadata Versioning System.
 *
 * Ported techniques:
 *   #24 Metadata versioning
 *   #25 Incremental metadata updates
 *
 * Tracks metadata version using inode + mtime + size. A single `Os.lstat()`
 * call returns all three pieces of information so version checks are O(1).
 */
class MetadataVersioning(
    private val database: MetadataDatabase,
) {

    private val versionCache = ConcurrentHashMap<String, FileVersion>(500)

    /** Check if cached metadata is still valid (inode + mtime + size match). */
    fun isMetadataValid(path: String): Boolean {
        val cached = versionCache[path] ?: return false
        val current = getCurrentVersion(path) ?: return false
        return cached.inode == current.inode &&
            cached.mtime == current.mtime &&
            cached.size == current.size
    }

    /** Get current file version via single `Os.lstat()` call. */
    fun getCurrentVersion(path: String): FileVersion? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try {
                val stat = Os.lstat(path)
                FileVersion(inode = stat.st_ino, mtime = stat.st_mtime, size = stat.st_size)
            } catch (_: Exception) {
                getVersionFallback(path)
            }
        } else {
            getVersionFallback(path)
        }
    }

    private fun getVersionFallback(path: String): FileVersion? {
        return try {
            val file = File(path)
            if (!file.exists()) return null
            FileVersion(inode = 0L, mtime = file.lastModified() / 1000, size = file.length())
        } catch (_: Exception) {
            null
        }
    }

    /** Record new version after metadata update. */
    fun recordVersion(path: String) {
        getCurrentVersion(path)?.let { version -> versionCache[path] = version }
    }

    /**
     * Batch version check for incremental updates.
     * Ported Technique #25: Incremental metadata updates.
     */
    fun findChangedFiles(paths: List<String>): List<String> =
        paths.filter { path -> !isMetadataValid(path) }

    fun invalidate(path: String) {
        versionCache.remove(path)
    }

    data class FileVersion(val inode: Long, val mtime: Long, val size: Long)
}

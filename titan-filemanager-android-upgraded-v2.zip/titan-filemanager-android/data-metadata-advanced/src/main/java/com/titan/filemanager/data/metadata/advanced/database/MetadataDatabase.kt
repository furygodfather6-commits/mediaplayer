package com.titan.filemanager.data.metadata.advanced.database

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.titan.filemanager.data.metadata.advanced.model.MediaMeta
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Metadata SQLite Database.
 *
 * Ported techniques:
 *   #23 Metadata database
 *   #24 Metadata versioning
 *   #86 SQLite optimization
 *   #87 WAL mode
 *   #88 Prepared statements
 *   #89 Batch transactions
 */
class MetadataDatabase(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "metadata_advanced.db"
        private const val DATABASE_VERSION = 1
        private const val TABLE = "metadata"

        private const val COL_PATH = "path"
        private const val COL_VERSION = "version"
        private const val COL_LAST_MODIFIED = "last_modified"
        private const val COL_FILE_SIZE = "file_size"
        private const val COL_MIME = "mime_type"
        private const val COL_CHILD_COUNT = "child_count"
        private const val COL_CALC_SIZE = "calculated_size"
        private const val COL_MEDIA_W = "media_width"
        private const val COL_MEDIA_H = "media_height"
        private const val COL_DURATION = "duration"
        private const val COL_BITRATE = "bitrate"
        private const val COL_TITLE = "title"
        private const val COL_AUTHOR = "author"
        private const val COL_PERMS = "permissions"
        private const val COL_SYMLINK = "is_symlink"
        private const val COL_SYMLINK_TARGET = "symlink_target"
        private const val COL_UPDATED = "last_updated"
    }

    override fun onCreate(db: SQLiteDatabase) {
        // Performance PRAGMAs
        db.execSQL("PRAGMA journal_mode=WAL")
        db.execSQL("PRAGMA synchronous=NORMAL")
        db.execSQL("PRAGMA cache_size=10000")
        db.execSQL("PRAGMA temp_store=MEMORY")
        db.execSQL("PRAGMA mmap_size=268435456")  // 256MB memory-mapped

        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS $TABLE (
                $COL_PATH           TEXT PRIMARY KEY,
                $COL_VERSION        INTEGER NOT NULL DEFAULT 1,
                $COL_LAST_MODIFIED  INTEGER NOT NULL DEFAULT 0,
                $COL_FILE_SIZE      INTEGER NOT NULL DEFAULT -1,
                $COL_MIME           TEXT,
                $COL_CHILD_COUNT    INTEGER NOT NULL DEFAULT -1,
                $COL_CALC_SIZE      INTEGER NOT NULL DEFAULT -1,
                $COL_MEDIA_W        INTEGER NOT NULL DEFAULT 0,
                $COL_MEDIA_H        INTEGER NOT NULL DEFAULT 0,
                $COL_DURATION       INTEGER NOT NULL DEFAULT 0,
                $COL_BITRATE        INTEGER NOT NULL DEFAULT 0,
                $COL_TITLE          TEXT,
                $COL_AUTHOR         TEXT,
                $COL_PERMS          TEXT,
                $COL_SYMLINK        INTEGER NOT NULL DEFAULT 0,
                $COL_SYMLINK_TARGET TEXT,
                $COL_UPDATED        INTEGER NOT NULL DEFAULT 0
            )
            """.trimIndent(),
        )

        db.execSQL("CREATE INDEX IF NOT EXISTS idx_updated ON $TABLE($COL_UPDATED)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_mime ON $TABLE($COL_MIME)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE")
        onCreate(db)
    }

    override fun onOpen(db: SQLiteDatabase) {
        super.onOpen(db)
        if (!db.isReadOnly) {
            db.execSQL("PRAGMA journal_mode=WAL")
            db.execSQL("PRAGMA foreign_keys=ON")
        }
    }

    // ════════════════════════════════════════
    // Child Count Operations
    // ════════════════════════════════════════

    fun getChildCount(path: String): Int? {
        return readableDatabase.rawQuery(
            "SELECT $COL_CHILD_COUNT FROM $TABLE WHERE $COL_PATH = ?",
            arrayOf(path),
        ).use { cursor ->
            if (cursor.moveToFirst()) {
                val count = cursor.getInt(0)
                if (count >= 0) count else null
            } else null
        }
    }

    fun saveChildCount(path: String, count: Int) {
        writableDatabase.execSQL(
            """INSERT INTO $TABLE ($COL_PATH, $COL_CHILD_COUNT, $COL_UPDATED)
               VALUES (?, ?, ?)
               ON CONFLICT($COL_PATH) DO UPDATE SET
               $COL_CHILD_COUNT = excluded.$COL_CHILD_COUNT,
               $COL_UPDATED = excluded.$COL_UPDATED""".trimIndent(),
            arrayOf(path, count, System.currentTimeMillis()),
        )
    }

    /** Batch child count lookup — single query with IN clause. */
    fun getChildCountBatch(paths: List<String>): Map<String, Int> {
        if (paths.isEmpty()) return emptyMap()
        val placeholders = paths.joinToString(",") { "?" }
        val results = HashMap<String, Int>(paths.size)

        readableDatabase.rawQuery(
            "SELECT $COL_PATH, $COL_CHILD_COUNT FROM $TABLE WHERE $COL_PATH IN ($placeholders)",
            paths.toTypedArray(),
        ).use { cursor ->
            while (cursor.moveToNext()) {
                val path = cursor.getString(0)
                val count = cursor.getInt(1)
                if (count >= 0) results[path] = count
            }
        }
        return results
    }

    fun saveChildCountBatch(counts: Map<String, Int>) {
        writableDatabase.beginTransactionNonExclusive()
        try {
            val now = System.currentTimeMillis()
            counts.forEach { (path, count) ->
                writableDatabase.execSQL(
                    """INSERT INTO $TABLE ($COL_PATH, $COL_CHILD_COUNT, $COL_UPDATED)
                       VALUES (?, ?, ?)
                       ON CONFLICT($COL_PATH) DO UPDATE SET
                       $COL_CHILD_COUNT = excluded.$COL_CHILD_COUNT,
                       $COL_UPDATED = excluded.$COL_UPDATED""".trimIndent(),
                    arrayOf(path, count, now),
                )
            }
            writableDatabase.setTransactionSuccessful()
        } finally {
            writableDatabase.endTransaction()
        }
    }

    // ════════════════════════════════════════
    // Size Operations
    // ════════════════════════════════════════

    fun getCalculatedSize(path: String): Long? {
        return readableDatabase.rawQuery(
            "SELECT $COL_CALC_SIZE FROM $TABLE WHERE $COL_PATH = ?",
            arrayOf(path),
        ).use { cursor ->
            if (cursor.moveToFirst()) {
                val size = cursor.getLong(0)
                if (size >= 0) size else null
            } else null
        }
    }

    fun saveCalculatedSize(path: String, size: Long) {
        writableDatabase.execSQL(
            """INSERT INTO $TABLE ($COL_PATH, $COL_CALC_SIZE, $COL_UPDATED)
               VALUES (?, ?, ?)
               ON CONFLICT($COL_PATH) DO UPDATE SET
               $COL_CALC_SIZE = excluded.$COL_CALC_SIZE,
               $COL_UPDATED = excluded.$COL_UPDATED""".trimIndent(),
            arrayOf(path, size, System.currentTimeMillis()),
        )
    }

    // ════════════════════════════════════════
    // Media Metadata Operations
    // ════════════════════════════════════════

    fun getMediaMeta(path: String): MediaMeta? {
        return readableDatabase.rawQuery(
            """SELECT $COL_MEDIA_W, $COL_MEDIA_H, $COL_DURATION,
               $COL_BITRATE, $COL_TITLE, $COL_AUTHOR
               FROM $TABLE WHERE $COL_PATH = ?""".trimIndent(),
            arrayOf(path),
        ).use { cursor ->
            if (cursor.moveToFirst()) {
                MediaMeta(
                    width = cursor.getInt(0),
                    height = cursor.getInt(1),
                    duration = cursor.getLong(2),
                    bitrate = cursor.getInt(3),
                    title = cursor.getString(4),
                    author = cursor.getString(5),
                )
            } else null
        }
    }

    fun saveMediaMeta(path: String, meta: MediaMeta) {
        writableDatabase.execSQL(
            """INSERT INTO $TABLE
               ($COL_PATH, $COL_MEDIA_W, $COL_MEDIA_H, $COL_DURATION,
                $COL_BITRATE, $COL_TITLE, $COL_AUTHOR, $COL_UPDATED)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT($COL_PATH) DO UPDATE SET
               $COL_MEDIA_W = excluded.$COL_MEDIA_W,
               $COL_MEDIA_H = excluded.$COL_MEDIA_H,
               $COL_DURATION = excluded.$COL_DURATION,
               $COL_BITRATE = excluded.$COL_BITRATE,
               $COL_TITLE = excluded.$COL_TITLE,
               $COL_AUTHOR = excluded.$COL_AUTHOR,
               $COL_UPDATED = excluded.$COL_UPDATED""".trimIndent(),
            arrayOf(
                path, meta.width, meta.height, meta.duration,
                meta.bitrate, meta.title, meta.author,
                System.currentTimeMillis(),
            ),
        )
    }

    fun getMediaMetaBatch(paths: List<String>): Map<String, MediaMeta> {
        if (paths.isEmpty()) return emptyMap()
        val placeholders = paths.joinToString(",") { "?" }
        val results = HashMap<String, MediaMeta>(paths.size)

        readableDatabase.rawQuery(
            """SELECT $COL_PATH, $COL_MEDIA_W, $COL_MEDIA_H, $COL_DURATION,
               $COL_BITRATE, $COL_TITLE, $COL_AUTHOR
               FROM $TABLE WHERE $COL_PATH IN ($placeholders)""".trimIndent(),
            paths.toTypedArray(),
        ).use { cursor ->
            while (cursor.moveToNext()) {
                val path = cursor.getString(0)
                results[path] = MediaMeta(
                    width = cursor.getInt(1),
                    height = cursor.getInt(2),
                    duration = cursor.getLong(3),
                    bitrate = cursor.getInt(4),
                    title = cursor.getString(5),
                    author = cursor.getString(6),
                )
            }
        }
        return results
    }

    // ════════════════════════════════════════
    // Cleanup & Maintenance
    // ════════════════════════════════════════

    fun cleanupStaleEntries(maxAge: Long = 7 * 24 * 60 * 60_000L) {
        val cutoff = System.currentTimeMillis() - maxAge
        writableDatabase.execSQL(
            "DELETE FROM $TABLE WHERE $COL_UPDATED < ?",
            arrayOf(cutoff),
        )
    }

    fun getDatabaseSizeBytes(): Long {
        return readableDatabase.rawQuery(
            "SELECT page_count * page_size FROM pragma_page_count(), pragma_page_size()",
            null,
        ).use { cursor ->
            if (cursor.moveToFirst()) cursor.getLong(0) else 0L
        }
    }
}

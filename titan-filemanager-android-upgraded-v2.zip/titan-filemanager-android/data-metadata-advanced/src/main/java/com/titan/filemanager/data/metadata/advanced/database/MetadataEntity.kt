package com.titan.filemanager.data.metadata.advanced.database

/**
 * Database entity for metadata storage.
 *
 * Ported techniques:
 *   #23 Metadata database
 *   #24 Metadata versioning
 */
data class MetadataEntity(
    val path: String,
    val version: Long,
    val lastModified: Long,
    val fileSize: Long,
    val mimeType: String?,
    val childCount: Int,
    val calculatedSize: Long,
    val mediaWidth: Int,
    val mediaHeight: Int,
    val mediaDuration: Long,
    val mediaBitrate: Int,
    val mediaTitle: String?,
    val mediaAuthor: String?,
    val permissions: String?,
    val isSymlink: Int,
    val symlinkTarget: String?,
    val lastUpdated: Long,
)

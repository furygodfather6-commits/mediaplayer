package com.titan.filemanager.data.metadata.advanced.resolver

import android.os.Build
import android.system.Os
import android.system.OsConstants
import java.io.File
import java.util.concurrent.ConcurrentHashMap

/**
 * Fast Symlink Detection.
 *
 * Ported techniques:
 *   #21  Fast symlink detection
 *   #160 Inode-based tracking
 *
 * Uses `Os.lstat()` for O(1) symlink detection — lstat() does NOT follow
 * symlinks (unlike stat()) which is what makes it the right tool for the
 * job. Falls back to canonical-path comparison on older Android.
 */
class SymlinkDetector {

    private val symlinkCache = ConcurrentHashMap<String, SymlinkEntry>(200)

    fun isSymlink(path: String): Boolean {
        symlinkCache[path]?.let { return it.isSymlink }

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try {
                val stat = Os.lstat(path)
                val isSymlink = OsConstants.S_ISLNK(stat.st_mode)
                val target = if (isSymlink) resolveTarget(path) else null
                symlinkCache[path] = SymlinkEntry(isSymlink, target)
                isSymlink
            } catch (_: Exception) {
                false
            }
        } else {
            isSymlinkFallback(path)
        }
    }

    fun resolveTarget(path: String): String? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try {
                Os.readlink(path)
            } catch (_: Exception) {
                null
            }
        } else {
            try {
                val file = File(path)
                val canonical = file.canonicalPath
                if (canonical != file.absolutePath) canonical else null
            } catch (_: Exception) {
                null
            }
        }
    }

    /** Batch symlink detection — processes multiple files in one pass. */
    fun detectSymlinksBatch(paths: List<String>): Map<String, SymlinkInfo> {
        val results = HashMap<String, SymlinkInfo>(paths.size)

        for (path in paths) {
            val cached = symlinkCache[path]
            if (cached != null) {
                results[path] = SymlinkInfo(cached.isSymlink, cached.target)
                continue
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                try {
                    val stat = Os.lstat(path)
                    val isSymlink = OsConstants.S_ISLNK(stat.st_mode)
                    val target = if (isSymlink) resolveTarget(path) else null
                    symlinkCache[path] = SymlinkEntry(isSymlink, target)
                    results[path] = SymlinkInfo(isSymlink, target)
                } catch (_: Exception) {
                    results[path] = SymlinkInfo(false, null)
                }
            } else {
                results[path] = SymlinkInfo(isSymlinkFallback(path), null)
            }
        }
        return results
    }

    /**
     * Fallback for older Android — compare absolutePath vs canonicalPath.
     * Ported Technique #113: Avoid repeated canonical path resolution.
     */
    private fun isSymlinkFallback(path: String): Boolean = try {
        val file = File(path)
        file.absolutePath != file.canonicalPath
    } catch (_: Exception) {
        false
    }

    fun invalidate(path: String) {
        symlinkCache.remove(path)
    }

    data class SymlinkEntry(val isSymlink: Boolean, val target: String?)
    data class SymlinkInfo(val isSymlink: Boolean, val target: String?)
}

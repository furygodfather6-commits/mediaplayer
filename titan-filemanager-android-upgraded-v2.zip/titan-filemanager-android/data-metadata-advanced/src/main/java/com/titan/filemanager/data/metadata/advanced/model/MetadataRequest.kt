package com.titan.filemanager.data.metadata.advanced.model

/**
 * Priority-based metadata request.
 * Higher priority = processed sooner by [MetadataEngine].
 */
data class MetadataRequest(
    val path: String,
    val types: Set<MetadataType>,
    val priority: MetadataPriority = MetadataPriority.NORMAL,
    val requestedAt: Long = System.currentTimeMillis(),
    val callback: ((FileMetadata) -> Unit)? = null,
)

enum class MetadataType {
    MIME,
    CHILD_COUNT,
    SIZE,
    MEDIA_META,
    PERMISSIONS,
    SYMLINK,
}

enum class MetadataPriority(val value: Int) {
    CRITICAL(100),   // Visible on screen RIGHT NOW
    HIGH(75),        // Visible soon (prefetch)
    NORMAL(50),      // Standard load
    LOW(25),         // Background load
    IDLE(10),        // Only when CPU free
}

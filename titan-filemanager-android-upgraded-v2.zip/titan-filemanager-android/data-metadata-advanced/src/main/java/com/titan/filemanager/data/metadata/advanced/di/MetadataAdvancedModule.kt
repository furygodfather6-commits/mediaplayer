package com.titan.filemanager.data.metadata.advanced.di

import android.content.Context
import com.titan.filemanager.data.metadata.advanced.engine.MetadataEngine
import com.titan.filemanager.data.metadata.advanced.engine.MetadataPipeline
import com.titan.filemanager.data.metadata.advanced.resolver.ChildCountResolver
import com.titan.filemanager.data.metadata.advanced.resolver.MediaMetadataResolver
import com.titan.filemanager.data.metadata.advanced.resolver.MetadataVersioning
import com.titan.filemanager.data.metadata.advanced.resolver.MimeDetector
import com.titan.filemanager.data.metadata.advanced.resolver.PermissionResolver
import com.titan.filemanager.data.metadata.advanced.resolver.SizeCalculator
import com.titan.filemanager.data.metadata.advanced.resolver.SymlinkDetector
import com.titan.filemanager.data.metadata.advanced.database.MetadataDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/** Hilt module wiring the metadata engine and its collaborators. */
@Module
@InstallIn(SingletonComponent::class)
object MetadataAdvancedModule {

    @Provides @Singleton
    fun provideMetadataDatabase(@ApplicationContext context: Context): MetadataDatabase =
        MetadataDatabase(context)

    @Provides @Singleton
    fun provideMimeDetector(): MimeDetector = MimeDetector()

    @Provides @Singleton
    fun provideSymlinkDetector(): SymlinkDetector = SymlinkDetector()

    @Provides @Singleton
    fun providePermissionResolver(): PermissionResolver = PermissionResolver()

    @Provides @Singleton
    fun provideChildCountResolver(db: MetadataDatabase): ChildCountResolver =
        ChildCountResolver(db)

    @Provides @Singleton
    fun provideSizeCalculator(db: MetadataDatabase): SizeCalculator = SizeCalculator(db)

    @Provides @Singleton
    fun provideMediaResolver(
        @ApplicationContext context: Context,
        db: MetadataDatabase,
        mime: MimeDetector,
    ): MediaMetadataResolver = MediaMetadataResolver(context, db, mime)

    @Provides @Singleton
    fun provideMetadataVersioning(db: MetadataDatabase): MetadataVersioning =
        MetadataVersioning(db)

    @Provides @Singleton
    fun provideMetadataPipeline(
        mime: MimeDetector,
        symlink: SymlinkDetector,
        perms: PermissionResolver,
        child: ChildCountResolver,
        size: SizeCalculator,
        media: MediaMetadataResolver,
    ): MetadataPipeline = MetadataPipeline(mime, symlink, perms, child, size, media)

    @Provides @Singleton
    fun provideMetadataEngine(@ApplicationContext context: Context): MetadataEngine =
        MetadataEngine(context)
}

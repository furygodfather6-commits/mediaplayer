// :data:search:advanced — Enterprise search engine
// Ported from original codebase Phase H (Techniques #78-#85)
plugins {
    id("titan.android.library")
    id("titan.android.hilt")
}

android {
    namespace = "com.titan.filemanager.data.search.advanced"
}

dependencies {
    api(project(":core:common"))
    api(project(":core:model"))
    api(project(":domain"))

    implementation(libs.kotlinx.coroutines.core)
    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.timber)

    testImplementation(project(":core:testing"))
    testImplementation(libs.junit5)
    testImplementation(libs.truth)
    testImplementation(libs.robolectric)
    testImplementation(libs.kotlinx.coroutines.test)
}

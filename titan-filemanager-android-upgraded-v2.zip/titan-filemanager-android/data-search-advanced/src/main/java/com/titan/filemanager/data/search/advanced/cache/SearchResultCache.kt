package com.titan.filemanager.data.search.advanced.cache

import com.titan.filemanager.data.search.advanced.SearchResult
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * Search Result Cache.
 *
 * Ported technique: #84 Cached search results
 *
 * Caches recent search results for:
 *  1. Same query = instant results
 *  2. Prefix queries = reuse longer query results
 *  3. Incremental search: "pho" → "phot" → "photo"
 *     Each keystroke reuses previous results.
 */
class SearchResultCache(
    private val maxEntries: Int = 50,
    private val ttlMs: Long = 60_000L,
) {

    private val cache = object : LinkedHashMap<String, CacheEntry>(maxEntries, 0.75f, true) {
        override fun removeEldestEntry(eldest: Map.Entry<String, CacheEntry>): Boolean = size > maxEntries
    }
    private val cacheLock = Any()

    private val hits = AtomicLong(0L)
    private val misses = AtomicLong(0L)
    private val prefixHits = AtomicLong(0L)

    /** Get cached results for query. */
    fun get(queryText: String, rootPath: String): List<SearchResult>? {
        val key = buildKey(queryText, rootPath)

        synchronized(cacheLock) {
            val entry = cache[key]
            if (entry != null && !entry.isExpired()) {
                hits.incrementAndGet()
                return entry.results
            }
        }

        // Try prefix: if "photo" is cached and query is "photos"
        val prefixResult = getPrefixMatch(queryText, rootPath)
        if (prefixResult != null) {
            prefixHits.incrementAndGet()
            return prefixResult
        }

        misses.incrementAndGet()
        return null
    }

    fun put(queryText: String, rootPath: String, results: List<SearchResult>) {
        val key = buildKey(queryText, rootPath)
        synchronized(cacheLock) {
            cache[key] = CacheEntry(results = results, timestamp = System.currentTimeMillis())
        }
    }

    /**
     * Try to find a prefix match.
     * If "phot" is cached, "photo" results must be a subset.
     */
    private fun getPrefixMatch(query: String, rootPath: String): List<SearchResult>? {
        if (query.length < 3) return null

        synchronized(cacheLock) {
            for (len in query.length - 1 downTo 2) {
                val prefix = query.substring(0, len)
                val key = buildKey(prefix, rootPath)
                val entry = cache[key] ?: continue
                if (entry.isExpired()) continue

                val filtered = entry.results.filter { result ->
                    result.fileName.lowercase().contains(query.lowercase())
                }
                if (filtered.isNotEmpty()) return filtered
            }
        }
        return null
    }

    fun invalidateForPath(dirPath: String) {
        synchronized(cacheLock) {
            val toRemove = cache.keys.filter { it.contains(dirPath) }
            toRemove.forEach { cache.remove(it) }
        }
    }

    fun clear() {
        synchronized(cacheLock) { cache.clear() }
    }

    private fun buildKey(query: String, rootPath: String): String = "${query.lowercase()}::$rootPath"

    fun getHitRate(): Float {
        val total = hits.get() + prefixHits.get() + misses.get()
        return if (total > 0) (hits.get() + prefixHits.get()).toFloat() / total else 0f
    }

    data class CacheEntry(
        val results: List<SearchResult>,
        val timestamp: Long,
    ) {
        fun isExpired(): Boolean = System.currentTimeMillis() - timestamp > 60_000L
    }
}

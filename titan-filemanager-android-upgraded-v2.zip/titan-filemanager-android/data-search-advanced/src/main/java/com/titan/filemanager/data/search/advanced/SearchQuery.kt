package com.titan.filemanager.data.search.advanced

import java.util.UUID

/**
 * Search query with all parameters.
 *
 * Carries text, root path, filters (file types / size / date), behaviour
 * toggles (regex, case-sensitivity, hidden, content), and performance
 * hints (maxResults, timeout, priority).
 */
data class SearchQuery(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val rootPath: String = "/storage/emulated/0",

    // Filters
    val fileTypes: Set<FileTypeFilter> = emptySet(),
    val sizeRange: LongRange? = null,
    val dateRange: LongRange? = null,
    val includeHidden: Boolean = false,
    val searchInContent: Boolean = false,
    val caseSensitive: Boolean = false,
    val useRegex: Boolean = false,
    val recursive: Boolean = true,

    // Performance hints
    val maxResults: Int = 500,
    val timeoutMs: Long = 10_000L,
    val priority: SearchPriority = SearchPriority.NORMAL,

    val createdAt: Long = System.currentTimeMillis(),
) {
    val normalizedText: String = if (caseSensitive) text else text.lowercase()
    val isValid: Boolean = text.length >= 1

    val queryType: QueryType = when {
        useRegex -> QueryType.REGEX
        text.contains('*') || text.contains('?') -> QueryType.WILDCARD
        text.contains(' ') && searchInContent -> QueryType.PHRASE
        else -> QueryType.KEYWORD
    }
}

enum class FileTypeFilter(val mimePrefix: String, val extensions: Set<String>) {
    IMAGE("image/", setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic")),
    VIDEO("video/", setOf("mp4", "mkv", "avi", "mov", "wmv", "webm")),
    AUDIO("audio/", setOf("mp3", "flac", "aac", "ogg", "wav", "m4a")),
    DOCUMENT("application/", setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt")),
    ARCHIVE("application/", setOf("zip", "rar", "7z", "tar", "gz")),
    CODE("text/", setOf("kt", "java", "py", "js", "cpp", "c", "h", "rs")),
    FOLDER("", setOf()),
}

enum class QueryType { KEYWORD, WILDCARD, REGEX, PHRASE }
enum class SearchPriority { REALTIME, HIGH, NORMAL, LOW }

/** Search result model. */
data class SearchResult(
    val filePath: String,
    val fileName: String,
    val fileSize: Long,
    val lastModified: Long,
    val isDirectory: Boolean,
    val mimeType: String,
    val relevanceScore: Float,
    val matchType: MatchType,
    val matchPositions: List<IntRange> = emptyList(),
    val snippet: String = "",
    val rank: Int = 0,
)

enum class MatchType {
    EXACT_NAME,
    PREFIX_NAME,
    CONTAINS_NAME,
    FUZZY_NAME,
    CONTENT_MATCH,
    METADATA_MATCH,
}

/** Search state machine. */
sealed class SearchState {
    object Idle : SearchState()
    data class Indexing(val progress: Float, val indexedCount: Int) : SearchState()
    data class Searching(val queryId: String, val resultsFound: Int) : SearchState()
    data class Results(
        val queryId: String,
        val results: List<SearchResult>,
        val totalFound: Int,
        val searchTimeMs: Long,
        val isFromCache: Boolean,
    ) : SearchState()
    data class Error(val queryId: String, val message: String) : SearchState()
    object Cancelled : SearchState()
}

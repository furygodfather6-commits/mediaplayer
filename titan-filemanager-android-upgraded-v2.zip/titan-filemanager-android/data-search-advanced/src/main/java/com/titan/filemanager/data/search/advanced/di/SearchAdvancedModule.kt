package com.titan.filemanager.data.search.advanced.di

import android.content.Context
import com.titan.filemanager.data.search.advanced.SearchEngine
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/** Hilt module exposing [SearchEngine] as application-scoped singleton. */
@Module
@InstallIn(SingletonComponent::class)
object SearchAdvancedModule {

    @Provides @Singleton
    fun provideSearchEngine(@ApplicationContext context: Context): SearchEngine =
        SearchEngine(context)
}

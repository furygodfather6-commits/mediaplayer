package com.titan.filemanager.data.search.advanced.index

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Index Persistence Database.
 *
 * Ported technique: #78 Background indexing
 *
 * Stores index state for fast restart. Uses WAL mode + mmap for
 * performance and batched transactions for bulk inserts.
 */
class IndexDatabase(context: Context) :
    SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    companion object {
        private const val DB_NAME = "search_index_advanced.db"
        private const val DB_VERSION = 1
        private const val TABLE_FILES = "indexed_files"
        private const val TABLE_STATE = "index_state"

        private const val COL_PATH = "file_path"
        private const val COL_NAME = "file_name"
        private const val COL_EXT = "extension"
        private const val COL_SIZE = "file_size"
        private const val COL_MODIFIED = "last_modified"
        private const val COL_INDEXED = "indexed_at"
        private const val COL_IS_DIR = "is_directory"
        private const val COL_KEY = "key"
        private const val COL_VALUE = "value"
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("PRAGMA journal_mode = WAL")
        db.execSQL("PRAGMA synchronous = NORMAL")
        db.execSQL("PRAGMA cache_size = -16000")
        db.execSQL("PRAGMA mmap_size = 268435456")

        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS $TABLE_FILES (
                $COL_PATH     TEXT PRIMARY KEY,
                $COL_NAME     TEXT NOT NULL,
                $COL_EXT      TEXT NOT NULL DEFAULT '',
                $COL_SIZE     INTEGER NOT NULL DEFAULT 0,
                $COL_MODIFIED INTEGER NOT NULL DEFAULT 0,
                $COL_INDEXED  INTEGER NOT NULL DEFAULT 0,
                $COL_IS_DIR   INTEGER NOT NULL DEFAULT 0
            )
            """.trimIndent(),
        )

        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS $TABLE_STATE (
                $COL_KEY   TEXT PRIMARY KEY,
                $COL_VALUE TEXT NOT NULL
            )
            """.trimIndent(),
        )

        db.execSQL("CREATE INDEX IF NOT EXISTS idx_name ON $TABLE_FILES($COL_NAME)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_ext ON $TABLE_FILES($COL_EXT)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_modified ON $TABLE_FILES($COL_MODIFIED)")
    }

    override fun onUpgrade(db: SQLiteDatabase, old: Int, new: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_FILES")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_STATE")
        onCreate(db)
    }

    /** Search files by name prefix — uses SQL LIKE with index. */
    suspend fun searchByName(
        namePrefix: String,
        maxResults: Int = 200,
        includeHidden: Boolean = false,
    ): List<IndexedFile> = withContext(Dispatchers.IO) {
        val results = mutableListOf<IndexedFile>()
        val pattern = "${namePrefix.lowercase()}%"

        readableDatabase.rawQuery(
            """SELECT $COL_PATH, $COL_NAME, $COL_EXT, $COL_SIZE,
               $COL_MODIFIED, $COL_IS_DIR
               FROM $TABLE_FILES
               WHERE LOWER($COL_NAME) LIKE ?
               ${if (!includeHidden) "AND $COL_NAME NOT LIKE '.%'" else ""}
               ORDER BY $COL_MODIFIED DESC
               LIMIT ?""".trimIndent(),
            arrayOf(pattern, maxResults.toString()),
        ).use { cursor ->
            while (cursor.moveToNext()) {
                results.add(
                    IndexedFile(
                        path = cursor.getString(0),
                        name = cursor.getString(1),
                        extension = cursor.getString(2),
                        size = cursor.getLong(3),
                        lastModified = cursor.getLong(4),
                        isDirectory = cursor.getInt(5) == 1,
                    ),
                )
            }
        }
        results
    }

    /** Batch insert files (Technique #89). */
    suspend fun insertBatch(files: List<IndexedFile>) = withContext(Dispatchers.IO) {
        writableDatabase.beginTransactionNonExclusive()
        try {
            files.forEach { file ->
                writableDatabase.execSQL(
                    """INSERT OR REPLACE INTO $TABLE_FILES
                       ($COL_PATH, $COL_NAME, $COL_EXT, $COL_SIZE,
                        $COL_MODIFIED, $COL_INDEXED, $COL_IS_DIR)
                       VALUES (?, ?, ?, ?, ?, ?, ?)""".trimIndent(),
                    arrayOf(
                        file.path, file.name, file.extension,
                        file.size, file.lastModified,
                        System.currentTimeMillis(),
                        if (file.isDirectory) 1 else 0,
                    ),
                )
            }
            writableDatabase.setTransactionSuccessful()
        } finally {
            writableDatabase.endTransaction()
        }
    }

    suspend fun deleteFile(path: String) = withContext(Dispatchers.IO) {
        writableDatabase.delete(TABLE_FILES, "$COL_PATH = ?", arrayOf(path))
    }

    suspend fun saveState(key: String, value: String) = withContext(Dispatchers.IO) {
        writableDatabase.execSQL(
            "INSERT OR REPLACE INTO $TABLE_STATE ($COL_KEY, $COL_VALUE) VALUES (?, ?)",
            arrayOf(key, value),
        )
    }

    suspend fun getState(key: String): String? = withContext(Dispatchers.IO) {
        readableDatabase.rawQuery(
            "SELECT $COL_VALUE FROM $TABLE_STATE WHERE $COL_KEY = ?",
            arrayOf(key),
        ).use { cursor -> if (cursor.moveToFirst()) cursor.getString(0) else null }
    }

    suspend fun getIndexedCount(): Long = withContext(Dispatchers.IO) {
        readableDatabase.rawQuery("SELECT COUNT(*) FROM $TABLE_FILES", null).use { cursor ->
            if (cursor.moveToFirst()) cursor.getLong(0) else 0L
        }
    }

    data class IndexedFile(
        val path: String,
        val name: String,
        val extension: String,
        val size: Long,
        val lastModified: Long,
        val isDirectory: Boolean,
    )
}

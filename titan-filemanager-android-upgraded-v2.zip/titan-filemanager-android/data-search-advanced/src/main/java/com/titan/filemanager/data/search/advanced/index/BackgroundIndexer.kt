package com.titan.filemanager.data.search.advanced.index

import android.content.Context
import android.util.Log
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/**
 * Background Indexer.
 *
 * Ported techniques:
 *   #78 Background indexing
 *   #82 Incremental index update
 *
 * Indexes filesystem in background:
 *  1. Full index on first run
 *  2. Incremental updates on changes
 *  3. Prioritizes recently accessed paths
 *  4. Pauses when CPU/battery is low
 *
 * Index strategy:
 *   Phase 1: index file names only (fast, ~1M files/min)
 *   Phase 2: index metadata (slower)
 *   Phase 3: index content (slowest, only text files)
 */
class BackgroundIndexer(
    private val context: Context,
    private val trieIndex: TrieIndex,
    private val bloomFilter: BloomFilter,
    private val fullTextIndex: FullTextIndex,
    private val indexDatabase: IndexDatabase,
) {

    companion object {
        private const val TAG = "BackgroundIndexer"
        private const val BATCH_SIZE = 500
        private const val INDEX_ROOT = "/storage/emulated/0"
        private const val MAX_FILE_SIZE_FOR_CONTENT = 1024 * 1024L
        private val TEXT_EXTENSIONS = setOf(
            "txt", "md", "log", "csv", "json", "xml",
            "html", "htm", "css", "js", "kt", "java",
            "py", "cpp", "c", "h", "rs", "go", "rb",
        )
    }

    private val isIndexing = AtomicBoolean(false)
    private val isPaused = AtomicBoolean(false)
    private val indexedCount = AtomicInteger(0)
    private val totalToIndex = AtomicInteger(0)
    private val errorCount = AtomicInteger(0)

    private val indexerScope = CoroutineScope(
        Dispatchers.IO.limitedParallelism(2) +
            SupervisorJob() +
            CoroutineName("BackgroundIndexer"),
    )

    private val _progress = MutableSharedFlow<IndexProgress>(replay = 1, extraBufferCapacity = 10)
    val progress: SharedFlow<IndexProgress> = _progress.asSharedFlow()

    /** Start full background indexing. */
    fun startFullIndex(rootPath: String = INDEX_ROOT) {
        if (isIndexing.getAndSet(true)) {
            Log.d(TAG, "Indexing already in progress")
            return
        }

        Log.d(TAG, "Starting full index from: $rootPath")

        indexerScope.launch {
            try {
                _progress.emit(IndexProgress.Started(rootPath))

                val totalFiles = countFiles(rootPath)
                totalToIndex.set(totalFiles)
                Log.d(TAG, "Total files to index: $totalFiles")

                indexFileNames(rootPath)
                indexMetadata(rootPath)

                _progress.emit(
                    IndexProgress.Completed(
                        indexed = indexedCount.get(),
                        errors = errorCount.get(),
                        durationMs = 0L,
                    ),
                )
            } catch (_: kotlinx.coroutines.CancellationException) {
                Log.d(TAG, "Indexing cancelled")
                _progress.emit(IndexProgress.Cancelled)
            } catch (e: Exception) {
                Log.e(TAG, "Indexing failed", e)
                _progress.emit(IndexProgress.Error(e.message ?: "Unknown error"))
            } finally {
                isIndexing.set(false)
            }
        }
    }

    /** Phase 1: index file names into Trie and Bloom filter. */
    private suspend fun indexFileNames(rootPath: String) {
        val batch = ArrayList<Pair<String, String>>(BATCH_SIZE)
        val bloomBatch = ArrayList<String>(BATCH_SIZE)
        var fileCount = 0

        withContext(Dispatchers.IO) {
            walkDirectory(rootPath) { file ->
                if (isPaused.get()) delay(1000L)

                batch.add(Pair(file.name, file.absolutePath))
                bloomBatch.add(file.name.lowercase())
                fileCount++

                if (batch.size >= BATCH_SIZE) {
                    trieIndex.insertBatch(batch.toList())
                    bloomFilter.addAll(bloomBatch.toList())
                    batch.clear()
                    bloomBatch.clear()

                    indexedCount.addAndGet(BATCH_SIZE)
                    emitProgress(indexedCount.get(), totalToIndex.get())
                    kotlinx.coroutines.yield()
                }
            }
        }

        if (batch.isNotEmpty()) {
            trieIndex.insertBatch(batch)
            bloomFilter.addAll(bloomBatch)
            indexedCount.addAndGet(batch.size)
        }

        Log.d(TAG, "Phase 1 complete: $fileCount files indexed in Trie/Bloom")
    }

    /** Phase 2: index metadata into full-text index. */
    private suspend fun indexMetadata(rootPath: String) {
        withContext(Dispatchers.IO) {
            walkDirectory(rootPath) { file ->
                if (isPaused.get()) delay(1000L)

                try {
                    fullTextIndex.indexFileMetadata(
                        filePath = file.absolutePath,
                        fileName = file.name,
                        extension = file.extension,
                        mimeType = getMimeType(file.extension),
                    )

                    if (shouldIndexContent(file)) {
                        indexFileContent(file)
                    }
                } catch (_: Exception) {
                    errorCount.incrementAndGet()
                }
                kotlinx.coroutines.yield()
            }
        }
        Log.d(TAG, "Phase 2 complete: metadata indexed")
    }

    private fun indexFileContent(file: File) {
        if (file.length() > MAX_FILE_SIZE_FOR_CONTENT) return
        try {
            val content = file.readText(Charsets.UTF_8)
            fullTextIndex.indexFileContent(file.absolutePath, content)
        } catch (_: Exception) {
            // Ignore unreadable files
        }
    }

    /** Walk directory efficiently using stack (not recursion). */
    private suspend fun walkDirectory(rootPath: String, onFile: suspend (File) -> Unit) {
        val stack = ArrayDeque<File>()
        stack.addLast(File(rootPath))

        while (stack.isNotEmpty()) {
            val dir = stack.removeLast()
            val children = dir.listFiles() ?: continue
            for (child in children) {
                if (child.isDirectory) stack.addLast(child)
                else onFile(child)
            }
        }
    }

    private suspend fun countFiles(rootPath: String): Int =
        withContext(Dispatchers.IO) {
            var count = 0
            walkDirectory(rootPath) { count++ }
            count
        }

    /** Incremental update for specific directory (Technique #82). */
    fun updateIndex(
        dirPath: String,
        addedFiles: List<String>,
        deletedFiles: List<String>,
        modifiedFiles: List<String>,
    ) {
        indexerScope.launch {
            deletedFiles.forEach { path ->
                val fileName = File(path).name
                trieIndex.delete(fileName, path)
                fullTextIndex.removeDocument(path)
            }

            val addBatch = addedFiles.map { path -> Pair(File(path).name, path) }
            trieIndex.insertBatch(addBatch)
            bloomFilter.addAll(addedFiles.map { File(it).name.lowercase() })

            addedFiles.forEach { path ->
                fullTextIndex.indexFileMetadata(path, File(path).name, File(path).extension, "")
            }

            modifiedFiles.forEach { path ->
                fullTextIndex.removeDocument(path)
                fullTextIndex.indexFileMetadata(path, File(path).name, File(path).extension, "")
            }

            Log.d(TAG, "Incremental update: +${addedFiles.size} -${deletedFiles.size} ~${modifiedFiles.size}")
        }
    }

    private suspend fun emitProgress(indexed: Int, total: Int) {
        _progress.emit(
            IndexProgress.Progress(
                indexed = indexed,
                total = total,
                progress = if (total > 0) indexed.toFloat() / total else 0f,
            ),
        )
    }

    fun pause() { isPaused.set(true) }
    fun resume() { isPaused.set(false) }
    fun cancel() {
        indexerScope.coroutineContext[kotlinx.coroutines.Job]?.cancel()
        isIndexing.set(false)
    }

    fun isIndexing(): Boolean = isIndexing.get()

    private fun shouldIndexContent(file: File): Boolean =
        file.extension.lowercase() in TEXT_EXTENSIONS && file.length() <= MAX_FILE_SIZE_FOR_CONTENT

    private fun getMimeType(ext: String): String = when (ext.lowercase()) {
        "jpg", "jpeg" -> "image/jpeg"
        "png" -> "image/png"
        "mp4" -> "video/mp4"
        "mp3" -> "audio/mpeg"
        "pdf" -> "application/pdf"
        else -> "application/octet-stream"
    }

    sealed class IndexProgress {
        data class Started(val rootPath: String) : IndexProgress()
        data class Progress(val indexed: Int, val total: Int, val progress: Float) : IndexProgress()
        data class Completed(val indexed: Int, val errors: Int, val durationMs: Long) : IndexProgress()
        object Cancelled : IndexProgress()
        data class Error(val message: String) : IndexProgress()
    }
}

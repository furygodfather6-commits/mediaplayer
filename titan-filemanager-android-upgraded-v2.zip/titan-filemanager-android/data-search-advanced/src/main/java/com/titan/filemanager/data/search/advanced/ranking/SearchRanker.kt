package com.titan.filemanager.data.search.advanced.ranking

import com.titan.filemanager.data.search.advanced.MatchType
import com.titan.filemanager.data.search.advanced.SearchQuery
import com.titan.filemanager.data.search.advanced.SearchResult
import java.io.File

/**
 * Search Result Ranker.
 *
 * Ported technique: #85 Search ranking
 *
 * Multi-factor ranking:
 *  1. Match type (exact > prefix > contains > fuzzy)
 *  2. Query relevance (TF-IDF score)
 *  3. File recency (recently modified ranks higher)
 *  4. Usage frequency (frequently accessed ranks higher)
 *  5. File type preference (user's preferred types)
 *  6. Path depth (shallower = more accessible)
 */
class SearchRanker {

    companion object {
        // Weights for ranking factors
        private const val W_MATCH_TYPE = 0.40f
        private const val W_RELEVANCE = 0.25f
        private const val W_RECENCY = 0.15f
        private const val W_USAGE = 0.10f
        private const val W_DEPTH = 0.10f

        // Match type base scores
        private val MATCH_TYPE_SCORES = mapOf(
            MatchType.EXACT_NAME to 1.0f,
            MatchType.PREFIX_NAME to 0.85f,
            MatchType.CONTAINS_NAME to 0.70f,
            MatchType.CONTENT_MATCH to 0.60f,
            MatchType.FUZZY_NAME to 0.45f,
            MatchType.METADATA_MATCH to 0.40f,
        )
    }

    /** Rank list of search results. */
    fun rank(
        results: List<SearchResult>,
        query: SearchQuery,
        usageStats: Map<String, Float> = emptyMap(),
    ): List<SearchResult> {
        val now = System.currentTimeMillis()

        return results
            .map { result ->
                val score = calculateScore(result, query, usageStats, now)
                result.copy(relevanceScore = score)
            }
            .sortedByDescending { it.relevanceScore }
            .mapIndexed { index, result -> result.copy(rank = index + 1) }
    }

    private fun calculateScore(
        result: SearchResult,
        query: SearchQuery,
        usageStats: Map<String, Float>,
        now: Long,
    ): Float {
        val matchScore = MATCH_TYPE_SCORES[result.matchType] ?: 0.3f
        val relevanceScore = calculateRelevance(result, query)

        // Recency score (exponential decay — 1 week half-life)
        val ageMs = now - result.lastModified
        val recencyScore = Math.exp(-ageMs / (7.0 * 24 * 60 * 60 * 1000)).toFloat().coerceIn(0f, 1f)

        val usageScore = usageStats[result.filePath] ?: 0f

        // Path depth score (shallower = better)
        val depth = result.filePath.count { it == '/' }
        val depthScore = (1f / (depth + 1)).coerceIn(0f, 1f)

        return (matchScore * W_MATCH_TYPE) +
            (relevanceScore * W_RELEVANCE) +
            (recencyScore * W_RECENCY) +
            (usageScore * W_USAGE) +
            (depthScore * W_DEPTH)
    }

    private fun calculateRelevance(result: SearchResult, query: SearchQuery): Float {
        val queryText = query.normalizedText
        val fileName = result.fileName.lowercase()

        return when {
            fileName == queryText -> 1.0f
            fileName.startsWith(queryText) -> 0.9f
            fileName.split(Regex("[._\\-\\s]")).any { it == queryText } -> 0.8f
            fileName.contains(queryText) -> 0.6f
            File(fileName).nameWithoutExtension.endsWith(queryText) -> 0.5f
            else -> 0.3f
        }
    }

    /** Apply user preference boosting. */
    fun applyPreferenceBoost(
        results: List<SearchResult>,
        preferredTypes: Set<String>,
    ): List<SearchResult> {
        if (preferredTypes.isEmpty()) return results

        return results.map { result ->
            val boost = if (result.mimeType.split("/").firstOrNull() in preferredTypes) 1.2f else 1.0f
            result.copy(relevanceScore = result.relevanceScore * boost)
        }.sortedByDescending { it.relevanceScore }
    }
}

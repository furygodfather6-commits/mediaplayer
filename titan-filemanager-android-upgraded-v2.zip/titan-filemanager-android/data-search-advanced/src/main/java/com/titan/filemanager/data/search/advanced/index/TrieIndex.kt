package com.titan.filemanager.data.search.advanced.index

import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.locks.ReentrantReadWriteLock

/**
 * Trie Index for Ultra-Fast Prefix Search.
 *
 * Ported technique: #79 Trie index
 *
 * Why Trie?
 *  - Prefix search: O(k) where k = query length
 *  - Autocomplete support
 *  - Memory efficient for common prefixes
 *  - Thread-safe with R/W lock
 *
 * Example:
 *   Files: "photo.jpg", "photo_backup.jpg", "phone.mp4"
 *   Trie: p→h→o→t→o(.jpg, _backup.jpg)
 *                →n→e(.mp4)
 *
 *   Search "pho": returns all 3 instantly
 *   Search "phot": returns photo.jpg, photo_backup.jpg
 */
class TrieIndex @javax.inject.Inject constructor() {

    companion object {
        private const val MAX_RESULTS_PER_PREFIX = 200
        private const val MAX_CHILDREN = 128 // ASCII printable
    }

    private val root = TrieNode()
    private val size = AtomicInteger(0)

    private val lock = ReentrantReadWriteLock()
    private val readLock = lock.readLock()
    private val writeLock = lock.writeLock()

    /** Insert file into trie. Indexes by lowercase filename. */
    fun insert(fileName: String, filePath: String) {
        val normalized = fileName.lowercase()
        writeLock.lock()
        try {
            var current = root
            for (char in normalized) {
                val index = charToIndex(char)
                if (index < 0) continue
                if (current.children[index] == null) {
                    current.children[index] = TrieNode()
                }
                current = current.children[index]!!
                current.addPath(filePath)
            }
            current.isEndOfWord = true
            current.paths.add(filePath)
            size.incrementAndGet()
        } finally {
            writeLock.unlock()
        }
    }

    /** Insert multiple files (batch — more efficient). */
    fun insertBatch(files: List<Pair<String, String>>) {
        writeLock.lock()
        try {
            for ((fileName, filePath) in files) {
                val normalized = fileName.lowercase()
                var current = root
                for (char in normalized) {
                    val index = charToIndex(char)
                    if (index < 0) continue
                    if (current.children[index] == null) {
                        current.children[index] = TrieNode()
                    }
                    current = current.children[index]!!
                    current.addPath(filePath)
                }
                current.isEndOfWord = true
                current.paths.add(filePath)
                size.incrementAndGet()
            }
        } finally {
            writeLock.unlock()
        }
    }

    /** Search by prefix — O(k) complexity where k = prefix length. */
    fun searchByPrefix(prefix: String, maxResults: Int = MAX_RESULTS_PER_PREFIX): List<String> {
        val normalized = prefix.lowercase()
        readLock.lock()
        try {
            var current = root
            for (char in normalized) {
                val index = charToIndex(char)
                if (index < 0) return emptyList()
                current = current.children[index] ?: return emptyList()
            }
            return current.allPaths.take(maxResults)
        } finally {
            readLock.unlock()
        }
    }

    /** Exact name search. */
    fun searchExact(name: String): List<String> {
        val normalized = name.lowercase()
        readLock.lock()
        try {
            var current = root
            for (char in normalized) {
                val index = charToIndex(char)
                if (index < 0) return emptyList()
                current = current.children[index] ?: return emptyList()
            }
            return if (current.isEndOfWord) current.paths.toList() else emptyList()
        } finally {
            readLock.unlock()
        }
    }

    /**
     * Fuzzy search using character-level matching — allows 1-2 char differences.
     * Returns list of (path, editDistance) pairs.
     */
    fun searchFuzzy(query: String, maxDistance: Int = 2, maxResults: Int = 50): List<Pair<String, Int>> {
        val normalized = query.lowercase()
        val results = mutableListOf<Pair<String, Int>>()

        readLock.lock()
        try {
            searchFuzzyRecursive(
                root, normalized, null,
                IntArray(normalized.length + 1) { it },
                maxDistance, results, maxResults,
                StringBuilder(),
            )
        } finally {
            readLock.unlock()
        }

        return results.sortedBy { it.second }.take(maxResults)
    }

    /** Recursive fuzzy search using Wagner-Fischer algorithm. */
    private fun searchFuzzyRecursive(
        node: TrieNode,
        query: String,
        nodeChar: Char?,
        prevRow: IntArray,
        maxDistance: Int,
        results: MutableList<Pair<String, Int>>,
        maxResults: Int,
        currentWord: StringBuilder,
    ) {
        if (results.size >= maxResults) return

        val columns = query.length + 1
        val currentRow = IntArray(columns)
        currentRow[0] = prevRow[0] + 1

        for (col in 1 until columns) {
            val insertCost = currentRow[col - 1] + 1
            val deleteCost = prevRow[col] + 1
            val replaceCost = if (nodeChar != null && query[col - 1] != nodeChar) {
                prevRow[col - 1] + 1
            } else {
                prevRow[col - 1]
            }
            currentRow[col] = minOf(insertCost, deleteCost, replaceCost)
        }

        if (node.isEndOfWord && currentRow[query.length] <= maxDistance) {
            node.paths.forEach { path -> results.add(Pair(path, currentRow[query.length])) }
        }

        // Prune: if minimum in current row exceeds max distance, skip subtree
        if (currentRow.minOrNull()!! <= maxDistance) {
            for (i in node.children.indices) {
                val child = node.children[i] ?: continue
                val char = indexToChar(i)
                currentWord.append(char)
                searchFuzzyRecursive(
                    child, query, char, currentRow,
                    maxDistance, results, maxResults, currentWord,
                )
                currentWord.deleteCharAt(currentWord.length - 1)
            }
        }
    }

    /** Delete file from trie. */
    fun delete(fileName: String, filePath: String) {
        val normalized = fileName.lowercase()
        writeLock.lock()
        try {
            deleteRecursive(root, normalized, filePath, 0)
        } finally {
            writeLock.unlock()
        }
    }

    private fun deleteRecursive(node: TrieNode, word: String, path: String, depth: Int): Boolean {
        if (depth == word.length) {
            node.paths.remove(path)
            node.allPaths.remove(path)
            if (node.paths.isEmpty()) node.isEndOfWord = false
            return node.children.all { it == null } && !node.isEndOfWord
        }

        val index = charToIndex(word[depth])
        if (index < 0) return false
        val child = node.children[index] ?: return false

        node.allPaths.remove(path)

        val shouldDelete = deleteRecursive(child, word, path, depth + 1)
        if (shouldDelete) {
            node.children[index] = null
        }
        return shouldDelete && node.paths.isEmpty() && node.children.all { it == null }
    }

    fun getSize(): Int = size.get()

    private fun charToIndex(char: Char): Int {
        val code = char.code
        return if (code < MAX_CHILDREN) code else -1
    }

    private fun indexToChar(index: Int): Char = index.toChar()

    /** Trie node — uses array for O(1) child access. */
    private class TrieNode {
        val children = arrayOfNulls<TrieNode>(MAX_CHILDREN)
        var isEndOfWord = false

        // Paths at this exact node (for exact match)
        val paths = ArrayList<String>(2)

        // All paths in subtree (for prefix search)
        val allPaths = ArrayList<String>(10)

        fun addPath(path: String) {
            if (!allPaths.contains(path)) allPaths.add(path)
        }
    }
}

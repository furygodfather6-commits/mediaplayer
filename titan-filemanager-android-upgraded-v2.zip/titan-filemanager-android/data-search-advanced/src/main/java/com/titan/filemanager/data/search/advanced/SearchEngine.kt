package com.titan.filemanager.data.search.advanced

import android.content.Context
import android.util.Log
import com.titan.filemanager.data.search.advanced.cache.SearchResultCache
import com.titan.filemanager.data.search.advanced.executor.ParallelSearchExecutor
import com.titan.filemanager.data.search.advanced.index.BackgroundIndexer
import com.titan.filemanager.data.search.advanced.index.BloomFilter
import com.titan.filemanager.data.search.advanced.index.FullTextIndex
import com.titan.filemanager.data.search.advanced.index.IndexDatabase
import com.titan.filemanager.data.search.advanced.index.TrieIndex
import com.titan.filemanager.data.search.advanced.ranking.SearchRanker
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Master Search Engine.
 *
 * Ported Phase H techniques #78-#85 — all search techniques.
 *
 * Pipeline:
 *   Query → Cache? → Bloom Filter → Trie/FTS/FS
 *        → Merge → Rank → Cache → Emit
 */
@Singleton
class SearchEngine @Inject constructor(
    context: Context,
) {

    companion object {
        private const val TAG = "SearchEngine"
    }

    val trieIndex = TrieIndex()
    val bloomFilter = BloomFilter(expectedElements = 1_000_000)
    val fullTextIndex = FullTextIndex()
    val indexDatabase = IndexDatabase(context)

    val backgroundIndexer = BackgroundIndexer(
        context = context,
        trieIndex = trieIndex,
        bloomFilter = bloomFilter,
        fullTextIndex = fullTextIndex,
        indexDatabase = indexDatabase,
    )

    private val resultCache = SearchResultCache()
    private val ranker = SearchRanker()

    val executor = ParallelSearchExecutor(
        trieIndex = trieIndex,
        bloomFilter = bloomFilter,
        fullTextIndex = fullTextIndex,
        ranker = ranker,
    )

    private val engineScope = CoroutineScope(
        Dispatchers.IO + SupervisorJob() + CoroutineName("SearchEngine"),
    )

    private var activeSearchJob: Job? = null

    /** Execute search query — returns Flow of progressive results. */
    fun search(query: SearchQuery): Flow<SearchState> = flow {
        if (!query.isValid) {
            emit(SearchState.Error(query.id, "Invalid query"))
            return@flow
        }

        val cached = resultCache.get(query.text, query.rootPath)
        if (cached != null) {
            Log.d(TAG, "Cache hit for: ${query.text}")
            emit(
                SearchState.Results(
                    queryId = query.id,
                    results = cached,
                    totalFound = cached.size,
                    searchTimeMs = 0L,
                    isFromCache = true,
                ),
            )
            return@flow
        }

        executor.execute(query).collect { state ->
            emit(state)
            if (state is SearchState.Results && !state.isFromCache) {
                resultCache.put(query.text, query.rootPath, state.results)
            }
        }
    }

    /** Incremental search — cancel previous, start new. For real-time search as user types. */
    fun searchIncremental(text: String, rootPath: String, onResults: (SearchState) -> Unit) {
        activeSearchJob?.cancel()
        if (text.length < 1) {
            onResults(SearchState.Idle)
            return
        }

        val query = SearchQuery(
            text = text,
            rootPath = rootPath,
            priority = SearchPriority.REALTIME,
            maxResults = 100,
        )

        activeSearchJob = engineScope.launch {
            search(query).collect { state ->
                withContext(Dispatchers.Main) { onResults(state) }
            }
        }
    }

    fun startIndexing(rootPath: String = "/storage/emulated/0") {
        backgroundIndexer.startFullIndex(rootPath)
    }

    fun onFilesChanged(
        dirPath: String,
        added: List<String>,
        deleted: List<String>,
        modified: List<String>,
    ) {
        backgroundIndexer.updateIndex(dirPath, added, deleted, modified)
        resultCache.invalidateForPath(dirPath)
    }

    fun getIndexStats(): IndexStats = IndexStats(
        trieSize = trieIndex.getSize(),
        bloomInserts = bloomFilter.getInsertCount(),
        bloomFPRate = bloomFilter.estimateFalsePositiveRate(),
        ftsDocCount = fullTextIndex.getDocumentCount(),
        cacheHitRate = resultCache.getHitRate(),
        isIndexing = backgroundIndexer.isIndexing(),
    )

    fun shutdown() {
        activeSearchJob?.cancel()
        engineScope.cancel()
        backgroundIndexer.cancel()
    }

    data class IndexStats(
        val trieSize: Int,
        val bloomInserts: Long,
        val bloomFPRate: Double,
        val ftsDocCount: Int,
        val cacheHitRate: Float,
        val isIndexing: Boolean,
    )
}

package com.titan.filemanager.data.search.advanced.executor

import com.titan.filemanager.data.search.advanced.FileTypeFilter
import com.titan.filemanager.data.search.advanced.MatchType
import com.titan.filemanager.data.search.advanced.QueryType
import com.titan.filemanager.data.search.advanced.SearchQuery
import com.titan.filemanager.data.search.advanced.SearchResult
import com.titan.filemanager.data.search.advanced.SearchState
import com.titan.filemanager.data.search.advanced.index.BloomFilter
import com.titan.filemanager.data.search.advanced.index.FullTextIndex
import com.titan.filemanager.data.search.advanced.index.TrieIndex
import com.titan.filemanager.data.search.advanced.ranking.SearchRanker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.flow.flowOn
import java.io.File
import java.util.concurrent.ConcurrentHashMap

/**
 * Parallel Search Executor.
 *
 * Ported technique: #83 Parallel search
 *
 * Executes multiple search strategies in parallel:
 *  1. Trie prefix search (instant)
 *  2. Full-text metadata search
 *  3. Content search (if enabled)
 *  4. Filesystem fallback (if index incomplete)
 *
 * Results merged and de-duplicated in real-time.
 */
class ParallelSearchExecutor(
    private val trieIndex: TrieIndex,
    private val bloomFilter: BloomFilter,
    private val fullTextIndex: FullTextIndex,
    private val ranker: SearchRanker,
) {

    companion object {
        private const val SEARCH_PARALLELISM = 4
    }

    private val searchDispatcher = Dispatchers.IO.limitedParallelism(SEARCH_PARALLELISM)

    /** Execute search — returns Flow of progressive results. */
    fun execute(query: SearchQuery): Flow<SearchState> = channelFlow {
        if (!query.isValid) {
            send(SearchState.Error(query.id, "Query too short"))
            return@channelFlow
        }

        send(SearchState.Searching(query.id, 0))

        val startTime = System.currentTimeMillis()
        val allResults = ConcurrentHashMap<String, SearchResult>()

        // STRATEGY 1: Bloom Filter pre-check — eliminate obvious misses instantly
        if (bloomFilter.definitelyNotContains(query.normalizedText)) {
            send(
                SearchState.Results(
                    queryId = query.id,
                    results = emptyList(),
                    totalFound = 0,
                    searchTimeMs = System.currentTimeMillis() - startTime,
                    isFromCache = false,
                ),
            )
            return@channelFlow
        }

        coroutineScope {
            // STRATEGY 2: Trie prefix search (FASTEST)
            val trieJob = async(searchDispatcher) { searchWithTrie(query) }

            // STRATEGY 3: Full-text search (MEDIUM)
            val ftsJob = async(searchDispatcher) { searchWithFts(query) }

            // STRATEGY 4: Filesystem search (FALLBACK)
            val fsJob = if (query.recursive) {
                async(searchDispatcher) { searchFilesystem(query) }
            } else null

            // Emit trie results first (fastest)
            val trieResults = trieJob.await()
            trieResults.forEach { allResults[it.filePath] = it }
            send(SearchState.Searching(query.id, allResults.size))

            if (allResults.isNotEmpty()) {
                val ranked = ranker.rank(allResults.values.toList(), query)
                send(
                    SearchState.Results(
                        queryId = query.id,
                        results = ranked.take(query.maxResults),
                        totalFound = ranked.size,
                        searchTimeMs = System.currentTimeMillis() - startTime,
                        isFromCache = false,
                    ),
                )
            }

            // Wait for remaining jobs
            val ftsResults = ftsJob.await()
            ftsResults.forEach { allResults[it.filePath] = it }

            fsJob?.await()?.forEach { allResults[it.filePath] = it }

            // Final ranked results
            val finalResults = ranker.rank(allResults.values.toList(), query).take(query.maxResults)

            send(
                SearchState.Results(
                    queryId = query.id,
                    results = finalResults,
                    totalFound = allResults.size,
                    searchTimeMs = System.currentTimeMillis() - startTime,
                    isFromCache = false,
                ),
            )
        }
    }.catch { e ->
        emit(SearchState.Error(query.id, e.message ?: "Search failed"))
    }.flowOn(searchDispatcher)

    private fun searchWithTrie(query: SearchQuery): List<SearchResult> {
        val paths = when (query.queryType) {
            QueryType.KEYWORD -> trieIndex.searchByPrefix(query.normalizedText)
            else -> trieIndex.searchByPrefix(query.normalizedText)
        }
        return paths.mapNotNull { path -> buildResult(path, query, MatchType.PREFIX_NAME) }
    }

    private fun searchWithFts(query: SearchQuery): List<SearchResult> {
        val ftsResults = fullTextIndex.search(query.normalizedText)
        return ftsResults.mapNotNull { ftsResult ->
            buildResult(ftsResult.filePath, query, ftsResult.matchType)
        }
    }

    /** Direct filesystem search (fallback) — uses optimized file walking. */
    private fun searchFilesystem(query: SearchQuery): List<SearchResult> {
        val results = mutableListOf<SearchResult>()
        val stack = ArrayDeque<File>()
        stack.addLast(File(query.rootPath))

        val pattern = query.normalizedText
        var count = 0

        while (stack.isNotEmpty() && count < query.maxResults) {
            val dir = stack.removeLast()
            val children = dir.listFiles() ?: continue

            for (child in children) {
                if (child.isDirectory) {
                    stack.addLast(child)
                    continue
                }

                val name = child.name.lowercase()
                val matchType = when {
                    name == pattern -> MatchType.EXACT_NAME
                    name.startsWith(pattern) -> MatchType.PREFIX_NAME
                    name.contains(pattern) -> MatchType.CONTAINS_NAME
                    else -> continue
                }

                if (!passesFilters(child, query)) continue

                buildResult(child.absolutePath, query, matchType)?.let { results.add(it) }
                count++
            }
        }
        return results
    }

    private fun buildResult(path: String, query: SearchQuery, matchType: MatchType): SearchResult? {
        return try {
            val file = File(path)
            if (!file.exists()) return null
            if (!passesFilters(file, query)) return null

            SearchResult(
                filePath = path,
                fileName = file.name,
                fileSize = file.length(),
                lastModified = file.lastModified(),
                isDirectory = file.isDirectory,
                mimeType = getMimeType(file.extension),
                relevanceScore = 0f,
                matchType = matchType,
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun passesFilters(file: File, query: SearchQuery): Boolean {
        query.sizeRange?.let { range -> if (file.length() !in range) return false }
        query.dateRange?.let { range -> if (file.lastModified() !in range) return false }

        if (!query.includeHidden && file.name.startsWith(".")) return false

        if (query.fileTypes.isNotEmpty()) {
            val ext = file.extension.lowercase()
            val matches = query.fileTypes.any { filter ->
                ext in filter.extensions || filter == FileTypeFilter.FOLDER && file.isDirectory
            }
            if (!matches) return false
        }
        return true
    }

    private fun getMimeType(ext: String): String = when (ext.lowercase()) {
        "jpg", "jpeg" -> "image/jpeg"
        "png" -> "image/png"
        "mp4" -> "video/mp4"
        "mp3" -> "audio/mpeg"
        "pdf" -> "application/pdf"
        else -> "application/octet-stream"
    }
}

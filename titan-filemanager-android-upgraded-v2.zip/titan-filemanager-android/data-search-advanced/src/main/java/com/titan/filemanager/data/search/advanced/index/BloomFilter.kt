package com.titan.filemanager.data.search.advanced.index

import android.util.Log
import java.util.BitSet
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.ln
import kotlin.math.pow

/**
 * Bloom Filter for Ultra-Fast Existence Check.
 *
 * Ported technique: #80 Bloom filter
 *
 * Why Bloom Filter?
 *  - O(k) lookup where k = hash functions (constant!)
 *  - Answers "definitely NOT present" or "MAYBE present"
 *  - Memory efficient: 10M files = ~10MB
 *  - Zero false negatives (if says NO, it's definitely NO)
 *  - Small false positives (~1% with good parameters)
 *
 * Use case: before expensive trie/db lookup, check bloom filter first.
 * If NO → skip immediately.
 *
 * Example:
 *   Search "photo" in 1M files:
 *     Without Bloom: scan all 1M entries
 *     With Bloom:    reject 99% immediately, scan ~10K
 */
class BloomFilter(
    expectedElements: Int = 1_000_000,
    falsePositiveProbability: Double = 0.01,
) {

    private val bitSetSize: Int = optimalBitSetSize(expectedElements, falsePositiveProbability)
    private val hashCount: Int = optimalHashCount(bitSetSize, expectedElements)

    private val bitSet = BitSet(bitSetSize)
    private val bitSetLock = Any()

    private val insertCount = AtomicLong(0L)
    private val queryCount = AtomicLong(0L)
    private val falsePositives = AtomicLong(0L)

    init {
        Log.d(
            "BloomFilter",
            "Created: bits=$bitSetSize hashFunctions=$hashCount " +
                "expectedFP=${String.format("%.2f", falsePositiveProbability * 100)}%",
        )
    }

    fun add(element: String) {
        val hashes = getHashes(element)
        synchronized(bitSetLock) {
            hashes.forEach { hash -> bitSet.set(hash) }
        }
        insertCount.incrementAndGet()
    }

    fun addAll(elements: Collection<String>) {
        synchronized(bitSetLock) {
            elements.forEach { element ->
                getHashes(element).forEach { hash -> bitSet.set(hash) }
                insertCount.incrementAndGet()
            }
        }
    }

    /** Check if element MIGHT be present. False negatives: IMPOSSIBLE. */
    fun mightContain(element: String): Boolean {
        queryCount.incrementAndGet()
        val hashes = getHashes(element)
        synchronized(bitSetLock) {
            return hashes.all { hash -> bitSet.get(hash) }
        }
    }

    /** Definitely NOT present — 100% accurate NO answers. */
    fun definitelyNotContains(element: String): Boolean = !mightContain(element)

    /** Bulk check: filter list to only potential matches. */
    fun filterPotentialMatches(candidates: List<String>): List<String> =
        candidates.filter { mightContain(it) }

    /** Generate k hash values for element. Uses double hashing: h(i) = h1 + i*h2. */
    private fun getHashes(element: String): IntArray {
        val h1 = murmurHash3(element, 0)
        val h2 = murmurHash3(element, h1.toInt())
        return IntArray(hashCount) { i ->
            abs((h1 + i.toLong() * h2) % bitSetSize).toInt()
        }
    }

    /** MurmurHash3 — fast, good distribution. */
    private fun murmurHash3(input: String, seed: Int): Long {
        val data = input.toByteArray()
        var h1 = seed.toLong()
        val c1 = 0xcc9e2d51L
        val c2 = 0x1b873593L

        var i = 0
        while (i + 4 <= data.size) {
            var k1 = (data[i].toLong() and 0xFF) or
                ((data[i + 1].toLong() and 0xFF) shl 8) or
                ((data[i + 2].toLong() and 0xFF) shl 16) or
                ((data[i + 3].toLong() and 0xFF) shl 24)

            k1 = (k1 * c1) and 0xFFFFFFFFL
            k1 = rotl32(k1, 15)
            k1 = (k1 * c2) and 0xFFFFFFFFL

            h1 = h1 xor k1
            h1 = rotl32(h1, 13)
            h1 = ((h1 * 5) + 0xe6546b64L) and 0xFFFFFFFFL
            i += 4
        }

        var k1 = 0L
        val remaining = data.size - i
        if (remaining >= 3) k1 = k1 xor ((data[i + 2].toLong() and 0xFF) shl 16)
        if (remaining >= 2) k1 = k1 xor ((data[i + 1].toLong() and 0xFF) shl 8)
        if (remaining >= 1) {
            k1 = k1 xor (data[i].toLong() and 0xFF)
            k1 = (k1 * c1) and 0xFFFFFFFFL
            k1 = rotl32(k1, 15)
            k1 = (k1 * c2) and 0xFFFFFFFFL
            h1 = h1 xor k1
        }

        h1 = h1 xor data.size.toLong()
        return fmix32(h1)
    }

    private fun rotl32(x: Long, r: Int): Long = ((x shl r) or (x ushr (32 - r))) and 0xFFFFFFFFL

    private fun fmix32(h: Long): Long {
        var result = h
        result = (result xor (result ushr 16)) and 0xFFFFFFFFL
        result = (result * 0x85ebca6bL) and 0xFFFFFFFFL
        result = (result xor (result ushr 13)) and 0xFFFFFFFFL
        result = (result * 0xc2b2ae35L) and 0xFFFFFFFFL
        result = (result xor (result ushr 16)) and 0xFFFFFFFFL
        return result
    }

    fun clear() {
        synchronized(bitSetLock) { bitSet.clear() }
        insertCount.set(0L)
    }

    fun estimateFalsePositiveRate(): Double {
        val setBits = synchronized(bitSetLock) { bitSet.cardinality() }
        val ratio = setBits.toDouble() / bitSetSize
        return ratio.pow(hashCount.toDouble())
    }

    fun getInsertCount(): Long = insertCount.get()
    fun getQueryCount(): Long = queryCount.get()

    private fun optimalBitSetSize(n: Int, p: Double): Int =
        ceil((-n * ln(p)) / (ln(2.0).pow(2))).toInt().coerceAtLeast(1024)

    private fun optimalHashCount(m: Int, n: Int): Int =
        (m.toDouble() / n * ln(2.0)).toInt().coerceIn(1, 20)

    data class BloomStats(
        val bitSetSize: Int,
        val hashCount: Int,
        val insertCount: Long,
        val queryCount: Long,
        val estimatedFPRate: Double,
        val fillRatio: Double,
    )

    fun getStats(): BloomStats {
        val setBits = synchronized(bitSetLock) { bitSet.cardinality() }
        return BloomStats(
            bitSetSize = bitSetSize,
            hashCount = hashCount,
            insertCount = insertCount.get(),
            queryCount = queryCount.get(),
            estimatedFPRate = estimateFalsePositiveRate(),
            fillRatio = setBits.toDouble() / bitSetSize,
        )
    }
}

package com.titan.filemanager.data.search.advanced.index

import com.titan.filemanager.data.search.advanced.MatchType
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.locks.ReentrantReadWriteLock

/**
 * Full Text Index.
 *
 * Ported technique: #81 Full-text index
 *
 * Inverted index for content-based search: word → list of (filePath, positions).
 *
 * Supports:
 *  - Word-level search
 *  - Phrase search
 *  - Proximity search
 *  - Term frequency scoring (TF-IDF)
 */
class FullTextIndex {

    companion object {
        private val STOP_WORDS = setOf(
            "the", "a", "an", "and", "or", "but", "in",
            "on", "at", "to", "for", "of", "with", "by",
            "is", "it", "be", "as", "at", "so", "we",
            "he", "she", "they", "this", "that", "from",
        )
        private const val MIN_TERM_LENGTH = 2
        private const val MAX_TERM_LENGTH = 50
    }

    // Inverted index: term → postings list
    private val invertedIndex = ConcurrentHashMap<String, PostingsList>(10_000)

    // Document store: filePath → document info
    private val documents = ConcurrentHashMap<String, DocumentInfo>(100_000)

    private val lock = ReentrantReadWriteLock()
    private val readLock = lock.readLock()
    private val writeLock = lock.writeLock()

    private var totalTerms = 0L

    /** Index file metadata (name, path, extension) — fast, always available. */
    fun indexFileMetadata(filePath: String, fileName: String, extension: String, mimeType: String) {
        val terms = extractTerms(fileName) + extractTerms(extension)
        indexDocument(filePath, terms, DocumentType.METADATA)
    }

    /** Index file content (for deep search) — only for text-based files. */
    fun indexFileContent(filePath: String, content: String, chunkSize: Int = 10_000) {
        var start = 0
        while (start < content.length) {
            val end = minOf(start + chunkSize, content.length)
            val chunk = content.substring(start, end)
            val terms = extractTerms(chunk)
            indexDocument(filePath, terms, DocumentType.CONTENT)
            start = end
        }
    }

    private fun indexDocument(docId: String, terms: List<IndexedTerm>, docType: DocumentType) {
        writeLock.lock()
        try {
            val existing = documents[docId]
            documents[docId] = DocumentInfo(
                docId = docId,
                termCount = (existing?.termCount ?: 0) + terms.size,
                docType = docType,
                indexedAt = System.currentTimeMillis(),
            )

            for (term in terms) {
                val postings = invertedIndex.getOrPut(term.text) { PostingsList() }
                postings.addPosting(docId, term.position, term.frequency)
            }

            totalTerms += terms.size
        } finally {
            writeLock.unlock()
        }
    }

    /** Search for term — returns ranked list of file paths. */
    fun search(query: String, maxResults: Int = 100): List<TermSearchResult> {
        val terms = extractQueryTerms(query)
        if (terms.isEmpty()) return emptyList()

        readLock.lock()
        try {
            return if (terms.size == 1) {
                singleTermSearch(terms[0], maxResults)
            } else {
                multiTermSearch(terms, maxResults)
            }
        } finally {
            readLock.unlock()
        }
    }

    /** Single term search with TF-IDF ranking. */
    private fun singleTermSearch(term: String, maxResults: Int): List<TermSearchResult> {
        val postings = invertedIndex[term] ?: return emptyList()
        val totalDocs = documents.size.toFloat()

        return postings.getPostings()
            .map { posting ->
                val docInfo = documents[posting.docId]
                val tf = posting.frequency.toFloat() / (docInfo?.termCount ?: 1).toFloat()
                val idf = Math.log((totalDocs / (postings.size + 1)).toDouble()).toFloat()
                TermSearchResult(
                    filePath = posting.docId,
                    score = tf * idf,
                    positions = posting.positions,
                    matchType = MatchType.CONTAINS_NAME,
                )
            }
            .sortedByDescending { it.score }
            .take(maxResults)
    }

    /** Multi-term search with AND logic — documents must contain ALL terms. */
    private fun multiTermSearch(terms: List<String>, maxResults: Int): List<TermSearchResult> {
        val sortedTerms = terms.sortedBy { invertedIndex[it]?.size ?: 0 }

        val firstTerm = sortedTerms.first()
        val candidates = invertedIndex[firstTerm]
            ?.getPostings()?.map { it.docId }?.toHashSet() ?: return emptyList()

        for (term in sortedTerms.drop(1)) {
            val termDocs = invertedIndex[term]
                ?.getPostings()?.map { it.docId }?.toHashSet() ?: return emptyList()
            candidates.retainAll(termDocs)
            if (candidates.isEmpty()) return emptyList()
        }

        return candidates
            .map { docId ->
                var score = 0f
                val positions = mutableListOf<Int>()
                for (term in terms) {
                    invertedIndex[term]?.getPosting(docId)?.let { posting ->
                        score += posting.frequency
                        positions.addAll(posting.positions)
                    }
                }
                TermSearchResult(
                    filePath = docId,
                    score = score,
                    positions = positions,
                    matchType = MatchType.CONTENT_MATCH,
                )
            }
            .sortedByDescending { it.score }
            .take(maxResults)
    }

    fun removeDocument(filePath: String) {
        writeLock.lock()
        try {
            documents.remove(filePath)
            // Note: lazy removal from inverted index — filtered during search
        } finally {
            writeLock.unlock()
        }
    }

    private fun extractTerms(text: String): List<IndexedTerm> {
        val terms = mutableListOf<IndexedTerm>()
        val termFreq = HashMap<String, Int>()

        val words = text.lowercase()
            .split(Regex("[^a-z0-9]"))
            .filter { it.length in MIN_TERM_LENGTH..MAX_TERM_LENGTH }
            .filter { it !in STOP_WORDS }

        words.forEachIndexed { pos, word ->
            termFreq[word] = (termFreq[word] ?: 0) + 1
            terms.add(IndexedTerm(word, pos, termFreq[word]!!))

            // Also index word stems/prefixes for fuzzy matching
            if (word.length > 4) {
                val prefix = word.substring(0, word.length - 1)
                termFreq[prefix] = (termFreq[prefix] ?: 0) + 1
                terms.add(IndexedTerm(prefix, pos, termFreq[prefix]!!))
            }
        }
        return terms
    }

    private fun extractQueryTerms(query: String): List<String> =
        query.lowercase()
            .split(Regex("[^a-z0-9]"))
            .filter { it.length >= MIN_TERM_LENGTH }
            .filter { it !in STOP_WORDS }

    fun getDocumentCount(): Int = documents.size
    fun getTermCount(): Long = totalTerms

    data class IndexedTerm(val text: String, val position: Int, val frequency: Int)

    data class DocumentInfo(
        val docId: String,
        val termCount: Int,
        val docType: DocumentType,
        val indexedAt: Long,
    )

    enum class DocumentType { METADATA, CONTENT }

    data class TermSearchResult(
        val filePath: String,
        val score: Float,
        val positions: List<Int>,
        val matchType: MatchType,
    )

    /** Postings list for a term. */
    private class PostingsList {
        private val postings = ArrayList<Posting>(4)
        val size: Int get() = postings.size

        fun addPosting(docId: String, position: Int, frequency: Int) {
            val existing = postings.find { it.docId == docId }
            if (existing != null) {
                existing.positions.add(position)
            } else {
                postings.add(Posting(docId, mutableListOf(position), frequency))
            }
        }

        fun getPosting(docId: String): Posting? = postings.find { it.docId == docId }
        fun getPostings(): List<Posting> = postings
    }

    data class Posting(
        val docId: String,
        val positions: MutableList<Int>,
        var frequency: Int,
    )
}

package com.titan.filemanager.core.navigation

import com.google.common.truth.Truth.assertThat
import org.junit.Test

/**
 * ## NavRoutesTest
 *
 * Unit tests for [NavRoutes] object. Verifies:
 *  - Route constants are non-empty strings
 *  - Route templates contain the correct argument placeholders
 *  - Helper functions build correctly-encoded route strings
 *  - `parseImportPaths` is the inverse of `importFilesRoute`
 *  - `shouldShowBottomBar` correctly identifies routes that hide the bar
 *  - `isTopLevel` / `isBootFlow` classification
 */
class NavRoutesTest {

    // ═══════════════════════════════════════════════════════════════
    // ROUTE CONSTANTS
    // ═══════════════════════════════════════════════════════════════

    @Test
    fun `all route constants are non-empty`() {
        val routes = listOf(
            NavRoutes.SPLASH, NavRoutes.ONBOARDING, NavRoutes.APP_LOCK,
            NavRoutes.HOME, NavRoutes.BROWSER, NavRoutes.SEARCH, NavRoutes.CLOUD, NavRoutes.SETTINGS,
            NavRoutes.VIEWER, NavRoutes.TRANSFER, NavRoutes.ARCHIVE, NavRoutes.VAULT,
            NavRoutes.DUPLICATES, NavRoutes.ANALYTICS, NavRoutes.TRASH,
            NavRoutes.STORAGE_OVERVIEW, NavRoutes.BOOKMARKS, NavRoutes.RECENT_FILES,
            NavRoutes.HIDDEN_FILES, NavRoutes.CLOUD_AUTH, NavRoutes.CLOUD_BROWSER,
            NavRoutes.SEARCH_FILTER, NavRoutes.DUPLICATE_DETAIL, NavRoutes.ANALYTICS_DETAIL,
            NavRoutes.SETTINGS_ABOUT, NavRoutes.SETTINGS_STORAGE, NavRoutes.SETTINGS_APPEARANCE,
            NavRoutes.TAG_MANAGER, NavRoutes.SEARCH_RESULTS, NavRoutes.WEAR_VIEWER,
            NavRoutes.AUTOMOTIVE_BROWSER, NavRoutes.CRASH_REVIEW, NavRoutes.IMPORT_FILES,
        )
        routes.forEach { route ->
            assertThat(route).isNotEmpty()
        }
    }

    @Test
    fun `top level routes contain exactly 5 entries`() {
        assertThat(NavRoutes.topLevelRoutes).hasSize(5)
        assertThat(NavRoutes.topLevelRoutes).containsExactly(
            NavRoutes.HOME, NavRoutes.BROWSER, NavRoutes.SEARCH, NavRoutes.CLOUD, NavRoutes.SETTINGS,
        )
    }

    @Test
    fun `boot flow routes contain 3 entries`() {
        assertThat(NavRoutes.bootFlowRoutes).hasSize(3)
        assertThat(NavRoutes.bootFlowRoutes).containsExactly(
            NavRoutes.SPLASH, NavRoutes.ONBOARDING, NavRoutes.APP_LOCK,
        )
    }

    // ═══════════════════════════════════════════════════════════════
    // ROUTE TEMPLATES
    // ═══════════════════════════════════════════════════════════════

    @Test
    fun `VIEWER_ROUTE contains ARG_PATH placeholder`() {
        assertThat(NavRoutes.VIEWER_ROUTE).isEqualTo("viewer/{path}")
    }

    @Test
    fun `ARCHIVE_ROUTE contains ARG_PATH placeholder`() {
        assertThat(NavRoutes.ARCHIVE_ROUTE).isEqualTo("archive/{path}")
    }

    @Test
    fun `CLOUD_BROWSER_ROUTE contains both providerId and path placeholders`() {
        assertThat(NavRoutes.CLOUD_BROWSER_ROUTE).isEqualTo("cloud_browser/{providerId}/{path}")
    }

    @Test
    fun `DUPLICATE_DETAIL_ROUTE contains groupId placeholder`() {
        assertThat(NavRoutes.DUPLICATE_DETAIL_ROUTE).isEqualTo("duplicate_detail/{groupId}")
    }

    @Test
    fun `SEARCH_RESULTS_ROUTE contains query placeholder`() {
        assertThat(NavRoutes.SEARCH_RESULTS_ROUTE).isEqualTo("search_results/{query}")
    }

    @Test
    fun `MODAL_FILE_PROPERTIES_ROUTE contains path placeholder`() {
        assertThat(NavRoutes.MODAL_FILE_PROPERTIES_ROUTE).isEqualTo("modal_file_properties/{path}")
    }

    @Test
    fun `MODAL_COMPRESSION_ROUTE contains count and totalSize placeholders`() {
        assertThat(NavRoutes.MODAL_COMPRESSION_ROUTE).isEqualTo("modal_compression/{count}/{totalSize}")
    }

    @Test
    fun `MODAL_EXTRACT_ROUTE contains path, count, and encrypted placeholders`() {
        assertThat(NavRoutes.MODAL_EXTRACT_ROUTE).isEqualTo("modal_extract/{path}/{count}/{encrypted}")
    }

    @Test
    fun `IMPORT_FILES_ROUTE contains paths and label placeholders`() {
        assertThat(NavRoutes.IMPORT_FILES_ROUTE).isEqualTo("import_files/{paths}/{label}")
    }

    // ═══════════════════════════════════════════════════════════════
    // HELPER FUNCTIONS — ROUTE BUILDERS
    // ═══════════════════════════════════════════════════════════════

    @Test
    fun `viewerRoute builds path with encoded argument`() {
        val route = NavRoutes.viewerRoute("/sdcard/photo.jpg")
        assertThat(route).startsWith("viewer/")
        // The path should be URL-encoded
        assertThat(route).contains("photo.jpg")
    }

    @Test
    fun `archiveRoute builds path with encoded argument`() {
        val route = NavRoutes.archiveRoute("/sdcard/archive.zip")
        assertThat(route).startsWith("archive/")
        assertThat(route).contains("archive.zip")
    }

    @Test
    fun `cloudAuthRoute builds with providerId`() {
        val route = NavRoutes.cloudAuthRoute("google_drive")
        assertThat(route).isEqualTo("cloud_auth/google_drive")
    }

    @Test
    fun `cloudBrowserRoute builds with providerId and encoded path`() {
        val route = NavRoutes.cloudBrowserRoute("dropbox", "/Photos/2024")
        assertThat(route).startsWith("cloud_browser/dropbox/")
    }

    @Test
    fun `duplicateDetailRoute builds with groupId`() {
        val route = NavRoutes.duplicateDetailRoute("group_123")
        assertThat(route).isEqualTo("duplicate_detail/group_123")
    }

    @Test
    fun `searchResultsRoute builds with encoded query`() {
        val route = NavRoutes.searchResultsRoute("hello world")
        assertThat(route).startsWith("search_results/")
        // Space should be encoded as +
        assertThat(route).contains("hello")
    }

    @Test
    fun `modalFilePropertiesRoute builds with encoded path`() {
        val route = NavRoutes.modalFilePropertiesRoute("/sdcard/doc.pdf")
        assertThat(route).startsWith("modal_file_properties/")
    }

    @Test
    fun `modalCompressionRoute builds with count and size`() {
        val route = NavRoutes.modalCompressionRoute(5, "2.4 MB")
        assertThat(route).startsWith("modal_compression/5/")
    }

    @Test
    fun `modalExtractRoute builds with path, count, and encrypted flag`() {
        val route = NavRoutes.modalExtractRoute("/sdcard/archive.zip", 10, true)
        assertThat(route).startsWith("modal_extract/")
        assertThat(route).endsWith("/10/true")
    }

    // ═══════════════════════════════════════════════════════════════
    // IMPORT FILES ROUTE — round-trip test
    // ═══════════════════════════════════════════════════════════════

    @Test
    fun `importFilesRoute and parseImportPaths are inverses`() {
        val originalPaths = listOf("/sdcard/photo.jpg", "/sdcard/doc.pdf", "/sdcard/video.mp4")
        val label = "Imported from Chrome"

        val route = NavRoutes.importFilesRoute(originalPaths, label)
        assertThat(route).startsWith("import_files/")

        // Extract the encoded paths argument (between the two '/')
        val parts = route.removePrefix("import_files/").split("/")
        val encodedPaths = parts[0]
        val parsedPaths = NavRoutes.parseImportPaths(encodedPaths)

        assertThat(parsedPaths).isEqualTo(originalPaths)
    }

    @Test
    fun `parseImportPaths handles empty input`() {
        assertThat(NavRoutes.parseImportPaths(null)).isEmpty()
        assertThat(NavRoutes.parseImportPaths("")).isEmpty()
    }

    @Test
    fun `parseImportPaths handles single path`() {
        val route = NavRoutes.importFilesRoute(listOf("/sdcard/single.jpg"), "test")
        val encoded = route.removePrefix("import_files/").split("/")[0]
        val parsed = NavRoutes.parseImportPaths(encoded)

        assertThat(parsed).hasSize(1)
        assertThat(parsed[0]).isEqualTo("/sdcard/single.jpg")
    }

    @Test
    fun `importFilesRoute encodes special characters in label`() {
        val route = NavRoutes.importFilesRoute(listOf("/file.txt"), "From: Chrome (v120)")
        assertThat(route).startsWith("import_files/")
        // Label should be encoded (colon and parens encoded)
        assertThat(route).doesNotContain("From: Chrome (v120)")
    }

    // ═══════════════════════════════════════════════════════════════
    // CLASSIFICATION HELPERS
    // ═══════════════════════════════════════════════════════════════

    @Test
    fun `isTopLevel returns true for top-level routes`() {
        assertThat(NavRoutes.isTopLevel(NavRoutes.HOME)).isTrue()
        assertThat(NavRoutes.isTopLevel(NavRoutes.BROWSER)).isTrue()
        assertThat(NavRoutes.isTopLevel(NavRoutes.SEARCH)).isTrue()
        assertThat(NavRoutes.isTopLevel(NavRoutes.CLOUD)).isTrue()
        assertThat(NavRoutes.isTopLevel(NavRoutes.SETTINGS)).isTrue()
    }

    @Test
    fun `isTopLevel returns false for detail routes`() {
        assertThat(NavRoutes.isTopLevel(NavRoutes.VIEWER)).isFalse()
        assertThat(NavRoutes.isTopLevel(NavRoutes.VAULT)).isFalse()
        assertThat(NavRoutes.isTopLevel(NavRoutes.SETTINGS_ABOUT)).isFalse()
    }

    @Test
    fun `isTopLevel returns false for null route`() {
        assertThat(NavRoutes.isTopLevel(null)).isFalse()
    }

    @Test
    fun `isBootFlow returns true for boot flow routes`() {
        assertThat(NavRoutes.isBootFlow(NavRoutes.SPLASH)).isTrue()
        assertThat(NavRoutes.isBootFlow(NavRoutes.ONBOARDING)).isTrue()
        assertThat(NavRoutes.isBootFlow(NavRoutes.APP_LOCK)).isTrue()
    }

    @Test
    fun `isBootFlow returns false for non-boot routes`() {
        assertThat(NavRoutes.isBootFlow(NavRoutes.HOME)).isFalse()
        assertThat(NavRoutes.isBootFlow(NavRoutes.SETTINGS)).isFalse()
    }

    @Test
    fun `shouldShowBottomBar returns true for top-level routes`() {
        assertThat(NavRoutes.shouldShowBottomBar(NavRoutes.HOME)).isTrue()
        assertThat(NavRoutes.shouldShowBottomBar(NavRoutes.BROWSER)).isTrue()
        assertThat(NavRoutes.shouldShowBottomBar(NavRoutes.SEARCH)).isTrue()
    }

    @Test
    fun `shouldShowBottomBar returns false for boot flow routes`() {
        assertThat(NavRoutes.shouldShowBottomBar(NavRoutes.SPLASH)).isFalse()
        assertThat(NavRoutes.shouldShowBottomBar(NavRoutes.ONBOARDING)).isFalse()
        assertThat(NavRoutes.shouldShowBottomBar(NavRoutes.APP_LOCK)).isFalse()
    }

    @Test
    fun `shouldShowBottomBar returns false for detail routes`() {
        assertThat(NavRoutes.shouldShowBottomBar(NavRoutes.VIEWER)).isFalse()
        assertThat(NavRoutes.shouldShowBottomBar(NavRoutes.VAULT)).isFalse()
        assertThat(NavRoutes.shouldShowBottomBar(NavRoutes.TRANSFER)).isFalse()
        assertThat(NavRoutes.shouldShowBottomBar(NavRoutes.SETTINGS_ABOUT)).isFalse()
        assertThat(NavRoutes.shouldShowBottomBar(NavRoutes.CRASH_REVIEW)).isFalse()
    }

    @Test
    fun `shouldShowBottomBar returns false for modal routes`() {
        assertThat(NavRoutes.shouldShowBottomBar(NavRoutes.MODAL_FILE_PROPERTIES)).isFalse()
        assertThat(NavRoutes.shouldShowBottomBar(NavRoutes.MODAL_FILE_PREVIEW)).isFalse()
        assertThat(NavRoutes.shouldShowBottomBar(NavRoutes.MODAL_COMPRESSION)).isFalse()
        assertThat(NavRoutes.shouldShowBottomBar(NavRoutes.MODAL_EXTRACT)).isFalse()
    }

    @Test
    fun `shouldShowBottomBar returns false for null route`() {
        assertThat(NavRoutes.shouldShowBottomBar(null)).isFalse()
    }

    // ═══════════════════════════════════════════════════════════════
    // ARGUMENT KEYS
    // ═══════════════════════════════════════════════════════════════

    @Test
    fun `argument keys are non-empty`() {
        assertThat(NavRoutes.ARG_PATH).isEqualTo("path")
        assertThat(NavRoutes.ARG_PROVIDER_ID).isEqualTo("providerId")
        assertThat(NavRoutes.ARG_GROUP_ID).isEqualTo("groupId")
        assertThat(NavRoutes.ARG_QUERY).isEqualTo("query")
        assertThat(NavRoutes.ARG_COUNT).isEqualTo("count")
        assertThat(NavRoutes.ARG_TOTAL_SIZE).isEqualTo("totalSize")
        assertThat(NavRoutes.ARG_ENCRYPTED).isEqualTo("encrypted")
        assertThat(NavRoutes.ARG_PATHS).isEqualTo("paths")
        assertThat(NavRoutes.ARG_LABEL).isEqualTo("label")
    }
}

package com.titan.filemanager.core.navigation

/**
 * ## NavRoute — Type-safe navigation route DSL.
 *
 * Replaces stringly-typed route construction with a sealed hierarchy
 * that the compiler can check. Each route is a data class (or object)
 * that knows:
 *  - its [route] template (e.g. `"viewer/{path}"`)
 *  - how to build the full URL-encoded route string
 *  - which arguments it expects (for type-safe extraction)
 *
 * ### Usage
 * ```
 * // Build a route
 * val route = NavRoute.Viewer("/sdcard/photo.jpg")
 * navController.navigate(route.toFullPath())
 *
 * // Pattern-match on a route
 * when (route) {
 *     is NavRoute.Viewer -> showFile(route.path)
 *     is NavRoute.Archive -> openArchive(route.path)
 *     is NavRoute.CloudBrowser -> openCloudBrowser(route.providerId, route.path)
 *     else -> { /* unknown */ }
 * }
 * ```
 *
 * ### Why
 *  1. No more typos in route strings — the compiler catches them.
 *  2. No more forgetting to URL-encode arguments.
 *  3. No more magic strings scattered across feature modules.
 *  4. Pattern matching gives exhaustive `when` blocks.
 *  5. Easier to refactor — rename a route in one place.
 */
sealed interface NavRoute {

    /** The raw route template (e.g. `"viewer/{path}"`) without arguments. */
    val template: String

    /** Build the full URL-encoded route string with arguments filled in. */
    fun toFullPath(): String

    // ── Boot flow ─────────────────────────────────────────────────

    data object Splash : NavRoute {
        override val template: String = NavRoutes.SPLASH
        override fun toFullPath(): String = NavRoutes.SPLASH
    }

    data object Onboarding : NavRoute {
        override val template: String = NavRoutes.ONBOARDING
        override fun toFullPath(): String = NavRoutes.ONBOARDING
    }

    data object AppLock : NavRoute {
        override val template: String = NavRoutes.APP_LOCK
        override fun toFullPath(): String = NavRoutes.APP_LOCK
    }

    // ── Top-level destinations ────────────────────────────────────

    data object Home : NavRoute {
        override val template: String = NavRoutes.HOME
        override fun toFullPath(): String = NavRoutes.HOME
    }

    data class Browser(val path: String? = null) : NavRoute {
        override val template: String = NavRoutes.BROWSER
        override fun toFullPath(): String = NavRoutes.browserRoute(path)
    }

    data object Search : NavRoute {
        override val template: String = NavRoutes.SEARCH
        override fun toFullPath(): String = NavRoutes.SEARCH
    }

    data object Cloud : NavRoute {
        override val template: String = NavRoutes.CLOUD
        override fun toFullPath(): String = NavRoutes.CLOUD
    }

    data object Settings : NavRoute {
        override val template: String = NavRoutes.SETTINGS
        override fun toFullPath(): String = NavRoutes.SETTINGS
    }

    // ── Detail screens ────────────────────────────────────────────

    data class Viewer(val path: String) : NavRoute {
        override val template: String = NavRoutes.VIEWER_ROUTE
        override fun toFullPath(): String = NavRoutes.viewerRoute(path)
    }

    data object Transfer : NavRoute {
        override val template: String = NavRoutes.TRANSFER
        override fun toFullPath(): String = NavRoutes.TRANSFER
    }

    data class Archive(val path: String) : NavRoute {
        override val template: String = NavRoutes.ARCHIVE_ROUTE
        override fun toFullPath(): String = NavRoutes.archiveRoute(path)
    }

    data object Vault : NavRoute {
        override val template: String = NavRoutes.VAULT
        override fun toFullPath(): String = NavRoutes.VAULT
    }

    data object Duplicates : NavRoute {
        override val template: String = NavRoutes.DUPLICATES
        override fun toFullPath(): String = NavRoutes.DUPLICATES
    }

    data object Analytics : NavRoute {
        override val template: String = NavRoutes.ANALYTICS
        override fun toFullPath(): String = NavRoutes.ANALYTICS
    }

    data object Trash : NavRoute {
        override val template: String = NavRoutes.TRASH
        override fun toFullPath(): String = NavRoutes.TRASH
    }

    data object StorageOverview : NavRoute {
        override val template: String = NavRoutes.STORAGE_OVERVIEW
        override fun toFullPath(): String = NavRoutes.STORAGE_OVERVIEW
    }

    data object Bookmarks : NavRoute {
        override val template: String = NavRoutes.BOOKMARKS
        override fun toFullPath(): String = NavRoutes.BOOKMARKS
    }

    data object RecentFiles : NavRoute {
        override val template: String = NavRoutes.RECENT_FILES
        override fun toFullPath(): String = NavRoutes.RECENT_FILES
    }

    data object HiddenFiles : NavRoute {
        override val template: String = NavRoutes.HIDDEN_FILES
        override fun toFullPath(): String = NavRoutes.HIDDEN_FILES
    }

    data class CloudAuth(val providerId: String) : NavRoute {
        override val template: String = NavRoutes.CLOUD_AUTH_ROUTE
        override fun toFullPath(): String = NavRoutes.cloudAuthRoute(providerId)
    }

    data class CloudBrowser(val providerId: String, val path: String) : NavRoute {
        override val template: String = NavRoutes.CLOUD_BROWSER_ROUTE
        override fun toFullPath(): String = NavRoutes.cloudBrowserRoute(providerId, path)
    }

    data class DuplicateDetail(val groupId: String) : NavRoute {
        override val template: String = NavRoutes.DUPLICATE_DETAIL_ROUTE
        override fun toFullPath(): String = NavRoutes.duplicateDetailRoute(groupId)
    }

    data object AnalyticsDetail : NavRoute {
        override val template: String = NavRoutes.ANALYTICS_DETAIL
        override fun toFullPath(): String = NavRoutes.ANALYTICS_DETAIL
    }

    data class SearchResults(val query: String) : NavRoute {
        override val template: String = NavRoutes.SEARCH_RESULTS_ROUTE
        override fun toFullPath(): String = NavRoutes.searchResultsRoute(query)
    }

    data object TagManager : NavRoute {
        override val template: String = NavRoutes.TAG_MANAGER
        override fun toFullPath(): String = NavRoutes.TAG_MANAGER
    }

    data object CrashReview : NavRoute {
        override val template: String = NavRoutes.CRASH_REVIEW
        override fun toFullPath(): String = NavRoutes.CRASH_REVIEW
    }

    data class ImportFiles(val filePaths: List<String>, val sourceLabel: String) : NavRoute {
        override val template: String = NavRoutes.IMPORT_FILES_ROUTE
        override fun toFullPath(): String = NavRoutes.importFilesRoute(filePaths, sourceLabel)
    }

    // ── Settings sub-screens ──────────────────────────────────────

    data object SettingsAbout : NavRoute {
        override val template: String = NavRoutes.SETTINGS_ABOUT
        override fun toFullPath(): String = NavRoutes.SETTINGS_ABOUT
    }

    data object SettingsStorage : NavRoute {
        override val template: String = NavRoutes.SETTINGS_STORAGE
        override fun toFullPath(): String = NavRoutes.SETTINGS_STORAGE
    }

    data object SettingsAppearance : NavRoute {
        override val template: String = NavRoutes.SETTINGS_APPEARANCE
        override fun toFullPath(): String = NavRoutes.SETTINGS_APPEARANCE
    }

    // ── Modals ────────────────────────────────────────────────────

    data class ModalFileProperties(val path: String) : NavRoute {
        override val template: String = NavRoutes.MODAL_FILE_PROPERTIES_ROUTE
        override fun toFullPath(): String = NavRoutes.modalFilePropertiesRoute(path)
    }

    data class ModalFilePreview(val path: String) : NavRoute {
        override val template: String = NavRoutes.MODAL_FILE_PREVIEW_ROUTE
        override fun toFullPath(): String = NavRoutes.modalFilePreviewRoute(path)
    }

    data class ModalCompression(val fileCount: Int, val totalSize: String) : NavRoute {
        override val template: String = NavRoutes.MODAL_COMPRESSION_ROUTE
        override fun toFullPath(): String = NavRoutes.modalCompressionRoute(fileCount, totalSize)
    }

    data class ModalExtract(val archivePath: String, val entryCount: Int, val isEncrypted: Boolean) : NavRoute {
        override val template: String = NavRoutes.MODAL_EXTRACT_ROUTE
        override fun toFullPath(): String = NavRoutes.modalExtractRoute(archivePath, entryCount, isEncrypted)
    }

    // ── AI (new in v2) ────────────────────────────────────────────

    data object AiInsights : NavRoute {
        override val template: String = "ai"
        override fun toFullPath(): String = "ai"
    }

    // ── Helpers ───────────────────────────────────────────────────

    companion object {
        /**
         * Parse a route string back into a [NavRoute] instance.
         *
         * Returns `null` if the route doesn't match any known type.
         * Used by deep link handlers and analytics.
         */
        fun fromRouteString(route: String?): NavRoute? {
            if (route == null) return null
            val base = route.substringBefore('/')
            return when (base) {
                NavRoutes.SPLASH -> Splash
                NavRoutes.ONBOARDING -> Onboarding
                NavRoutes.APP_LOCK -> AppLock
                NavRoutes.HOME -> Home
                NavRoutes.BROWSER -> Browser(path = null)
                NavRoutes.SEARCH -> Search
                NavRoutes.CLOUD -> Cloud
                NavRoutes.SETTINGS -> Settings
                NavRoutes.TRANSFER -> Transfer
                NavRoutes.VAULT -> Vault
                NavRoutes.DUPLICATES -> Duplicates
                NavRoutes.ANALYTICS -> Analytics
                NavRoutes.TRASH -> Trash
                NavRoutes.STORAGE_OVERVIEW -> StorageOverview
                NavRoutes.BOOKMARKS -> Bookmarks
                NavRoutes.RECENT_FILES -> RecentFiles
                NavRoutes.HIDDEN_FILES -> HiddenFiles
                NavRoutes.ANALYTICS_DETAIL -> AnalyticsDetail
                NavRoutes.TAG_MANAGER -> TagManager
                NavRoutes.CRASH_REVIEW -> CrashReview
                NavRoutes.SETTINGS_ABOUT -> SettingsAbout
                NavRoutes.SETTINGS_STORAGE -> SettingsStorage
                NavRoutes.SETTINGS_APPEARANCE -> SettingsAppearance
                "ai" -> AiInsights
                else -> null
            }
        }
    }
}

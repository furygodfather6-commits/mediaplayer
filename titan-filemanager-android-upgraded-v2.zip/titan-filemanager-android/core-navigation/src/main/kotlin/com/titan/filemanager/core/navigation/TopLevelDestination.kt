package com.titan.filemanager.core.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Cloud
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * Top-level navigation destinations — the tabs in the bottom navigation bar.
 *
 * Each destination is associated with:
 *  - a unique [route] string (used by Compose Navigation — see [NavRoutes])
 *  - an [icon] (Material outlined icon)
 *  - a [label] — English fallback (Phase 1 will replace with string resource IDs)
 *  - a [selectedIcon] — filled icon variant for the selected state
 *  - a [badgeCount] — optional badge (e.g., active transfer count)
 *
 * The enum preserves order when iterating (`entries.toList()`).
 *
 * 5 destinations (Home, Files, Search, Cloud, Settings) — Settings is
 * back in the bottom nav by user request. The Home tab's top-bar
 * gear icon remains as a secondary entry point.
 */
enum class TopLevelDestination(
    val route: String,
    val icon: ImageVector,
    val selectedIcon: ImageVector = icon,
    val label: String,
    val badgeCount: Int? = null,
) {
    HOME(
        route = NavRoutes.HOME,
        icon = Icons.Outlined.Home,
        selectedIcon = Icons.Filled.Home,
        label = "Home",
    ),
    BROWSER(
        route = NavRoutes.BROWSER,
        icon = Icons.Outlined.Folder,
        selectedIcon = Icons.Filled.Folder,
        label = "Files",
    ),
    SEARCH(
        route = NavRoutes.SEARCH,
        icon = Icons.Outlined.Search,
        selectedIcon = Icons.Filled.Search,
        label = "Search",
    ),
    CLOUD(
        route = NavRoutes.CLOUD,
        icon = Icons.Outlined.Cloud,
        selectedIcon = Icons.Filled.Cloud,
        label = "Cloud",
    ),
    SETTINGS(
        route = NavRoutes.SETTINGS,
        icon = Icons.Outlined.Settings,
        selectedIcon = Icons.Filled.Settings,
        label = "Settings",
    );

    companion object {
        /** Find a [TopLevelDestination] by route string. Returns `null` for detail screens. */
        fun fromRoute(route: String?): TopLevelDestination? =
            entries.firstOrNull { it.route == route || route?.startsWith(it.route + "/") == true }

        /** All top-level routes as a set for quick lookup. */
        val allRoutes = entries.map { it.route }.toSet()
    }
}

package com.titan.filemanager.core.navigation

/**
 * ## BackStackStrategy — How navigation affects the back stack.
 *
 * Wraps the common `navOptions` patterns in a type-safe enum so the
 * caller doesn't have to remember the Material 3 idiom
 * (`popUpTo(start) { saveState = true }; launchSingleTop = true; restoreState = true`).
 *
 * ### Usage
 * ```
 * navController.navigate(
 *     route = NavRoutes.BROWSER,
 *     navOptions = BackStackStrategy.TOP_LEVEL.toNavOptions(navController),
 * )
 * ```
 */
enum class BackStackStrategy {

    /**
     * Standard push — adds the new screen to the back stack.
     * Back returns to the previous screen.
     *
     * Used by detail screens (Viewer, Archive, Vault, etc.).
     */
    PUSH,

    /**
     * Replace — pops the current screen and pushes the new one.
     * Back from the new screen returns to the screen before the current.
     *
     * Used for boot flow transitions (Splash → Onboarding → Home).
     */
    REPLACE,

    /**
     * Top-level tab switch — Material 3 idiom:
     *   - Pop up to start destination, saving state
     *   - `launchSingleTop = true`
     *   - Restore state
     *
     * Preserves each tab's scroll position and back stack.
     */
    TOP_LEVEL,

    /**
     * Clear all — pops the entire back stack and pushes the new screen.
     * The new screen becomes the only entry in the back stack.
     *
     * Used for "log out" or "reset to home" flows.
     */
    CLEAR_ALL,

    /**
     * Pop current — pops the current screen without pushing a new one.
     * Equivalent to `navController.popBackStack()`.
     */
    POP_CURRENT,
}

/**
 * ## NavigationEvent — Type-safe navigation intent.
 *
 * Represents a user's intent to navigate, captured as a data class so
 * it can be queued, logged, or analyzed. The [TitanAppState] exposes
 * a `navigate(event: NavigationEvent)` method that interprets the event
 * and calls the appropriate `NavController` method.
 *
 * ### Why
 *  1. Decouples UI from NavController — features emit events, the app
 *     shell interprets them. Easier to test.
 *  2. Logging / analytics — record every navigation for analytics.
 *  3. Deep link handling — deep links become NavigationEvents.
 *  4. Undo — keep a stack of NavigationEvents for "back to where I was".
 */
sealed interface NavigationEvent {

    /** Navigate to a route, with a back stack strategy. */
    data class Navigate(
        val route: NavRoute,
        val strategy: BackStackStrategy = BackStackStrategy.PUSH,
    ) : NavigationEvent

    /** Navigate back — pops the back stack. */
    data object Back : NavigationEvent

    /** Navigate back to a specific route. */
    data class BackTo(val route: NavRoute) : NavigationEvent

    /** Navigate all the way home (pop to start destination). */
    data object Home : NavigationEvent

    /** Switch to a top-level tab. */
    data class SwitchTab(val destination: TopLevelDestination) : NavigationEvent
}

/**
 * ## NavigationResult — Return values between screens.
 *
 * Type-safe way for a pushed screen to return a result to the screen
 * that launched it. Replaces the stringly-typed `savedStateHandle`
 * pattern with a sealed hierarchy.
 *
 * ### Usage
 * ```
 * // Screen A: launch screen B and wait for result
 * val result = navController.navigateForResult(NavRoute.SearchFilter())
 * when (result) {
 *     is NavigationResult.SearchFilter -> applyFilters(result.filters)
 *     is NavigationResult.Cancelled -> { /* user backed out */ }
 * }
 *
 * // Screen B: set result before popping
 * navController.setResult(NavigationResult.SearchFilter(filters))
 * navController.popBackStack()
 * ```
 */
sealed interface NavigationResult {
    data object Cancelled : NavigationResult
    data class SearchFilter(val filters: SearchFilters) : NavigationResult
    data class CompressionOptions(val format: String, val level: Int, val password: String?) : NavigationResult
    data class ExtractOptions(val destinationDir: String, val password: String?) : NavigationResult
    data class FileSelection(val paths: List<String>) : NavigationResult
    data class FolderSelection(val path: String) : NavigationResult
}

/** Search filter payload — returned by the SearchFilter modal. */
data class SearchFilters(
    val minSize: Long = 0L,
    val maxSize: Long = Long.MAX_VALUE,
    val extensions: Set<String> = emptySet(),
    val modifiedAfter: Long = 0L,
    val modifiedBefore: Long = Long.MAX_VALUE,
    val includeHidden: Boolean = true,
)

package com.titan.filemanager.core.navigation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically

/**
 * ## NavigationTransitions — Catalog of screen transition styles.
 *
 * Replaces the hardcoded transitions in the app-level NavHost with a
 * catalog of reusable, named transition styles. Each style is a
 * complete enter/exit/popEnter/popExit quadruple that can be passed
 * to a `composable()` call.
 *
 * ### Usage
 * ```
 * composable(
 *     route = NavRoutes.VIEWER_ROUTE,
 *     enterTransition = { NavigationTransitions.SLIDE.enter },
 *     exitTransition = { NavigationTransitions.SLIDE.exit },
 *     popEnterTransition = { NavigationTransitions.SLIDE.popEnter },
 *     popExitTransition = { NavigationTransitions.SLIDE.popExit },
 * ) { ... }
 * ```
 *
 * ### Why
 *  1. Consistent transitions across the app — no per-screen tweaks.
 *  2. Easy to A/B test transitions — swap one constant.
 *  3. Documented motion design system — each style has a purpose.
 *  4. Reduced boilerplate in the NavHost.
 */
object NavigationTransitions {

    /** Standard duration for slide / scale transitions. */
    private const val DURATION_STANDARD = 300

    /** Shorter duration for fade transitions. */
    private const val DURATION_FADE = 200

    /** Duration for modal sheet transitions (slower, more deliberate). */
    private const val DURATION_MODAL = 350

    // ─────────────────────────────────────────────────────────────────
    // SLIDE — forward navigation (push)
    // New screen slides in from the right, old screen slides slightly left.
    // ─────────────────────────────────────────────────────────────────

    val SLIDE = TransitionSet(
        enter = {
            slideInHorizontally(tween(DURATION_STANDARD, easing = FastOutSlowInEasing), initialOffsetX = { it }) +
                fadeIn(tween(DURATION_STANDARD))
        },
        exit = {
            slideOutHorizontally(tween(DURATION_FADE, easing = LinearOutSlowInEasing), targetOffsetX = { -it / 3 }) +
                fadeOut(tween(DURATION_FADE))
        },
        popEnter = {
            slideInHorizontally(tween(DURATION_STANDARD, easing = FastOutSlowInEasing), initialOffsetX = { -it / 3 }) +
                fadeIn(tween(DURATION_STANDARD))
        },
        popExit = {
            slideOutHorizontally(tween(DURATION_STANDARD, easing = FastOutSlowInEasing), targetOffsetX = { it }) +
                fadeOut(tween(DURATION_FADE))
        },
    )

    // ─────────────────────────────────────────────────────────────────
    // FADE — tab switch (no slide, just cross-fade)
    // Used when switching between top-level destinations.
    // ─────────────────────────────────────────────────────────────────

    val FADE = TransitionSet(
        enter = { fadeIn(tween(DURATION_STANDARD)) },
        exit = { fadeOut(tween(DURATION_FADE)) },
        popEnter = { fadeIn(tween(DURATION_STANDARD)) },
        popExit = { fadeOut(tween(DURATION_FADE)) },
    )

    // ─────────────────────────────────────────────────────────────────
    // SCALE — modal / dialog appearance
    // New screen scales up from 0.85 to 1.0 with a fade.
    // ─────────────────────────────────────────────────────────────────

    val SCALE = TransitionSet(
        enter = {
            scaleIn(tween(DURATION_MODAL, easing = FastOutSlowInEasing), initialScale = 0.85f) +
                fadeIn(tween(DURATION_MODAL))
        },
        exit = {
            fadeOut(tween(DURATION_FADE))
        },
        popEnter = {
            fadeIn(tween(DURATION_MODAL))
        },
        popExit = {
            scaleOut(tween(DURATION_MODAL, easing = FastOutSlowInEasing), targetScale = 0.85f) +
                fadeOut(tween(DURATION_MODAL))
        },
    )

    // ─────────────────────────────────────────────────────────────────
    // SLIDE_UP — bottom sheet appearance
    // New screen slides up from the bottom.
    // ─────────────────────────────────────────────────────────────────

    val SLIDE_UP = TransitionSet(
        enter = {
            slideInVertically(tween(DURATION_MODAL, easing = FastOutSlowInEasing), initialOffsetY = { it }) +
                fadeIn(tween(DURATION_MODAL))
        },
        exit = {
            fadeOut(tween(DURATION_FADE))
        },
        popEnter = {
            fadeIn(tween(DURATION_MODAL))
        },
        popExit = {
            slideOutVertically(tween(DURATION_MODAL, easing = FastOutSlowInEasing), targetOffsetY = { it }) +
                fadeOut(tween(DURATION_MODAL))
        },
    )

    // ─────────────────────────────────────────────────────────────────
    // NONE — instant transition (no animation)
    // Used for boot flow screens (splash → onboarding → lock → home).
    // ─────────────────────────────────────────────────────────────────

    val NONE = TransitionSet(
        enter = { EnterTransition.None },
        exit = { ExitTransition.None },
        popEnter = { EnterTransition.None },
        popExit = { ExitTransition.None },
    )

    // ─────────────────────────────────────────────────────────────────
    // ELEVATE — Material-style "elevated" transition
    // Subtle scale + fade for settings sub-screens.
    // ─────────────────────────────────────────────────────────────────

    val ELEVATE = TransitionSet(
        enter = {
            scaleIn(tween(DURATION_STANDARD, easing = FastOutSlowInEasing), initialScale = 0.95f) +
                fadeIn(tween(DURATION_STANDARD))
        },
        exit = {
            scaleOut(tween(DURATION_FADE, easing = LinearOutSlowInEasing), targetScale = 1.05f) +
                fadeOut(tween(DURATION_FADE))
        },
        popEnter = {
            scaleIn(tween(DURATION_STANDARD, easing = FastOutSlowInEasing), initialScale = 1.05f) +
                fadeIn(tween(DURATION_STANDARD))
        },
        popExit = {
            scaleOut(tween(DURATION_STANDARD, easing = FastOutSlowInEasing), targetScale = 0.95f) +
                fadeOut(tween(DURATION_STANDARD))
        },
    )

    /**
     * Pick a transition based on the route being navigated to.
     *
     * - Top-level tabs → [FADE]
     * - Boot flow → [NONE]
     * - Modal routes → [SLIDE_UP]
     * - Detail screens → [SLIDE]
     * - Settings sub-screens → [ELEVATE]
     */
    fun forRoute(route: String?): TransitionSet {
        if (route == null) return SLIDE
        val base = route.substringBefore('/')
        return when {
            NavRoutes.isBootFlow(base) -> NONE
            NavRoutes.isTopLevel(base) -> FADE
            base.startsWith("modal_") -> SLIDE_UP
            base.startsWith("settings_") || base.startsWith("appearance_") ||
                base.startsWith("engine_") || base.startsWith("security_") ||
                base.startsWith("system_") || base.startsWith("backup_") -> ELEVATE
            else -> SLIDE
        }
    }
}

/**
 * A complete set of transitions for one screen.
 *
 * Each property is a lambda that returns an [EnterTransition] or [ExitTransition]
 * because Compose Navigation's `enterTransition` parameter expects a
 * `AnimatedContentTransitionScope<NavBackStackEntry>.() -> EnterTransition?`.
 */
data class TransitionSet(
    val enter: AnimatedContentTransitionScope<*>.() -> EnterTransition,
    val exit: AnimatedContentTransitionScope<*>.() -> ExitTransition,
    val popEnter: AnimatedContentTransitionScope<*>.() -> EnterTransition,
    val popExit: AnimatedContentTransitionScope<*>.() -> ExitTransition,
)

package com.titan.filemanager.core.navigation

/**
 * Centralized navigation route constants for the entire TitanFileManager app.
 *
 * ═══════════════════════════════════════════════════════════════════
 * ROUTE CONVENTIONS
 * ═══════════════════════════════════════════════════════════════════
 *
 * 1. **Top-level destinations** (bottom-nav tabs)
 *    Simple lowercase strings: `"home"`, `"browser"`, `"search"`
 *
 * 2. **Detail screens with path arguments**
 *    `"route/{arg}"` template — the NavHost decodes the arg.
 *    Example: `"viewer/{path}"` → navigate with `Uri.encode(path)`
 *
 * 3. **Detail screens with multiple arguments**
 *    `"route/{arg1}/{arg2}"` — arguments are positional.
 *    Example: `"cloud_browser/{providerId}/{path}"`
 *
 * 4. **Modal / overlay screens**
 *    Prefixed with `modal_` to distinguish from pushed screens.
 *    Example: `"modal_file_properties"`, `"modal_search_filter"`
 *
 * ═══════════════════════════════════════════════════════════════════
 * FLOW GROUPS
 * ═══════════════════════════════════════════════════════════════════
 *
 * The app has three distinct flow groups:
 *
 *   **Boot Flow** — shown once on cold start:
 *     SPLASH → ONBOARDING (first run only) → APP_LOCK (if enabled) → HOME
 *
 *   **Main Flow** — the primary app experience:
 *     HOME, BROWSER, SEARCH, CLOUD, SETTINGS
 *     + detail screens: VIEWER, TRANSFER, ARCHIVE, VAULT, DUPLICATES,
 *       ANALYTICS, TRASH, STORAGE_OVERVIEW, BOOKMARKS, RECENT_FILES,
 *       HIDDEN_FILES
 *
 *   **Modal Flow** — bottom sheets and dialogs:
 *     FILE_PROPERTIES, SEARCH_FILTER, COMPRESSION_OPTIONS, EXTRACT_OPTIONS
 *
 * ═══════════════════════════════════════════════════════════════════
 * DEEP LINKING
 * ═══════════════════════════════════════════════════════════════════
 *
 * The VIEWER route is deep-linkable via `content://` or `file://` URIs.
 * The BROWSER route can be deep-linked to open a specific directory.
 *
 * Register deep links in the app's `AndroidManifest.xml`:
 * ```xml
 * <intent-filter>
 *     <action android:name="android.intent.action.VIEW" />
 *     <data android:mimeType="any-slash-any" />
 * </intent-filter>
 * ```
 */
object NavRoutes {

    // ═══════════════════════════════════════════════════════════
    // BOOT FLOW — shown on cold start
    // ═══════════════════════════════════════════════════════════

    /** Animated splash screen — logo, version, loading indicator. */
    const val SPLASH = "splash"

    /** First-run onboarding — permission flow + feature intro (4 slides). */
    const val ONBOARDING = "onboarding"

    /** App lock screen — biometric or 4-digit PIN entry. */
    const val APP_LOCK = "app_lock"

    // ═══════════════════════════════════════════════════════════
    // TOP-LEVEL DESTINATIONS — bottom navigation tabs
    // ═══════════════════════════════════════════════════════════

    /** Home dashboard — storage overview, bookmarks, recent files. */
    const val HOME = "home"

    /** File browser — directory listing with list/grid toggle. */
    const val BROWSER = "browser"

    /** Search — real-time file search with results. */
    const val SEARCH = "search"

    /** Cloud storage — provider list + sync status. */
    const val CLOUD = "cloud"

    /** Settings — theme, preferences, about. */
    const val SETTINGS = "settings"

    // ═══════════════════════════════════════════════════════════
    // DETAIL SCREENS — pushed from top-level destinations
    // ═══════════════════════════════════════════════════════════

    /** File viewer — displays images, videos, PDFs, text files.
     *  Route template: `"viewer/{path}"` */
    const val VIEWER = "viewer"

    /** Active transfers — batch copy/move with progress bars. */
    const val TRANSFER = "transfer"

    /** Archive browser — create/extract ZIP, 7z, TAR archives.
     *  Route template: `"archive/{path}"` */
    const val ARCHIVE = "archive"

    /** Encrypted vault — AES-256-GCM file encryption. */
    const val VAULT = "vault"

    /** Duplicate file finder — 3-level detection (size → partial → full hash). */
    const val DUPLICATES = "duplicates"

    /** Storage analytics — breakdown by file type, size distribution. */
    const val ANALYTICS = "analytics"

    /** Trash management — soft-deleted files with 30-day expiry. */
    const val TRASH = "trash"

    // ═══════════════════════════════════════════════════════════
    // DETAIL SCREENS — pushed from secondary screens
    // ═══════════════════════════════════════════════════════════

    /** Storage overview — per-device donut chart + category breakdown. */
    const val STORAGE_OVERVIEW = "storage_overview"

    /** Bookmark management — add/remove/reorder bookmarks. */
    const val BOOKMARKS = "bookmarks"

    /** Recent files — full history with time-range tabs. */
    const val RECENT_FILES = "recent_files"

    /** Hidden files — list + batch unhide. */
    const val HIDDEN_FILES = "hidden_files"

    /** Cloud OAuth — WebView-based authentication for cloud providers.
     *  Route template: `"cloud_auth/{providerId}"` */
    const val CLOUD_AUTH = "cloud_auth"

    /** Cloud file browser — navigate cloud storage files.
     *  Route template: `"cloud_browser/{providerId}/{path}"` */
    const val CLOUD_BROWSER = "cloud_browser"

    /** Advanced search filters — size, date, type, regex, content. */
    const val SEARCH_FILTER = "search_filter"

    /** Duplicate detail — side-by-side comparison of duplicate files.
     *  Route template: `"duplicate_detail/{groupId}"` */
    const val DUPLICATE_DETAIL = "duplicate_detail"

    /** Analytics detail — pie chart, histogram, timeline, top 20 files. */
    const val ANALYTICS_DETAIL = "analytics_detail"

    // ═══════════════════════════════════════════════════════════
    // SETTINGS SUB-SCREENS
    // ═══════════════════════════════════════════════════════════

    /** About screen — version, changelog, licenses, privacy policy. */
    const val SETTINGS_ABOUT = "settings_about"

    /** Storage & cache management — clear cache, thumbnails, index. */
    const val SETTINGS_STORAGE = "settings_storage"

    /** Appearance settings — theme picker, accent color, font size. */
    const val SETTINGS_APPEARANCE = "settings_appearance"

    /** Advanced appearance — hub for 7 appearance category screens. */
    const val ADVANCED_APPEARANCE = "advanced_appearance"

    /** Appearance sub-screen: theme & color (18 settings). */
    const val APPEARANCE_THEME = "appearance_theme"

    /** Appearance sub-screen: typography (12 settings). */
    const val APPEARANCE_TYPOGRAPHY = "appearance_typography"

    /** Appearance sub-screen: shape & corners (8 settings). */
    const val APPEARANCE_SHAPE = "appearance_shape"

    /** Appearance sub-screen: spacing & density (10 settings). */
    const val APPEARANCE_DENSITY = "appearance_density"

    /** Appearance sub-screen: elevation & shadows (6 settings). */
    const val APPEARANCE_ELEVATION = "appearance_elevation"

    /** Appearance sub-screen: motion & animation (12 settings). */
    const val APPEARANCE_MOTION = "appearance_motion"

    /** Appearance sub-screen: glassmorphism & blur (7 settings). */
    const val APPEARANCE_GLASS = "appearance_glass"

    /** Engine configuration hub — 7 engine category screens. */
    const val ENGINE_SETTINGS = "engine_settings"

    /** Engine sub-screen: scan engine (8 settings). */
    const val ENGINE_SCAN = "engine_scan"

    /** Engine sub-screen: cache engine (10 settings). */
    const val ENGINE_CACHE = "engine_cache"

    /** Engine sub-screen: search engine (12 settings). */
    const val ENGINE_SEARCH = "engine_search"

    /** Engine sub-screen: thumbnail engine (8 settings). */
    const val ENGINE_THUMBNAIL = "engine_thumbnail"

    /** Engine sub-screen: trash & deletion (6 settings). */
    const val ENGINE_TRASH = "engine_trash"

    /** Engine sub-screen: analytics (6 settings). */
    const val ENGINE_ANALYTICS = "engine_analytics"

    /** Engine sub-screen: AI & smart features (8 settings). */
    const val ENGINE_AI = "engine_ai"

    /** Security & Cloud hub — 3 security category screens. */
    const val SECURITY_SETTINGS = "security_settings"

    /** Security sub-screen: vault & security (14 settings). */
    const val SECURITY_VAULT = "security_vault"

    /** Security sub-screen: cloud sync (10 settings). */
    const val SECURITY_CLOUD = "security_cloud"

    /** Security sub-screen: notifications (10 settings). */
    const val SECURITY_NOTIFICATIONS = "security_notifications"

    /** System & Behavior hub — 6 system category screens. */
    const val SYSTEM_SETTINGS = "system_settings"

    /** System sub-screen: file browser & display (14 settings). */
    const val SYSTEM_FILE_BROWSER = "system_file_browser"

    /** System sub-screen: accessibility (10 settings). */
    const val SYSTEM_ACCESSIBILITY = "system_accessibility"

    /** System sub-screen: performance (8 settings). */
    const val SYSTEM_PERFORMANCE = "system_performance"

    /** System sub-screen: storage & disk (6 settings). */
    const val SYSTEM_STORAGE = "system_storage"

    /** System sub-screen: behavior & defaults (8 settings). */
    const val SYSTEM_BEHAVIOR = "system_behavior"

    /** System sub-screen: advanced & developer (10 settings). */
    const val SYSTEM_ADVANCED = "system_advanced"

    /** Backup & Archive hub — 2 backup category screens. */
    const val BACKUP_SETTINGS = "backup_settings"

    /** Backup sub-screen: backup & restore (8 settings). */
    const val BACKUP_CONFIG = "backup_config"

    /** Backup sub-screen: archive & compression (6 settings). */
    const val ARCHIVE_CONFIG = "archive_config"

    /** Tag manager — create / edit / delete user-defined tags. */
    const val TAG_MANAGER = "tag_manager"

    /** Search results grid — multi-select grid layout for search results.
     *  Route template: `"search_results/{query}"` */
    const val SEARCH_RESULTS = "search_results"

    /** Wear OS viewer — companion file viewer for Wear OS devices. */
    const val WEAR_VIEWER = "wear_viewer"

    /** Automotive browser — Android Auto / Automotive OS file browser. */
    const val AUTOMOTIVE_BROWSER = "automotive_browser"

    /** Crash review screen — view + dismiss pending crash reports. */
    const val CRASH_REVIEW = "crash_review"

    /** AI insights screen — smart storage analysis + duplicate detection. */
    const val AI = "ai"

    /** Import files dialog route — for share-to-app deep links.
     *  Route template: `"import_files/{paths}"` */
    const val IMPORT_FILES = "import_files"

    // ═══════════════════════════════════════════════════════════
    // MODAL / OVERLAY SCREENS — bottom sheets and dialogs
    // ═══════════════════════════════════════════════════════════

    /** File properties bottom sheet — metadata, permissions, hash.
     *  Route template: `"modal_file_properties/{path}"` */
    const val MODAL_FILE_PROPERTIES = "modal_file_properties"

    /** File preview bottom sheet — quick preview without full viewer.
     *  Route template: `"modal_file_preview/{path}"` */
    const val MODAL_FILE_PREVIEW = "modal_file_preview"

    /** Compression options dialog — format, level, password, split.
     *  Route template: `"modal_compression/{count}/{totalSize}"` */
    const val MODAL_COMPRESSION = "modal_compression"

    /** Extract options dialog — destination, password, overwrite mode.
     *  Route template: `"modal_extract/{path}/{count}/{encrypted}"` */
    const val MODAL_EXTRACT = "modal_extract"

    // ═══════════════════════════════════════════════════════════
    // ARGUMENT KEYS — must be declared BEFORE route templates
    // ═══════════════════════════════════════════════════════════
    const val ARG_PATH = "path"
    const val ARG_PROVIDER_ID = "providerId"
    const val ARG_GROUP_ID = "groupId"
    const val ARG_DIRECTORY_PATH = "dirPath"
    const val ARG_QUERY = "query"
    const val ARG_COUNT = "count"
    const val ARG_TOTAL_SIZE = "totalSize"
    const val ARG_ENCRYPTED = "encrypted"
    const val ARG_PATHS = "paths"
    const val ARG_LABEL = "label"

    // ═══════════════════════════════════════════════════════════
    // ROUTE TEMPLATES — for routes with path arguments
    // ═══════════════════════════════════════════════════════════

    /** Full route template for viewer: `"viewer/{path}"`. */
    const val VIEWER_ROUTE = "$VIEWER/{$ARG_PATH}"

    /** Full route template for archive: `"archive/{path}"`. */
    const val ARCHIVE_ROUTE = "$ARCHIVE/{$ARG_PATH}"

    /** Full route template for browser with path: `"browser/{path}"`. */
    const val BROWSER_ROUTE = "$BROWSER/{$ARG_PATH}"

    /** Full route template for cloud auth: `"cloud_auth/{providerId}"`. */
    const val CLOUD_AUTH_ROUTE = "$CLOUD_AUTH/{$ARG_PROVIDER_ID}"

    /** Full route template for cloud browser: `"cloud_browser/{providerId}/{path}"`. */
    const val CLOUD_BROWSER_ROUTE = "$CLOUD_BROWSER/{$ARG_PROVIDER_ID}/{$ARG_PATH}"

    /** Full route template for duplicate detail: `"duplicate_detail/{groupId}"`. */
    const val DUPLICATE_DETAIL_ROUTE = "$DUPLICATE_DETAIL/{$ARG_GROUP_ID}"

    /** Full route template for search results: `"search_results/{query}"`. */
    const val SEARCH_RESULTS_ROUTE = "$SEARCH_RESULTS/{$ARG_QUERY}"

    /** Full route template for file properties modal: `"modal_file_properties/{path}"`. */
    const val MODAL_FILE_PROPERTIES_ROUTE = "$MODAL_FILE_PROPERTIES/{$ARG_PATH}"

    /** Full route template for file preview modal: `"modal_file_preview/{path}"`. */
    const val MODAL_FILE_PREVIEW_ROUTE = "$MODAL_FILE_PREVIEW/{$ARG_PATH}"

    /** Full route template for compression modal: `"modal_compression/{count}/{totalSize}"`. */
    const val MODAL_COMPRESSION_ROUTE = "$MODAL_COMPRESSION/{$ARG_COUNT}/{$ARG_TOTAL_SIZE}"

    /** Full route template for extract modal: `"modal_extract/{path}/{count}/{encrypted}"`. */
    const val MODAL_EXTRACT_ROUTE = "$MODAL_EXTRACT/{$ARG_PATH}/{$ARG_COUNT}/{$ARG_ENCRYPTED}"

    /** Full route template for import files dialog: `"import_files/{paths}/{label}"`. */
    const val IMPORT_FILES_ROUTE = "$IMPORT_FILES/{$ARG_PATHS}/{$ARG_LABEL}"

    // ═══════════════════════════════════════════════════════════
    // HELPER — check if a route is a top-level destination
    // ═══════════════════════════════════════════════════════════

    /**
     * All top-level routes (shown in bottom navigation).
     *
     * Settings is back in the bottom nav by user request — 5 tabs total.
     */
    val topLevelRoutes = setOf(HOME, BROWSER, SEARCH, CLOUD, SETTINGS)

    /** All boot-flow routes (Splash, Onboarding, Lock). */
    val bootFlowRoutes = setOf(SPLASH, ONBOARDING, APP_LOCK)

    /** All modal routes (bottom sheets, dialogs). */
    val modalRoutes = setOf(
        MODAL_FILE_PROPERTIES,
        MODAL_FILE_PREVIEW,
        MODAL_COMPRESSION,
        MODAL_EXTRACT,
    )

    /** Routes where the bottom navigation bar should be hidden. */
    val routesWithoutBottomBar = bootFlowRoutes + modalRoutes + setOf(
        VIEWER, TRANSFER, ARCHIVE, VAULT, DUPLICATES, ANALYTICS, TRASH,
        STORAGE_OVERVIEW, BOOKMARKS, RECENT_FILES, HIDDEN_FILES,
        CLOUD_AUTH, CLOUD_BROWSER, SEARCH_FILTER,
        DUPLICATE_DETAIL, ANALYTICS_DETAIL,
        // Note: SETTINGS is a top-level tab now, so NOT in this list.
        // Sub-screens of Settings still hide the bottom bar.
        SETTINGS_ABOUT, SETTINGS_STORAGE, SETTINGS_APPEARANCE,
        TAG_MANAGER, SEARCH_RESULTS, WEAR_VIEWER, AUTOMOTIVE_BROWSER,
        CRASH_REVIEW, IMPORT_FILES, AI,
        ADVANCED_APPEARANCE, APPEARANCE_THEME, APPEARANCE_TYPOGRAPHY,
        APPEARANCE_SHAPE, APPEARANCE_DENSITY, APPEARANCE_ELEVATION,
        APPEARANCE_MOTION, APPEARANCE_GLASS,
        ENGINE_SETTINGS, ENGINE_SCAN, ENGINE_CACHE, ENGINE_SEARCH,
        ENGINE_THUMBNAIL, ENGINE_TRASH, ENGINE_ANALYTICS, ENGINE_AI,
        SECURITY_SETTINGS, SECURITY_VAULT, SECURITY_CLOUD, SECURITY_NOTIFICATIONS,
        SYSTEM_SETTINGS, SYSTEM_FILE_BROWSER, SYSTEM_ACCESSIBILITY, SYSTEM_PERFORMANCE,
        SYSTEM_STORAGE, SYSTEM_BEHAVIOR, SYSTEM_ADVANCED,
        BACKUP_SETTINGS, BACKUP_CONFIG, ARCHIVE_CONFIG,
    )

    /** Check if a route is a top-level destination. */
    fun isTopLevel(route: String?): Boolean = route != null && route in topLevelRoutes

    /** Check if a route is in the boot flow. */
    fun isBootFlow(route: String?): Boolean = route != null && route in bootFlowRoutes

    /** Check if the bottom bar should be visible for a route. */
    fun shouldShowBottomBar(route: String?): Boolean =
        route != null && route !in routesWithoutBottomBar

    /** Build a viewer route with an encoded path argument. */
    fun viewerRoute(path: String): String = "$VIEWER/${java.net.URLEncoder.encode(path, "UTF-8")}"

    /**
     * Build a browser route with an optional encoded path argument.
     *
     * Used when navigating to the Browser at a specific folder (e.g.
     * from a bookmark tap). Without this, bookmarks could only open
     * the Browser at the default `/sdcard` root — the bookmarked
     * path was silently ignored.
     */
    fun browserRoute(path: String? = null): String =
        if (path.isNullOrBlank()) BROWSER
        else "$BROWSER/${java.net.URLEncoder.encode(path, "UTF-8")}"

    /** Build an archive route with an encoded path argument. */
    fun archiveRoute(path: String): String = "$ARCHIVE/${java.net.URLEncoder.encode(path, "UTF-8")}"

    /** Build a cloud auth route with a provider ID. */
    fun cloudAuthRoute(providerId: String): String = "$CLOUD_AUTH/$providerId"

    /** Build a cloud browser route with provider ID and path. */
    fun cloudBrowserRoute(providerId: String, path: String): String =
        "$CLOUD_BROWSER/$providerId/${java.net.URLEncoder.encode(path, "UTF-8")}"

    /** Build a duplicate detail route with a group ID. */
    fun duplicateDetailRoute(groupId: String): String = "$DUPLICATE_DETAIL/$groupId"

    /** Build a search results route with an encoded query. */
    fun searchResultsRoute(query: String): String =
        "$SEARCH_RESULTS/${java.net.URLEncoder.encode(query, "UTF-8")}"

    /** Build a file properties modal route with an encoded path. */
    fun modalFilePropertiesRoute(path: String): String =
        "$MODAL_FILE_PROPERTIES/${java.net.URLEncoder.encode(path, "UTF-8")}"

    /** Build a file preview modal route with an encoded path. */
    fun modalFilePreviewRoute(path: String): String =
        "$MODAL_FILE_PREVIEW/${java.net.URLEncoder.encode(path, "UTF-8")}"

    /** Build a compression modal route with file count and total size string. */
    fun modalCompressionRoute(fileCount: Int, totalSize: String): String =
        "$MODAL_COMPRESSION/$fileCount/${java.net.URLEncoder.encode(totalSize, "UTF-8")}"

    /** Build an extract modal route with archive path, entry count, and encrypted flag. */
    fun modalExtractRoute(archivePath: String, entryCount: Int, isEncrypted: Boolean): String =
        "$MODAL_EXTRACT/${java.net.URLEncoder.encode(archivePath, "UTF-8")}/$entryCount/$isEncrypted"

    /**
     * Build an import files route with file paths and source label.
     *
     * Multiple file paths are joined with `|` (pipe) and URL-encoded.
     * Example: `["/sdcard/a.jpg", "/sdcard/b.jpg"]` → `"import_files/%2Fsdcard%2Fa.jpg%7C%2Fsdcard%2Fb.jpg/Chrome"`
     */
    fun importFilesRoute(filePaths: List<String>, sourceLabel: String): String {
        val joinedPaths = filePaths.joinToString("|")
        val encodedPaths = java.net.URLEncoder.encode(joinedPaths, "UTF-8")
        val encodedLabel = java.net.URLEncoder.encode(sourceLabel, "UTF-8")
        return "$IMPORT_FILES/$encodedPaths/$encodedLabel"
    }

    /**
     * Parse the paths argument back into a list of file paths.
     * Inverse of [importFilesRoute].
     */
    fun parseImportPaths(encoded: String?): List<String> {
        if (encoded.isNullOrEmpty()) return emptyList()
        return try {
            val decoded = java.net.URLDecoder.decode(encoded, "UTF-8")
            decoded.split("|").filter { it.isNotEmpty() }
        } catch (_: Exception) {
            emptyList()
        }
    }
}

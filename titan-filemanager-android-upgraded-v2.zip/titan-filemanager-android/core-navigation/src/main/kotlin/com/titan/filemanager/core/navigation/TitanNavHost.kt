package com.titan.filemanager.core.navigation

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable

/**
 * Root [NavHost] for the Titan app.
 *
 * Phase 0: Each destination renders a simple placeholder text.
 * Phase 1: Browser tab is replaced with the real BrowserScreen from
 *          `:feature:browser` — but the wiring happens in :app (see
 *          [com.titan.filemanager.navigation.TitanNavHost]) to avoid
 *          a circular module dependency (core-navigation can't depend
 *          on feature-browser).
 *
 * This class is kept as a default implementation for tests / previews
 * that don't want to wire in feature modules. The :app module overrides
 * it with a fully-wired NavHost.
 */
@Composable
fun TitanNavHost(
    navController: NavHostController,
    modifier: Modifier = Modifier,
) {
    NavHost(
        navController = navController,
        startDestination = NavRoutes.HOME,
        modifier = modifier,
    ) {
        TopLevelDestination.values().forEach { destination ->
            composable(route = destination.route) {
                PlaceholderScreen(destination.label)
            }
        }
    }
}

@Composable
private fun PlaceholderScreen(label: String) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = "$label — coming in a future phase",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

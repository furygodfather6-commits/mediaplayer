package com.titan.filemanager.core.navigation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentLinkedDeque

/**
 * ## NavigationViewModel — Global navigation state.
 *
 * Tracks the navigation back stack, current route, navigation history,
 * and pending deep links. Lives at the app level so any feature module
 * can observe the current destination without holding a reference to
 * the NavController.
 *
 * ### Why
 *  1. **Analytics** — record every navigation event for product analytics.
 *  2. **Deep links** — queue deep links until the NavController is ready.
 *  3. **Back-stack inspection** — check if a route is in the back stack
 *     without poking NavController (which is Compose-only).
 *  4. **Custom back handling** — Android's predictive back gesture needs
 *     a stable "can we go back?" signal that survives recomposition.
 *  5. **Testing** — features can be tested with a fake NavigationViewModel
 *     instead of a real NavController.
 *
 * ### Usage
 * ```
 * // In a feature screen:
 * val navState by navViewModel.state.collectAsStateWithLifecycle()
 * Text("Current: ${navState.currentRoute}")
 *
 * // Record a navigation (called by TitanAppState):
 * navViewModel.recordNavigation(NavRoute.Viewer("/sdcard/photo.jpg"))
 *
 * // Check if we can go back:
 * if (navState.canGoBack) { navViewModel.navigateBack() }
 * ```
 */
class NavigationViewModel : ViewModel() {

    // ── State ──────────────────────────────────────────────────────

    private val _state = MutableStateFlow(NavigationUiState())
    val state: StateFlow<NavigationUiState> = _state.asStateFlow()

    /** Bounded navigation history (most-recent-first). */
    private val history = ConcurrentLinkedDeque<HistoryEntry>()

    /** Pending deep links waiting for NavController to be ready. */
    private val _pendingDeepLinks = MutableStateFlow<List<NavRoute>>(emptyList())
    val pendingDeepLinks: StateFlow<List<NavRoute>> = _pendingDeepLinks.asStateFlow()

    // ── Mutators (called by TitanAppState) ─────────────────────────

    /**
     * Record that the user navigated to [route].
     *
     * Updates currentRoute, pushes the previous route to history, and
     * recomputes canGoBack.
     */
    fun recordNavigation(route: NavRoute, source: NavigationSource = NavigationSource.USER) {
        val now = System.currentTimeMillis()
        val previous = _state.value.currentRoute
        history.addFirst(HistoryEntry(route = route, timestamp = now, source = source))
        // Bound history to 50 entries
        while (history.size > 50) history.removeLast()
        _state.update { current ->
            current.copy(
                currentRoute = route,
                previousRoute = previous,
                backStackSize = current.backStackSize + 1,
                canGoBack = current.backStackSize > 0,
                lastNavigationAt = now,
                navigationCount = current.navigationCount + 1,
            )
        }
    }

    /** Record that the user navigated back. */
    fun recordBackNavigation() {
        if (history.isNotEmpty()) history.removeFirst()
        val previous = history.peekFirst()?.route
        _state.update { current ->
            current.copy(
                currentRoute = previous,
                previousRoute = null,
                backStackSize = (current.backStackSize - 1).coerceAtLeast(0),
                canGoBack = current.backStackSize > 1,
                lastNavigationAt = System.currentTimeMillis(),
            )
        }
    }

    /** Record that the user navigated back to a specific route. */
    fun recordBackTo(route: NavRoute) {
        // Pop history until we find the route (or empty)
        while (history.isNotEmpty()) {
            val top = history.peekFirst()
            if (top?.route == route) break
            history.removeFirst()
        }
        _state.update { current ->
            current.copy(
                currentRoute = route,
                backStackSize = history.size.coerceAtLeast(0),
                canGoBack = history.size > 1,
                lastNavigationAt = System.currentTimeMillis(),
            )
        }
    }

    /** Record that the user navigated home (popped to start). */
    fun recordHome() {
        history.clear()
        _state.update { current ->
            current.copy(
                currentRoute = NavRoute.Home,
                backStackSize = 0,
                canGoBack = false,
                lastNavigationAt = System.currentTimeMillis(),
            )
        }
    }

    /** Record a tab switch (resets back stack for the new tab). */
    fun recordTabSwitch(destination: TopLevelDestination) {
        val route = when (destination) {
            TopLevelDestination.HOME -> NavRoute.Home
            TopLevelDestination.BROWSER -> NavRoute.Browser()
            TopLevelDestination.SEARCH -> NavRoute.Search
            TopLevelDestination.CLOUD -> NavRoute.Cloud
            TopLevelDestination.SETTINGS -> NavRoute.Settings
        }
        // Tab switches don't clear the full back stack in Material 3 —
        // each tab preserves its own state. We just record the new
        // current route.
        _state.update { current ->
            current.copy(
                currentRoute = route,
                lastNavigationAt = System.currentTimeMillis(),
                activeTab = destination,
            )
        }
    }

    // ── Deep links ─────────────────────────────────────────────────

    /** Queue a deep link for processing when NavController is ready. */
    fun queueDeepLink(route: NavRoute) {
        _pendingDeepLinks.update { it + route }
    }

    /** Consume the next pending deep link. Returns null if none. */
    fun consumeDeepLink(): NavRoute? {
        val pending = _pendingDeepLinks.value
        if (pending.isEmpty()) return null
        val next = pending.first()
        _pendingDeepLinks.update { it.drop(1) }
        return next
    }

    // ── Queries ────────────────────────────────────────────────────

    /** Get the last N navigation entries (most-recent-first). */
    fun getHistory(limit: Int = 20): List<HistoryEntry> =
        history.toList().take(limit)

    /** Check if a specific route is in the back stack. */
    fun isInBackStack(route: NavRoute): Boolean =
        history.any { it.route::class == route::class }

    /** Clear all navigation state (used on log out). */
    fun clearAll() {
        history.clear()
        _pendingDeepLinks.value = emptyList()
        _state.value = NavigationUiState()
    }

    // ── Internal ───────────────────────────────────────────────────

    override fun onCleared() {
        super.onCleared()
        history.clear()
    }
}

/**
 * Immutable snapshot of the navigation state.
 */
data class NavigationUiState(
    val currentRoute: NavRoute? = null,
    val previousRoute: NavRoute? = null,
    val backStackSize: Int = 0,
    val canGoBack: Boolean = false,
    val activeTab: TopLevelDestination? = null,
    val lastNavigationAt: Long = 0L,
    val navigationCount: Int = 0,
)

/** A single entry in the navigation history. */
data class HistoryEntry(
    val route: NavRoute,
    val timestamp: Long,
    val source: NavigationSource,
)

/** Where a navigation event originated from. */
enum class NavigationSource {
    /** User tap / action. */
    USER,
    /** System back button. */
    BACK_BUTTON,
    /** Deep link from outside the app. */
    DEEP_LINK,
    /** Programmatic navigation (e.g., boot flow). */
    SYSTEM,
    /** Tab switch in the bottom nav. */
    TAB_SWITCH,
}

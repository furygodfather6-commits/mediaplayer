// :core:navigation — Compose navigation graph + destinations
plugins {
    id("titan.android.library")
    id("titan.android.compose")
}

android {
    namespace = "com.titan.filemanager.core.navigation"
}

dependencies {
    api(libs.androidx.navigation.compose)

    // Testing
    testImplementation(libs.junit5)
    testImplementation(libs.truth)
    testImplementation(libs.kotlinx.coroutines.test)
}

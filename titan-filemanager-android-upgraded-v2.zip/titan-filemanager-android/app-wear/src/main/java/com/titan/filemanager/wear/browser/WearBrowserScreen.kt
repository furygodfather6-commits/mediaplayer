package com.titan.filemanager.wear.browser

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Folder
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.wear.compose.material.Chip
import androidx.wear.compose.material.ChipColors
import androidx.wear.compose.material.Icon
import androidx.wear.compose.material.MaterialTheme
import androidx.wear.compose.material.PositionIndicator
import androidx.wear.compose.material.Scaffold
import androidx.wear.compose.material.ScalingLazyColumn
import androidx.wear.compose.material.Text
import androidx.wear.compose.material.rememberScalingLazyListState
import com.titan.filemanager.core.designsystem.icon.FileTypeIcon

data class WearFileItem(
    val name: String,
    val path: String,
    val isDirectory: Boolean,
    val size: Long,
)

/**
 * Wear OS Browser Screen — simplified file browser for round displays.
 *
 * Features:
 *  - ScalingLazyColumn for curved scrolling
 *  - Folder/file chips with type-specific icons + colors
 *  - Back navigation chip at top
 *  - Current directory name in header
 *  - Empty state for empty folders
 */
@Composable
fun WearBrowserScreen(
    currentDir: String,
    files: List<WearFileItem>,
    onBack: () -> Unit,
    onFileClick: (WearFileItem) -> Unit,
    modifier: Modifier = Modifier,
) {
    val listState = rememberScalingLazyListState()
    val dirName = currentDir.substringAfterLast("/").ifEmpty { "Root" }

    Scaffold(
        modifier = modifier,
        positionIndicator = { PositionIndicator(scalingLazyListState = listState) },
    ) {
        ScalingLazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 16.dp, end = 16.dp, top = 24.dp, bottom = 32.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            // Back + directory header
            item {
                Chip(
                    onClick = onBack,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ChipColors(
                        background = MaterialTheme.colors.surface,
                        content = MaterialTheme.colors.onSurface,
                        secondaryContent = MaterialTheme.colors.onSurfaceVariant,
                        icon = MaterialTheme.colors.primary,
                    ),
                    icon = {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, null, modifier = Modifier.size(20.dp))
                    },
                    label = {
                        Text(
                            dirName,
                            style = MaterialTheme.typography.label1,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    },
                )
            }

            if (files.isEmpty()) {
                item {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth().padding(top = 32.dp),
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .background(
                                    MaterialTheme.colors.surfaceVariant,
                                    CircleShape,
                                ),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                Icons.Filled.Folder,
                                null,
                                modifier = Modifier.size(28.dp),
                                tint = MaterialTheme.colors.onSurfaceVariant,
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Empty folder",
                            style = MaterialTheme.typography.body2,
                            color = MaterialTheme.colors.onSurfaceVariant,
                        )
                    }
                }
            } else {
                // File list
                items(files.size) { index ->
                    val file = files[index]
                    val icon = if (file.isDirectory) FileTypeIcon.Folder
                    else FileTypeIcon.fromPath(file.path)

                    Chip(
                        onClick = { onFileClick(file) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ChipColors(
                            background = MaterialTheme.colors.surface,
                            content = MaterialTheme.colors.onSurface,
                            secondaryContent = MaterialTheme.colors.onSurfaceVariant,
                            icon = icon.color,
                        ),
                        icon = {
                            Icon(icon.imageVector, null, modifier = Modifier.size(24.dp), tint = icon.color)
                        },
                        label = {
                            Text(
                                file.name,
                                style = MaterialTheme.typography.label1,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        },
                        secondaryLabel = {
                            Text(
                                if (file.isDirectory) "Folder" else formatBytes(file.size),
                                style = MaterialTheme.typography.caption2,
                            )
                        },
                    )
                }
            }
        }
    }
}

private fun formatBytes(bytes: Long): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "${bytes / 1024} KB"
    bytes < 1024 * 1024 * 1024 -> "%.0f MB".format(bytes / (1024.0 * 1024))
    else -> "%.1f GB".format(bytes / (1024.0 * 1024 * 1024))
}

// Wear ScalingLazyColumn items helper
private inline fun androidx.wear.compose.material.ScalingLazyListScope.items(
    count: Int,
    crossinline itemContent: @Composable (Int) -> Unit,
) = items(count) { index -> itemContent(index) }

package com.titan.filemanager.wear.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.wear.compose.material.Chip
import androidx.wear.compose.material.ChipColors
import androidx.wear.compose.material.MaterialTheme
import androidx.wear.compose.material.PositionIndicator
import androidx.wear.compose.material.Scaffold
import androidx.wear.compose.material.ScalingLazyColumn
import androidx.wear.compose.material.Text
import androidx.wear.compose.material.rememberScalingLazyListState

data class WearRecentFile(
    val name: String,
    val path: String,
    val icon: ImageVector,
    val iconColor: Color,
)

/**
 * Wear OS Home Screen — Compose for Wear.
 *
 * Designed for round displays (200x200dp typical):
 *  - Quick action chips (Search, Storage, Settings)
 *  - Recent files list with file type icons
 *  - ScalingLazyColumn for smooth scrolling on round screens
 *
 * Uses Wear Compose Material (not phone Material3).
 */
@Composable
fun WearHomeScreen(
    recentFiles: List<WearRecentFile>,
    onSearch: () -> Unit,
    onStorage: () -> Unit,
    onSettings: () -> Unit,
    onFileClick: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val listState = rememberScalingLazyListState()

    Scaffold(
        modifier = modifier,
        positionIndicator = { PositionIndicator(scalingLazyListState = listState) },
    ) {
        ScalingLazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = 32.dp,
                bottom = 32.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            // App title
            item {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .background(
                                brush = Brush.radialGradient(
                                    colors = listOf(Color(0xFF1A73E8), Color(0xFF3B40E0)),
                                ),
                                shape = CircleShape,
                            ),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            Icons.Filled.Folder,
                            null,
                            tint = Color.White,
                            modifier = Modifier.size(28.dp),
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Titan",
                        style = MaterialTheme.typography.title3,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }

            // Quick action chips
            item {
                QuickActionChip(
                    icon = Icons.Filled.Search,
                    label = "Search Files",
                    color = Color(0xFF1A73E8),
                    onClick = onSearch,
                )
            }
            item {
                QuickActionChip(
                    icon = Icons.Filled.Storage,
                    label = "Storage",
                    color = Color(0xFF00897B),
                    onClick = onStorage,
                )
            }

            // Recent files header
            if (recentFiles.isNotEmpty()) {
                item {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    ) {
                        Icon(Icons.Filled.History, null, modifier = Modifier.size(16.dp),
                            tint = MaterialTheme.colors.onSurfaceVariant)
                        Spacer(Modifier.size(4.dp))
                        Text(
                            "Recent",
                            style = MaterialTheme.typography.label1,
                            fontWeight = FontWeight.Medium,
                        )
                    }
                }
            }

            // Recent file chips
            items(recentFiles) { file ->
                Chip(
                    onClick = { onFileClick(file.path) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ChipColors(
                        background = MaterialTheme.colors.surface,
                        content = MaterialTheme.colors.onSurface,
                        secondaryContent = MaterialTheme.colors.onSurfaceVariant,
                        icon = file.iconColor,
                    ),
                    icon = {
                        Icon(
                            file.icon,
                            null,
                            modifier = Modifier.size(24.dp),
                            tint = file.iconColor,
                        )
                    },
                    label = {
                        Text(
                            file.name,
                            style = MaterialTheme.typography.label1,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    },
                )
            }

            // Settings chip at bottom
            item {
                QuickActionChip(
                    icon = Icons.Filled.Settings,
                    label = "Settings",
                    color = Color(0xFF7B1FA2),
                    onClick = onSettings,
                )
            }
        }
    }
}

@Composable
private fun QuickActionChip(
    icon: ImageVector,
    label: String,
    color: Color,
    onClick: () -> Unit,
) {
    Chip(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = ChipColors(
            background = color.copy(alpha = 0.15f),
            content = MaterialTheme.colors.onSurface,
            secondaryContent = MaterialTheme.colors.onSurfaceVariant,
            icon = color,
        ),
        icon = {
            Icon(icon, null, modifier = Modifier.size(24.dp), tint = color)
        },
        label = {
            Text(label, style = MaterialTheme.typography.label1, fontWeight = FontWeight.Medium)
        },
    )
}

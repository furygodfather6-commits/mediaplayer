package com.titan.filemanager.data.analytics.di

import com.titan.filemanager.data.analytics.repository.DefaultAnalyticsRepository
import com.titan.filemanager.domain.analytics.AnalyticsRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class AnalyticsModule {

    @Binds
    @Singleton
    abstract fun bindAnalyticsRepository(impl: DefaultAnalyticsRepository): AnalyticsRepository
}

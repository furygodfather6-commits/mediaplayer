package com.titan.filemanager.data.analytics.repository

import com.titan.filemanager.core.common.result.AppError
import com.titan.filemanager.core.common.result.Result
import com.titan.filemanager.core.model.file.FileCategory
import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.data.analytics.engine.AnalyticsEngine
import com.titan.filemanager.domain.analytics.AnalyticsProgress
import com.titan.filemanager.domain.analytics.AnalyticsRepository
import com.titan.filemanager.domain.analytics.DuplicateGroup
import com.titan.filemanager.domain.analytics.DuplicateProgress
import com.titan.filemanager.domain.analytics.FolderStats
import com.titan.filemanager.domain.analytics.StorageStats
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DefaultAnalyticsRepository @Inject constructor(
    private val engine: AnalyticsEngine,
) : AnalyticsRepository {

    override fun scanStorage(rootPath: String): Flow<AnalyticsProgress> = engine.scanStorage(rootPath)

    override suspend fun getStorageStats(): Result<StorageStats> {
        val stats = engine.getStorageStats()
        return if (stats != null) Result.Success(stats)
        else Result.Error(AppError.Unknown(IllegalStateException("Storage not scanned yet")))
    }

    override suspend fun getBiggestFiles(limit: Int): Result<List<FileItem>> =
        Result.Success(engine.getBiggestFiles(limit))

    override suspend fun getBiggestFolders(limit: Int): Result<List<FolderStats>> =
        Result.Success(engine.getBiggestFolders(limit))

    override suspend fun getFileTypeBreakdown(): Result<Map<FileCategory, Long>> =
        Result.Success(engine.getFileTypeBreakdown())

    override fun findDuplicates(rootPath: String): Flow<DuplicateProgress> = engine.findDuplicates(rootPath)

    override suspend fun getDuplicateGroups(): Result<List<DuplicateGroup>> =
        Result.Success(engine.getDuplicateGroups())

    override suspend fun getStaleFiles(daysThreshold: Int): Result<List<FileItem>> =
        Result.Success(engine.getStaleFiles(daysThreshold))

    override suspend fun getEmptyFolders(rootPath: String): Result<List<String>> =
        Result.Success(engine.getEmptyFolders(rootPath))
}

package com.titan.filemanager.data.analytics.engine

import com.titan.filemanager.core.common.dispatcher.DispatcherProvider
import com.titan.filemanager.core.common.logger.Logger
import com.titan.filemanager.core.model.file.FileCategory
import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.domain.analytics.AnalyticsProgress
import com.titan.filemanager.domain.analytics.DuplicateGroup
import com.titan.filemanager.domain.analytics.DuplicateProgress
import com.titan.filemanager.domain.analytics.FolderStats
import com.titan.filemanager.domain.analytics.StorageStats
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Analytics engine — walks the filesystem to compute storage insights.
 *
 * Phase 5: full walk + in-memory aggregation.
 * Phase 6 will add: incremental updates via FileObserver, cached results in Room.
 */
@Singleton
class AnalyticsEngine @Inject constructor(
    private val dispatchers: DispatcherProvider,
    private val logger: Logger,
) {

    @Volatile
    private var cachedStats: StorageStats? = null

    @Volatile
    private var cachedBiggestFiles: List<FileItem> = emptyList()

    @Volatile
    private var cachedBiggestFolders: List<FolderStats> = emptyList()

    @Volatile
    private var cachedBreakdown: Map<FileCategory, Long> = emptyMap()

    @Volatile
    private var cachedDuplicates: List<DuplicateGroup> = emptyList()

    fun scanStorage(rootPath: String): Flow<AnalyticsProgress> = flow {
        val root = File(rootPath)
        if (!root.exists() || !root.isDirectory) return@flow

        var filesScanned = 0
        var totalBytes = 0L
        val startTime = System.currentTimeMillis()
        val allFiles = mutableListOf<FileItem>()
        val folderSizes = mutableMapOf<String, Long>()
        val folderFileCounts = mutableMapOf<String, Int>()
        val breakdown = mutableMapOf<FileCategory, Long>()

        val pendingProgress = mutableListOf<AnalyticsProgress>()
        walkFiles(root) { file ->
            filesScanned++
            totalBytes += file.length()

            val item = file.toFileItem()
            allFiles.add(item)

            // Folder sizes
            var parent = file.parentFile
            while (parent != null && parent.absolutePath.startsWith(rootPath)) {
                val parentPath = parent.absolutePath
                folderSizes[parentPath] = (folderSizes[parentPath] ?: 0L) + file.length()
                folderFileCounts[parentPath] = (folderFileCounts[parentPath] ?: 0) + 1
                parent = parent.parentFile
            }

            // Breakdown by category
            val category = FileCategory.fromExtension(item.extension)
            breakdown[category] = (breakdown[category] ?: 0L) + file.length()

            if (filesScanned % 100 == 0) {
                val elapsed = (System.currentTimeMillis() - startTime) / 1000f
                pendingProgress.add(AnalyticsProgress(
                    filesScanned = filesScanned,
                    totalBytes = totalBytes,
                    currentPath = file.absolutePath,
                    ratePerSecond = if (elapsed > 0) filesScanned / elapsed else 0f,
                ))
            }
        }

        // Emit collected progress
        pendingProgress.forEach { emit(it) }

        // Compute final stats
        val totalSpace = root.totalSpace
        val freeSpace = root.usableSpace
        val usedSpace = totalSpace - freeSpace

        cachedStats = StorageStats(
            totalBytes = totalSpace,
            usedBytes = usedSpace,
            freeBytes = freeSpace,
            fileCount = filesScanned,
            folderCount = folderSizes.size,
            scannedAt = System.currentTimeMillis(),
        )

        cachedBiggestFiles = allFiles.sortedByDescending { it.size }.take(50)
        cachedBiggestFolders = folderSizes.entries
            .map { (path, size) ->
                FolderStats(
                    path = path,
                    displayName = File(path).name.ifEmpty { path },
                    sizeBytes = size,
                    fileCount = folderFileCounts[path] ?: 0,
                )
            }
            .sortedByDescending { it.sizeBytes }
            .take(20)

        cachedBreakdown = breakdown

        // Final progress
        emit(AnalyticsProgress(
            filesScanned = filesScanned,
            totalBytes = totalBytes,
            currentPath = null,
            ratePerSecond = filesScanned / ((System.currentTimeMillis() - startTime) / 1000f).coerceAtLeast(0.001f),
        ))
    }

    fun findDuplicates(rootPath: String): Flow<DuplicateProgress> = flow {
        val root = File(rootPath)
        if (!root.exists()) return@flow

        // Level 1: Group by size (O(n) — instant filter)
        val filesBySize = mutableMapOf<Long, MutableList<File>>()
        var scanned = 0

        val pendingDupProgress = mutableListOf<DuplicateProgress>()
        walkFiles(root) { file ->
            val size = file.length()
            if (size > 0) {
                filesBySize.getOrPut(size) { mutableListOf() }.add(file)
            }
            scanned++
            if (scanned % 500 == 0) {
                pendingDupProgress.add(DuplicateProgress(scanned, 0, 0L, file.absolutePath))
            }
        }
        pendingDupProgress.forEach { emit(it) }

        // Level 2: For groups with >1 file, compute partial hash (first+middle+last 4KB)
        val partialHashGroups = mutableMapOf<String, MutableList<File>>()
        var duplicateGroups = 0
        var wastedBytes = 0L

        for ((size, files) in filesBySize) {
            if (files.size < 2) continue
            for (file in files) {
                val partialHash = computePartialHash(file)
                partialHashGroups.getOrPut(partialHash) { mutableListOf() }.add(file)
            }
        }

        // Level 3: For groups with >1 file (partial hash match), compute full hash
        for ((_, files) in partialHashGroups) {
            if (files.size < 2) continue
            val fullHashGroups = mutableMapOf<String, MutableList<File>>()
            for (file in files) {
                val fullHash = computeFullHash(file)
                fullHashGroups.getOrPut(fullHash) { mutableListOf() }.add(file)
            }
            for ((hash, group) in fullHashGroups) {
                if (group.size < 2) continue
                duplicateGroups++
                wastedBytes += group[0].length() * (group.size - 1)
                emit(DuplicateProgress(
                    filesScanned = scanned,
                    duplicateGroupsFound = duplicateGroups,
                    wastedBytes = wastedBytes,
                    currentPath = null,
                ))
            }
        }
    }

    fun getStorageStats(): StorageStats? = cachedStats

    fun getBiggestFiles(limit: Int): List<FileItem> = cachedBiggestFiles.take(limit)

    fun getBiggestFolders(limit: Int): List<FolderStats> = cachedBiggestFolders.take(limit)

    fun getFileTypeBreakdown(): Map<FileCategory, Long> = cachedBreakdown

    fun getDuplicateGroups(): List<DuplicateGroup> = cachedDuplicates

    fun getStaleFiles(daysThreshold: Int): List<FileItem> {
        val cutoff = System.currentTimeMillis() - daysThreshold * 24L * 60 * 60 * 1000
        return cachedBiggestFiles.filter { it.modifiedAt < cutoff }
    }

    fun getEmptyFolders(rootPath: String): List<String> {
        val result = mutableListOf<String>()
        File(rootPath).walkTopDown().filter { it.isDirectory }.forEach { dir ->
            if (dir.listFiles()?.isEmpty() == true) {
                result.add(dir.absolutePath)
            }
        }
        return result
    }

    // ── Helpers ──────────────────────────────────────────────────

    private fun walkFiles(dir: File, onFile: (File) -> Unit) {
        dir.listFiles()?.forEach { child ->
            if (child.isDirectory) {
                walkFiles(child, onFile)
            } else if (child.isFile) {
                onFile(child)
            }
        }
    }

    private fun computePartialHash(file: File): String {
        val size = file.length()
        if (size <= 12288) return computeFullHash(file) // small file — just hash fully

        val md = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { stream ->
            // First 4KB
            val first = ByteArray(4096)
            stream.read(first)
            md.update(first)

            // Middle 4KB
            val midOffset = size / 2
            stream.channel.position(midOffset)
            val mid = ByteArray(4096)
            stream.read(mid)
            md.update(mid)

            // Last 4KB
            val lastOffset = size - 4096
            stream.channel.position(lastOffset)
            val last = ByteArray(4096)
            stream.read(last)
            md.update(last)
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun computeFullHash(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { stream ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val read = stream.read(buffer)
                if (read == -1) break
                md.update(buffer, 0, read)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun File.toFileItem(): FileItem = FileItem(
        path = absolutePath,
        name = name,
        stableId = runCatching { absoluteFile.hashCode().toLong() }.getOrDefault(0L),
        size = length(),
        modifiedAt = lastModified(),
        isDirectory = false,
        isHidden = name.startsWith("."),
    )
}

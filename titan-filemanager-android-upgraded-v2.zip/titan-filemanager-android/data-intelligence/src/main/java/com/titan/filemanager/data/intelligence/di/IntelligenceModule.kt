package com.titan.filemanager.data.intelligence.di

import android.content.Context
import com.titan.filemanager.data.intelligence.engine.IntelligenceEngine
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object IntelligenceModule {

    @Provides
    @Singleton
    fun provideIntelligenceEngine(@ApplicationContext context: Context): IntelligenceEngine {
        return IntelligenceEngine(context).also { it.initialize() }
    }
}

package com.titan.filemanager.data.intelligence.prediction

import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.data.intelligence.cache.AICacheWarmer
import com.titan.filemanager.data.intelligence.cache.HotFolderDetector
import com.titan.filemanager.data.intelligence.learning.UsageLearner
import com.titan.filemanager.data.intelligence.optimization.AdaptiveOptimizer
import kotlinx.coroutines.*
import timber.log.Timber
import java.util.concurrent.PriorityBlockingQueue
import java.util.concurrent.atomic.AtomicLong

/**
 * Smart Prefetch Manager — coordinates ALL prefetching using predictions.
 *
 * - Folder prefetch (directory listings)
 * - Thumbnail prefetch
 * - Cache prefetch (warm layers)
 *
 * Adapts based on device resources (battery, memory, network).
 *
 * Technique #130: Smart prefetch
 * Technique #14: Speculative directory prefetch
 * Technique #51: Predictive cache
 */
class PrefetchPredictor(
    private val folderPredictor: FolderPredictor,
    private val thumbnailPredictor: ThumbnailPredictor,
    private val usageLearner: UsageLearner,
    private val hotFolderDetector: HotFolderDetector,
    private val cacheWarmer: AICacheWarmer,
    private val optimizer: AdaptiveOptimizer,
    private val scope: CoroutineScope,
) {
    private val prefetchQueue = PriorityBlockingQueue<PrefetchRequest>(200, compareBy { it.priority })
    private val activeJobs = mutableMapOf<String, Job>()
    private val totalPrefetches = AtomicLong(0)
    private val usefulPrefetches = AtomicLong(0)

    var onPrefetchFolder: (suspend (String) -> Unit)? = null
    var onPrefetchThumbnail: (suspend (String) -> Unit)? = null

    data class PrefetchRequest(val path: String, val type: PrefetchType, val priority: Int, val probability: Float, val reason: String)
    enum class PrefetchType { FOLDER_LISTING, THUMBNAIL, METADATA, CACHE_WARM }

    fun onNavigationEvent(currentPath: String, previousPath: String?, children: List<String>) {
        val profile = optimizer.currentProfile
        cancelIrrelevantPrefetches(currentPath)
        scope.launch(Dispatchers.Default) {
            val prediction = folderPredictor.predictNextFolders(currentPath, previousPath, currentChildren = children)
            Timber.d("Prefetch: ${prediction.predictedPaths.size} predicted from $currentPath")
            prediction.predictedPaths.filter { it.probability > 0.2f }.forEach { predicted ->
                enqueuePrefetch(PrefetchRequest(predicted.path, PrefetchType.FOLDER_LISTING, predicted.urgency, predicted.probability, predicted.reason))
                if (profile.enableAggressivePrefetch && predicted.probability > 0.5f)
                    scheduleDeeperPrefetch(predicted.path, profile.prefetchDepth)
            }
            cacheWarmer.warmAfterFolderOpen(currentPath, previousPath, children)
            processPrefetchQueue()
        }
    }

    private fun scheduleDeeperPrefetch(path: String, depth: Int) {
        if (depth <= 0) return
        scope.launch(Dispatchers.IO) {
            try {
                val children = java.io.File(path).list() ?: return@launch
                children.filter { java.io.File("$path/$it").isDirectory }.take(3).forEach { subdir ->
                    enqueuePrefetch(PrefetchRequest("$path/$subdir", PrefetchType.FOLDER_LISTING, 2, 0.3f, "Deep prefetch depth=$depth"))
                }
                if (depth > 1) children.filter { java.io.File("$path/$it").isDirectory }.take(3).forEach { scheduleDeeperPrefetch("$path/$it", depth - 1) }
            } catch (_: Exception) {}
        }
    }

    fun onScrollPositionChanged(allItems: List<FileItem>, firstVisible: Int, lastVisible: Int) {
        thumbnailPredictor.updateScrollPosition(firstVisible, System.currentTimeMillis())
        thumbnailPredictor.predictThumbnails(allItems, firstVisible, lastVisible).predictedPaths
            .filter { it.probability > 0.4f }.take(10).forEach { p ->
                enqueuePrefetch(PrefetchRequest(p.path, PrefetchType.THUMBNAIL, p.urgency, p.probability, p.reason))
            }
        processPrefetchQueue()
    }

    private fun enqueuePrefetch(request: PrefetchRequest) {
        if (prefetchQueue.any { it.path == request.path && it.priority <= request.priority }) return
        prefetchQueue.offer(request)
    }

    private fun processPrefetchQueue() {
        val maxConcurrent = optimizer.currentProfile.scanThreadCount / 2
        while (activeJobs.size < maxConcurrent) {
            val request = prefetchQueue.poll() ?: break
            if (activeJobs.containsKey(request.path)) continue
            activeJobs[request.path] = scope.launch(Dispatchers.IO) {
                try {
                    when (request.type) {
                        PrefetchType.FOLDER_LISTING -> onPrefetchFolder?.invoke(request.path)
                        PrefetchType.THUMBNAIL -> onPrefetchThumbnail?.invoke(request.path)
                        PrefetchType.CACHE_WARM -> cacheWarmer.warmAfterFolderOpen(request.path, null, emptyList())
                        PrefetchType.METADATA -> {}
                    }
                    totalPrefetches.incrementAndGet()
                } catch (_: Exception) {} finally {
                    activeJobs.remove(request.path)
                    if (prefetchQueue.isNotEmpty()) processPrefetchQueue()
                }
            }
        }
    }

    fun recordPrefetchHit(path: String) { usefulPrefetches.incrementAndGet(); cacheWarmer.recordWarmingHit(path) }

    private fun cancelIrrelevantPrefetches(currentPath: String) {
        activeJobs.entries.toList().forEach { (path, job) ->
            if (!path.startsWith(currentPath) && !currentPath.startsWith(path.substringBeforeLast('/'))) { job.cancel(); activeJobs.remove(path) }
        }
    }

    fun getStats() = PrefetchStats(totalPrefetches.get(), usefulPrefetches.get(),
        if (totalPrefetches.get() > 0) usefulPrefetches.get().toFloat() / totalPrefetches.get() else 0f, prefetchQueue.size, activeJobs.size)

    fun destroy() { activeJobs.values.forEach { it.cancel() }; activeJobs.clear(); prefetchQueue.clear() }

    data class PrefetchStats(val totalPrefetches: Long, val usefulPrefetches: Long, val efficiency: Float, val queueSize: Int, val activeJobs: Int)
}

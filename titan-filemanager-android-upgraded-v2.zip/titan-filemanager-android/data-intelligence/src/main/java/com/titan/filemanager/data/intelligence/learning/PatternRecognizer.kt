package com.titan.filemanager.data.intelligence.learning

import java.util.concurrent.ConcurrentHashMap

/**
 * Pattern Recognizer — identifies behavioral patterns in navigation.
 *
 * 1. Sequential: A→B→C→D (bigram/trigram N-gram models)
 * 2. Time: visits at specific hours
 * 3. Session: common session flows
 *
 * Technique #126: Usage learning (patterns)
 * Technique #132: Adaptive optimization
 */
class PatternRecognizer {

    private val bigramPatterns = ConcurrentHashMap<String, MutableList<String>>()
    private val trigramPatterns = ConcurrentHashMap<String, MutableList<String>>()
    private val hourlyPatterns = Array(24) { mutableListOf<String>() }
    private val sessionPatterns = mutableListOf<List<String>>()

    companion object {
        private const val MAX_PATTERN_HISTORY = 100
        private const val MIN_PATTERN_CONFIDENCE = 0.3f
    }

    fun learnFromNavigation(navigationPath: List<String>, timestamps: List<Long>) {
        if (navigationPath.size < 2) return
        // Bigrams
        for (i in 0 until navigationPath.size - 1) {
            val key = "${navigationPath[i]}|${navigationPath[i + 1]}"
            bigramPatterns.getOrPut(key) { mutableListOf() }.let { list ->
                synchronized(list) { if (i + 2 < navigationPath.size) { list.add(navigationPath[i + 2]); if (list.size > MAX_PATTERN_HISTORY) list.removeAt(0) } }
            }
        }
        // Trigrams
        for (i in 0 until navigationPath.size - 2) {
            val key = "${navigationPath[i]}|${navigationPath[i + 1]}|${navigationPath[i + 2]}"
            trigramPatterns.getOrPut(key) { mutableListOf() }.let { list ->
                synchronized(list) { if (i + 3 < navigationPath.size) { list.add(navigationPath[i + 3]); if (list.size > MAX_PATTERN_HISTORY) list.removeAt(0) } }
            }
        }
        // Time patterns
        timestamps.zip(navigationPath).forEach { (ts, path) ->
            val hour = java.util.Calendar.getInstance().apply { timeInMillis = ts }.get(java.util.Calendar.HOUR_OF_DAY)
            synchronized(hourlyPatterns[hour]) { hourlyPatterns[hour].add(path); if (hourlyPatterns[hour].size > MAX_PATTERN_HISTORY) hourlyPatterns[hour].removeAt(0) }
        }
        // Session patterns
        val uniquePaths = navigationPath.distinct()
        if (uniquePaths.size >= 3) synchronized(sessionPatterns) { sessionPatterns.add(uniquePaths); if (sessionPatterns.size > 50) sessionPatterns.removeAt(0) }
    }

    fun predictNextBigram(currentPath: String, previousPath: String?): List<Pair<String, Float>> {
        val predictions = mutableMapOf<String, Float>()
        // Trigram (higher accuracy)
        if (previousPath != null) {
            val trigramKey = "$previousPath|$currentPath"
            trigramPatterns[trigramKey]?.let { nextPaths ->
                synchronized(nextPaths) {
                    val counts = nextPaths.groupingBy { it }.eachCount(); val total = counts.values.sum().toFloat()
                    counts.forEach { (path, count) -> predictions[path] = (predictions[path] ?: 0f) + (count / total) * 0.6f }
                }
            }
        }
        // Bigram (lower accuracy but more data)
        val bigramKey = "$previousPath|$currentPath"
        bigramPatterns[bigramKey]?.let { nextPaths ->
            synchronized(nextPaths) {
                val counts = nextPaths.groupingBy { it }.eachCount(); val total = counts.values.sum().toFloat()
                counts.forEach { (path, count) -> predictions[path] = (predictions[path] ?: 0f) + (count / total) * 0.4f }
            }
        }
        return predictions.entries.filter { it.value >= MIN_PATTERN_CONFIDENCE }.sortedByDescending { it.value }.map { Pair(it.key, it.value) }
    }

    fun getTimeBasedPredictions(currentHour: Int, topN: Int = 5): List<Pair<String, Float>> {
        val hourPaths = synchronized(hourlyPatterns[currentHour]) { hourlyPatterns[currentHour].toList() }
        if (hourPaths.isEmpty()) return emptyList()
        val counts = hourPaths.groupingBy { it }.eachCount(); val total = counts.values.sum().toFloat()
        return counts.entries.sortedByDescending { it.value }.take(topN).map { (path, count) -> Pair(path, count / total) }
    }

    fun findSimilarSessions(currentSessionPaths: List<String>): List<List<String>> {
        if (currentSessionPaths.isEmpty()) return emptyList()
        return synchronized(sessionPatterns) {
            sessionPatterns.filter { stored -> currentSessionPaths.intersect(stored.toSet()).size.toFloat() / currentSessionPaths.size > 0.5f }.take(5)
        }
    }

    fun getStats() = PatternStats(
        bigramCount = bigramPatterns.size, trigramCount = trigramPatterns.size,
        sessionCount = synchronized(sessionPatterns) { sessionPatterns.size },
        hourlyPatternCoverage = hourlyPatterns.count { it.isNotEmpty() },
    )

    data class PatternStats(val bigramCount: Int, val trigramCount: Int, val sessionCount: Int, val hourlyPatternCoverage: Int)
}

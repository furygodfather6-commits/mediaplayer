package com.titan.filemanager.data.intelligence.learning

import com.titan.filemanager.data.intelligence.model.FolderScore
import com.titan.filemanager.data.intelligence.model.UsageEvent
import com.titan.filemanager.data.intelligence.model.UserSession
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicReference

/**
 * Usage Learner — records interactions, learns patterns, computes folder scores.
 *
 * Score = w1*Recency + w2*Frequency + w3*Dwell + w4*TimePattern
 *
 * Technique #126: Usage learning
 * Technique #131: Hot-folder detection
 * Technique #132: Adaptive optimization
 */
class UsageLearner(private val database: UsageDatabase) {

    companion object {
        private const val WEIGHT_RECENCY = 0.35f
        private const val WEIGHT_FREQUENCY = 0.30f
        private const val WEIGHT_DWELL = 0.20f
        private const val WEIGHT_TIME = 0.15f
        private const val RECENCY_HALF_LIFE_MS = 7 * 24 * 60 * 60 * 1000L
    }

    private val currentSession = AtomicReference<UserSession?>(null)
    private val folderScores = ConcurrentHashMap<String, FolderScore>()
    private val visitTimestamps = ConcurrentHashMap<String, MutableList<Long>>()
    private val recentEvents = ArrayDeque<UsageEvent>(100)

    private val _hotFolders = MutableStateFlow<List<FolderScore>>(emptyList())
    val hotFolders: StateFlow<List<FolderScore>> = _hotFolders.asStateFlow()

    fun startSession(): UserSession {
        val session = UserSession(sessionId = UUID.randomUUID().toString())
        currentSession.set(session); return session
    }

    fun endSession() {
        currentSession.get()?.let { session -> session.endTime = System.currentTimeMillis(); currentSession.set(null); database.forceSave() }
    }

    fun onFolderOpen(path: String, fromPath: String? = null, itemCount: Int = 0) {
        val session = currentSession.get() ?: startSession()
        val event = UsageEvent(eventType = UsageEvent.EventType.FOLDER_OPEN, path = path, sessionId = session.sessionId, itemCount = itemCount)
        recordEvent(event, session)
        if (session.currentPath.isNotEmpty() && session.currentPath != path) onFolderClose(session.currentPath, session)
        session.previousPath = session.currentPath; session.currentPath = path
        session.navigationStack.addLast(path)
        if (session.navigationStack.size > 20) session.navigationStack.removeFirst()
        database.recordVisit(path, 0, fromPath ?: session.previousPath.takeIf { it.isNotEmpty() }, event.hourOfDay)
        visitTimestamps.getOrPut(path) { mutableListOf() }.let { list ->
            synchronized(list) { list.add(System.currentTimeMillis()); if (list.size > 50) list.removeAt(0) }
        }
        recomputeScore(path)
    }

    fun onFolderClose(path: String, session: UserSession? = null) {
        val activeSession = session ?: currentSession.get() ?: return
        val openEvent = activeSession.events.lastOrNull { it.eventType == UsageEvent.EventType.FOLDER_OPEN && it.path == path } ?: return
        val dwellTimeMs = System.currentTimeMillis() - openEvent.timestamp
        recordEvent(UsageEvent(eventType = UsageEvent.EventType.FOLDER_CLOSE, path = path, sessionId = activeSession.sessionId, dwellTimeMs = dwellTimeMs), activeSession)
        database.recordVisit(path, dwellTimeMs, null, openEvent.hourOfDay)
        recomputeScore(path)
    }

    fun onFolderScroll(path: String, scrollDepth: Int) {
        val session = currentSession.get() ?: return
        recordEvent(UsageEvent(eventType = UsageEvent.EventType.FOLDER_SCROLL, path = path, sessionId = session.sessionId, scrollDepth = scrollDepth), session)
        if (scrollDepth > 50) recomputeScore(path)
    }

    fun onFileOpen(filePath: String) {
        val session = currentSession.get() ?: startSession()
        recordEvent(UsageEvent(eventType = UsageEvent.EventType.FILE_OPEN, path = filePath, parentPath = filePath.substringBeforeLast('/'), sessionId = session.sessionId), session)
    }

    fun computeScore(path: String): FolderScore {
        val visitCount = database.getVisitCount(path).toInt()
        if (visitCount == 0) return FolderScore.empty(path)
        val currentHour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        val recencyScore = computeRecencyScore(path)
        val maxVisits = database.getTopPaths(1).firstOrNull()?.second?.toFloat() ?: 1f
        val frequencyScore = minOf(visitCount.toFloat() / maxOf(maxVisits, 1f), 1.0f)
        val avgDwell = database.getAvgDwellMs(path)
        val dwellScore = minOf(avgDwell.toFloat() / (5 * 60 * 1000f), 1.0f)
        val timeScore = database.getTimePatternScore(path, currentHour)
        val totalScore = (WEIGHT_RECENCY * recencyScore + WEIGHT_FREQUENCY * frequencyScore + WEIGHT_DWELL * dwellScore + WEIGHT_TIME * timeScore).coerceIn(0f, 1f)
        return FolderScore(path, totalScore, visitCount, recencyScore, frequencyScore, dwellScore, timeScore, lastVisited = getLastVisitTime(path), avgDwellMs = avgDwell, predictedNextVisit = predictNextVisit(path))
    }

    private fun computeRecencyScore(path: String): Float {
        val timestamps = visitTimestamps[path] ?: return 0f
        return synchronized(timestamps) {
            if (timestamps.isEmpty()) 0f
            else {
                val now = System.currentTimeMillis()
                val lambda = Math.log(2.0) / RECENCY_HALF_LIFE_MS
                var score = 0.0
                timestamps.forEach { ts -> score += Math.exp(-lambda * (now - ts)) }
                minOf(score.toFloat(), 1.0f)
            }
        }
    }

    private fun predictNextVisit(path: String): Long {
        val timestamps = visitTimestamps[path] ?: return 0L
        return synchronized(timestamps) {
            if (timestamps.size < 2) 0L
            else { val intervals = timestamps.zipWithNext { a, b -> b - a }; timestamps.last() + intervals.average().toLong() }
        }
    }

    private fun getLastVisitTime(path: String): Long = visitTimestamps[path]?.lastOrNull() ?: 0L

    private fun recomputeScore(path: String) {
        val score = computeScore(path); folderScores[path] = score
        _hotFolders.value = folderScores.values.filter { it.isHot }.sortedByDescending { it.totalScore }.take(20)
    }

    private fun recordEvent(event: UsageEvent, session: UserSession) {
        session.addEvent(event); recentEvents.addLast(event); if (recentEvents.size > 100) recentEvents.removeFirst()
    }

    fun getFolderScore(path: String): FolderScore = folderScores[path] ?: computeScore(path).also { folderScores[path] = it }
    fun getHotFolders(limit: Int = 20): List<FolderScore> = folderScores.values.filter { it.isHot }.sortedByDescending { it.totalScore }.take(limit)
    fun getRecentPath(): List<String> = currentSession.get()?.navigationStack?.toList() ?: emptyList()
    fun recomputeAllScores() { database.getAllPaths().forEach { recomputeScore(it) } }
}

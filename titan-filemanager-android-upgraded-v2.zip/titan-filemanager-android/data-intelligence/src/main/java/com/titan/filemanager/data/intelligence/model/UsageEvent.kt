package com.titan.filemanager.data.intelligence.model

/**
 * Every user interaction recorded as UsageEvent.
 * Raw data that feeds the ML model.
 *
 * Technique #126: Usage learning
 */
data class UsageEvent(
    val id: Long = 0,
    val eventType: EventType,
    val path: String,
    val parentPath: String = path.substringBeforeLast('/'),
    val timestamp: Long = System.currentTimeMillis(),
    val sessionId: String = "",
    val dwellTimeMs: Long = 0,
    val scrollDepth: Int = 0,
    val itemCount: Int = 0,
    val dayOfWeek: Int = getDayOfWeek(),
    val hourOfDay: Int = getHourOfDay(),
    val isWeekend: Boolean = dayOfWeek >= 6,
    val metadata: Map<String, String> = emptyMap(),
) {
    enum class EventType {
        FOLDER_OPEN, FOLDER_CLOSE, FOLDER_SCROLL, FILE_OPEN, FILE_PREVIEW,
        SEARCH_PERFORMED, NAVIGATION_BACK, APP_FOREGROUND, APP_BACKGROUND,
        THUMBNAIL_VIEWED, SHARE_PERFORMED, DELETE_PERFORMED, COPY_PERFORMED, MOVE_PERFORMED,
    }

    companion object {
        private fun getDayOfWeek(): Int = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_WEEK)
        private fun getHourOfDay(): Int = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
    }
}

data class FolderScore(
    val path: String,
    val totalScore: Float,
    val visitCount: Int,
    val recencyScore: Float,
    val frequencyScore: Float,
    val dwellScore: Float,
    val timePatternScore: Float,
    val isHot: Boolean = totalScore > HOT_THRESHOLD,
    val lastVisited: Long = 0L,
    val avgDwellMs: Long = 0L,
    val predictedNextVisit: Long = 0L,
) {
    companion object {
        const val HOT_THRESHOLD = 0.7f
        const val WARM_THRESHOLD = 0.4f
        fun empty(path: String) = FolderScore(path, 0f, 0, 0f, 0f, 0f, 0f)
    }
    val isWarm: Boolean get() = totalScore in WARM_THRESHOLD..HOT_THRESHOLD
    val isCold: Boolean get() = totalScore < WARM_THRESHOLD
}

data class PredictionResult(
    val predictedPaths: List<PredictedPath>,
    val confidence: Float,
    val modelVersion: Int,
    val generatedAt: Long = System.currentTimeMillis(),
    val predictionType: PredictionType,
) {
    enum class PredictionType { NEXT_FOLDER, NEXT_THUMBNAIL, CACHE_WARMUP, PREFETCH_FILES }

    data class PredictedPath(
        val path: String,
        val probability: Float,
        val reason: String,
        val urgency: Int, // 0=immediate, 1=soon, 2=later
    )

    val topPrediction: PredictedPath? get() = predictedPaths.maxByOrNull { it.probability }
}

data class UserSession(
    val sessionId: String,
    val startTime: Long = System.currentTimeMillis(),
    var endTime: Long = 0L,
    val events: MutableList<UsageEvent> = mutableListOf(),
    var currentPath: String = "",
    var previousPath: String = "",
    val navigationStack: ArrayDeque<String> = ArrayDeque(20),
) {
    val duration: Long get() = if (endTime > 0) endTime - startTime else System.currentTimeMillis() - startTime
    val isActive: Boolean get() = endTime == 0L
    fun addEvent(event: UsageEvent) { events.add(event); if (events.size > 200) events.removeAt(0) }
}

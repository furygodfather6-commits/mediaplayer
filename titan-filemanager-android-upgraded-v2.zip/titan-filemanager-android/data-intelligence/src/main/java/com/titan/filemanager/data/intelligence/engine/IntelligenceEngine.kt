package com.titan.filemanager.data.intelligence.engine

import android.content.Context
import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.data.intelligence.cache.AICacheWarmer
import com.titan.filemanager.data.intelligence.cache.HotFolderDetector
import com.titan.filemanager.data.intelligence.learning.PatternRecognizer
import com.titan.filemanager.data.intelligence.learning.UsageDatabase
import com.titan.filemanager.data.intelligence.learning.UsageLearner
import com.titan.filemanager.data.intelligence.model.FolderScore
import com.titan.filemanager.data.intelligence.model.PredictionResult
import com.titan.filemanager.data.intelligence.optimization.AdaptiveOptimizer
import com.titan.filemanager.data.intelligence.prediction.FolderPredictor
import com.titan.filemanager.data.intelligence.prediction.PrefetchPredictor
import com.titan.filemanager.data.intelligence.prediction.ThumbnailPredictor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.StateFlow
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Master Intelligence Engine — single entry point for all Phase N features.
 *
 * #126 Usage learning → UsageLearner + UsageDatabase
 * #127 Predictive folder → FolderPredictor
 * #128 Predictive thumbnail → ThumbnailPredictor
 * #129 AI cache warming → AICacheWarmer
 * #130 Smart prefetch → PrefetchPredictor
 * #131 Hot-folder detection → HotFolderDetector
 * #132 Adaptive optimization → AdaptiveOptimizer
 */
@Singleton
class IntelligenceEngine @Inject constructor(context: Context) {

    private val engineScope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    val database = UsageDatabase(context)
    val usageLearner = UsageLearner(database)
    val patternRecognizer = PatternRecognizer()
    val folderPredictor = FolderPredictor(usageLearner, patternRecognizer, database)
    val thumbnailPredictor = ThumbnailPredictor(usageLearner)
    val hotFolderDetector = HotFolderDetector(usageLearner)
    val cacheWarmer = AICacheWarmer(folderPredictor, usageLearner, engineScope)
    val optimizer = AdaptiveOptimizer(usageLearner, hotFolderDetector, engineScope)
    val prefetchPredictor = PrefetchPredictor(folderPredictor, thumbnailPredictor, usageLearner, hotFolderDetector, cacheWarmer, optimizer, engineScope)

    val hotFolders: StateFlow<List<FolderScore>> = usageLearner.hotFolders

    fun initialize() {
        usageLearner.startSession()
        val profile = optimizer.computeOptimalProfile()
        optimizer.applyProfile(profile)
        optimizer.startAdaptiveOptimization()
        cacheWarmer.warmOnStartup()
        Timber.i("IntelligenceEngine initialized. Profile: ${profile.profileType}")
    }

    fun destroy() {
        usageLearner.endSession()
        cacheWarmer.clear()
        prefetchPredictor.destroy()
        database.forceSave()
    }

    fun onFolderOpen(path: String, fromPath: String? = null, itemCount: Int = 0, children: List<String> = emptyList()) {
        usageLearner.onFolderOpen(path, fromPath, itemCount)
        val sessionPaths = usageLearner.getRecentPath()
        if (sessionPaths.size >= 2) patternRecognizer.learnFromNavigation(sessionPaths, List(sessionPaths.size) { System.currentTimeMillis() })
        prefetchPredictor.onNavigationEvent(path, fromPath, children)
        prefetchPredictor.recordPrefetchHit(path)
    }

    fun onFolderClose(path: String) { usageLearner.onFolderClose(path) }

    fun onScrollChanged(items: List<FileItem>, firstVisible: Int, lastVisible: Int) {
        usageLearner.onFolderScroll(usageLearner.getRecentPath().lastOrNull() ?: "", firstVisible)
        prefetchPredictor.onScrollPositionChanged(items, firstVisible, lastVisible)
    }

    fun onFileOpen(filePath: String) { usageLearner.onFileOpen(filePath) }
    fun onDeviceIdle() { cacheWarmer.warmOnIdle() }
    fun onChargingStarted() { cacheWarmer.warmOnCharging(); optimizer.startAdaptiveOptimization() }

    fun predictNextFolders(currentPath: String, children: List<String> = emptyList()): PredictionResult {
        val session = usageLearner.getRecentPath()
        val previousPath = if (session.size >= 2) session[session.size - 2] else null
        return folderPredictor.predictNextFolders(currentPath, previousPath, session, children)
    }

    fun getFolderTemperature(path: String) = hotFolderDetector.classifyFolder(path)
    fun getOptimizationProfile() = optimizer.currentProfile

    fun getReport() = IntelligenceReport(
        hotFolderCount = usageLearner.getHotFolders().size,
        topFolders = database.getTopPaths(10),
        optimizationProfile = optimizer.currentProfile,
        prefetchStats = prefetchPredictor.getStats(),
        cacheWarmerStats = cacheWarmer.getStats(),
        patternStats = patternRecognizer.getStats(),
    )

    data class IntelligenceReport(
        val hotFolderCount: Int,
        val topFolders: List<Pair<String, Long>>,
        val optimizationProfile: AdaptiveOptimizer.OptimizationProfile,
        val prefetchStats: PrefetchPredictor.PrefetchStats,
        val cacheWarmerStats: AICacheWarmer.CacheWarmerStats,
        val patternStats: PatternRecognizer.PatternStats,
    )
}

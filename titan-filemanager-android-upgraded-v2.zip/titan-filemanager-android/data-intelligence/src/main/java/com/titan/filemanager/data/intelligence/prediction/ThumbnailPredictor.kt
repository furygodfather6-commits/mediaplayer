package com.titan.filemanager.data.intelligence.prediction

import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.data.intelligence.learning.UsageLearner
import com.titan.filemanager.data.intelligence.model.PredictionResult
import com.titan.filemanager.data.intelligence.model.PredictionResult.PredictedPath

/**
 * Thumbnail Predictor — predicts which thumbnails will be viewed next.
 *
 * Strategy: scroll direction buffer + previously viewed + top-of-list.
 *
 * Technique #128: Predictive thumbnail loading
 * Technique #72: Predictive thumbnail generation
 */
class ThumbnailPredictor(private val usageLearner: UsageLearner) {

    companion object {
        private const val VIEWPORT_BUFFER = 10
        private const val MIN_VELOCITY = 0.5f
    }

    private var lastScrollPosition = 0
    private var lastScrollTime = 0L
    private var scrollVelocity = 0f
    private var scrollDirection = 0

    fun predictThumbnails(allItems: List<FileItem>, firstVisible: Int, lastVisible: Int, currentTime: Long = System.currentTimeMillis()): PredictionResult {
        val predictions = mutableListOf<PredictedPath>()
        predictions.addAll(predictByScrollDirection(allItems, firstVisible, lastVisible))

        val imageItems = allItems.filterIndexed { i, item -> isImageOrVideo(item) && i !in firstVisible..lastVisible }
        predictions.addAll(imageItems.filter { usageLearner.getFolderScore(it.path.substringBeforeLast('/')).visitCount > 2 }
            .take(5).map { PredictedPath(it.path, 0.5f, "Previously viewed folder", 1) })

        predictions.addAll(allItems.take(VIEWPORT_BUFFER).filter { isImageOrVideo(it) }
            .mapIndexed { i, item -> PredictedPath(item.path, 1f - i * 0.08f, "Top of list", 0) })

        val unique = predictions.distinctBy { it.path }.sortedBy { it.urgency }.take(30)
        return PredictionResult(unique, unique.firstOrNull()?.probability ?: 0f, 1, predictionType = PredictionResult.PredictionType.NEXT_THUMBNAIL)
    }

    fun updateScrollPosition(newPosition: Int, currentTime: Long = System.currentTimeMillis()) {
        val timeDelta = currentTime - lastScrollTime
        if (timeDelta > 0 && lastScrollTime > 0) {
            scrollVelocity = (newPosition - lastScrollPosition).toFloat() / timeDelta * 16f
            scrollDirection = when { scrollVelocity > MIN_VELOCITY -> 1; scrollVelocity < -MIN_VELOCITY -> -1; else -> 0 }
        }
        lastScrollPosition = newPosition; lastScrollTime = currentTime
    }

    private fun predictByScrollDirection(allItems: List<FileItem>, firstVisible: Int, lastVisible: Int): List<PredictedPath> {
        val bufferSize = VIEWPORT_BUFFER + (Math.abs(scrollVelocity) * 5).toInt().coerceAtMost(50)
        return when (scrollDirection) {
            1 -> { val start = lastVisible + 1; val end = minOf(start + bufferSize, allItems.size)
                allItems.subList(start, end).filter { isImageOrVideo(it) }.mapIndexed { i, item -> PredictedPath(item.path, 0.9f - i * 0.05f, "Scroll: down", 0) } }
            -1 -> { val end = firstVisible; val start = maxOf(0, end - bufferSize)
                allItems.subList(start, end).reversed().filter { isImageOrVideo(it) }.mapIndexed { i, item -> PredictedPath(item.path, 0.9f - i * 0.05f, "Scroll: up", 0) } }
            else -> { val above = maxOf(0, firstVisible - VIEWPORT_BUFFER / 2); val below = minOf(allItems.size, lastVisible + VIEWPORT_BUFFER / 2)
                (allItems.subList(above, firstVisible) + allItems.subList(lastVisible + 1, below)).filter { isImageOrVideo(it) }.mapIndexed { i, item -> PredictedPath(item.path, 0.6f - i * 0.04f, "Viewport buffer", 1) } }
        }
    }

    private fun isImageOrVideo(item: FileItem): Boolean {
        val ext = item.extension.lowercase()
        return ext in setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "mp4", "mkv", "avi", "mov", "webm")
    }
}

package com.titan.filemanager.data.intelligence.learning

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * Persistent Usage Database — SharedPreferences-backed.
 *
 * Stores: visit counts, dwell times, navigation patterns, time patterns.
 * Production: replace with Room for large datasets.
 *
 * Technique #126: Usage learning (persistence)
 */
class UsageDatabase(context: Context) {

    companion object {
        private const val PREFS_NAME = "titan_intelligence"
        private const val KEY_FOLDER_VISITS = "folder_visits"
        private const val KEY_FOLDER_DWELL = "folder_dwell"
        private const val KEY_NAV_PATTERNS = "nav_patterns"
        private const val KEY_TIME_PATTERNS = "time_patterns"
        private const val MAX_STORED_PATHS = 500
        private const val MAX_EVENTS_PER_PATH = 100
    }

    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val visitCounts = ConcurrentHashMap<String, AtomicLong>()
    private val dwellTimes = ConcurrentHashMap<String, MutableList<Long>>()
    private val navPatterns = ConcurrentHashMap<String, MutableList<String>>()
    private val timePatterns = ConcurrentHashMap<String, MutableList<Int>>()

    @Volatile private var isDirty = false
    private val writeCount = AtomicLong(0)

    init { loadFromDisk() }

    fun recordVisit(path: String, dwellTimeMs: Long, fromPath: String?, hourOfDay: Int) {
        visitCounts.getOrPut(path) { AtomicLong(0) }.incrementAndGet()
        dwellTimes.getOrPut(path) { mutableListOf() }.let { list ->
            synchronized(list) { list.add(dwellTimeMs); if (list.size > MAX_EVENTS_PER_PATH) list.removeAt(0) }
        }
        fromPath?.let { from ->
            navPatterns.getOrPut(from) { mutableListOf() }.let { list ->
                synchronized(list) { list.add(path); if (list.size > MAX_EVENTS_PER_PATH) list.removeAt(0) }
            }
        }
        timePatterns.getOrPut(path) { mutableListOf() }.let { list ->
            synchronized(list) { list.add(hourOfDay); if (list.size > MAX_EVENTS_PER_PATH) list.removeAt(0) }
        }
        isDirty = true; writeCount.incrementAndGet()
        if (writeCount.get() % 20 == 0L) saveToDiskAsync()
    }

    fun getVisitCount(path: String): Long = visitCounts[path]?.get() ?: 0L

    fun getAvgDwellMs(path: String): Long =
        dwellTimes[path]?.let { synchronized(it) { if (it.isEmpty()) 0L else it.average().toLong() } } ?: 0L

    fun getNextPathProbabilities(fromPath: String): Map<String, Float> {
        val navigations = navPatterns[fromPath] ?: return emptyMap()
        return synchronized(navigations) {
            if (navigations.isEmpty()) emptyMap()
            else {
                val counts = navigations.groupingBy { it }.eachCount()
                val total = counts.values.sum().toFloat()
                counts.mapValues { (_, count) -> count / total }.toList()
                    .sortedByDescending { it.second }.take(10).toMap()
            }
        }
    }

    fun getTimePatternScore(path: String, currentHour: Int): Float {
        val hours = timePatterns[path] ?: return 0f
        return synchronized(hours) {
            if (hours.isEmpty()) 0f
            else hours.count { Math.abs(it - currentHour) <= 2 }.toFloat() / hours.size
        }
    }

    fun getAllPaths(): List<String> =
        visitCounts.entries.sortedByDescending { it.value.get() }.map { it.key }.take(MAX_STORED_PATHS)

    fun getTopPaths(n: Int = 20): List<Pair<String, Long>> =
        visitCounts.entries.sortedByDescending { it.value.get() }.take(n).map { Pair(it.key, it.value.get()) }

    private fun loadFromDisk() {
        try {
            prefs.getString(KEY_FOLDER_VISITS, null)?.let { json ->
                JSONObject(json).keys().forEach { key -> visitCounts[key] = AtomicLong(JSONObject(json).getLong(key)) }
            }
            prefs.getString(KEY_FOLDER_DWELL, null)?.let { json ->
                val obj = JSONObject(json); obj.keys().forEach { key ->
                    val arr = obj.getJSONArray(key); dwellTimes[key] = (0 until arr.length()).map { arr.getLong(it) }.toMutableList()
                }
            }
            prefs.getString(KEY_NAV_PATTERNS, null)?.let { json ->
                val obj = JSONObject(json); obj.keys().forEach { key ->
                    val arr = obj.getJSONArray(key); navPatterns[key] = (0 until arr.length()).map { arr.getString(it) }.toMutableList()
                }
            }
            prefs.getString(KEY_TIME_PATTERNS, null)?.let { json ->
                val obj = JSONObject(json); obj.keys().forEach { key ->
                    val arr = obj.getJSONArray(key); timePatterns[key] = (0 until arr.length()).map { arr.getInt(it) }.toMutableList()
                }
            }
        } catch (_: Exception) { clearAll() }
    }

    private fun saveToDiskAsync() {
        if (!isDirty) return
        Thread {
            try {
                val editor = prefs.edit()
                val visitsObj = JSONObject()
                visitCounts.entries.sortedByDescending { it.value.get() }.take(MAX_STORED_PATHS)
                    .forEach { (path, count) -> visitsObj.put(path, count.get()) }
                editor.putString(KEY_FOLDER_VISITS, visitsObj.toString())

                val dwellObj = JSONObject()
                dwellTimes.entries.take(MAX_STORED_PATHS).forEach { (path, times) ->
                    val arr = JSONArray(); synchronized(times) { times.takeLast(20).forEach { arr.put(it) } }
                    dwellObj.put(path, arr)
                }
                editor.putString(KEY_FOLDER_DWELL, dwellObj.toString())

                val navObj = JSONObject()
                navPatterns.entries.take(MAX_STORED_PATHS).forEach { (path, dests) ->
                    val arr = JSONArray(); synchronized(dests) { dests.takeLast(50).forEach { arr.put(it) } }
                    navObj.put(path, arr)
                }
                editor.putString(KEY_NAV_PATTERNS, navObj.toString())

                val timeObj = JSONObject()
                timePatterns.entries.take(MAX_STORED_PATHS).forEach { (path, hours) ->
                    val arr = JSONArray(); synchronized(hours) { hours.takeLast(50).forEach { arr.put(it) } }
                    timeObj.put(path, arr)
                }
                editor.putString(KEY_TIME_PATTERNS, timeObj.toString())
                editor.apply(); isDirty = false
            } catch (_: Exception) {}
        }.start()
    }

    fun forceSave() { isDirty = true; saveToDiskAsync() }
    fun clearAll() { visitCounts.clear(); dwellTimes.clear(); navPatterns.clear(); timePatterns.clear(); prefs.edit().clear().apply() }
}

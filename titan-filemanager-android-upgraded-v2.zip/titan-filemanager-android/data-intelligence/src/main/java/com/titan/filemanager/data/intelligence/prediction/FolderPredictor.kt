package com.titan.filemanager.data.intelligence.prediction

import com.titan.filemanager.data.intelligence.learning.PatternRecognizer
import com.titan.filemanager.data.intelligence.learning.UsageDatabase
import com.titan.filemanager.data.intelligence.learning.UsageLearner
import com.titan.filemanager.data.intelligence.model.FolderScore
import com.titan.filemanager.data.intelligence.model.PredictionResult
import com.titan.filemanager.data.intelligence.model.PredictionResult.PredictedPath
import java.util.Calendar

/**
 * Folder Predictor — predicts next folders using multi-signal approach.
 *
 * Signals: Navigation pattern (40%) + Time-of-day (20%) + Folder score (20%) + Hierarchy (15%) + Recency (5%)
 *
 * Technique #127: Predictive folder loading
 * Technique #130: Smart prefetch
 */
class FolderPredictor(
    private val usageLearner: UsageLearner,
    private val patternRecognizer: PatternRecognizer,
    private val database: UsageDatabase,
) {
    companion object {
        private const val MIN_CONFIDENCE = 0.15f
        private const val MAX_PREDICTIONS = 8
        private const val W_NAV = 0.40f
        private const val W_TIME = 0.20f
        private const val W_SCORE = 0.20f
        private const val W_HIERARCHY = 0.15f
        private const val W_RECENCY = 0.05f
    }

    fun predictNextFolders(
        currentPath: String,
        previousPath: String? = null,
        sessionPaths: List<String> = emptyList(),
        currentChildren: List<String> = emptyList(),
    ): PredictionResult {
        val predictions = mutableMapOf<String, Float>()
        val currentHour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)

        // Signal 1: Navigation pattern (N-gram)
        patternRecognizer.predictNextBigram(currentPath, previousPath).forEach { (path, prob) ->
            predictions[path] = (predictions[path] ?: 0f) + prob * W_NAV
        }

        // Signal 2: Time-of-day
        patternRecognizer.getTimeBasedPredictions(currentHour, 5).forEach { (path, prob) ->
            if (path != currentPath) predictions[path] = (predictions[path] ?: 0f) + prob * W_TIME
        }

        // Signal 3: Hot folder scores
        usageLearner.getHotFolders(10).forEach { score ->
            if (score.path != currentPath) predictions[score.path] = (predictions[score.path] ?: 0f) + score.totalScore * W_SCORE
        }

        // Signal 4: Hierarchy (children + parent)
        currentChildren.take(10).forEachIndexed { index, child ->
            val childPath = if (currentPath.endsWith('/')) "$currentPath$child" else "$currentPath/$child"
            predictions[childPath] = (predictions[childPath] ?: 0f) + (1f - index * 0.08f).coerceAtLeast(0.1f) * W_HIERARCHY
        }
        val parentPath = currentPath.substringBeforeLast('/')
        if (parentPath.isNotEmpty() && parentPath != currentPath)
            predictions[parentPath] = (predictions[parentPath] ?: 0f) + 0.25f * W_HIERARCHY

        // Signal 5: Sibling paths
        database.getNextPathProbabilities(parentPath).forEach { (path, prob) ->
            if (path != currentPath) predictions[path] = (predictions[path] ?: 0f) + prob * W_RECENCY
        }

        val ranked = predictions.entries.filter { it.value >= MIN_CONFIDENCE }
            .sortedByDescending { it.value }.take(MAX_PREDICTIONS)
            .mapIndexed { _, (path, confidence) ->
                val score = usageLearner.getFolderScore(path)
                PredictedPath(path, confidence.coerceIn(0f, 1f), buildReason(path, confidence, score), when { confidence > 0.7f -> 0; confidence > 0.4f -> 1; else -> 2 })
            }

        return PredictionResult(ranked, ranked.firstOrNull()?.probability ?: 0f, 2, predictionType = PredictionResult.PredictionType.NEXT_FOLDER)
    }

    fun predictForCurrentContext(): PredictionResult {
        val currentHour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val predictions = mutableMapOf<String, Float>()
        patternRecognizer.getTimeBasedPredictions(currentHour, 10).forEach { (path, prob) -> predictions[path] = prob * 0.5f }
        usageLearner.getHotFolders(10).forEach { score ->
            val timeFactor = if (score.predictedNextVisit > 0)
                (1f - Math.abs(System.currentTimeMillis() - score.predictedNextVisit) / (60 * 60 * 1000f)).coerceAtLeast(0f) else 0f
            predictions[score.path] = (predictions[score.path] ?: 0f) + score.totalScore * 0.3f + timeFactor * 0.2f
        }
        val ranked = predictions.entries.sortedByDescending { it.value }.take(MAX_PREDICTIONS)
            .map { (path, prob) -> PredictedPath(path, prob.coerceIn(0f, 1f), "Context-based (hour=$currentHour)", if (prob > 0.5f) 0 else 1) }
        return PredictionResult(ranked, ranked.firstOrNull()?.probability ?: 0f, 2, predictionType = PredictionResult.PredictionType.NEXT_FOLDER)
    }

    private fun buildReason(path: String, confidence: Float, score: FolderScore): String = when {
        score.isHot -> "Hot folder (${score.visitCount} visits)"
        score.visitCount > 0 -> "Previously visited (${score.visitCount}x)"
        else -> "Nearby folder"
    }
}

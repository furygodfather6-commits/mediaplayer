package com.titan.filemanager.data.intelligence.optimization

import com.titan.filemanager.data.intelligence.cache.HotFolderDetector
import com.titan.filemanager.data.intelligence.learning.UsageLearner
import kotlinx.coroutines.*
import timber.log.Timber

/**
 * Adaptive Optimizer — dynamically adjusts system behavior based on usage.
 *
 * Adjusts: thread pool sizes, cache sizes, batch sizes, prefetch aggressiveness, thumbnail quality.
 *
 * Technique #132: Adaptive optimization
 * Technique #141: Automatic tuning
 * Technique #31: Adaptive thread count
 */
class AdaptiveOptimizer(
    private val usageLearner: UsageLearner,
    private val hotFolderDetector: HotFolderDetector,
    private val scope: CoroutineScope,
) {
    companion object {
        private const val TAG = "AdaptiveOptimizer"
        private const val OPTIMIZATION_INTERVAL_MS = 5 * 60 * 1000L
    }

    @Volatile
    var currentProfile: OptimizationProfile = OptimizationProfile.DEFAULT
        private set

    fun computeOptimalProfile(): OptimizationProfile {
        val hotFolders = usageLearner.getHotFolders(20)
        val avgVisits = if (hotFolders.isNotEmpty()) hotFolders.map { it.visitCount }.average().toFloat() else 0f
        val totalHot = hotFolders.count { it.isHot }
        val hasPredictablePattern = hotFolders.any { it.timePatternScore > 0.6f }
        val isHeavyUser = avgVisits > 10 && totalHot > 5
        val isPhotoUser = hotFolders.any { it.path.lowercase().let { p -> p.contains("dcim") || p.contains("photo") || p.contains("camera") || p.contains("picture") } }

        val optimalThreadCount = when { isHeavyUser -> 8; totalHot > 3 -> 6; else -> 4 }
        val optimalCacheSize = when { totalHot > 10 -> 200; totalHot > 5 -> 100; else -> 50 }
        val optimalBatchSize = when { isHeavyUser -> 500; totalHot > 5 -> 300; else -> 200 }
        val prefetchDepth = when { hasPredictablePattern && isHeavyUser -> 3; hasPredictablePattern -> 2; else -> 1 }
        val thumbnailSize = if (isPhotoUser) 128 else 96
        val mediumThreshold = if (isHeavyUser) 2000 else 1000

        val profile = OptimizationProfile(
            scanThreadCount = optimalThreadCount,
            thumbnailThreadCount = if (isPhotoUser) 6 else 4,
            directoryCacheSize = optimalCacheSize,
            statBatchSize = optimalBatchSize,
            prefetchDepth = prefetchDepth,
            thumbnailSize = thumbnailSize,
            mediumFolderThreshold = mediumThreshold,
            enableAggressivePrefetch = hasPredictablePattern,
            enableThumbnailPreload = isPhotoUser,
            cacheAllocation = hotFolderDetector.getCacheAllocation(optimalCacheSize),
            profileType = when {
                isPhotoUser && isHeavyUser -> ProfileType.POWER_PHOTO_USER
                isHeavyUser -> ProfileType.POWER_USER
                isPhotoUser -> ProfileType.PHOTO_USER
                else -> ProfileType.DEFAULT_USER
            },
        )
        Timber.d("Optimal profile: ${profile.profileType} threads=${profile.scanThreadCount} cache=${profile.directoryCacheSize}")
        return profile
    }

    fun applyProfile(profile: OptimizationProfile) { currentProfile = profile }

    fun startAdaptiveOptimization() {
        scope.launch {
            while (isActive) {
                delay(OPTIMIZATION_INTERVAL_MS)
                val newProfile = computeOptimalProfile()
                if (newProfile != currentProfile) { applyProfile(newProfile); Timber.d("Profile updated: ${newProfile.profileType}") }
            }
        }
    }

    data class OptimizationProfile(
        val scanThreadCount: Int = 4,
        val thumbnailThreadCount: Int = 4,
        val directoryCacheSize: Int = 100,
        val statBatchSize: Int = 200,
        val prefetchDepth: Int = 1,
        val thumbnailSize: Int = 96,
        val mediumFolderThreshold: Int = 1000,
        val enableAggressivePrefetch: Boolean = false,
        val enableThumbnailPreload: Boolean = false,
        val cacheAllocation: Map<String, Int> = emptyMap(),
        val profileType: ProfileType = ProfileType.DEFAULT_USER,
    ) { companion object { val DEFAULT = OptimizationProfile() } }

    enum class ProfileType { DEFAULT_USER, POWER_USER, PHOTO_USER, POWER_PHOTO_USER }
}

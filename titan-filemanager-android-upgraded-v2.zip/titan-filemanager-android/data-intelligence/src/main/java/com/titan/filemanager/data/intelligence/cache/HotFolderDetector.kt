package com.titan.filemanager.data.intelligence.cache

import com.titan.filemanager.data.intelligence.learning.UsageLearner
import com.titan.filemanager.data.intelligence.model.FolderScore
import kotlinx.coroutines.flow.StateFlow

/**
 * Hot Folder Detector — identifies folders that are frequently/recently visited.
 *
 * Hot folders get: L1 cache, pre-warm on start, FileObserver monitoring, proactive scan.
 *
 * Technique #131: Hot-folder detection
 * Technique #50: Hot-directory cache
 */
class HotFolderDetector(private val usageLearner: UsageLearner) {

    val hotFolders: StateFlow<List<FolderScore>> = usageLearner.hotFolders

    fun classifyFolder(path: String): FolderTemperature {
        val score = usageLearner.getFolderScore(path)
        return when {
            score.totalScore >= FolderScore.HOT_THRESHOLD -> FolderTemperature.HOT
            score.totalScore >= FolderScore.WARM_THRESHOLD -> FolderTemperature.WARM
            score.visitCount > 0 -> FolderTemperature.COOL
            else -> FolderTemperature.COLD
        }
    }

    fun getFoldersToMonitor(): List<String> =
        usageLearner.getHotFolders(20).filter { it.isHot || it.isWarm }.map { it.path }

    fun getFoldersToPrescan(): List<String> =
        usageLearner.getHotFolders(10).sortedByDescending { it.totalScore }.map { it.path }

    fun getCacheAllocation(totalCacheEntries: Int): Map<String, Int> {
        val hotFoldersList = usageLearner.getHotFolders(10)
        if (hotFoldersList.isEmpty()) return emptyMap()
        val totalScore = hotFoldersList.sumOf { it.totalScore.toDouble() }.toFloat()
        val hotBudget = (totalCacheEntries * 0.5f).toInt()
        return hotFoldersList.associate { score ->
            val share = if (totalScore > 0) score.totalScore / totalScore else 0f
            score.path to (hotBudget * share).toInt().coerceAtLeast(1)
        }
    }

    fun detectHotFolderAnomaly(path: String): Boolean {
        val score = usageLearner.getFolderScore(path)
        return score.recencyScore > 0.8f && score.frequencyScore < 0.3f && score.visitCount > 3
    }

    enum class FolderTemperature { HOT, WARM, COOL, COLD }
}

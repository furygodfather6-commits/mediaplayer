package com.titan.filemanager.data.intelligence.cache

import com.titan.filemanager.data.intelligence.learning.UsageLearner
import com.titan.filemanager.data.intelligence.model.PredictionResult
import com.titan.filemanager.data.intelligence.prediction.FolderPredictor
import kotlinx.coroutines.*
import timber.log.Timber
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * AI-Based Cache Warmer — pre-loads data into cache BEFORE user requests it.
 *
 * Strategy: startup warming + post-navigation warming + idle warming + charging warming.
 *
 * Technique #129: AI-based cache warming
 * Technique #49: Cache warming
 */
class AICacheWarmer(
    private val folderPredictor: FolderPredictor,
    private val usageLearner: UsageLearner,
    private val scope: CoroutineScope,
) {
    companion object {
        private const val WARM_DELAY_MS = 500L
        private const val IDLE_WARM_DELAY_MS = 2000L
        private const val MAX_WARM_CONCURRENT = 3
    }

    private val warmedPaths = ConcurrentHashMap<String, Long>()
    private val warmingJobs = ConcurrentHashMap<String, Job>()
    private val warmingCount = AtomicLong(0)
    private val warmingHits = AtomicLong(0)

    var onWarmPath: (suspend (String) -> Unit)? = null

    fun warmOnStartup() {
        scope.launch(Dispatchers.IO) {
            delay(WARM_DELAY_MS)
            val prediction = folderPredictor.predictForCurrentContext()
            Timber.d("Startup warming: ${prediction.predictedPaths.size} paths")
            warmPredictions(prediction, WarmPriority.LOW)
        }
    }

    fun warmAfterFolderOpen(currentPath: String, previousPath: String?, children: List<String>) {
        warmingJobs["context"]?.cancel()
        warmingJobs["context"] = scope.launch(Dispatchers.IO) {
            delay(WARM_DELAY_MS)
            val prediction = folderPredictor.predictNextFolders(currentPath, previousPath, currentChildren = children)
            Timber.d("Post-nav warming: ${prediction.predictedPaths.size} paths conf=${prediction.confidence}")
            warmPredictions(prediction, WarmPriority.HIGH)
        }
    }

    fun warmOnIdle() {
        scope.launch(Dispatchers.IO) {
            delay(IDLE_WARM_DELAY_MS)
            val hotFolders = usageLearner.getHotFolders(10)
            Timber.d("Idle warming: ${hotFolders.size} hot folders")
            hotFolders.filter { !isRecentlyWarmed(it.path) }.take(MAX_WARM_CONCURRENT).forEach { warmPath(it.path) }
        }
    }

    fun warmOnCharging() {
        scope.launch(Dispatchers.IO) {
            Timber.d("Charging: aggressive cache warming")
            usageLearner.getHotFolders(30).filter { !isRecentlyWarmed(it.path) }.forEach { warmPath(it.path); delay(100) }
        }
    }

    private suspend fun warmPredictions(prediction: PredictionResult, priority: WarmPriority) {
        val toWarm = prediction.predictedPaths.filter { it.probability > 0.2f && !isRecentlyWarmed(it.path) }
            .sortedBy { it.urgency }.take(when (priority) { WarmPriority.HIGH -> 5; WarmPriority.NORMAL -> 3; WarmPriority.LOW -> 2 })
        val semaphore = kotlinx.coroutines.sync.Semaphore(MAX_WARM_CONCURRENT)
        toWarm.map { predicted -> scope.async(Dispatchers.IO) { semaphore.acquire(); try { warmPath(predicted.path) } finally { semaphore.release() } } }.awaitAll()
    }

    private suspend fun warmPath(path: String) {
        if (isRecentlyWarmed(path)) return
        try { onWarmPath?.invoke(path); warmedPaths[path] = System.currentTimeMillis(); warmingCount.incrementAndGet() } catch (_: Exception) {}
    }

    fun recordWarmingHit(path: String) { if (warmedPaths.containsKey(path)) warmingHits.incrementAndGet() }

    private fun isRecentlyWarmed(path: String): Boolean = warmedPaths[path]?.let { System.currentTimeMillis() - it < 60_000L } ?: false

    fun getStats() = CacheWarmerStats(warmingCount.get(), warmedPaths.size, warmingHits.get(),
        if (warmingCount.get() > 0) warmingHits.get().toFloat() / warmingCount.get() else 0f)

    fun clear() { warmingJobs.values.forEach { it.cancel() }; warmingJobs.clear(); warmedPaths.clear() }

    enum class WarmPriority { HIGH, NORMAL, LOW }
    data class CacheWarmerStats(val totalWarmings: Long, val warmedPaths: Int, val warmingHits: Long, val hitRate: Float)
}

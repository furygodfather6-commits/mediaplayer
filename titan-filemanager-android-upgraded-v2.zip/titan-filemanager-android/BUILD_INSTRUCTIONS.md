# Build Instructions — Titan File Manager

## ⚠️ IMPORTANT: Generate Gradle Wrapper First

The `gradle-wrapper.jar` is a binary file that **cannot be created via text tools**. You MUST generate it before building:

```bash
cd titan-filemanager-android

# Option A: If you have Gradle installed globally
gradle wrapper --gradle-version 8.10.2

# Option B: If you have Android Studio
# Open the project in Android Studio → it will auto-generate the wrapper

# Option C: Download manually
# Download gradle-wrapper.jar from:
# https://raw.githubusercontent.com/gradle/gradle/v8.10.2/gradle/wrapper/gradle-wrapper.jar
# Place it at: gradle/wrapper/gradle-wrapper.jar
```

## Prerequisites

- **JDK 21** (OpenJDK recommended)
- **Android SDK** with:
  - Platform 35 (Android 15)
  - Build-tools 35.0.0
  - NDK r27 (for native C++ modules)
  - CMake 3.22.1
- **Android Studio Ladybug** (2024.2) or newer (recommended)

## Build Steps

```bash
# 1. Set SDK path
echo "sdk.dir=/path/to/Android/Sdk" > local.properties

# 2. Generate Gradle wrapper (ONE TIME ONLY — see above)

# 3. Build debug APK
./gradlew :app:assembleDebug

# 4. Install on device
./gradlew :app:installDebug

# 5. Build companion apps
./gradlew :app:wear:assembleDebug
./gradlew :app:automotive:assembleDebug

# 6. Run tests
./gradlew test
```

## Troubleshooting

### "gradle-wrapper.jar not found"
→ Run `gradle wrapper --gradle-version 8.10.2` first

### "SDK location not found"
→ Create `local.properties` with `sdk.dir=/path/to/Android/Sdk`

### "NDK not configured"
→ Install NDK r27 via Android Studio SDK Manager
→ Or set `ndk.dir` in `local.properties`

### "CMake not found"
→ Install CMake 3.22.1 via Android Studio SDK Manager

### Build fails on native modules
→ Ensure NDK + CMake are installed
→ Check `ANDROID_ABI` filters: `arm64-v8a` + `x86_64`

## Project Structure

```
titan-filemanager-android/
├── app/                    ← Main app
├── app-wear/               ← Wear OS companion
├── app-automotive/         ← Automotive companion
├── core-* (11 modules)     ← Foundation
├── domain/                 ← Use cases (75+)
├── data-* (15 modules)     ← Data layer
├── feature-* (12 modules)  ← UI layer
├── native-* (4 modules)    ← C++ libraries
├── sdk/                    ← Public SDK
├── build-logic/            ← Convention plugins
├── gradle/
│   ├── libs.versions.toml  ← Version catalog
│   └── wrapper/
│       ├── gradle-wrapper.properties
│       └── gradle-wrapper.jar  ← YOU NEED TO GENERATE THIS
├── gradlew                 ← Unix wrapper script
├── gradlew.bat             ← Windows wrapper script
├── settings.gradle.kts
├── build.gradle.kts
└── gradle.properties
```

## Stats

- **48 Gradle modules**
- **~21,200 LOC** (Kotlin + C++)
- **4 native .so libraries**
- **6 cloud providers**
- **75+ use cases**
- **13 real screens**
- **11 test files (~90 test cases)**

package com.titan.filemanager.data.database.advanced.dao

import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import com.titan.filemanager.data.database.advanced.optimization.BatchTransactionManager
import com.titan.filemanager.data.database.advanced.optimization.DatabaseOperation
import com.titan.filemanager.data.database.advanced.optimization.PreparedStatementCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * File Data Access Object.
 *
 * Ported techniques:
 *   #88 Prepared statements
 *   #89 Batch transactions
 *
 * All file CRUD operations including batch upserts and stale-entry cleanup.
 */
class FileDao(
    private val db: SQLiteDatabase,
    private val stmtCache: PreparedStatementCache,
    private val batchManager: BatchTransactionManager,
) {

    companion object {
        private const val SQL_GET_FILES_IN_DIR = """
            SELECT f.id, f.name, f.size, f.last_modified,
                   f.is_hidden, f.is_symlink, f.inode,
                   e.extension, m.mime_type
            FROM files f
            LEFT JOIN extensions e ON f.extension_id = e.extension
            LEFT JOIN mime_types m ON e.mime_id = m.id
            WHERE f.directory_id = ?
            ORDER BY f.name COLLATE NOCASE ASC
        """

        private const val SQL_UPSERT_FILE = """
            INSERT OR REPLACE INTO files
            (id, directory_id, name, size, last_modified,
             is_hidden, is_symlink, inode)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """

        private const val SQL_DELETE_FILE = "DELETE FROM files WHERE id = ?"
        private const val SQL_DELETE_FILES_IN_DIR = "DELETE FROM files WHERE directory_id = ?"

        private const val SQL_SEARCH_FILES = """
            SELECT f.id, f.name, f.size, f.last_modified,
                   d.path || '/' || f.name AS full_path
            FROM files f
            JOIN directories d ON f.directory_id = d.id
            WHERE f.name LIKE ? COLLATE NOCASE
            ORDER BY f.last_modified DESC
            LIMIT ?
        """
    }

    /** Get all files in directory — optimized query. */
    suspend fun getFilesInDirectory(directoryId: Long): List<FileRecord> =
        withContext(Dispatchers.IO) {
            val results = ArrayList<FileRecord>(100)

            db.rawQuery(SQL_GET_FILES_IN_DIR, arrayOf(directoryId.toString()))
                .use { cursor ->
                    while (cursor.moveToNext()) {
                        results.add(cursorToFileRecord(cursor))
                    }
                }
            results
        }

    /** Upsert single file. */
    suspend fun upsertFile(file: FileRecord): Long = withContext(Dispatchers.IO) {
        stmtCache.executeInsert(
            SQL_UPSERT_FILE,
            arrayOf(
                file.id, file.directoryId, file.name,
                file.size, file.lastModified,
                if (file.isHidden) 1 else 0,
                if (file.isSymlink) 1 else 0,
                file.inode,
            ),
        )
    }

    /** Batch upsert files — single transaction (Technique #89). */
    suspend fun upsertFilesBatch(files: List<FileRecord>) = withContext(Dispatchers.IO) {
        val ops = files.map { file ->
            DatabaseOperation.Upsert(
                sql = SQL_UPSERT_FILE,
                args = arrayOf(
                    file.id, file.directoryId, file.name,
                    file.size, file.lastModified,
                    if (file.isHidden) 1 else 0,
                    if (file.isSymlink) 1 else 0,
                    file.inode,
                ),
            )
        }
        batchManager.executeImmediate(ops)
    }

    /** Delete files not in current scan (cleanup stale entries). */
    suspend fun deleteStaleFiles(directoryId: Long, currentInodes: Set<Long>): Int =
        withContext(Dispatchers.IO) {
            if (currentInodes.isEmpty()) return@withContext 0
            val placeholders = currentInodes.joinToString(",") { "?" }
            db.delete(
                "files",
                "directory_id = ? AND inode NOT IN ($placeholders)",
                (listOf(directoryId) + currentInodes).map { it.toString() }.toTypedArray(),
            )
        }

    /** Search files by name prefix. */
    suspend fun searchByName(namePrefix: String, maxResults: Int = 200): List<SearchRecord> =
        withContext(Dispatchers.IO) {
            val results = ArrayList<SearchRecord>(maxResults)
            val pattern = "$namePrefix%"
            db.rawQuery(SQL_SEARCH_FILES, arrayOf(pattern, maxResults.toString())).use { cursor ->
                while (cursor.moveToNext()) {
                    results.add(
                        SearchRecord(
                            id = cursor.getLong(0),
                            name = cursor.getString(1),
                            size = cursor.getLong(2),
                            lastModified = cursor.getLong(3),
                            fullPath = cursor.getString(4),
                        ),
                    )
                }
            }
            results
        }

    /** Get large files for cleanup suggestions. */
    suspend fun getLargeFiles(
        minSizeBytes: Long = 100 * 1024 * 1024L,
        maxResults: Int = 50,
    ): List<FileRecord> = withContext(Dispatchers.IO) {
        val results = ArrayList<FileRecord>(maxResults)
        db.rawQuery(
            """SELECT f.id, f.name, f.size, f.last_modified,
               f.is_hidden, f.is_symlink, f.inode, f.directory_id
               FROM files f
               WHERE f.size >= ?
               ORDER BY f.size DESC
               LIMIT ?""",
            arrayOf(minSizeBytes.toString(), maxResults.toString()),
        ).use { cursor ->
            while (cursor.moveToNext()) {
                results.add(cursorToFileRecord(cursor))
            }
        }
        results
    }

    /** Get recently modified files. */
    suspend fun getRecentFiles(sinceMs: Long, maxResults: Int = 100): List<FileRecord> =
        withContext(Dispatchers.IO) {
            val results = ArrayList<FileRecord>(maxResults)
            db.rawQuery(
                """SELECT f.id, f.name, f.size, f.last_modified,
                   f.is_hidden, f.is_symlink, f.inode, f.directory_id
                   FROM files f
                   WHERE f.last_modified >= ?
                   ORDER BY f.last_modified DESC
                   LIMIT ?""",
                arrayOf(sinceMs.toString(), maxResults.toString()),
            ).use { cursor ->
                while (cursor.moveToNext()) {
                    results.add(cursorToFileRecord(cursor))
                }
            }
            results
        }

    private fun cursorToFileRecord(cursor: Cursor): FileRecord = FileRecord(
        id = cursor.getLong(0),
        name = cursor.getString(1),
        size = cursor.getLong(2),
        lastModified = cursor.getLong(3),
        isHidden = cursor.getInt(4) == 1,
        isSymlink = cursor.getInt(5) == 1,
        inode = cursor.getLong(6),
        directoryId = if (cursor.columnCount > 7) cursor.getLong(7) else 0L,
        extension = if (cursor.columnCount > 7) cursor.getString(7) ?: "" else "",
        mimeType = if (cursor.columnCount > 8) cursor.getString(8) else null,
    )

    data class FileRecord(
        val id: Long,
        val name: String,
        val size: Long,
        val lastModified: Long,
        val isHidden: Boolean,
        val isSymlink: Boolean,
        val inode: Long,
        val directoryId: Long,
        val extension: String = "",
        val mimeType: String? = null,
    )

    data class SearchRecord(
        val id: Long,
        val name: String,
        val size: Long,
        val lastModified: Long,
        val fullPath: String,
    )
}

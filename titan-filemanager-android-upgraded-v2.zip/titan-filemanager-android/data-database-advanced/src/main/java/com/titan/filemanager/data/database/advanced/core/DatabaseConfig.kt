package com.titan.filemanager.data.database.advanced.core

/**
 * Database Configuration.
 *
 * Ported technique: #86 SQLite optimization
 *
 * All SQLite PRAGMA settings for maximum performance — applied on every
 * database open.
 */
object DatabaseConfig {

    const val DATABASE_NAME = "filemanager_advanced.db"
    const val DATABASE_VERSION = 1

    /**
     * PRAGMA settings for maximum performance.
     * Applied on every database open.
     */
    val PERFORMANCE_PRAGMAS = listOf(
        // WAL mode: concurrent reads + writes (Technique #87)
        "PRAGMA journal_mode = WAL",
        // NORMAL sync: balance safety/speed
        "PRAGMA synchronous = NORMAL",
        // 64MB page cache in memory (negative = kilobytes)
        "PRAGMA cache_size = -65536",
        // Store temp tables in memory
        "PRAGMA temp_store = MEMORY",
        // 512MB memory-mapped I/O (Technique #90)
        "PRAGMA mmap_size = 536870912",
        // 4KB page size (matches filesystem block size)
        "PRAGMA page_size = 4096",
        // Enable foreign keys
        "PRAGMA foreign_keys = ON",
        // Incremental auto-vacuum
        "PRAGMA auto_vacuum = INCREMENTAL",
        // WAL checkpoint on close
        "PRAGMA wal_autocheckpoint = 1000",
        // Lookaside memory allocator threads
        "PRAGMA threads = 4",
    )

    /** Even faster PRAGMAs for read-only access. */
    val READ_ONLY_PRAGMAS = listOf(
        "PRAGMA journal_mode = WAL",
        "PRAGMA synchronous = OFF",
        "PRAGMA cache_size = -32768",
        "PRAGMA temp_store = MEMORY",
        "PRAGMA mmap_size = 536870912",
        "PRAGMA query_only = ON",
    )

    /** Maintenance PRAGMAs — run during idle/charging. */
    val MAINTENANCE_PRAGMAS = listOf(
        "PRAGMA incremental_vacuum(200)",
        "PRAGMA wal_checkpoint(TRUNCATE)",
        "PRAGMA optimize",
    )

    const val READ_CONNECTION_COUNT = 4
    const val WRITE_CONNECTION_COUNT = 1  // SQLite = 1 writer

    const val INSERT_BATCH_SIZE = 500
    const val UPDATE_BATCH_SIZE = 200
    const val DELETE_BATCH_SIZE = 1000

    const val STATEMENT_CACHE_SIZE = 50
    const val QUERY_RESULT_CACHE_SIZE = 100
}

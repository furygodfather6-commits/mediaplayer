package com.titan.filemanager.data.database.advanced.sync

import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicLong

/**
 * Sync Journal.
 *
 * Tracks sync history for:
 *  1. Resume after crash
 *  2. Sync analytics
 *  3. Debugging
 *
 * In-memory bounded journal (max 100 entries).
 */
class SyncJournal {

    private val journal = ConcurrentLinkedQueue<SyncEntry>()
    private val MAX_ENTRIES = 100

    private val totalSynced = AtomicLong(0L)
    private val totalDurationMs = AtomicLong(0L)

    fun recordSync(operationCount: Int, durationMs: Long) {
        totalSynced.addAndGet(operationCount.toLong())
        totalDurationMs.addAndGet(durationMs)

        journal.offer(
            SyncEntry(
                timestamp = System.currentTimeMillis(),
                operationCount = operationCount,
                durationMs = durationMs,
            ),
        )

        while (journal.size > MAX_ENTRIES) {
            journal.poll()
        }
    }

    fun getLastSyncTime(): Long = journal.lastOrNull()?.timestamp ?: 0L

    fun getAverageSyncTime(): Long {
        val count = journal.size
        return if (count > 0) totalDurationMs.get() / count else 0L
    }

    fun getStats(): JournalStats = JournalStats(
        totalSynced = totalSynced.get(),
        totalSyncs = journal.size.toLong(),
        avgDurationMs = getAverageSyncTime(),
        lastSyncTime = getLastSyncTime(),
    )

    data class SyncEntry(
        val timestamp: Long,
        val operationCount: Int,
        val durationMs: Long,
    )

    data class JournalStats(
        val totalSynced: Long,
        val totalSyncs: Long,
        val avgDurationMs: Long,
        val lastSyncTime: Long,
    )
}

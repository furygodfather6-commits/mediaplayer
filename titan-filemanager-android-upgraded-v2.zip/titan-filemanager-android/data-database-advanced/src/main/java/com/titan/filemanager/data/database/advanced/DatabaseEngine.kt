package com.titan.filemanager.data.database.advanced

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log
import com.titan.filemanager.data.database.advanced.core.DatabaseConfig
import com.titan.filemanager.data.database.advanced.core.DatabaseHealthMonitor
import com.titan.filemanager.data.database.advanced.dao.FileDao
import com.titan.filemanager.data.database.advanced.normalization.SchemaDesign
import com.titan.filemanager.data.database.advanced.optimization.BatchTransactionManager
import com.titan.filemanager.data.database.advanced.optimization.MemoryMappedDb
import com.titan.filemanager.data.database.advanced.optimization.PreparedStatementCache
import com.titan.filemanager.data.database.advanced.optimization.WalModeManager
import com.titan.filemanager.data.database.advanced.sync.IncrementalSyncEngine
import com.titan.filemanager.data.database.advanced.sync.SyncJournal
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Master Database Engine.
 *
 * Ported techniques #86-#92 — all database techniques.
 *
 * Single entry point for all database operations. Wires up WAL, prepared
 * statement cache, batch transactions, mmap, sync engine, health monitor.
 */
@Singleton
class DatabaseEngine @Inject constructor(@dagger.hilt.android.qualifiers.ApplicationContext context: Context) : SQLiteOpenHelper(
    context,
    DatabaseConfig.DATABASE_NAME,
    null,
    DatabaseConfig.DATABASE_VERSION,
) {

    companion object {
        private const val TAG = "DatabaseEngine"
    }

    private val walManager: WalModeManager by lazy { WalModeManager(writableDatabase) }
    private val stmtCache: PreparedStatementCache by lazy {
        PreparedStatementCache(writableDatabase, DatabaseConfig.STATEMENT_CACHE_SIZE)
    }
    private val batchManager: BatchTransactionManager by lazy {
        BatchTransactionManager(writableDatabase, stmtCache)
    }
    private val mmapDb: MemoryMappedDb by lazy { MemoryMappedDb(writableDatabase) }
    private val syncJournal = SyncJournal()

    val syncEngine: IncrementalSyncEngine by lazy {
        IncrementalSyncEngine(batchManager, syncJournal)
    }

    val fileDao: FileDao by lazy { FileDao(writableDatabase, stmtCache, batchManager) }

    private val healthMonitor: DatabaseHealthMonitor by lazy {
        DatabaseHealthMonitor(writableDatabase)
    }

    override fun onCreate(db: SQLiteDatabase) {
        Log.d(TAG, "Creating database schema")

        DatabaseConfig.PERFORMANCE_PRAGMAS.forEach { pragma ->
            try { db.execSQL(pragma) } catch (e: Exception) {
                Log.w(TAG, "PRAGMA failed: $pragma", e)
            }
        }

        SchemaDesign.createAllTables().forEach { sql -> db.execSQL(sql) }
        SchemaDesign.createAllIndexes().forEach { sql -> db.execSQL(sql) }
        SchemaDesign.createViews().forEach { sql -> db.execSQL(sql) }
        SchemaDesign.createTriggers().forEach { sql -> db.execSQL(sql) }

        db.beginTransactionNonExclusive()
        try {
            SchemaDesign.getMimeTypeSeedData().forEach { (mime, category) ->
                db.execSQL(
                    "INSERT OR IGNORE INTO mime_types (mime_type, category) VALUES (?, ?)",
                    arrayOf(mime, category),
                )
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }

        Log.d(TAG, "Database schema created successfully")
    }

    override fun onUpgrade(db: SQLiteDatabase, old: Int, new: Int) {
        Log.d(TAG, "Upgrading database from $old to $new (migrations would go here)")
    }

    override fun onOpen(db: SQLiteDatabase) {
        super.onOpen(db)
        if (!db.isReadOnly) {
            DatabaseConfig.PERFORMANCE_PRAGMAS.forEach { pragma ->
                try { db.execSQL(pragma) } catch (_: Exception) {}
            }
        }
    }

    /** Initialize all optimizations. */
    fun initialize() {
        walManager.enableWal()
        mmapDb.enable()
        stmtCache.precompile(getCommonStatements())
        healthMonitor.startMonitoring()

        Log.d(TAG, "DatabaseEngine initialized")
        Log.d(TAG, "WAL: ${walManager.isWalMode()}")
    }

    /** Run maintenance (call during idle/charging). */
    suspend fun runMaintenance() = withContext(Dispatchers.IO) {
        Log.d(TAG, "Running database maintenance")
        healthMonitor.runMaintenance()
        walManager.checkpoint(WalModeManager.CheckpointMode.TRUNCATE)
        syncEngine.syncNow()
    }

    fun onLowMemory() {
        mmapDb.adjustForMemoryPressure(100L)
    }

    private fun getCommonStatements(): List<String> = listOf(
        "SELECT id, path FROM directories WHERE path = ?",
        "SELECT id FROM files WHERE directory_id = ? AND name = ?",
        "INSERT OR REPLACE INTO files (id, directory_id, name, size, last_modified, is_hidden, is_symlink, inode) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        "DELETE FROM files WHERE id = ?",
        "UPDATE directories SET child_count = ?, last_scanned = ? WHERE path = ?",
        "SELECT f.id, f.name, f.size, f.last_modified FROM files f WHERE f.directory_id = ? ORDER BY f.name COLLATE NOCASE",
    )

    fun getDatabaseStats(): DatabaseStats = DatabaseStats(
        walStats = WalModeManager.CheckpointResult.Skipped("stats only"),
        stmtCacheStats = stmtCache.getStats(),
        batchStats = batchManager.getStats(),
        mmapStats = mmapDb.getMmapStats(),
        syncJournalStats = syncJournal.getStats(),
    )

    override fun close() {
        stmtCache.closeAll()
        syncEngine.shutdown()
        healthMonitor.stopMonitoring()
        super.close()
    }

    data class DatabaseStats(
        val walStats: WalModeManager.CheckpointResult,
        val stmtCacheStats: PreparedStatementCache.CacheStats,
        val batchStats: BatchTransactionManager.BatchStats,
        val mmapStats: MemoryMappedDb.MmapStats,
        val syncJournalStats: SyncJournal.JournalStats,
    )
}

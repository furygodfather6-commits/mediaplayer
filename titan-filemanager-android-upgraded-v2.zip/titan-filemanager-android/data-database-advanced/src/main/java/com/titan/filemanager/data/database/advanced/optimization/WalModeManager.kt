package com.titan.filemanager.data.database.advanced.optimization

import android.database.sqlite.SQLiteDatabase
import android.util.Log
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * WAL Mode Manager.
 *
 * Ported technique: #87 WAL mode
 *
 * WAL (Write-Ahead Log) benefits:
 *  1. Readers don't block writers
 *  2. Writers don't block readers
 *  3. Better concurrency for file manager
 *  4. Faster commits (append to WAL, not modify B-tree)
 *  5. Crash recovery guaranteed
 *
 * | Operation       | Journal | WAL    |
 * |-----------------|---------|--------|
 * | Read speed      | Fast    | Faster |
 * | Write speed     | Medium  | Fast   |
 * | Concurrent read | Blocked | Free   |
 * | Crash safety    | Good    | Better |
 */
class WalModeManager(private val db: SQLiteDatabase) {

    companion object {
        private const val TAG = "WalModeManager"
        private const val WAL_SIZE_THRESHOLD_KB = 10_240L  // 10MB
        private const val CHECKPOINT_INTERVAL_MS = 60_000L  // 1 minute
    }

    private val isWalEnabled = AtomicBoolean(false)
    private val lastCheckpointTime = AtomicLong(0L)
    private val totalCheckpoints = AtomicLong(0L)
    private val walFrameCount = AtomicLong(0L)

    /** Enable WAL mode — must be called before any reads/writes. */
    fun enableWal(): Boolean {
        return try {
            val result = db.rawQuery("PRAGMA journal_mode = WAL", null)
            result.use { cursor ->
                if (cursor.moveToFirst()) {
                    val mode = cursor.getString(0)
                    val enabled = mode == "wal"
                    isWalEnabled.set(enabled)

                    if (enabled) {
                        applyWalOptimizations()
                        Log.d(TAG, "WAL mode enabled successfully")
                    } else {
                        Log.w(TAG, "WAL mode not enabled, mode=$mode")
                    }
                    enabled
                } else false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to enable WAL", e)
            false
        }
    }

    private fun applyWalOptimizations() {
        try {
            db.execSQL("PRAGMA wal_autocheckpoint = 1000")
            db.execSQL("PRAGMA cache_size = -65536")
            db.execSQL("PRAGMA mmap_size = 536870912")
            Log.d(TAG, "WAL optimizations applied")
        } catch (e: Exception) {
            Log.w(TAG, "Some WAL optimizations failed", e)
        }
    }

    /**
     * Perform WAL checkpoint — moves WAL file content back to main database.
     *
     * Modes:
     *  - PASSIVE:  Non-blocking, best effort
     *  - FULL:     Wait for readers to finish
     *  - RESTART:  Full + restart WAL from beginning
     *  - TRUNCATE: Full + truncate WAL file (smallest WAL)
     */
    fun checkpoint(mode: CheckpointMode = CheckpointMode.PASSIVE): CheckpointResult {
        val now = System.currentTimeMillis()

        if (mode == CheckpointMode.PASSIVE &&
            now - lastCheckpointTime.get() < CHECKPOINT_INTERVAL_MS
        ) {
            return CheckpointResult.Skipped("Too soon")
        }

        return try {
            val cursor = db.rawQuery("PRAGMA wal_checkpoint(${mode.name})", null)
            cursor.use { c ->
                if (c.moveToFirst()) {
                    val busy = c.getInt(0)
                    val log = c.getInt(1)
                    val checkpointed = c.getInt(2)

                    lastCheckpointTime.set(now)
                    totalCheckpoints.incrementAndGet()
                    walFrameCount.set(0L)

                    Log.d(TAG, "Checkpoint ${mode.name}: busy=$busy log=$log checked=$checkpointed")

                    CheckpointResult.Success(
                        mode = mode,
                        logFrames = log,
                        checkpointedFrames = checkpointed,
                        hadBusyReaders = busy == 1,
                    )
                } else {
                    CheckpointResult.Failed("No result from checkpoint")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Checkpoint failed", e)
            CheckpointResult.Failed(e.message ?: "Unknown error")
        }
    }

    fun getWalSizeKb(): Long = try {
        db.rawQuery("PRAGMA wal_checkpoint", null).use { cursor ->
            if (cursor.moveToFirst()) cursor.getLong(1) else 0L
        }
    } catch (_: Exception) {
        0L
    }

    fun shouldCheckpoint(): Boolean =
        getWalSizeKb() > WAL_SIZE_THRESHOLD_KB ||
            System.currentTimeMillis() - lastCheckpointTime.get() > CHECKPOINT_INTERVAL_MS * 10

    fun isWalMode(): Boolean = isWalEnabled.get()
    fun getCheckpointCount(): Long = totalCheckpoints.get()

    enum class CheckpointMode { PASSIVE, FULL, RESTART, TRUNCATE }

    sealed class CheckpointResult {
        data class Success(
            val mode: CheckpointMode,
            val logFrames: Int,
            val checkpointedFrames: Int,
            val hadBusyReaders: Boolean,
        ) : CheckpointResult()

        data class Failed(val reason: String) : CheckpointResult()
        data class Skipped(val reason: String) : CheckpointResult()
    }
}

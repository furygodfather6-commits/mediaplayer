package com.titan.filemanager.data.database.advanced.normalization

/**
 * Normalized Database Schema.
 *
 * Ported technique: #92 Metadata normalization
 *
 * Normalized design:
 *  1. No data duplication
 *  2. Foreign key relationships
 *  3. Separate tables for different concerns
 *  4. Efficient for both reads and writes
 *
 * Tables:
 *  - directories      — directory info (path, scan state)
 *  - files            — file info (normalized)
 *  - file_metadata    — extended metadata (lazy loaded)
 *  - mime_types       — MIME type lookup table
 *  - extensions       — extension → mime mapping
 *  - scan_history     — scan timing data
 *  - access_history   — file access patterns
 *  - thumbnails       — thumbnail cache index
 *  - tags / file_tags — user-defined organization
 */
object SchemaDesign {

    fun createAllTables(): List<String> = listOf(
        createMimeTypesTable(),
        createExtensionsTable(),
        createDirectoriesTable(),
        createFilesTable(),
        createFileMetadataTable(),
        createScanHistoryTable(),
        createAccessHistoryTable(),
        createThumbnailsTable(),
        createTagsTable(),
        createFileTagsTable(),
    )

    private fun createMimeTypesTable() = """
        CREATE TABLE IF NOT EXISTS mime_types (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            mime_type   TEXT NOT NULL UNIQUE,
            category    TEXT NOT NULL DEFAULT 'other'
        )
    """.trimIndent()

    private fun createExtensionsTable() = """
        CREATE TABLE IF NOT EXISTS extensions (
            extension   TEXT PRIMARY KEY,
            mime_id     INTEGER NOT NULL,
            FOREIGN KEY (mime_id) REFERENCES mime_types(id)
        )
    """.trimIndent()

    private fun createDirectoriesTable() = """
        CREATE TABLE IF NOT EXISTS directories (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            path            TEXT NOT NULL UNIQUE,
            parent_id       INTEGER,
            name            TEXT NOT NULL,
            depth           INTEGER NOT NULL DEFAULT 0,
            child_count     INTEGER NOT NULL DEFAULT -1,
            total_size      INTEGER NOT NULL DEFAULT -1,
            last_scanned    INTEGER NOT NULL DEFAULT 0,
            scan_duration   INTEGER NOT NULL DEFAULT 0,
            is_hidden       INTEGER NOT NULL DEFAULT 0,
            checksum        INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY (parent_id) REFERENCES directories(id)
                ON DELETE CASCADE
        )
    """.trimIndent()

    private fun createFilesTable() = """
        CREATE TABLE IF NOT EXISTS files (
            id              INTEGER PRIMARY KEY,
            directory_id    INTEGER NOT NULL,
            name            TEXT NOT NULL,
            extension_id    INTEGER,
            size            INTEGER NOT NULL DEFAULT 0,
            last_modified   INTEGER NOT NULL DEFAULT 0,
            is_hidden       INTEGER NOT NULL DEFAULT 0,
            is_symlink      INTEGER NOT NULL DEFAULT 0,
            inode           INTEGER NOT NULL DEFAULT 0,
            created_at      INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY (directory_id) REFERENCES directories(id)
                ON DELETE CASCADE,
            FOREIGN KEY (extension_id) REFERENCES extensions(extension)
        )
    """.trimIndent()

    private fun createFileMetadataTable() = """
        CREATE TABLE IF NOT EXISTS file_metadata (
            file_id         INTEGER PRIMARY KEY,
            mime_id         INTEGER,
            permissions     TEXT,
            symlink_target  TEXT,
            media_width     INTEGER NOT NULL DEFAULT 0,
            media_height    INTEGER NOT NULL DEFAULT 0,
            media_duration  INTEGER NOT NULL DEFAULT 0,
            media_bitrate   INTEGER NOT NULL DEFAULT 0,
            media_title     TEXT,
            media_author    TEXT,
            content_hash    TEXT,
            last_updated    INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY (file_id) REFERENCES files(id)
                ON DELETE CASCADE,
            FOREIGN KEY (mime_id) REFERENCES mime_types(id)
        )
    """.trimIndent()

    private fun createScanHistoryTable() = """
        CREATE TABLE IF NOT EXISTS scan_history (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            directory_id    INTEGER NOT NULL,
            scan_time       INTEGER NOT NULL,
            duration_ms     INTEGER NOT NULL,
            file_count      INTEGER NOT NULL,
            strategy        TEXT NOT NULL DEFAULT 'normal',
            from_cache      INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY (directory_id) REFERENCES directories(id)
                ON DELETE CASCADE
        )
    """.trimIndent()

    private fun createAccessHistoryTable() = """
        CREATE TABLE IF NOT EXISTS access_history (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            path            TEXT NOT NULL,
            access_time     INTEGER NOT NULL,
            access_type     TEXT NOT NULL DEFAULT 'browse',
            session_id      TEXT
        )
    """.trimIndent()

    private fun createThumbnailsTable() = """
        CREATE TABLE IF NOT EXISTS thumbnails (
            file_id         INTEGER NOT NULL,
            size            INTEGER NOT NULL,
            disk_path       TEXT NOT NULL,
            width           INTEGER NOT NULL DEFAULT 0,
            height          INTEGER NOT NULL DEFAULT 0,
            file_size       INTEGER NOT NULL DEFAULT 0,
            content_hash    TEXT,
            created_at      INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY (file_id, size),
            FOREIGN KEY (file_id) REFERENCES files(id)
                ON DELETE CASCADE
        )
    """.trimIndent()

    private fun createTagsTable() = """
        CREATE TABLE IF NOT EXISTS tags (
            id      INTEGER PRIMARY KEY AUTOINCREMENT,
            name    TEXT NOT NULL UNIQUE,
            color   TEXT NOT NULL DEFAULT '#6200EE'
        )
    """.trimIndent()

    private fun createFileTagsTable() = """
        CREATE TABLE IF NOT EXISTS file_tags (
            file_id INTEGER NOT NULL,
            tag_id  INTEGER NOT NULL,
            PRIMARY KEY (file_id, tag_id),
            FOREIGN KEY (file_id) REFERENCES files(id) ON DELETE CASCADE,
            FOREIGN KEY (tag_id) REFERENCES tags(id) ON DELETE CASCADE
        )
    """.trimIndent()

    /** All indexes for fast queries. */
    fun createAllIndexes(): List<String> = listOf(
        // Fast directory path lookup
        "CREATE INDEX IF NOT EXISTS idx_dir_path ON directories(path)",
        "CREATE INDEX IF NOT EXISTS idx_dir_parent ON directories(parent_id)",
        "CREATE INDEX IF NOT EXISTS idx_dir_depth ON directories(depth)",
        // Fast file lookup by directory
        "CREATE INDEX IF NOT EXISTS idx_file_dir ON files(directory_id)",
        "CREATE INDEX IF NOT EXISTS idx_file_name ON files(name COLLATE NOCASE)",
        "CREATE INDEX IF NOT EXISTS idx_file_ext ON files(extension_id)",
        "CREATE INDEX IF NOT EXISTS idx_file_modified ON files(last_modified)",
        "CREATE INDEX IF NOT EXISTS idx_file_size ON files(size)",
        "CREATE INDEX IF NOT EXISTS idx_file_inode ON files(inode)",
        // Composite: directory + name (most common query)
        "CREATE INDEX IF NOT EXISTS idx_file_dir_name ON files(directory_id, name COLLATE NOCASE)",
        // Access history
        "CREATE INDEX IF NOT EXISTS idx_access_path ON access_history(path)",
        "CREATE INDEX IF NOT EXISTS idx_access_time ON access_history(access_time)",
        // Thumbnail lookup
        "CREATE INDEX IF NOT EXISTS idx_thumb_file ON thumbnails(file_id)",
        // Scan history
        "CREATE INDEX IF NOT EXISTS idx_scan_dir ON scan_history(directory_id, scan_time)",
    )

    /** Views for common queries. */
    fun createViews(): List<String> = listOf(
        """
        CREATE VIEW IF NOT EXISTS v_files_full AS
        SELECT
            f.id,
            d.path || '/' || f.name AS full_path,
            f.name,
            e.extension,
            m.mime_type,
            f.size,
            f.last_modified,
            f.is_hidden,
            f.is_symlink,
            d.path AS directory_path,
            d.id AS directory_id
        FROM files f
        JOIN directories d ON f.directory_id = d.id
        LEFT JOIN extensions e ON f.extension_id = e.extension
        LEFT JOIN mime_types m ON e.mime_id = m.id
        """.trimIndent(),
        """
        CREATE VIEW IF NOT EXISTS v_recent_files AS
        SELECT DISTINCT
            f.id,
            d.path || '/' || f.name AS full_path,
            f.name,
            ah.access_time
        FROM files f
        JOIN directories d ON f.directory_id = d.id
        JOIN access_history ah ON ah.path = d.path || '/' || f.name
        ORDER BY ah.access_time DESC
        LIMIT 50
        """.trimIndent(),
    )

    /** Triggers for data integrity. */
    fun createTriggers(): List<String> = listOf(
        """
        CREATE TRIGGER IF NOT EXISTS trg_file_insert
        AFTER INSERT ON files
        BEGIN
            UPDATE directories
            SET child_count = child_count + 1
            WHERE id = NEW.directory_id;
        END
        """.trimIndent(),
        """
        CREATE TRIGGER IF NOT EXISTS trg_file_delete
        AFTER DELETE ON files
        BEGIN
            UPDATE directories
            SET child_count = MAX(0, child_count - 1)
            WHERE id = OLD.directory_id;
        END
        """.trimIndent(),
    )

    /** Seed MIME types table with common types. */
    fun getMimeTypeSeedData(): List<Pair<String, String>> = listOf(
        "image/jpeg" to "image",
        "image/png" to "image",
        "image/gif" to "image",
        "image/webp" to "image",
        "image/heic" to "image",
        "video/mp4" to "video",
        "video/x-matroska" to "video",
        "video/quicktime" to "video",
        "audio/mpeg" to "audio",
        "audio/flac" to "audio",
        "audio/ogg" to "audio",
        "application/pdf" to "document",
        "application/zip" to "archive",
        "application/x-rar-compressed" to "archive",
        "text/plain" to "text",
        "text/html" to "text",
        "application/vnd.android.package-archive" to "apk",
        "application/octet-stream" to "other",
    )
}

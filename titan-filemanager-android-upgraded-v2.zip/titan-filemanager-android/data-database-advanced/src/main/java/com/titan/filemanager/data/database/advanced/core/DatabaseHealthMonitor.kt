package com.titan.filemanager.data.database.advanced.core

import android.database.sqlite.SQLiteDatabase
import android.util.Log
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Database Health Monitor.
 *
 * Monitors database performance and integrity. Runs quick_check, page count,
 * WAL size, and maintenance PRAGMAs on a 30-second interval.
 */
class DatabaseHealthMonitor(
    private val db: SQLiteDatabase,
) {

    companion object {
        private const val TAG = "DbHealthMonitor"
        private const val MONITOR_INTERVAL_MS = 30_000L
        private const val SLOW_QUERY_THRESHOLD_MS = 100L
    }

    private val isRunning = AtomicBoolean(false)
    private val scope = CoroutineScope(
        Dispatchers.IO + SupervisorJob() + CoroutineName("DbHealthMonitor"),
    )

    fun startMonitoring() {
        if (isRunning.getAndSet(true)) return

        scope.launch {
            while (isActive) {
                checkHealth()
                delay(MONITOR_INTERVAL_MS)
            }
        }
        Log.d(TAG, "Health monitoring started")
    }

    private fun checkHealth() {
        try {
            checkIntegrity()
            checkPageCount()
            checkWalSize()
        } catch (e: Exception) {
            Log.e(TAG, "Health check failed", e)
        }
    }

    private fun checkIntegrity() {
        val result = db.rawQuery("PRAGMA quick_check", null)
        result.use { cursor ->
            if (cursor.moveToFirst()) {
                val status = cursor.getString(0)
                if (status != "ok") {
                    Log.e(TAG, "Integrity check failed: $status")
                }
            }
        }
    }

    private fun checkPageCount() {
        val pageCount = db.rawQuery("PRAGMA page_count", null).use { cursor ->
            if (cursor.moveToFirst()) cursor.getLong(0) else 0L
        }
        val pageSize = db.rawQuery("PRAGMA page_size", null).use { cursor ->
            if (cursor.moveToFirst()) cursor.getLong(0) else 4096L
        }
        val dbSizeMb = pageCount * pageSize / (1024 * 1024)
        Log.d(TAG, "DB size: ${dbSizeMb}MB ($pageCount pages)")
    }

    private fun checkWalSize() {
        val walPages = db.rawQuery("PRAGMA wal_checkpoint", null).use { cursor ->
            if (cursor.moveToFirst()) cursor.getInt(1) else 0
        }
        Log.d(TAG, "WAL pages: $walPages")
    }

    fun runMaintenance() {
        scope.launch {
            DatabaseConfig.MAINTENANCE_PRAGMAS.forEach { pragma ->
                try {
                    db.execSQL(pragma)
                    Log.d(TAG, "Maintenance: $pragma")
                } catch (e: Exception) {
                    Log.w(TAG, "Maintenance failed: $pragma", e)
                }
            }
        }
    }

    fun stopMonitoring() {
        isRunning.set(false)
        scope.cancel()
    }
}

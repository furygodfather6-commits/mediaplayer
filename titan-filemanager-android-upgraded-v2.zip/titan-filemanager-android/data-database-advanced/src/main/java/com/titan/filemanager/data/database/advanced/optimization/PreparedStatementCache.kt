package com.titan.filemanager.data.database.advanced.optimization

import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteStatement
import android.util.Log
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.locks.ReentrantLock

/**
 * Prepared Statement Cache.
 *
 * Ported technique: #88 Prepared statements
 *
 * Why Prepared Statements?
 *  1. SQL parsed ONCE, executed many times
 *  2. No SQL injection risk
 *  3. Less CPU overhead per execution
 *  4. Better query plan reuse
 *
 * Performance comparison:
 *  - Raw SQL string:  ~0.5ms parse + ~0.1ms execute
 *  - Prepared stmt:   ~0ms parse + ~0.05ms execute
 *  → 10× faster for repeated queries
 */
class PreparedStatementCache(
    private val db: SQLiteDatabase,
    private val maxSize: Int = 50,
) {

    companion object {
        private const val TAG = "PreparedStatementCache"
    }

    private val cache = object : LinkedHashMap<String, CachedStatement>(maxSize, 0.75f, true) {
        override fun removeEldestEntry(eldest: Map.Entry<String, CachedStatement>): Boolean {
            return if (size > maxSize) {
                eldest.value.statement.close()
                Log.d(TAG, "Evicted statement: ${eldest.key.take(50)}")
                true
            } else false
        }
    }

    private val cacheLock = ReentrantLock()

    private val hits = AtomicLong(0L)
    private val misses = AtomicLong(0L)
    private val compilations = AtomicLong(0L)

    /** Get or compile prepared statement — thread-safe via lock. */
    fun getStatement(sql: String): SQLiteStatement {
        cacheLock.lock()
        try {
            val cached = cache[sql]
            if (cached != null && !cached.isInUse) {
                cached.isInUse = true
                cached.useCount++
                cached.lastUsed = System.currentTimeMillis()
                hits.incrementAndGet()
                return cached.statement
            }
        } finally {
            cacheLock.unlock()
        }

        misses.incrementAndGet()
        val statement = compileStatement(sql)

        cacheLock.lock()
        try {
            cache[sql] = CachedStatement(statement = statement, sql = sql, isInUse = true)
        } finally {
            cacheLock.unlock()
        }

        return statement
    }

    /** Release statement back to cache. */
    fun releaseStatement(sql: String) {
        cacheLock.lock()
        try {
            cache[sql]?.let { cached ->
                cached.statement.clearBindings()
                cached.isInUse = false
            }
        } finally {
            cacheLock.unlock()
        }
    }

    fun executeInsert(sql: String, bindArgs: Array<Any?>): Long {
        val stmt = getStatement(sql)
        return try {
            bindArgs(stmt, bindArgs)
            stmt.executeInsert()
        } finally {
            releaseStatement(sql)
        }
    }

    fun executeUpdateDelete(sql: String, bindArgs: Array<Any?>): Int {
        val stmt = getStatement(sql)
        return try {
            bindArgs(stmt, bindArgs)
            stmt.executeUpdateDelete()
        } finally {
            releaseStatement(sql)
        }
    }

    fun execute(sql: String, bindArgs: Array<Any?> = emptyArray()) {
        val stmt = getStatement(sql)
        try {
            bindArgs(stmt, bindArgs)
            stmt.execute()
        } finally {
            releaseStatement(sql)
        }
    }

    private fun bindArgs(stmt: SQLiteStatement, args: Array<Any?>) {
        stmt.clearBindings()
        args.forEachIndexed { index, arg ->
            val bindIndex = index + 1  // SQLite is 1-indexed
            when (arg) {
                null -> stmt.bindNull(bindIndex)
                is String -> stmt.bindString(bindIndex, arg)
                is Long -> stmt.bindLong(bindIndex, arg)
                is Int -> stmt.bindLong(bindIndex, arg.toLong())
                is Double -> stmt.bindDouble(bindIndex, arg)
                is Float -> stmt.bindDouble(bindIndex, arg.toDouble())
                is Boolean -> stmt.bindLong(bindIndex, if (arg) 1L else 0L)
                is ByteArray -> stmt.bindBlob(bindIndex, arg)
                else -> stmt.bindString(bindIndex, arg.toString())
            }
        }
    }

    private fun compileStatement(sql: String): SQLiteStatement {
        compilations.incrementAndGet()
        return db.compileStatement(sql)
    }

    /** Pre-compile frequently used statements. */
    fun precompile(statements: List<String>) {
        statements.forEach { sql ->
            try {
                cacheLock.lock()
                try {
                    if (!cache.containsKey(sql)) {
                        val stmt = compileStatement(sql)
                        cache[sql] = CachedStatement(statement = stmt, sql = sql)
                    }
                } finally {
                    cacheLock.unlock()
                }
            } catch (e: Exception) {
                Log.w(TAG, "Failed to precompile: $sql", e)
            }
        }
        Log.d(TAG, "Precompiled ${statements.size} statements")
    }

    fun getCacheSize(): Int {
        cacheLock.lock()
        try {
            return cache.size
        } finally {
            cacheLock.unlock()
        }
    }

    fun getHitRate(): Float {
        val total = hits.get() + misses.get()
        return if (total > 0) hits.get().toFloat() / total else 0f
    }

    fun closeAll() {
        cacheLock.lock()
        try {
            cache.values.forEach { it.statement.close() }
            cache.clear()
        } finally {
            cacheLock.unlock()
        }
    }

    data class CachedStatement(
        val statement: SQLiteStatement,
        val sql: String,
        var isInUse: Boolean = false,
        var useCount: Long = 0L,
        var lastUsed: Long = System.currentTimeMillis(),
    )

    data class CacheStats(
        val size: Int,
        val maxSize: Int,
        val hits: Long,
        val misses: Long,
        val compilations: Long,
        val hitRate: Float,
    )

    fun getStats() = CacheStats(
        size = getCacheSize(),
        maxSize = maxSize,
        hits = hits.get(),
        misses = misses.get(),
        compilations = compilations.get(),
        hitRate = getHitRate(),
    )
}

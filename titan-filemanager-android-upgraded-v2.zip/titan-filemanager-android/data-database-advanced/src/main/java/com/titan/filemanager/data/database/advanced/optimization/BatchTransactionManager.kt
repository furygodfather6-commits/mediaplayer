package com.titan.filemanager.data.database.advanced.optimization

import android.database.sqlite.SQLiteDatabase
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * Batch Transaction Manager.
 *
 * Ported technique: #89 Batch transactions
 *
 * Problem: Individual inserts are SLOW.
 *  1000 individual INSERTs = 1000 transactions, each = disk sync = ~1-5ms.
 *  Total: 1000-5000ms = 1-5 seconds!
 *
 * Solution: Batch into single transaction.
 *  1000 INSERTs in 1 transaction = 1 disk sync.
 *  Total: ~10-50ms = 50-100× faster!
 *
 * Strategy:
 *  - Buffer operations in memory
 *  - Flush in configurable batch sizes
 *  - Use IMMEDIATE transaction (no upgrade needed)
 *  - Retry on SQLITE_BUSY
 */
class BatchTransactionManager(
    private val db: SQLiteDatabase,
    private val stmtCache: PreparedStatementCache,
) {

    companion object {
        private const val TAG = "BatchTransaction"
        private const val DEFAULT_BATCH_SIZE = 500
        private const val MAX_RETRY_COUNT = 3
        private const val RETRY_DELAY_MS = 50L
    }

    private val pendingOps = ConcurrentLinkedQueue<DatabaseOperation>()
    private val pendingCount = AtomicInteger(0)

    private val totalBatches = AtomicLong(0L)
    private val totalOperations = AtomicLong(0L)
    private val totalTimeMs = AtomicLong(0L)

    fun queue(operation: DatabaseOperation) {
        pendingOps.offer(operation)
        pendingCount.incrementAndGet()
    }

    fun queueAll(operations: List<DatabaseOperation>) {
        operations.forEach { pendingOps.offer(it) }
        pendingCount.addAndGet(operations.size)
    }

    suspend fun flush(batchSize: Int = DEFAULT_BATCH_SIZE): FlushResult =
        withContext(Dispatchers.IO) {
            if (pendingOps.isEmpty()) return@withContext FlushResult(0, 0L)

            val start = System.currentTimeMillis()
            var processed = 0
            var failed = 0

            while (pendingOps.isNotEmpty()) {
                val batch = drainBatch(batchSize)
                if (batch.isEmpty()) break

                val result = executeBatch(batch)
                processed += result.first
                failed += result.second
            }

            val elapsed = System.currentTimeMillis() - start
            totalBatches.incrementAndGet()
            totalOperations.addAndGet(processed.toLong())
            totalTimeMs.addAndGet(elapsed)

            Log.d(TAG, "Flush: $processed ops in ${elapsed}ms")
            FlushResult(processed, elapsed)
        }

    private fun executeBatch(batch: List<DatabaseOperation>): Pair<Int, Int> {
        var processed = 0
        var failed = 0
        var retryCount = 0

        while (retryCount < MAX_RETRY_COUNT) {
            try {
                db.beginTransactionNonExclusive()
                try {
                    for (op in batch) {
                        try {
                            executeOperation(op)
                            processed++
                        } catch (e: Exception) {
                            Log.w(TAG, "Operation failed: ${op.javaClass.simpleName}", e)
                            failed++
                        }
                    }
                    db.setTransactionSuccessful()
                    break
                } finally {
                    db.endTransaction()
                }
            } catch (_: android.database.sqlite.SQLiteException) {
                retryCount++
                if (retryCount < MAX_RETRY_COUNT) {
                    try { Thread.sleep(RETRY_DELAY_MS * retryCount) } catch (_: InterruptedException) {}
                    Log.w(TAG, "Retry $retryCount after SQLite error")
                } else {
                    Log.e(TAG, "Batch failed after $MAX_RETRY_COUNT retries")
                    failed += batch.size - processed
                }
            }
        }

        return Pair(processed, failed)
    }

    private fun executeOperation(op: DatabaseOperation) {
        when (op) {
            is DatabaseOperation.Insert -> stmtCache.executeInsert(op.sql, op.args)
            is DatabaseOperation.Update -> stmtCache.executeUpdateDelete(op.sql, op.args)
            is DatabaseOperation.Delete -> stmtCache.executeUpdateDelete(op.sql, op.args)
            is DatabaseOperation.Execute -> stmtCache.execute(op.sql, op.args)
            is DatabaseOperation.Upsert -> stmtCache.executeInsert(op.sql, op.args)
        }
    }

    /** Execute directly in single transaction (not queued). */
    suspend fun executeImmediate(operations: List<DatabaseOperation>): FlushResult =
        withContext(Dispatchers.IO) {
            val start = System.currentTimeMillis()
            val result = executeBatch(operations)
            val elapsed = System.currentTimeMillis() - start
            FlushResult(result.first, elapsed)
        }

    private fun drainBatch(maxSize: Int): List<DatabaseOperation> {
        val batch = ArrayList<DatabaseOperation>(maxSize)
        repeat(maxSize) {
            val op = pendingOps.poll() ?: return batch
            batch.add(op)
            pendingCount.decrementAndGet()
        }
        return batch
    }

    fun getPendingCount(): Int = pendingCount.get()

    fun getStats() = BatchStats(
        pendingCount = pendingCount.get(),
        totalBatches = totalBatches.get(),
        totalOperations = totalOperations.get(),
        avgBatchTimeMs = if (totalBatches.get() > 0) totalTimeMs.get() / totalBatches.get() else 0L,
        avgOpsPerMs = if (totalTimeMs.get() > 0) totalOperations.get().toFloat() / totalTimeMs.get() else 0f,
    )

    data class FlushResult(val processed: Int, val durationMs: Long)

    data class BatchStats(
        val pendingCount: Int,
        val totalBatches: Long,
        val totalOperations: Long,
        val avgBatchTimeMs: Long,
        val avgOpsPerMs: Float,
    )
}

/** Sealed class for database operations. */
sealed class DatabaseOperation {
    data class Insert(val sql: String, val args: Array<Any?>) : DatabaseOperation()
    data class Update(val sql: String, val args: Array<Any?>) : DatabaseOperation()
    data class Delete(val sql: String, val args: Array<Any?>) : DatabaseOperation()
    data class Execute(val sql: String, val args: Array<Any?> = emptyArray()) : DatabaseOperation()
    data class Upsert(val sql: String, val args: Array<Any?>) : DatabaseOperation()
}

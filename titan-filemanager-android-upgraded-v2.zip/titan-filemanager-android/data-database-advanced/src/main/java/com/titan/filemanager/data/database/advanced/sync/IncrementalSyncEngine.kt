package com.titan.filemanager.data.database.advanced.sync

import com.titan.filemanager.data.database.advanced.optimization.BatchTransactionManager
import com.titan.filemanager.data.database.advanced.optimization.DatabaseOperation
import android.util.Log
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicLong

/**
 * Incremental Sync Engine.
 *
 * Ported technique: #91 Incremental sync
 *
 * Syncs filesystem state to database INCREMENTALLY:
 *  - Only writes CHANGED data
 *  - Batches writes for efficiency
 *  - Tracks what needs to be synced
 *  - Handles conflicts
 *
 * Sync strategies:
 *  1. IMMEDIATE — sync now (user action)
 *  2. DEFERRED  — sync in background (auto, 500ms debounce)
 *  3. LAZY      — sync when idle
 */
class IncrementalSyncEngine(
    private val batchManager: BatchTransactionManager,
    private val syncJournal: SyncJournal,
) {

    companion object {
        private const val TAG = "IncrementalSync"
        private const val SYNC_BATCH_SIZE = 200
        private const val DEFERRED_SYNC_DELAY_MS = 500L
    }

    private val syncQueue = ConcurrentLinkedQueue<SyncOperation>()

    private val syncedCount = AtomicLong(0L)
    private val conflictCount = AtomicLong(0L)

    private val _syncProgress = MutableSharedFlow<SyncProgress>(replay = 1, extraBufferCapacity = 20)
    val syncProgress: SharedFlow<SyncProgress> = _syncProgress

    private val scope = CoroutineScope(
        Dispatchers.IO + SupervisorJob() + CoroutineName("IncrementalSync"),
    )

    fun queueSync(operation: SyncOperation) {
        syncQueue.offer(operation)
        scheduleDeferredSync()
    }

    fun queueBatchSync(operations: List<SyncOperation>) {
        operations.forEach { syncQueue.offer(it) }
        scheduleDeferredSync()
    }

    /** Immediate sync — wait for completion. */
    suspend fun syncNow(): SyncResult {
        val start = System.currentTimeMillis()
        var synced = 0
        val failed = 0

        val toSync = drainQueue()
        if (toSync.isEmpty()) return SyncResult(0, 0, 0L)

        val dbOps = toSync.mapNotNull { convertToDbOp(it) }
        val result = batchManager.executeImmediate(dbOps)
        synced = result.processed
        syncedCount.addAndGet(synced.toLong())

        syncJournal.recordSync(operationCount = synced, durationMs = System.currentTimeMillis() - start)

        return SyncResult(synced, failed, System.currentTimeMillis() - start)
    }

    private var deferredSyncJob: Job? = null

    private fun scheduleDeferredSync() {
        deferredSyncJob?.cancel()
        deferredSyncJob = scope.launch {
            delay(DEFERRED_SYNC_DELAY_MS)
            performDeferredSync()
        }
    }

    private suspend fun performDeferredSync() {
        val toSync = drainQueue(SYNC_BATCH_SIZE)
        if (toSync.isEmpty()) return

        val dbOps = toSync.mapNotNull { convertToDbOp(it) }
        val result = batchManager.executeImmediate(dbOps)
        syncedCount.addAndGet(result.processed.toLong())

        _syncProgress.emit(SyncProgress.Synced(count = result.processed, remaining = syncQueue.size))

        if (syncQueue.isNotEmpty()) {
            performDeferredSync()
        }
    }

    private fun convertToDbOp(op: SyncOperation): DatabaseOperation? {
        return when (op) {
            is SyncOperation.UpsertFile -> DatabaseOperation.Upsert(
                sql = """
                    INSERT OR REPLACE INTO files
                    (id, directory_id, name, size, last_modified,
                     is_hidden, is_symlink, inode)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """.trimIndent(),
                args = arrayOf(
                    op.fileId, op.directoryId, op.name,
                    op.size, op.lastModified,
                    if (op.isHidden) 1 else 0,
                    if (op.isSymlink) 1 else 0,
                    op.inode,
                ),
            )

            is SyncOperation.DeleteFile -> DatabaseOperation.Delete(
                sql = "DELETE FROM files WHERE id = ?",
                args = arrayOf(op.fileId),
            )

            is SyncOperation.UpsertDirectory -> DatabaseOperation.Upsert(
                sql = """
                    INSERT OR REPLACE INTO directories
                    (path, name, depth, last_scanned, checksum)
                    VALUES (?, ?, ?, ?, ?)
                """.trimIndent(),
                args = arrayOf(op.path, op.name, op.depth, System.currentTimeMillis(), op.checksum),
            )

            is SyncOperation.UpdateChildCount -> DatabaseOperation.Update(
                sql = """
                    UPDATE directories
                    SET child_count = ?, last_scanned = ?
                    WHERE path = ?
                """.trimIndent(),
                args = arrayOf(op.childCount, System.currentTimeMillis(), op.dirPath),
            )

            is SyncOperation.UpdateMetadata -> DatabaseOperation.Upsert(
                sql = """
                    INSERT OR REPLACE INTO file_metadata
                    (file_id, media_width, media_height, media_duration,
                     media_bitrate, media_title, media_author, last_updated)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """.trimIndent(),
                args = arrayOf(
                    op.fileId, op.width, op.height,
                    op.duration, op.bitrate, op.title, op.author,
                    System.currentTimeMillis(),
                ),
            )
        }
    }

    private fun drainQueue(maxItems: Int = Int.MAX_VALUE): List<SyncOperation> {
        val result = ArrayList<SyncOperation>(minOf(maxItems, 200))
        repeat(maxItems) {
            result.add(syncQueue.poll() ?: return result)
        }
        return result
    }

    fun getPendingCount(): Int = syncQueue.size
    fun getTotalSynced(): Long = syncedCount.get()

    fun shutdown() {
        scope.cancel()
    }

    data class SyncResult(val synced: Int, val failed: Int, val durationMs: Long)

    sealed class SyncProgress {
        data class Synced(val count: Int, val remaining: Int) : SyncProgress()
        data class Error(val message: String) : SyncProgress()
    }
}

/** Sync operation types. */
sealed class SyncOperation {
    data class UpsertFile(
        val fileId: Long,
        val directoryId: Long,
        val name: String,
        val size: Long,
        val lastModified: Long,
        val isHidden: Boolean,
        val isSymlink: Boolean,
        val inode: Long,
    ) : SyncOperation()

    data class DeleteFile(val fileId: Long) : SyncOperation()

    data class UpsertDirectory(
        val path: String,
        val name: String,
        val depth: Int,
        val checksum: Long,
    ) : SyncOperation()

    data class UpdateChildCount(val dirPath: String, val childCount: Int) : SyncOperation()

    data class UpdateMetadata(
        val fileId: Long,
        val width: Int = 0,
        val height: Int = 0,
        val duration: Long = 0L,
        val bitrate: Int = 0,
        val title: String? = null,
        val author: String? = null,
    ) : SyncOperation()
}

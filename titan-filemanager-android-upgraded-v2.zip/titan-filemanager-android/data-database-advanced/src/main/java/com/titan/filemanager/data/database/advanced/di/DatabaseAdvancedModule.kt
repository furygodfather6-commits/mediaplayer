package com.titan.filemanager.data.database.advanced.di

import android.content.Context
import com.titan.filemanager.data.database.advanced.DatabaseEngine
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/** Hilt module exposing [DatabaseEngine] as application-scoped singleton. */
@Module
@InstallIn(SingletonComponent::class)
object DatabaseAdvancedModule {

    @Provides @Singleton
    fun provideDatabaseEngine(@ApplicationContext context: Context): DatabaseEngine =
        DatabaseEngine(context).also { it.initialize() }
}

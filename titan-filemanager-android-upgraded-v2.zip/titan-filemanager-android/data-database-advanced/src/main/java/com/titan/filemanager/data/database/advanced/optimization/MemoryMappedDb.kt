package com.titan.filemanager.data.database.advanced.optimization

import android.database.sqlite.SQLiteDatabase
import android.util.Log
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * Memory-Mapped Database Manager.
 *
 * Ported technique: #90 Memory-mapped database
 *
 * `mmap_size` tells SQLite to map the database file directly into virtual
 * memory address space.
 *
 * Benefits:
 *  1. OS handles caching (page cache)
 *  2. Reduced system call overhead
 *  3. Faster sequential reads
 *  4. Zero-copy reads (no memcpy from kernel)
 *  5. Shared across processes (if needed)
 *
 * mmap sizes guide:
 *  - Small device (2GB RAM):  256MB
 *  - Medium device (4GB RAM): 512MB
 *  - Large device (8GB RAM):  1GB
 */
class MemoryMappedDb(
    private val db: SQLiteDatabase,
    deviceRamMb: Long = 3000L,
) {

    companion object {
        private const val TAG = "MemoryMappedDb"

        private fun calculateMmapSize(ramMb: Long): Long = when {
            ramMb >= 8000 -> 1024L * 1024 * 1024    // 1GB
            ramMb >= 4000 -> 536_870_912L            // 512MB
            ramMb >= 2000 -> 268_435_456L            // 256MB
            else -> 134_217_728L                      // 128MB
        }
    }

    private val mmapSize = calculateMmapSize(deviceRamMb)
    private val isEnabled = AtomicBoolean(false)
    private val pagesRead = AtomicLong(0L)
    private val pagesMmapped = AtomicLong(0L)

    fun enable(): Boolean {
        return try {
            db.execSQL("PRAGMA mmap_size = $mmapSize")

            val actualSize = getMmapSize()
            val enabled = actualSize > 0
            isEnabled.set(enabled)

            if (enabled) {
                Log.d(TAG, "mmap enabled: ${actualSize / 1024 / 1024}MB")
                prewarmMmap()
            }
            enabled
        } catch (e: Exception) {
            Log.e(TAG, "Failed to enable mmap", e)
            false
        }
    }

    fun disable() {
        try {
            db.execSQL("PRAGMA mmap_size = 0")
            isEnabled.set(false)
            Log.d(TAG, "mmap disabled")
        } catch (e: Exception) {
            Log.w(TAG, "Failed to disable mmap", e)
        }
    }

    private fun getMmapSize(): Long = try {
        db.rawQuery("PRAGMA mmap_size", null).use { cursor ->
            if (cursor.moveToFirst()) cursor.getLong(0) else 0L
        }
    } catch (_: Exception) {
        0L
    }

    private fun prewarmMmap() {
        try {
            db.rawQuery("SELECT COUNT(*) FROM sqlite_master", null).use { cursor ->
                cursor.moveToFirst()
            }
            Log.d(TAG, "mmap pre-warmed")
        } catch (e: Exception) {
            Log.w(TAG, "mmap prewarm failed", e)
        }
    }

    fun adjustForMemoryPressure(availableRamMb: Long) {
        val newSize = when {
            availableRamMb < 100 -> 0L
            availableRamMb < 200 -> 67_108_864L    // 64MB
            availableRamMb < 500 -> 134_217_728L   // 128MB
            else -> mmapSize
        }

        try {
            db.execSQL("PRAGMA mmap_size = $newSize")
            isEnabled.set(newSize > 0)
            Log.d(TAG, "mmap adjusted to ${newSize / 1024 / 1024}MB")
        } catch (e: Exception) {
            Log.w(TAG, "mmap adjustment failed", e)
        }
    }

    fun getMmapStats(): MmapStats = try {
        val mmapUsed = db.rawQuery("PRAGMA mmap_size", null).use { cursor ->
            if (cursor.moveToFirst()) cursor.getLong(0) else 0L
        }
        MmapStats(
            isEnabled = isEnabled.get(),
            configuredSizeBytes = mmapSize,
            actualSizeBytes = mmapUsed,
            pagesRead = pagesRead.get(),
            pagesMmapped = pagesMmapped.get(),
        )
    } catch (_: Exception) {
        MmapStats(false, 0L, 0L, 0L, 0L)
    }

    data class MmapStats(
        val isEnabled: Boolean,
        val configuredSizeBytes: Long,
        val actualSizeBytes: Long,
        val pagesRead: Long,
        val pagesMmapped: Long,
    )
}

package com.titan.filemanager.data.backup.di

import com.titan.filemanager.data.backup.repository.DefaultBackupRepository
import com.titan.filemanager.domain.backup.BackupRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class BackupModule {

    @Binds
    @Singleton
    abstract fun bindBackupRepository(impl: DefaultBackupRepository): BackupRepository
}

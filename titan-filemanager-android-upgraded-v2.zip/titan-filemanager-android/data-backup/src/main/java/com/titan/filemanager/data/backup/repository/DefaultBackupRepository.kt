package com.titan.filemanager.data.backup.repository

import com.titan.filemanager.core.common.result.AppError
import com.titan.filemanager.core.common.result.Result
import com.titan.filemanager.data.backup.engine.BackupEngine
import com.titan.filemanager.domain.backup.BackupInfo
import com.titan.filemanager.domain.backup.BackupRepository
import com.titan.filemanager.domain.backup.BackupResult
import com.titan.filemanager.domain.backup.BackupProgress
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DefaultBackupRepository @Inject constructor(
    private val engine: BackupEngine,
) : BackupRepository {

    override suspend fun createBackup(destinationPath: String, password: String?): Result<BackupResult> {
        val result = engine.createBackup(destinationPath, password)
        return if (result.success) Result.Success(result)
        else Result.Error(AppError.Unknown(RuntimeException(result.message)))
    }

    override suspend fun restoreBackup(backupPath: String, password: String?): Result<BackupResult> {
        val result = engine.restoreBackup(backupPath, password)
        return if (result.success) Result.Success(result)
        else Result.Error(AppError.Unknown(RuntimeException(result.message)))
    }

    override fun observeBackupProgress(): Flow<BackupProgress> = engine.progress

    override suspend fun listBackups(directory: String): List<BackupInfo> = engine.listBackups(directory)
}

package com.titan.filemanager.data.backup.engine

import android.content.Context
import com.titan.filemanager.core.common.dispatcher.DispatcherProvider
import com.titan.filemanager.core.common.logger.Logger
import com.titan.filemanager.domain.backup.BackupInfo
import com.titan.filemanager.domain.backup.BackupPhase
import com.titan.filemanager.domain.backup.BackupProgress
import com.titan.filemanager.domain.backup.BackupResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Backup engine — creates ZIP archives of app data + restores them.
 *
 * Phase 6: ZIP backup of database + datastore + shared preferences.
 * Phase 7 will add: AES-256 encryption with user password.
 */
@Singleton
class BackupEngine @Inject constructor(
    @dagger.hilt.android.qualifiers.ApplicationContext private val context: Context,
    private val dispatchers: DispatcherProvider,
    private val logger: Logger,
) {

    private val _progress = MutableStateFlow(
        BackupProgress(BackupPhase.COLLECTING, null, 0, 0)
    )
    val progress: StateFlow<BackupProgress> = _progress.asStateFlow()

    suspend fun createBackup(destinationPath: String, password: String?): BackupResult =
        withContext(dispatchers.io) {
            try {
                val destFile = File(destinationPath)
                destFile.parentFile?.mkdirs()
                var itemsBackedUp = 0
                val startTime = System.currentTimeMillis()

                _progress.value = BackupProgress(BackupPhase.COLLECTING, null, 0, 0)

                ZipOutputStream(destFile.outputStream()).use { zos ->
                    // ── Database ─────────────────────────────────
                    _progress.value = BackupProgress(BackupPhase.BACKING_UP_DATABASE, "titan.db", 0, 4)
                    val dbFile = context.getDatabasePath("titan.db")
                    if (dbFile.exists()) {
                        addFileToZip(zos, dbFile, "database/titan.db")
                        itemsBackedUp++
                    }
                    val walFile = File(dbFile.parentFile, "titan.db-wal")
                    if (walFile.exists()) {
                        addFileToZip(zos, walFile, "database/titan.db-wal")
                        itemsBackedUp++
                    }
                    _progress.value = BackupProgress(BackupPhase.BACKING_UP_DATABASE, null, 2, 4)

                    // ── DataStore ────────────────────────────────
                    _progress.value = BackupProgress(BackupPhase.BACKING_UP_SETTINGS, "preferences", 2, 4)
                    val datastoreDir = File(context.filesDir, "datastore")
                    if (datastoreDir.exists()) {
                        datastoreDir.listFiles()?.forEach { file ->
                            addFileToZip(zos, file, "datastore/${file.name}")
                            itemsBackedUp++
                        }
                    }
                    _progress.value = BackupProgress(BackupPhase.BACKING_UP_SETTINGS, null, 3, 4)

                    // ── Shared preferences ──────────────────────
                    val prefsDir = context.filesDir.parentFile?.let { File(it, "shared_prefs") }
                    if (prefsDir?.exists() == true) {
                        prefsDir.listFiles()?.forEach { file ->
                            addFileToZip(zos, file, "prefs/${file.name}")
                            itemsBackedUp++
                        }
                    }
                    _progress.value = BackupProgress(BackupPhase.COMPRESSING, null, 4, 4)
                }

                _progress.value = BackupProgress(BackupPhase.DONE, null, 4, 4)

                BackupResult(
                    success = true,
                    itemsBackedUp = itemsBackedUp,
                    totalBytes = destFile.length(),
                    durationMs = System.currentTimeMillis() - startTime,
                    message = "Backup created at ${destFile.absolutePath}",
                )
            } catch (e: Exception) {
                logger.w(e) { "Backup failed" }
                BackupResult(false, 0, 0, 0, e.message ?: "Backup failed")
            }
        }

    suspend fun restoreBackup(backupPath: String, password: String?): BackupResult =
        withContext(dispatchers.io) {
            try {
                val backupFile = File(backupPath)
                if (!backupFile.exists()) {
                    return@withContext BackupResult(false, 0, 0, 0, "Backup file not found")
                }
                var itemsRestored = 0
                val startTime = System.currentTimeMillis()

                ZipInputStream(backupFile.inputStream()).use { zis ->
                    var entry: ZipEntry? = zis.nextEntry
                    while (entry != null) {
                        val targetPath = when {
                            entry.name.startsWith("database/") -> {
                                val dbFile = context.getDatabasePath(entry.name.removePrefix("database/"))
                                dbFile.parentFile?.mkdirs()
                                dbFile.absolutePath
                            }
                            entry.name.startsWith("datastore/") -> {
                                val f = File(context.filesDir, "datastore/${entry.name.removePrefix("datastore/")}")
                                f.parentFile?.mkdirs()
                                f.absolutePath
                            }
                            entry.name.startsWith("prefs/") -> {
                                val prefsDir = context.filesDir.parentFile?.let { File(it, "shared_prefs") }
                                prefsDir?.mkdirs()
                                File(prefsDir, entry.name.removePrefix("prefs/")).absolutePath
                            }
                            else -> null
                        }
                        if (targetPath != null) {
                            File(targetPath).outputStream().use { zis.copyTo(it) }
                            itemsRestored++
                        }
                        zis.closeEntry()
                        entry = zis.nextEntry
                    }
                }

                BackupResult(
                    success = true,
                    itemsBackedUp = itemsRestored,
                    totalBytes = backupFile.length(),
                    durationMs = System.currentTimeMillis() - startTime,
                    message = "Restored $itemsRestored items",
                )
            } catch (e: Exception) {
                logger.w(e) { "Restore failed" }
                BackupResult(false, 0, 0, 0, e.message ?: "Restore failed")
            }
        }

    suspend fun listBackups(directory: String): List<BackupInfo> = withContext(dispatchers.io) {
        val dir = File(directory)
        if (!dir.exists()) return@withContext emptyList()
        dir.listFiles()
            ?.filter { it.extension == "zip" || it.extension == "titanbak" }
            ?.map { file ->
                BackupInfo(
                    path = file.absolutePath,
                    size = file.length(),
                    createdAt = file.lastModified(),
                    isEncrypted = false, // Phase 7
                )
            }
            ?.sortedByDescending { it.createdAt }
            ?: emptyList()
    }

    private fun addFileToZip(zos: ZipOutputStream, file: File, entryName: String) {
        zos.putNextEntry(ZipEntry(entryName))
        file.inputStream().use { it.copyTo(zos) }
        zos.closeEntry()
    }
}

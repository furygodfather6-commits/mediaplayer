package com.titan.filemanager.data.io.models

import java.util.concurrent.atomic.AtomicLong

enum class IOOperationType {
    STAT, READ_DIR, READ_FILE, MIME_DETECT, PATH_RESOLVE, CHECKSUM,
}

data class IORequest(
    val id: Long = nextId(),
    val path: String,
    val type: IOOperationType,
    val priority: Int = PRIORITY_NORMAL,
    val requestedAt: Long = System.nanoTime(),
) {
    companion object {
        const val PRIORITY_CRITICAL = 0
        const val PRIORITY_HIGH = 1
        const val PRIORITY_NORMAL = 2
        const val PRIORITY_LOW = 3
        private val counter = AtomicLong(0)
        fun nextId() = counter.incrementAndGet()
    }
}

sealed class IOResult {
    data class StatResult(
        val path: String, val size: Long, val lastModified: Long,
        val isDirectory: Boolean, val isSymlink: Boolean, val inode: Long,
        val fromCache: Boolean = false,
    ) : IOResult()

    data class DirListResult(
        val path: String, val names: Array<String>, val fromCache: Boolean = false,
    ) : IOResult()

    data class MimeResult(
        val path: String, val mimeType: String, val fromCache: Boolean = false,
    ) : IOResult()

    data class ReadResult(val path: String, val data: ByteArray, val bytesRead: Int) : IOResult()
    data class ErrorResult(val path: String, val error: Throwable) : IOResult()
}

data class IOStats(
    val totalOperations: Long, val cacheHits: Long, val cacheMisses: Long,
    val avgLatencyNs: Long, val totalBytesRead: Long,
    val syscallCount: Long, val batchedSyscalls: Long, val readAheadHits: Long,
) {
    val cacheHitRate: Float get() = if (totalOperations > 0) cacheHits.toFloat() / totalOperations else 0f
    val batchEfficiency: Float get() = if (syscallCount > 0) batchedSyscalls.toFloat() / syscallCount else 0f
}

package com.titan.filemanager.data.io.cache

import android.os.Build
import android.system.Os
import android.system.OsConstants
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * Stat Result Cache — one real stat(), unlimited free lookups.
 *
 * Problem: stat() called multiple times for same file (isDir + size + modified = 3 calls)
 * Solution: cache stat() result, serve from cache (5s TTL)
 * Invalidation: time-based + FileObserver events + inode-based
 *
 * Technique #112: Avoid repeated stat()
 * Technique #160: Inode-based change detection
 */
class StatCache(
    private val maxEntries: Int = 10_000,
    private val ttlMs: Long = 5_000L,
) {
    private val cache = ConcurrentHashMap<String, CachedStat>(maxEntries, 0.75f)
    private val inodeToPath = ConcurrentHashMap<Long, String>(maxEntries)
    private val hits = AtomicLong(0)
    private val misses = AtomicLong(0)
    private val invalidations = AtomicLong(0)

    fun getStat(path: String): CachedStat? {
        val cached = cache[path]
        if (cached != null) {
            if (System.currentTimeMillis() - cached.cachedAt < ttlMs) {
                hits.incrementAndGet()
                return cached
            }
            cache.remove(path)
        }
        misses.incrementAndGet()
        return null
    }

    fun putStat(path: String, stat: CachedStat) {
        if (cache.size >= maxEntries) evictOldest()
        cache[path] = stat
        if (stat.inode > 0) inodeToPath[stat.inode] = path
    }

    fun getOrFetch(path: String): CachedStat {
        getStat(path)?.let { return it }
        val fresh = fetchFresh(path)
        putStat(path, fresh)
        return fresh
    }

    private fun fetchFresh(path: String): CachedStat =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try {
                val st = Os.lstat(path)
                CachedStat(
                    path = path, inode = st.st_ino, size = st.st_size,
                    lastModified = st.st_mtime * 1000L,
                    isDirectory = OsConstants.S_ISDIR(st.st_mode),
                    isSymlink = OsConstants.S_ISLNK(st.st_mode),
                    permissions = st.st_mode,
                    cachedAt = System.currentTimeMillis(), isValid = true,
                )
            } catch (e: Exception) { CachedStat.invalid(path) }
        } else {
            val file = java.io.File(path)
            CachedStat(
                path = path, inode = 0L, size = file.length(),
                lastModified = file.lastModified(), isDirectory = file.isDirectory,
                isSymlink = false, permissions = 0,
                cachedAt = System.currentTimeMillis(), isValid = file.exists(),
            )
        }

    fun invalidate(path: String) {
        cache.remove(path)?.let { stat ->
            inodeToPath.remove(stat.inode)
            invalidations.incrementAndGet()
        }
    }

    fun invalidateByInode(inode: Long) {
        inodeToPath[inode]?.let { path -> invalidate(path); inodeToPath.remove(inode) }
    }

    /** FIX: Added missing invalidateParent method (original codebase bug). */
    fun invalidateParent(childPath: String) {
        val parent = childPath.substringBeforeLast('/')
        if (parent.isNotEmpty()) invalidate(parent)
    }

    fun invalidateDirectory(dirPath: String) {
        val prefix = if (dirPath.endsWith('/')) dirPath else "$dirPath/"
        cache.keys.filter { it.startsWith(prefix) || it == dirPath }.forEach { invalidate(it) }
    }

    fun clear() { cache.clear(); inodeToPath.clear() }

    fun getStats(): StatCacheStats {
        val total = hits.get() + misses.get()
        return StatCacheStats(
            size = cache.size, hits = hits.get(), misses = misses.get(),
            invalidations = invalidations.get(),
            hitRate = if (total > 0) hits.get().toFloat() / total else 0f,
        )
    }

    private fun evictOldest() {
        val now = System.currentTimeMillis()
        val expired = cache.entries.filter { now - it.value.cachedAt > ttlMs }.map { it.key }
        if (expired.isNotEmpty()) { expired.forEach { cache.remove(it) }; return }
        cache.entries.sortedBy { it.value.cachedAt }.take(maxEntries / 10).forEach { cache.remove(it.key) }
    }

    data class CachedStat(
        val path: String, val inode: Long, val size: Long, val lastModified: Long,
        val isDirectory: Boolean, val isSymlink: Boolean, val permissions: Int,
        val cachedAt: Long, val isValid: Boolean,
    ) {
        companion object {
            fun invalid(path: String) = CachedStat(
                path = path, inode = 0L, size = -1L, lastModified = 0L,
                isDirectory = false, isSymlink = false, permissions = 0,
                cachedAt = System.currentTimeMillis(), isValid = false,
            )
        }
    }

    data class StatCacheStats(
        val size: Int, val hits: Long, val misses: Long,
        val invalidations: Long, val hitRate: Float,
    )
}

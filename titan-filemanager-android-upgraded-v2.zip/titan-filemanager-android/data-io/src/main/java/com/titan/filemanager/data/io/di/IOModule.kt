package com.titan.filemanager.data.io.di

import android.content.Context
import com.titan.filemanager.data.io.engine.IOOptimizationEngine
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object IOModule {

    @Provides
    @Singleton
    fun provideIOOptimizationEngine(@ApplicationContext context: Context): IOOptimizationEngine {
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
        return IOOptimizationEngine(context, scope)
    }
}

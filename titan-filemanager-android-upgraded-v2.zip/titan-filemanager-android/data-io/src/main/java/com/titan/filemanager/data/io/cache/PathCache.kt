package com.titan.filemanager.data.io.cache

import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * Canonical Path Cache — avoid expensive File.getCanonicalPath() syscalls.
 *
 * For 10K files = 0.5-2 seconds wasted on canonical path resolution.
 * Solution: cache permanently (paths rarely change).
 *
 * Technique #113: Avoid repeated canonical path resolution
 */
class PathCache(private val maxEntries: Int = 50_000) {

    private val canonicalCache = ConcurrentHashMap<String, String>(maxEntries, 0.75f)
    private val extensionCache = ConcurrentHashMap<String, String>(10_000, 0.75f)
    private val parentCache = ConcurrentHashMap<String, String>(10_000, 0.75f)
    private val canonicalHits = AtomicLong(0)
    private val canonicalMisses = AtomicLong(0)
    private val extHits = AtomicLong(0)
    private val extMisses = AtomicLong(0)

    fun getCanonical(path: String): String {
        canonicalCache[path]?.let { canonicalHits.incrementAndGet(); return it }
        canonicalMisses.incrementAndGet()
        val canonical = try { File(path).canonicalPath } catch (e: Exception) { path }
        if (canonicalCache.size < maxEntries) canonicalCache[path] = canonical
        return canonical
    }

    fun normalizePath(path: String): String {
        canonicalCache[path]?.let { return it }
        val normalized = normalizePathFast(path)
        if (canonicalCache.size < maxEntries) canonicalCache[path] = normalized
        return normalized
    }

    private fun normalizePathFast(path: String): String {
        if (path.isEmpty()) return path
        val parts = ArrayList<String>(16)
        var start = 0
        val len = path.length
        var i = 0
        while (i <= len) {
            if (i == len || path[i] == '/') {
                if (i > start) when (val seg = path.substring(start, i)) {
                    "." -> {}
                    ".." -> { if (parts.isNotEmpty()) parts.removeAt(parts.size - 1) }
                    else -> parts.add(seg)
                }
                start = i + 1
            }
            i++
        }
        return if (parts.isEmpty()) "/" else "/" + parts.joinToString("/")
    }

    fun getExtension(filename: String): String {
        extensionCache[filename]?.let { extHits.incrementAndGet(); return it }
        extMisses.incrementAndGet()
        val ext = extractExtension(filename)
        if (extensionCache.size < 10_000) extensionCache[filename] = ext
        return ext
    }

    fun getParent(path: String): String {
        parentCache[path]?.let { return it }
        val parent = path.substringBeforeLast('/', "")
        if (parent.isEmpty()) return "/"
        if (parentCache.size < 10_000) parentCache[path] = parent
        return parent
    }

    fun buildChildPath(parent: String, childName: String): String {
        val key = "$parent|$childName"
        canonicalCache[key]?.let { return it }
        val childPath = if (parent.endsWith('/')) "$parent$childName" else "$parent/$childName"
        if (canonicalCache.size < maxEntries) canonicalCache[key] = childPath
        return childPath
    }

    private fun extractExtension(filename: String): String {
        val lastDot = filename.lastIndexOf('.')
        val lastSlash = filename.lastIndexOf('/')
        return if (lastDot > lastSlash + 1 && lastDot < filename.length - 1)
            filename.substring(lastDot + 1).lowercase() else ""
    }

    fun invalidate(path: String) { canonicalCache.remove(path); parentCache.remove(path) }
    fun clear() { canonicalCache.clear(); extensionCache.clear(); parentCache.clear() }

    fun getStats() = PathCacheStats(
        canonicalCacheSize = canonicalCache.size,
        extensionCacheSize = extensionCache.size,
        canonicalHitRate = run {
            val total = canonicalHits.get() + canonicalMisses.get()
            if (total > 0) canonicalHits.get().toFloat() / total else 0f
        },
        extHitRate = run {
            val total = extHits.get() + extMisses.get()
            if (total > 0) extHits.get().toFloat() / total else 0f
        },
    )

    data class PathCacheStats(
        val canonicalCacheSize: Int, val extensionCacheSize: Int,
        val canonicalHitRate: Float, val extHitRate: Float,
    )
}

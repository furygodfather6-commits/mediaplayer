package com.titan.filemanager.data.io.buffered

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.*
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicLong

/**
 * Buffered I/O Engine — large buffers, thread-local reuse, NIO for large files.
 *
 * Small (<4KB): direct read. Medium (4KB-1MB): buffered stream. Large (>1MB): NIO channel.
 * Copy: zero-copy transferTo.
 *
 * Technique #116: Buffered I/O
 * Technique #95: Zero-copy (channel transfer)
 */
class BufferedIOEngine(private val defaultBufferSize: Int = 64 * 1024) {

    companion object {
        private const val UFS_BUFFER = 128 * 1024
        private val totalReads = AtomicLong(0)
        private val totalBytesRead = AtomicLong(0)
        private val bufferedReads = AtomicLong(0)
    }

    private val threadLocalBuffer = ThreadLocal.withInitial { ByteArray(defaultBufferSize) }

    suspend fun readFileOptimal(path: String, maxBytes: Long = Long.MAX_VALUE): ByteArray? =
        withContext(Dispatchers.IO) {
            totalReads.incrementAndGet(); bufferedReads.incrementAndGet()
            try {
                val file = File(path); val fileSize = file.length()
                if (fileSize == 0L) return@withContext ByteArray(0)
                val readSize = minOf(fileSize, maxBytes)
                when {
                    readSize < 4 * 1024 -> readSmall(path, readSize.toInt())
                    readSize < 1024 * 1024 -> readMedium(path, readSize.toInt())
                    else -> readLarge(path, readSize)
                }?.also { totalBytesRead.addAndGet(it.size.toLong()) }
            } catch (_: Exception) { null }
        }

    private fun readSmall(path: String, size: Int): ByteArray? = try { File(path).readBytes() } catch (_: Exception) { null }

    private fun readMedium(path: String, size: Int): ByteArray? = try {
        val output = ByteArray(size)
        val buffer = threadLocalBuffer.get()!!
        BufferedInputStream(FileInputStream(path), defaultBufferSize).use { bis ->
            var offset = 0; var remaining = size
            while (remaining > 0) {
                val read = bis.read(buffer, 0, minOf(remaining, buffer.size))
                if (read == -1) break
                System.arraycopy(buffer, 0, output, offset, read)
                offset += read; remaining -= read
            }
            if (offset > 0) output.copyOf(offset) else null
        }
    } catch (_: Exception) { null }

    private fun readLarge(path: String, size: Long): ByteArray? = try {
        FileInputStream(path).channel.use { channel ->
            val directBuf = ByteBuffer.allocateDirect(minOf(size.toInt(), UFS_BUFFER))
            val output = ByteArrayOutputStream(size.toInt())
            while (channel.position() < size) {
                directBuf.clear()
                val read = channel.read(directBuf)
                if (read == -1) break
                directBuf.flip()
                val chunk = ByteArray(read); directBuf.get(chunk); output.write(chunk)
            }
            output.toByteArray()
        }
    } catch (_: Exception) { null }

    suspend fun copyFileBuffered(source: String, dest: String, progressCallback: ((Long, Long) -> Unit)? = null): Boolean =
        withContext(Dispatchers.IO) {
            try {
                FileInputStream(source).channel.use { src ->
                    FileOutputStream(dest).channel.use { dst ->
                        val totalSize = src.size(); var transferred = 0L
                        while (transferred < totalSize) {
                            val chunk = src.transferTo(transferred, minOf(UFS_BUFFER.toLong(), totalSize - transferred), dst)
                            if (chunk <= 0) break
                            transferred += chunk; progressCallback?.invoke(transferred, totalSize)
                        }
                        transferred >= totalSize
                    }
                }
            } catch (_: Exception) { false }
        }

    fun getBufferedWriter(path: String) = BufferedWriter(FileWriter(path), defaultBufferSize)
    fun getBufferedReader(path: String) = BufferedReader(FileReader(path), defaultBufferSize)

    fun getStats() = BufferedIOStats(totalReads.get(), bufferedReads.get(), totalBytesRead.get(),
        if (totalReads.get() > 0) totalBytesRead.get() / totalReads.get() else 0L)

    data class BufferedIOStats(val totalReads: Long, val bufferedReads: Long, val totalBytesRead: Long, val avgBytesPerRead: Long)
}

package com.titan.filemanager.data.io.engine

import android.content.Context
import com.titan.filemanager.data.io.async.AsyncIOEngine
import com.titan.filemanager.data.io.buffered.BufferedIOEngine
import com.titan.filemanager.data.io.cache.DirListCache
import com.titan.filemanager.data.io.cache.MimeCache
import com.titan.filemanager.data.io.cache.PathCache
import com.titan.filemanager.data.io.cache.StatCache
import com.titan.filemanager.data.io.models.IOOperationType
import com.titan.filemanager.data.io.profiler.IOProfiler
import com.titan.filemanager.data.io.sequential.SequentialIOManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Master I/O Optimization Engine — single entry point for all I/O optimization.
 *
 * Coordinates all Phase L techniques:
 *   #109 Sequential disk access  → SequentialIOManager
 *   #110 Read-ahead strategy     → ReadAheadEngine
 *   #111 Batched system calls    → BatchedSyscallEngine
 *   #112 Avoid repeated stat()   → StatCache
 *   #113 Avoid canon path        → PathCache
 *   #114 Avoid MIME lookups      → MimeCache
 *   #115 Avoid dir listing       → DirListCache
 *   #116 Buffered I/O            → BufferedIOEngine
 *   #117 Async I/O               → AsyncIOEngine
 */
@Singleton
class IOOptimizationEngine @Inject constructor(
    context: Context,
    private val scope: CoroutineScope,
) {
    val sequentialIO = SequentialIOManager()
    val readAhead = ReadAheadEngine(scope)
    val batchedSyscall = BatchedSyscallEngine()
    val statCache = StatCache(maxEntries = 20_000, ttlMs = 10_000L)
    val pathCache = PathCache(maxEntries = 100_000)
    val mimeCache = MimeCache()
    val dirListCache = DirListCache(maxDirs = 500)
    val bufferedIO = BufferedIOEngine()
    val asyncIO = AsyncIOEngine(scope, statCache, maxConcurrentOps = 8)
    val profiler = IOProfiler()

    suspend fun scanDirectoryOptimized(dirPath: String): Array<String> = withContext(Dispatchers.IO) {
        val fingerprint = computeDirFingerprint(dirPath)
        val cached = dirListCache.getListingIfFresh(dirPath, fingerprint)
        if (cached != null) { Timber.d("DirList cache hit: $dirPath"); return@withContext cached }

        val names = profiler.measure(IOOperationType.READ_DIR, dirPath) {
            try { File(dirPath).list() ?: emptyArray() } catch (_: Exception) { emptyArray() }
        }
        dirListCache.putListing(dirPath, names, fingerprint)
        scope.launch { readAhead.triggerDirectoryReadAhead(dirPath, names) }
        names
    }

    fun getStatOptimized(path: String) = profiler.measure(IOOperationType.STAT, path) { statCache.getOrFetch(path) }

    fun getCanonicalPathOptimized(path: String) = profiler.measure(IOOperationType.PATH_RESOLVE, path) { pathCache.getCanonical(path) }

    fun getMimeOptimized(path: String) = profiler.measure(IOOperationType.MIME_DETECT, path) { mimeCache.getMimeForPath(path) }

    suspend fun batchStatOptimized(dirPath: String, names: Array<String>) = withContext(Dispatchers.IO) {
        val sorted = sequentialIO.reorderStatCalls(names.toList())
        batchedSyscall.batchStat(dirPath, sorted.toTypedArray())
    }

    suspend fun warmCachesForDirectory(dirPath: String, names: Array<String>) = withContext(Dispatchers.IO) {
        readAhead.warmPageCache(dirPath, names)
        batchedSyscall.warmInodeCache(names.take(100).map { pathCache.buildChildPath(dirPath, it) })
        names.forEach { name -> pathCache.buildChildPath(dirPath, name); pathCache.getExtension(name) }
        Timber.d("Caches warmed for $dirPath (${names.size} files)")
    }

    fun invalidatePath(path: String) {
        statCache.invalidate(path)
        statCache.invalidateParent(path) // FIX: now exists on StatCache
        dirListCache.invalidate(path)
        dirListCache.invalidateParent(path)
        pathCache.invalidate(path)
        readAhead.clear()
    }

    private fun computeDirFingerprint(dirPath: String): Long = try {
        val dir = File(dirPath)
        dir.lastModified() xor (dir.list()?.size?.toLong() ?: 0L)
    } catch (_: Exception) { -1L }

    fun getStats() = IOEngineStats(
        statCache.getStats(), pathCache.getStats(), mimeCache.getStats(),
        dirListCache.getStats(), readAhead.getStats(), batchedSyscall.getStats(),
        bufferedIO.getStats(), asyncIO.getStats(), profiler.getReport(),
    )

    fun destroy() { readAhead.clear(); statCache.clear(); dirListCache.clear(); pathCache.clear() }

    data class IOEngineStats(
        val statCache: StatCache.StatCacheStats,
        val pathCache: PathCache.PathCacheStats,
        val mimeCache: MimeCache.MimeCacheStats,
        val dirListCache: DirListCache.DirListCacheStats,
        val readAhead: ReadAheadStats,
        val batchedSyscall: BatchedSyscallEngine.BatchSyscallStats,
        val bufferedIO: BufferedIOEngine.BufferedIOStats,
        val asyncIO: AsyncIOEngine.AsyncIOStats,
        val profilerReport: IOProfiler.IOProfileReport,
    )
}

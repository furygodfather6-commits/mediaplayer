package com.titan.filemanager.data.io.async

import com.titan.filemanager.data.io.cache.StatCache
import com.titan.filemanager.data.io.models.IOOperationType
import com.titan.filemanager.data.io.models.IORequest
import com.titan.filemanager.data.io.models.IOResult
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.sync.Semaphore
import java.io.File
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * Async I/O Engine — non-blocking I/O via coroutines + priority scheduling.
 *
 * FIX: Original code created fresh StatCache() per call — defeated caching.
 * This version accepts injected StatCache for proper cache reuse.
 *
 * Technique #117: Async I/O
 * Technique #111: Batched operations
 */
class AsyncIOEngine(
    private val scope: CoroutineScope,
    private val statCache: StatCache,
    private val maxConcurrentOps: Int = 8,
) {
    private val semaphore = Semaphore(maxConcurrentOps)
    private val activeOps = AtomicInteger(0)
    private val completedOps = AtomicLong(0)

    fun statAsync(path: String, priority: Int = IORequest.PRIORITY_NORMAL, callback: (IOResult.StatResult?) -> Unit): Job =
        scope.launch(Dispatchers.IO) {
            semaphore.acquire(); activeOps.incrementAndGet()
            try {
                val result = statCache.getOrFetch(path)
                withContext(Dispatchers.Main) {
                    callback(IOResult.StatResult(
                        path = path, size = result.size, lastModified = result.lastModified,
                        isDirectory = result.isDirectory, isSymlink = result.isSymlink,
                        inode = result.inode, fromCache = false,
                    ))
                }
            } catch (_: Exception) { withContext(Dispatchers.Main) { callback(null) } }
            finally { activeOps.decrementAndGet(); completedOps.incrementAndGet(); semaphore.release() }
        }

    fun statBatchAsync(paths: List<String>, priority: Int = IORequest.PRIORITY_NORMAL): Flow<IOResult.StatResult> =
        channelFlow {
            paths.map { path ->
                async(Dispatchers.IO) {
                    semaphore.acquire()
                    try {
                        val result = statCache.getOrFetch(path)
                        send(IOResult.StatResult(
                            path = path, size = result.size, lastModified = result.lastModified,
                            isDirectory = result.isDirectory, isSymlink = result.isSymlink, inode = result.inode,
                        ))
                    } finally { semaphore.release() }
                }
            }.awaitAll()
        }.flowOn(Dispatchers.IO)

    fun readFilesAsync(requests: List<IORequest>, onResult: (String, ByteArray?) -> Unit) {
        requests.sortedBy { it.priority }.forEach { request ->
            scope.launch(Dispatchers.IO) {
                semaphore.acquire(); activeOps.incrementAndGet()
                try {
                    val data = try {
                        File(request.path).let { f -> if (f.length() < 10 * 1024 * 1024L) f.readBytes() else null }
                    } catch (_: Exception) { null }
                    withContext(Dispatchers.Main) { onResult(request.path, data) }
                } finally { activeOps.decrementAndGet(); completedOps.incrementAndGet(); semaphore.release() }
            }
        }
    }

    fun asyncScanPipeline(dirPath: String): Flow<IOResult> = channelFlow {
        val names = withContext(Dispatchers.IO) { File(dirPath).list() ?: emptyArray() }
        val statJobs = names.map { name ->
            async(Dispatchers.IO) {
                semaphore.acquire()
                try {
                    val fullPath = if (dirPath.endsWith('/')) "$dirPath$name" else "$dirPath/$name"
                    val result = statCache.getOrFetch(fullPath)
                    IOResult.StatResult(
                        path = fullPath, size = result.size, lastModified = result.lastModified,
                        isDirectory = result.isDirectory, isSymlink = result.isSymlink, inode = result.inode,
                    )
                } finally { semaphore.release() }
            }
        }
        statJobs.forEach { job -> try { send(job.await()) } catch (_: Exception) {} }
    }.flowOn(Dispatchers.IO)

    fun getStats() = AsyncIOStats(activeOps.get(), completedOps.get(), maxConcurrentOps, 0)

    data class AsyncIOStats(val activeOps: Int, val completedOps: Long, val maxConcurrentOps: Int, val queueSize: Int)
}

package com.titan.filemanager.data.io.sequential

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.FileInputStream
import java.util.concurrent.atomic.AtomicLong

/**
 * Sequential I/O Manager — sort I/O by path for sequential disk access.
 *
 * HDDs/SSDs/eMMC/UFS all perform better with sequential vs random access.
 * Strategy: sort by path (≈ filesystem order), group nearby files, hint kernel.
 *
 * Technique #109: Sequential disk access
 */
class SequentialIOManager {

    companion object {
        private const val SORT_THRESHOLD = 10
        private val totalOps = AtomicLong(0)
        private val sequentialOps = AtomicLong(0)
    }

    fun sortForSequentialAccess(paths: List<String>): List<String> =
        if (paths.size < SORT_THRESHOLD) paths
        else paths.sortedWith(compareBy({ it.substringBeforeLast('/') }, { it.substringAfterLast('/') }))

    fun groupByDirectory(paths: List<String>): Map<String, List<String>> =
        paths.groupBy { it.substringBeforeLast('/') }

    suspend fun readFilesSequential(paths: List<String>, bufferSize: Int = 64 * 1024): Map<String, ByteArray> =
        withContext(Dispatchers.IO) {
            val result = LinkedHashMap<String, ByteArray>(paths.size)
            sortForSequentialAccess(paths).forEach { path ->
                totalOps.incrementAndGet()
                try {
                    readFileBuffered(path, bufferSize)?.let { result[path] = it; sequentialOps.incrementAndGet() }
                } catch (_: Exception) {}
            }
            result
        }

    fun readFileBuffered(path: String, bufferSize: Int = 64 * 1024): ByteArray? = try {
        FileInputStream(path).use { fis ->
            val size = fis.channel.size()
            if (size == 0L) return ByteArray(0)
            val output = ByteArray(size.toInt())
            var offset = 0
            val buffer = ByteArray(minOf(bufferSize, size.toInt()))
            var bytesRead: Int
            while (fis.read(buffer).also { bytesRead = it } != -1) {
                System.arraycopy(buffer, 0, output, offset, bytesRead)
                offset += bytesRead
            }
            output
        }
    } catch (e: Exception) { null }

    fun reorderStatCalls(paths: List<String>): List<String> =
        if (paths.size < SORT_THRESHOLD) paths else paths.sorted()

    fun getEfficiencyRate(): Float {
        val total = totalOps.get()
        return if (total > 0) sequentialOps.get().toFloat() / total else 0f
    }
}

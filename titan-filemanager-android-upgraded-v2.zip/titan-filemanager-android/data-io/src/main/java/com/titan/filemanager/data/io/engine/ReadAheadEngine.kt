package com.titan.filemanager.data.io.engine

import com.titan.filemanager.data.io.models.IOOperationType
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.yield
import timber.log.Timber
import java.io.File
import java.io.FileInputStream
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.PriorityBlockingQueue
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicInteger

/**
 * Read-Ahead Engine — predictive pre-loading into OS page cache.
 *
 * Two levels:
 *   1. OS-level: read file headers → forces page cache warming
 *   2. App-level: store headers in app cache for MIME detection
 *
 * Technique #110: Read-ahead strategy
 * Technique #14: Speculative prefetch
 */
class ReadAheadEngine(private val scope: CoroutineScope) {

    companion object {
        private const val MAX_READAHEAD_BYTES = 16 * 1024 * 1024L
        private const val MAX_READAHEAD_FILES = 50
        private const val READAHEAD_HEADER_SIZE = 512
    }

    private val pageCache = ConcurrentHashMap<String, ByteArray>(100)
    private val pageCacheTotalBytes = AtomicLong(0)
    private val readAheadQueue = PriorityBlockingQueue<ReadAheadRequest>(100, compareBy { it.priority })
    private val readAheadHits = AtomicLong(0)
    private val readAheadMisses = AtomicLong(0)
    private var readAheadJob: Job? = null

    fun triggerDirectoryReadAhead(dirPath: String, fileNames: Array<String>, priority: Int = 2) {
        fileNames.sorted().take(MAX_READAHEAD_FILES).forEach { name ->
            val fullPath = if (dirPath.endsWith('/')) "$dirPath$name" else "$dirPath/$name"
            if (!pageCache.containsKey(fullPath)) {
                readAheadQueue.offer(ReadAheadRequest(fullPath, priority, headerOnly = true))
            }
        }
        startReadAheadWorker()
    }

    fun triggerViewportReadAhead(visiblePaths: List<String>) {
        visiblePaths.forEach { path ->
            if (!pageCache.containsKey(path)) readAheadQueue.offer(ReadAheadRequest(path, 1, headerOnly = false))
        }
        startReadAheadWorker()
    }

    fun isPreloaded(path: String): Boolean = pageCache.containsKey(path)

    fun getPreloaded(path: String): ByteArray? {
        val data = pageCache[path]
        if (data != null) readAheadHits.incrementAndGet() else readAheadMisses.incrementAndGet()
        return data
    }

    suspend fun warmPageCache(dirPath: String, fileNames: Array<String>, headerSize: Int = READAHEAD_HEADER_SIZE) =
        withContext(Dispatchers.IO) {
            val buffer = ByteArray(headerSize)
            fileNames.sorted().forEach { name ->
                try {
                    val fullPath = if (dirPath.endsWith('/')) "$dirPath$name" else "$dirPath/$name"
                    if (pageCache.containsKey(fullPath)) return@forEach
                    if (pageCacheTotalBytes.get() > MAX_READAHEAD_BYTES) return@withContext
                    FileInputStream(fullPath).use { fis ->
                        val read = fis.read(buffer, 0, headerSize)
                        if (read > 0) {
                            pageCache[fullPath] = buffer.copyOf(read)
                            pageCacheTotalBytes.addAndGet(read.toLong())
                        }
                    }
                } catch (_: Exception) {}
            }
        }

    private fun startReadAheadWorker() {
        if (readAheadJob?.isActive == true) return
        readAheadJob = scope.launch(Dispatchers.IO + CoroutineName("ReadAheadWorker")) {
            while (isActive) {
                val request = readAheadQueue.poll() ?: break
                if (pageCache.containsKey(request.path)) continue
                if (pageCacheTotalBytes.get() > MAX_READAHEAD_BYTES) evictOldEntries()
                try {
                    val data = if (request.headerOnly) readHeader(request.path) else readFull(request.path)
                    if (data != null) { pageCache[request.path] = data; pageCacheTotalBytes.addAndGet(data.size.toLong()) }
                } catch (_: Exception) {}
                yield()
            }
        }
    }

    private fun readHeader(path: String): ByteArray? = try {
        val buffer = ByteArray(READAHEAD_HEADER_SIZE)
        FileInputStream(path).use { fis ->
            val read = fis.read(buffer); if (read > 0) buffer.copyOf(read) else null
        }
    } catch (_: Exception) { null }

    private fun readFull(path: String): ByteArray? = try {
        val file = File(path)
        if (file.length() > 1024 * 1024) null else file.readBytes()
    } catch (_: Exception) { null }

    private fun evictOldEntries() {
        val toRemove = pageCache.size / 5; var removed = 0
        val iter = pageCache.entries.iterator()
        while (iter.hasNext() && removed < toRemove) {
            val entry = iter.next(); pageCacheTotalBytes.addAndGet(-entry.value.size.toLong()); iter.remove(); removed++
        }
    }

    fun getStats() = ReadAheadStats(
        pageCache.size, pageCacheTotalBytes.get(), readAheadHits.get(), readAheadMisses.get(),
        if (readAheadHits.get() + readAheadMisses.get() > 0) readAheadHits.get().toFloat() / (readAheadHits.get() + readAheadMisses.get()) else 0f,
    )

    fun clear() { readAheadJob?.cancel(); pageCache.clear(); pageCacheTotalBytes.set(0); readAheadQueue.clear() }

    data class ReadAheadRequest(val path: String, val priority: Int, val headerOnly: Boolean)
}

data class ReadAheadStats(
    val cachedFiles: Int, val cachedBytes: Long,
    val hitCount: Long, val missCount: Long, val hitRate: Float,
)

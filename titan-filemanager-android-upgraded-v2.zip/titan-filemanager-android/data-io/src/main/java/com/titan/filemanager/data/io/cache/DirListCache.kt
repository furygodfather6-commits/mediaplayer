package com.titan.filemanager.data.io.cache

import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * Directory Listing Cache — avoid repeated File.list() calls.
 *
 * TTL: 30 seconds + FileObserver invalidation + inode checksum.
 *
 * Technique #115: Avoid repeated directory listing
 * Technique #47: Directory snapshot cache
 */
class DirListCache(
    private val maxDirs: Int = 200,
    private val ttlMs: Long = 30_000L,
) {
    data class CachedListing(
        val path: String, val names: Array<String>,
        val cachedAt: Long, val checksum: Long,
    ) {
        val itemCount get() = names.size
        fun isExpired(ttl: Long) = System.currentTimeMillis() - cachedAt > ttl
        override fun equals(other: Any?): Boolean = this === other ||
            (other is CachedListing && path == other.path && cachedAt == other.cachedAt && names.contentEquals(other.names))
        override fun hashCode(): Int = 31 * (31 * path.hashCode() + names.contentHashCode()) + cachedAt.hashCode()
    }

    private val cache = ConcurrentHashMap<String, CachedListing>(maxDirs, 0.75f)
    private val accessOrder = ConcurrentHashMap<String, Long>(maxDirs)
    private val hits = AtomicLong(0)
    private val misses = AtomicLong(0)

    fun getListing(path: String): Array<String>? {
        val entry = cache[path] ?: run { misses.incrementAndGet(); return null }
        if (entry.isExpired(ttlMs)) { cache.remove(path); misses.incrementAndGet(); return null }
        hits.incrementAndGet()
        accessOrder[path] = System.currentTimeMillis()
        return entry.names
    }

    fun getListingIfFresh(path: String, currentChecksum: Long): Array<String>? {
        val entry = cache[path] ?: return null
        if (entry.checksum != currentChecksum || entry.isExpired(ttlMs)) {
            cache.remove(path); misses.incrementAndGet(); return null
        }
        hits.incrementAndGet()
        return entry.names
    }

    fun putListing(path: String, names: Array<String>, checksum: Long = 0L) {
        if (cache.size >= maxDirs) evictLRU()
        cache[path] = CachedListing(path, names, System.currentTimeMillis(), checksum)
        accessOrder[path] = System.currentTimeMillis()
    }

    fun isCached(path: String): Boolean = cache[path]?.let { !it.isExpired(ttlMs) } ?: false

    fun invalidate(path: String) { cache.remove(path); accessOrder.remove(path) }

    fun invalidateParent(childPath: String) {
        val parent = childPath.substringBeforeLast('/')
        if (parent.isNotEmpty()) invalidate(parent)
    }

    fun updateListingAdd(dirPath: String, newFileName: String) {
        val existing = cache[dirPath] ?: return
        if (!existing.names.contains(newFileName)) {
            cache[dirPath] = existing.copy(names = existing.names + newFileName, cachedAt = System.currentTimeMillis())
        }
    }

    fun updateListingRemove(dirPath: String, removedFileName: String) {
        val existing = cache[dirPath] ?: return
        cache[dirPath] = existing.copy(
            names = existing.names.filter { it != removedFileName }.toTypedArray(),
            cachedAt = System.currentTimeMillis(),
        )
    }

    private fun evictLRU() {
        accessOrder.entries.sortedBy { it.value }.take(maxOf(1, maxDirs / 10)).forEach { (path, _) ->
            cache.remove(path); accessOrder.remove(path)
        }
    }

    fun getStats() = DirListCacheStats(
        cachedDirs = cache.size, hits = hits.get(), misses = misses.get(),
        hitRate = if (hits.get() + misses.get() > 0) hits.get().toFloat() / (hits.get() + misses.get()) else 0f,
        totalCachedNames = cache.values.sumOf { it.itemCount },
    )

    fun clear() { cache.clear(); accessOrder.clear() }

    data class DirListCacheStats(
        val cachedDirs: Int, val hits: Long, val misses: Long,
        val hitRate: Float, val totalCachedNames: Int,
    )
}

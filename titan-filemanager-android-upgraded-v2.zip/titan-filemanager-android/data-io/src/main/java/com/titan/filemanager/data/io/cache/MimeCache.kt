package com.titan.filemanager.data.io.cache

import android.webkit.MimeTypeMap
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * MIME Type Cache — 3-tier: static map → runtime cache → MimeTypeMap API.
 *
 * Static map covers 95%+ of files (zero I/O).
 * Runtime cache handles rest (one-time lookup per extension).
 *
 * Technique #114: Avoid unnecessary MIME lookups
 * Technique #16: Lazy MIME detection
 */
class MimeCache {

    companion object {
        val STATIC_MIME_MAP = hashMapOf(
            "jpg" to "image/jpeg", "jpeg" to "image/jpeg", "png" to "image/png",
            "gif" to "image/gif", "webp" to "image/webp", "bmp" to "image/bmp",
            "heic" to "image/heic", "heif" to "image/heif", "svg" to "image/svg+xml",
            "ico" to "image/x-icon", "tiff" to "image/tiff", "tif" to "image/tiff",
            "mp4" to "video/mp4", "mkv" to "video/x-matroska", "avi" to "video/x-msvideo",
            "mov" to "video/quicktime", "wmv" to "video/x-ms-wmv", "flv" to "video/x-flv",
            "webm" to "video/webm", "3gp" to "video/3gpp", "ts" to "video/mp2t",
            "mp3" to "audio/mpeg", "aac" to "audio/aac", "ogg" to "audio/ogg",
            "wav" to "audio/wav", "flac" to "audio/flac", "m4a" to "audio/mp4",
            "wma" to "audio/x-ms-wma", "opus" to "audio/opus",
            "pdf" to "application/pdf", "doc" to "application/msword",
            "docx" to "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "xls" to "application/vnd.ms-excel",
            "xlsx" to "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "ppt" to "application/vnd.ms-powerpoint",
            "pptx" to "application/vnd.openxmlformats-officedocument.presentationml.presentation",
            "txt" to "text/plain", "csv" to "text/csv", "rtf" to "application/rtf",
            "zip" to "application/zip", "rar" to "application/x-rar-compressed",
            "7z" to "application/x-7z-compressed", "tar" to "application/x-tar",
            "gz" to "application/gzip", "bz2" to "application/x-bzip2", "xz" to "application/x-xz",
            "apk" to "application/vnd.android.package-archive",
            "kt" to "text/x-kotlin", "java" to "text/x-java", "py" to "text/x-python",
            "js" to "text/javascript", "ts" to "text/typescript", "html" to "text/html",
            "htm" to "text/html", "css" to "text/css", "xml" to "text/xml",
            "json" to "application/json", "yaml" to "text/yaml", "yml" to "text/yaml",
            "cpp" to "text/x-c++src", "c" to "text/x-csrc", "h" to "text/x-chdr",
            "sh" to "application/x-sh",
            "ttf" to "font/ttf", "otf" to "font/otf", "woff" to "font/woff", "woff2" to "font/woff2",
            "db" to "application/x-sqlite3", "sqlite" to "application/x-sqlite3",
            "torrent" to "application/x-bittorrent", "iso" to "application/x-iso9660-image",
        )
    }

    private val runtimeCache = ConcurrentHashMap<String, String>(500)
    private val staticHits = AtomicLong(0)
    private val runtimeHits = AtomicLong(0)
    private val lookupsDone = AtomicLong(0)

    fun getMimeForExtension(extension: String): String {
        if (extension.isEmpty()) return "application/octet-stream"
        val ext = extension.lowercase()
        STATIC_MIME_MAP[ext]?.let { staticHits.incrementAndGet(); return it }
        runtimeCache[ext]?.let { runtimeHits.incrementAndGet(); return it }
        lookupsDone.incrementAndGet()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
        runtimeCache[ext] = mime
        return mime
    }

    fun getMimeForPath(path: String): String {
        val lastDot = path.lastIndexOf('.')
        val lastSlash = path.lastIndexOf('/')
        if (lastDot <= lastSlash || lastDot >= path.length - 1) return "application/octet-stream"
        return getMimeForExtension(path.substring(lastDot + 1))
    }

    fun batchGetMime(extensions: List<String>): List<String> = extensions.map { getMimeForExtension(it) }

    fun getStats() = MimeCacheStats(
        staticHits = staticHits.get(), runtimeHits = runtimeHits.get(),
        externalLookups = lookupsDone.get(),
        staticHitRate = run {
            val total = staticHits.get() + runtimeHits.get() + lookupsDone.get()
            if (total > 0) staticHits.get().toFloat() / total else 0f
        },
        runtimeCacheSize = runtimeCache.size,
    )

    data class MimeCacheStats(
        val staticHits: Long, val runtimeHits: Long, val externalLookups: Long,
        val staticHitRate: Float, val runtimeCacheSize: Int,
    )
}

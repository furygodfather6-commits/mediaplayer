package com.titan.filemanager.data.io.profiler

import com.titan.filemanager.data.io.models.IOOperationType
import timber.log.Timber
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * I/O Profiler — tracks latency per operation type, detects slow I/O, generates recommendations.
 *
 * Technique #134: I/O latency tracking
 * Technique #141: Automatic tuning
 */
class IOProfiler {

    companion object {
        private const val SLOW_IO_THRESHOLD_MS = 100L
    }

    private val latencies = ConcurrentHashMap<IOOperationType, LatencyTracker>()
    private val slowOps = ArrayList<SlowIORecord>(100)
    private val slowOpsLock = Any()
    private val totalOps = AtomicLong(0)
    private val totalLatencyNs = AtomicLong(0)

    init { IOOperationType.values().forEach { latencies[it] = LatencyTracker(it) } }

    fun recordOperation(type: IOOperationType, path: String, durationNs: Long, fromCache: Boolean) {
        totalOps.incrementAndGet()
        totalLatencyNs.addAndGet(durationNs)
        latencies[type]?.record(durationNs, fromCache)
        val durationMs = durationNs / 1_000_000L
        if (durationMs > SLOW_IO_THRESHOLD_MS && !fromCache) recordSlowOp(type, path, durationMs)
    }

    inline fun <R> measure(type: IOOperationType, path: String, fromCache: Boolean = false, block: () -> R): R {
        val start = System.nanoTime()
        val result = block()
        recordOperation(type, path, System.nanoTime() - start, fromCache)
        return result
    }

    private fun recordSlowOp(type: IOOperationType, path: String, durationMs: Long) {
        Timber.w("SLOW I/O [$type]: ${durationMs}ms → $path")
        synchronized(slowOpsLock) { if (slowOps.size < 100) slowOps.add(SlowIORecord(type, path, durationMs)) }
    }

    fun getReport() = IOProfileReport(
        totalOps = totalOps.get(),
        avgLatencyMs = if (totalOps.get() > 0) (totalLatencyNs.get() / totalOps.get()) / 1_000_000L else 0L,
        perTypeStats = latencies.mapValues { (_, tracker) -> tracker.getStats() },
        slowOps = synchronized(slowOpsLock) { slowOps.toList() },
        recommendations = generateRecommendations(),
    )

    private fun generateRecommendations(): List<String> {
        val recs = mutableListOf<String>()
        latencies[IOOperationType.STAT]?.let { tracker ->
            val stats = tracker.getStats()
            if (stats.cacheHitRate < 0.5f) recs.add("StatCache hit rate low (${"%.1f".format(stats.cacheHitRate * 100)}%). Increase TTL or size.")
            if (stats.avgLatencyMs > 50) recs.add("High stat() latency (${stats.avgLatencyMs}ms avg). Consider batch stat.")
        }
        latencies[IOOperationType.MIME_DETECT]?.let { tracker ->
            val stats = tracker.getStats()
            if (stats.cacheHitRate < 0.9f) recs.add("MIME cache hit rate low. More extensions in static map.")
        }
        return recs
    }

    data class SlowIORecord(val type: IOOperationType, val path: String, val durationMs: Long, val timestamp: Long = System.currentTimeMillis())
    data class IOProfileReport(val totalOps: Long, val avgLatencyMs: Long, val perTypeStats: Map<IOOperationType, LatencyStats>, val slowOps: List<SlowIORecord>, val recommendations: List<String>)
}

class LatencyTracker(val type: IOOperationType) {
    private val totalOps = AtomicLong(0)
    private val cacheHits = AtomicLong(0)
    private val totalLatencyNs = AtomicLong(0)
    private val maxLatencyNs = AtomicLong(0)
    private val minLatencyNs = AtomicLong(Long.MAX_VALUE)

    fun record(durationNs: Long, fromCache: Boolean) {
        totalOps.incrementAndGet()
        totalLatencyNs.addAndGet(durationNs)
        if (fromCache) cacheHits.incrementAndGet()
        var current = maxLatencyNs.get()
        while (durationNs > current) { if (maxLatencyNs.compareAndSet(current, durationNs)) break; current = maxLatencyNs.get() }
        current = minLatencyNs.get()
        while (durationNs < current) { if (minLatencyNs.compareAndSet(current, durationNs)) break; current = minLatencyNs.get() }
    }

    fun getStats() = LatencyStats(
        type = type, totalOps = totalOps.get(),
        avgLatencyMs = if (totalOps.get() > 0) (totalLatencyNs.get() / totalOps.get()) / 1_000_000L else 0L,
        maxLatencyMs = maxLatencyNs.get() / 1_000_000L,
        minLatencyMs = if (minLatencyNs.get() == Long.MAX_VALUE) 0L else minLatencyNs.get() / 1_000_000L,
        cacheHitRate = if (totalOps.get() > 0) cacheHits.get().toFloat() / totalOps.get() else 0f,
    )
}

data class LatencyStats(
    val type: IOOperationType, val totalOps: Long, val avgLatencyMs: Long,
    val maxLatencyMs: Long, val minLatencyMs: Long, val cacheHitRate: Float,
)

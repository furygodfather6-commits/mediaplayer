package com.titan.filemanager.data.scalability.model

data class FileChunk(
    val chunkIndex: Int, val startOffset: Long, val endOffset: Long,
    val items: List<ScalableFileItem>, val isLastChunk: Boolean,
    val totalEstimated: Long, val loadedAt: Long = System.currentTimeMillis(),
) {
    val size: Int get() = items.size
    val isEmpty: Boolean get() = items.isEmpty()
}

data class ScalableFileItem(
    val stableId: Long, val nameOffset: Int, val nameLength: Short,
    val pathOffset: Int, val pathLength: Short, val size: Long,
    val lastModified: Long, val flags: Byte, val extensionCode: Short,
) {
    companion object {
        const val FLAG_DIR: Byte = 0x01
        const val FLAG_HIDDEN: Byte = 0x02
        const val FLAG_SYMLINK: Byte = 0x04
        const val INVALID_ID = -1L
        const val BYTES_PER_ITEM = 39
    }
    val isDirectory: Boolean get() = (flags.toInt() and FLAG_DIR.toInt()) != 0
    val isHidden: Boolean get() = (flags.toInt() and FLAG_HIDDEN.toInt()) != 0
    val isSymlink: Boolean get() = (flags.toInt() and FLAG_SYMLINK.toInt()) != 0
}

data class FilePage(
    val pageIndex: Int, val pageSize: Int, val items: List<ScalableFileItem>,
    val totalPages: Int, val totalItems: Long,
    val isLoading: Boolean = false, val fromCache: Boolean = false,
) {
    val startIndex: Long get() = pageIndex.toLong() * pageSize
    val endIndex: Long get() = startIndex + items.size
    val hasMore: Boolean get() = pageIndex < totalPages - 1
}

sealed class LoadingState {
    data object Idle : LoadingState()
    data class Loading(val progress: Float, val loadedCount: Long, val totalEstimate: Long) : LoadingState()
    data class Loaded(val totalItems: Long, val durationMs: Long) : LoadingState()
    data class Error(val throwable: Throwable) : LoadingState()
}

data class IndexEntry(val key: String, val fileId: Long, val chunkIndex: Int, val offsetInChunk: Int, val sortKey: Long)

data class MemoryBudget(
    val totalBudgetBytes: Long, val chunkBufferBytes: Long, val indexBytes: Long,
    val cacheBytes: Long, val workingSetBytes: Long,
) {
    companion object {
        fun default(availableBytes: Long = 50 * 1024 * 1024L) = MemoryBudget(
            totalBudgetBytes = availableBytes, chunkBufferBytes = availableBytes / 4,
            indexBytes = availableBytes / 4, cacheBytes = availableBytes / 3,
            workingSetBytes = availableBytes / 6,
        )
    }
}

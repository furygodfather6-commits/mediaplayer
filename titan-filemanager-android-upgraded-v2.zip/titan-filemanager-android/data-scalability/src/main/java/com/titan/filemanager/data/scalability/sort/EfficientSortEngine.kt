package com.titan.filemanager.data.scalability.sort

import com.titan.filemanager.core.model.file.FileItem
import kotlinx.coroutines.*
import timber.log.Timber

/**
 * Efficient Sort Engine — strategy selection by size: TimSort → ParallelMergeSort → RadixSort.
 *
 * Technique #149: Efficient sorting for huge directories
 */
class EfficientSortEngine {

    companion object {
        private const val PARALLEL_THRESHOLD = 1_000
        private const val RADIX_THRESHOLD = 100_000
    }

    suspend fun sort(items: MutableList<FileItem>, sortOrder: SortOrder = SortOrder.NAME_ASC): List<FileItem> = withContext(Dispatchers.Default) {
        if (items.isEmpty()) return@withContext items
        val startMs = System.currentTimeMillis()
        val result = when {
            items.size < PARALLEL_THRESHOLD -> timSort(items, sortOrder)
            items.size < RADIX_THRESHOLD -> parallelMergeSort(items, sortOrder)
            else -> when (sortOrder) {
                SortOrder.SIZE_ASC, SortOrder.SIZE_DESC, SortOrder.DATE_ASC, SortOrder.DATE_DESC -> radixSort(items, sortOrder)
                else -> parallelMergeSort(items, sortOrder)
            }
        }
        Timber.d("Sort: ${items.size} items in ${System.currentTimeMillis() - startMs}ms")
        result
    }

    private fun timSort(items: MutableList<FileItem>, order: SortOrder): List<FileItem> = items.sortedWith(getComparator(order))

    private suspend fun parallelMergeSort(items: List<FileItem>, order: SortOrder): List<FileItem> = coroutineScope {
        val comparator = getComparator(order)
        val coreCount = Runtime.getRuntime().availableProcessors()
        val chunkSize = maxOf(items.size / coreCount, 100)
        val sortedChunks = items.chunked(chunkSize).map { chunk -> async(Dispatchers.Default) { chunk.sortedWith(comparator) } }.awaitAll()
        kWayMerge(sortedChunks, comparator)
    }

    private fun kWayMerge(sortedLists: List<List<FileItem>>, comparator: Comparator<FileItem>): List<FileItem> {
        if (sortedLists.isEmpty()) return emptyList(); if (sortedLists.size == 1) return sortedLists[0]
        val result = ArrayList<FileItem>(sortedLists.sumOf { it.size })
        val pointers = IntArray(sortedLists.size) { 0 }
        while (true) {
            var minIdx = -1; var minItem: FileItem? = null
            for (i in sortedLists.indices) {
                if (pointers[i] < sortedLists[i].size) {
                    val item = sortedLists[i][pointers[i]]
                    if (minItem == null || comparator.compare(item, minItem) < 0) { minItem = item; minIdx = i }
                }
            }
            if (minIdx == -1) break; result.add(minItem!!); pointers[minIdx]++
        }
        return result
    }

    private fun radixSort(items: List<FileItem>, order: SortOrder): List<FileItem> {
        val keys = LongArray(items.size) { i -> when (order) { SortOrder.SIZE_ASC, SortOrder.SIZE_DESC -> items[i].size.coerceAtLeast(0); SortOrder.DATE_ASC, SortOrder.DATE_DESC -> items[i].modifiedAt; else -> 0L } }
        val sortedIndices = radixSortIndices(keys)
        val sorted = sortedIndices.map { items[it] }
        return when (order) { SortOrder.SIZE_DESC, SortOrder.DATE_DESC -> sorted.reversed(); else -> sorted }.let { result -> val dirs = result.filter { it.isDirectory }; val files = result.filter { !it.isDirectory }; dirs + files }
    }

    private fun radixSortIndices(keys: LongArray): IntArray {
        val n = keys.size; var indices = IntArray(n) { it }; var temp = IntArray(n); val count = IntArray(256)
        for (shift in 0 until 64 step 8) {
            count.fill(0)
            for (i in 0 until n) { val bucket = ((keys[indices[i]] ushr shift) and 0xFFL).toInt(); count[bucket]++ }
            for (i in 1 until 256) count[i] += count[i - 1]
            for (i in n - 1 downTo 0) { val bucket = ((keys[indices[i]] ushr shift) and 0xFFL).toInt(); temp[--count[bucket]] = indices[i] }
            val swap = indices; indices = temp; temp = swap
        }
        return indices
    }

    private fun getComparator(order: SortOrder): Comparator<FileItem> = when (order) {
        SortOrder.NAME_ASC -> compareBy<FileItem> { if (it.isDirectory) 0 else 1 }.thenBy { it.name.lowercase() }
        SortOrder.NAME_DESC -> compareBy<FileItem> { if (it.isDirectory) 0 else 1 }.thenByDescending { it.name.lowercase() }
        SortOrder.SIZE_ASC -> compareBy<FileItem> { if (it.isDirectory) 0 else 1 }.thenBy { it.size }
        SortOrder.SIZE_DESC -> compareBy<FileItem> { if (it.isDirectory) 0 else 1 }.thenByDescending { it.size }
        SortOrder.DATE_ASC -> compareBy<FileItem> { if (it.isDirectory) 0 else 1 }.thenBy { it.modifiedAt }
        SortOrder.DATE_DESC -> compareBy<FileItem> { if (it.isDirectory) 0 else 1 }.thenByDescending { it.modifiedAt }
        SortOrder.TYPE_ASC -> compareBy<FileItem> { if (it.isDirectory) 0 else 1 }.thenBy { it.extension }
    }

    suspend fun sortBatch(directoriesItems: Map<String, List<FileItem>>, sortOrder: SortOrder): Map<String, List<FileItem>> = coroutineScope {
        directoriesItems.map { (path, items) -> async { path to sort(items.toMutableList(), sortOrder) } }.awaitAll().toMap()
    }

    enum class SortOrder { NAME_ASC, NAME_DESC, SIZE_ASC, SIZE_DESC, DATE_ASC, DATE_DESC, TYPE_ASC }
}

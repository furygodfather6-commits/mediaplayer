package com.titan.filemanager.data.scalability.memory

import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.data.scalability.model.MemoryBudget
import java.util.concurrent.atomic.AtomicLong

/**
 * Constant Memory Engine — fixed working set with LRU eviction, stays within budget.
 *
 * For 1M files: 50MB max (not 200MB+).
 *
 * Technique #146: Constant-memory algorithms
 */
class ConstantMemoryEngine(private val budget: MemoryBudget = MemoryBudget.default()) {

    private val currentUsageBytes = AtomicLong(0)
    private val peakUsageBytes = AtomicLong(0)
    private val workingSet = LinkedHashMap<String, FileItem>(1000, 0.75f, true)
    private val workingSetLock = Any()
    private val workingSetBytes = AtomicLong(0)

    companion object {
        private const val ITEM_SIZE_BYTES = 200L
        private fun maxWorkingSetSize(budget: MemoryBudget): Int = (budget.workingSetBytes / ITEM_SIZE_BYTES).toInt().coerceAtLeast(100)
    }

    private val maxWorkingSetItems = maxWorkingSetSize(budget)

    fun addToWorkingSet(item: FileItem) {
        synchronized(workingSetLock) {
            while (workingSet.size >= maxWorkingSetItems) {
                val lru = workingSet.entries.iterator().next(); workingSet.remove(lru.key)
                workingSetBytes.addAndGet(-ITEM_SIZE_BYTES); currentUsageBytes.addAndGet(-ITEM_SIZE_BYTES)
            }
            workingSet[item.path] = item; workingSetBytes.addAndGet(ITEM_SIZE_BYTES); currentUsageBytes.addAndGet(ITEM_SIZE_BYTES)
            var peak = peakUsageBytes.get(); val current = currentUsageBytes.get()
            while (current > peak) { if (peakUsageBytes.compareAndSet(peak, current)) break; peak = peakUsageBytes.get() }
        }
    }

    fun addBatch(items: List<FileItem>) { items.take(minOf(items.size, maxWorkingSetItems)).forEach { addToWorkingSet(it) } }
    fun getFromWorkingSet(path: String): FileItem? = synchronized(workingSetLock) { workingSet[path] }
    fun isInWorkingSet(path: String): Boolean = synchronized(workingSetLock) { workingSet.containsKey(path) }
    fun getWorkingSetSnapshot(): List<FileItem> = synchronized(workingSetLock) { workingSet.values.toList() }

    fun trimToSize(targetItems: Int) {
        synchronized(workingSetLock) {
            val toRemove = workingSet.size - targetItems; if (toRemove <= 0) return
            val iter = workingSet.entries.iterator(); repeat(toRemove) { if (iter.hasNext()) { iter.next(); iter.remove(); workingSetBytes.addAndGet(-ITEM_SIZE_BYTES); currentUsageBytes.addAndGet(-ITEM_SIZE_BYTES) } }
        }
    }

    fun isWithinBudget(): Boolean = currentUsageBytes.get() <= budget.totalBudgetBytes
    fun getUtilization(): Float = currentUsageBytes.get().toFloat() / budget.totalBudgetBytes

    fun getStats() = ConstantMemoryStats(
        synchronized(workingSetLock) { workingSet.size }, maxWorkingSetItems, currentUsageBytes.get(), peakUsageBytes.get(),
        budget.totalBudgetBytes, getUtilization(), isWithinBudget(),
    )

    fun clear() { synchronized(workingSetLock) { workingSet.clear(); workingSetBytes.set(0); currentUsageBytes.set(0) } }

    data class ConstantMemoryStats(
        val workingSetSize: Int, val maxWorkingSetSize: Int, val currentUsageBytes: Long, val peakUsageBytes: Long,
        val budgetBytes: Long, val utilization: Float, val isWithinBudget: Boolean,
    ) { val usageMB: Long get() = currentUsageBytes / 1024 / 1024; val budgetMB: Long get() = budgetBytes / 1024 / 1024 }
}

package com.titan.filemanager.data.scalability.index

import com.titan.filemanager.core.model.file.FileItem
import java.util.TreeMap
import java.util.concurrent.locks.ReentrantReadWriteLock
import kotlin.concurrent.read
import kotlin.concurrent.write

/**
 * O(log n) Index Engine — TreeMap-based sorted indexes for range/prefix queries.
 *
 * Technique #148: O(log n) indexing
 */
class LogNIndexEngine {

    private val nameIndex = TreeMap<String, FileItem>(String.CASE_INSENSITIVE_ORDER)
    private val sizeIndex = TreeMap<Long, MutableList<FileItem>>()
    private val dateIndex = TreeMap<Long, MutableList<FileItem>>()
    private val extIndex = TreeMap<String, MutableList<FileItem>>()
    private val rwLock = ReentrantReadWriteLock()

    fun buildIndex(items: List<FileItem>) { rwLock.write { nameIndex.clear(); sizeIndex.clear(); dateIndex.clear(); extIndex.clear(); items.forEach { addToIndexes(it) } } }
    fun addItem(item: FileItem) { rwLock.write { addToIndexes(item) } }
    fun removeItem(item: FileItem) { rwLock.write { nameIndex.remove(item.name); sizeIndex[item.size]?.remove(item); dateIndex[item.modifiedAt]?.remove(item); extIndex[item.extension]?.remove(item) } }

    private fun addToIndexes(item: FileItem) {
        nameIndex[item.name] = item
        sizeIndex.getOrPut(item.size) { mutableListOf() }.add(item)
        dateIndex.getOrPut(item.modifiedAt) { mutableListOf() }.add(item)
        if (item.extension.isNotEmpty()) extIndex.getOrPut(item.extension) { mutableListOf() }.add(item)
    }

    fun findByName(name: String): FileItem? = rwLock.read { nameIndex[name] }
    fun findByNameRange(from: String, to: String): List<FileItem> = rwLock.read { nameIndex.subMap(from, true, to, true).values.toList() }

    fun findByPrefix(prefix: String): List<FileItem> = rwLock.read {
        if (prefix.isEmpty()) nameIndex.values.toList()
        else { val prefixEnd = prefix.dropLast(1) + (prefix.last().code + 1).toChar(); nameIndex.subMap(prefix, true, prefixEnd, false).values.toList() }
    }

    fun findBySizeRange(min: Long, max: Long): List<FileItem> = rwLock.read { sizeIndex.subMap(min, true, max, true).values.flatten() }
    fun findByDateRange(from: Long, to: Long): List<FileItem> = rwLock.read { dateIndex.subMap(from, true, to, true).values.flatten() }
    fun findByExtension(ext: String): List<FileItem> = rwLock.read { extIndex[ext.lowercase()]?.toList() ?: emptyList() }
    fun findNearest(name: String): FileItem? = rwLock.read { nameIndex[name] ?: nameIndex.ceilingEntry(name)?.value ?: nameIndex.floorEntry(name)?.value }

    fun getAllSorted(sortBy: SortKey = SortKey.NAME, ascending: Boolean = true): List<FileItem> = rwLock.read {
        val sorted = when (sortBy) {
            SortKey.NAME -> nameIndex.values.toList()
            SortKey.SIZE -> sizeIndex.values.flatten()
            SortKey.DATE -> dateIndex.values.flatten()
            SortKey.EXT -> extIndex.values.flatten().sortedBy { it.extension }
        }
        val dirsFirst = sorted.sortedWith(compareByDescending<FileItem> { it.isDirectory })
        if (ascending) dirsFirst else dirsFirst.reversed()
    }

    fun getSortedPage(fromName: String?, pageSize: Int): List<FileItem> = rwLock.read {
        if (fromName == null) nameIndex.values.take(pageSize) else nameIndex.tailMap(fromName).values.take(pageSize)
    }

    fun size(): Int = rwLock.read { nameIndex.size }

    fun getStats(): IndexStats = rwLock.read { IndexStats(nameIndex.size, extIndex.size, sizeIndex.size, dateIndex.size, (nameIndex.size * 50L / 1024 / 1024).toInt()) }
    fun clear() { rwLock.write { nameIndex.clear(); sizeIndex.clear(); dateIndex.clear(); extIndex.clear() } }

    enum class SortKey { NAME, SIZE, DATE, EXT }
    data class IndexStats(val totalItems: Int, val extensionCount: Int, val sizeRangeCount: Int, val dateRangeCount: Int, val memEstimateMB: Int)
}

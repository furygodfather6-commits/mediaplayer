package com.titan.filemanager.data.scalability.engine

import android.content.Context
import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.data.scalability.identity.StableIdManager
import com.titan.filemanager.data.scalability.index.LogNIndexEngine
import com.titan.filemanager.data.scalability.loading.IncrementalLoader
import com.titan.filemanager.data.scalability.lookup.O1LookupEngine
import com.titan.filemanager.data.scalability.memory.ConstantMemoryEngine
import com.titan.filemanager.data.scalability.million.MillionFileEngine
import com.titan.filemanager.data.scalability.model.MemoryBudget
import com.titan.filemanager.data.scalability.sort.EfficientSortEngine
import com.titan.filemanager.data.scalability.stream.StreamingDataModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Master Scalability Engine — single entry point for all Phase P features.
 *
 * Strategy selection by directory size:
 *   ≤500: load all + sort + O(1) index
 *   ≤50K: incremental + LogN index
 *   >50K: chunked streaming + sparse index + constant memory
 *
 * #142 Million-file → MillionFileEngine
 * #143 Incremental → IncrementalLoader
 * #144 Streaming → StreamingDataModel
 * #145 Stable IDs → StableIdManager
 * #146 Constant memory → ConstantMemoryEngine
 * #147 O(1) lookup → O1LookupEngine
 * #148 O(log n) index → LogNIndexEngine
 * #149 Efficient sort → EfficientSortEngine
 */
@Singleton
class ScalabilityEngine @Inject constructor(context: Context) {

    companion object {
        private const val SMALL_DIR = 500
        private const val LARGE_DIR = 50_000
    }

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private val budget = MemoryBudget.default(getAvailableMemory(context))

    val millionFileEngine = MillionFileEngine(budget)
    val incrementalLoader = IncrementalLoader()
    val streamingModel = StreamingDataModel()
    val stableIdManager = StableIdManager()
    val constantMemory = ConstantMemoryEngine(budget)
    val lookupEngine = O1LookupEngine()
    val indexEngine = LogNIndexEngine()
    val sortEngine = EfficientSortEngine()

    fun loadDirectory(dirPath: String): Flow<DirectoryLoadEvent> = flow {
        emit(DirectoryLoadEvent.Started(dirPath))
        val estimatedSize = quickEstimateSize(dirPath)
        emit(DirectoryLoadEvent.SizeEstimated(estimatedSize))
        Timber.d("Loading: $dirPath estimated=$estimatedSize")
        when {
            estimatedSize <= SMALL_DIR -> loadSmall(dirPath).collect { emit(it) }
            estimatedSize <= LARGE_DIR -> loadMedium(dirPath).collect { emit(it) }
            else -> loadMassive(dirPath).collect { emit(it) }
        }
    }

    private fun loadSmall(dirPath: String): Flow<DirectoryLoadEvent> = flow {
        incrementalLoader.loadIncremental(dirPath).collect { batch ->
            when (batch.batchType) {
                IncrementalLoader.BatchType.IMMEDIATE, IncrementalLoader.BatchType.FAST, IncrementalLoader.BatchType.BACKGROUND -> {
                    val itemsWithIds = stableIdManager.applyStableIds(batch.items)
                    lookupEngine.indexItems(itemsWithIds)
                    emit(DirectoryLoadEvent.Batch(itemsWithIds, batch.progress, batch.batchType == IncrementalLoader.BatchType.IMMEDIATE))
                }
                IncrementalLoader.BatchType.COMPLETE -> emit(DirectoryLoadEvent.Complete(batch.totalExpected.toLong(), batch.elapsedMs))
                else -> {}
            }
        }
    }

    private fun loadMedium(dirPath: String): Flow<DirectoryLoadEvent> = flow {
        val allItems = mutableListOf<FileItem>()
        incrementalLoader.loadIncremental(dirPath).collect { batch ->
            when (batch.batchType) {
                IncrementalLoader.BatchType.IMMEDIATE -> {
                    val items = stableIdManager.applyStableIds(batch.items); lookupEngine.indexItems(items); allItems.addAll(items)
                    emit(DirectoryLoadEvent.Batch(items, batch.progress, true))
                }
                IncrementalLoader.BatchType.FAST, IncrementalLoader.BatchType.BACKGROUND -> {
                    val items = stableIdManager.applyStableIds(batch.items); lookupEngine.indexItems(items); allItems.addAll(items)
                    emit(DirectoryLoadEvent.Batch(items, batch.progress, false))
                }
                IncrementalLoader.BatchType.COMPLETE -> {
                    indexEngine.buildIndex(allItems)
                    emit(DirectoryLoadEvent.Complete(allItems.size.toLong(), batch.elapsedMs))
                }
                else -> {}
            }
        }
    }

    private fun loadMassive(dirPath: String): Flow<DirectoryLoadEvent> = flow {
        millionFileEngine.streamDirectory(dirPath).collect { chunk ->
            if (chunk.isLastChunk) { emit(DirectoryLoadEvent.Complete(millionFileEngine.getLoadedCount(), 0)); return@collect }
            val fileItems = chunk.items.mapIndexed { idx, item ->
                FileItem(path = "", name = "item_${chunk.startOffset + idx}", stableId = item.stableId,
                    size = if (item.size < 0) 0L else item.size, modifiedAt = item.lastModified,
                    isDirectory = item.isDirectory, isHidden = item.isHidden)
            }
            constantMemory.addBatch(fileItems)
            emit(DirectoryLoadEvent.Chunk(chunk.chunkIndex, fileItems,
                if (chunk.totalEstimated > 0) chunk.endOffset.toFloat() / chunk.totalEstimated else 0f, chunk.totalEstimated))
        }
    }

    suspend fun sortItems(items: List<FileItem>, sortOrder: EfficientSortEngine.SortOrder): List<FileItem> =
        if (items.size > 1000 && indexEngine.size() == items.size) {
            indexEngine.getAllSorted(when (sortOrder) {
                EfficientSortEngine.SortOrder.NAME_ASC, EfficientSortEngine.SortOrder.NAME_DESC -> LogNIndexEngine.SortKey.NAME
                EfficientSortEngine.SortOrder.SIZE_ASC, EfficientSortEngine.SortOrder.SIZE_DESC -> LogNIndexEngine.SortKey.SIZE
                EfficientSortEngine.SortOrder.DATE_ASC, EfficientSortEngine.SortOrder.DATE_DESC -> LogNIndexEngine.SortKey.DATE
                else -> LogNIndexEngine.SortKey.NAME
            })
        } else sortEngine.sort(items.toMutableList(), sortOrder)

    fun findFile(path: String): FileItem? = lookupEngine.findByPath(path)
    fun searchByPrefix(prefix: String): List<FileItem> = indexEngine.findByPrefix(prefix)
    fun getStableId(path: String): Long = stableIdManager.getStableId(path)

    private fun quickEstimateSize(dirPath: String): Int = try { java.io.File(dirPath).list()?.size ?: 0 } catch (_: Exception) { 0 }
    private fun getAvailableMemory(context: Context): Long = minOf(Runtime.getRuntime().maxMemory() / 4, 50 * 1024 * 1024L)

    fun getStats() = ScalabilityStats(
        millionEngine = MillionEngineStats(millionFileEngine.getTotalCount(), millionFileEngine.getLoadedCount(), millionFileEngine.getSparseIndexSize()),
        lookupStats = lookupEngine.getStats(), indexStats = indexEngine.getStats(),
        memoryStats = constantMemory.getStats(), stableIdStats = stableIdManager.getStats(),
    )

    fun destroy() { millionFileEngine.reset(); lookupEngine.clear(); indexEngine.clear(); constantMemory.clear(); stableIdManager.clear(); streamingModel.clear() }

    sealed class DirectoryLoadEvent {
        data class Started(val path: String) : DirectoryLoadEvent()
        data class SizeEstimated(val count: Int) : DirectoryLoadEvent()
        data class Batch(val items: List<FileItem>, val progress: Float, val isFirstBatch: Boolean) : DirectoryLoadEvent()
        data class Chunk(val chunkIndex: Int, val items: List<FileItem>, val progress: Float, val totalEstimated: Long) : DirectoryLoadEvent()
        data class Complete(val totalItems: Long, val durationMs: Long) : DirectoryLoadEvent()
        data class Error(val throwable: Throwable) : DirectoryLoadEvent()
    }

    data class ScalabilityStats(
        val millionEngine: MillionEngineStats, val lookupStats: O1LookupEngine.LookupStats,
        val indexStats: LogNIndexEngine.IndexStats, val memoryStats: ConstantMemoryEngine.ConstantMemoryStats,
        val stableIdStats: StableIdManager.StableIdStats,
    )

    data class MillionEngineStats(val totalTracked: Long, val loaded: Long, val sparseIndexSize: Int)
}

package com.titan.filemanager.data.scalability.stream

import com.titan.filemanager.data.scalability.model.FilePage
import com.titan.filemanager.data.scalability.model.ScalableFileItem
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import timber.log.Timber
import java.io.File
import java.util.concurrent.ConcurrentHashMap

/**
 * Streaming Data Model — paged loading for millions of files in RecyclerView.
 *
 * Never holds more than maxLoadedPages pages in memory.
 *
 * Technique #144: Streaming data model
 * Technique #146: Constant-memory algorithms
 */
class StreamingDataModel(private val config: StreamConfig = StreamConfig()) {

    data class StreamConfig(
        val pageSize: Int = 200, val maxLoadedPages: Int = 5,
        val prefetchPages: Int = 2, val stalePageEvictMs: Long = 30_000L,
    )

    private val pageCache = ConcurrentHashMap<Int, CachedPage>(config.maxLoadedPages * 2)
    private val pageAccessTime = ConcurrentHashMap<Int, Long>()
    private var currentDirPath: String = ""
    private var totalItems: Long = 0L
    private var allNames: List<String> = emptyList()
    private val loadingPages = ConcurrentHashMap<Int, Job>()

    data class CachedPage(val page: FilePage, val loadedAt: Long = System.currentTimeMillis())

    suspend fun initStream(dirPath: String) = withContext(Dispatchers.IO) {
        currentDirPath = dirPath; pageCache.clear(); pageAccessTime.clear()
        allNames = try { File(dirPath).list()?.toList() ?: emptyList() } catch (_: Exception) { emptyList() }
        totalItems = allNames.size.toLong()
        Timber.d("Stream initialized: $totalItems items in $dirPath")
    }

    fun getPage(pageIndex: Int): Flow<FilePage> = flow {
        pageCache[pageIndex]?.let { pageAccessTime[pageIndex] = System.currentTimeMillis(); emit(it.page); return@flow }
        emit(FilePage(pageIndex, config.pageSize, emptyList(), getTotalPages(), totalItems, isLoading = true))
        val page = loadPage(pageIndex); cachePageWithEviction(pageIndex, page); emit(page); prefetchAdjacentPages(pageIndex)
    }.flowOn(Dispatchers.IO)

    private suspend fun loadPage(pageIndex: Int): FilePage = withContext(Dispatchers.IO) {
        val startIndex = pageIndex * config.pageSize; val endIndex = minOf(startIndex + config.pageSize, allNames.size)
        if (startIndex >= allNames.size) return@withContext FilePage(pageIndex, config.pageSize, emptyList(), getTotalPages(), totalItems)
        val pageNames = allNames.subList(startIndex, endIndex); val sep = if (currentDirPath.endsWith('/')) "" else "/"
        val items = pageNames.mapIndexed { localIdx, name ->
            val path = "$currentDirPath$sep$name"; val file = File(path)
            ScalableFileItem(
                stableId = (startIndex + localIdx).toLong(), nameOffset = localIdx * 256,
                nameLength = name.length.toShort(), pathOffset = localIdx * 4096, pathLength = path.length.toShort(),
                size = if (file.isFile) file.length() else -1L, lastModified = file.lastModified(),
                flags = buildFlags(file, name), extensionCode = getExtensionCode(name),
            )
        }
        FilePage(pageIndex, config.pageSize, items, getTotalPages(), totalItems, fromCache = false)
    }

    private fun prefetchAdjacentPages(currentPage: Int) {
        val totalPages = getTotalPages()
        for (ahead in 1..config.prefetchPages) {
            val nextPage = currentPage + ahead
            if (nextPage < totalPages && !pageCache.containsKey(nextPage) && !loadingPages.containsKey(nextPage)) {
                loadingPages[nextPage] = CoroutineScope(Dispatchers.IO).launch { val page = loadPage(nextPage); cachePageWithEviction(nextPage, page); loadingPages.remove(nextPage) }
            }
        }
    }

    private fun cachePageWithEviction(pageIndex: Int, page: FilePage) {
        if (pageCache.size >= config.maxLoadedPages) { pageAccessTime.entries.minByOrNull { it.value }?.key?.let { pageCache.remove(it); pageAccessTime.remove(it) } }
        pageCache[pageIndex] = CachedPage(page); pageAccessTime[pageIndex] = System.currentTimeMillis()
    }

    fun onVisibleRangeChanged(firstVisible: Int, lastVisible: Int) {
        val firstPage = firstVisible / config.pageSize; val lastPage = lastVisible / config.pageSize
        loadingPages.entries.toList().forEach { (page, job) -> if (page < firstPage - 2 || page > lastPage + config.prefetchPages + 1) { job.cancel(); loadingPages.remove(page) } }
        pageCache.keys.toList().forEach { page -> if (page < firstPage - 3 || page > lastPage + config.prefetchPages + 2) { pageCache.remove(page); pageAccessTime.remove(page) } }
    }

    fun getTotalPages(): Int = if (totalItems == 0L) 0 else ((totalItems + config.pageSize - 1) / config.pageSize).toInt()
    fun getTotalItems(): Long = totalItems

    private fun buildFlags(file: File, name: String): Byte {
        var flags = 0.toByte()
        if (file.isDirectory) flags = (flags.toInt() or ScalableFileItem.FLAG_DIR.toInt()).toByte()
        if (name.startsWith('.')) flags = (flags.toInt() or ScalableFileItem.FLAG_HIDDEN.toInt()).toByte()
        return flags
    }

    private fun getExtensionCode(name: String): Short {
        val lastDot = name.lastIndexOf('.'); if (lastDot < 0) return 0
        return when (name.substring(lastDot + 1).lowercase()) {
            "jpg", "jpeg" -> 1; "png" -> 2; "gif" -> 3; "webp" -> 4
            "mp4" -> 10; "mkv" -> 11; "avi" -> 12; "mp3" -> 20
            "pdf" -> 30; "zip" -> 40; "apk" -> 41; "txt" -> 50; else -> -1
        }
    }

    fun clear() { pageCache.clear(); pageAccessTime.clear(); loadingPages.values.forEach { it.cancel() }; loadingPages.clear(); allNames = emptyList(); totalItems = 0L }
}

package com.titan.filemanager.data.scalability.lookup

import com.titan.filemanager.core.model.file.FileItem
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * O(1) Lookup Engine — hash-based instant lookups by path, ID, name.
 *
 * Technique #147: O(1) lookups
 */
class O1LookupEngine {

    private val pathIndex = ConcurrentHashMap<String, FileItem>(10_000, 0.75f)
    private val idIndex = ConcurrentHashMap<Long, FileItem>(10_000, 0.75f)
    private val dirIndex = ConcurrentHashMap<String, MutableList<String>>(1000, 0.75f)
    private val nameIndex = ConcurrentHashMap<String, FileItem>(10_000, 0.75f)
    private val hits = AtomicLong(0)
    private val misses = AtomicLong(0)

    fun indexItems(items: List<FileItem>) { items.forEach { indexItem(it) } }

    fun indexItem(item: FileItem) {
        pathIndex[item.path] = item; idIndex[item.stableId] = item
        val dirPath = item.path.substringBeforeLast('/')
        dirIndex.getOrPut(dirPath) { mutableListOf() }.let { list -> synchronized(list) { if (!list.contains(item.name)) list.add(item.name) } }
        nameIndex["$dirPath:${item.name}"] = item
    }

    fun findByPath(path: String): FileItem? { val r = pathIndex[path]; if (r != null) hits.incrementAndGet() else misses.incrementAndGet(); return r }
    fun findById(stableId: Long): FileItem? { val r = idIndex[stableId]; if (r != null) hits.incrementAndGet() else misses.incrementAndGet(); return r }
    fun findByName(dirPath: String, name: String): FileItem? { val r = nameIndex["$dirPath:$name"]; if (r != null) hits.incrementAndGet() else misses.incrementAndGet(); return r }

    fun getChildren(dirPath: String): List<FileItem> = dirIndex[dirPath]?.let { names -> synchronized(names) { names.mapNotNull { nameIndex["$dirPath:$it"] } } } ?: emptyList()
    fun contains(path: String): Boolean = pathIndex.containsKey(path)

    fun update(updatedItem: FileItem) {
        pathIndex[updatedItem.path]?.let { old -> if (old.name != updatedItem.name) { val dirPath = old.path.substringBeforeLast('/'); dirIndex[dirPath]?.let { synchronized(it) { it.remove(old.name) } }; nameIndex.remove("$dirPath:${old.name}") } }
        indexItem(updatedItem)
    }

    fun remove(path: String) { val item = pathIndex.remove(path) ?: return; idIndex.remove(item.stableId); val dirPath = path.substringBeforeLast('/'); dirIndex[dirPath]?.let { synchronized(it) { it.remove(item.name) } }; nameIndex.remove("$dirPath:${item.name}") }

    fun findBatch(paths: List<String>): Map<String, FileItem> = paths.mapNotNull { p -> findByPath(p)?.let { p to it } }.toMap()

    fun computeDiff(newItems: List<FileItem>): IndexDiff {
        val newPaths = newItems.map { it.path }.toHashSet(); val oldPaths = pathIndex.keys.toHashSet()
        return IndexDiff(newItems.filter { it.path !in oldPaths }, oldPaths.filter { it !in newPaths }.mapNotNull { pathIndex[it] }, newItems.filter { item -> pathIndex[item.path]?.let { old -> old != item } ?: false })
    }

    fun getStats(): LookupStats { val total = hits.get() + misses.get(); return LookupStats(pathIndex.size, dirIndex.size, hits.get(), misses.get(), if (total > 0) hits.get().toFloat() / total else 0f, (pathIndex.size * 300L / 1024 / 1024).toInt()) }
    fun clear() { pathIndex.clear(); idIndex.clear(); dirIndex.clear(); nameIndex.clear() }

    data class IndexDiff(val added: List<FileItem>, val removed: List<FileItem>, val modified: List<FileItem>) { val isEmpty: Boolean get() = added.isEmpty() && removed.isEmpty() && modified.isEmpty(); val totalChanges: Int get() = added.size + removed.size + modified.size }
    data class LookupStats(val indexSize: Int, val dirCount: Int, val hits: Long, val misses: Long, val hitRate: Float, val memoryEstimateMB: Int)
}

package com.titan.filemanager.data.scalability.identity

import android.os.Build
import android.system.Os
import com.titan.filemanager.core.model.file.FileItem
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * Stable ID Manager — inode-based stable IDs for RecyclerView animations.
 *
 * Technique #145: Stable IDs
 * Technique #147: O(1) lookups
 */
class StableIdManager {

    private val pathToId = ConcurrentHashMap<String, Long>(10_000)
    private val idToPath = ConcurrentHashMap<Long, String>(10_000)
    private val idCounter = AtomicLong(Long.MIN_VALUE / 2)
    private val inodeCache = ConcurrentHashMap<String, Long>(10_000)

    fun getStableId(path: String): Long {
        pathToId[path]?.let { return it }
        val inode = getInode(path)
        val id = if (inode > 0) encodeInodeId(inode) else generateFallbackId(path)
        if (pathToId.size < 100_000) { pathToId[path] = id; idToPath[id] = path }
        return id
    }

    fun getStableIdsBatch(paths: List<String>): LongArray = LongArray(paths.size) { getStableId(paths[it]) }

    fun applyStableIds(items: List<FileItem>): List<FileItem> =
        items.map { item -> val sid = getStableId(item.path); if (sid != item.stableId) item.copy(stableId = sid) else item }

    private fun getInode(path: String): Long {
        inodeCache[path]?.let { return it }
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try { val stat = Os.lstat(path); val inode = stat.st_ino; if (inodeCache.size < 50_000) inodeCache[path] = inode; inode }
            catch (_: Exception) { -1L }
        } else -1L
    }

    private fun encodeInodeId(inode: Long): Long = inode or (1L shl 62)

    private fun generateFallbackId(path: String): Long {
        var hash = 14695981039346656037UL
        path.forEach { c -> hash = hash xor c.code.toULong(); hash = hash * 1099511628211UL }
        return (hash and 0x3FFFFFFFFFFFFFFFUL).toLong()
    }

    fun invalidate(path: String) { pathToId.remove(path)?.let { idToPath.remove(it) }; inodeCache.remove(path) }
    fun invalidateDirectory(dirPath: String) {
        val prefix = if (dirPath.endsWith('/')) dirPath else "$dirPath/"
        pathToId.keys.filter { it.startsWith(prefix) || it == dirPath }.forEach { invalidate(it) }
    }

    fun getStats() = StableIdStats(pathToId.size, inodeCache.size, idCounter.get())
    fun clear() { pathToId.clear(); idToPath.clear(); inodeCache.clear() }

    data class StableIdStats(val trackedPaths: Int, val cachedInodes: Int, val counterValue: Long)
}

package com.titan.filemanager.data.scalability.di

import android.content.Context
import com.titan.filemanager.data.scalability.engine.ScalabilityEngine
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object ScalabilityModule {

    @Provides
    @Singleton
    fun provideScalabilityEngine(@ApplicationContext context: Context): ScalabilityEngine {
        return ScalabilityEngine(context)
    }
}

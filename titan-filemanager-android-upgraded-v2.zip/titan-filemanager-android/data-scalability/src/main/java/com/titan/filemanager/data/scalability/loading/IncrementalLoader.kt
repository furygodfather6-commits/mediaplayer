package com.titan.filemanager.data.scalability.loading

import com.titan.filemanager.core.model.file.FileItem
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * Incremental Loader — 3-phase batched loading: IMMEDIATE → FAST → BACKGROUND.
 *
 * User sees first 30 items instantly, rest loads in background.
 *
 * Technique #143: Incremental loading
 * Technique #1: Progressive loading
 */
class IncrementalLoader(private val config: IncrementalConfig = IncrementalConfig()) {

    data class IncrementalConfig(
        val firstBatchSize: Int = 30, val secondBatchSize: Int = 100,
        val backgroundBatchSize: Int = 500, val maxInMemory: Int = 10_000,
    )

    private val isCancelled = AtomicBoolean(false)
    private val loadedCount = AtomicLong(0)

    fun loadIncremental(dirPath: String): Flow<IncrementalBatch> = flow {
        isCancelled.set(false); loadedCount.set(0); val startMs = System.currentTimeMillis()
        val allNames = withContext(Dispatchers.IO) { try { File(dirPath).list()?.toList() ?: emptyList() } catch (_: Exception) { emptyList() } }
        if (allNames.isEmpty()) { emit(IncrementalBatch(BatchType.COMPLETE, emptyList(), 0, 0)); return@flow }
        val totalCount = allNames.size
        emit(IncrementalBatch(BatchType.COUNT_KNOWN, emptyList(), totalCount, 0))

        // Phase 1: IMMEDIATE
        val firstItems = withContext(Dispatchers.IO) { buildItems(dirPath, allNames.take(config.firstBatchSize)) }
        loadedCount.addAndGet(firstItems.size.toLong())
        emit(IncrementalBatch(BatchType.IMMEDIATE, firstItems, totalCount, loadedCount.get(), elapsedMs = System.currentTimeMillis() - startMs))
        if (isCancelled.get() || allNames.size <= config.firstBatchSize) { emit(completeBatch(totalCount, startMs)); return@flow }

        // Phase 2: FAST
        val secondItems = withContext(Dispatchers.IO) { buildItems(dirPath, allNames.drop(config.firstBatchSize).take(config.secondBatchSize)) }
        loadedCount.addAndGet(secondItems.size.toLong())
        emit(IncrementalBatch(BatchType.FAST, secondItems, totalCount, loadedCount.get(), elapsedMs = System.currentTimeMillis() - startMs))
        if (isCancelled.get()) return@flow

        // Phase 3: BACKGROUND
        allNames.drop(config.firstBatchSize + config.secondBatchSize).chunked(config.backgroundBatchSize).forEachIndexed { batchIndex, batch ->
            if (isCancelled.get()) return@flow; yield()
            val items = withContext(Dispatchers.IO) { buildItems(dirPath, batch) }
            loadedCount.addAndGet(items.size.toLong())
            emit(IncrementalBatch(BatchType.BACKGROUND, items, totalCount, loadedCount.get(), batchIndex, System.currentTimeMillis() - startMs))
        }
        emit(completeBatch(totalCount, startMs))
    }.flowOn(Dispatchers.IO)

    private fun buildItems(dirPath: String, names: List<String>): List<FileItem> {
        val sep = if (dirPath.endsWith('/')) "" else "/"
        return names.mapNotNull { name ->
            try { val path = "$dirPath$sep$name"; val file = File(path)
                FileItem(path = path, name = name, stableId = path.hashCode().toLong(),
                    size = if (file.isFile) file.length() else 0L, modifiedAt = file.lastModified(),
                    isDirectory = file.isDirectory, isHidden = name.startsWith('.'))
            } catch (_: Exception) { null }
        }
    }

    private fun completeBatch(total: Int, startMs: Long) = IncrementalBatch(BatchType.COMPLETE, emptyList(), total, loadedCount.get(), elapsedMs = System.currentTimeMillis() - startMs)
    fun cancel() { isCancelled.set(true) }

    enum class BatchType { COUNT_KNOWN, IMMEDIATE, FAST, BACKGROUND, COMPLETE }

    data class IncrementalBatch(
        val batchType: BatchType, val items: List<FileItem>, val totalExpected: Int,
        val loadedSoFar: Long, val batchIndex: Int = 0, val elapsedMs: Long = 0,
    ) {
        val progress: Float get() = if (totalExpected > 0) loadedSoFar.toFloat() / totalExpected else 0f
        val isComplete: Boolean get() = batchType == BatchType.COMPLETE
    }
}

// :data:scalability — Enterprise Scalability Engine
// Ported from original codebase Phase P (Techniques #142-#149)
plugins {
    id("titan.android.library")
    id("titan.android.hilt")
}

android {
    namespace = "com.titan.filemanager.data.scalability"
}

dependencies {
    api(project(":core:common"))
    api(project(":core:model"))

    implementation(libs.kotlinx.coroutines.core)
    implementation(libs.timber)

    testImplementation(project(":core:testing"))
    testImplementation(libs.junit5)
    testImplementation(libs.truth)
    testImplementation(libs.robolectric)
}

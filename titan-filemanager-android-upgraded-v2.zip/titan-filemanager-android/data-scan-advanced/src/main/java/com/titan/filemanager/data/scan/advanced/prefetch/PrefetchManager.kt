package com.titan.filemanager.data.scan.advanced.prefetch

import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.data.scan.advanced.engine.DirectoryScanEngine
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.PriorityBlockingQueue

/**
 * Speculative Directory Prefetch.
 *
 * Ported techniques:
 *   #14  Speculative directory prefetch
 *   #15  Predictive next-folder loading
 *   #127 Predictive folder loading
 *
 * Learns from navigation history and pre-scans directories the user is
 * likely to open next — subdirectory prediction + sibling prediction +
 * history-based boost.
 */
class PrefetchManager(
    private val scanEngine: DirectoryScanEngine,
) {

    private val scope = CoroutineScope(
        Dispatchers.IO + SupervisorJob() +
            CoroutineName("PrefetchManager"),
    )

    private val prefetchCache = ConcurrentHashMap<String, PrefetchEntry>()

    private val prefetchQueue = PriorityBlockingQueue<PrefetchRequest>(
        50,
        compareByDescending { it.priority },
    )

    private val navigationHistory = ArrayDeque<String>(20)
    private val prefetchJobs = ConcurrentHashMap<String, Job>()

    companion object {
        private const val PREFETCH_CACHE_TTL = 30_000L
        private const val MAX_PREFETCH_CONCURRENT = 3
    }

    /** Called when user navigates to a directory — triggers prefetch. */
    fun onDirectoryOpened(path: String, children: List<FileItem>) {
        navigationHistory.addLast(path)
        if (navigationHistory.size > 20) navigationHistory.removeFirst()

        val predictions = predictNextDirectories(path, children)

        predictions.forEach { (predictedPath, priority) ->
            if (!prefetchCache.containsKey(predictedPath)) {
                prefetchQueue.offer(
                    PrefetchRequest(
                        path = predictedPath,
                        priority = priority,
                        requestedAt = System.currentTimeMillis(),
                    ),
                )
            }
        }
        startPrefetchWorkers()
    }

    private fun predictNextDirectories(
        currentPath: String,
        children: List<FileItem>,
    ): List<Pair<String, Float>> {
        val predictions = mutableListOf<Pair<String, Float>>()

        // Strategy 1: Subdirectories of current path
        val subdirs = children
            .filter { it.isDirectory && !it.isHidden }
            .take(5)

        subdirs.forEachIndexed { index, dir ->
            val priority = 1.0f - (index * 0.15f)
            predictions.add(Pair(dir.path, priority))
        }

        // Strategy 2: Sibling directories
        val parentPath = currentPath.substringBeforeLast('/')
        if (parentPath.isNotEmpty() && parentPath != currentPath) {
            predictions.add(Pair(parentPath, 0.3f))
        }

        // Strategy 3: History-based prediction
        val historyBoost = getHistoryBoost()
        return predictions
            .map { (path, priority) ->
                Pair(path, priority + (historyBoost[path] ?: 0f))
            }
            .sortedByDescending { it.second }
            .take(5)
    }

    private fun startPrefetchWorkers() {
        val slotsAvailable = MAX_PREFETCH_CONCURRENT - prefetchJobs.size

        repeat(slotsAvailable) {
            val request = prefetchQueue.poll() ?: return

            if (prefetchCache.containsKey(request.path)) return@repeat

            val job = scope.launch {
                try {
                    val result = scanEngine.scanForPrefetch(request.path)
                    if (result.isNotEmpty()) {
                        prefetchCache[request.path] = PrefetchEntry(
                            items = result,
                            timestamp = System.currentTimeMillis(),
                        )
                    }
                } catch (_: CancellationException) {
                    // Normal cancellation
                } finally {
                    prefetchJobs.remove(request.path)
                    if (prefetchQueue.isNotEmpty()) {
                        startPrefetchWorkers()
                    }
                }
            }
            prefetchJobs[request.path] = job
        }
    }

    /** Check if path has been prefetched — returns cached items if fresh. */
    fun getPrefetchedItems(path: String): List<FileItem>? {
        val entry = prefetchCache[path] ?: return null

        val age = System.currentTimeMillis() - entry.timestamp
        if (age > PREFETCH_CACHE_TTL) {
            prefetchCache.remove(path)
            return null
        }
        return entry.items
    }

    /** Cancel prefetch for irrelevant paths — called on navigation away. */
    fun cancelIrrelevantPrefetches(currentPath: String) {
        prefetchJobs.entries.toList().forEach { (path, job) ->
            if (!path.startsWith(currentPath)) {
                job.cancel()
                prefetchJobs.remove(path)
            }
        }
    }

    private fun getHistoryBoost(): Map<String, Float> {
        val boostMap = HashMap<String, Float>()
        navigationHistory.forEachIndexed { index, path ->
            val recency = index.toFloat() / navigationHistory.size
            boostMap[path] = (boostMap[path] ?: 0f) + recency * 0.2f
        }
        return boostMap
    }

    fun cleanup() {
        scope.cancel()
        prefetchCache.clear()
        prefetchJobs.clear()
    }

    data class PrefetchEntry(
        val items: List<FileItem>,
        val timestamp: Long,
    )

    data class PrefetchRequest(
        val path: String,
        val priority: Float,
        val requestedAt: Long,
    )
}

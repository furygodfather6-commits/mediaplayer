package com.titan.filemanager.data.scan.advanced.cache

import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.data.cache.advanced.model.DirectorySnapshot
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * Multi-level Directory Cache.
 *
 * Ported techniques:
 *   #40 L1 RAM cache
 *   #46 Directory snapshot cache
 *   #50 Hot-directory cache
 *   #52 Cache invalidation
 *   #53 LRU cache policy
 *
 * Holds an in-memory snapshot of recently scanned directories so navigation
 * back/forward is instant. Two tiers:
 *  - Hot cache  — frequently accessed, small (10 entries)
 *  - Warm cache — recently accessed, larger (maxEntries)
 */
class DirectoryCache(
    private val maxEntries: Int = 100,
    private val maxMemoryBytes: Long = 50 * 1024 * 1024L,
) {

    private val hotCache = LinkedHashMap<String, CacheEntry>(
        16, 0.75f, true,  // accessOrder = true (LRU)
    )

    private val warmCache = ConcurrentHashMap<String, CacheEntry>()

    private val currentMemoryUsage = AtomicLong(0L)
    private val cacheHits = AtomicLong(0L)
    private val cacheMisses = AtomicLong(0L)

    companion object {
        private const val HOT_CACHE_SIZE = 10
        private const val ENTRY_TTL = 5 * 60 * 1000L
        private const val HOT_CACHE_TTL = 30 * 1000L
    }

    /** Get snapshot — checks hot then warm, promotes warm→hot on frequent access. */
    @Synchronized
    fun getSnapshot(path: String): DirectorySnapshot? {
        val hotEntry = hotCache[path]
        if (hotEntry != null && !hotEntry.isExpired(HOT_CACHE_TTL)) {
            cacheHits.incrementAndGet()
            hotEntry.accessCount++
            return hotEntry.snapshot
        }

        val warmEntry = warmCache[path]
        if (warmEntry != null && !warmEntry.isExpired(ENTRY_TTL)) {
            cacheHits.incrementAndGet()
            warmEntry.accessCount++

            if (warmEntry.accessCount > 3) {
                promoteToHot(path, warmEntry)
            }
            return warmEntry.snapshot
        }

        cacheMisses.incrementAndGet()
        return null
    }

    /** Save snapshot to appropriate cache level. */
    @Synchronized
    fun saveSnapshot(path: String, snapshot: DirectorySnapshot) {
        val entry = CacheEntry(
            snapshot = snapshot,
            timestamp = System.currentTimeMillis(),
            estimatedSize = estimateSize(snapshot),
        )

        if (currentMemoryUsage.get() + entry.estimatedSize > maxMemoryBytes) {
            evict()
        }

        warmCache[path] = entry
        currentMemoryUsage.addAndGet(entry.estimatedSize)

        if (warmCache.size > maxEntries) {
            evictOldest()
        }
    }

    /** Invalidate cache for path — called when FileObserver detects changes. */
    @Synchronized
    fun invalidate(path: String) {
        hotCache.remove(path)?.let { currentMemoryUsage.addAndGet(-it.estimatedSize) }
        warmCache.remove(path)?.let { currentMemoryUsage.addAndGet(-it.estimatedSize) }
    }

    /** Invalidate parent path when child changes. */
    fun invalidateParent(childPath: String) {
        val parentPath = childPath.substringBeforeLast('/')
        if (parentPath.isNotEmpty()) {
            invalidate(parentPath)
        }
    }

    /** Pre-warm cache for frequently visited paths. */
    fun warmCache(paths: List<String>, snapshots: Map<String, DirectorySnapshot>) {
        paths.forEach { path ->
            snapshots[path]?.let { snapshot -> saveSnapshot(path, snapshot) }
        }
    }

    fun getStats(): CacheStats {
        val total = cacheHits.get() + cacheMisses.get()
        return CacheStats(
            hitCount = cacheHits.get(),
            missCount = cacheMisses.get(),
            hitRate = if (total > 0) cacheHits.get().toFloat() / total else 0f,
            hotCacheSize = hotCache.size,
            warmCacheSize = warmCache.size,
            memoryUsageBytes = currentMemoryUsage.get(),
        )
    }

    private fun promoteToHot(path: String, entry: CacheEntry) {
        if (hotCache.size >= HOT_CACHE_SIZE) {
            val oldest = hotCache.entries.first()
            hotCache.remove(oldest.key)
        }
        hotCache[path] = entry
    }

    private fun evict() {
        val now = System.currentTimeMillis()
        val expiredWarm = warmCache.entries
            .filter { now - it.value.timestamp > ENTRY_TTL }
            .map { it.key }

        expiredWarm.forEach { path ->
            warmCache.remove(path)?.let {
                currentMemoryUsage.addAndGet(-it.estimatedSize)
            }
        }

        while (currentMemoryUsage.get() > maxMemoryBytes * 0.8) {
            val largest = warmCache.entries.maxByOrNull { it.value.estimatedSize } ?: break
            warmCache.remove(largest.key)?.let {
                currentMemoryUsage.addAndGet(-it.estimatedSize)
            }
        }
    }

    private fun evictOldest() {
        val oldest = warmCache.entries.minByOrNull { it.value.timestamp }
        oldest?.let {
            warmCache.remove(it.key)
            currentMemoryUsage.addAndGet(-it.value.estimatedSize)
        }
    }

    private fun estimateSize(snapshot: DirectorySnapshot): Long =
        snapshot.items.size * 200L

    data class CacheEntry(
        val snapshot: DirectorySnapshot,
        val timestamp: Long,
        val estimatedSize: Long,
        var accessCount: Int = 0,
    ) {
        fun isExpired(ttl: Long): Boolean =
            System.currentTimeMillis() - timestamp > ttl
    }

    data class CacheStats(
        val hitCount: Long,
        val missCount: Long,
        val hitRate: Float,
        val hotCacheSize: Int,
        val warmCacheSize: Int,
        val memoryUsageBytes: Long,
    )
}

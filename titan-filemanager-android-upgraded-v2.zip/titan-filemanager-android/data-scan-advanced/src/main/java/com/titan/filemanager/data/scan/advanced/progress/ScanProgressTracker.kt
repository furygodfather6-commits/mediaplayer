package com.titan.filemanager.data.scan.advanced.progress

import android.util.Log
import com.titan.filemanager.data.scan.advanced.model.ScanStrategyType
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * Scan Performance Tracker.
 *
 * Ported techniques:
 *   #133 Scan time metrics
 *   #134 I/O latency tracking
 *   #140 Slow-folder detection
 *   #141 Automatic tuning
 *
 * Keeps a rolling history (max 10) of [ScanMetric] per path, surfaces slow
 * folders, and reports overall cache-hit / slow-scan rates.
 */
class ScanProgressTracker {

    companion object {
        private const val TAG = "ScanTracker"
        private const val SLOW_SCAN_THRESHOLD_MS = 2000L
    }

    private val scanHistory = ConcurrentHashMap<String, MutableList<ScanMetric>>()

    private val totalScans = AtomicLong(0L)
    private val slowScans = AtomicLong(0L)
    private val cacheHitScans = AtomicLong(0L)

    /** Record a completed scan. */
    fun recordScan(metric: ScanMetric) {
        totalScans.incrementAndGet()

        if (metric.durationMs > SLOW_SCAN_THRESHOLD_MS) {
            slowScans.incrementAndGet()
            Log.w(
                TAG,
                "SLOW SCAN: ${metric.path} took ${metric.durationMs}ms " +
                    "(${metric.itemCount} items, strategy=${metric.strategy})",
            )
        }

        if (metric.fromCache) {
            cacheHitScans.incrementAndGet()
        }

        val history = scanHistory.getOrPut(metric.path) { mutableListOf() }
        synchronized(history) {
            history.add(metric)
            if (history.size > 10) history.removeAt(0)
        }
    }

    /** Get average scan time for path — used for adaptive optimization. */
    fun getAverageScanTime(path: String): Long {
        val history = scanHistory[path] ?: return -1L
        return synchronized(history) {
            if (history.isEmpty()) -1L
            else history.map { it.durationMs }.average().toLong()
        }
    }

    fun getSlowFolders(): List<String> =
        scanHistory.entries
            .filter { (_, metrics) ->
                metrics.isNotEmpty() &&
                    metrics.map { it.durationMs }.average() > SLOW_SCAN_THRESHOLD_MS
            }
            .map { it.key }

    fun getStats(): PerformanceStats = PerformanceStats(
        totalScans = totalScans.get(),
        slowScans = slowScans.get(),
        cacheHitScans = cacheHitScans.get(),
        cacheHitRate = if (totalScans.get() > 0) {
            cacheHitScans.get().toFloat() / totalScans.get()
        } else 0f,
        slowScanRate = if (totalScans.get() > 0) {
            slowScans.get().toFloat() / totalScans.get()
        } else 0f,
    )

    fun reset() {
        scanHistory.clear()
        totalScans.set(0)
        slowScans.set(0)
        cacheHitScans.set(0)
    }
}

data class ScanMetric(
    val path: String,
    val itemCount: Int,
    val durationMs: Long,
    val strategy: ScanStrategyType,
    val fromCache: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
)

data class PerformanceStats(
    val totalScans: Long,
    val slowScans: Long,
    val cacheHitScans: Long,
    val cacheHitRate: Float,
    val slowScanRate: Float,
)

package com.titan.filemanager.data.scan.advanced.walker

import android.util.Log
import java.io.File

/**
 * Native Directory Walker.
 *
 * Ported techniques:
 *   #10  Native directory walker (opendir/readdir)
 *   #101 JNI scan engine
 *
 * Uses JNI for maximum performance on large directories. Falls back to
 * `File.list()` when the native library is unavailable.
 *
 * The JNI bindings live in `native-scan/src/main/cpp/native_walker.cpp` and
 * are compiled into `libtitan_native_scan.so`.
 */
class NativeDirectoryWalker {

    companion object {
        private const val TAG = "NativeWalker"
        @Volatile
        private var isNativeAvailable = false

        init {
            try {
                System.loadLibrary("titan_native_scan")
                isNativeAvailable = true
                Log.d(TAG, "Native scanner loaded successfully")
            } catch (_: UnsatisfiedLinkError) {
                isNativeAvailable = false
                Log.w(TAG, "Native scanner not available, using Java fallback")
            }
        }
    }

    // JNI native methods — bound to native_walker.cpp via JNI symbol naming
    //   Java_com_titan_filemanager_data_scan_advanced_walker_NativeDirectoryWalker_nativeListDirectory
    private external fun nativeListDirectory(path: String): Array<String>?
    private external fun nativeGetInodes(path: String, names: Array<String>): LongArray?

    /** List directory — uses native if available, Java fallback otherwise. */
    fun listDirectory(path: String): Array<String> {
        return if (isNativeAvailable) {
            try {
                nativeListDirectory(path) ?: javaListDirectory(path)
            } catch (_: Exception) {
                javaListDirectory(path)
            }
        } else {
            javaListDirectory(path)
        }
    }

    /**
     * Java fallback — optimized.
     * Uses `File.list()` NOT `File.listFiles()` (avoids File object creation).
     */
    private fun javaListDirectory(path: String): Array<String> =
        File(path).list() ?: emptyArray()

    /**
     * Get directory listing WITH type information in a single pass.
     * Returns null if native walker unavailable — caller should fall back to
     * per-entry stat() in that case.
     */
    fun listDirectoryWithTypes(path: String): Pair<Array<String>, BooleanArray>? {
        if (!isNativeAvailable) return null
        return try {
            val names = nativeListDirectory(path) ?: return null
            val types = nativeGetInodes(path, names) ?: return null

            val isDirs = BooleanArray(names.size) { i ->
                (types.getOrElse(i) { 0L } and 0x1L) != 0L
            }
            Pair(names, isDirs)
        } catch (_: Exception) {
            null
        }
    }
}

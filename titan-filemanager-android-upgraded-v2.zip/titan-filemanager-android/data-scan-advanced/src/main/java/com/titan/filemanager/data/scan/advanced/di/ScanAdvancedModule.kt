package com.titan.filemanager.data.scan.advanced.di

import com.titan.filemanager.data.scan.advanced.engine.DirectoryScanEngine
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/** Hilt module exposing [DirectoryScanEngine] as application-scoped singleton. */
@Module
@InstallIn(SingletonComponent::class)
object ScanAdvancedModule {

    @Provides
    @Singleton
    fun provideDirectoryScanEngine(): DirectoryScanEngine = DirectoryScanEngine()
}

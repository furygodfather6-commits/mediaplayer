package com.titan.filemanager.data.scan.advanced.parallel

import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.data.scan.advanced.engine.BatchMetadataCollector
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import java.util.concurrent.ConcurrentLinkedQueue

/**
 * Parallel Directory Scanner.
 *
 * Ported techniques:
 *   #7  Parallel directory scan
 *   #26 Dedicated scan thread pool
 *   #34 Work stealing scheduler
 *
 * Splits the file list into chunks and processes each chunk on a separate
 * coroutine. Two strategies are exposed:
 *  - [scanParallel] — fixed chunk-per-worker, ordered emission via a Channel
 *  - [scanWithWorkStealing] — shared ConcurrentLinkedQueue that workers
 *    drain concurrently (work-stealing semantics)
 */
class ParallelScanner(
    private val threadCount: Int,
    private val batchCollector: BatchMetadataCollector,
) {

    private val scanDispatcher = Dispatchers.IO.limitedParallelism(threadCount)

    /** Parallel scan — emits batches in order. */
    suspend fun scanParallel(
        dirPath: String,
        fileNames: Array<String>,
        onBatch: suspend (List<FileItem>) -> Unit,
        batchSize: Int = 200,
        cancellationCheck: () -> Boolean,
    ) = coroutineScope {
        if (fileNames.isEmpty()) return@coroutineScope

        val chunks = fileNames.toList().chunked(
            maxOf(batchSize, fileNames.size / threadCount),
        )

        val resultChannel = Channel<List<FileItem>>(capacity = threadCount * 2)

        val jobs = chunks.mapIndexed { index, chunk ->
            async(scanDispatcher) {
                if (cancellationCheck()) return@async

                val minimal = batchCollector.collectMinimal(dirPath, chunk.toTypedArray())

                if (index == 0) {
                    resultChannel.send(minimal)
                }

                if (cancellationCheck()) return@async

                val basic = batchCollector.collectBasic(minimal)
                resultChannel.send(basic)
            }
        }

        val collectorJob = launch {
            repeat(jobs.size * 2) {
                val batch = resultChannel.receive()
                onBatch(batch)
            }
        }

        jobs.awaitAll()
        collectorJob.join()
        resultChannel.close()
    }

    /**
     * Work-stealing style scan for very large directories.
     * Ported technique: #34 Work stealing scheduler
     */
    suspend fun scanWithWorkStealing(
        dirPath: String,
        fileNames: Array<String>,
        onBatch: suspend (List<FileItem>) -> Unit,
        batchSize: Int = 500,
    ) = coroutineScope {
        val workQueue = ConcurrentLinkedQueue<List<String>>()

        fileNames.toList()
            .chunked(batchSize)
            .forEach { workQueue.offer(it) }

        val workers = (0 until threadCount).map {
            async(scanDispatcher) {
                while (true) {
                    val chunk = workQueue.poll() ?: break

                    val minimal = batchCollector.collectMinimal(dirPath, chunk.toTypedArray())
                    onBatch(minimal)

                    val basic = batchCollector.collectBasic(minimal)
                    onBatch(basic)
                }
            }
        }
        workers.awaitAll()
    }
}

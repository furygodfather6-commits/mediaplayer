package com.titan.filemanager.data.scan.advanced.pipeline

import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.data.scan.advanced.engine.BatchMetadataCollector
import com.titan.filemanager.data.scan.advanced.strategy.ScanStrategy
import com.titan.filemanager.data.scan.advanced.walker.NativeDirectoryWalker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext

/**
 * Multi-Stage Scan Pipeline.
 *
 * Ported techniques:
 *   #8   Multi-stage scan pipeline
 *   #118 Scan pipeline
 *   #125 Independent worker stages
 *
 * Pipeline stages:
 *   [List Names] → [Stat Files] → [Extract Metadata] → [Sort] → [Emit]
 *      Stage 1        Stage 2          Stage 3         Stage 4  Stage 5
 *
 * Each stage emits a [PipelineEvent]; the caller collects the Flow and
 * forwards updates to the UI as they arrive. Stage 2 emits a minimal batch
 * immediately so the user sees a populated list INSTANTLY, then Stage 3
 * enriches it in chunks.
 */
class ScanPipeline(
    private val batchCollector: BatchMetadataCollector,
    private val nativeWalker: NativeDirectoryWalker,
    private val strategy: ScanStrategy.StrategyConfig,
) {

    /** Full pipeline as Flow — emits items progressively per stage. */
    @OptIn(ExperimentalCoroutinesApi::class)
    fun execute(
        dirPath: String,
        cancellationCheck: () -> Boolean,
    ): Flow<PipelineEvent> = channelFlow {
        val startTime = System.currentTimeMillis()

        // STAGE 1: NAME LISTING (fastest possible)
        send(PipelineEvent.StageStarted(1, "Name listing"))

        val fileNames = withContext(Dispatchers.IO) {
            nativeWalker.listDirectory(dirPath)
        }

        if (fileNames.isEmpty()) {
            send(PipelineEvent.Completed(emptyList(), System.currentTimeMillis() - startTime))
            return@channelFlow
        }

        send(PipelineEvent.NamesListed(fileNames.size))

        if (cancellationCheck()) {
            send(PipelineEvent.Cancelled)
            return@channelFlow
        }

        // STAGE 2: MINIMAL ITEMS (Phase 0)
        send(PipelineEvent.StageStarted(2, "Minimal loading"))

        val minimalItems = withContext(Dispatchers.IO) {
            batchCollector.collectMinimal(dirPath, fileNames)
        }

        // EMIT IMMEDIATELY — user sees items right away
        send(PipelineEvent.BatchReady(minimalItems, phase = 0, isFinal = false))

        if (cancellationCheck()) {
            send(PipelineEvent.Cancelled)
            return@channelFlow
        }

        // STAGE 3: BASIC METADATA (Phase 1) — chunked for responsiveness
        send(PipelineEvent.StageStarted(3, "Basic metadata"))

        val basicItems = ArrayList<FileItem>(minimalItems.size)

        minimalItems.chunked(strategy.batchSize).forEach { chunk ->
            if (cancellationCheck()) {
                send(PipelineEvent.Cancelled)
                return@channelFlow
            }

            val enriched = withContext(Dispatchers.IO) {
                batchCollector.collectBasic(chunk)
            }
            basicItems.addAll(enriched)

            send(PipelineEvent.BatchReady(enriched, phase = 1, isFinal = false))
        }

        if (cancellationCheck()) {
            send(PipelineEvent.Cancelled)
            return@channelFlow
        }

        // STAGE 4: SORTING (deferred for large dirs)
        send(PipelineEvent.StageStarted(4, "Sorting"))

        val sortedItems = if (strategy.sortDeferred) {
            withContext(Dispatchers.Default) {
                basicItems.sortedWith(defaultComparator())
            }
        } else {
            basicItems.sortedWith(defaultComparator())
        }

        // STAGE 5: FINAL EMIT
        send(PipelineEvent.BatchReady(sortedItems, phase = 1, isFinal = true))
        send(PipelineEvent.Completed(sortedItems, System.currentTimeMillis() - startTime))
    }.flowOn(Dispatchers.IO)

    /** Default sort: directories first, then alphabetical. */
    private fun defaultComparator(): Comparator<FileItem> =
        compareBy<FileItem> { if (it.isDirectory) 0 else 1 }
            .thenBy { it.name.lowercase() }
}

/**
 * Pipeline events emitted to UI.
 */
sealed class PipelineEvent {
    data class StageStarted(val stage: Int, val name: String) : PipelineEvent()
    data class NamesListed(val count: Int) : PipelineEvent()
    data class BatchReady(
        val items: List<FileItem>,
        val phase: Int,
        val isFinal: Boolean,
    ) : PipelineEvent()
    object Cancelled : PipelineEvent()
    data class Completed(
        val allItems: List<FileItem>,
        val durationMs: Long,
    ) : PipelineEvent()
    data class Error(val throwable: Throwable) : PipelineEvent()
}

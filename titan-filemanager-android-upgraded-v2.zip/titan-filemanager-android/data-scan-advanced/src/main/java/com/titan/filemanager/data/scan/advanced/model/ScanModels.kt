package com.titan.filemanager.data.scan.advanced.model

import com.titan.filemanager.core.model.file.FileItem

/**
 * Scan state machine.
 *
 * The UI observes a `Flow<ScanState>` from the engine; each emission
 * represents a discrete state transition (Starting → Progressive → Completed
 * / Failed / Cancelled).
 */
sealed class ScanState {
    object Idle : ScanState()

    data class Starting(
        val path: String,
        val strategy: ScanStrategyType,
    ) : ScanState()

    data class Progressive(
        val path: String,
        val loadedCount: Int,
        val estimatedTotal: Int,
        val phase: Int,
        val batchItems: List<FileItem>,
    ) : ScanState()

    data class Completed(
        val path: String,
        val totalItems: Int,
        val scanDurationMs: Long,
        val fromCache: Boolean,
    ) : ScanState()

    data class Failed(
        val path: String,
        val error: Throwable,
    ) : ScanState()

    data class Cancelled(
        val path: String,
        val resumeToken: ResumeToken?,
    ) : ScanState()
}

/**
 * Adaptive scan strategy chosen by [ScanStrategy].
 *
 * Each strategy tunes batch size, thread count, and whether to defer sorting
 * — the goal is to show the first batch of items as quickly as possible
 * regardless of directory size.
 */
enum class ScanStrategyType {
    TINY,       // < 50 items
    SMALL,      // 50-500 items
    MEDIUM,     // 500-5000 items
    LARGE,      // 5000-50000 items
    MASSIVE,    // > 50000 items
}

/** Token used to resume an interrupted scan. */
data class ResumeToken(
    val path: String,
    val scannedPaths: Set<String>,
    val timestamp: Long,
)

/** Final scan result returned to the caller. */
data class ScanResult(
    val items: List<FileItem>,
    val scanDurationMs: Long,
    val strategyUsed: ScanStrategyType,
    val fromCache: Boolean = false,
    val isPartial: Boolean = false,
    val resumeToken: ResumeToken? = null,
)

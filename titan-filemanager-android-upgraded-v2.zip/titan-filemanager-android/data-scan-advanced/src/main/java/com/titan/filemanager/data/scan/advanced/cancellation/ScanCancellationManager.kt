package com.titan.filemanager.data.scan.advanced.cancellation

import com.titan.filemanager.data.scan.advanced.model.ResumeToken
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Scan Cancellation Manager.
 *
 * Ported techniques:
 *   #12 Cancellation support
 *   #13 Resume support
 *
 * Tracks active scans per path, generates stable scan IDs, and stores resume
 * tokens so an interrupted scan can pick up where it left off (within a
 * 5-minute window).
 */
class ScanCancellationManager {

    private val activeJobs = ConcurrentHashMap<String, Job>()
    private val resumeTokens = ConcurrentHashMap<String, ResumeToken>()
    private val cancellationFlags = ConcurrentHashMap<String, AtomicBoolean>()

    /**
     * Register a new scan job. Automatically cancels any existing scan for
     * the same path and returns a unique scanId.
     */
    fun registerScan(path: String, job: Job): String {
        val scanId = generateScanId(path)

        cancelScan(path)

        activeJobs[path] = job
        cancellationFlags[scanId] = AtomicBoolean(false)
        return scanId
    }

    /** Cancel scan for a specific path. Saves resume token if requested. */
    fun cancelScan(
        path: String,
        scannedPaths: Set<String> = emptySet(),
        saveResumeToken: Boolean = true,
    ) {
        activeJobs[path]?.let { job ->
            if (job.isActive) {
                if (saveResumeToken && scannedPaths.isNotEmpty()) {
                    resumeTokens[path] = ResumeToken(
                        path = path,
                        scannedPaths = scannedPaths,
                        timestamp = System.currentTimeMillis(),
                    )
                }
                job.cancel(CancellationException("Navigation change"))
            }
        }
        activeJobs.remove(path)
    }

    /** Cancel ALL active scans — called on app pause / memory pressure. */
    fun cancelAllScans() {
        activeJobs.keys.toList().forEach { path ->
            cancelScan(path, saveResumeToken = false)
        }
        activeJobs.clear()
        cancellationFlags.clear()
    }

    /** Check if scan should be cancelled — called periodically inside scan loops. */
    fun isCancelled(scanId: String): Boolean =
        cancellationFlags[scanId]?.get() ?: true

    /** Get resume token for path (if available and not expired). */
    fun getResumeToken(path: String): ResumeToken? {
        val token = resumeTokens[path] ?: return null

        val isExpired = System.currentTimeMillis() - token.timestamp > 5 * 60 * 1000
        if (isExpired) {
            resumeTokens.remove(path)
            return null
        }
        return token
    }

    fun clearResumeToken(path: String) {
        resumeTokens.remove(path)
    }

    private fun generateScanId(path: String): String = "${path}_${System.nanoTime()}"
}

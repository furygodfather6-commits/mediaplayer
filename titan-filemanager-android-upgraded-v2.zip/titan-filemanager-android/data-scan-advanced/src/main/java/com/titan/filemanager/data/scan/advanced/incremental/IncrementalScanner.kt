package com.titan.filemanager.data.scan.advanced.incremental

import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.data.cache.advanced.model.DirectorySnapshot
import java.io.File

/**
 * Incremental Directory Scanner.
 *
 * Ported techniques:
 *   #2   Incremental directory scan
 *   #160 Inode-based change detection
 *
 * Only processes CHANGED files instead of doing a full rescan. Uses inode +
 * mtime + size for fast change detection.
 */
class IncrementalScanner {

    /** Compare new scan with cached snapshot; returns only changed items. */
    fun computeDiff(newItems: List<FileItem>, snapshot: DirectorySnapshot): ScanDiff {
        val snapshotMap = snapshot.items.associateBy { it.path }
        val newMap = newItems.associateBy { it.path }

        val added = mutableListOf<FileItem>()
        val modified = mutableListOf<FileItem>()
        val deleted = mutableListOf<FileItem>()
        val unchanged = mutableListOf<FileItem>()

        for (newItem in newItems) {
            val old = snapshotMap[newItem.path]
            when {
                old == null -> added.add(newItem)
                isModified(old, newItem) -> modified.add(newItem)
                else -> unchanged.add(newItem)
            }
        }

        for (oldItem in snapshot.items) {
            if (!newMap.containsKey(oldItem.path)) {
                deleted.add(oldItem)
            }
        }

        return ScanDiff(added, modified, deleted, unchanged)
    }

    /**
     * Fast change detection using:
     *  1. Inode (most reliable)
     *  2. Last modified time
     *  3. Size
     */
    private fun isModified(old: FileItem, new: FileItem): Boolean {
        // Stable ID change = file replaced
        if (old.stableId != new.stableId && old.stableId != 0L) return true

        if (old.modifiedAt != new.modifiedAt) return true

        if (!old.isDirectory && old.size != new.size) return true

        return false
    }

    /**
     * Apply diff to existing list WITHOUT full refresh.
     * Returns updated list.
     */
    fun applyDiff(
        currentItems: MutableList<FileItem>,
        diff: ScanDiff,
    ): List<FileItem> {
        if (diff.isEmpty()) return currentItems

        val result = currentItems.toMutableList()

        val deletedPaths = diff.deleted.map { it.path }.toHashSet()
        result.removeAll { it.path in deletedPaths }

        val modifiedMap = diff.modified.associateBy { it.path }
        val iterator = result.listIterator()
        while (iterator.hasNext()) {
            val item = iterator.next()
            modifiedMap[item.path]?.let { iterator.set(it) }
        }

        result.addAll(diff.added)
        return result
    }

    /**
     * Compute snapshot checksum for quick change detection.
     * Ported technique: #160 Inode-based change detection
     */
    fun computeChecksum(dirPath: String): Long = try {
        val dir = File(dirPath)
        val stat = dir.lastModified()
        val count = dir.list()?.size ?: 0
        stat xor count.toLong()
    } catch (_: Exception) {
        -1L
    }

    /**
     * Check if directory has changed since snapshot — O(1) operation.
     */
    fun hasDirectoryChanged(dirPath: String, snapshot: DirectorySnapshot): Boolean {
        val currentChecksum = computeChecksum(dirPath)
        return currentChecksum != snapshot.checksum
    }
}

data class ScanDiff(
    val added: List<FileItem>,
    val modified: List<FileItem>,
    val deleted: List<FileItem>,
    val unchanged: List<FileItem>,
) {
    fun isEmpty() = added.isEmpty() && modified.isEmpty() && deleted.isEmpty()
    val hasChanges get() = !isEmpty()
}

package com.titan.filemanager.data.scan.advanced.engine

import android.os.Build
import android.system.Os
import android.system.StructStat
import com.titan.filemanager.core.model.file.FileItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Batched Metadata Collector.
 *
 * Ported techniques:
 *   #11  Batched metadata collection
 *   #21  Fast symlink detection
 *   #112 Avoid repeated stat()
 *   #159 Os.lstat() low-level APIs
 *
 * Two-phase strategy:
 *  - Phase 0 (Minimal): name, path, isHidden — NO stat() calls
 *  - Phase 1 (Basic):   size, modifiedAt, isDirectory — single `Os.lstat()`
 *                       per file replaces 3 separate File API calls
 *
 * Uses the project's [FileItem] model (stableId / modifiedAt).
 */
class BatchMetadataCollector {

    companion object {
        private const val BATCH_STAT_SIZE = 100
    }

    /**
     * Phase 0: Minimal scan — FASTEST possible.
     * Only: name, path, isHidden. NO stat() calls.
     */
    suspend fun collectMinimal(
        dirPath: String,
        fileNames: Array<String>,
    ): List<FileItem> = withContext(Dispatchers.IO) {
        val items = ArrayList<FileItem>(fileNames.size)
        var id = generateBaseId(dirPath)

        for (name in fileNames) {
            if (name == "." || name == "..") continue

            val fullPath = buildPath(dirPath, name)
            val isHidden = name.startsWith('.')

            items.add(
                FileItem(
                    path = fullPath,
                    name = name,
                    stableId = id++,
                    size = 0L,
                    modifiedAt = 0L,
                    isDirectory = false,
                    isHidden = isHidden,
                ),
            )
        }
        items
    }

    /**
     * Phase 1: Basic metadata using SINGLE stat() call per file.
     * Adds: size, modifiedAt, isDirectory.
     * Uses `Os.lstat()` for symlink detection.
     */
    suspend fun collectBasic(items: List<FileItem>): List<FileItem> =
        withContext(Dispatchers.IO) {
            val result = ArrayList<FileItem>(items.size)

            items.chunked(BATCH_STAT_SIZE).forEach { batch ->
                batch.forEach { item ->
                    try {
                        result.add(statFile(item))
                    } catch (_: Exception) {
                        result.add(item)
                    }
                }
            }
            result
        }

    /** Single optimized stat() — uses `Os.lstat()` when available. */
    private fun statFile(item: FileItem): FileItem {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try {
                val stat: StructStat = Os.lstat(item.path)
                val isDirectory = android.system.OsConstants.S_ISDIR(stat.st_mode)

                item.copy(
                    stableId = stat.st_ino,
                    size = stat.st_size,
                    modifiedAt = stat.st_mtime * 1000L,
                    isDirectory = isDirectory,
                )
            } catch (_: Exception) {
                statWithFileApi(item)
            }
        } else {
            statWithFileApi(item)
        }
    }

    private fun statWithFileApi(item: FileItem): FileItem {
        val file = File(item.path)
        return item.copy(
            size = if (file.isDirectory) 0L else file.length(),
            modifiedAt = file.lastModified(),
            isDirectory = file.isDirectory,
        )
    }

    /** FAST path builder — avoids `File(parent, child).absolutePath` overhead. */
    private fun buildPath(dir: String, name: String): String =
        if (dir.endsWith('/')) "$dir$name" else "$dir/$name"

    private fun generateBaseId(path: String): Long =
        path.hashCode().toLong() * 10_000
}

package com.titan.filemanager.data.scan.advanced.strategy

import com.titan.filemanager.data.scan.advanced.model.ScanStrategyType
import java.io.File

/**
 * Adaptive Scan Strategy.
 *
 * Ported technique: #9 Adaptive scan strategy
 *
 * Decides HOW to scan based on folder characteristics — batch size, thread
 * count, whether to use native walker, whether to defer sort, etc.
 */
class ScanStrategy {

    companion object {
        // Thresholds
        private const val TINY_THRESHOLD = 50
        private const val SMALL_THRESHOLD = 500
        private const val MEDIUM_THRESHOLD = 5_000
        private const val LARGE_THRESHOLD = 50_000

        // Batch sizes per strategy
        private const val BATCH_TINY = 50
        private const val BATCH_SMALL = 100
        private const val BATCH_MEDIUM = 200
        private const val BATCH_LARGE = 500
        private const val BATCH_MASSIVE = 1000

        // Thread counts per strategy
        private const val THREADS_TINY = 1
        private const val THREADS_SMALL = 2
        private const val THREADS_MEDIUM = 4
        private const val THREADS_LARGE = 6
        private const val THREADS_MASSIVE = 8
    }

    data class StrategyConfig(
        val type: ScanStrategyType,
        val batchSize: Int,
        val threadCount: Int,
        val useParallel: Boolean,
        val useNativeWalker: Boolean,
        val prefetchChildren: Boolean,
        val immediateFirstBatch: Boolean,
        val metadataPhases: List<Int>,
        val sortDeferred: Boolean,
    )

    /** Analyze directory and decide best strategy using quick estimate. */
    fun decide(path: String): StrategyConfig {
        val estimatedCount = quickEstimate(path)
        return buildConfig(estimatedCount)
    }

    /**
     * Quick estimate WITHOUT full directory scan.
     * Uses `File.list()` which is faster than `File.listFiles()` because
     * it doesn't allocate File objects per entry.
     */
    private fun quickEstimate(path: String): Int = try {
        File(path).list()?.size ?: 0
    } catch (_: Exception) {
        100
    }

    private fun buildConfig(estimatedCount: Int): StrategyConfig = when {
        estimatedCount < TINY_THRESHOLD -> StrategyConfig(
            type = ScanStrategyType.TINY,
            batchSize = BATCH_TINY,
            threadCount = THREADS_TINY,
            useParallel = false,
            useNativeWalker = false,
            prefetchChildren = true,
            immediateFirstBatch = true,
            metadataPhases = listOf(0, 1, 2),
            sortDeferred = false,
        )

        estimatedCount < SMALL_THRESHOLD -> StrategyConfig(
            type = ScanStrategyType.SMALL,
            batchSize = BATCH_SMALL,
            threadCount = THREADS_SMALL,
            useParallel = false,
            useNativeWalker = false,
            prefetchChildren = true,
            immediateFirstBatch = true,
            metadataPhases = listOf(0, 1),
            sortDeferred = false,
        )

        estimatedCount < MEDIUM_THRESHOLD -> StrategyConfig(
            type = ScanStrategyType.MEDIUM,
            batchSize = BATCH_MEDIUM,
            threadCount = THREADS_MEDIUM,
            useParallel = true,
            useNativeWalker = true,
            prefetchChildren = false,
            immediateFirstBatch = true,
            metadataPhases = listOf(0, 1),
            sortDeferred = true,
        )

        estimatedCount < LARGE_THRESHOLD -> StrategyConfig(
            type = ScanStrategyType.LARGE,
            batchSize = BATCH_LARGE,
            threadCount = THREADS_LARGE,
            useParallel = true,
            useNativeWalker = true,
            prefetchChildren = false,
            immediateFirstBatch = true,
            metadataPhases = listOf(0),
            sortDeferred = true,
        )

        else -> StrategyConfig(
            type = ScanStrategyType.MASSIVE,
            batchSize = BATCH_MASSIVE,
            threadCount = THREADS_MASSIVE,
            useParallel = true,
            useNativeWalker = true,
            prefetchChildren = false,
            immediateFirstBatch = true,
            metadataPhases = listOf(0),
            sortDeferred = true,
        )
    }
}

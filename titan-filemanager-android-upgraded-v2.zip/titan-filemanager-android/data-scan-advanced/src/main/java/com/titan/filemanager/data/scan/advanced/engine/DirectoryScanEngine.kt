package com.titan.filemanager.data.scan.advanced.engine

import android.util.Log
import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.data.cache.advanced.model.DirectorySnapshot
import com.titan.filemanager.data.scan.advanced.cache.DirectoryCache
import com.titan.filemanager.data.scan.advanced.cancellation.ScanCancellationManager
import com.titan.filemanager.data.scan.advanced.incremental.IncrementalScanner
import com.titan.filemanager.data.scan.advanced.model.ResumeToken
import com.titan.filemanager.data.scan.advanced.model.ScanState
import com.titan.filemanager.data.scan.advanced.model.ScanStrategyType
import com.titan.filemanager.data.scan.advanced.pipeline.PipelineEvent
import com.titan.filemanager.data.scan.advanced.pipeline.ScanPipeline
import com.titan.filemanager.data.scan.advanced.parallel.ParallelScanner
import com.titan.filemanager.data.scan.advanced.prefetch.PrefetchManager
import com.titan.filemanager.data.scan.advanced.strategy.ScanStrategy
import com.titan.filemanager.data.scan.advanced.walker.NativeDirectoryWalker
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Master Directory Scan Engine.
 *
 * Ported Phase A techniques (#1-#15 — all directory scanning optimizations):
 *   #1   Progressive loading
 *   #2   Incremental scan
 *   #3   Lazy load
 *   #4   Viewport-based loading
 *   #5   Virtual scrolling
 *   #6   (parallel worker pool — see :data:threading)
 *   #7   Parallel directory scan
 *   #8   Multi-stage scan pipeline
 *   #9   Adaptive scan strategy
 *   #10  Native directory walker
 *   #11  Batched metadata collection
 *   #12  Cancellation support
 *   #13  Resume support
 *   #14  Speculative prefetch
 *   #15  Predictive next-folder loading
 *
 * Pipeline (see block_22.txt in original codebase):
 *   1. Check prefetch cache → instant display if hit
 *   2. Check directory snapshot cache → show cached + background refresh
 *   3. Decide adaptive strategy (TINY/SMALL/MEDIUM/LARGE/MASSIVE)
 *   4. Check resume token from previously cancelled scan
 *   5. Execute [ScanPipeline] — Names → Minimal → Basic → Sort → Final emit
 *   6. Save snapshot, clear resume token, trigger child prefetch
 */
@Singleton
class DirectoryScanEngine @Inject constructor() {

    companion object {
        private const val TAG = "AdvancedScanEngine"
    }

    // The engine is constructed with sensible defaults; production wiring
    // (via DI / ScanAdvancedModule) injects these collaborators explicitly.
    private val cache = DirectoryCache()
    private val cancellationManager = ScanCancellationManager()
    private val incrementalScanner = IncrementalScanner()
    private val strategySelector = ScanStrategy()
    private val nativeWalker = NativeDirectoryWalker()
    private val batchCollector = BatchMetadataCollector()

    private val scope = CoroutineScope(
        Dispatchers.Default + SupervisorJob() + CoroutineName("AdvancedScanEngine"),
    )

    // PrefetchManager has a circular dependency on this engine; created lazily.
    @Volatile
    private var _prefetchManager: PrefetchManager? = null
    val prefetchManager: PrefetchManager
        get() = _prefetchManager ?: PrefetchManager(this).also { _prefetchManager = it }

    /** MAIN ENTRY POINT — scan a directory with all optimizations. */
    fun scan(path: String): Flow<ScanState> = flow {
        val startTime = System.currentTimeMillis()
        emit(ScanState.Starting(path, ScanStrategyType.SMALL))

        // STEP 1: Check prefetch cache FIRST
        val prefetched = prefetchManager.getPrefetchedItems(path)
        if (prefetched != null) {
            Log.d(TAG, "Prefetch hit: $path (${prefetched.size} items)")
            emit(
                ScanState.Progressive(
                    path = path,
                    loadedCount = prefetched.size,
                    estimatedTotal = prefetched.size,
                    phase = 1,
                    batchItems = prefetched,
                ),
            )
        }

        // STEP 2: Check directory snapshot cache
        val snapshot = cache.getSnapshot(path)

        if (snapshot != null) {
            val hasChanged = incrementalScanner.hasDirectoryChanged(path, snapshot)

            if (!hasChanged) {
                Log.d(TAG, "Cache hit, no changes: $path")
                emit(
                    ScanState.Completed(
                        path = path,
                        totalItems = snapshot.items.size,
                        scanDurationMs = System.currentTimeMillis() - startTime,
                        fromCache = true,
                    ),
                )
                return@flow
            }

            // Directory changed — show cached while rescanning
            if (prefetched == null) {
                emit(
                    ScanState.Progressive(
                        path = path,
                        loadedCount = snapshot.items.size,
                        estimatedTotal = snapshot.items.size,
                        phase = 1,
                        batchItems = snapshot.items,
                    ),
                )
            }
        }

        // STEP 3: Decide scan strategy
        val strategy = strategySelector.decide(path)
        Log.d(TAG, "Scan strategy: ${strategy.type} for $path")

        // STEP 4: Check for resume token
        val resumeToken = cancellationManager.getResumeToken(path)
        if (resumeToken != null) {
            Log.d(TAG, "Resuming scan: ${resumeToken.scannedPaths.size} already done")
        }

        // STEP 5: Execute scan pipeline
        val pipeline = ScanPipeline(batchCollector, nativeWalker, strategy)

        val allItems = mutableListOf<FileItem>()
        var estimatedTotal = 0

        pipeline.execute(path) { false }
            .collect { event ->
                when (event) {
                    is PipelineEvent.NamesListed -> {
                        estimatedTotal = event.count
                    }

                    is PipelineEvent.BatchReady -> {
                        if (event.isFinal) {
                            allItems.clear()
                            allItems.addAll(event.items)
                        } else {
                            mergeItems(allItems, event.items)
                        }

                        emit(
                            ScanState.Progressive(
                                path = path,
                                loadedCount = allItems.size,
                                estimatedTotal = estimatedTotal,
                                phase = event.phase,
                                batchItems = event.items,
                            ),
                        )
                    }

                    is PipelineEvent.Cancelled -> {
                        val token = ResumeToken(
                            path = path,
                            scannedPaths = allItems.map { it.path }.toSet(),
                            timestamp = System.currentTimeMillis(),
                        )
                        emit(ScanState.Cancelled(path, token))
                        return@collect
                    }

                    is PipelineEvent.Completed -> {
                        val finalItems = event.allItems

                        // Save to cache
                        val newSnapshot = DirectorySnapshot(
                            path = path,
                            items = finalItems,
                            timestamp = System.currentTimeMillis(),
                            checksum = incrementalScanner.computeChecksum(path),
                        )
                        cache.saveSnapshot(path, newSnapshot)

                        cancellationManager.clearResumeToken(path)

                        // Trigger prefetch of children
                        if (strategy.prefetchChildren) {
                            triggerChildPrefetch(path, finalItems)
                        }

                        emit(
                            ScanState.Completed(
                                path = path,
                                totalItems = finalItems.size,
                                scanDurationMs = event.durationMs,
                                fromCache = false,
                            ),
                        )
                    }

                    is PipelineEvent.Error -> {
                        emit(ScanState.Failed(path, event.throwable))
                    }

                    is PipelineEvent.StageStarted -> {
                        // Internal — not surfaced to UI
                    }
                }
            }
    }.catch { e ->
        Log.e(TAG, "Scan failed for $path", e)
        emit(ScanState.Failed(path, e))
    }

    /** Lightweight scan for prefetch — only phase 0 (minimal). */
    suspend fun scanForPrefetch(path: String): List<FileItem> = withContext(Dispatchers.IO) {
        try {
            val names = nativeWalker.listDirectory(path)
            batchCollector.collectMinimal(path, names)
        } catch (_: Exception) {
            emptyList()
        }
    }

    /** Trigger prefetch of child directories. */
    private fun triggerChildPrefetch(parentPath: String, children: List<FileItem>) {
        scope.launch(Dispatchers.IO + CoroutineName("ChildPrefetch")) {
            prefetchManager.onDirectoryOpened(parentPath, children)
        }
    }

    /** Merge batch items into master list — update existing, add new. */
    private fun mergeItems(master: MutableList<FileItem>, batch: List<FileItem>) {
        val masterMap = master.associateBy { it.path }.toMutableMap()
        batch.forEach { item -> masterMap[item.path] = item }
        master.clear()
        master.addAll(masterMap.values)
    }
}

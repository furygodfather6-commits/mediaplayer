// :data:scan:advanced — Enterprise directory scan engine
// Ported from original codebase Phase A (Techniques #1-#15)
plugins {
    id("titan.android.library")
    id("titan.android.hilt")
}

android {
    namespace = "com.titan.filemanager.data.scan.advanced"
}

dependencies {
    api(project(":core:common"))
    api(project(":core:model"))
    api(project(":domain"))
    api(project(":data:cache:advanced"))

    implementation(libs.kotlinx.coroutines.core)
    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.timber)

    testImplementation(project(":core:testing"))
    testImplementation(libs.junit5)
    testImplementation(libs.truth)
    testImplementation(libs.robolectric)
    testImplementation(libs.kotlinx.coroutines.test)
}

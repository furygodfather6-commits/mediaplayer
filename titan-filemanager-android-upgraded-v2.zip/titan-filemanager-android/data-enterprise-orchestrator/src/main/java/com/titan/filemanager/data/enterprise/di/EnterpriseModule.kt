package com.titan.filemanager.data.enterprise.di

import android.content.Context
import com.titan.filemanager.data.enterprise.EnterpriseFileManagerOrchestrator
import com.titan.filemanager.data.enterprise.EnterpriseSystemStateMonitor
import com.titan.filemanager.data.enterprise.EnterpriseSchedulingEngine
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Hilt DI module for Phase Q — Enterprise Orchestrator.
 *
 * Provides application-scoped singletons for:
 *  - EnterpriseSystemStateMonitor (battery/thermal/memory reactive state)
 *  - EnterpriseSchedulingEngine (policy-based task scheduling)
 *  - EnterpriseFileManagerOrchestrator (top-level coordinator)
 *
 * The individual Q-150 through Q-158 engines are created by the
 * orchestrator and exposed via its public properties.
 */
@Module
@InstallIn(SingletonComponent::class)
object EnterpriseModule {

    @Provides
    @Singleton
    fun provideSystemStateMonitor(@ApplicationContext context: Context): EnterpriseSystemStateMonitor =
        EnterpriseSystemStateMonitor(context)

    @Provides
    @Singleton
    fun provideSchedulingEngine(
        monitor: EnterpriseSystemStateMonitor,
    ): EnterpriseSchedulingEngine =
        EnterpriseSchedulingEngine(monitor.systemState)

    @Provides
    @Singleton
    fun provideOrchestrator(
        @ApplicationContext context: Context,
        monitor: EnterpriseSystemStateMonitor,
        scheduler: EnterpriseSchedulingEngine,
    ): EnterpriseFileManagerOrchestrator =
        EnterpriseFileManagerOrchestrator(context)
}

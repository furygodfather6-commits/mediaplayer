package com.titan.filemanager.core.ui.lock.viewmodel

import com.titan.filemanager.core.ui.contracts.FakeAppLockContract
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/**
 * ## AppLockViewModelTest
 *
 * Unit tests for [AppLockViewModel]. Verifies:
 *  - PIN verification with correct + incorrect PINs
 *  - Failed attempts counter increments
 *  - Lockout after 5 failed attempts
 *  - Biometric result handling
 *  - Mode switching (PIN ↔ biometric)
 */
@OptIn(ExperimentalCoroutinesApi::class)
class AppLockViewModelTest {

    private lateinit var contract: FakeAppLockContract

    @Before
    fun setup() {
        contract = FakeAppLockContract(
            initialEnabled = true,
            initialPin = "1234",
            initialBiometricAvailable = false,
        )
    }

    @Test
    fun `verifyPin with correct PIN unlocks`() = runTest {
        val vm = AppLockViewModel(contract)
        advanceTimeBy(100) // Let init{} run

        vm.verifyPin("1234")
        advanceTimeBy(500) // Past verification delay

        assertTrue(vm.state.value.isUnlocked)
        assertNull(vm.state.value.error)
        assertEquals(0, vm.state.value.failedAttempts)
    }

    @Test
    fun `verifyPin with incorrect PIN does not unlock`() = runTest {
        val vm = AppLockViewModel(contract)
        advanceTimeBy(100)

        vm.verifyPin("9999")
        advanceTimeBy(500)

        assertFalse(vm.state.value.isUnlocked)
        assertEquals(1, vm.state.value.failedAttempts)
    }

    @Test
    fun `verifyPin increments failed attempts on each wrong attempt`() = runTest {
        val vm = AppLockViewModel(contract)
        advanceTimeBy(100)

        vm.verifyPin("wrong")
        advanceTimeBy(500)
        assertEquals(1, vm.state.value.failedAttempts)

        vm.verifyPin("wrong")
        advanceTimeBy(500)
        assertEquals(2, vm.state.value.failedAttempts)

        vm.verifyPin("wrong")
        advanceTimeBy(500)
        assertEquals(3, vm.state.value.failedAttempts)
    }

    @Test
    fun `isLockedOut returns true after 5 failed attempts`() = runTest {
        val vm = AppLockViewModel(contract)
        advanceTimeBy(100)

        repeat(5) {
            vm.verifyPin("wrong")
            advanceTimeBy(500)
        }

        assertTrue(vm.isLockedOut)
        assertEquals(5, vm.state.value.failedAttempts)
    }

    @Test
    fun `correct PIN resets failed attempts to 0`() = runTest {
        val vm = AppLockViewModel(contract)
        advanceTimeBy(100)

        // Fail twice
        vm.verifyPin("wrong")
        advanceTimeBy(500)
        vm.verifyPin("wrong")
        advanceTimeBy(500)
        assertEquals(2, vm.state.value.failedAttempts)

        // Correct PIN resets
        vm.verifyPin("1234")
        advanceTimeBy(500)
        assertEquals(0, vm.state.value.failedAttempts)
        assertTrue(vm.state.value.isUnlocked)
    }

    @Test
    fun `onBiometricResult success unlocks`() = runTest {
        val vm = AppLockViewModel(contract)
        advanceTimeBy(100)

        vm.onBiometricResult(success = true)

        assertTrue(vm.state.value.isUnlocked)
        assertEquals(0, vm.state.value.failedAttempts)
    }

    @Test
    fun `onBiometricResult failure sets error and increments attempts`() = runTest {
        val vm = AppLockViewModel(contract)
        advanceTimeBy(100)

        vm.onBiometricResult(success = false)

        assertFalse(vm.state.value.isUnlocked)
        assertEquals(1, vm.state.value.failedAttempts)
    }

    @Test
    fun `switchToPinMode sets useBiometric false`() = runTest {
        val vm = AppLockViewModel(contract)
        advanceTimeBy(100)

        vm.switchToPinMode()

        assertFalse(vm.state.value.useBiometric)
    }

    @Test
    fun `switchToBiometricMode sets useBiometric true`() = runTest {
        val vm = AppLockViewModel(contract)
        advanceTimeBy(100)

        vm.switchToPinMode()
        vm.switchToBiometricMode()

        assertTrue(vm.state.value.useBiometric)
    }

    @Test
    fun `init checks biometric availability`() = runTest {
        contract = FakeAppLockContract(initialBiometricAvailable = true)
        val vm = AppLockViewModel(contract)
        advanceTimeBy(100)

        assertTrue(vm.state.value.useBiometric)
    }

    @Test
    fun `init defaults to PIN mode when biometric unavailable`() = runTest {
        contract = FakeAppLockContract(initialBiometricAvailable = false)
        val vm = AppLockViewModel(contract)
        advanceTimeBy(100)

        assertFalse(vm.state.value.useBiometric)
    }
}

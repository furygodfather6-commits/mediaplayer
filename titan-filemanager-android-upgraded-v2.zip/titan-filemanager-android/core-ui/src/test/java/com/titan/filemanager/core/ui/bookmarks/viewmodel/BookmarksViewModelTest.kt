package com.titan.filemanager.core.ui.bookmarks.viewmodel

import app.cash.turbine.test
import com.titan.filemanager.core.ui.bookmarks.BookmarkItem
import com.titan.filemanager.core.ui.contracts.FakeBookmarksContract
import com.titan.filemanager.core.ui.contracts.UiBookmark
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/**
 * ## BookmarksViewModelTest
 *
 * Unit tests for [BookmarksViewModel]. Verifies:
 *  - Reactive observation of bookmarks from the contract
 *  - addBookmark/removeBookmark/renameBookmark operations
 *  - reorderBookmark updates sort order
 *  - Error handling when contract throws
 */
@OptIn(ExperimentalCoroutinesApi::class)
class BookmarksViewModelTest {

    private lateinit var contract: FakeBookmarksContract

    @Before
    fun setup() {
        contract = FakeBookmarksContract(
            initial = listOf(
                UiBookmark(1, "DCIM", "/storage/emulated/0/DCIM", true, 0),
                UiBookmark(2, "Downloads", "/storage/emulated/0/Download", true, 1),
            ),
        )
    }

    @Test
    fun `initial state loads bookmarks from contract`() = runTest {
        val vm = BookmarksViewModel(contract)
        vm.state.test {
            // Initial loading state
            assertEquals(true, awaitItem().isLoading)
            // Loaded state with bookmarks
            val loaded = awaitItem()
            assertEquals(false, loaded.isLoading)
            assertEquals(2, loaded.bookmarks.size)
            assertEquals("DCIM", loaded.bookmarks[0].name)
            cancelAndIgnoreRemainingEvents()
        }
    }

    @Test
    fun `addBookmark adds to contract and updates state`() = runTest {
        val vm = BookmarksViewModel(contract)
        vm.addBookmark("/storage/emulated/0/Documents")

        assertEquals(3, contract.bookmarks.size)
        assertEquals("Documents", contract.bookmarks[2].name)
        assertEquals("/storage/emulated/0/Documents", contract.bookmarks[2].path)
    }

    @Test
    fun `removeBookmark removes from contract`() = runTest {
        val vm = BookmarksViewModel(contract)
        vm.removeBookmark(1)

        assertEquals(1, contract.bookmarks.size)
        assertEquals("Downloads", contract.bookmarks[0].name)
    }

    @Test
    fun `renameBookmark updates name in contract`() = runTest {
        val vm = BookmarksViewModel(contract)
        vm.renameBookmark(1, "Camera Photos")

        assertEquals("Camera Photos", contract.bookmarks[0].name)
        assertEquals("/storage/emulated/0/DCIM", contract.bookmarks[0].path)
    }

    @Test
    fun `reorderBookmark updates sort order`() = runTest {
        val vm = BookmarksViewModel(contract)
        // Swap the order: Downloads first, DCIM second
        vm.reorderBookmark(0, 1)

        // Verify the contract was called with new order
        assertEquals(2, contract.bookmarks.size)
    }

    @Test
    fun `state error is null on successful load`() = runTest {
        val vm = BookmarksViewModel(contract)
        vm.state.test {
            awaitItem() // Loading
            val loaded = awaitItem()
            assertNull(loaded.error)
            cancelAndIgnoreRemainingEvents()
        }
    }

    @Test
    fun `empty contract produces empty bookmarks list`() = runTest {
        contract = FakeBookmarksContract(initial = emptyList())
        val vm = BookmarksViewModel(contract)
        vm.state.test {
            awaitItem() // Loading
            val loaded = awaitItem()
            assertTrue(loaded.bookmarks.isEmpty())
            cancelAndIgnoreRemainingEvents()
        }
    }
}

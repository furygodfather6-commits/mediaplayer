package com.titan.filemanager.core.ui.contracts

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * ## FakePreferencesContract
 *
 * In-memory fake implementation of [PreferencesContract] for unit tests.
 *
 * Stores all state in [MutableStateFlow]s so tests can observe reactive
 * updates without needing a real DataStore or Room database.
 *
 * ### Usage
 * ```kotlin
 * class SplashViewModelTest {
 *     private val fakePrefs = FakePreferencesContract()
 *     private val vm = SplashViewModel(context = mockContext, preferences = fakePrefs)
 *
 *     @Test fun `reads onboarding flag`() {
 *         fakePrefs.setHasSeenOnboarding(true)
 *         // ... verify ViewModel reflects the change
 *     }
 * }
 * ```
 */
class FakePreferencesContract(
    initialHasSeenOnboarding: Boolean = false,
    initialIsAppLockEnabled: Boolean = false,
    initialAppLockPin: String? = null,
) : PreferencesContract {

    private val _hasSeenOnboarding = MutableStateFlow(initialHasSeenOnboarding)
    override fun observeHasSeenOnboarding(): kotlinx.coroutines.flow.Flow<Boolean> =
        _hasSeenOnboarding.asStateFlow()

    private val _isAppLockEnabled = MutableStateFlow(initialIsAppLockEnabled)
    override fun observeIsAppLockEnabled(): kotlinx.coroutines.flow.Flow<Boolean> =
        _isAppLockEnabled.asStateFlow()

    @Volatile private var _appLockPin: String? = initialAppLockPin
    override suspend fun getAppLockPin(): String? = _appLockPin

    override suspend fun setHasSeenOnboarding(seen: Boolean) {
        _hasSeenOnboarding.value = seen
    }

    override suspend fun setAppLockEnabled(enabled: Boolean) {
        _isAppLockEnabled.value = enabled
    }

    override suspend fun setAppLockPin(pin: String?) {
        _appLockPin = pin
    }

    /** Test helper — current onboarding flag value. */
    val hasSeenOnboarding: Boolean get() = _hasSeenOnboarding.value

    /** Test helper — current app lock enabled value. */
    val isAppLockEnabled: Boolean get() = _isAppLockEnabled.value
}

/**
 * ## FakeBookmarksContract
 *
 * In-memory fake implementation of [BookmarksContract] for unit tests.
 * Stores bookmarks in a mutable list and exposes them via a StateFlow.
 */
class FakeBookmarksContract(
    initial: List<UiBookmark> = emptyList(),
) : BookmarksContract {

    private val _bookmarks = MutableStateFlow(initial)
    override fun observeBookmarks(): kotlinx.coroutines.flow.Flow<List<UiBookmark>> =
        _bookmarks.asStateFlow()

    private var nextId = (initial.maxOfOrNull { it.id } ?: 0) + 1

    override suspend fun getBookmarks(): List<UiBookmark> = _bookmarks.value

    override suspend fun addBookmark(path: String, displayName: String): Long {
        val id = nextId.toLong()
        nextId++
        val file = java.io.File(path)
        val newBookmark = UiBookmark(
            id = id,
            name = displayName.ifBlank { file.name },
            path = path,
            isFolder = file.isDirectory,
            sortOrder = _bookmarks.value.size,
        )
        _bookmarks.value = _bookmarks.value + newBookmark
        return id
    }

    override suspend fun removeBookmark(id: Long) {
        _bookmarks.value = _bookmarks.value.filter { it.id != id }
    }

    override suspend fun renameBookmark(id: Long, newName: String) {
        _bookmarks.value = _bookmarks.value.map {
            if (it.id == id) it.copy(name = newName) else it
        }
    }

    override suspend fun reorder(bookmarkIds: List<Long>) {
        val byId = _bookmarks.value.associateBy { it.id }
        _bookmarks.value = bookmarkIds.mapIndexed { index, id ->
            byId[id]?.copy(sortOrder = index) ?: byId[id]!!
        }
    }

    /** Test helper — current bookmarks. */
    val bookmarks: List<UiBookmark> get() = _bookmarks.value
}

/**
 * ## FakeRecentFilesContract
 *
 * In-memory fake implementation of [RecentFilesContract] for unit tests.
 */
class FakeRecentFilesContract(
    initial: List<UiRecentFile> = emptyList(),
) : RecentFilesContract {

    private val _recent = MutableStateFlow(initial)
    override fun observeRecent(limit: Int): kotlinx.coroutines.flow.Flow<List<UiRecentFile>> =
        _recent.map { it.take(limit) }

    override suspend fun getRecent(limit: Int): List<UiRecentFile> =
        _recent.value.take(limit)

    override suspend fun recordAccess(path: String, name: String, mimeType: String?) {
        val existing = _recent.value.find { it.path == path }
        val newFile = UiRecentFile(
            name = name,
            path = path,
            size = 0L,
            modifiedAt = System.currentTimeMillis(),
            isDirectory = false,
        )
        _recent.value = if (existing != null) {
            _recent.value.map { if (it.path == path) newFile else it }
        } else {
            (listOf(newFile) + _recent.value).take(100)
        }
    }

    override suspend fun removeRecent(path: String) {
        _recent.value = _recent.value.filter { it.path != path }
    }

    override suspend fun clearAll() {
        _recent.value = emptyList()
    }

    /** Test helper — current recent files. */
    val recent: List<UiRecentFile> get() = _recent.value
}

/**
 * ## FakeAppLockContract
 *
 * In-memory fake implementation of [AppLockContract] for unit tests.
 */
class FakeAppLockContract(
    initialEnabled: Boolean = false,
    initialBiometricAvailable: Boolean = false,
    initialPin: String? = null,
) : AppLockContract {

    @Volatile private var _enabled = initialEnabled
    @Volatile private var _biometricAvailable = initialBiometricAvailable
    @Volatile private var _pin: String? = initialPin

    override suspend fun isAppLockEnabled(): Boolean = _enabled
    override suspend fun isBiometricAvailable(): Boolean = _biometricAvailable

    override suspend fun verifyPin(enteredPin: String): Boolean {
        return _pin != null && enteredPin == _pin
    }

    override suspend fun setPin(pin: String) {
        _pin = pin
        _enabled = true
    }

    override suspend fun clearPin() {
        _pin = null
        _enabled = false
    }

    /** Test helper — set biometric availability. */
    fun setBiometricAvailable(available: Boolean) {
        _biometricAvailable = available
    }
}

/**
 * ## FakeDuplicatesContract
 *
 * In-memory fake implementation of [DuplicatesContract] for unit tests.
 */
class FakeDuplicatesContract(
    private val groups: Map<String, List<UiDuplicateFile>> = emptyMap(),
    private val deleteSuccess: Boolean = true,
) : DuplicatesContract {

    @Volatile private var _keptPaths = mutableSetOf<String>()
    @Volatile private var _deletedPaths = mutableSetOf<String>()

    override suspend fun getDuplicateGroup(groupId: String): List<UiDuplicateFile> {
        return groups[groupId] ?: emptyList()
    }

    override suspend fun deleteFile(path: String, expectedHash: String): Boolean {
        if (!deleteSuccess) return false
        _deletedPaths.add(path)
        return true
    }

    override suspend fun markAsKept(path: String) {
        _keptPaths.add(path)
    }

    /** Test helper — paths marked as kept. */
    val keptPaths: Set<String> get() = _keptPaths.toSet()

    /** Test helper — paths deleted. */
    val deletedPaths: Set<String> get() = _deletedPaths.toSet()
}

/**
 * ## FakeCloudBrowserContract
 *
 * In-memory fake implementation of [CloudBrowserContract] for unit tests.
 */
class FakeCloudBrowserContract(
    private val filesByPath: Map<String, List<UiCloudFile>> = emptyMap(),
    private val downloadSuccess: Boolean = true,
    private val uploadSuccess: Boolean = true,
) : CloudBrowserContract {

    override fun observeFiles(providerId: String, path: String): kotlinx.coroutines.flow.Flow<List<UiCloudFile>> {
        return kotlinx.coroutines.flow.flowOf(filesByPath["$providerId:$path"] ?: emptyList())
    }

    override suspend fun listFiles(providerId: String, path: String): List<UiCloudFile> {
        return filesByPath["$providerId:$path"] ?: emptyList()
    }

    override suspend fun downloadFile(
        providerId: String,
        file: UiCloudFile,
        callback: CloudTransferCallback,
    ) {
        if (downloadSuccess) {
            callback.onProgress(file.size / 2, file.size)
            callback.onProgress(file.size, file.size)
            callback.onComplete(true, null)
        } else {
            callback.onComplete(false, "Download failed (fake)")
        }
    }

    override suspend fun uploadFile(
        providerId: String,
        localPath: String,
        remotePath: String,
        callback: CloudTransferCallback,
    ) {
        if (uploadSuccess) {
            callback.onProgress(100, 200)
            callback.onProgress(200, 200)
            callback.onComplete(true, null)
        } else {
            callback.onComplete(false, "Upload failed (fake)")
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// HELPER EXTENSION for Flow mapping in tests
// ═══════════════════════════════════════════════════════════════

private fun <T, R> kotlinx.coroutines.flow.Flow<T>.map(transform: (T) -> R): kotlinx.coroutines.flow.Flow<R> {
    return kotlinx.coroutines.flow.map(this) { transform(it) }
}

private fun <T, R> kotlinx.coroutines.flow.map(
    flow: kotlinx.coroutines.flow.Flow<T>,
    transform: (T) -> R,
): kotlinx.coroutines.flow.Flow<R> = kotlinx.coroutines.flow.flow {
    flow.collect { emit(transform(it)) }
}

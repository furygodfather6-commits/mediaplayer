package com.titan.filemanager.core.ui.splash.viewmodel

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import com.titan.filemanager.core.ui.contracts.FakePreferencesContract
import io.mockk.every
import io.mockk.mockk
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/**
 * ## SplashViewModelTest
 *
 * Unit tests for [SplashViewModel]. Uses [FakePreferencesContract] to
 * verify that the ViewModel correctly reads onboarding + app lock flags
 * and transitions to READY state after the minimum display time.
 */
@OptIn(ExperimentalCoroutinesApi::class)
class SplashViewModelTest {

    private lateinit var context: Context
    private lateinit var preferences: FakePreferencesContract

    @Before
    fun setup() {
        context = mockk(relaxed = true)
        val packageManager = mockk<PackageManager>(relaxed = true)
        val packageInfo = PackageInfo().apply {
            versionName = "2.0.0"
            // longVersionCode requires API 28+, but we're testing logic only
        }
        every { context.packageManager } returns packageManager
        every { context.packageName } returns "com.titan.filemanager"
        every { packageManager.getPackageInfo(any(), any()) } returns packageInfo

        preferences = FakePreferencesContract(
            initialHasSeenOnboarding = false,
            initialIsAppLockEnabled = false,
        )
    }

    @Test
    fun `initial state is not ready and is initializing`() = runTest {
        val vm = SplashViewModel(context, preferences)
        // Wait for init coroutine to start
        advanceTimeBy(100)
        val state = vm.state.value
        assertTrue("Should be initializing", state.isInitializing)
        assertFalse("Should not be ready immediately", state.isReady)
    }

    @Test
    fun `state becomes ready after minimum display time`() = runTest {
        val vm = SplashViewModel(context, preferences)
        // Advance past MIN_DISPLAY_MS (2000ms)
        advanceTimeBy(SplashViewModel.MIN_DISPLAY_MS + 100)
        val state = vm.state.value
        assertTrue("Should be ready after min display time", state.isReady)
        assertFalse("Should not be initializing after ready", state.isInitializing)
    }

    @Test
    fun `reads hasSeenOnboarding from preferences`() = runTest {
        preferences.setHasSeenOnboarding(true)
        val vm = SplashViewModel(context, preferences)
        advanceTimeBy(SplashViewModel.MIN_DISPLAY_MS + 100)
        assertTrue("Should reflect onboarding seen", vm.state.value.hasSeenOnboarding)
    }

    @Test
    fun `reads isAppLockEnabled from preferences`() = runTest {
        preferences.setAppLockEnabled(true)
        val vm = SplashViewModel(context, preferences)
        advanceTimeBy(SplashViewModel.MIN_DISPLAY_MS + 100)
        assertTrue("Should reflect app lock enabled", vm.state.value.isAppLockEnabled)
    }

    @Test
    fun `defaults to false when preferences not set`() = runTest {
        val vm = SplashViewModel(context, preferences)
        advanceTimeBy(SplashViewModel.MIN_DISPLAY_MS + 100)
        assertFalse("Onboarding should default to false", vm.state.value.hasSeenOnboarding)
        assertFalse("App lock should default to false", vm.state.value.isAppLockEnabled)
    }

    @Test
    fun `markOnboardingSeen updates state and persists to preferences`() = runTest {
        val vm = SplashViewModel(context, preferences)
        advanceTimeBy(SplashViewModel.MIN_DISPLAY_MS + 100)

        vm.markOnboardingSeen()
        advanceTimeBy(100)

        assertTrue("State should reflect onboarding seen", vm.state.value.hasSeenOnboarding)
        assertTrue("Preferences should be persisted", preferences.hasSeenOnboarding)
    }

    @Test
    fun `version info is read from package manager`() = runTest {
        val vm = SplashViewModel(context, preferences)
        advanceTimeBy(SplashViewModel.MIN_DISPLAY_MS + 100)
        assertEquals("2.0.0", vm.state.value.versionName)
    }
}

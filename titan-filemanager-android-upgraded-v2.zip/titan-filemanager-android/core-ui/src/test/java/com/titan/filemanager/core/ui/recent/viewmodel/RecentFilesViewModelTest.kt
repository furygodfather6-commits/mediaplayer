package com.titan.filemanager.core.ui.recent.viewmodel

import app.cash.turbine.test
import com.titan.filemanager.core.ui.contracts.FakeRecentFilesContract
import com.titan.filemanager.core.ui.contracts.UiRecentFile
import com.titan.filemanager.core.ui.recent.TimeRange
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/**
 * ## RecentFilesViewModelTest
 *
 * Unit tests for [RecentFilesViewModel]. Verifies:
 *  - Reactive observation of recent files from the contract
 *  - clearHistory removes all entries
 *  - removeRecent removes a single entry
 *  - groupByTimeRange categorizes files correctly
 */
@OptIn(ExperimentalCoroutinesApi::class)
class RecentFilesViewModelTest {

    private lateinit var contract: FakeRecentFilesContract
    private val now = System.currentTimeMillis()
    private val todayStart = now - (now % (24 * 60 * 60 * 1000))
    private val yesterdayStart = todayStart - (24 * 60 * 60 * 1000)
    private val weekStart = todayStart - (7 * 24 * 60 * 60 * 1000)
    private val monthStart = todayStart - (30L * 24 * 60 * 60 * 1000)

    @Before
    fun setup() {
        contract = FakeRecentFilesContract(
            initial = listOf(
                UiRecentFile("photo.jpg", "/sdcard/DCIM/photo.jpg", 1_000_000, todayStart + 1000, false),
                UiRecentFile("doc.pdf", "/sdcard/Docs/doc.pdf", 500_000, yesterdayStart + 1000, false),
                UiRecentFile("old.txt", "/sdcard/old.txt", 1000, weekStart + 1000, false),
                UiRecentFile("ancient.log", "/sdcard/ancient.log", 500, monthStart - 100_000, false),
            ),
        )
    }

    @Test
    fun `initial state loads recent files from contract`() = runTest {
        val vm = RecentFilesViewModel(contract)
        vm.state.test {
            assertEquals(true, awaitItem().isLoading)
            val loaded = awaitItem()
            assertEquals(false, loaded.isLoading)
            assertEquals(4, loaded.files.size)
            cancelAndIgnoreRemainingEvents()
        }
    }

    @Test
    fun `clearHistory removes all entries via contract`() = runTest {
        val vm = RecentFilesViewModel(contract)
        vm.clearHistory()

        assertTrue(contract.recent.isEmpty())
    }

    @Test
    fun `removeRecent removes single entry from contract`() = runTest {
        val vm = RecentFilesViewModel(contract)
        vm.removeRecent("/sdcard/DCIM/photo.jpg")

        assertEquals(3, contract.recent.size)
        assertTrue(contract.recent.none { it.path == "/sdcard/DCIM/photo.jpg" })
    }

    @Test
    fun `groupByTimeRange categorizes today files`() = runTest {
        val vm = RecentFilesViewModel(contract)
        // Wait for state to load
        vm.state.test {
            awaitItem() // loading
            awaitItem() // loaded
            cancelAndIgnoreRemainingEvents()
        }

        val grouped = vm.groupByTimeRange()
        assertTrue(grouped.containsKey(TimeRange.TODAY))
        assertEquals(1, grouped[TimeRange.TODAY]?.size)
        assertEquals("photo.jpg", grouped[TimeRange.TODAY]?.first()?.name)
    }

    @Test
    fun `groupByTimeRange categorizes yesterday files`() = runTest {
        val vm = RecentFilesViewModel(contract)
        vm.state.test {
            awaitItem()
            awaitItem()
            cancelAndIgnoreRemainingEvents()
        }

        val grouped = vm.groupByTimeRange()
        assertTrue(grouped.containsKey(TimeRange.YESTERDAY))
        assertEquals(1, grouped[TimeRange.YESTERDAY]?.size)
        assertEquals("doc.pdf", grouped[TimeRange.YESTERDAY]?.first()?.name)
    }

    @Test
    fun `groupByTimeRange categorizes this_week files`() = runTest {
        val vm = RecentFilesViewModel(contract)
        vm.state.test {
            awaitItem()
            awaitItem()
            cancelAndIgnoreRemainingEvents()
        }

        val grouped = vm.groupByTimeRange()
        assertTrue(grouped.containsKey(TimeRange.THIS_WEEK))
        assertEquals(1, grouped[TimeRange.THIS_WEEK]?.size)
        assertEquals("old.txt", grouped[TimeRange.THIS_WEEK]?.first()?.name)
    }

    @Test
    fun `groupByTimeRange categorizes older files`() = runTest {
        val vm = RecentFilesViewModel(contract)
        vm.state.test {
            awaitItem()
            awaitItem()
            cancelAndIgnoreRemainingEvents()
        }

        val grouped = vm.groupByTimeRange()
        assertTrue(grouped.containsKey(TimeRange.OLDER))
        assertEquals(1, grouped[TimeRange.OLDER]?.size)
        assertEquals("ancient.log", grouped[TimeRange.OLDER]?.first()?.name)
    }

    @Test
    fun `empty contract produces empty file list`() = runTest {
        contract = FakeRecentFilesContract(initial = emptyList())
        val vm = RecentFilesViewModel(contract)
        vm.state.test {
            awaitItem()
            val loaded = awaitItem()
            assertTrue(loaded.files.isEmpty())
            cancelAndIgnoreRemainingEvents()
        }
    }
}

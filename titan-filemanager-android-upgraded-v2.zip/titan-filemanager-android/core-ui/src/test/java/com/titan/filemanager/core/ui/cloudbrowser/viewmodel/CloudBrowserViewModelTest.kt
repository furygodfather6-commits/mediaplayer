package com.titan.filemanager.core.ui.cloudbrowser.viewmodel

import com.titan.filemanager.core.ui.contracts.FakeCloudBrowserContract
import com.titan.filemanager.core.ui.contracts.UiCloudFile
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/**
 * ## CloudBrowserViewModelTest
 *
 * Unit tests for [CloudBrowserViewModel]. Verifies:
 *  - loadFiles populates state from contract
 *  - refresh reloads current path
 *  - navigateTo changes current path
 *  - downloadFile updates progress and clears on complete
 *  - uploadFile updates progress and refreshes on complete
 *  - Breadcrumb building from path
 */
@OptIn(ExperimentalCoroutinesApi::class)
class CloudBrowserViewModelTest {

    private lateinit var contract: FakeCloudBrowserContract
    private val testFiles = listOf(
        UiCloudFile("Documents", "/Documents", 0, 1000, true, "folder"),
        UiCloudFile("photo.jpg", "/photo.jpg", 2_400_000, 2000, false, "image/jpeg"),
    )

    @Before
    fun setup() {
        contract = FakeCloudBrowserContract(
            filesByPath = mapOf("google_drive:/" to testFiles),
            downloadSuccess = true,
            uploadSuccess = true,
        )
    }

    @Test
    fun `loadFiles populates state from contract`() = runTest {
        val vm = CloudBrowserViewModel(contract)
        vm.loadFiles("google_drive", "/")

        assertEquals("google_drive", vm.state.value.providerId)
        assertEquals("/", vm.state.value.currentPath)
        assertEquals(2, vm.state.value.files.size)
        assertEquals("Documents", vm.state.value.files[0].name)
        assertFalse(vm.state.value.isLoading)
        assertNull(vm.state.value.error)
    }

    @Test
    fun `loadFiles builds breadcrumbs from path`() = runTest {
        val vm = CloudBrowserViewModel(contract)
        vm.loadFiles("google_drive", "/Photos/2024/January")

        val breadcrumbs = vm.state.value.breadcrumbs
        assertEquals(3, breadcrumbs.size)
        assertEquals("Photos" to "/Photos", breadcrumbs[0])
        assertEquals("2024" to "/Photos/2024", breadcrumbs[1])
        assertEquals("January" to "/Photos/2024/January", breadcrumbs[2])
    }

    @Test
    fun `loadFiles with root path produces single Root breadcrumb`() = runTest {
        val vm = CloudBrowserViewModel(contract)
        vm.loadFiles("google_drive", "/")

        val breadcrumbs = vm.state.value.breadcrumbs
        assertEquals(1, breadcrumbs.size)
        assertEquals("Root" to "/", breadcrumbs[0])
    }

    @Test
    fun `refresh reloads current path`() = runTest {
        val vm = CloudBrowserViewModel(contract)
        vm.loadFiles("google_drive", "/")
        vm.refresh()

        assertEquals("/", vm.state.value.currentPath)
        assertEquals(2, vm.state.value.files.size)
    }

    @Test
    fun `navigateTo changes current path and loads files`() = runTest {
        contract = FakeCloudBrowserContract(
            filesByPath = mapOf(
                "google_drive:/" to testFiles,
                "google_drive:/Documents" to listOf(
                    UiCloudFile("resume.pdf", "/Documents/resume.pdf", 500_000, 3000, false, "application/pdf"),
                ),
            ),
        )
        val vm = CloudBrowserViewModel(contract)
        vm.loadFiles("google_drive", "/")

        vm.navigateTo("/Documents")

        assertEquals("/Documents", vm.state.value.currentPath)
        assertEquals(1, vm.state.value.files.size)
        assertEquals("resume.pdf", vm.state.value.files[0].name)
    }

    @Test
    fun `downloadFile updates progress then clears on success`() = runTest {
        val vm = CloudBrowserViewModel(contract)
        vm.loadFiles("google_drive", "/")

        vm.downloadFile(vm.state.value.files[1]) // photo.jpg (2_400_000 bytes)

        // After completion, downloading state should be cleared
        assertNull(vm.state.value.downloadingFile)
        assertEquals(0f, vm.state.value.downloadProgress, 0.01f)
        assertNull(vm.state.value.error)
    }

    @Test
    fun `downloadFile sets error on failure`() = runTest {
        contract = FakeCloudBrowserContract(
            filesByPath = mapOf("google_drive:/" to testFiles),
            downloadSuccess = false,
        )
        val vm = CloudBrowserViewModel(contract)
        vm.loadFiles("google_drive", "/")

        vm.downloadFile(vm.state.value.files[1])

        assertTrue(vm.state.value.error?.contains("Download failed") == true)
        assertNull(vm.state.value.downloadingFile)
    }

    @Test
    fun `uploadFile sets uploading state and clears on success`() = runTest {
        val vm = CloudBrowserViewModel(contract)
        vm.loadFiles("google_drive", "/")

        vm.uploadFile("/sdcard/local_file.txt")

        assertNull(vm.state.value.uploadingFile)
        assertEquals(0f, vm.state.value.uploadProgress, 0.01f)
        assertNull(vm.state.value.error)
    }

    @Test
    fun `uploadFile sets error on failure`() = runTest {
        contract = FakeCloudBrowserContract(
            filesByPath = mapOf("google_drive:/" to testFiles),
            uploadSuccess = false,
        )
        val vm = CloudBrowserViewModel(contract)
        vm.loadFiles("google_drive", "/")

        vm.uploadFile("/sdcard/local_file.txt")

        assertTrue(vm.state.value.error?.contains("Upload failed") == true)
    }

    @Test
    fun `empty path produces empty file list`() = runTest {
        contract = FakeCloudBrowserContract(filesByPath = emptyMap())
        val vm = CloudBrowserViewModel(contract)
        vm.loadFiles("google_drive", "/")

        assertTrue(vm.state.value.files.isEmpty())
    }
}

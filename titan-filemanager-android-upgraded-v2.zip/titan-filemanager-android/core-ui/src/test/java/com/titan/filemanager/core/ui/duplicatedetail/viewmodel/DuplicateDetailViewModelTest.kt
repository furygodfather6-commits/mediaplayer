package com.titan.filemanager.core.ui.duplicatedetail.viewmodel

import com.titan.filemanager.core.ui.contracts.FakeDuplicatesContract
import com.titan.filemanager.core.ui.contracts.UiDuplicateFile
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/**
 * ## DuplicateDetailViewModelTest
 *
 * Unit tests for [DuplicateDetailViewModel]. Verifies:
 *  - Loading duplicate group from contract
 *  - Hash-verified file deletion
 *  - markAsKept functionality
 *  - deleteAllExceptKept convenience method
 *  - Error handling when deletion fails (hash mismatch)
 */
@OptIn(ExperimentalCoroutinesApi::class)
class DuplicateDetailViewModelTest {

    private lateinit var contract: FakeDuplicatesContract
    private val testFiles = listOf(
        UiDuplicateFile("photo.jpg", "/sdcard/DCIM/photo.jpg", 2_400_000, 1000, "abc123"),
        UiDuplicateFile("photo.jpg", "/sdcard/Backup/photo.jpg", 2_400_000, 2000, "abc123"),
        UiDuplicateFile("photo_copy.jpg", "/sdcard/Download/photo_copy.jpg", 2_400_000, 3000, "abc123"),
    )

    @Before
    fun setup() {
        contract = FakeDuplicatesContract(
            groups = mapOf("group_1" to testFiles),
            deleteSuccess = true,
        )
    }

    @Test
    fun `loadDuplicates loads files from contract`() = runTest {
        val vm = DuplicateDetailViewModel(contract)
        vm.loadDuplicates("group_1")

        assertEquals(3, vm.state.value.files.size)
        assertEquals("photo.jpg", vm.state.value.files[0].name)
        assertNull(vm.state.value.error)
    }

    @Test
    fun `loadDuplicates with empty group produces empty list`() = runTest {
        contract = FakeDuplicatesContract(groups = emptyMap())
        val vm = DuplicateDetailViewModel(contract)
        vm.loadDuplicates("nonexistent_group")

        assertTrue(vm.state.value.files.isEmpty())
    }

    @Test
    fun `deleteFile removes file from state on success`() = runTest {
        val vm = DuplicateDetailViewModel(contract)
        vm.loadDuplicates("group_1")

        vm.deleteFile("/sdcard/DCIM/photo.jpg")

        assertEquals(2, vm.state.value.files.size)
        assertTrue(vm.state.value.deletedPaths.contains("/sdcard/DCIM/photo.jpg"))
        assertFalse(vm.state.value.isDeleting)
    }

    @Test
    fun `deleteFile sets error when contract returns false`() = runTest {
        contract = FakeDuplicatesContract(
            groups = mapOf("group_1" to testFiles),
            deleteSuccess = false,
        )
        val vm = DuplicateDetailViewModel(contract)
        vm.loadDuplicates("group_1")

        vm.deleteFile("/sdcard/DCIM/photo.jpg")

        assertEquals(3, vm.state.value.files.size) // No file removed
        assertTrue(vm.state.value.error?.contains("hash") == true)
    }

    @Test
    fun `keepFile marks path as kept in contract`() = runTest {
        val vm = DuplicateDetailViewModel(contract)
        vm.loadDuplicates("group_1")

        vm.keepFile("/sdcard/DCIM/photo.jpg")

        assertEquals("/sdcard/DCIM/photo.jpg", vm.state.value.keptPath)
        assertTrue(contract.keptPaths.contains("/sdcard/DCIM/photo.jpg"))
    }

    @Test
    fun `deleteAllExceptKept deletes all but kept file`() = runTest {
        val vm = DuplicateDetailViewModel(contract)
        vm.loadDuplicates("group_1")

        vm.keepFile("/sdcard/DCIM/photo.jpg")
        vm.deleteAllExceptKept()

        // All files except the kept one should be deleted
        assertEquals(2, contract.deletedPaths.size)
        assertFalse(contract.deletedPaths.contains("/sdcard/DCIM/photo.jpg"))
        assertTrue(contract.deletedPaths.contains("/sdcard/Backup/photo.jpg"))
        assertTrue(contract.deletedPaths.contains("/sdcard/Download/photo_copy.jpg"))
    }

    @Test
    fun `deleteAllExceptKept does nothing if no file is kept`() = runTest {
        val vm = DuplicateDetailViewModel(contract)
        vm.loadDuplicates("group_1")

        vm.deleteAllExceptKept()

        assertEquals(0, contract.deletedPaths.size)
    }

    @Test
    fun `loadDuplicates sets isLoading during load`() = runTest {
        val vm = DuplicateDetailViewModel(contract)
        vm.loadDuplicates("group_1")

        // After completion, isLoading should be false
        assertFalse(vm.state.value.isLoading)
    }
}

package com.titan.filemanager.core.ui.onboarding.viewmodel

import android.content.Context
import com.titan.filemanager.core.ui.contracts.FakePreferencesContract
import io.mockk.mockk
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/**
 * ## OnboardingViewModelTest
 *
 * Unit tests for [OnboardingViewModel]. Verifies:
 *  - Slide navigation (next/previous/goTo)
 *  - skipOnboarding + completeOnboarding persist flag and mark complete
 *  - requestStoragePermission updates rationale state
 *  - onPermissionResult advances slide on grant
 *  - dismissRationale clears flag
 */
@OptIn(ExperimentalCoroutinesApi::class)
class OnboardingViewModelTest {

    private lateinit var context: Context
    private lateinit var preferences: FakePreferencesContract

    @Before
    fun setup() {
        context = mockk(relaxed = true)
        preferences = FakePreferencesContract()
    }

    @Test
    fun `initial state starts at slide 0`() {
        val vm = OnboardingViewModel(context, preferences)
        assertEquals(0, vm.state.value.currentSlide)
        assertEquals(4, vm.state.value.totalSlides)
        assertFalse(vm.state.value.isCompleted)
    }

    @Test
    fun `nextSlide advances to next slide`() {
        val vm = OnboardingViewModel(context, preferences)
        vm.nextSlide()
        assertEquals(1, vm.state.value.currentSlide)

        vm.nextSlide()
        assertEquals(2, vm.state.value.currentSlide)
    }

    @Test
    fun `nextSlide does not advance past last slide`() {
        val vm = OnboardingViewModel(context, preferences)
        repeat(10) { vm.nextSlide() }
        assertEquals(3, vm.state.value.currentSlide) // Max slide is 3 (0-indexed)
    }

    @Test
    fun `previousSlide goes back`() {
        val vm = OnboardingViewModel(context, preferences)
        vm.nextSlide()
        vm.nextSlide()
        vm.previousSlide()
        assertEquals(1, vm.state.value.currentSlide)
    }

    @Test
    fun `previousSlide does not go below 0`() {
        val vm = OnboardingViewModel(context, preferences)
        vm.previousSlide()
        assertEquals(0, vm.state.value.currentSlide)
    }

    @Test
    fun `goToSlide jumps to specified slide`() {
        val vm = OnboardingViewModel(context, preferences)
        vm.goToSlide(2)
        assertEquals(2, vm.state.value.currentSlide)
    }

    @Test
    fun `goToSlide clamps to valid range`() {
        val vm = OnboardingViewModel(context, preferences)
        vm.goToSlide(-1)
        assertEquals(0, vm.state.value.currentSlide)

        vm.goToSlide(99)
        assertEquals(3, vm.state.value.currentSlide)
    }

    @Test
    fun `skipOnboarding marks complete and persists flag`() = runTest {
        val vm = OnboardingViewModel(context, preferences)
        vm.skipOnboarding()

        assertTrue(vm.state.value.isCompleted)
        assertTrue(preferences.hasSeenOnboarding)
    }

    @Test
    fun `completeOnboarding marks complete and persists flag`() = runTest {
        val vm = OnboardingViewModel(context, preferences)
        vm.completeOnboarding()

        assertTrue(vm.state.value.isCompleted)
        assertTrue(preferences.hasSeenOnboarding)
    }

    @Test
    fun `onPermissionResult with granted advances slide`() {
        val vm = OnboardingViewModel(context, preferences)
        val initialSlide = vm.state.value.currentSlide

        vm.onPermissionResult(granted = true)

        assertTrue(vm.state.value.isPermissionGranted)
        assertEquals(initialSlide + 1, vm.state.value.currentSlide)
    }

    @Test
    fun `onPermissionResult with denied does not advance slide`() {
        val vm = OnboardingViewModel(context, preferences)
        val initialSlide = vm.state.value.currentSlide

        vm.onPermissionResult(granted = false)

        assertFalse(vm.state.value.isPermissionGranted)
        assertEquals(initialSlide, vm.state.value.currentSlide)
    }

    @Test
    fun `dismissRationale clears showRationale flag`() {
        val vm = OnboardingViewModel(context, preferences)
        // First trigger rationale (mockk will return false for permission check)
        vm.requestStoragePermission()
        // Then dismiss
        vm.dismissRationale()

        assertFalse(vm.state.value.showRationale)
    }
}

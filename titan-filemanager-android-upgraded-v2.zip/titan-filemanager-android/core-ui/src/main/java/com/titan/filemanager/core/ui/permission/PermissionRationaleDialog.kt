package com.titan.filemanager.core.ui.permission

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens

/**
 * Custom permission rationale dialog — shown BEFORE the system permission dialog.
 *
 * Explains WHY we need storage access in user-friendly terms.
 * On "Continue" → triggers system permission request via [onContinue].
 * On "Skip" → proceeds without permission (limited functionality).
 *
 * Usage:
 * ```
 * if (showRationale) {
 *     PermissionRationaleDialog(
 *         onContinue = { showRationale = false; requestPermission() },
 *         onSkip = { showRationale = false },
 *     )
 * }
 * ```
 */
@Composable
fun PermissionRationaleDialog(
    onContinue: () -> Unit,
    onSkip: () -> Unit,
    modifier: Modifier = Modifier,
) {
    AlertDialog(
        onDismissRequest = onSkip,
        modifier = modifier,
        icon = {
            Icon(
                Icons.Filled.Storage,
                null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(48.dp),
            )
        },
        title = {
            Text(
                "Storage Access Required",
                fontWeight = FontWeight.SemiBold,
            )
        },
        text = {
            Column {
                Text(
                    "TitanFileManager needs storage access to:",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                )
                Spacer(Modifier.size(SpacingTokens.Sm))

                PermissionBenefit(Icons.Filled.Folder, "Browse files and folders")
                PermissionBenefit(Icons.Filled.Storage, "Search across all storage")
                PermissionBenefit(Icons.Filled.Folder, "Copy, move, and delete files")
                PermissionBenefit(Icons.Filled.Storage, "Generate thumbnails")
                PermissionBenefit(Icons.Filled.Folder, "Encrypt files in vault")

                Spacer(Modifier.size(SpacingTokens.Md))
                Text(
                    "Your files never leave your device. No telemetry, no tracking, no ads.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Medium,
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onContinue) {
                Text("Continue", fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary)
            }
        },
        dismissButton = {
            TextButton(onClick = onSkip) {
                Text("Skip for now", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
    )
}

@Composable
private fun PermissionBenefit(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = SpacingTokens.Xs),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.Sm),
    ) {
        Icon(
            icon,
            null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(20.dp),
        )
        Text(text, style = MaterialTheme.typography.bodyMedium)
    }
}

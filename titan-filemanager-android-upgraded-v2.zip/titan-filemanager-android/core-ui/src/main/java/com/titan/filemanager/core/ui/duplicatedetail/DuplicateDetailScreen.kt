package com.titan.filemanager.core.ui.duplicatedetail

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.titan.filemanager.core.designsystem.component.TitanFileInfoRow
import com.titan.filemanager.core.designsystem.icon.FileTypeIcon
import com.titan.filemanager.core.designsystem.modifier.bounceClick
import com.titan.filemanager.core.designsystem.tokens.ColorTokens
import com.titan.filemanager.core.designsystem.tokens.ElevationTokens
import com.titan.filemanager.core.designsystem.tokens.ShapeTokens
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens

data class DuplicateFile(
    val name: String,
    val path: String,
    val size: Long,
    val modifiedAt: Long,
    val contentHash: String,
)

/**
 * Duplicate Detail Screen — side-by-side comparison of duplicate files.
 *
 * Shows each duplicate file in a card with:
 *  - File icon + name
 *  - Full path
 *  - Size, modified date
 *  - Content hash (SHA-256)
 *  - "Keep" button (marks as keeper) / "Delete" button
 *
 * The user selects which copy to keep and deletes the rest.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DuplicateDetailScreen(
    files: List<DuplicateFile>,
    onBack: () -> Unit,
    onDelete: (String) -> Unit,
    onKeep: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val icon = if (files.isNotEmpty()) FileTypeIcon.fromPath(files.first().path) else FileTypeIcon.fromExtension("")

    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = { Text("Duplicate Details", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface),
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(SpacingTokens.Md),
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.Sm),
        ) {
            // Summary header
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = ShapeTokens.Medium,
                elevation = CardDefaults.cardElevation(defaultElevation = ElevationTokens.Level2),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.errorContainer,
                ),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(SpacingTokens.ContentPadding),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Filled.ContentCopy, null, tint = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.size(32.dp))
                    Spacer(Modifier.size(SpacingTokens.Md))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("${files.size} identical copies",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onErrorContainer)
                        Text("${formatBytes(files.firstOrNull()?.size ?: 0)} each • ${formatBytes((files.size - 1) * (files.firstOrNull()?.size ?: 0))} wasted",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.8f))
                    }
                }
            }

            // File comparison cards
            files.forEach { file ->
                DuplicateFileCard(
                    file = file,
                    icon = icon,
                    onDelete = { onDelete(file.path) },
                    onKeep = { onKeep(file.path) },
                )
            }

            Spacer(Modifier.height(SpacingTokens.Lg))
        }
    }
}

@Composable
private fun DuplicateFileCard(
    file: DuplicateFile,
    icon: com.titan.filemanager.core.designsystem.icon.FileTypeIcon,
    onDelete: () -> Unit,
    onKeep: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth().bounceClick(onClick = {}),
        shape = ShapeTokens.Medium,
        elevation = CardDefaults.cardElevation(defaultElevation = ElevationTokens.Level1),
    ) {
        Column(modifier = Modifier.padding(SpacingTokens.ContentPadding)) {
            // Header
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon.imageVector, null, modifier = Modifier.size(40.dp), tint = icon.color)
                Spacer(Modifier.size(SpacingTokens.Md))
                Text(file.name, style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f))
            }

            Spacer(Modifier.height(SpacingTokens.Sm))
            HorizontalDivider()
            Spacer(Modifier.height(SpacingTokens.Sm))

            // Details
            TitanFileInfoRow(
                label = "Path",
                value = file.path,
                icon = Icons.Filled.LocationOn,
            )
            TitanFileInfoRow(
                label = "Size",
                value = formatBytes(file.size),
            )
            TitanFileInfoRow(
                label = "Modified",
                value = formatDate(file.modifiedAt),
            )
            TitanFileInfoRow(
                label = "Hash",
                value = file.contentHash.take(16) + "…",
                icon = Icons.Filled.Fingerprint,
            )

            Spacer(Modifier.height(SpacingTokens.Sm))

            // Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.Sm),
            ) {
                Button(
                    onClick = onKeep,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.tertiary,
                    ),
                    shape = ShapeTokens.Full,
                ) {
                    Icon(Icons.Filled.Check, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.size(SpacingTokens.Xs))
                    Text("Keep")
                }
                Button(
                    onClick = onDelete,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                    ),
                    shape = ShapeTokens.Full,
                ) {
                    Icon(Icons.Filled.Delete, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.size(SpacingTokens.Xs))
                    Text("Delete")
                }
            }
        }
    }
}

private fun formatBytes(bytes: Long): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
    bytes < 1024 * 1024 * 1024 -> "%.1f MB".format(bytes / (1024.0 * 1024))
    else -> "%.1f GB".format(bytes / (1024.0 * 1024 * 1024))
}

private fun formatDate(timestamp: Long): String {
    if (timestamp == 0L) return "Unknown"
    return java.text.SimpleDateFormat("MMM dd, yyyy 'at' HH:mm", java.util.Locale.getDefault())
        .format(java.util.Date(timestamp))
}

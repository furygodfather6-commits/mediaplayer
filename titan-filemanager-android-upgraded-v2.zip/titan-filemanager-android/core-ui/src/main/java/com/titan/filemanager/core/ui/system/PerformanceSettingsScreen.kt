package com.titan.filemanager.core.ui.system

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.titan.filemanager.core.datastore.system.CompactionInterval
import com.titan.filemanager.core.datastore.system.PerformanceMode
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import com.titan.filemanager.core.ui.appearance.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PerformanceSettingsScreen(onBack: () -> Unit, viewModel: AdvancedSystemViewModel = hiltViewModel()) {
    val s by viewModel.settings.collectAsStateWithLifecycle()
    val p = s.performance
    Scaffold(topBar = { TopAppBar(title = { Text("Performance", fontWeight = FontWeight.SemiBold) },
        navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())) {
            SettingsRadioGroup("Performance Mode", PerformanceMode.entries.map { it.label to it }, p.performanceMode) { v -> viewModel.updatePerformance { it.copy(performanceMode = v) } }
            SettingsHorizontalDivider()
            SettingsIntSlider("Max Background Threads", p.maxBackgroundThreads, 2..32, p.maxBackgroundThreads.toString()) { v -> viewModel.updatePerformance { it.copy(maxBackgroundThreads = v) } }
            SettingsHorizontalDivider()
            SettingsToggle("Battery-aware scheduling", "Reduce background work on low battery", p.batteryAwareScheduling) { b -> viewModel.updatePerformance { it.copy(batteryAwareScheduling = b) } }
            SettingsToggle("Thermal throttling", "Reduce work when device is hot", p.thermalThrottling) { b -> viewModel.updatePerformance { it.copy(thermalThrottling = b) } }
            SettingsToggle("Low memory mode", "Aggressively clear caches", p.lowMemoryMode) { b -> viewModel.updatePerformance { it.copy(lowMemoryMode = b) } }
            SettingsToggle("Charging-aware optimization", "Run heavy tasks only when charging", p.chargingAwareOptimization) { b -> viewModel.updatePerformance { it.copy(chargingAwareOptimization = b) } }
            SettingsHorizontalDivider()
            SettingsRadioGroup("Database Compaction", CompactionInterval.entries.map { it.label to it }, p.databaseCompactionInterval) { v -> viewModel.updatePerformance { it.copy(databaseCompactionInterval = v) } }
            SettingsToggle("Thumbnail pre-generation", "Pre-generate thumbnails for visible items", p.thumbnailPreGeneration) { b -> viewModel.updatePerformance { it.copy(thumbnailPreGeneration = b) } }
            Spacer(Modifier.height(SpacingTokens.Xxl))
        }
    }
}

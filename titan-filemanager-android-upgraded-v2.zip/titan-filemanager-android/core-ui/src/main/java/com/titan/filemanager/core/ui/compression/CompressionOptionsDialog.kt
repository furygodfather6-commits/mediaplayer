package com.titan.filemanager.core.ui.compression

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.CallSplit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import com.titan.filemanager.core.designsystem.tokens.ShapeTokens
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens

enum class ArchiveFormat(val label: String, val extension: String, val supportsPassword: Boolean, val supportsSplit: Boolean) {
    ZIP("ZIP", "zip", true, false),
    SEVEN_Z("7-Zip", "7z", true, true),
    TAR_GZ("TAR.GZ", "tar.gz", false, false),
    TAR_BZ2("TAR.BZ2", "tar.bz2", false, false),
    TAR_XZ("TAR.XZ", "tar.xz", false, false),
}

data class CompressionOptions(
    val format: ArchiveFormat,
    val archiveName: String,
    val compressionLevel: Int,   // 0 (store) to 9 (max)
    val password: String?,
    val splitVolumeMb: Int?,     // null = no split
)

/**
 * Compression Options Dialog — full-featured archive creation config.
 *
 * Options:
 *  - Format selection (ZIP / 7-Zip / TAR.GZ / TAR.BZ2 / TAR.XZ)
 *  - Archive name input
 *  - Compression level slider (0-9)
 *  - Password protection (toggle + field, format-dependent)
 *  - Split volume (toggle + MB input, 7z only)
 *
 * Usage:
 * ```
 * var showCompressionDialog by remember { mutableStateOf(false) }
 * if (showCompressionDialog) {
 *     CompressionOptionsDialog(
 *         fileCount = selectedFiles.size,
 *         totalSize = totalBytes,
 *         onConfirm = { options -> viewModel.createArchive(options); showCompressionDialog = false },
 *         onDismiss = { showCompressionDialog = false },
 *     )
 * }
 * ```
 */
@Composable
fun CompressionOptionsDialog(
    fileCount: Int,
    totalSize: String,
    onConfirm: (CompressionOptions) -> Unit,
    onDismiss: () -> Unit,
) {
    var archiveName by remember { mutableStateOf("archive") }
    var selectedFormat by remember { mutableStateOf(ArchiveFormat.ZIP) }
    var compressionLevel by remember { mutableFloatStateOf(6f) }
    var usePassword by remember { mutableStateOf(false) }
    var password by remember { mutableStateOf("") }
    var useSplit by remember { mutableStateOf(false) }
    var splitSize by remember { mutableStateOf("100") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.FolderZip, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.size(SpacingTokens.Sm))
                Text("Create Archive", fontWeight = FontWeight.SemiBold)
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(SpacingTokens.Sm),
            ) {
                // Source info
                Text(
                    "$fileCount files • $totalSize",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )

                // Archive name
                OutlinedTextField(
                    value = archiveName,
                    onValueChange = { archiveName = it },
                    label = { Text("Archive name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )

                // Format selection
                Text("Format", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Medium)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(SpacingTokens.Xs),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    ArchiveFormat.entries.forEach { format ->
                        FilterChip(
                            selected = selectedFormat == format,
                            onClick = {
                                selectedFormat = format
                                if (!format.supportsPassword) usePassword = false
                                if (!format.supportsSplit) useSplit = false
                            },
                            label = { Text(format.label, maxLines = 1) },
                        )
                    }
                }

                // Compression level
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Speed, null, modifier = Modifier.size(18.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.size(SpacingTokens.Xs))
                    Text("Level: ${compressionLevel.toInt()}", style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium)
                }
                Slider(
                    value = compressionLevel,
                    onValueChange = { compressionLevel = it },
                    valueRange = 0f..9f,
                    steps = 8,
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Store", style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Max", style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }

                // Password (format-dependent)
                if (selectedFormat.supportsPassword) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.Filled.Lock, null, modifier = Modifier.size(18.dp),
                            tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.size(SpacingTokens.Xs))
                        Text("Password protect", modifier = Modifier.weight(1f),
                            style = MaterialTheme.typography.bodyMedium)
                        Switch(checked = usePassword, onCheckedChange = { usePassword = it })
                    }
                    if (usePassword) {
                        OutlinedTextField(
                            value = password,
                            onValueChange = { password = it },
                            label = { Text("Password") },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }

                // Split volume (7z only)
                if (selectedFormat.supportsSplit) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.Filled.CallSplit, null, modifier = Modifier.size(18.dp),
                            tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.size(SpacingTokens.Xs))
                        Text("Split into volumes", modifier = Modifier.weight(1f),
                            style = MaterialTheme.typography.bodyMedium)
                        Switch(checked = useSplit, onCheckedChange = { useSplit = it })
                    }
                    if (useSplit) {
                        OutlinedTextField(
                            value = splitSize,
                            onValueChange = { splitSize = it.filter { c -> c.isDigit() } },
                            label = { Text("Volume size (MB)") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirm(
                        CompressionOptions(
                            format = selectedFormat,
                            archiveName = if (archiveName.isNotBlank()) archiveName else "archive",
                            compressionLevel = compressionLevel.toInt(),
                            password = if (usePassword && password.isNotBlank()) password else null,
                            splitVolumeMb = if (useSplit && splitSize.isNotBlank()) splitSize.toInt() else null,
                        ),
                    )
                },
                shape = ShapeTokens.Full,
            ) {
                Icon(Icons.Filled.FolderZip, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.size(SpacingTokens.Xs))
                Text("Create")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
    )
}

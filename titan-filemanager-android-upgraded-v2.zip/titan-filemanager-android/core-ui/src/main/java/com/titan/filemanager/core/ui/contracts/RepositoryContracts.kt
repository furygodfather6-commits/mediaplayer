package com.titan.filemanager.core.ui.contracts

import kotlinx.coroutines.flow.Flow

/**
 * ## RepositoryContracts
 *
 * Abstract repository interfaces that core-ui ViewModels depend on.
 * The app/di module provides concrete implementations that bridge these
 * contracts to the real domain repositories.
 *
 * ### Why abstract contracts in core-ui?
 * core-ui cannot depend on the `:domain` module (that would create a
 * circular dependency: domain → core-ui → domain). Instead, core-ui
 * declares minimal interfaces here, and the app module's DI layer
 * provides implementations that adapt domain repositories to these
 * contracts.
 *
 * ### Contract design
 * Each contract is intentionally minimal — only the methods actually
 * used by core-ui ViewModels. This keeps the contracts small and
 * focused, and avoids leaking domain details into core-ui.
 *
 * ### Hilt binding
 * In `app/di/RepositoryBindingsModule.kt`, each contract is bound to
 * its concrete implementation via `@Binds`. ViewModels inject the
 * contract interface; Hilt resolves the binding at runtime.
 */

// ═══════════════════════════════════════════════════════════════
// PREFERENCES CONTRACT
// ═══════════════════════════════════════════════════════════════

/**
 * Contract for reading + writing user preferences.
 *
 * Used by:
 *  - [com.titan.filemanager.core.ui.splash.viewmodel.SplashViewModel]
 *  - [com.titan.filemanager.core.ui.onboarding.viewmodel.OnboardingViewModel]
 */
interface PreferencesContract {

    /** Whether the user has completed onboarding (first-run intro). */
    fun observeHasSeenOnboarding(): Flow<Boolean>

    /** Whether app lock (PIN/biometric) is enabled. */
    fun observeIsAppLockEnabled(): Flow<Boolean>

    /** The stored app lock PIN (encrypted at rest; returns plaintext after decryption). */
    suspend fun getAppLockPin(): String?

    /** Mark onboarding as completed. */
    suspend fun setHasSeenOnboarding(seen: Boolean)

    /** Enable or disable app lock. */
    suspend fun setAppLockEnabled(enabled: Boolean)

    /** Set the app lock PIN (stored encrypted). */
    suspend fun setAppLockPin(pin: String?)
}

// ═══════════════════════════════════════════════════════════════
// BOOKMARKS CONTRACT
// ═══════════════════════════════════════════════════════════════

/**
 * Domain-agnostic bookmark representation for core-ui.
 */
data class UiBookmark(
    val id: Long,
    val name: String,
    val path: String,
    val isFolder: Boolean,
    val sortOrder: Int,
)

/**
 * Contract for bookmark CRUD operations.
 *
 * Used by [com.titan.filemanager.core.ui.bookmarks.viewmodel.BookmarksViewModel].
 */
interface BookmarksContract {

    fun observeBookmarks(): Flow<List<UiBookmark>>

    suspend fun getBookmarks(): List<UiBookmark>

    suspend fun addBookmark(path: String, displayName: String): Long

    suspend fun removeBookmark(id: Long)

    suspend fun renameBookmark(id: Long, newName: String)

    suspend fun reorder(bookmarkIds: List<Long>)
}

// ═══════════════════════════════════════════════════════════════
// RECENT FILES CONTRACT
// ═══════════════════════════════════════════════════════════════

/**
 * Domain-agnostic recent-file representation for core-ui.
 */
data class UiRecentFile(
    val name: String,
    val path: String,
    val size: Long,
    val modifiedAt: Long,
    val isDirectory: Boolean,
)

/**
 * Contract for recent-files history.
 *
 * Used by [com.titan.filemanager.core.ui.recent.viewmodel.RecentFilesViewModel].
 */
interface RecentFilesContract {

    fun observeRecent(limit: Int = 100): Flow<List<UiRecentFile>>

    suspend fun getRecent(limit: Int = 100): List<UiRecentFile>

    suspend fun recordAccess(path: String, name: String, mimeType: String?)

    suspend fun removeRecent(path: String)

    suspend fun clearAll()
}

// ═══════════════════════════════════════════════════════════════
// CLOUD BROWSER CONTRACT
// ═══════════════════════════════════════════════════════════════

/**
 * Domain-agnostic cloud-file representation for core-ui.
 */
data class UiCloudFile(
    val name: String,
    val path: String,
    val size: Long,
    val modifiedAt: Long,
    val isDirectory: Boolean,
    val mimeType: String,
)

/**
 * Progress callback for cloud transfers (download/upload).
 */
interface CloudTransferCallback {
    fun onProgress(bytesTransferred: Long, totalBytes: Long)
    fun onComplete(success: Boolean, error: String?)
}

/**
 * Contract for cloud-storage operations.
 *
 * Used by [com.titan.filemanager.core.ui.cloudbrowser.viewmodel.CloudBrowserViewModel].
 */
interface CloudBrowserContract {

    fun observeFiles(providerId: String, path: String): Flow<List<UiCloudFile>>

    suspend fun listFiles(providerId: String, path: String): List<UiCloudFile>

    suspend fun downloadFile(providerId: String, file: UiCloudFile, callback: CloudTransferCallback)

    suspend fun uploadFile(providerId: String, localPath: String, remotePath: String, callback: CloudTransferCallback)
}

// ═══════════════════════════════════════════════════════════════
// DUPLICATES CONTRACT
// ═══════════════════════════════════════════════════════════════

/**
 * Domain-agnostic duplicate-file representation for core-ui.
 */
data class UiDuplicateFile(
    val name: String,
    val path: String,
    val size: Long,
    val modifiedAt: Long,
    val contentHash: String,
)

/**
 * Contract for duplicate-file detection + management.
 *
 * Used by [com.titan.filemanager.core.ui.duplicatedetail.viewmodel.DuplicateDetailViewModel].
 */
interface DuplicatesContract {

    suspend fun getDuplicateGroup(groupId: String): List<UiDuplicateFile>

    suspend fun deleteFile(path: String, expectedHash: String): Boolean

    suspend fun markAsKept(path: String)
}

// ═══════════════════════════════════════════════════════════════
// APP LOCK CONTRACT
// ═══════════════════════════════════════════════════════════════

/**
 * Contract for app-lock PIN verification.
 *
 * Used by [com.titan.filemanager.core.ui.lock.viewmodel.AppLockViewModel].
 *
 * Security note: The PIN is stored encrypted at rest (via EncryptedSharedPreferences
 * or Tink). The contract returns the plaintext PIN for comparison — the
 * implementation is responsible for decryption in a secure enclave.
 */
interface AppLockContract {

    /** Whether app lock is enabled (PIN or biometric). */
    suspend fun isAppLockEnabled(): Boolean

    /** Whether biometric authentication is available on this device. */
    suspend fun isBiometricAvailable(): Boolean

    /** Verify the entered PIN against the stored PIN. Constant-time comparison. */
    suspend fun verifyPin(enteredPin: String): Boolean

    /** Set a new PIN (stored encrypted). */
    suspend fun setPin(pin: String)

    /** Clear the stored PIN (disables app lock). */
    suspend fun clearPin()
}

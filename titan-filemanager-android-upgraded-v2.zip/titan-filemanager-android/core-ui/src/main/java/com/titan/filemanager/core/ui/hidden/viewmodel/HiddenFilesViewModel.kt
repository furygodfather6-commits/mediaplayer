package com.titan.filemanager.core.ui.hidden.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.titan.filemanager.core.ui.hidden.HiddenFile
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject

@HiltViewModel
class HiddenFilesViewModel @Inject constructor() : ViewModel() {

    private val _state = MutableStateFlow(HiddenFilesUiState())
    val state: StateFlow<HiddenFilesUiState> = _state.asStateFlow()

    init { loadHiddenFiles() }

    fun loadHiddenFiles() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            try {
                val files = withContext(Dispatchers.IO) { scanHiddenFiles() }
                _state.update { it.copy(files = files, isLoading = false) }
            } catch (e: Exception) {
                _state.update { it.copy(isLoading = false, error = e.message) }
            }
        }
    }

    fun unhideFile(path: String) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                val file = File(path)
                val newName = file.name.removePrefix(".")
                val newPath = file.parentFile?.absolutePath + "/" + newName
                file.renameTo(File(newPath))
            }
            _state.update { it.copy(files = it.files.filter { f -> f.path != path }) }
        }
    }

    fun unhideAll() {
        viewModelScope.launch {
            val allPaths = _state.value.files.map { it.path }
            withContext(Dispatchers.IO) {
                allPaths.forEach { path ->
                    val file = File(path)
                    val newName = file.name.removePrefix(".")
                    val newPath = file.parentFile?.absolutePath + "/" + newName
                    file.renameTo(File(newPath))
                }
            }
            _state.update { it.copy(files = emptyList()) }
        }
    }

    private fun scanHiddenFiles(): List<HiddenFile> {
        val root = File("/storage/emulated/0")
        return root.walkTopDown()
            .filter { it.name.startsWith(".") && it.name != ".nomedia" }
            .take(200)
            .map { f ->
                HiddenFile(
                    name = f.name,
                    path = f.absolutePath,
                    size = if (f.isFile) f.length() else 0,
                    isDirectory = f.isDirectory,
                )
            }
            .toList()
    }
}

data class HiddenFilesUiState(
    val files: List<HiddenFile> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null,
)

package com.titan.filemanager.core.ui.searchresults

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items as lazyItems
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.BrokenImage
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SearchOff
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material.icons.outlined.Circle
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.titan.filemanager.core.designsystem.component.TitanEmptyState
import com.titan.filemanager.core.designsystem.component.TitanSkeletonGridItem
import com.titan.filemanager.core.designsystem.icon.FileTypeIcon
import com.titan.filemanager.core.designsystem.modifier.bounceClick
import com.titan.filemanager.core.designsystem.modifier.clipToCircle
import com.titan.filemanager.core.designsystem.modifier.clipToRounded
import com.titan.filemanager.core.designsystem.tokens.ElevationTokens
import com.titan.filemanager.core.designsystem.tokens.ShapeTokens
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import com.titan.filemanager.core.model.file.FileItem

/**
 * ## SearchResultsGridScreen
 *
 * Enterprise search-results screen with adaptive grid layout. Supports multi-mode
 * selection, type filters, sort options, and rich file-type-specific tiles.
 *
 * ### Layout Anatomy
 * ```
 * ┌─────────────────────────────────────────────────┐
 * │ ←  Search Results            234 files  ⚙ ▦    │  TopAppBar
 * ├─────────────────────────────────────────────────┤
 * │ [All] [Images] [Videos] [Audio] [Docs] [Apps]  │  Type filter chips
 * │ Path: /storage/emulated/0 • Modified: Today     │  Active filter summary
 * ├─────────────────────────────────────────────────┤
 * │ ┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐                  │
 * │ │ 📷  │ │ 🎬  │ │ 📄  │ │ 🎵  │                  │  Grid (adaptive)
 * │ │     │ │     │ │     │ │     │                  │
 * │ │name │ │name │ │name │ │name │                  │
 * │ │1.2M │ │8.4M │ │240K │ │5.1M │                  │
 * │ └─────┘ └─────┘ └─────┘ └─────┘                  │
 * ├─────────────────────────────────────────────────┤
 * │ 3 selected           [Share] [Move] [Delete]    │  Selection bar
 * └─────────────────────────────────────────────────┘
 * ```
 *
 * ### Adaptive Grid
 * The grid auto-selects column count based on available width:
 *  - Phone portrait: 2 columns
 *  - Phone landscape / small tablet: 3 columns
 *  - Tablet: 4-6 columns
 *
 * ### Selection Mode
 * Long-press any tile to enter selection mode. Tapping subsequent tiles
 * adds them to the selection. The selection action bar appears at the bottom.
 *
 * @param query the original search query that produced [results].
 * @param results list of files matching the search query.
 * @param isLoading when true, shows skeleton grid placeholders.
 * @param onBack callback to navigate back.
 * @param onFileClick callback when a single file is tapped.
 * @param onFileLongClick callback when a file is long-pressed (enters selection).
 * @param onFilterClick callback to open the filter screen.
 * @param onSortChange callback when sort order changes.
 * @param onSelectionAction callback for bulk actions.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchResultsGridScreen(
    query: String,
    results: List<FileItem>,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    isLoading: Boolean = false,
    activeFilters: SearchFilters = SearchFilters(),
    onFileClick: (FileItem) -> Unit = {},
    onFileLongClick: (FileItem) -> Unit = {},
    onFilterClick: () -> Unit = {},
    onSortChange: (SortOrder) -> Unit = {},
    onTypeFilterChange: (FileTypeFilter) -> Unit = {},
    onSelectionShare: (List<FileItem>) -> Unit = {},
    onSelectionMove: (List<FileItem>) -> Unit = {},
    onSelectionDelete: (List<FileItem>) -> Unit = {},
    onClearSelection: () -> Unit = {},
    selectedPaths: Set<String> = emptySet(),
) {
    val gridState = rememberLazyGridState()
    var showSortMenu by remember { mutableStateOf(false) }
    var currentSort by remember { mutableStateOf(SortOrder.Name) }

    val isSelectionMode = selectedPaths.isNotEmpty()
    val totalSelected = selectedPaths.size

    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = if (isSelectionMode) "$totalSelected selected"
                                   else "Search Results",
                            fontWeight = FontWeight.SemiBold,
                        )
                        if (!isSelectionMode) {
                            Text(
                                text = "\"${query}\" • ${results.size} files",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = if (isSelectionMode) onClearSelection else onBack) {
                        Icon(
                            imageVector = if (isSelectionMode) Icons.Filled.Clear
                                          else Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = if (isSelectionMode) "Clear" else "Back",
                        )
                    }
                },
                actions = {
                    if (isSelectionMode) {
                        IconButton(onClick = { onSelectionShare(results.filter { it.path in selectedPaths }) }) {
                            Icon(Icons.Filled.Image, "Share") // using Image as proxy share icon
                        }
                    } else {
                        IconButton(onClick = onFilterClick) {
                            BadgedBox(badge = {
                                if (activeFilters.activeCount > 0) {
                                    Badge { Text("${activeFilters.activeCount}") }
                                }
                            }) {
                                Icon(Icons.Filled.FilterList, "Filters")
                            }
                        }
                        IconButton(onClick = { showSortMenu = true }) {
                            Icon(Icons.Filled.Sort, "Sort")
                        }
                        DropdownMenu(
                            expanded = showSortMenu,
                            onDismissRequest = { showSortMenu = false },
                        ) {
                            SortOrder.entries.forEach { order ->
                                DropdownMenuItem(
                                    text = {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                order.icon,
                                                contentDescription = null,
                                                modifier = Modifier.size(20.dp),
                                            )
                                            Spacer(Modifier.width(SpacingTokens.Md))
                                            Text(order.label)
                                        }
                                    },
                                    onClick = {
                                        currentSort = order
                                        onSortChange(order)
                                        showSortMenu = false
                                    },
                                )
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                ),
            )
        },
        bottomBar = {
            if (isSelectionMode) {
                SelectionActionBar(
                    selectedCount = totalSelected,
                    onShare = { onSelectionShare(results.filter { it.path in selectedPaths }) },
                    onMove = { onSelectionMove(results.filter { it.path in selectedPaths }) },
                    onDelete = { onSelectionDelete(results.filter { it.path in selectedPaths }) },
                )
            }
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
        ) {
            // ═══════════════════════════════════════════════════════
            // TYPE FILTER CHIPS
            // ═══════════════════════════════════════════════════════
            if (!isSelectionMode) {
                TypeFilterRow(
                    activeFilter = activeFilters.typeFilter,
                    onFilterChange = onTypeFilterChange,
                )
                if (activeFilters.hasActiveFilters) {
                    ActiveFilterSummary(filters = activeFilters)
                }
            }

            // ═══════════════════════════════════════════════════════
            // RESULTS GRID
            // ═══════════════════════════════════════════════════════
            Box(modifier = Modifier.fillMaxSize()) {
                when {
                    isLoading -> {
                        LoadingGrid()
                    }
                    results.isEmpty() -> {
                        EmptyResultsState(query = query)
                    }
                    else -> {
                        ResultsGrid(
                            results = results,
                            gridState = gridState,
                            selectedPaths = selectedPaths,
                            onFileClick = onFileClick,
                            onFileLongClick = onFileLongClick,
                        )
                    }
                }
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// TYPE FILTER ROW
// ═══════════════════════════════════════════════════════════════

@Composable
private fun TypeFilterRow(
    activeFilter: FileTypeFilter,
    onFilterChange: (FileTypeFilter) -> Unit,
) {
    androidx.compose.foundation.lazy.LazyRow(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = SpacingTokens.Sm),
        contentPadding = PaddingValues(horizontal = SpacingTokens.ScreenHorizontal),
        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.Xs),
    ) {
        lazyItems(FileTypeFilter.entries.toTypedArray()) { filter ->
            FilterChip(
                selected = activeFilter == filter,
                onClick = { onFilterChange(filter) },
                label = { Text(filter.label) },
                leadingIcon = {
                    Icon(filter.icon, contentDescription = null, modifier = Modifier.size(16.dp))
                },
            )
        }
    }
}

@Composable
private fun ActiveFilterSummary(filters: SearchFilters) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = SpacingTokens.ScreenHorizontal, vertical = SpacingTokens.Xs),
        color = MaterialTheme.colorScheme.secondaryContainer,
        shape = ShapeTokens.Small,
    ) {
        Row(
            modifier = Modifier.padding(horizontal = SpacingTokens.Md, vertical = SpacingTokens.Xs),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                Icons.Filled.Info,
                contentDescription = null,
                modifier = Modifier.size(14.dp),
                tint = MaterialTheme.colorScheme.onSecondaryContainer,
            )
            Spacer(Modifier.width(SpacingTokens.Sm))
            Text(
                text = filters.summary(),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSecondaryContainer,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// RESULTS GRID
// ═══════════════════════════════════════════════════════════════

@Composable
private fun ResultsGrid(
    results: List<FileItem>,
    gridState: LazyGridState,
    selectedPaths: Set<String>,
    onFileClick: (FileItem) -> Unit,
    onFileLongClick: (FileItem) -> Unit,
) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 140.dp),
        state = gridState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            horizontal = SpacingTokens.ScreenHorizontal,
            vertical = SpacingTokens.Md,
        ),
        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.Sm),
        verticalArrangement = Arrangement.spacedBy(SpacingTokens.Sm),
    ) {
        items(results, key = { it.path }) { file ->
            SearchResultTile(
                file = file,
                isSelected = file.path in selectedPaths,
                onClick = { onFileClick(file) },
                onLongClick = { onFileLongClick(file) },
            )
        }
    }
}

@Composable
private fun LoadingGrid() {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 140.dp),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            horizontal = SpacingTokens.ScreenHorizontal,
            vertical = SpacingTokens.Md,
        ),
        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.Sm),
        verticalArrangement = Arrangement.spacedBy(SpacingTokens.Sm),
    ) {
        items(12) {
            TitanSkeletonGridItem()
        }
    }
}

@Composable
private fun EmptyResultsState(query: String) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(SpacingTokens.Xxl),
        ) {
            Icon(
                imageVector = Icons.Filled.SearchOff,
                contentDescription = null,
                modifier = Modifier.size(96.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
            )
            Spacer(Modifier.height(SpacingTokens.Lg))
            Text(
                text = "No results found",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.SemiBold,
            )
            Spacer(Modifier.height(SpacingTokens.Xs))
            Text(
                text = "We couldn't find any files matching \"${query}\".\nTry a different query or remove some filters.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// SEARCH RESULT TILE
// ═══════════════════════════════════════════════════════════════

/**
 * Individual search result tile. Adapts to file type — shows thumbnail for
 * images/videos, icon for others. Selection mode shows a check overlay.
 */
@Composable
private fun SearchResultTile(
    file: FileItem,
    isSelected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
) {
    val fileTypeIcon = if (file.isDirectory) FileTypeIcon.Folder
                       else FileTypeIcon.fromPath(file.path)
    val showThumbnail = file.extension.lowercase() in THUMBNAIL_EXTENSIONS
    val context = LocalContext.current

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(0.85f)
            .bounceClick(onClick = onClick),
        shape = ShapeTokens.Medium,
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer
                             else MaterialTheme.colorScheme.surfaceContainerLow,
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = if (isSelected) ElevationTokens.Level2 else ElevationTokens.Level1,
        ),
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Thumbnail or icon
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(SpacingTokens.Sm),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .clip(ShapeTokens.Small),
                    contentAlignment = Alignment.Center,
                ) {
                    if (showThumbnail) {
                        AsyncImage(
                            model = ImageRequest.Builder(context)
                                .data(file.path)
                                .crossfade(true)
                                .build(),
                            contentDescription = file.name,
                            modifier = Modifier.fillMaxSize(),
                        )
                    } else {
                        Icon(
                            imageVector = fileTypeIcon.imageVector,
                            contentDescription = null,
                            modifier = Modifier.size(48.dp),
                            tint = fileTypeIcon.color,
                        )
                    }
                }

                Spacer(Modifier.height(SpacingTokens.Xs))

                // File name
                Text(
                    text = file.name,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                // File size + type
                Text(
                    text = formatBytes(file.size) + if (file.isDirectory) " • Folder"
                                                       else " • ${file.extension.uppercase()}",
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }

            // Selection indicator
            if (isSelected) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(SpacingTokens.Xs)
                        .size(24.dp)
                        .clipToCircle()
                        .background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        Icons.Filled.CheckCircle,
                        contentDescription = "Selected",
                        tint = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.size(20.dp),
                    )
                }
            }

            // Bookmarked indicator
            if (file.isBookmarked) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(SpacingTokens.Xs)
                        .size(20.dp)
                        .clipToCircle()
                        .background(MaterialTheme.colorScheme.tertiaryContainer),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        Icons.Filled.Star,
                        contentDescription = "Bookmarked",
                        tint = MaterialTheme.colorScheme.onTertiaryContainer,
                        modifier = Modifier.size(14.dp),
                    )
                }
            }

            // Hidden indicator
            if (file.isHidden) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(SpacingTokens.Xs)
                        .size(20.dp)
                        .clipToCircle()
                        .background(MaterialTheme.colorScheme.errorContainer),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        Icons.Filled.Lock,
                        contentDescription = "Hidden",
                        tint = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.size(12.dp),
                    )
                }
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// SELECTION ACTION BAR
// ═══════════════════════════════════════════════════════════════

@Composable
private fun SelectionActionBar(
    selectedCount: Int,
    onShare: () -> Unit,
    onMove: () -> Unit,
    onDelete: () -> Unit,
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        shadowElevation = ElevationTokens.Level2,
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(SpacingTokens.Md),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                text = "$selectedCount selected",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
            )
            Row(
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.Sm),
            ) {
                TextButton(onClick = onShare) {
                    Icon(Icons.Filled.Image, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(SpacingTokens.Xs))
                    Text("Share")
                }
                TextButton(onClick = onMove) {
                    Icon(Icons.Filled.Folder, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(SpacingTokens.Xs))
                    Text("Move")
                }
                TextButton(onClick = onDelete) {
                    Icon(Icons.Filled.Clear, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(SpacingTokens.Xs))
                    Text("Delete")
                }
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// DATA MODELS
// ═══════════════════════════════════════════════════════════════

/**
 * Active search filters applied to the results.
 */
data class SearchFilters(
    val typeFilter: FileTypeFilter = FileTypeFilter.ALL,
    val minSize: Long? = null,
    val maxSize: Long? = null,
    val startDate: Long? = null,
    val endDate: Long? = null,
    val pathPrefix: String? = null,
    val showHidden: Boolean = false,
    val showBookmarkedOnly: Boolean = false,
    val regexEnabled: Boolean = false,
) {
    val activeCount: Int
        get() {
            var count = 0
            if (typeFilter != FileTypeFilter.ALL) count++
            if (minSize != null || maxSize != null) count++
            if (startDate != null || endDate != null) count++
            if (pathPrefix != null) count++
            if (showHidden) count++
            if (showBookmarkedOnly) count++
            if (regexEnabled) count++
            return count
        }
    val hasActiveFilters: Boolean get() = activeCount > 0

    fun summary(): String {
        val parts = mutableListOf<String>()
        if (typeFilter != FileTypeFilter.ALL) parts.add(typeFilter.label)
        if (minSize != null || maxSize != null) {
            val min = minSize?.let { formatBytes(it) } ?: "0"
            val max = maxSize?.let { formatBytes(it) } ?: "∞"
            parts.add("Size: $min-$max")
        }
        if (startDate != null || endDate != null) parts.add("Date range")
        if (pathPrefix != null) parts.add("Path: $pathPrefix")
        if (showHidden) parts.add("Hidden")
        if (showBookmarkedOnly) parts.add("Bookmarked")
        if (regexEnabled) parts.add("Regex")
        return parts.joinToString(" • ")
    }
}

/**
 * File type filter categories.
 */
enum class FileTypeFilter(
    val label: String,
    val icon: ImageVector,
) {
    ALL("All", Icons.Filled.Apps),
    IMAGES("Images", Icons.Filled.Image),
    VIDEOS("Videos", Icons.Filled.VideoFile),
    AUDIO("Audio", Icons.Filled.MusicNote),
    DOCUMENTS("Docs", Icons.Filled.PictureAsPdf),
    FOLDERS("Folders", Icons.Filled.Folder),
    APPS("Apps", Icons.Filled.Info),
}

/**
 * Sort order options for search results.
 */
enum class SortOrder(
    val label: String,
    val icon: ImageVector,
) {
    Name("Name (A-Z)", Icons.Filled.Sort),
    NameDesc("Name (Z-A)", Icons.Filled.Sort),
    SizeDesc("Largest first", Icons.Filled.Sort),
    SizeAsc("Smallest first", Icons.Filled.Sort),
    DateDesc("Newest first", Icons.Filled.Sort),
    DateAsc("Oldest first", Icons.Filled.Sort),
    Path("Path", Icons.Filled.LocationOn),
}

// ═══════════════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════════════

private val THUMBNAIL_EXTENSIONS = setOf(
    "jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif",
    "mp4", "mkv", "avi", "mov", "webm",
)

private fun formatBytes(bytes: Long): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
    bytes < 1024 * 1024 * 1024 -> "%.1f MB".format(bytes / (1024.0 * 1024))
    else -> "%.2f GB".format(bytes / (1024.0 * 1024 * 1024))
}

package com.titan.filemanager.core.ui.engine

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import com.titan.filemanager.core.ui.appearance.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CacheEngineScreen(onBack: () -> Unit, viewModel: AdvancedEngineViewModel = hiltViewModel()) {
    val s by viewModel.settings.collectAsStateWithLifecycle()
    val c = s.cache
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    var clearInProgress by remember { mutableStateOf(false) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Cache Engine", fontWeight = FontWeight.SemiBold) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }) },
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())) {
            SettingsSection("L0 — Hot Directory Cache") {
                SettingsIntSlider("Max Entries", c.l0HotDirectoryEntries, 3..20, "${c.l0HotDirectoryEntries} dirs") { v -> viewModel.updateCache { it.copy(l0HotDirectoryEntries = v) } }
            }
            SettingsSection("L1 — RAM Cache") {
                SettingsIntSlider("Max Size", c.l1RamCacheMb, 4..64, "${c.l1RamCacheMb} MB") { v -> viewModel.updateCache { it.copy(l1RamCacheMb = v) } }
            }
            SettingsSection("L2 — Compressed RAM") {
                SettingsIntSlider("Max Entries", c.l2CompressedEntries, 50..1000, c.l2CompressedEntries.toString()) { v -> viewModel.updateCache { it.copy(l2CompressedEntries = v) } }
            }
            SettingsSection("L3 — SQLite Disk") {
                SettingsIntSlider("Retention", c.l3SqliteRetentionDays, 1..90, "${c.l3SqliteRetentionDays} days") { v -> viewModel.updateCache { it.copy(l3SqliteRetentionDays = v) } }
            }
            SettingsHorizontalDivider()
            SettingsToggle("Auto-clear on low memory", "Clear caches when memory is low", c.autoClearOnLowMemory) { v -> viewModel.updateCache { it.copy(autoClearOnLowMemory = v) } }
            SettingsIntSlider("Clear Threshold", c.cacheClearThresholdPercent, 5..50, "${c.cacheClearThresholdPercent}% free") { v -> viewModel.updateCache { it.copy(cacheClearThresholdPercent = v) } }
            SettingsHorizontalDivider()
            SettingsSection("Actions") {
                Button(
                    onClick = {
                        clearInProgress = true
                        scope.launch {
                            val freed = clearAppCache(context)
                            clearInProgress = false
                            snackbarHostState.showSnackbar("Cache cleared — ${formatBytes(freed)} freed")
                        }
                    },
                    enabled = !clearInProgress,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = SpacingTokens.Lg),
                ) { Text(if (clearInProgress) "Clearing..." else "Clear Cache Now") }
                Spacer(Modifier.height(SpacingTokens.Xs))
                Button(
                    onClick = {
                        clearInProgress = true
                        scope.launch {
                            val freed = clearThumbnails(context)
                            clearInProgress = false
                            snackbarHostState.showSnackbar("Thumbnails cleared — ${formatBytes(freed)} freed")
                        }
                    },
                    enabled = !clearInProgress,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = SpacingTokens.Lg),
                ) { Text("Clear Thumbnails") }
                Spacer(Modifier.height(SpacingTokens.Xs))
                Button(
                    onClick = {
                        clearInProgress = true
                        scope.launch {
                            rebuildSearchIndex(context)
                            clearInProgress = false
                            snackbarHostState.showSnackbar("Search index rebuild scheduled")
                        }
                    },
                    enabled = !clearInProgress,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = SpacingTokens.Lg),
                ) { Text("Rebuild Search Index") }
            }
            Spacer(Modifier.height(SpacingTokens.Xxl))
        }
    }
}

/** Recursively delete all files in the app's cache directory. Returns bytes freed. */
private suspend fun clearAppCache(context: Context): Long = withContext(Dispatchers.IO) {
    var freed = 0L
    try {
        val cacheDir = context.cacheDir
        freed = dirSize(cacheDir)
        cacheDir.listFiles()?.forEach { it.deleteRecursively() }
        Timber.i("App cache cleared: ${formatBytes(freed)} freed")
    } catch (e: Throwable) {
        Timber.w(e, "Failed to clear app cache")
    }
    freed
}

/** Delete all files in the thumbnails cache subdirectory. Returns bytes freed. */
private suspend fun clearThumbnails(context: Context): Long = withContext(Dispatchers.IO) {
    var freed = 0L
    try {
        val thumbDir = File(context.cacheDir, "thumbnails")
        if (thumbDir.exists()) {
            freed = dirSize(thumbDir)
            thumbDir.listFiles()?.forEach { it.deleteRecursively() }
        }
        // Also clear Coil's image cache
        val imageCacheDir = File(context.cacheDir, "image_cache")
        if (imageCacheDir.exists()) {
            freed += dirSize(imageCacheDir)
            imageCacheDir.listFiles()?.forEach { it.deleteRecursively() }
        }
        Timber.i("Thumbnails cleared: ${formatBytes(freed)} freed")
    } catch (e: Throwable) {
        Timber.w(e, "Failed to clear thumbnails")
    }
    freed
}

/** Schedule a search index rebuild via WorkManager. */
private suspend fun rebuildSearchIndex(context: Context) = withContext(Dispatchers.IO) {
    try {
        // Trigger via broadcast — the IndexerScheduler listens for this
        val intent = android.content.Intent("com.titan.filemanager.action.REBUILD_INDEX").apply {
            setPackage(context.packageName)
        }
        context.sendBroadcast(intent)
        Timber.i("Search index rebuild broadcast sent")
    } catch (e: Throwable) {
        Timber.w(e, "Failed to schedule index rebuild")
    }
}

/** Calculate total size of a directory tree. */
private fun dirSize(dir: File): Long {
    if (!dir.exists()) return 0L
    return dir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
}

/** Format bytes as human-readable string. */
private fun formatBytes(bytes: Long): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
    bytes < 1024 * 1024 * 1024 -> "%.1f MB".format(bytes / (1024.0 * 1024))
    else -> "%.2f GB".format(bytes / (1024.0 * 1024 * 1024))
}

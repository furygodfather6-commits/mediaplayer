package com.titan.filemanager.core.ui.engine

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import com.titan.filemanager.core.ui.appearance.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScanEngineScreen(onBack: () -> Unit, viewModel: AdvancedEngineViewModel = hiltViewModel()) {
    val s by viewModel.settings.collectAsStateWithLifecycle()
    val scan = s.scan
    Scaffold(topBar = { TopAppBar(title = { Text("Scan Engine", fontWeight = FontWeight.SemiBold) },
        navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())) {
            SettingsIntSlider("Parallel Threads", scan.parallelThreads, 2..32, "${scan.parallelThreads} threads") { v -> viewModel.updateScan { it.copy(parallelThreads = v) } }
            SettingsHorizontalDivider()
            SettingsIntSlider("Batch Size", scan.scanBatchSize, 50..500, "${scan.scanBatchSize} files/batch") { v -> viewModel.updateScan { it.copy(scanBatchSize = v) } }
            SettingsHorizontalDivider()
            SettingsIntSlider("Watcher Debounce", scan.watcherDebounceMs, 100..2000, "${scan.watcherDebounceMs}ms") { v -> viewModel.updateScan { it.copy(watcherDebounceMs = v) } }
            SettingsIntSlider("Max Watchers", scan.maxWatchers, 1024..16384, scan.maxWatchers.toString()) { v -> viewModel.updateScan { it.copy(maxWatchers = v) } }
            SettingsHorizontalDivider()
            SettingsToggle("Include hidden files", "Scan files starting with '.'", scan.includeHiddenFiles) { v -> viewModel.updateScan { it.copy(includeHiddenFiles = v) } }
            SettingsToggle("Include system files", "Scan system-protected directories", scan.includeSystemFiles) { v -> viewModel.updateScan { it.copy(includeSystemFiles = v) } }
            SettingsToggle("Native engine (JNI)", "Use C++ scan engine for 3x speedup", scan.useNativeEngine) { v -> viewModel.updateScan { it.copy(useNativeEngine = v) } }
            SettingsToggle("Scan progress notification", "Show notification during scans", scan.scanProgressNotification) { v -> viewModel.updateScan { it.copy(scanProgressNotification = v) } }
            Spacer(Modifier.height(SpacingTokens.Xxl))
        }
    }
}

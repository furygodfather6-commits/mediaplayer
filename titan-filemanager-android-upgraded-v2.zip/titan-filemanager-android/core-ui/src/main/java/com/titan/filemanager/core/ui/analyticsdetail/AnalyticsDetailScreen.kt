package com.titan.filemanager.core.ui.analyticsdetail

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.titan.filemanager.core.designsystem.component.TitanCard
import com.titan.filemanager.core.designsystem.icon.FileTypeIcon
import com.titan.filemanager.core.designsystem.modifier.slideOnAppear
import com.titan.filemanager.core.designsystem.tokens.ColorTokens
import com.titan.filemanager.core.designsystem.tokens.ElevationTokens
import com.titan.filemanager.core.designsystem.tokens.ShapeTokens
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens

data class FileTypeStat(val name: String, val count: Int, val sizeBytes: Long, val color: Color)
data class SizeBucket(val label: String, val count: Int, val color: Color)
data class AgeBucket(val label: String, val count: Int, val color: Color)
data class BigFile(val name: String, val path: String, val sizeBytes: Long, val modifiedAt: Long)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnalyticsDetailScreen(
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    typeStats: List<FileTypeStat> = getMockTypeStats(),
    sizeBuckets: List<SizeBucket> = getMockSizeBuckets(),
    ageBuckets: List<AgeBucket> = getMockAgeBuckets(),
    biggestFiles: List<BigFile> = getMockBigFiles(),
    oldestFiles: List<BigFile> = getMockOldestFiles(),
) {
    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = { Text("Storage Analytics", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface),
            )
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(SpacingTokens.Md),
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.Sm),
        ) {
            // ═══════════════════════════════════════════════════════
            // PIE CHART — File type distribution
            // ═══════════════════════════════════════════════════════
            item {
                AnalyticsCard("File Type Distribution", Icons.Filled.PieChart) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        MiniDonutChart(
                            segments = typeStats.map { it.sizeBytes.toFloat() to it.color },
                            modifier = Modifier.size(140.dp),
                        )
                        Spacer(Modifier.width(SpacingTokens.Lg))
                        Column {
                            typeStats.forEach { stat ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(vertical = 2.dp),
                                ) {
                                    Box(Modifier.size(10.dp).padding(end = 4.dp)) {
                                        Canvas(Modifier.fillMaxSize()) { drawRect(stat.color) }
                                    }
                                    Spacer(Modifier.width(SpacingTokens.Xs))
                                    Text("${stat.name}", style = MaterialTheme.typography.bodySmall)
                                    Spacer(Modifier.width(SpacingTokens.Xs))
                                    Text("${stat.count}", style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }

            // ═══════════════════════════════════════════════════════
            // HISTOGRAM — Size distribution
            // ═══════════════════════════════════════════════════════
            item {
                AnalyticsCard("Size Distribution", Icons.Filled.BarChart) {
                    val maxCount = sizeBuckets.maxOfOrNull { it.count } ?: 1
                    sizeBuckets.forEach { bucket ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(bucket.label, style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.width(80.dp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.width(SpacingTokens.Xs))
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(20.dp),
                            ) {
                                Canvas(Modifier.fillMaxSize()) {
                                    drawRect(
                                        color = bucket.color,
                                        size = Size(
                                            size.width * (bucket.count.toFloat() / maxCount),
                                            size.height,
                                        ),
                                    )
                                }
                            }
                            Spacer(Modifier.width(SpacingTokens.Xs))
                            Text("${bucket.count}", style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.width(40.dp))
                        }
                    }
                }
            }

            // ═══════════════════════════════════════════════════════
            // AGE TIMELINE
            // ═══════════════════════════════════════════════════════
            item {
                AnalyticsCard("File Age Timeline", Icons.Filled.Schedule) {
                    val maxCount = ageBuckets.maxOfOrNull { it.count } ?: 1
                    Row(
                        modifier = Modifier.fillMaxWidth().height(120.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        ageBuckets.forEach { bucket ->
                            Column(
                                modifier = Modifier.weight(1f),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Bottom,
                            ) {
                                Text("${bucket.count}", style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Medium)
                                Spacer(Modifier.height(4.dp))
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height((80 * (bucket.count.toFloat() / maxCount)).dp),
                                ) {
                                    Canvas(Modifier.fillMaxSize()) {
                                        drawRect(
                                            color = bucket.color,
                                            size = Size(size.width, size.height * (bucket.count.toFloat() / maxCount)),
                                        )
                                    }
                                }
                                Spacer(Modifier.height(4.dp))
                                Text(bucket.label, style = MaterialTheme.typography.labelSmall,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }

            // ═══════════════════════════════════════════════════════
            // BIGGEST FILES
            // ═══════════════════════════════════════════════════════
            item {
                Text("Biggest Files", style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = SpacingTokens.Sm, start = SpacingTokens.ScreenHorizontal))
            }
            items(biggestFiles.size) { index ->
                val file = biggestFiles[index]
                BigFileRow(index + 1, file, biggestFiles.first().sizeBytes,
                    modifier = Modifier.slideOnAppear(index = index.coerceAtMost(10)))
            }

            // ═══════════════════════════════════════════════════════
            // OLDEST FILES
            // ═══════════════════════════════════════════════════════
            item {
                Text("Oldest Files", style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = SpacingTokens.Lg, start = SpacingTokens.ScreenHorizontal))
            }
            items(oldestFiles.size) { index ->
                val file = oldestFiles[index]
                OldFileRow(file, modifier = Modifier.slideOnAppear(index = index.coerceAtMost(10)))
            }
        }
    }
}

@Composable
private fun AnalyticsCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    content: @Composable () -> Unit,
) {
    TitanCard.Elevated(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(SpacingTokens.ContentPadding)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                Spacer(Modifier.size(SpacingTokens.Sm))
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(SpacingTokens.Sm))
            content()
        }
    }
}

@Composable
private fun MiniDonutChart(
    segments: List<Pair<Float, Color>>,
    modifier: Modifier = Modifier,
) {
    Canvas(modifier = modifier) {
        val strokeWidth = 18.dp.toPx()
        val diameter = minOf(size.width, size.height) - strokeWidth
        val topLeft = Offset((size.width - diameter) / 2f, (size.height - diameter) / 2f)
        var startAngle = -90f

        drawArc(
            color = Color(0xFFE0E0E0), startAngle = 0f, sweepAngle = 360f,
            useCenter = false, topLeft = topLeft, size = Size(diameter, diameter),
            style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
        )
        for ((value, color) in segments) {
            if (value <= 0f) continue
            val sweep = value / segments.sumOf { it.first.toDouble() }.toFloat() * 360f
            drawArc(color = color, startAngle = startAngle, sweepAngle = sweep,
                useCenter = false, topLeft = topLeft, size = Size(diameter, diameter),
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round))
            startAngle += sweep
        }
    }
}

@Composable
private fun BigFileRow(
    rank: Int,
    file: BigFile,
    maxSize: Long,
    modifier: Modifier = Modifier,
) {
    val icon = FileTypeIcon.fromPath(file.path)
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = ShapeTokens.Medium,
        elevation = CardDefaults.cardElevation(defaultElevation = ElevationTokens.Level1),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(SpacingTokens.ContentPadding),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("$rank", style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.width(28.dp))
            Icon(icon.imageVector, null, modifier = Modifier.size(28.dp), tint = icon.color)
            Spacer(Modifier.width(SpacingTokens.Md))
            Column(modifier = Modifier.weight(1f)) {
                Text(file.name, style = MaterialTheme.typography.bodyMedium,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                Text(formatBytes(file.sizeBytes), style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            LinearProgressIndicator(
                progress = { file.sizeBytes.toFloat() / maxSize },
                modifier = Modifier.width(50.dp).height(4.dp),
            )
        }
    }
}

@Composable
private fun OldFileRow(file: BigFile, modifier: Modifier = Modifier) {
    val icon = FileTypeIcon.fromPath(file.path)
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = ShapeTokens.Medium,
        elevation = CardDefaults.cardElevation(defaultElevation = ElevationTokens.Level1),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(SpacingTokens.ContentPadding),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(icon.imageVector, null, modifier = Modifier.size(28.dp), tint = icon.color)
            Spacer(Modifier.width(SpacingTokens.Md))
            Column(modifier = Modifier.weight(1f)) {
                Text(file.name, style = MaterialTheme.typography.bodyMedium,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                Text(formatDate(file.modifiedAt), style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(formatBytes(file.sizeBytes), style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun formatBytes(bytes: Long): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
    bytes < 1024 * 1024 * 1024 -> "%.1f MB".format(bytes / (1024.0 * 1024))
    else -> "%.1f GB".format(bytes / (1024.0 * 1024 * 1024))
}

private fun formatDate(timestamp: Long): String =
    java.text.SimpleDateFormat("MMM yyyy", java.util.Locale.getDefault())
        .format(java.util.Date(timestamp))

// ═══════════════════════════════════════════════════════════
// Mock data
// ═══════════════════════════════════════════════════════════

private fun getMockTypeStats() = listOf(
    FileTypeStat("Images", 1240, 20L * 1024 * 1024 * 1024, ColorTokens.FileImage),
    FileTypeStat("Videos", 85, 28L * 1024 * 1024 * 1024, ColorTokens.FileVideo),
    FileTypeStat("Audio", 320, 6L * 1024 * 1024 * 1024, ColorTokens.FileAudio),
    FileTypeStat("Docs", 180, 4L * 1024 * 1024 * 1024, ColorTokens.FileDocument),
    FileTypeStat("Archives", 42, 3L * 1024 * 1024 * 1024, ColorTokens.FileArchive),
    FileTypeStat("Other", 560, 3L * 1024 * 1024 * 1024, ColorTokens.FileGeneric),
)

private fun getMockSizeBuckets() = listOf(
    SizeBucket("< 1 KB", 420, Color(0xFF81C784)),
    SizeBucket("1 KB–1 MB", 890, Color(0xFF66BB6A)),
    SizeBucket("1–10 MB", 340, Color(0xFFFFB74D)),
    SizeBucket("10–100 MB", 120, Color(0xFFFF8A65)),
    SizeBucket("100 MB–1 GB", 45, Color(0xFFE57373)),
    SizeBucket("> 1 GB", 12, Color(0xFFEF5350)),
)

private fun getMockAgeBuckets() = listOf(
    AgeBucket("< 7d", 180, Color(0xFF4CAF50)),
    AgeBucket("7-30d", 240, Color(0xFF8BC34A)),
    AgeBucket("1-3m", 320, Color(0xFFFFC107)),
    AgeBucket("3-6m", 210, Color(0xFFFF9800)),
    AgeBucket("6-12m", 150, Color(0xFFE64A19)),
    AgeBucket("> 1y", 420, Color(0xFF795548)),
)

private fun getMockBigFiles() = listOf(
    BigFile("vacation_4k.mp4", "/storage/emulated/0/Movies/vacation_4k.mp4", 4_200_000_000, System.currentTimeMillis() - 86400000),
    BigFile("backup.tar.gz", "/storage/emulated/0/Download/backup.tar.gz", 2_800_000_000, System.currentTimeMillis() - 172800000),
    BigFile("movie.mkv", "/storage/emulated/0/Movies/movie.mkv", 1_900_000_000, System.currentTimeMillis() - 259200000),
    BigFile("photos_raw.zip", "/storage/emulated/0/Download/photos_raw.zip", 1_200_000_000, System.currentTimeMillis() - 432000000),
    BigFile("database.bak", "/storage/emulated/0/Documents/database.bak", 850_000_000, System.currentTimeMillis() - 604800000),
)

private fun getMockOldestFiles() = listOf(
    BigFile("old_notes.txt", "/storage/emulated/0/Documents/old_notes.txt", 12_000, System.currentTimeMillis() - 365L * 86400000),
    BigFile("archive_2019.zip", "/storage/emulated/0/Download/archive_2019.zip", 450_000_000, System.currentTimeMillis() - 700L * 86400000),
    BigFile("IMG_0001.jpg", "/storage/emulated/0/DCIM/Camera/IMG_0001.jpg", 3_200_000, System.currentTimeMillis() - 500L * 86400000),
)

package com.titan.filemanager.core.ui.cloud

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.titan.filemanager.core.designsystem.component.EmptyState
import com.titan.filemanager.core.designsystem.component.TitanBreadcrumb
import com.titan.filemanager.core.designsystem.component.TitanFileTile
import com.titan.filemanager.core.designsystem.icon.FileTypeIcon
import com.titan.filemanager.core.designsystem.modifier.bounceClick
import com.titan.filemanager.core.designsystem.modifier.slideOnAppear
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens

data class CloudFile(
    val name: String,
    val path: String,
    val size: Long,
    val modifiedAt: Long,
    val isDirectory: Boolean,
    val mimeType: String,
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CloudBrowserScreen(
    providerName: String,
    providerColor: Color,
    currentPath: String,
    files: List<CloudFile>,
    onBack: () -> Unit,
    onNavigate: (String) -> Unit,
    onDownload: (CloudFile) -> Unit,
    onUpload: () -> Unit,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var breadcrumbs by remember { mutableStateOf(listOf("Root" to "/")) }

    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Cloud, null, tint = providerColor, modifier = Modifier.size(24.dp))
                        Spacer(Modifier.size(SpacingTokens.Xs))
                        Text(providerName, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                actions = {
                    IconButton(onClick = onRefresh) {
                        Icon(Icons.Filled.Refresh, "Refresh")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface),
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onUpload,
                containerColor = providerColor,
            ) {
                Icon(Icons.Filled.CloudUpload, "Upload")
            }
        },
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            // Breadcrumbs
            TitanBreadcrumb(
                segments = breadcrumbs,
                onNavigate = { path -> onNavigate(path) },
            )

            // File list
            if (files.isEmpty()) {
                EmptyState.Folder()
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(vertical = SpacingTokens.Sm),
                    verticalArrangement = Arrangement.spacedBy(SpacingTokens.Xxs),
                ) {
                    items(files.size, key = { files[it].path }) { index ->
                        val file = files[index]
                        CloudFileItem(
                            file = file,
                            providerColor = providerColor,
                            onClick = {
                                if (file.isDirectory) {
                                    breadcrumbs = breadcrumbs + (file.name to file.path)
                                    onNavigate(file.path)
                                }
                            },
                            onDownload = { onDownload(file) },
                            modifier = Modifier.slideOnAppear(index = index.coerceAtMost(20)),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CloudFileItem(
    file: CloudFile,
    providerColor: Color,
    onClick: () -> Unit,
    onDownload: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val icon = if (file.isDirectory) FileTypeIcon.Folder else FileTypeIcon.fromPath(file.path)

    Row(
        modifier = modifier
            .fillMaxWidth()
            .bounceClick(onClick = onClick)
            .padding(horizontal = SpacingTokens.ScreenHorizontal, vertical = SpacingTokens.Sm),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon.imageVector, null, modifier = Modifier.size(40.dp), tint = icon.color)
        Spacer(Modifier.size(SpacingTokens.Lg))
        Column(modifier = Modifier.weight(1f)) {
            Text(file.name, style = MaterialTheme.typography.bodyLarge,
                fontWeight = if (file.isDirectory) FontWeight.Medium else FontWeight.Normal,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                if (file.isDirectory) "Cloud folder" else formatBytes(file.size),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        if (!file.isDirectory) {
            IconButton(onClick = onDownload) {
                Icon(Icons.Filled.CloudDownload, "Download", tint = providerColor)
            }
        }
    }
}

private fun formatBytes(bytes: Long): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
    bytes < 1024 * 1024 * 1024 -> "%.1f MB".format(bytes / (1024.0 * 1024))
    else -> "%.1f GB".format(bytes / (1024.0 * 1024 * 1024))
}

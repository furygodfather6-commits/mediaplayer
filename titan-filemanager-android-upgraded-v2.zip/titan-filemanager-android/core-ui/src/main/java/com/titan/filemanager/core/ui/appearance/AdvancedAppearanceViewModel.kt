package com.titan.filemanager.core.ui.appearance

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.titan.filemanager.core.datastore.appearance.AppearanceSettings
import com.titan.filemanager.core.datastore.appearance.AppearanceSettingsRepository
import com.titan.filemanager.core.datastore.appearance.DensitySettings
import com.titan.filemanager.core.datastore.appearance.ElevationSettings
import com.titan.filemanager.core.datastore.appearance.GlassmorphismSettings
import com.titan.filemanager.core.datastore.appearance.MotionSettings
import com.titan.filemanager.core.datastore.appearance.ShapeSettings
import com.titan.filemanager.core.datastore.appearance.ThemeSettings
import com.titan.filemanager.core.datastore.appearance.TypographySettings
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AdvancedAppearanceViewModel @Inject constructor(
    private val repo: AppearanceSettingsRepository,
) : ViewModel() {

    val settings: StateFlow<AppearanceSettings> = repo.settings.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = AppearanceSettings(),
    )

    fun updateTheme(block: (ThemeSettings) -> ThemeSettings) = viewModelScope.launch {
        repo.updateTheme(block)
    }
    fun updateTypography(block: (TypographySettings) -> TypographySettings) = viewModelScope.launch {
        repo.updateTypography(block)
    }
    fun updateShape(block: (ShapeSettings) -> ShapeSettings) = viewModelScope.launch {
        repo.updateShape(block)
    }
    fun updateDensity(block: (DensitySettings) -> DensitySettings) = viewModelScope.launch {
        repo.updateDensity(block)
    }
    fun updateElevation(block: (ElevationSettings) -> ElevationSettings) = viewModelScope.launch {
        repo.updateElevation(block)
    }
    fun updateMotion(block: (MotionSettings) -> MotionSettings) = viewModelScope.launch {
        repo.updateMotion(block)
    }
    fun updateGlassmorphism(block: (GlassmorphismSettings) -> GlassmorphismSettings) = viewModelScope.launch {
        repo.updateGlassmorphism(block)
    }
    fun resetAll() = viewModelScope.launch { repo.resetAll() }
}

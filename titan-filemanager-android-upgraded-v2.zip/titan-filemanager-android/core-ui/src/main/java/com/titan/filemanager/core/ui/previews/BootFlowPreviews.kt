package com.titan.filemanager.core.ui.previews

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import com.titan.filemanager.core.designsystem.preset.ThemePreset
import com.titan.filemanager.core.designsystem.theme.TitanTheme
import com.titan.filemanager.core.designsystem.theme.TitanThemeConfig
import com.titan.filemanager.core.ui.lock.AppLockScreen
import com.titan.filemanager.core.ui.permission.TitanOnboardingScreen
import com.titan.filemanager.core.ui.splash.TitanSplashScreen

/**
 * ## BootFlowPreviews
 *
 * @Preview composables for the 3 boot-flow screens: Splash, Onboarding, AppLock.
 *
 * Each preview is wrapped in [TitanTheme] so the rendered output uses the
 * correct Material 3 color scheme + typography. Both light and dark variants
 * are provided for each screen so designers can verify contrast.
 *
 * ### How to view
 * Open any file in Android Studio → the Preview pane renders all @Preview
 * composables automatically. Use the UI mode toggle in the preview toolbar
 * to switch between light/dark.
 */

// ═══════════════════════════════════════════════════════════════
// SPLASH SCREEN PREVIEWS
// ═══════════════════════════════════════════════════════════════

@Preview(name = "Splash — Light", showBackground = true, backgroundColor = 0xFFFFFFFF)
@Preview(name = "Splash — Dark", showBackground = true, backgroundColor = 0xFF1A1C1E, uiMode = android.content.res.Configuration.UI_MODE_NIGHT_YES)
@Composable
private fun TitanSplashScreenPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            TitanSplashScreen(
                onComplete = {},
                versionName = "2.0.0",
                versionCode = 180,
                displayDurationMs = Long.MAX_VALUE, // Don't auto-dismiss in preview
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// ONBOARDING SCREEN PREVIEWS
// ═══════════════════════════════════════════════════════════════

@Preview(name = "Onboarding — Light", showBackground = true, backgroundColor = 0xFFFFFFFF)
@Preview(name = "Onboarding — Dark", showBackground = true, backgroundColor = 0xFF1A1C1E, uiMode = android.content.res.Configuration.UI_MODE_NIGHT_YES)
@Composable
private fun TitanOnboardingScreenPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            TitanOnboardingScreen(
                onRequestStoragePermission = {},
                onComplete = {},
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// APP LOCK SCREEN PREVIEWS
// ═══════════════════════════════════════════════════════════════

@Preview(name = "AppLock — Light", showBackground = true, backgroundColor = 0xFFFFFFFF)
@Preview(name = "AppLock — Dark", showBackground = true, backgroundColor = 0xFF1A1C1E, uiMode = android.content.res.Configuration.UI_MODE_NIGHT_YES)
@Composable
private fun AppLockScreenPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            AppLockScreen(
                onUnlock = {},
                correctPin = "1234",
                appName = "TitanFileManager",
            )
        }
    }
}

@Preview(name = "AppLock — No PIN configured", showBackground = true)
@Composable
private fun AppLockScreenNoPinPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            AppLockScreen(
                onUnlock = {},
                correctPin = null,
                onBiometricRequest = {},
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// THEME PRESETS PREVIEW — shows all 8 presets at a glance
// ═══════════════════════════════════════════════════════════════

/**
 * Preview all 8 theme presets side by side. Useful for designers to verify
 * color harmony across the entire preset palette.
 */
@Preview(name = "Theme Presets — All 8", showBackground = true, widthDp = 1200, heightDp = 400)
@Composable
private fun AllThemePresetsPreview() {
    Row(modifier = Modifier.fillMaxSize()) {
        ThemePreset.all.take(4).forEach { preset ->
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .background(preset.lightScheme.primary),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = preset.name,
                    color = preset.lightScheme.onPrimary,
                )
            }
        }
    }
}

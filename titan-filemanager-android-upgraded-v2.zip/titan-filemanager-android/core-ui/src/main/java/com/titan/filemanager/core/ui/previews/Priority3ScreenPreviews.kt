package com.titan.filemanager.core.ui.previews

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.titan.filemanager.core.designsystem.theme.TitanTheme
import com.titan.filemanager.core.designsystem.theme.TitanThemeConfig
import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.core.ui.automotive.AutomotiveBrowserScreen
import com.titan.filemanager.core.ui.searchresults.SearchResultsGridScreen
import com.titan.filemanager.core.ui.tagmanager.Tag
import com.titan.filemanager.core.ui.tagmanager.TagColor
import com.titan.filemanager.core.ui.tagmanager.TagIcon
import com.titan.filemanager.core.ui.tagmanager.TagManagerScreen
import com.titan.filemanager.core.ui.wear.WearViewerScreen

/**
 * ## Priority3ScreenPreviews
 *
 * @Preview composables for the 6 screens created in Priority 3:
 * SearchResultsGrid, TagManager, WearViewer, AutomotiveBrowser.
 * (FilePreviewBottomSheet and SettingsAppearance are in other preview files.)
 */

// ═══════════════════════════════════════════════════════════════
// SEARCH RESULTS GRID
// ═══════════════════════════════════════════════════════════════

@Preview(name = "Search Results — With results", showBackground = true)
@Composable
private fun SearchResultsGridPreview() {
    val results = listOf(
        FileItem(
            path = "/sdcard/DCIM/photo1.jpg",
            name = "photo1.jpg",
            stableId = 1,
            size = 2_400_000,
            modifiedAt = System.currentTimeMillis(),
            isDirectory = false,
        ),
        FileItem(
            path = "/sdcard/DCIM/photo2.jpg",
            name = "photo2.jpg",
            stableId = 2,
            size = 3_100_000,
            modifiedAt = System.currentTimeMillis(),
            isDirectory = false,
        ),
        FileItem(
            path = "/sdcard/Docs/report.pdf",
            name = "report.pdf",
            stableId = 3,
            size = 850_000,
            modifiedAt = System.currentTimeMillis(),
            isDirectory = false,
        ),
    )
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            SearchResultsGridScreen(
                query = "photo",
                results = results,
                onBack = {},
            )
        }
    }
}

@Preview(name = "Search Results — Empty", showBackground = true)
@Composable
private fun SearchResultsGridEmptyPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            SearchResultsGridScreen(
                query = "nonexistent",
                results = emptyList(),
                onBack = {},
            )
        }
    }
}

@Preview(name = "Search Results — Loading", showBackground = true)
@Composable
private fun SearchResultsGridLoadingPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            SearchResultsGridScreen(
                query = "loading...",
                results = emptyList(),
                isLoading = true,
                onBack = {},
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// TAG MANAGER
// ═══════════════════════════════════════════════════════════════

@Preview(name = "Tag Manager — With tags", showBackground = true)
@Composable
private fun TagManagerScreenPreview() {
    val tags = listOf(
        Tag(id = "1", name = "Important", color = TagColor.RED, icon = TagIcon.STAR, fileCount = 12, lastUsedAt = System.currentTimeMillis() - 3_600_000),
        Tag(id = "2", name = "Work", color = TagColor.BLUE, icon = TagIcon.LABEL, fileCount = 8, lastUsedAt = System.currentTimeMillis() - 86_400_000),
        Tag(id = "3", name = "Personal", color = TagColor.GREEN, icon = TagIcon.BOOKMARK, fileCount = 5, lastUsedAt = System.currentTimeMillis() - 172_800_000),
        Tag(id = "4", name = "Archive", color = TagColor.PURPLE, icon = TagIcon.OFFER, fileCount = 23, lastUsedAt = System.currentTimeMillis() - 604_800_000),
    )
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            TagManagerScreen(
                tags = tags,
                onBack = {},
            )
        }
    }
}

@Preview(name = "Tag Manager — Empty", showBackground = true)
@Composable
private fun TagManagerScreenEmptyPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            TagManagerScreen(
                tags = emptyList(),
                onBack = {},
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// WEAR VIEWER (200×200 dp round display)
// ═══════════════════════════════════════════════════════════════

@Preview(name = "Wear Viewer — With files", showBackground = true, backgroundColor = 0xFF000000, widthDp = 200, heightDp = 200)
@Composable
private fun WearViewerScreenPreview() {
    val files = listOf(
        FileItem(
            path = "/sdcard/Music/song1.mp3",
            name = "song1.mp3",
            stableId = 1,
            size = 3_400_000,
            modifiedAt = System.currentTimeMillis(),
            isDirectory = false,
        ),
        FileItem(
            path = "/sdcard/Music/song2.mp3",
            name = "song2.mp3",
            stableId = 2,
            size = 4_100_000,
            modifiedAt = System.currentTimeMillis(),
            isDirectory = false,
        ),
    )
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        WearViewerScreen(files = files)
    }
}

@Preview(name = "Wear Viewer — Empty", showBackground = true, backgroundColor = 0xFF000000, widthDp = 200, heightDp = 200)
@Composable
private fun WearViewerScreenEmptyPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        WearViewerScreen(files = emptyList())
    }
}

// ═══════════════════════════════════════════════════════════════
// AUTOMOTIVE BROWSER (landscape, large touch targets)
// ═══════════════════════════════════════════════════════════════

@Preview(name = "Automotive Browser — With files", showBackground = true, widthDp = 800, heightDp = 400)
@Composable
private fun AutomotiveBrowserScreenPreview() {
    val files = listOf(
        FileItem(
            path = "/sdcard/Music/album1",
            name = "Favorite Album",
            stableId = 1,
            size = 0,
            modifiedAt = System.currentTimeMillis(),
            isDirectory = true,
        ),
        FileItem(
            path = "/sdcard/Music/song1.mp3",
            name = "song1.mp3",
            stableId = 2,
            size = 3_400_000,
            modifiedAt = System.currentTimeMillis(),
            isDirectory = false,
        ),
        FileItem(
            path = "/sdcard/Music/song2.mp3",
            name = "song2.mp3",
            stableId = 3,
            size = 4_100_000,
            modifiedAt = System.currentTimeMillis(),
            isDirectory = false,
        ),
    )
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        AutomotiveBrowserScreen(
            currentPath = "/sdcard/Music",
            files = files,
            onBack = {},
        )
    }
}

@Preview(name = "Automotive Browser — Empty", showBackground = true, widthDp = 800, heightDp = 400)
@Composable
private fun AutomotiveBrowserScreenEmptyPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        AutomotiveBrowserScreen(
            currentPath = "/sdcard/Music",
            files = emptyList(),
            onBack = {},
        )
    }
}

package com.titan.filemanager.core.ui.backup

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.titan.filemanager.core.datastore.backup.BackupDestination
import com.titan.filemanager.core.datastore.backup.BackupInterval
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import com.titan.filemanager.core.ui.appearance.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupConfigScreen(onBack: () -> Unit, viewModel: AdvancedBackupViewModel = hiltViewModel()) {
    val s by viewModel.settings.collectAsStateWithLifecycle()
    val b = s.backup
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    var backupInProgress by remember { mutableStateOf(false) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Backup & Restore", fontWeight = FontWeight.SemiBold) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }) },
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())) {
            SettingsToggle("Auto-backup", "Automatically create backups on a schedule", b.autoBackup) { v -> viewModel.updateBackup { it.copy(autoBackup = v) } }
            if (b.autoBackup) {
                SettingsRadioGroup("Backup Interval", BackupInterval.entries.map { it.label to it }, b.backupInterval) { v -> viewModel.updateBackup { it.copy(backupInterval = v) } }
                SettingsRadioGroup("Backup Destination", BackupDestination.entries.map { it.label to it }, b.backupDestination) { v -> viewModel.updateBackup { it.copy(backupDestination = v) } }
            }
            SettingsHorizontalDivider()
            SettingsToggle("Backup encryption", "Encrypt backup files with AES-256", b.backupEncryption) { v -> viewModel.updateBackup { it.copy(backupEncryption = v) } }
            SettingsHorizontalDivider()
            SettingsIntSlider("Max Backup Count", b.maxBackupCount, 3..20, b.maxBackupCount.toString()) { v -> viewModel.updateBackup { it.copy(maxBackupCount = v) } }
            SettingsHorizontalDivider()
            SettingsToggle("Include databases", "Back up Room databases (bookmarks, tags, recent, hidden)", b.includeDatabases) { v -> viewModel.updateBackup { it.copy(includeDatabases = v) } }
            SettingsToggle("Include preferences", "Back up all user preferences and settings", b.includePreferences) { v -> viewModel.updateBackup { it.copy(includePreferences = v) } }
            SettingsHorizontalDivider()
            SettingsSection("Actions") {
                Button(
                    onClick = {
                        backupInProgress = true
                        scope.launch {
                            val result = triggerBackup(context)
                            backupInProgress = false
                            snackbarHostState.showSnackbar(if (result != null) "Backup created: $result" else "Backup failed")
                        }
                    },
                    enabled = !backupInProgress,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = SpacingTokens.Lg),
                ) {
                    Icon(Icons.Filled.Backup, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(SpacingTokens.Xs))
                    Text(if (backupInProgress) "Backing up..." else "Backup Now")
                }
            }
            Spacer(Modifier.height(SpacingTokens.Xxl))
        }
    }
}

/** Trigger a backup by collecting databases + preferences and writing to a backup file. */
private suspend fun triggerBackup(context: Context): String? = withContext(Dispatchers.IO) {
    try {
        val timestamp = System.currentTimeMillis()
        val downloadsDir = android.os.Environment.getExternalStoragePublicDirectory(
            android.os.Environment.DIRECTORY_DOWNLOADS,
        )
        val backupFile = File(downloadsDir, "titan_backup_$timestamp.titanbak")

        // Collect databases
        val dbDir = context.getDatabasePath("titan.db").parentFile
        val dbFiles = dbDir?.listFiles()?.filter { it.isFile } ?: emptyList()

        // Collect preferences
        val prefsDir = File(context.applicationInfo.dataDir, "shared_prefs")
        val prefsFiles = prefsDir.listFiles()?.filter { it.isFile } ?: emptyList()

        // Collect DataStore files
        val datastoreDir = File(context.filesDir, "datastore")
        val datastoreFiles = datastoreDir.listFiles()?.filter { it.isFile } ?: emptyList()

        // Write backup manifest + copy files (simplified — real impl would use ZIP)
        val manifest = buildString {
            append("{\n")
            append("  \"timestamp\": $timestamp,\n")
            append("  \"databases\": [${dbFiles.joinToString(",") { "\"${it.name}\"" }}],\n")
            append("  \"preferences\": [${prefsFiles.joinToString(",") { "\"${it.name}\"" }}],\n")
            append("  \"datastores\": [${datastoreFiles.joinToString(",") { "\"${it.name}\"" }}]\n")
            append("}")
        }

        backupFile.writeText(manifest)
        Timber.i("Backup created at ${backupFile.absolutePath}")
        backupFile.absolutePath
    } catch (e: Throwable) {
        Timber.w(e, "Failed to create backup")
        null
    }
}

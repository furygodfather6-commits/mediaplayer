package com.titan.filemanager.core.ui.settingsabout

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.titan.filemanager.core.designsystem.component.TitanCard
import com.titan.filemanager.core.designsystem.component.TitanFileInfoRow
import com.titan.filemanager.core.designsystem.modifier.bounceClick
import com.titan.filemanager.core.designsystem.modifier.clipToCircle
import com.titan.filemanager.core.designsystem.modifier.neonGlow
import com.titan.filemanager.core.designsystem.tokens.ElevationTokens
import com.titan.filemanager.core.designsystem.tokens.ShapeTokens
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsAboutScreen(
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    versionName: String = "2.0.0",
    versionCode: Int = 180,
    buildDate: String = "Jul 04, 2026",
    onRateApp: () -> Unit = {},
    onReportBug: () -> Unit = {},
    onViewSource: () -> Unit = {},
    onViewPrivacy: () -> Unit = {},
    onViewTerms: () -> Unit = {},
    onViewLicenses: () -> Unit = {},
) {
    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = { Text("About", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface),
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(SpacingTokens.Md),
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.Sm),
        ) {
            // ═══════════════════════════════════════════════════════
            // APP IDENTITY
            // ═══════════════════════════════════════════════════════
            TitanCard.Gradient(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(SpacingTokens.Xl),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Icon(
                        Icons.Filled.Folder,
                        null,
                        modifier = Modifier
                            .size(72.dp)
                            .clipToCircle()
                            .neonGlow(androidx.compose.ui.graphics.Color.White, 20.dp),
                        tint = androidx.compose.ui.graphics.Color.White,
                    )
                    Spacer(Modifier.height(SpacingTokens.Md))
                    Text("TitanFileManager", style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold, color = androidx.compose.ui.graphics.Color.White)
                    Text("Enterprise Edition", style = MaterialTheme.typography.bodyMedium,
                        color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.8f))
                    Spacer(Modifier.height(SpacingTokens.Xs))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Verified, null, modifier = Modifier.size(16.dp),
                            tint = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.7f))
                        Spacer(Modifier.size(SpacingTokens.Xs))
                        Text("v$versionName • Build $versionCode", style = MaterialTheme.typography.labelMedium,
                            color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.7f))
                    }
                    Text("Built on $buildDate", style = MaterialTheme.typography.labelSmall,
                        color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.5f))
                }
            }

            // ═══════════════════════════════════════════════════════
            // BUILD INFO
            // ═══════════════════════════════════════════════════════
            TitanCard.Elevated(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(SpacingTokens.ContentPadding)) {
                    AboutSectionHeader("Build Information", Icons.Filled.Info)
                    TitanFileInfoRow("Version", versionName)
                    TitanFileInfoRow("Build Code", versionCode.toString())
                    TitanFileInfoRow("Build Date", buildDate)
                    TitanFileInfoRow("Techniques", "180 / 180 ✅")
                    TitanFileInfoRow("Architecture", "66 Gradle Modules")
                    TitanFileInfoRow("Native Libraries", "4 (.so: scan, crypto, archive, media)")
                    TitanFileInfoRow("Min Android", "8.0 (API 26)")
                    TitanFileInfoRow("Target Android", "14 (API 34)")
                }
            }

            // ═══════════════════════════════════════════════════════
            // CHANGELOG
            // ═══════════════════════════════════════════════════════
            TitanCard.Elevated(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(SpacingTokens.ContentPadding)) {
                    AboutSectionHeader("What's New", Icons.Filled.History)
                    Spacer(Modifier.height(SpacingTokens.Xs))
                    ChangelogItem("2.0.0", "Complete enterprise rewrite with 180 techniques, 66 modules, 4 native libraries, SDK, Wear OS + Automotive")
                    ChangelogItem("1.5.0", "Added vault (AES-256-GCM), cloud sync (6 providers), AI categorizer, semantic search")
                    ChangelogItem("1.0.0", "Initial release with scan, cache, search, thumbnails, viewer")
                }
            }

            // ═══════════════════════════════════════════════════════
            // PRIVACY & SECURITY
            // ═══════════════════════════════════════════════════════
            TitanCard.Elevated(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(SpacingTokens.ContentPadding)) {
                    AboutSectionHeader("Privacy & Security", Icons.Filled.Security)
                    AboutActionRow(Icons.Filled.PrivacyTip, "Privacy Policy", "No telemetry, no tracking", onViewPrivacy)
                    AboutActionRow(Icons.Filled.Description, "Terms of Service", "MIT License", onViewTerms)
                    AboutActionRow(Icons.Filled.Security, "Security", "AES-256-GCM vault, zero-knowledge", onViewPrivacy)
                }
            }

            // ═══════════════════════════════════════════════════════
            // OPEN SOURCE
            // ═══════════════════════════════════════════════════════
            TitanCard.Elevated(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(SpacingTokens.ContentPadding)) {
                    AboutSectionHeader("Open Source", Icons.Filled.Code)
                    AboutActionRow(Icons.Filled.Code, "Source Code", "GitHub", onViewSource)
                    AboutActionRow(Icons.Filled.Description, "Open Source Licenses", "Third-party libraries", onViewLicenses)
                }
            }

            // ═══════════════════════════════════════════════════════
            // FEEDBACK
            // ═══════════════════════════════════════════════════════
            TitanCard.Elevated(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(SpacingTokens.ContentPadding)) {
                    AboutSectionHeader("Feedback", Icons.Filled.Star)
                    AboutActionRow(Icons.Filled.Star, "Rate App", "Support the project", onRateApp)
                    AboutActionRow(Icons.Filled.BugReport, "Report Bug", "Help us improve", onReportBug)
                }
            }

            Spacer(Modifier.height(SpacingTokens.Lg))

            // Copyright
            Text(
                "© 2026 TitanFileManager\nMade with ❤️ for power users",
                style = MaterialTheme.typography.bodySmall,
                fontFamily = FontFamily.Monospace,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(SpacingTokens.Md),
            )
        }
    }
}

@Composable
private fun AboutSectionHeader(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
        Spacer(Modifier.size(SpacingTokens.Sm))
        Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun ChangelogItem(version: String, text: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = SpacingTokens.Xs),
        verticalAlignment = Alignment.Top,
    ) {
        Text(
            "v$version",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(end = SpacingTokens.Sm),
        )
        Text(
            text,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun AboutActionRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = SpacingTokens.Xs)
            .bounceClickLocal(onClick),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
        Spacer(Modifier.size(SpacingTokens.Md))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(Icons.AutoMirrored.Filled.OpenInNew, null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
    }
}

// Local helper to avoid import issues
@Composable
private fun Modifier.bounceClickLocal(onClick: () -> Unit): Modifier =
    this.bounceClick(onClick = onClick)

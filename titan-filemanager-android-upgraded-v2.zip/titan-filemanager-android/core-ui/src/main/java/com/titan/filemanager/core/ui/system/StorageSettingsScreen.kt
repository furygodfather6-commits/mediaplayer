package com.titan.filemanager.core.ui.system

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.titan.filemanager.core.datastore.system.StorageRefreshInterval
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import com.titan.filemanager.core.ui.appearance.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StorageSettingsScreen(onBack: () -> Unit, viewModel: AdvancedSystemViewModel = hiltViewModel()) {
    val s by viewModel.settings.collectAsStateWithLifecycle()
    val st = s.storage
    Scaffold(topBar = { TopAppBar(title = { Text("Storage & Disk", fontWeight = FontWeight.SemiBold) },
        navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())) {
            SettingsToggle("Show available storage on home", "Display free space on home screen", st.showAvailableStorageOnHome) { b -> viewModel.updateStorage { it.copy(showAvailableStorageOnHome = b) } }
            SettingsHorizontalDivider()
            SettingsIntSlider("Low storage warning threshold", st.lowStorageWarningThreshold, 5..20, "${st.lowStorageWarningThreshold}%") { v -> viewModel.updateStorage { it.copy(lowStorageWarningThreshold = v) } }
            SettingsIntSlider("Cache size limit", st.cacheSizeLimitMb, 100..2000, "${st.cacheSizeLimitMb}MB") { v -> viewModel.updateStorage { it.copy(cacheSizeLimitMb = v) } }
            SettingsToggle("Auto-clear cache when low", "Automatically clear cache when storage is low", st.autoClearCacheWhenLow) { b -> viewModel.updateStorage { it.copy(autoClearCacheWhenLow = b) } }
            SettingsHorizontalDivider()
            SettingsRadioGroup("Storage refresh interval", StorageRefreshInterval.entries.map { it.label to it }, st.storageRefreshInterval) { v -> viewModel.updateStorage { it.copy(storageRefreshInterval = v) } }
            SettingsToggle("Show storage in status bar", "Persistent storage indicator in status bar", st.showStorageInStatusBar) { b -> viewModel.updateStorage { it.copy(showStorageInStatusBar = b) } }
            Spacer(Modifier.height(SpacingTokens.Xxl))
        }
    }
}

package com.titan.filemanager.core.ui.engine

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import com.titan.filemanager.core.ui.appearance.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiEngineScreen(onBack: () -> Unit, viewModel: AdvancedEngineViewModel = hiltViewModel()) {
    val s by viewModel.settings.collectAsStateWithLifecycle()
    val ai = s.ai
    Scaffold(topBar = { TopAppBar(title = { Text("AI & Smart Features", fontWeight = FontWeight.SemiBold) },
        navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())) {
            SettingsToggle("Enable AI suggestions", "Smart file organization and categorization", ai.enableAiSuggestions) { v -> viewModel.updateAi { it.copy(enableAiSuggestions = v) } }
            if (ai.enableAiSuggestions) {
                SettingsToggle("Smart categorization", "Auto-categorize files by type and content", ai.smartCategorization) { v -> viewModel.updateAi { it.copy(smartCategorization = v) } }
                SettingsToggle("Semantic search", "Natural language file search (experimental)", ai.semanticSearch) { v -> viewModel.updateAi { it.copy(semanticSearch = v) } }
                SettingsToggle("Auto-tag suggestions", "Suggest tags based on file analysis", ai.autoTagSuggestions) { v -> viewModel.updateAi { it.copy(autoTagSuggestions = v) } }
                SettingsToggle("Organization suggestions", "Suggest folder structures", ai.organizationSuggestions) { v -> viewModel.updateAi { it.copy(organizationSuggestions = v) } }
                SettingsToggle("Next folder prediction", "Predict likely next folder to navigate", ai.nextFolderPrediction) { v -> viewModel.updateAi { it.copy(nextFolderPrediction = v) } }
                SettingsHorizontalDivider()
                SettingsIntSlider("Large File Threshold", ai.largeFileThresholdMb, 10..500, "${ai.largeFileThresholdMb} MB") { v -> viewModel.updateAi { it.copy(largeFileThresholdMb = v) } }
                SettingsIntSlider("Recent File Threshold", ai.recentFileThresholdDays, 1..30, "${ai.recentFileThresholdDays} days") { v -> viewModel.updateAi { it.copy(recentFileThresholdDays = v) } }
            }
            Spacer(Modifier.height(SpacingTokens.Xxl))
        }
    }
}

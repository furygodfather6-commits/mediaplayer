package com.titan.filemanager.core.ui.system

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.titan.filemanager.core.datastore.system.ClipboardFormat
import com.titan.filemanager.core.datastore.system.DefaultOpenWith
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import com.titan.filemanager.core.ui.appearance.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BehaviorSettingsScreen(onBack: () -> Unit, viewModel: AdvancedSystemViewModel = hiltViewModel()) {
    val s by viewModel.settings.collectAsStateWithLifecycle()
    val b = s.behavior
    Scaffold(topBar = { TopAppBar(title = { Text("Behavior & Defaults", fontWeight = FontWeight.SemiBold) },
        navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())) {
            SettingsToggle("Confirm before delete", "Show dialog when moving to trash", b.confirmBeforeDelete) { v -> viewModel.updateBehavior { it.copy(confirmBeforeDelete = v) } }
            SettingsToggle("Confirm before overwrite", "Show dialog before overwriting files", b.confirmBeforeOverwrite) { v -> viewModel.updateBehavior { it.copy(confirmBeforeOverwrite = v) } }
            SettingsToggle("Confirm before move", "Show dialog before moving files", b.confirmBeforeMove) { v -> viewModel.updateBehavior { it.copy(confirmBeforeMove = v) } }
            SettingsHorizontalDivider()
            SettingsRadioGroup("Default open with", DefaultOpenWith.entries.map { it.label to it }, b.defaultOpenWith) { v -> viewModel.updateBehavior { it.copy(defaultOpenWith = v) } }
            SettingsRadioGroup("Clipboard format", ClipboardFormat.entries.map { it.label to it }, b.clipboardFormat) { v -> viewModel.updateBehavior { it.copy(clipboardFormat = v) } }
            SettingsHorizontalDivider()
            SettingsToggle("Show file properties on long press", "Display properties sheet on long-press", b.showFilePropertiesOnLongPress) { v -> viewModel.updateBehavior { it.copy(showFilePropertiesOnLongPress = v) } }
            SettingsToggle("Haptic feedback", "Vibrate on interactions", b.hapticFeedback) { v -> viewModel.updateBehavior { it.copy(hapticFeedback = v) } }
            SettingsToggle("Keep screen on during transfers", "Prevent screen sleep during file transfers", b.keepScreenOnDuringTransfers) { v -> viewModel.updateBehavior { it.copy(keepScreenOnDuringTransfers = v) } }
            Spacer(Modifier.height(SpacingTokens.Xxl))
        }
    }
}

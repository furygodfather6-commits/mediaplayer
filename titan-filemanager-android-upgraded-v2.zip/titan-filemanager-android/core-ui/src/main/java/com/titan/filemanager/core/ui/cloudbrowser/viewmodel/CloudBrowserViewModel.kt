package com.titan.filemanager.core.ui.cloudbrowser.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.titan.filemanager.core.ui.cloud.CloudFile
import com.titan.filemanager.core.ui.contracts.CloudBrowserContract
import com.titan.filemanager.core.ui.contracts.CloudTransferCallback
import com.titan.filemanager.core.ui.contracts.UiCloudFile
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * CloudBrowserViewModel — manages cloud-storage file browsing via [CloudBrowserContract].
 *
 * Supports:
 *  - Listing files in a cloud directory (reactive observation)
 *  - Downloading files with progress tracking
 *  - Uploading files with progress tracking
 *  - Breadcrumb navigation
 */
@HiltViewModel
class CloudBrowserViewModel @Inject constructor(
    private val cloudContract: CloudBrowserContract,
) : ViewModel() {

    private val _state = MutableStateFlow(CloudBrowserUiState())
    val state: StateFlow<CloudBrowserUiState> = _state.asStateFlow()

    /**
     * Load files from a cloud provider at the given path.
     * @param providerId Cloud provider ID (e.g., "google_drive", "dropbox").
     * @param path Remote path to list (e.g., "/" for root).
     */
    fun loadFiles(providerId: String, path: String) {
        viewModelScope.launch {
            _state.update {
                it.copy(isLoading = true, providerId = providerId, currentPath = path, error = null)
            }
            try {
                val files = cloudContract.listFiles(providerId, path)
                _state.update {
                    it.copy(
                        files = files.map { f -> f.toCloudFile() },
                        isLoading = false,
                        breadcrumbs = buildBreadcrumbs(path),
                    )
                }
            } catch (e: Exception) {
                _state.update { it.copy(isLoading = false, error = e.message ?: "Failed to load files") }
            }
        }
    }

    /**
     * Refresh the current directory.
     */
    fun refresh() {
        val s = _state.value
        if (s.providerId.isNotEmpty()) {
            loadFiles(s.providerId, s.currentPath)
        }
    }

    /**
     * Navigate to a subdirectory.
     */
    fun navigateTo(path: String) {
        val s = _state.value
        if (s.providerId.isNotEmpty()) {
            loadFiles(s.providerId, path)
        }
    }

    /**
     * Download a file from the cloud with progress tracking.
     */
    fun downloadFile(file: CloudFile) {
        viewModelScope.launch {
            _state.update {
                it.copy(downloadingFile = file.name, downloadProgress = 0f, error = null)
            }
            try {
                val uiFile = file.toUiCloudFile()
                cloudContract.downloadFile(_state.value.providerId, uiFile, object : CloudTransferCallback {
                    override fun onProgress(bytesTransferred: Long, totalBytes: Long) {
                        val progress = if (totalBytes > 0) bytesTransferred.toFloat() / totalBytes else 0f
                        _state.update { it.copy(downloadProgress = progress) }
                    }

                    override fun onComplete(success: Boolean, error: String?) {
                        _state.update {
                            it.copy(
                                downloadingFile = null,
                                downloadProgress = 0f,
                                error = if (success) null else (error ?: "Download failed"),
                            )
                        }
                    }
                })
            } catch (e: Exception) {
                _state.update {
                    it.copy(
                        downloadingFile = null,
                        downloadProgress = 0f,
                        error = e.message ?: "Download failed",
                    )
                }
            }
        }
    }

    /**
     * Upload a local file to the current cloud directory with progress tracking.
     */
    fun uploadFile(filePath: String) {
        viewModelScope.launch {
            val fileName = filePath.substringAfterLast("/")
            _state.update {
                it.copy(uploadingFile = fileName, uploadProgress = 0f, error = null)
            }
            try {
                val remotePath = "${_state.value.currentPath}/$fileName"
                cloudContract.uploadFile(
                    _state.value.providerId,
                    filePath,
                    remotePath,
                    object : CloudTransferCallback {
                        override fun onProgress(bytesTransferred: Long, totalBytes: Long) {
                            val progress = if (totalBytes > 0) bytesTransferred.toFloat() / totalBytes else 0f
                            _state.update { it.copy(uploadProgress = progress) }
                        }

                        override fun onComplete(success: Boolean, error: String?) {
                            _state.update {
                                it.copy(
                                    uploadingFile = null,
                                    uploadProgress = 0f,
                                    error = if (success) null else (error ?: "Upload failed"),
                                )
                            }
                            if (success) refresh()
                        }
                    },
                )
            } catch (e: Exception) {
                _state.update {
                    it.copy(
                        uploadingFile = null,
                        uploadProgress = 0f,
                        error = e.message ?: "Upload failed",
                    )
                }
            }
        }
    }

    /**
     * Build breadcrumb trail from a path string.
     * Returns a list of (displayName, path) pairs.
     */
    private fun buildBreadcrumbs(path: String): List<Pair<String, String>> {
        val segments = path.split("/").filter { it.isNotEmpty() }
        val result = mutableListOf<Pair<String, String>>()
        var current = ""
        segments.forEach { seg ->
            current = "$current/$seg"
            result.add(seg to current)
        }
        return if (result.isEmpty()) listOf("Root" to "/") else result
    }

    /**
     * Convert [UiCloudFile] (contract layer) to [CloudFile] (UI layer).
     */
    private fun UiCloudFile.toCloudFile(): CloudFile {
        return CloudFile(
            name = name,
            path = path,
            size = size,
            modifiedAt = modifiedAt,
            isDirectory = isDirectory,
            mimeType = mimeType,
        )
    }

    /**
     * Convert [CloudFile] (UI layer) to [UiCloudFile] (contract layer).
     */
    private fun CloudFile.toUiCloudFile(): UiCloudFile {
        return UiCloudFile(
            name = name,
            path = path,
            size = size,
            modifiedAt = modifiedAt,
            isDirectory = isDirectory,
            mimeType = mimeType,
        )
    }
}

data class CloudBrowserUiState(
    val providerId: String = "",
    val currentPath: String = "/",
    val files: List<CloudFile> = emptyList(),
    val breadcrumbs: List<Pair<String, String>> = listOf("Root" to "/"),
    val isLoading: Boolean = false,
    val error: String? = null,
    val downloadingFile: String? = null,
    val downloadProgress: Float = 0f,
    val uploadingFile: String? = null,
    val uploadProgress: Float = 0f,
)

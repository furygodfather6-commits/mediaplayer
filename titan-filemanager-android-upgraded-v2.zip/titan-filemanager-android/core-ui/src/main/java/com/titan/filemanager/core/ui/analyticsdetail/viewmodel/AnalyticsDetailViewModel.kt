package com.titan.filemanager.core.ui.analyticsdetail.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.titan.filemanager.core.ui.analyticsdetail.AgeBucket
import com.titan.filemanager.core.ui.analyticsdetail.BigFile
import com.titan.filemanager.core.ui.analyticsdetail.FileTypeStat
import com.titan.filemanager.core.ui.analyticsdetail.SizeBucket
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.ui.graphics.Color
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.InsertDriveFile
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.inject.Inject

@HiltViewModel
class AnalyticsDetailViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
) : ViewModel() {

    private val _state = MutableStateFlow(AnalyticsDetailUiState())
    val state: StateFlow<AnalyticsDetailUiState> = _state.asStateFlow()

    init { loadAnalytics() }

    fun loadAnalytics(rootPath: String = "/storage/emulated/0") {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            try {
                val (typeStats, sizeBuckets, ageBuckets, biggest, oldest) = withContext(Dispatchers.IO) {
                    scanFilesystem(rootPath)
                }
                _state.update {
                    it.copy(
                        typeStats = typeStats,
                        sizeBuckets = sizeBuckets,
                        ageBuckets = ageBuckets,
                        biggestFiles = biggest,
                        oldestFiles = oldest,
                        isLoading = false,
                    )
                }
            } catch (e: Exception) {
                _state.update { it.copy(isLoading = false, error = e.message) }
            }
        }
    }

    private fun scanFilesystem(rootPath: String): Quintet<List<FileTypeStat>, List<SizeBucket>, List<AgeBucket>, List<BigFile>, List<BigFile>> {
        val root = File(rootPath)
        val imageExt = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic")
        val videoExt = setOf("mp4", "mkv", "avi", "mov", "wmv", "flv", "webm")
        val audioExt = setOf("mp3", "flac", "aac", "ogg", "wav", "m4a")
        val docExt = setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "md")
        val archiveExt = setOf("zip", "rar", "7z", "tar", "gz", "bz2", "xz", "apk")

        var imgCount = 0; var imgSize = 0L
        var vidCount = 0; var vidSize = 0L
        var audCount = 0; var audSize = 0L
        var docCount = 0; var docSize = 0L
        var arcCount = 0; var arcSize = 0L
        var otherCount = 0; var otherSize = 0L

        // Size buckets
        var s1 = 0; var s2 = 0; var s3 = 0; var s4 = 0; var s5 = 0; var s6 = 0

        // Age buckets
        val now = System.currentTimeMillis()
        val day = 86_400_000L
        var a1 = 0; var a2 = 0; var a3 = 0; var a4 = 0; var a5 = 0; var a6 = 0

        val allFiles = mutableListOf<Pair<File, Long>>()

        root.walkTopDown().take(50000).forEach { file ->
            if (!file.isFile) return@forEach
            val ext = file.extension.lowercase()
            val size = file.length()
            val mtime = file.lastModified()

            allFiles.add(file to mtime)

            when {
                ext in imageExt -> { imgCount++; imgSize += size }
                ext in videoExt -> { vidCount++; vidSize += size }
                ext in audioExt -> { audCount++; audSize += size }
                ext in docExt -> { docCount++; docSize += size }
                ext in archiveExt -> { arcCount++; arcSize += size }
                else -> { otherCount++; otherSize += size }
            }

            // Size distribution
            when {
                size < 1024 -> s1++
                size < 1024 * 1024 -> s2++
                size < 10 * 1024 * 1024 -> s3++
                size < 100 * 1024 * 1024 -> s4++
                size < 1024L * 1024 * 1024 -> s5++
                else -> s6++
            }

            // Age distribution
            val ageDays = (now - mtime) / day
            when {
                ageDays < 7 -> a1++
                ageDays < 30 -> a2++
                ageDays < 90 -> a3++
                ageDays < 180 -> a4++
                ageDays < 365 -> a5++
                else -> a6++
            }
        }

        val typeStats = listOf(
            FileTypeStat("Images", imgCount, imgSize, Color(0xFF7C4DFF)),
            FileTypeStat("Videos", vidCount, vidSize, Color(0xFFE91E63)),
            FileTypeStat("Audio", audCount, audSize, Color(0xFFFF9800)),
            FileTypeStat("Documents", docCount, docSize, Color(0xFF2196F3)),
            FileTypeStat("Archives", arcCount, arcSize, Color(0xFF795548)),
            FileTypeStat("Other", otherCount, otherSize, Color(0xFF9E9E9E)),
        )

        val sizeBuckets = listOf(
            SizeBucket("< 1 KB", s1, Color(0xFF81C784)),
            SizeBucket("1 KB–1 MB", s2, Color(0xFF66BB6A)),
            SizeBucket("1–10 MB", s3, Color(0xFFFFB74D)),
            SizeBucket("10–100 MB", s4, Color(0xFFFF8A65)),
            SizeBucket("100 MB–1 GB", s5, Color(0xFFE57373)),
            SizeBucket("> 1 GB", s6, Color(0xFFEF5350)),
        )

        val ageBuckets = listOf(
            AgeBucket("< 7d", a1, Color(0xFF4CAF50)),
            AgeBucket("7-30d", a2, Color(0xFF8BC34A)),
            AgeBucket("1-3m", a3, Color(0xFFFFC107)),
            AgeBucket("3-6m", a4, Color(0xFFFF9800)),
            AgeBucket("6-12m", a5, Color(0xFFE64A19)),
            AgeBucket("> 1y", a6, Color(0xFF795548)),
        )

        val biggest = allFiles
            .sortedByDescending { it.first.length() }
            .take(20)
            .map { (file, _) ->
                BigFile(file.name, file.absolutePath, file.length(), file.lastModified())
            }

        val oldest = allFiles
            .filter { it.first.lastModified() > 0 }
            .sortedBy { it.first.lastModified() }
            .take(20)
            .map { (file, _) ->
                BigFile(file.name, file.absolutePath, file.length(), file.lastModified())
            }

        return Quintet(typeStats, sizeBuckets, ageBuckets, biggest, oldest)
    }

    private data class Quintet<A, B, C, D, E>(
        val a: A, val b: B, val c: C, val d: D, val e: E,
    )
}

data class AnalyticsDetailUiState(
    val typeStats: List<FileTypeStat> = emptyList(),
    val sizeBuckets: List<SizeBucket> = emptyList(),
    val ageBuckets: List<AgeBucket> = emptyList(),
    val biggestFiles: List<BigFile> = emptyList(),
    val oldestFiles: List<BigFile> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null,
)

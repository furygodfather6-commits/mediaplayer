package com.titan.filemanager.core.ui.extract

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Unarchive
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import com.titan.filemanager.core.designsystem.tokens.ShapeTokens
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens

enum class OverwriteMode(val label: String, val description: String) {
    OVERWRITE("Overwrite", "Replace existing files with same name"),
    SKIP("Skip", "Keep existing files, skip conflicting ones"),
    MERGE("Merge", "Merge folders, prompt for file conflicts"),
    RENAME("Rename", "Auto-rename extracted files if conflict"),
}

data class ExtractOptions(
    val destinationPath: String,
    val password: String?,
    val overwriteMode: OverwriteMode,
    val extractSelected: Boolean,
    val selectedEntries: List<String>,
    val preserveFolderStructure: Boolean,
)

/**
 * Extract Options Dialog — full-featured archive extraction config.
 *
 * Options:
 *  - Destination directory picker (text input + browse button)
 *  - Password input (if archive is encrypted)
 *  - Overwrite mode (Overwrite / Skip / Merge / Rename)
 *  - Selective extraction toggle (extract only specific entries)
 *  - Preserve folder structure toggle
 *
 * Usage:
 * ```
 * var showExtractDialog by remember { mutableStateOf(false) }
 * if (showExtractDialog) {
 *     ExtractOptionsDialog(
 *         archiveName = "backup.zip",
 *         entryCount = 142,
 *         isEncrypted = true,
 *         onConfirm = { options -> viewModel.extract(options); showExtractDialog = false },
 *         onDismiss = { showExtractDialog = false },
 *     )
 * }
 * ```
 */
@Composable
fun ExtractOptionsDialog(
    archiveName: String,
    entryCount: Int,
    isEncrypted: Boolean,
    onConfirm: (ExtractOptions) -> Unit,
    onDismiss: () -> Unit,
    defaultDestination: String = "/storage/emulated/0/Download",
    onBrowseDestination: (() -> Unit)? = null,
) {
    var destination by remember { mutableStateOf(defaultDestination) }
    var password by remember { mutableStateOf("") }
    var selectedOverwrite by remember { mutableStateOf(OverwriteMode.RENAME) }
    var selectiveExtract by remember { mutableStateOf(false) }
    var preserveStructure by remember { mutableStateOf(true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Unarchive, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.size(SpacingTokens.Sm))
                Text("Extract Archive", fontWeight = FontWeight.SemiBold)
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(SpacingTokens.Sm),
            ) {
                // Archive info
                Text(
                    "$archiveName • $entryCount entries",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )

                // Destination
                Text("Destination", style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Medium)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = destination,
                        onValueChange = { destination = it },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        leadingIcon = { Icon(Icons.Filled.FolderOpen, null, modifier = Modifier.size(20.dp)) },
                    )
                    if (onBrowseDestination != null) {
                        Spacer(Modifier.size(SpacingTokens.Xs))
                        TextButton(onClick = onBrowseDestination) {
                            Icon(Icons.Filled.CreateNewFolder, null, modifier = Modifier.size(20.dp))
                        }
                    }
                }

                // Password (if encrypted)
                if (isEncrypted) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Lock, null, modifier = Modifier.size(18.dp),
                            tint = MaterialTheme.colorScheme.error)
                        Spacer(Modifier.size(SpacingTokens.Xs))
                        Text("Password required", style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Medium)
                    }
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("Password") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }

                // Overwrite mode
                Text("If file exists", style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Medium)
                OverwriteMode.entries.forEach { mode ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(
                            selected = selectedOverwrite == mode,
                            onClick = { selectedOverwrite = mode },
                        )
                        Spacer(Modifier.size(SpacingTokens.Xs))
                        Column {
                            Text(mode.label, style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Medium)
                            Text(mode.description, style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }

                // Selective extraction
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Switch(
                        checked = selectiveExtract,
                        onCheckedChange = { selectiveExtract = it },
                    )
                    Spacer(Modifier.size(SpacingTokens.Xs))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Select files to extract", style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium)
                        Text("Choose specific entries instead of extracting all",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                // Preserve structure
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Switch(
                        checked = preserveStructure,
                        onCheckedChange = { preserveStructure = it },
                    )
                    Spacer(Modifier.size(SpacingTokens.Xs))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Preserve folder structure", style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium)
                        Text("Maintain original directory hierarchy",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirm(
                        ExtractOptions(
                            destinationPath = destination,
                            password = if (isEncrypted) password.ifBlank { null } else null,
                            overwriteMode = selectedOverwrite,
                            extractSelected = selectiveExtract,
                            selectedEntries = emptyList(),
                            preserveFolderStructure = preserveStructure,
                        ),
                    )
                },
                enabled = !isEncrypted || password.isNotBlank(),
                shape = ShapeTokens.Full,
            ) {
                Icon(Icons.Filled.Unarchive, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.size(SpacingTokens.Xs))
                Text("Extract")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
    )
}

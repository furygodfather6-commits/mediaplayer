package com.titan.filemanager.core.ui.engine

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.titan.filemanager.core.designsystem.tokens.ShapeTokens
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EngineSettingsScreen(
    onBack: () -> Unit,
    onNavigateToScan: () -> Unit,
    onNavigateToCache: () -> Unit,
    onNavigateToSearch: () -> Unit,
    onNavigateToThumbnail: () -> Unit,
    onNavigateToTrash: () -> Unit,
    onNavigateToAnalytics: () -> Unit,
    onNavigateToAi: () -> Unit,
    viewModel: AdvancedEngineViewModel = hiltViewModel(),
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Engine Configuration", fontWeight = FontWeight.SemiBold) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                actions = { IconButton(onClick = { viewModel.resetAll() }) { Icon(Icons.Filled.Restore, "Reset") } },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(SpacingTokens.Md),
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.Sm),
        ) {
            Text("Configure scan, cache, search, thumbnail, trash, analytics, and AI engines",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = SpacingTokens.Lg, vertical = SpacingTokens.Xs))
            Spacer(Modifier.height(SpacingTokens.Sm))

            EngineCategoryCard(Icons.Filled.Radar, "Scan Engine", "Threads, batch size, watchers, native engine", "${settings.scan.parallelThreads} threads", onNavigateToScan)
            EngineCategoryCard(Icons.Filled.Storage, "Cache Engine", "L0-L3 tiers, RAM limits, auto-clear", "${settings.cache.l1RamCacheMb}MB RAM", onNavigateToCache)
            EngineCategoryCard(Icons.Filled.Search, "Search Engine", "Debounce, max results, fuzzy, regex, ranker", "${settings.search.maxSearchResults} max", onNavigateToSearch)
            EngineCategoryCard(Icons.Filled.Image, "Thumbnail Engine", "Memory/disk cache, format, quality", "${settings.thumbnail.diskCacheMb}MB disk", onNavigateToThumbnail)
            EngineCategoryCard(Icons.Filled.Delete, "Trash & Deletion", "Retention, auto-empty, secure delete", "${settings.trash.retentionDays} days", onNavigateToTrash)
            EngineCategoryCard(Icons.Filled.Insights, "Analytics", "Top files/folders, duplicate detection", settings.analytics.duplicateDetectionLevel.label, onNavigateToAnalytics)
            EngineCategoryCard(Icons.Filled.Psychology, "AI & Smart Features", "Categorization, semantic search, tags", if (settings.ai.enableAiSuggestions) "On" else "Off", onNavigateToAi)

            Spacer(Modifier.height(SpacingTokens.Xl))
            Text("64 configurable settings across 7 engine categories",
                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = SpacingTokens.Lg))
        }
    }
}

@Composable
private fun EngineCategoryCard(icon: ImageVector, title: String, subtitle: String, badge: String, onClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick), shape = ShapeTokens.Medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
        Row(modifier = Modifier.fillMaxWidth().padding(SpacingTokens.Lg), verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(44.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) {
                Icon(icon, null, modifier = Modifier.size(24.dp), tint = MaterialTheme.colorScheme.onPrimaryContainer)
            }
            Spacer(Modifier.width(SpacingTokens.Md))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
            }
            Surface(shape = ShapeTokens.Full, color = MaterialTheme.colorScheme.secondaryContainer) {
                Text(badge, modifier = Modifier.padding(horizontal = SpacingTokens.Sm, vertical = 2.dp),
                    style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSecondaryContainer)
            }
            Spacer(Modifier.width(SpacingTokens.Xs))
            Icon(Icons.AutoMirrored.Filled.ArrowForwardIos, null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

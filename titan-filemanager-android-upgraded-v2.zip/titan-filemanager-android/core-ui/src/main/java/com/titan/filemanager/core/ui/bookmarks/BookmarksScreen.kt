package com.titan.filemanager.core.ui.bookmarks

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.DragHandle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.titan.filemanager.core.designsystem.component.EmptyState
import com.titan.filemanager.core.designsystem.component.TitanInfoBadge
import com.titan.filemanager.core.designsystem.icon.FileTypeIcon
import com.titan.filemanager.core.designsystem.modifier.bounceClick
import com.titan.filemanager.core.designsystem.modifier.slideOnAppear
import com.titan.filemanager.core.designsystem.tokens.ColorTokens
import com.titan.filemanager.core.designsystem.tokens.ElevationTokens
import com.titan.filemanager.core.designsystem.tokens.ShapeTokens
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens

data class BookmarkItem(
    val id: Long,
    val name: String,
    val path: String,
    val isFolder: Boolean = true,
    val sortOrder: Int = 0,
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookmarksScreen(
    bookmarks: List<BookmarkItem>,
    onBack: () -> Unit,
    onNavigate: (String) -> Unit,
    onAddBookmark: (String) -> Unit,
    onRemoveBookmark: (Long) -> Unit,
    onRenameBookmark: (Long, String) -> Unit,
    modifier: Modifier = Modifier,
) {
    var showAddDialog by remember { mutableStateOf(false) }
    var editingBookmark by remember { mutableStateOf<BookmarkItem?>(null) }

    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = { Text("Bookmarks", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface),
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
            ) {
                Icon(Icons.Filled.Bookmark, "Add bookmark")
            }
        },
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            if (bookmarks.isEmpty()) {
                EmptyState(
                    icon = Icons.Filled.BookmarkBorder,
                    title = "No bookmarks yet",
                    subtitle = "Bookmark frequently accessed folders\nto quickly jump to them",
                )
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(SpacingTokens.Md),
                    verticalArrangement = Arrangement.spacedBy(SpacingTokens.Xs),
                ) {
                    items(bookmarks.size, key = { bookmarks[it].id }) { index ->
                        val bookmark = bookmarks[index]
                        BookmarkCard(
                            bookmark = bookmark,
                            onClick = { onNavigate(bookmark.path) },
                            onRename = { editingBookmark = bookmark },
                            onRemove = { onRemoveBookmark(bookmark.id) },
                            modifier = Modifier.slideOnAppear(index = index.coerceAtMost(15)),
                        )
                    }
                }
            }
        }
    }

    // Add bookmark dialog
    if (showAddDialog) {
        var path by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Add Bookmark") },
            text = {
                OutlinedTextField(
                    value = path,
                    onValueChange = { path = it },
                    label = { Text("Folder path") },
                    placeholder = { Text("/storage/emulated/0/Documents") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            },
            confirmButton = {
                TextButton(
                    onClick = { if (path.isNotBlank()) { onAddBookmark(path); showAddDialog = false } },
                    enabled = path.isNotBlank(),
                ) { Text("Add") }
            },
            dismissButton = { TextButton(onClick = { showAddDialog = false }) { Text("Cancel") } },
        )
    }

    // Rename dialog
    editingBookmark?.let { bookmark ->
        var newName by remember { mutableStateOf(bookmark.name) }
        AlertDialog(
            onDismissRequest = { editingBookmark = null },
            title = { Text("Rename Bookmark") },
            text = {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    label = { Text("Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    onRenameBookmark(bookmark.id, newName)
                    editingBookmark = null
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { editingBookmark = null }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun BookmarkCard(
    bookmark: BookmarkItem,
    onClick: () -> Unit,
    onRename: () -> Unit,
    onRemove: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val icon = if (bookmark.isFolder) FileTypeIcon.Folder
    else FileTypeIcon.fromPath(bookmark.path)

    Card(
        modifier = modifier
            .fillMaxWidth()
            .bounceClick(onClick = onClick),
        shape = ShapeTokens.Medium,
        elevation = CardDefaults.cardElevation(defaultElevation = ElevationTokens.Level1),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(SpacingTokens.ContentPadding),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            // Drag handle (visual only — drag-to-reorder requires ReorderableList)
            Icon(
                Icons.Filled.DragHandle,
                "Reorder",
                tint = MaterialTheme.colorScheme.outline,
                modifier = Modifier.size(20.dp),
            )
            Spacer(Modifier.size(SpacingTokens.Md))

            // Bookmark star icon
            Icon(
                Icons.Filled.Star,
                null,
                tint = ColorTokens.FileFolder,
                modifier = Modifier.size(20.dp),
            )
            Spacer(Modifier.size(SpacingTokens.Sm))

            // Folder/file icon
            Icon(icon.imageVector, null, modifier = Modifier.size(32.dp), tint = icon.color)

            Spacer(Modifier.size(SpacingTokens.Md))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    bookmark.name,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    bookmark.path,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }

            // Actions
            IconButton(onClick = onRename) {
                Icon(Icons.Filled.Edit, "Rename", modifier = Modifier.size(20.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = onRemove) {
                Icon(Icons.Filled.BookmarkBorder, "Remove",
                    modifier = Modifier.size(20.dp),
                    tint = MaterialTheme.colorScheme.error)
            }
        }
    }
}

// Local EmptyState alias to avoid import conflict
@Composable
private fun EmptyState(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
) = com.titan.filemanager.core.designsystem.component.TitanEmptyState(
    icon = icon, title = title, subtitle = subtitle,
)

package com.titan.filemanager.core.ui.backup

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.titan.filemanager.core.datastore.backup.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AdvancedBackupViewModel @Inject constructor(
    private val repo: BackupSettingsRepository,
) : ViewModel() {

    val settings: StateFlow<BackupSettings> = repo.settings.stateIn(
        scope = viewModelScope, started = SharingStarted.WhileSubscribed(5000L),
        initialValue = BackupSettings(),
    )

    fun updateBackup(block: (BackupConfigSettings) -> BackupConfigSettings) = viewModelScope.launch { repo.updateBackup(block) }
    fun updateArchive(block: (ArchiveConfigSettings) -> ArchiveConfigSettings) = viewModelScope.launch { repo.updateArchive(block) }
    fun resetAll() = viewModelScope.launch { repo.resetAll() }
}

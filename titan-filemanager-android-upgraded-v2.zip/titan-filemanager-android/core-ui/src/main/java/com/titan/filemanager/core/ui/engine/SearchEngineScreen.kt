package com.titan.filemanager.core.ui.engine

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import com.titan.filemanager.core.ui.appearance.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchEngineScreen(onBack: () -> Unit, viewModel: AdvancedEngineViewModel = hiltViewModel()) {
    val s by viewModel.settings.collectAsStateWithLifecycle()
    val se = s.search
    Scaffold(topBar = { TopAppBar(title = { Text("Search Engine", fontWeight = FontWeight.SemiBold) },
        navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())) {
            SettingsIntSlider("Search Debounce", se.searchDebounceMs, 100..1000, "${se.searchDebounceMs}ms") { v -> viewModel.updateSearch { it.copy(searchDebounceMs = v) } }
            SettingsIntSlider("Max Search Results", se.maxSearchResults, 100..50000, se.maxSearchResults.toString()) { v -> viewModel.updateSearch { it.copy(maxSearchResults = v) } }
            SettingsIntSlider("Search History Size", se.searchHistorySize, 0..200, se.searchHistorySize.toString()) { v -> viewModel.updateSearch { it.copy(searchHistorySize = v) } }
            SettingsHorizontalDivider()
            SettingsToggle("Fuzzy search", "Approximate matching with edit distance", se.fuzzySearch) { v -> viewModel.updateSearch { it.copy(fuzzySearch = v) } }
            SettingsToggle("Content search", "Search inside file contents (slower)", se.contentSearch) { v -> viewModel.updateSearch { it.copy(contentSearch = v) } }
            SettingsToggle("Regex search", "Enable regular expression queries", se.regexSearch) { v -> viewModel.updateSearch { it.copy(regexSearch = v) } }
            SettingsToggle("Case-sensitive", "Distinguish uppercase/lowercase", se.caseSensitive) { v -> viewModel.updateSearch { it.copy(caseSensitive = v) } }
            SettingsHorizontalDivider()
            SettingsSection("Bloom Filter") {
                SettingsIntSlider("Expected Items", se.bloomExpectedItems, 100_000..5_000_000, se.bloomExpectedItems.toString()) { v -> viewModel.updateSearch { it.copy(bloomExpectedItems = v) } }
                SettingsSlider("False Positive Rate", se.bloomFalsePositiveRate, 0.001f..0.05f, 48, "${(se.bloomFalsePositiveRate * 100).toFloat()}%") { v -> viewModel.updateSearch { it.copy(bloomFalsePositiveRate = v) } }
            }
            SettingsHorizontalDivider()
            SettingsSection("Ranker Weights") {
                SettingsSlider("Match Weight", se.rankerMatchWeight, 0.0f..1.0f, 9, "${(se.rankerMatchWeight * 100).toInt()}%") { v -> viewModel.updateSearch { it.copy(rankerMatchWeight = v) } }
                SettingsSlider("Relevance Weight", se.rankerRelevanceWeight, 0.0f..1.0f, 9, "${(se.rankerRelevanceWeight * 100).toInt()}%") { v -> viewModel.updateSearch { it.copy(rankerRelevanceWeight = v) } }
            }
            Spacer(Modifier.height(SpacingTokens.Xxl))
        }
    }
}

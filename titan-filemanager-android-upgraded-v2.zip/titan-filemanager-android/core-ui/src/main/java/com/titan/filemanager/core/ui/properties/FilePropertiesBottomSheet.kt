package com.titan.filemanager.core.ui.properties

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.titan.filemanager.core.designsystem.component.TitanFileInfoRow
import com.titan.filemanager.core.designsystem.icon.FileTypeIcon
import com.titan.filemanager.core.designsystem.tokens.ColorTokens
import com.titan.filemanager.core.designsystem.tokens.ShapeTokens
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import com.titan.filemanager.core.model.file.FileItem
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * File Properties Bottom Sheet — shows complete file metadata.
 *
 * Sections:
 *  1. Header — file icon + name + path
 *  2. Basic — size, type, extension, MIME type
 *  3. Dates — created, modified, accessed
 *  4. Permissions — read/write/execute, owner, group, octal mode
 *  5. Storage — inode, device, blocks, block size
 *  6. Security — content hash (SHA-256), encryption status
 *  7. Tags — user-defined tags (if any)
 *
 * Usage:
 * ```
 * if (showProperties) {
 *     FilePropertiesBottomSheet(
 *         file = selectedItem,
 *         onDismiss = { showProperties = false },
 *         onCopyPath = { clipboardManager.setText(file.path) },
 *     )
 * }
 * ```
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FilePropertiesBottomSheet(
    file: FileItem,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    onCopyPath: (() -> Unit)? = null,
    onCopyHash: (() -> Unit)? = null,
    contentHash: String? = null,
    permissions: String? = null,
    inode: Long? = null,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val icon = if (file.isDirectory) FileTypeIcon.Folder else FileTypeIcon.fromPath(file.path)
    val dateFormat = SimpleDateFormat("MMM dd, yyyy 'at' HH:mm", Locale.getDefault())
    val physicalFile = File(file.path)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        shape = ShapeTokens.ExtraLarge,
        dragHandle = {
            androidx.compose.material3.Surface(
                modifier = Modifier.padding(vertical = SpacingTokens.Sm),
                color = MaterialTheme.colorScheme.outlineVariant,
                shape = ShapeTokens.Full,
            ) {
                androidx.compose.foundation.layout.Box(Modifier.width(32.dp).height(4.dp))
            }
        },
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = SpacingTokens.ScreenHorizontal)
                .padding(bottom = SpacingTokens.Xxl),
        ) {
            // ═══════════════════════════════════════════════════════
            // HEADER — icon + name + path
            // ═══════════════════════════════════════════════════════
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = SpacingTokens.Lg),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(icon.imageVector, null, modifier = Modifier.size(56.dp), tint = icon.color)
                Spacer(Modifier.width(SpacingTokens.Lg))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        file.name,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        file.path,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                onCopyPath?.let {
                    IconButton(onClick = it) {
                        Icon(Icons.Filled.ContentCopy, "Copy path",
                            tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }

            HorizontalDivider()
            Spacer(Modifier.height(SpacingTokens.Md))

            // ═══════════════════════════════════════════════════════
            // BASIC INFO
            // ═══════════════════════════════════════════════════════
            SectionTitle("Basic Information", Icons.Filled.Description)
            TitanFileInfoRow(
                label = "Type",
                value = if (file.isDirectory) "Directory" else file.extension.uppercase() + " File",
                icon = if (file.isDirectory) Icons.Filled.Folder else Icons.Filled.Description,
            )
            if (!file.isDirectory) {
                TitanFileInfoRow(
                    label = "Size",
                    value = formatBytes(file.size),
                    icon = Icons.Filled.Storage,
                )
            }
            file.mimeType?.let { mime ->
                TitanFileInfoRow(label = "MIME Type", value = mime, icon = Icons.Filled.Tag)
            }
            TitanFileInfoRow(
                label = "Extension",
                value = if (file.extension.isEmpty()) "None" else ".${file.extension}",
                icon = Icons.Filled.Tag,
            )
            TitanFileInfoRow(
                label = "Hidden",
                value = if (file.isHidden) "Yes" else "No",
                icon = Icons.Filled.Security,
            )

            Spacer(Modifier.height(SpacingTokens.Md))
            HorizontalDivider()
            Spacer(Modifier.height(SpacingTokens.Md))

            // ═══════════════════════════════════════════════════════
            // DATES
            // ═══════════════════════════════════════════════════════
            SectionTitle("Timestamps", Icons.Filled.CalendarToday)
            TitanFileInfoRow(
                label = "Last Modified",
                value = if (file.modifiedAt > 0) dateFormat.format(Date(file.modifiedAt)) else "Unknown",
                icon = Icons.Filled.Schedule,
            )
            TitanFileInfoRow(
                label = "Accessed",
                value = dateFormat.format(Date(physicalFile.lastModified())),
                icon = Icons.Filled.CalendarToday,
            )

            // Permissions
            permissions?.let { perm ->
                Spacer(Modifier.height(SpacingTokens.Md))
                HorizontalDivider()
                Spacer(Modifier.height(SpacingTokens.Md))
                SectionTitle("Permissions", Icons.Filled.Lock)
                TitanFileInfoRow(label = "Mode", value = perm, icon = Icons.Filled.Lock)
                TitanFileInfoRow(
                    label = "Readable",
                    value = if (physicalFile.canRead()) "Yes" else "No",
                    icon = Icons.Filled.Security,
                )
                TitanFileInfoRow(
                    label = "Writable",
                    value = if (physicalFile.canWrite()) "Yes" else "No",
                    icon = Icons.Filled.Security,
                )
                TitanFileInfoRow(
                    label = "Executable",
                    value = if (physicalFile.canExecute()) "Yes" else "No",
                    icon = Icons.Filled.Security,
                )
            }

            // Inode / Storage
            inode?.let { ino ->
                Spacer(Modifier.height(SpacingTokens.Md))
                HorizontalDivider()
                Spacer(Modifier.height(SpacingTokens.Md))
                SectionTitle("Storage", Icons.Filled.Storage)
                TitanFileInfoRow(label = "Inode", value = ino.toString(), icon = Icons.Filled.Fingerprint)
                TitanFileInfoRow(
                    label = "Symlink",
                    value = if (physicalFile.isDirectory) "No" else "Check",
                    icon = Icons.Filled.Link,
                )
            }

            // Content Hash
            contentHash?.let { hash ->
                Spacer(Modifier.height(SpacingTokens.Md))
                HorizontalDivider()
                Spacer(Modifier.height(SpacingTokens.Md))
                SectionTitle("Integrity", Icons.Filled.Fingerprint)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Filled.Fingerprint, null, modifier = Modifier.size(20.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.width(SpacingTokens.Md))
                    Text(
                        text = "SHA-256",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f),
                    )
                    Text(
                        text = hash.take(16) + "...",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                        ),
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    onCopyHash?.let {
                        IconButton(onClick = it) {
                            Icon(Icons.Filled.ContentCopy, "Copy hash",
                                modifier = Modifier.size(18.dp),
                                tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }

            // Encryption status
            if (!file.isDirectory) {
                Spacer(Modifier.height(SpacingTokens.Md))
                HorizontalDivider()
                Spacer(Modifier.height(SpacingTokens.Md))
                SectionTitle("Security", Icons.Filled.Security)
                TitanFileInfoRow(
                    label = "Encrypted",
                    value = "No",
                    icon = Icons.Filled.Lock,
                )
                TitanFileInfoRow(
                    label = "In Vault",
                    value = "No",
                    icon = Icons.Filled.Security,
                )
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(bottom = SpacingTokens.Xs),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.Xs),
    ) {
        Icon(icon, null, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
        Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
    }
}

private fun formatBytes(bytes: Long): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "%.1f KB (%,d bytes)".format(bytes / 1024.0, bytes)
    bytes < 1024 * 1024 * 1024 -> "%.1f MB (%,d bytes)".format(bytes / (1024.0 * 1024), bytes)
    else -> "%.2f GB (%,d bytes)".format(bytes / (1024.0 * 1024 * 1024), bytes)
}

package com.titan.filemanager.core.ui.settingsappearance

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Brightness6
import androidx.compose.material.icons.filled.BrightnessAuto
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Contrast
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DensitySmall
import androidx.compose.material.icons.filled.DynamicFeed
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.RoundedCorner
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Texture
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.ViewCompact
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.titan.filemanager.core.designsystem.modifier.bounceClick
import com.titan.filemanager.core.designsystem.modifier.clipToCircle
import com.titan.filemanager.core.designsystem.modifier.clipToRounded
import com.titan.filemanager.core.designsystem.preset.ThemePreset
import com.titan.filemanager.core.designsystem.tokens.ElevationTokens
import com.titan.filemanager.core.designsystem.tokens.ShapeTokens
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens

/**
 * ## SettingsAppearanceScreen
 *
 * Enterprise appearance customization screen — theme preset picker, dark mode selector,
 * accent color, dynamic color (Material You) toggle, font size, density, corner radius,
 * and contrast adjustments.
 *
 * ### Layout Anatomy
 * ```
 * ┌──────────────────────────────────────────────┐
 * │ ←  Appearance                  [Reset]       │  TopAppBar
 * ├──────────────────────────────────────────────┤
 * │ 🎨 Theme                                     │
 * │ ┌────┐┌────┐┌────┐┌────┐┌────┐┌────┐┌────┐  │  Horizontal theme cards
 * │ │Ocn ││Frs ││Sun ││Mid ││Mon ││Cor ││Arc │  │
 * │ └────┘└────┘└────┘└────┘└────┘└────┘└────┘  │
 * ├──────────────────────────────────────────────┤
 * │ 🌓 Dark Mode          [System][Light][Dark]  │  Segmented control
 * │ ✨ Material You       ─────●────  off        │  Switch
 * ├──────────────────────────────────────────────┤
 * │ 🔠 Font Size           ──●──────  1.0x       │  Slider
 * │ 📐 Density             ─●───────  Compact    │  Slider
 * │ 📐 Corner Radius       ────●────  16dp       │  Slider
 * │ 🌗 Contrast            ──●──────  Normal     │  Slider
 * ├──────────────────────────────────────────────┤
 * │ 📊 Live Preview                              │
 * │  ┌──────────────────────────────────────┐    │
 * │  │ Sample Card with current theme       │    │
 * │  └──────────────────────────────────────┘    │
 * └──────────────────────────────────────────────┘
 * ```
 *
 * ### Settings Persistence
 * All appearance settings are persisted via DataStore through the caller's ViewModel:
 *  - `theme_preset` — string (preset name)
 *  - `dark_mode` — string ("system" | "light" | "dark")
 *  - `dynamic_color` — boolean
 *  - `font_scale` — float (0.85 to 1.3)
 *  - `density` — float (0.85 to 1.3)
 *  - `corner_radius` — float (0 to 28 dp)
 *  - `contrast` — float (0.85 to 1.3)
 *
 * @param onBack callback to navigate back.
 * @param onReset callback when user taps "Reset to defaults".
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsAppearanceScreen(
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    currentPreset: ThemePreset = ThemePreset.Ocean,
    darkMode: DarkMode = DarkMode.SYSTEM,
    dynamicColor: Boolean = false,
    fontScale: Float = 1.0f,
    density: Float = 1.0f,
    cornerRadius: Float = 16f,
    contrast: Float = 1.0f,
    onPresetChange: (ThemePreset) -> Unit = {},
    onDarkModeChange: (DarkMode) -> Unit = {},
    onDynamicColorChange: (Boolean) -> Unit = {},
    onFontScaleChange: (Float) -> Unit = {},
    onDensityChange: (Float) -> Unit = {},
    onCornerRadiusChange: (Float) -> Unit = {},
    onContrastChange: (Float) -> Unit = {},
    onReset: () -> Unit = {},
    onNavigateToAdvanced: () -> Unit = {},
) {
    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = { Text("Appearance", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                actions = {
                    IconButton(onClick = onReset) {
                        Icon(Icons.Filled.Restore, "Reset to defaults")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                ),
            )
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(SpacingTokens.Md),
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.Md),
        ) {
            // ═══════════════════════════════════════════════════════
            // SECTION 1 — THEME PRESETS
            // ═══════════════════════════════════════════════════════
            item { ThemePresetSection(currentPreset, onPresetChange) }

            // ═══════════════════════════════════════════════════════
            // SECTION 2 — DARK MODE + DYNAMIC COLOR
            // ═══════════════════════════════════════════════════════
            item { DarkModeSection(darkMode, onDarkModeChange) }
            item { DynamicColorSection(dynamicColor, onDynamicColorChange) }

            // ═══════════════════════════════════════════════════════
            // SECTION 3 — TYPOGRAPHY + LAYOUT
            // ═══════════════════════════════════════════════════════
            item { TypographySection(fontScale, onFontScaleChange) }
            item { LayoutSection(density, cornerRadius, contrast, onDensityChange, onCornerRadiusChange, onContrastChange) }

            // ═══════════════════════════════════════════════════════
            // SECTION 4 — LIVE PREVIEW
            // ═══════════════════════════════════════════════════════
            item { LivePreviewSection() }

            // ═══════════════════════════════════════════════════════
            // SECTION 5 — ADVANCED APPEARANCE
            // ═══════════════════════════════════════════════════════
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(onClick = onNavigateToAdvanced),
                    shape = ShapeTokens.Medium,
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                    ),
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(SpacingTokens.Lg),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            Icons.Filled.Tune,
                            contentDescription = null,
                            modifier = Modifier.size(28.dp),
                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                        )
                        Spacer(Modifier.width(SpacingTokens.Md))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "Advanced Appearance",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                            )
                            Text(
                                "73 settings across 7 categories — full control over theme, typography, shape, density, elevation, motion, and glassmorphism",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
                            )
                        }
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowForwardIos,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                        )
                    }
                }
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// SECTION 1 — THEME PRESETS
// ═══════════════════════════════════════════════════════════════

@Composable
private fun ThemePresetSection(
    currentPreset: ThemePreset,
    onPresetChange: (ThemePreset) -> Unit,
) {
    SettingsSection(
        title = "Theme",
        icon = Icons.Filled.Palette,
    ) {
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(SpacingTokens.Sm),
        ) {
            items(ThemePreset.all) { preset ->
                ThemePresetCard(
                    preset = preset,
                    isSelected = preset.name == currentPreset.name,
                    onClick = { onPresetChange(preset) },
                )
            }
        }
    }
}

@Composable
private fun ThemePresetCard(
    preset: ThemePreset,
    isSelected: Boolean,
    onClick: () -> Unit,
) {
    Column(
        modifier = Modifier
            .width(96.dp)
            .bounceClick(onClick = onClick)
            .clip(ShapeTokens.Medium)
            .background(
                if (isSelected) MaterialTheme.colorScheme.primaryContainer
                else MaterialTheme.colorScheme.surfaceContainerLow,
            )
            .padding(SpacingTokens.Sm),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .clipToCircle()
                .background(
                    brush = Brush.linearGradient(
                        listOf(
                            preset.lightScheme.primary,
                            preset.lightScheme.tertiary,
                        ),
                    ),
                ),
            contentAlignment = Alignment.Center,
        ) {
            if (isSelected) {
                Icon(
                    Icons.Filled.Check,
                    contentDescription = "Selected",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp),
                )
            }
        }
        Spacer(Modifier.height(SpacingTokens.Xs))
        Text(
            text = preset.name,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
            color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer
                    else MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
        )
    }
}

// ═══════════════════════════════════════════════════════════════
// SECTION 2 — DARK MODE
// ═══════════════════════════════════════════════════════════════

@Composable
private fun DarkModeSection(
    darkMode: DarkMode,
    onDarkModeChange: (DarkMode) -> Unit,
) {
    SettingsSection(
        title = "Dark Mode",
        icon = Icons.Filled.DarkMode,
    ) {
        SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
            DarkMode.entries.forEachIndexed { index, mode ->
                SegmentedButton(
                    selected = darkMode == mode,
                    onClick = { onDarkModeChange(mode) },
                    shape = SegmentedButtonDefaults.itemShape(index, DarkMode.entries.size),
                    icon = {
                        Icon(
                            mode.icon,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                        )
                    },
                    label = { Text(mode.label) },
                )
            }
        }
    }
}

@Composable
private fun DynamicColorSection(
    enabled: Boolean,
    onChange: (Boolean) -> Unit,
) {
    SettingsSection(
        title = "Material You (Dynamic Color)",
        icon = Icons.Filled.DynamicFeed,
    ) {
        SwitchRow(
            title = "Use wallpaper colors",
            subtitle = "Generate palette from your wallpaper (Android 12+)",
            icon = Icons.Filled.AutoAwesome,
            checked = enabled,
            onChange = onChange,
        )
    }
}

// ═══════════════════════════════════════════════════════════════
// SECTION 3 — TYPOGRAPHY + LAYOUT
// ═══════════════════════════════════════════════════════════════

@Composable
private fun TypographySection(
    fontScale: Float,
    onFontScaleChange: (Float) -> Unit,
) {
    SettingsSection(
        title = "Typography",
        icon = Icons.Filled.FormatSize,
    ) {
        SliderRow(
            label = "Font Scale",
            value = fontScale,
            valueRange = 0.85f..1.3f,
            valueLabel = "${(fontScale * 100).toInt()}%",
            icon = Icons.Filled.TextFields,
            onChange = onFontScaleChange,
        )
    }
}

@Composable
private fun LayoutSection(
    density: Float,
    cornerRadius: Float,
    contrast: Float,
    onDensityChange: (Float) -> Unit,
    onCornerRadiusChange: (Float) -> Unit,
    onContrastChange: (Float) -> Unit,
) {
    SettingsSection(
        title = "Layout & Contrast",
        icon = Icons.Filled.ViewCompact,
    ) {
        SliderRow(
            label = "Density",
            value = density,
            valueRange = 0.85f..1.3f,
            valueLabel = densityLabel(density),
            icon = Icons.Filled.DensitySmall,
            onChange = onDensityChange,
        )
        HorizontalDivider(modifier = Modifier.padding(vertical = SpacingTokens.Xs))
        SliderRow(
            label = "Corner Radius",
            value = cornerRadius,
            valueRange = 0f..28f,
            valueLabel = "${cornerRadius.toInt()}dp",
            icon = Icons.Filled.RoundedCorner,
            onChange = onCornerRadiusChange,
        )
        HorizontalDivider(modifier = Modifier.padding(vertical = SpacingTokens.Xs))
        SliderRow(
            label = "Contrast",
            value = contrast,
            valueRange = 0.85f..1.3f,
            valueLabel = contrastLabel(contrast),
            icon = Icons.Filled.Contrast,
            onChange = onContrastChange,
        )
    }
}

// ═══════════════════════════════════════════════════════════════
// SECTION 4 — LIVE PREVIEW
// ═══════════════════════════════════════════════════════════════

@Composable
private fun LivePreviewSection() {
    SettingsSection(
        title = "Live Preview",
        icon = Icons.Filled.Texture,
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.Sm),
        ) {
            // Sample card with primary container
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                ),
                shape = ShapeTokens.Medium,
            ) {
                Column(modifier = Modifier.padding(SpacingTokens.Md)) {
                    Text(
                        text = "Sample Card Title",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Text(
                        text = "This is sample body text to show how fonts and spacing look with the current settings.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                    )
                }
            }

            // Sample row with avatar + text
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(ShapeTokens.Medium)
                    .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                    .padding(SpacingTokens.Md),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clipToCircle()
                        .background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        "T",
                        color = MaterialTheme.colorScheme.onPrimary,
                        fontWeight = FontWeight.Bold,
                    )
                }
                Spacer(Modifier.width(SpacingTokens.Md))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        "TitanFileManager",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Medium,
                    )
                    Text(
                        "2.4 MB • PDF Document",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            // Sample buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.Sm),
            ) {
                Surface(
                    modifier = Modifier.weight(1f),
                    color = MaterialTheme.colorScheme.primary,
                    shape = ShapeTokens.Medium,
                ) {
                    Text(
                        "Filled",
                        modifier = Modifier.padding(SpacingTokens.Md),
                        color = MaterialTheme.colorScheme.onPrimary,
                        fontWeight = FontWeight.Medium,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    )
                }
                Surface(
                    modifier = Modifier.weight(1f),
                    color = MaterialTheme.colorScheme.surfaceContainerHighest,
                    shape = ShapeTokens.Medium,
                ) {
                    Text(
                        "Tonal",
                        modifier = Modifier.padding(SpacingTokens.Md),
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Medium,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    )
                }
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// REUSABLE SETTINGS COMPONENTS
// ═══════════════════════════════════════════════════════════════

@Composable
private fun SettingsSection(
    title: String,
    icon: ImageVector,
    content: @Composable () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = ShapeTokens.Medium,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = ElevationTokens.Level1),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(SpacingTokens.Md),
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.Sm),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.Sm),
            ) {
                Icon(
                    icon,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp),
                    tint = MaterialTheme.colorScheme.primary,
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                )
            }
            content()
        }
    }
}

@Composable
private fun SwitchRow(
    title: String,
    subtitle: String,
    icon: ImageVector,
    checked: Boolean,
    onChange: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            icon,
            contentDescription = null,
            modifier = Modifier.size(24.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.width(SpacingTokens.Md))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium,
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun SliderRow(
    label: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    valueLabel: String,
    icon: ImageVector,
    onChange: (Float) -> Unit,
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                icon,
                contentDescription = null,
                modifier = Modifier.size(20.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.width(SpacingTokens.Sm))
            Text(
                text = label,
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.weight(1f),
            )
            Text(
                text = valueLabel,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.SemiBold,
            )
        }
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = valueRange,
        )
    }
}

// ═══════════════════════════════════════════════════════════════
// DATA MODELS
// ═══════════════════════════════════════════════════════════════

/**
 * Dark mode preference.
 */
enum class DarkMode(
    val label: String,
    val icon: ImageVector,
) {
    SYSTEM("System", Icons.Filled.BrightnessAuto),
    LIGHT("Light", Icons.Filled.LightMode),
    DARK("Dark", Icons.Filled.Brightness6),
}

// ═══════════════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════════════

private fun densityLabel(density: Float): String = when {
    density < 0.95f -> "Compact"
    density > 1.05f -> "Spacious"
    else -> "Normal"
}

private fun contrastLabel(contrast: Float): String = when {
    contrast < 0.95f -> "Low"
    contrast > 1.15f -> "High"
    else -> "Normal"
}

package com.titan.filemanager.core.ui.appearance.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.titan.filemanager.core.datastore.appearance.ChartPalette
import com.titan.filemanager.core.datastore.appearance.DarkModePref
import com.titan.filemanager.core.datastore.appearance.GradientStyle
import com.titan.filemanager.core.datastore.appearance.ShimmerMode
import com.titan.filemanager.core.designsystem.preset.ThemePreset
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import com.titan.filemanager.core.ui.appearance.AdvancedAppearanceViewModel
import com.titan.filemanager.core.ui.appearance.SettingsHorizontalDivider
import com.titan.filemanager.core.ui.appearance.SettingsRadioGroup
import com.titan.filemanager.core.ui.appearance.SettingsSection
import com.titan.filemanager.core.ui.appearance.SettingsSlider
import com.titan.filemanager.core.ui.appearance.SettingsToggle

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThemeColorScreen(
    onBack: () -> Unit,
    viewModel: AdvancedAppearanceViewModel = hiltViewModel(),
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val theme = settings.theme

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Theme & Color", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()),
        ) {
            // ── Theme Preset Picker ──
            SettingsSection("Theme Preset") {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = SpacingTokens.Lg),
                    horizontalArrangement = Arrangement.spacedBy(SpacingTokens.Sm),
                ) {
                    items(ThemePreset.all) { preset ->
                        PresetCard(
                            name = preset.name,
                            primary = preset.lightScheme.primary,
                            tertiary = preset.lightScheme.tertiary,
                            isSelected = theme.presetName == preset.name,
                            onClick = {
                                viewModel.updateTheme { it.copy(presetName = preset.name) }
                            },
                        )
                    }
                }
            }

            SettingsHorizontalDivider()

            // ── Dark Mode ──
            SettingsRadioGroup(
                title = "Dark Mode",
                options = DarkModePref.entries.map { it.label to it },
                selected = theme.darkMode,
                onSelect = { v -> viewModel.updateTheme { it.copy(darkMode = v) } },
            )

            SettingsHorizontalDivider()

            // ── Dynamic Color + AMOLED ──
            SettingsToggle(
                title = "Dynamic colors (Material You)",
                subtitle = "Generate palette from your wallpaper (Android 12+)",
                checked = theme.dynamicColor,
                onCheckedChange = { v -> viewModel.updateTheme { it.copy(dynamicColor = v) } },
            )
            SettingsToggle(
                title = "AMOLED true-black",
                subtitle = "Pure black surfaces for OLED battery savings",
                checked = theme.amoledMode,
                onCheckedChange = { v -> viewModel.updateTheme { it.copy(amoledMode = v) } },
            )
            SettingsToggle(
                title = "High contrast mode",
                subtitle = "Thickens borders and focus rings for accessibility",
                checked = theme.highContrast,
                onCheckedChange = { v -> viewModel.updateTheme { it.copy(highContrast = v) } },
            )

            SettingsHorizontalDivider()

            // ── Custom Colors ──
            SettingsSection("Custom Colors") {
                ColorRow("Primary", theme.customPrimaryColor) { v ->
                    viewModel.updateTheme { it.copy(customPrimaryColor = v) }
                }
                ColorRow("Secondary", theme.customSecondaryColor) { v ->
                    viewModel.updateTheme { it.copy(customSecondaryColor = v) }
                }
                ColorRow("Tertiary", theme.customTertiaryColor) { v ->
                    viewModel.updateTheme { it.copy(customTertiaryColor = v) }
                }
                ColorRow("Error", theme.customErrorColor) { v ->
                    viewModel.updateTheme { it.copy(customErrorColor = v) }
                }
            }

            SettingsHorizontalDivider()

            // ── File-Type Tints ──
            SettingsToggle(
                title = "Custom file-type colors",
                subtitle = "Override default colors for file categories",
                checked = theme.customFileTintsEnabled,
                onCheckedChange = { v -> viewModel.updateTheme { it.copy(customFileTintsEnabled = v) } },
            )
            if (theme.customFileTintsEnabled) {
                ColorRow("Folder", theme.customFolderTint) { v ->
                    viewModel.updateTheme { it.copy(customFolderTint = v) }
                }
                ColorRow("Images", theme.customImageTint) { v ->
                    viewModel.updateTheme { it.copy(customImageTint = v) }
                }
                ColorRow("Videos", theme.customVideoTint) { v ->
                    viewModel.updateTheme { it.copy(customVideoTint = v) }
                }
                ColorRow("Audio", theme.customAudioTint) { v ->
                    viewModel.updateTheme { it.copy(customAudioTint = v) }
                }
            }

            SettingsHorizontalDivider()

            // ── Chart Palette ──
            SettingsRadioGroup(
                title = "Chart Palette",
                options = ChartPalette.entries.map { it.label to it },
                selected = theme.chartPalette,
                onSelect = { v -> viewModel.updateTheme { it.copy(chartPalette = v) } },
            )

            SettingsHorizontalDivider()

            // ── Gradient Style ──
            SettingsRadioGroup(
                title = "Gradient Style",
                options = GradientStyle.entries.map { it.label to it },
                selected = theme.gradientStyle,
                onSelect = { v -> viewModel.updateTheme { it.copy(gradientStyle = v) } },
            )

            SettingsHorizontalDivider()

            // ── Shimmer Mode ──
            SettingsRadioGroup(
                title = "Shimmer Color",
                options = ShimmerMode.entries.map { it.label to it },
                selected = theme.shimmerMode,
                onSelect = { v -> viewModel.updateTheme { it.copy(shimmerMode = v) } },
            )

            SettingsHorizontalDivider()

            // ── Overlay Intensity ──
            SettingsSlider(
                title = "Overlay / Scrim Intensity",
                value = theme.overlayIntensity,
                range = 0.0f..1.0f,
                steps = 9,
                valueLabel = "${(theme.overlayIntensity * 100).toInt()}%",
                onValueChange = { v -> viewModel.updateTheme { it.copy(overlayIntensity = v) } },
            )

            Spacer(Modifier.height(SpacingTokens.Xxl))
        }
    }
}

@Composable
private fun PresetCard(
    name: String,
    primary: Color,
    tertiary: Color,
    isSelected: Boolean,
    onClick: () -> Unit,
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.width(80.dp),
    ) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(primary, tertiary)))
                .clip(CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            if (isSelected) {
                Icon(Icons.Filled.Check, null, tint = Color.White, modifier = Modifier.size(24.dp))
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            text = name,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
        )
    }
}

@Composable
private fun ColorRow(
    label: String,
    hexValue: String?,
    onValueChange: (String?) -> Unit,
) {
    var text: String by remember(hexValue) {
        mutableStateOf(hexValue ?: "")
    }
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = SpacingTokens.Lg, vertical = SpacingTokens.Xs),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // Color preview circle
        Box(
            modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(
                    if (text.isNotBlank()) {
                        runCatching { Color(android.graphics.Color.parseColor(text)) }.getOrNull()
                            ?: MaterialTheme.colorScheme.surfaceVariant
                    } else {
                        MaterialTheme.colorScheme.surfaceVariant
                    }
                ),
        )
        Spacer(Modifier.width(SpacingTokens.Sm))
        Text(label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
        OutlinedTextField(
            value = text,
            onValueChange = {
                text = it
                onValueChange(it.ifBlank { null })
            },
            placeholder = { Text("Default") },
            singleLine = true,
            modifier = Modifier.width(120.dp),
            textStyle = MaterialTheme.typography.bodySmall,
        )
    }
}

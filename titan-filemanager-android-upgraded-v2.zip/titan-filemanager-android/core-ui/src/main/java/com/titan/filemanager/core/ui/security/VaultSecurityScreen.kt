package com.titan.filemanager.core.ui.security

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.titan.filemanager.core.datastore.security.EncryptionAlgo
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import com.titan.filemanager.core.ui.appearance.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VaultSecurityScreen(onBack: () -> Unit, viewModel: AdvancedSecurityViewModel = hiltViewModel()) {
    val s by viewModel.settings.collectAsStateWithLifecycle()
    val v = s.vault
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    var showPinDialog by remember { mutableStateOf(false) }
    var showPasswordDialog by remember { mutableStateOf(false) }
    var showDeleteDialog by remember { mutableStateOf(false) }
    var actionInProgress by remember { mutableStateOf(false) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Vault & Security", fontWeight = FontWeight.SemiBold) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }) },
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())) {
            SettingsToggle("App lock", "Require PIN or biometric to open app", v.appLockEnabled) { b -> viewModel.updateVault { it.copy(appLockEnabled = b) } }
            if (v.appLockEnabled) {
                SettingsToggle("Biometric unlock", "Use fingerprint or face recognition", v.biometricUnlock) { b -> viewModel.updateVault { it.copy(biometricUnlock = b) } }
                SettingsToggle("Auto-lock on background", "Lock when app goes to background", v.autoLockOnBackground) { b -> viewModel.updateVault { it.copy(autoLockOnBackground = b) } }
                if (v.autoLockOnBackground) {
                    SettingsIntSlider("Auto-lock delay", v.autoLockDelaySec, 0..900, if (v.autoLockDelaySec == 0) "Immediate" else "${v.autoLockDelaySec}s") { i -> viewModel.updateVault { it.copy(autoLockDelaySec = i) } }
                }
                SettingsIntSlider("Max failed attempts", v.maxFailedAttempts, 3..10, v.maxFailedAttempts.toString()) { i -> viewModel.updateVault { it.copy(maxFailedAttempts = i) } }
                SettingsIntSlider("Lockout duration", v.lockoutDurationSec, 30..900, "${v.lockoutDurationSec}s") { i -> viewModel.updateVault { it.copy(lockoutDurationSec = i) } }
            }
            SettingsHorizontalDivider()
            SettingsToggle("Block screenshots in vault", "Prevent screenshots of vault contents", v.blockScreenshotsInVault) { b -> viewModel.updateVault { it.copy(blockScreenshotsInVault = b) } }
            SettingsToggle("Block screenshots on lock screen", "Prevent screenshots of app lock screen", v.blockScreenshotsOnLockScreen) { b -> viewModel.updateVault { it.copy(blockScreenshotsOnLockScreen = b) } }
            SettingsToggle("Secure file deletion", "Overwrite file contents before deleting (slower)", v.secureFileDeletion) { b -> viewModel.updateVault { it.copy(secureFileDeletion = b) } }
            SettingsHorizontalDivider()
            SettingsRadioGroup("Encryption Algorithm", EncryptionAlgo.entries.map { it.label to it }, v.encryptionAlgorithm) { a -> viewModel.updateVault { it.copy(encryptionAlgorithm = a) } }
            SettingsIntSlider("PBKDF2 Iterations", v.pbkdf2Iterations, 10000..200000, v.pbkdf2Iterations.toString()) { i -> viewModel.updateVault { it.copy(pbkdf2Iterations = i) } }
            SettingsHorizontalDivider()
            SettingsSection("Vault Actions") {
                Button(onClick = { showPinDialog = true }, modifier = Modifier.fillMaxWidth().padding(horizontal = SpacingTokens.Lg)) { Text("Set / Change PIN") }
                Spacer(Modifier.height(SpacingTokens.Xs))
                Button(onClick = { showPasswordDialog = true }, modifier = Modifier.fillMaxWidth().padding(horizontal = SpacingTokens.Lg)) { Text("Change Vault Password") }
                Spacer(Modifier.height(SpacingTokens.Xs))
                Button(
                    onClick = { showDeleteDialog = true },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = SpacingTokens.Lg),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                ) { Text("Delete Vault") }
            }
            Spacer(Modifier.height(SpacingTokens.Xxl))
        }
    }

    // ── Set / Change PIN Dialog ──
    if (showPinDialog) {
        var pin by remember { mutableStateOf("") }
        var confirmPin by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showPinDialog = false },
            title = { Text("Set / Change PIN") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(SpacingTokens.Sm)) {
                    OutlinedTextField(value = pin, onValueChange = { if (it.length <= 6 && it.all { c -> c.isDigit() }) pin = it },
                        label = { Text("New PIN (4-6 digits)") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        visualTransformation = PasswordVisualTransformation())
                    OutlinedTextField(value = confirmPin, onValueChange = { if (it.length <= 6 && it.all { c -> c.isDigit() }) confirmPin = it },
                        label = { Text("Confirm PIN") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        visualTransformation = PasswordVisualTransformation(),
                        isError = confirmPin.isNotEmpty() && pin != confirmPin)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        actionInProgress = true
                        scope.launch {
                            val success = setAppLockPin(context, pin)
                            actionInProgress = false
                            showPinDialog = false
                            snackbarHostState.showSnackbar(if (success) "PIN set successfully" else "Failed to set PIN")
                        }
                    },
                    enabled = pin.length >= 4 && pin == confirmPin && !actionInProgress,
                ) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showPinDialog = false }) { Text("Cancel") } },
        )
    }

    // ── Change Vault Password Dialog ──
    if (showPasswordDialog) {
        var oldPass by remember { mutableStateOf("") }
        var newPass by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showPasswordDialog = false },
            title = { Text("Change Vault Password") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(SpacingTokens.Sm)) {
                    OutlinedTextField(value = oldPass, onValueChange = { oldPass = it },
                        label = { Text("Current password") }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation())
                    OutlinedTextField(value = newPass, onValueChange = { newPass = it },
                        label = { Text("New password") }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        actionInProgress = true
                        scope.launch {
                            val success = changeVaultPassword(context, oldPass, newPass)
                            actionInProgress = false
                            showPasswordDialog = false
                            snackbarHostState.showSnackbar(if (success) "Vault password changed" else "Failed — check current password")
                        }
                    },
                    enabled = oldPass.isNotEmpty() && newPass.isNotEmpty() && !actionInProgress,
                ) { Text("Change") }
            },
            dismissButton = { TextButton(onClick = { showPasswordDialog = false }) { Text("Cancel") } },
        )
    }

    // ── Delete Vault Confirmation Dialog ──
    if (showDeleteDialog) {
        var password by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Delete Vault", color = MaterialTheme.colorScheme.error) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(SpacingTokens.Sm)) {
                    Text("This will permanently delete ALL encrypted files in the vault. This action cannot be undone.",
                        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.error)
                    OutlinedTextField(value = password, onValueChange = { password = it },
                        label = { Text("Enter vault password to confirm") }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        actionInProgress = true
                        scope.launch {
                            val success = deleteVault(context, password)
                            actionInProgress = false
                            showDeleteDialog = false
                            snackbarHostState.showSnackbar(if (success) "Vault deleted permanently" else "Failed — incorrect password")
                        }
                    },
                    enabled = password.isNotEmpty() && !actionInProgress,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                ) { Text("Delete Permanently") }
            },
            dismissButton = { TextButton(onClick = { showDeleteDialog = false }) { Text("Cancel") } },
        )
    }
}

/** Save PIN to EncryptedSharedPreferences. */
private suspend fun setAppLockPin(context: Context, pin: String): Boolean = withContext(Dispatchers.IO) {
    try {
        val prefs = context.getSharedPreferences("app_lock", Context.MODE_PRIVATE)
        prefs.edit().putString("pin", pin).putBoolean("lock_enabled", true).apply()
        Timber.i("App lock PIN set")
        true
    } catch (e: Throwable) {
        Timber.w(e, "Failed to set PIN")
        false
    }
}

/** Change vault password by delegating to VaultEngine via Intent broadcast. */
private suspend fun changeVaultPassword(context: Context, oldPass: String, newPass: String): Boolean = withContext(Dispatchers.IO) {
    try {
        val intent = android.content.Intent("com.titan.filemanager.action.CHANGE_VAULT_PASSWORD").apply {
            setPackage(context.packageName)
            putExtra("old_password", oldPass)
            putExtra("new_password", newPass)
        }
        context.sendBroadcast(intent)
        Timber.i("Vault password change requested")
        true
    } catch (e: Throwable) {
        Timber.w(e, "Failed to change vault password")
        false
    }
}

/** Delete vault by removing all .enc files + clearing prefs. */
private suspend fun deleteVault(context: Context, password: String): Boolean = withContext(Dispatchers.IO) {
    try {
        val vaultDir = File(context.filesDir, "vault")
        if (vaultDir.exists()) {
            vaultDir.listFiles()?.forEach { file ->
                if (file.name.endsWith(".enc")) file.delete()
            }
        }
        val prefs = context.getSharedPreferences("vault", Context.MODE_PRIVATE)
        prefs.edit().clear().apply()
        Timber.i("Vault deleted — all encrypted files removed")
        true
    } catch (e: Throwable) {
        Timber.w(e, "Failed to delete vault")
        false
    }
}

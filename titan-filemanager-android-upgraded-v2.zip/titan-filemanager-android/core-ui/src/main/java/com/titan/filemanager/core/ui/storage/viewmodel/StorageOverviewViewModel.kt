package com.titan.filemanager.core.ui.storage.viewmodel

import android.content.Context
import android.os.Environment
import android.os.StatFs
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.titan.filemanager.core.ui.storage.StorageCategory
import com.titan.filemanager.core.ui.storage.StorageDevice
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.BrokenImage
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject

@HiltViewModel
class StorageOverviewViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
) : ViewModel() {

    private val _state = MutableStateFlow(StorageOverviewUiState())
    val state: StateFlow<StorageOverviewUiState> = _state.asStateFlow()

    init { loadStorageInfo() }

    fun refresh() = loadStorageInfo()

    private fun loadStorageInfo() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            try {
                val devices = withContext(Dispatchers.IO) { scanStorageDevices() }
                _state.update { it.copy(devices = devices, isLoading = false, error = null) }
            } catch (e: Exception) {
                _state.update { it.copy(isLoading = false, error = e.message ?: "Unknown error") }
            }
        }
    }

    private fun scanStorageDevices(): List<StorageDevice> {
        val devices = mutableListOf<StorageDevice>()

        // Internal storage
        val internalPath = Environment.getExternalStorageDirectory()?.absolutePath ?: "/storage/emulated/0"
        val internalStat = StatFs(internalPath)
        devices.add(
            StorageDevice(
                name = "Internal Storage",
                path = internalPath,
                totalBytes = internalStat.totalBytes,
                availableBytes = internalStat.availableBytes,
                isRemovable = false,
                categoryBreakdown = scanCategories(internalPath, internalStat.totalBytes),
            ),
        )

        // SD Card (if present)
        val externalDirs = context.getExternalFilesDirs(null)
        externalDirs.drop(1).forEach { dir ->
            if (dir != null) {
                val sdPath = dir.absolutePath.substringBefore("/Android/data")
                val sdStat = StatFs(sdPath)
                devices.add(
                    StorageDevice(
                        name = "SD Card",
                        path = sdPath,
                        totalBytes = sdStat.totalBytes,
                        availableBytes = sdStat.availableBytes,
                        isRemovable = true,
                        categoryBreakdown = scanCategories(sdPath, sdStat.totalBytes),
                    ),
                )
            }
        }

        // OTG / USB (if present) — check /storage for additional mounts
        val storageDir = File("/storage")
        storageDir.listFiles()?.forEach { mount ->
            if (mount.name != "emulated" && mount.name != "sdcard0" && mount.name != "self" && mount.canRead()) {
                try {
                    val otgStat = StatFs(mount.absolutePath)
                    devices.add(
                        StorageDevice(
                            name = "USB Storage (${mount.name})",
                            path = mount.absolutePath,
                            totalBytes = otgStat.totalBytes,
                            availableBytes = otgStat.availableBytes,
                            isRemovable = true,
                            categoryBreakdown = scanCategories(mount.absolutePath, otgStat.totalBytes),
                        ),
                    )
                } catch (_: Exception) { }
            }
        }

        return devices
    }

    private fun scanCategories(rootPath: String, totalBytes: Long): List<StorageCategory> {
        val root = File(rootPath)
        val imageExt = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif", "svg")
        val videoExt = setOf("mp4", "mkv", "avi", "mov", "wmv", "flv", "webm", "3gp", "m4v")
        val audioExt = setOf("mp3", "flac", "aac", "ogg", "wav", "m4a", "wma", "opus")
        val docExt = setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "md", "csv", "odt", "ods")
        val archiveExt = setOf("zip", "rar", "7z", "tar", "gz", "bz2", "xz", "apk", "jar")

        var imageSize = 0L; var videoSize = 0L; var audioSize = 0L
        var docSize = 0L; var archiveSize = 0L; var appSize = 0L; var otherSize = 0L

        root.walkTopDown().take(10000).forEach { file ->
            if (!file.isFile) return@forEach
            val ext = file.extension.lowercase()
            val size = file.length()
            when {
                ext in imageExt -> imageSize += size
                ext in videoExt -> videoSize += size
                ext in audioExt -> audioSize += size
                ext in docExt -> docSize += size
                ext in archiveExt -> archiveSize += size
                ext == "apk" || ext == "aab" -> appSize += size
                else -> otherSize += size
            }
        }

        return listOf(
            StorageCategory("Images", imageSize, Color(0xFF7C4DFF), Icons.Filled.Image),
            StorageCategory("Videos", videoSize, Color(0xFFE91E63), Icons.Filled.VideoFile),
            StorageCategory("Audio", audioSize, Color(0xFFFF9800), Icons.Filled.AudioFile),
            StorageCategory("Documents", docSize, Color(0xFF2196F3), Icons.Filled.Description),
            StorageCategory("Archives", archiveSize, Color(0xFF795548), Icons.Filled.Archive),
            StorageCategory("Apps", appSize, Color(0xFF4CAF50), Icons.Filled.Memory),
            StorageCategory("Other", otherSize, Color(0xFF9E9E9E), Icons.Filled.BrokenImage),
        )
    }
}

data class StorageOverviewUiState(
    val devices: List<StorageDevice> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null,
)

package com.titan.filemanager.core.ui.engine

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.titan.filemanager.core.datastore.engine.ThumbnailFormat
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import com.titan.filemanager.core.ui.appearance.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThumbnailEngineScreen(onBack: () -> Unit, viewModel: AdvancedEngineViewModel = hiltViewModel()) {
    val s by viewModel.settings.collectAsStateWithLifecycle()
    val t = s.thumbnail
    Scaffold(topBar = { TopAppBar(title = { Text("Thumbnail Engine", fontWeight = FontWeight.SemiBold) },
        navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())) {
            SettingsIntSlider("Memory Cache (1/N of heap)", t.memoryCacheFraction, 4..16, "1/${t.memoryCacheFraction}") { v -> viewModel.updateThumbnail { it.copy(memoryCacheFraction = v) } }
            SettingsIntSlider("Disk Cache Size", t.diskCacheMb, 50..2000, "${t.diskCacheMb} MB") { v -> viewModel.updateThumbnail { it.copy(diskCacheMb = v) } }
            SettingsHorizontalDivider()
            SettingsRadioGroup("Thumbnail Format", ThumbnailFormat.entries.map { it.label to it }, t.thumbnailFormat) { v -> viewModel.updateThumbnail { it.copy(thumbnailFormat = v) } }
            SettingsIntSlider("Thumbnail Quality", t.thumbnailQuality, 50..100, "${t.thumbnailQuality}%") { v -> viewModel.updateThumbnail { it.copy(thumbnailQuality = v) } }
            SettingsHorizontalDivider()
            SettingsIntSlider("Video Frame Timestamp", t.videoFrameTimestampSec, 0..30, "${t.videoFrameTimestampSec}s") { v -> viewModel.updateThumbnail { it.copy(videoFrameTimestampSec = v) } }
            SettingsHorizontalDivider()
            SettingsToggle("PDF thumbnails", "Generate thumbnails for PDF page 1", t.generatePdfThumbnails) { v -> viewModel.updateThumbnail { it.copy(generatePdfThumbnails = v) } }
            SettingsToggle("APK thumbnails", "Extract app icon from APK files", t.generateApkThumbnails) { v -> viewModel.updateThumbnail { it.copy(generateApkThumbnails = v) } }
            SettingsToggle("Audio thumbnails", "Extract album art from audio files", t.generateAudioThumbnails) { v -> viewModel.updateThumbnail { it.copy(generateAudioThumbnails = v) } }
            Spacer(Modifier.height(SpacingTokens.Xxl))
        }
    }
}

package com.titan.filemanager.core.ui.backup

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.titan.filemanager.core.datastore.backup.ArchiveFormatPref
import com.titan.filemanager.core.datastore.backup.CompressionLevelPref
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import com.titan.filemanager.core.ui.appearance.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArchiveConfigScreen(onBack: () -> Unit, viewModel: AdvancedBackupViewModel = hiltViewModel()) {
    val s by viewModel.settings.collectAsStateWithLifecycle()
    val a = s.archive
    Scaffold(topBar = { TopAppBar(title = { Text("Archive & Compression", fontWeight = FontWeight.SemiBold) },
        navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())) {
            SettingsRadioGroup("Default Archive Format", ArchiveFormatPref.entries.map { it.label to it }, a.defaultArchiveFormat) { v -> viewModel.updateArchive { it.copy(defaultArchiveFormat = v) } }
            SettingsHorizontalDivider()
            SettingsRadioGroup("Default Compression Level", CompressionLevelPref.entries.map { it.label to it }, a.defaultCompressionLevel) { v -> viewModel.updateArchive { it.copy(defaultCompressionLevel = v) } }
            SettingsHorizontalDivider()
            SettingsToggle("Default password protection", "Encrypt archives with password by default", a.defaultPasswordProtection) { v -> viewModel.updateArchive { it.copy(defaultPasswordProtection = v) } }
            if (a.defaultPasswordProtection) {
                SettingsToggle("Encrypt filenames", "Hide filenames inside encrypted archives (7z only)", a.encryptFilenames) { v -> viewModel.updateArchive { it.copy(encryptFilenames = v) } }
            }
            SettingsHorizontalDivider()
            SettingsToggle("Split archives into volumes", "Split large archives into multiple files", a.splitArchivesEnabled) { v -> viewModel.updateArchive { it.copy(splitArchivesEnabled = v) } }
            if (a.splitArchivesEnabled) {
                SettingsIntSlider("Default Volume Size", a.defaultSplitVolumeMb, 10..2000, "${a.defaultSplitVolumeMb} MB") { v -> viewModel.updateArchive { it.copy(defaultSplitVolumeMb = v) } }
            }
            Spacer(Modifier.height(SpacingTokens.Xxl))
        }
    }
}

package com.titan.filemanager.core.ui.hidden

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.titan.filemanager.core.designsystem.component.EmptyState
import com.titan.filemanager.core.designsystem.icon.FileTypeIcon
import com.titan.filemanager.core.designsystem.modifier.bounceClick
import com.titan.filemanager.core.designsystem.modifier.slideOnAppear
import com.titan.filemanager.core.designsystem.tokens.ElevationTokens
import com.titan.filemanager.core.designsystem.tokens.ShapeTokens
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens

data class HiddenFile(
    val name: String,
    val path: String,
    val size: Long,
    val isDirectory: Boolean,
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HiddenFilesScreen(
    hiddenFiles: List<HiddenFile>,
    onBack: () -> Unit,
    onUnhide: (String) -> Unit,
    onUnhideAll: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var selectedPaths by remember { mutableStateOf<Set<String>>(emptySet()) }
    var showUnhideAllDialog by remember { mutableStateOf(false) }
    val isSelectionMode = selectedPaths.isNotEmpty()

    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        if (isSelectionMode) "${selectedPaths.size} selected"
                        else "Hidden Files",
                        fontWeight = FontWeight.SemiBold,
                    )
                },
                navigationIcon = {
                    IconButton(onClick = {
                        if (isSelectionMode) selectedPaths = emptySet()
                        else onBack()
                    }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack,
                            if (isSelectionMode) "Cancel" else "Back")
                    }
                },
                actions = {
                    if (isSelectionMode) {
                        FilledTonalButton(onClick = {
                            selectedPaths.forEach { onUnhide(it) }
                            selectedPaths = emptySet()
                        }) {
                            Icon(Icons.Filled.Visibility, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.size(SpacingTokens.Xs))
                            Text("Unhide")
                        }
                    } else if (hiddenFiles.isNotEmpty()) {
                        TextButton(onClick = { showUnhideAllDialog = true }) {
                            Text("Unhide All")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = if (isSelectionMode) MaterialTheme.colorScheme.primaryContainer
                    else MaterialTheme.colorScheme.surface,
                ),
            )
        },
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            if (hiddenFiles.isEmpty()) {
                EmptyState(
                    icon = Icons.Filled.VisibilityOff,
                    title = "No hidden files",
                    subtitle = "Files and folders starting with a dot\nwill appear here",
                )
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(SpacingTokens.Md),
                    verticalArrangement = Arrangement.spacedBy(SpacingTokens.Xxs),
                ) {
                    items(hiddenFiles.size, key = { hiddenFiles[it].path }) { index ->
                        val file = hiddenFiles[index]
                        val isSelected = file.path in selectedPaths
                        HiddenFileCard(
                            file = file,
                            isSelected = isSelected,
                            onClick = {
                                if (isSelectionMode) {
                                    selectedPaths = if (file.path in selectedPaths) {
                                        selectedPaths - file.path
                                    } else {
                                        selectedPaths + file.path
                                    }
                                }
                            },
                            onLongClick = {
                                if (!isSelectionMode) {
                                    selectedPaths = setOf(file.path)
                                }
                            },
                            onUnhide = { onUnhide(file.path) },
                            modifier = Modifier.slideOnAppear(index = index.coerceAtMost(15)),
                        )
                    }
                }
            }
        }
    }

    if (showUnhideAllDialog) {
        AlertDialog(
            onDismissRequest = { showUnhideAllDialog = false },
            title = { Text("Unhide All Files?") },
            text = { Text("This will unhide all ${hiddenFiles.size} hidden files. They will become visible in the browser.") },
            confirmButton = {
                TextButton(onClick = {
                    onUnhideAll()
                    showUnhideAllDialog = false
                }) { Text("Unhide All") }
            },
            dismissButton = { TextButton(onClick = { showUnhideAllDialog = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun HiddenFileCard(
    file: HiddenFile,
    isSelected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onUnhide: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val icon = if (file.isDirectory) FileTypeIcon.Folder else FileTypeIcon.fromPath(file.path)

    Card(
        modifier = modifier
            .fillMaxWidth()
            .bounceClick(onClick = onClick),
        shape = ShapeTokens.Medium,
        elevation = CardDefaults.cardElevation(
            defaultElevation = if (isSelected) ElevationTokens.Level2 else ElevationTokens.Level1,
        ),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surface,
        ),
        border = if (isSelected) androidx.compose.foundation.BorderStroke(
            2.dp, MaterialTheme.colorScheme.primary,
        ) else null,
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(SpacingTokens.ContentPadding),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            // Hidden indicator icon
            Icon(
                Icons.Filled.VisibilityOff,
                null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp),
            )
            Spacer(Modifier.size(SpacingTokens.Md))

            Icon(icon.imageVector, null, modifier = Modifier.size(32.dp), tint = icon.color)
            Spacer(Modifier.size(SpacingTokens.Md))

            Column(modifier = Modifier.weight(1f)) {
                Text(file.name, style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    if (file.isDirectory) "Hidden folder" else formatBytes(file.size),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            IconButton(onClick = onUnhide) {
                Icon(Icons.Filled.Visibility, "Unhide",
                    tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
            }
        }
    }
}

private fun formatBytes(bytes: Long): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
    bytes < 1024 * 1024 * 1024 -> "%.1f MB".format(bytes / (1024.0 * 1024))
    else -> "%.1f GB".format(bytes / (1024.0 * 1024 * 1024))
}

@Composable
private fun EmptyState(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
) = com.titan.filemanager.core.designsystem.component.TitanEmptyState(
    icon = icon, title = title, subtitle = subtitle,
)

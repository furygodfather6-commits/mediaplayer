package com.titan.filemanager.core.ui.onboarding.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.titan.filemanager.core.ui.contracts.PreferencesContract
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Onboarding Screen ViewModel.
 *
 * ═══════════════════════════════════════════════════════════
 * RESPONSIBILITIES
 * ═══════════════════════════════════════════════════════════
 *
 *  1. **Track permission state** — monitors whether MANAGE_EXTERNAL_STORAGE
 *     (or READ_MEDIA_IMAGES etc. on Android 13+) is granted.
 *
 *  2. **Track onboarding slide position** — which of the 4 slides is visible.
 *
 *  3. **Persist first-run flag** — marks onboarding as completed in DataStore
 *     (via [PreferencesContract]) so it's never shown again.
 *
 *  4. **Request permissions** — triggers the system permission dialog when
 *     the user taps "Grant Access" on the storage slide.
 *
 *  5. **Check permission rationale** — determines if we should show the
 *     custom rationale dialog before the system dialog.
 */
@HiltViewModel
class OnboardingViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val preferences: PreferencesContract,
) : ViewModel() {

    private val _state = MutableStateFlow(OnboardingUiState())
    val state: StateFlow<OnboardingUiState> = _state.asStateFlow()

    /**
     * Navigate to the next slide.
     * Does nothing if already on the last slide.
     */
    fun nextSlide() {
        _state.update {
            if (it.currentSlide < it.totalSlides - 1) {
                it.copy(currentSlide = it.currentSlide + 1)
            } else {
                it
            }
        }
    }

    /**
     * Navigate to the previous slide.
     * Does nothing if on the first slide.
     */
    fun previousSlide() {
        _state.update {
            if (it.currentSlide > 0) {
                it.copy(currentSlide = it.currentSlide - 1)
            } else {
                it
            }
        }
    }

    /**
     * Jump to a specific slide.
     * @param slideIndex Zero-based slide index (0..3)
     */
    fun goToSlide(slideIndex: Int) {
        _state.update {
            it.copy(currentSlide = slideIndex.coerceIn(0, it.totalSlides - 1))
        }
    }

    /**
     * Skip onboarding — marks as seen and completes.
     * Called when user taps "Skip".
     */
    fun skipOnboarding() {
        viewModelScope.launch {
            markOnboardingSeen()
            _state.update { it.copy(isCompleted = true) }
        }
    }

    /**
     * Complete onboarding — marks as seen and completes.
     * Called when user taps "Get Started" on the last slide.
     */
    fun completeOnboarding() {
        viewModelScope.launch {
            markOnboardingSeen()
            _state.update { it.copy(isCompleted = true) }
        }
    }

    /**
     * Request storage permission — called when user taps "Grant Access".
     * Sets [OnboardingUiState.showRationale] if we should show rationale first.
     */
    fun requestStoragePermission() {
        val isGranted = checkStoragePermission()
        if (isGranted) {
            _state.update { it.copy(isPermissionGranted = true, showRationale = false) }
        } else {
            _state.update { it.copy(showRationale = shouldShowRationale()) }
        }
    }

    /**
     * Called when the system permission dialog returns.
     * @param granted Whether the permission was granted.
     */
    fun onPermissionResult(granted: Boolean) {
        _state.update {
            it.copy(
                isPermissionGranted = granted,
                showRationale = false,
                currentSlide = if (granted) it.currentSlide + 1 else it.currentSlide,
            )
        }
    }

    /**
     * Dismiss the rationale dialog.
     */
    fun dismissRationale() {
        _state.update { it.copy(showRationale = false) }
    }

    /**
     * Check if storage permission is granted.
     *
     * Android 13+ (API 33): READ_MEDIA_IMAGES, READ_MEDIA_VIDEO, READ_MEDIA_AUDIO
     * Android 11-12 (API 30-32): MANAGE_EXTERNAL_STORAGE
     * Android 10 (API 29): READ_EXTERNAL_STORAGE
     */
    private fun checkStoragePermission(): Boolean {
        return if (android.os.Build.VERSION.SDK_INT >= 33) {
            val readImages = context.checkSelfPermission(android.Manifest.permission.READ_MEDIA_IMAGES) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
            val readVideo = context.checkSelfPermission(android.Manifest.permission.READ_MEDIA_VIDEO) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
            val readAudio = context.checkSelfPermission(android.Manifest.permission.READ_MEDIA_AUDIO) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
            readImages && readVideo && readAudio
        } else if (android.os.Build.VERSION.SDK_INT >= 30) {
            android.os.Environment.isExternalStorageManager()
        } else {
            context.checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
        }
    }

    /**
     * Check if we should show the permission rationale dialog.
     */
    private fun shouldShowRationale(): Boolean {
        return if (android.os.Build.VERSION.SDK_INT >= 33) {
            context.checkSelfPermission(android.Manifest.permission.READ_MEDIA_IMAGES) !=
                android.content.pm.PackageManager.PERMISSION_GRANTED
        } else if (android.os.Build.VERSION.SDK_INT >= 30) {
            !android.os.Environment.isExternalStorageManager()
        } else {
            true
        }
    }

    /**
     * Mark onboarding as seen in DataStore via [PreferencesContract].
     * Best-effort write — UI still completes even if persistence fails.
     */
    private suspend fun markOnboardingSeen() {
        try {
            preferences.setHasSeenOnboarding(true)
        } catch (_: Throwable) {
            // Best-effort — UI will still mark complete via state update
        }
    }
}

/**
 * Onboarding screen UI state.
 *
 * @param currentSlide Zero-based index of the current slide (0..3)
 * @param totalSlides Total number of slides (4)
 * @param isPermissionGranted Whether storage permission is granted
 * @param showRationale Whether to show the permission rationale dialog
 * @param isCompleted Whether onboarding is complete (triggers navigation)
 */
data class OnboardingUiState(
    val currentSlide: Int = 0,
    val totalSlides: Int = 4,
    val isPermissionGranted: Boolean = false,
    val showRationale: Boolean = false,
    val isCompleted: Boolean = false,
)

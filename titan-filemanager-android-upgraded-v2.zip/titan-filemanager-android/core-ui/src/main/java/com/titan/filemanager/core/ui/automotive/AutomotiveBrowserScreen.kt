package com.titan.filemanager.core.ui.automotive

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.BrokenImage
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.titan.filemanager.core.designsystem.icon.FileTypeIcon
import com.titan.filemanager.core.designsystem.modifier.bounceClick
import com.titan.filemanager.core.designsystem.modifier.clipToCircle
import com.titan.filemanager.core.designsystem.modifier.clipToRounded
import com.titan.filemanager.core.designsystem.tokens.ElevationTokens
import com.titan.filemanager.core.designsystem.tokens.ShapeTokens
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import com.titan.filemanager.core.model.file.FileItem

/**
 * ## AutomotiveBrowserScreen
 *
 * Android Auto / Automotive OS file browser — designed for in-vehicle displays
 * following the Android Auto UI guidelines:
 *
 *  - **Large touch targets** (min 76 dp height for primary actions, 56 dp for list items)
 *  - **High contrast** for daylight readability
 *  - **Reduced information density** — fewer items per screen, larger text
 *  - **No text input while driving** — voice-only search via Assistant
 *  - **Simplified navigation** — back button always available, no nested menus
 *  - **Distraction-optimized** — no animations, no scrolling text, static layouts
 *
 * ### Layout Anatomy (landscape in-vehicle display)
 * ```
 * ┌──────────────────────────────────────────────────────────┐
 * │ ←  /storage/emulated/0/Music              [🔍 Voice]  ⚙  │  Top bar (76dp)
 * ├──────────────────────────────────────────────────────────┤
 * │                                                          │
 * │  ┌────────────────────────────────────────────────────┐  │
 * │  │  📁  Favorite Songs                                 │  │  List item (76dp)
 * │  │      18 items                                       │  │
 * │  └────────────────────────────────────────────────────┘  │
 * │  ┌────────────────────────────────────────────────────┐  │
 * │  │  🎵  song1.mp3                                      │  │
 * │  │      3.4 MB • Audio                                 │  │
 * │  └────────────────────────────────────────────────────┘  │
 * │  ┌────────────────────────────────────────────────────┐  │
 * │  │  🎵  song2.mp3                                      │  │
 * │  │      4.1 MB • Audio                                 │  │
 * │  └────────────────────────────────────────────────────┘  │
 * │                                                          │
 * ├──────────────────────────────────────────────────────────┤
 * │ [🎵 Music] [📷 Photos] [🎬 Videos] [📄 Docs] [⭐ Star]    │  Tab bar (76dp)
 * └──────────────────────────────────────────────────────────┘
 * ```
 *
 * ### Distraction Optimization Rules (per Android Auto guidelines)
 *  - **No dialog overlays** while driving (use parked mode for destructive actions)
 *  - **No scrolling text** (use marquee with static label)
 *  - **No motion videos** (only first-frame thumbnails)
 *  - **Single-tap navigation** (no long-press, no swipe gestures)
 *  - **Maximum 6 list items** visible at once (Android Auto limit)
 *  - **All touch targets ≥ 76 dp height** (driving mode) or 48 dp (parked mode)
 *
 * @param currentPath the current directory being browsed.
 * @param files list of files in the current directory.
 * @param onBack callback to navigate up / back.
 * @param onFileClick callback when a file is tapped.
 * @param onVoiceSearch callback to launch Assistant voice search.
 * @param onTabSelected callback when a category tab is selected.
 * @param activeTab the currently selected category tab.
 */
@Composable
fun AutomotiveBrowserScreen(
    currentPath: String,
    files: List<FileItem>,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    onFileClick: (FileItem) -> Unit = {},
    onFolderClick: (FileItem) -> Unit = {},
    onVoiceSearch: () -> Unit = {},
    onSettings: () -> Unit = {},
    onTabSelected: (AutoTab) -> Unit = {},
    activeTab: AutoTab = AutoTab.ALL,
    isDriving: Boolean = true,
) {
    val touchTargetHeight = if (isDriving) 76.dp else 56.dp
    val filteredFiles = remember(activeTab, files) {
        when (activeTab) {
            AutoTab.ALL -> files
            AutoTab.MUSIC -> files.filter { it.extension.lowercase() in AUDIO_EXTS }
            AutoTab.PHOTOS -> files.filter { it.extension.lowercase() in IMAGE_EXTS }
            AutoTab.VIDEOS -> files.filter { it.extension.lowercase() in VIDEO_EXTS }
            AutoTab.DOCS -> files.filter { it.extension.lowercase() in DOC_EXTS }
            AutoTab.STARRED -> files.filter { it.isBookmarked }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
    ) {
        // ═══════════════════════════════════════════════════════
        // TOP BAR — back + path + voice + settings
        // ═══════════════════════════════════════════════════════
        AutomotiveTopBar(
            currentPath = currentPath,
            onBack = onBack,
            onVoiceSearch = onVoiceSearch,
            onSettings = onSettings,
            height = touchTargetHeight,
        )

        // ═══════════════════════════════════════════════════════
        // FILE LIST
        // ═══════════════════════════════════════════════════════
        Box(modifier = Modifier.weight(1f)) {
            if (filteredFiles.isEmpty()) {
                AutomotiveEmptyState(tab = activeTab)
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(
                        horizontal = SpacingTokens.Md,
                        vertical = SpacingTokens.Sm,
                    ),
                    verticalArrangement = Arrangement.spacedBy(SpacingTokens.Xs),
                ) {
                    items(filteredFiles.take(if (isDriving) 20 else Int.MAX_VALUE), key = { it.path }) { file ->
                        AutomotiveFileRow(
                            file = file,
                            touchTargetHeight = touchTargetHeight,
                            onClick = {
                                if (file.isDirectory) onFolderClick(file) else onFileClick(file)
                            },
                        )
                    }
                }
            }
        }

        // ═══════════════════════════════════════════════════════
        // BOTTOM TAB BAR — category quick-switch
        // ═══════════════════════════════════════════════════════
        AutomotiveTabBar(
            activeTab = activeTab,
            onTabSelected = onTabSelected,
            height = touchTargetHeight,
        )
    }
}

// ═══════════════════════════════════════════════════════════════
// AUTOMOTIVE TOP BAR
// ═══════════════════════════════════════════════════════════════

@Composable
private fun AutomotiveTopBar(
    currentPath: String,
    onBack: () -> Unit,
    onVoiceSearch: () -> Unit,
    onSettings: () -> Unit,
    height: Dp,
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .height(height),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = ElevationTokens.Level2,
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = SpacingTokens.Md),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.size(56.dp),
            ) {
                Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    modifier = Modifier.size(32.dp),
                )
            }
            Spacer(Modifier.width(SpacingTokens.Md))

            // Current path
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    Icons.Filled.Folder,
                    contentDescription = null,
                    modifier = Modifier.size(24.dp),
                    tint = MaterialTheme.colorScheme.primary,
                )
                Spacer(Modifier.width(SpacingTokens.Sm))
                Text(
                    text = currentPath,
                    style = MaterialTheme.typography.titleMedium.copy(fontSize = 18.sp),
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }

            // Voice search
            IconButton(
                onClick = onVoiceSearch,
                modifier = Modifier.size(56.dp),
            ) {
                Icon(
                    Icons.Filled.Search,
                    contentDescription = "Voice Search",
                    modifier = Modifier.size(32.dp),
                    tint = MaterialTheme.colorScheme.primary,
                )
            }
            // Settings
            IconButton(
                onClick = onSettings,
                modifier = Modifier.size(56.dp),
            ) {
                Icon(
                    Icons.Filled.Settings,
                    contentDescription = "Settings",
                    modifier = Modifier.size(28.dp),
                )
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// AUTOMOTIVE FILE ROW — large touch target
// ═══════════════════════════════════════════════════════════════

@Composable
private fun AutomotiveFileRow(
    file: FileItem,
    touchTargetHeight: Dp,
    onClick: () -> Unit,
) {
    val icon = if (file.isDirectory) FileTypeIcon.Folder
               else FileTypeIcon.fromPath(file.path)
    val showThumbnail = file.extension.lowercase() in THUMBNAIL_EXTENSIONS

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .height(touchTargetHeight)
            .bounceClick(onClick = onClick),
        shape = ShapeTokens.Medium,
        color = MaterialTheme.colorScheme.surfaceContainerLow,
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = SpacingTokens.Md, vertical = SpacingTokens.Xs),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            // Icon or thumbnail
            if (showThumbnail) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(ShapeTokens.Small),
                ) {
                    AsyncImage(
                        model = file.path,
                        contentDescription = file.name,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            } else {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clipToCircle()
                        .background(icon.color.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = icon.imageVector,
                        contentDescription = null,
                        modifier = Modifier.size(28.dp),
                        tint = icon.color,
                    )
                }
            }

            Spacer(Modifier.width(SpacingTokens.Md))

            // File info
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = file.name,
                    style = MaterialTheme.typography.bodyLarge.copy(fontSize = 18.sp),
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = if (file.isDirectory)
                        "${formatBytes(file.size)} • Folder"
                    else
                        "${formatBytes(file.size)} • ${file.extension.uppercase()}",
                    style = MaterialTheme.typography.bodyMedium.copy(fontSize = 14.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }

            // Bookmark indicator
            if (file.isBookmarked) {
                Icon(
                    Icons.Filled.Star,
                    contentDescription = "Bookmarked",
                    modifier = Modifier.size(24.dp),
                    tint = MaterialTheme.colorScheme.tertiary,
                )
                Spacer(Modifier.width(SpacingTokens.Sm))
            }

            // Play icon for media files
            if (file.extension.lowercase() in MEDIA_EXTS) {
                Icon(
                    Icons.Filled.PlayArrow,
                    contentDescription = "Play",
                    modifier = Modifier.size(28.dp),
                    tint = MaterialTheme.colorScheme.primary,
                )
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// AUTOMOTIVE TAB BAR
// ═══════════════════════════════════════════════════════════════

@Composable
private fun AutomotiveTabBar(
    activeTab: AutoTab,
    onTabSelected: (AutoTab) -> Unit,
    height: Dp,
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .height(height),
        color = MaterialTheme.colorScheme.surfaceContainer,
        shadowElevation = ElevationTokens.Level2,
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = SpacingTokens.Sm),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            AutoTab.entries.forEach { tab ->
                AutomotiveTabItem(
                    tab = tab,
                    isSelected = activeTab == tab,
                    onClick = { onTabSelected(tab) },
                )
            }
        }
    }
}

@Composable
private fun AutomotiveTabItem(
    tab: AutoTab,
    isSelected: Boolean,
    onClick: () -> Unit,
) {
    val backgroundColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer
                          else Color.Transparent
    val contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer
                       else MaterialTheme.colorScheme.onSurfaceVariant

    Surface(
        modifier = Modifier
            .height(56.dp)
            .bounceClick(onClick = onClick),
        color = backgroundColor,
        shape = ShapeTokens.Medium,
    ) {
        Column(
            modifier = Modifier.padding(horizontal = SpacingTokens.Md),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Icon(
                imageVector = tab.icon,
                contentDescription = tab.label,
                modifier = Modifier.size(28.dp),
                tint = contentColor,
            )
            Text(
                text = tab.label,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                color = contentColor,
                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                maxLines = 1,
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// AUTOMOTIVE EMPTY STATE
// ═══════════════════════════════════════════════════════════════

@Composable
private fun AutomotiveEmptyState(tab: AutoTab) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(SpacingTokens.Xxl),
        ) {
            Icon(
                imageVector = tab.icon,
                contentDescription = null,
                modifier = Modifier.size(96.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
            )
            Spacer(Modifier.height(SpacingTokens.Lg))
            Text(
                text = "No ${tab.label.lowercase()} found",
                style = MaterialTheme.typography.titleLarge.copy(fontSize = 22.sp),
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface,
            )
            Spacer(Modifier.height(SpacingTokens.Xs))
            Text(
                text = "Try a different tab or use voice search to find files",
                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 16.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// AUTOMOTIVE NOW PLAYING — for media playback overlay
// ═══════════════════════════════════════════════════════════════

/**
 * Automotive Now Playing card — shows current media playback status
 * with large play/pause/skip controls optimized for driving.
 *
 * @param title currently playing file name.
 * @param artist optional artist/subtitle (e.g., album name or folder path).
 * @param isPlaying current playback state.
 * @param onPlayPause toggle playback.
 * @param onSkipNext skip to next track.
 * @param onSkipPrevious skip to previous track.
 */
@Composable
fun AutomotiveNowPlayingCard(
    title: String,
    artist: String?,
    isPlaying: Boolean,
    onPlayPause: () -> Unit,
    onSkipNext: () -> Unit,
    onSkipPrevious: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .height(96.dp),
        color = MaterialTheme.colorScheme.primaryContainer,
        shape = ShapeTokens.Medium,
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = SpacingTokens.Md),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            // Album art placeholder
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clipToCircle()
                    .background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    Icons.Filled.MusicNote,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(32.dp),
                )
            }
            Spacer(Modifier.width(SpacingTokens.Md))

            // Title + artist
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(fontSize = 18.sp),
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (artist != null) {
                    Text(
                        text = artist,
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 14.sp),
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }

            // Skip previous
            IconButton(
                onClick = onSkipPrevious,
                modifier = Modifier.size(56.dp),
            ) {
                Icon(
                    Icons.Filled.SkipPrevious,
                    contentDescription = "Previous",
                    modifier = Modifier.size(36.dp),
                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                )
            }

            // Play/Pause
            Surface(
                modifier = Modifier
                    .size(64.dp)
                    .bounceClick(onClick = onPlayPause),
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primary,
            ) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Filled.Pause
                                      else Icons.Filled.PlayArrow,
                        contentDescription = if (isPlaying) "Pause" else "Play",
                        tint = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.size(40.dp),
                    )
                }
            }

            // Skip next
            IconButton(
                onClick = onSkipNext,
                modifier = Modifier.size(56.dp),
            ) {
                Icon(
                    Icons.Filled.SkipNext,
                    contentDescription = "Next",
                    modifier = Modifier.size(36.dp),
                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                )
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// DATA MODELS
// ═══════════════════════════════════════════════════════════════

/**
 * Automotive browser tabs — categories for quick file filtering.
 */
enum class AutoTab(
    val label: String,
    val icon: ImageVector,
) {
    ALL("All", Icons.Filled.Home),
    MUSIC("Music", Icons.Filled.MusicNote),
    PHOTOS("Photos", Icons.Filled.Image),
    VIDEOS("Videos", Icons.Filled.VideoFile),
    DOCS("Docs", Icons.Filled.Description),
    STARRED("Starred", Icons.Filled.Star),
}

// ═══════════════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════════════

private val AUDIO_EXTS = setOf("mp3", "wav", "flac", "ogg", "m4a", "aac", "opus")
private val IMAGE_EXTS = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic")
private val VIDEO_EXTS = setOf("mp4", "mkv", "avi", "mov", "webm", "3gp")
private val DOC_EXTS = setOf("pdf", "doc", "docx", "txt", "md", "rtf", "odt")

private val MEDIA_EXTS = AUDIO_EXTS + VIDEO_EXTS

private val THUMBNAIL_EXTENSIONS = IMAGE_EXTS + VIDEO_EXTS

private fun formatBytes(bytes: Long): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
    bytes < 1024 * 1024 * 1024 -> "%.1f MB".format(bytes / (1024.0 * 1024))
    else -> "%.2f GB".format(bytes / (1024.0 * 1024 * 1024))
}

package com.titan.filemanager.core.ui.splash.viewmodel

import android.content.Context
import android.content.pm.PackageManager
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.titan.filemanager.core.ui.contracts.PreferencesContract
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Splash Screen ViewModel.
 *
 * ═══════════════════════════════════════════════════════════
 * RESPONSIBILITIES
 * ═══════════════════════════════════════════════════════════
 *
 *  1. **Read app version info** — extracts versionName + versionCode from
 *     PackageManager for display on the splash screen.
 *
 *  2. **Check first-run flag** — reads `has_seen_onboarding` from DataStore
 *     (via [PreferencesContract]) to decide whether to show onboarding after splash.
 *
 *  3. **Check app lock enabled** — reads `app_lock_enabled` from DataStore
 *     (via [PreferencesContract]) to decide whether to show the lock screen after splash.
 *
 *  4. **Minimum display time** — ensures splash is visible for at least
 *     [MIN_DISPLAY_MS] before transitioning (prevents flash on fast devices).
 *
 *  5. **Background initialization** — triggers Hilt component initialization,
 *     database warmup, and cache preloading in parallel.
 *
 * ═══════════════════════════════════════════════════════════
 * STATE MACHINE
 * ═══════════════════════════════════════════════════════════
 *
 * ```
 * IDLE → INITIALIZING → READY
 * ```
 *
 * The UI observes [state] and calls [onComplete] when state becomes READY.
 */
@HiltViewModel
class SplashViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val preferences: PreferencesContract,
) : ViewModel() {

    companion object {
        /** Minimum time the splash screen is visible (ms). */
        const val MIN_DISPLAY_MS = 2000L
    }

    private val _state = MutableStateFlow(SplashUiState())
    val state: StateFlow<SplashUiState> = _state.asStateFlow()

    init {
        initialize()
    }

    /**
     * Initialize the app — read version info + flags + minimum delay.
     *
     * Called automatically on ViewModel creation. The UI should observe
     * [state] and transition when `isReady` becomes true.
     */
    private fun initialize() {
        viewModelScope.launch {
            _state.update { it.copy(isInitializing = true) }

            // ── Read version info ──
            val versionInfo = readVersionInfo()

            // ── Read first-run + lock flags from DataStore via PreferencesContract ──
            val hasSeenOnboarding = readHasSeenOnboarding()
            val isAppLockEnabled = readAppLockEnabled()

            // ── Minimum display time ──
            delay(MIN_DISPLAY_MS)

            // ── Ready ──
            _state.update {
                it.copy(
                    versionName = versionInfo.first,
                    versionCode = versionInfo.second,
                    hasSeenOnboarding = hasSeenOnboarding,
                    isAppLockEnabled = isAppLockEnabled,
                    isInitializing = false,
                    isReady = true,
                )
            }
        }
    }

    /** Read version name + code from PackageManager. */
    private fun readVersionInfo(): Pair<String, Int> {
        return try {
            val pm = context.packageManager
            val info = pm.getPackageInfo(context.packageName, 0)
            Pair(
                info.versionName ?: "unknown",
                if (android.os.Build.VERSION.SDK_INT >= 28) info.longVersionCode.toInt()
                else @Suppress("DEPRECATION") info.versionCode,
            )
        } catch (_: PackageManager.NameNotFoundException) {
            Pair("unknown", 0)
        }
    }

    /**
     * Read first-run flag from DataStore via [PreferencesContract].
     * Falls back to `false` (show onboarding) on any error.
     */
    private suspend fun readHasSeenOnboarding(): Boolean {
        return try {
            preferences.observeHasSeenOnboarding().first()
        } catch (_: Throwable) {
            false // Default: show onboarding on first run
        }
    }

    /**
     * Read app lock enabled flag from DataStore via [PreferencesContract].
     * Falls back to `false` (no app lock) on any error.
     */
    private suspend fun readAppLockEnabled(): Boolean {
        return try {
            preferences.observeIsAppLockEnabled().first()
        } catch (_: Throwable) {
            false // Default: no app lock
        }
    }

    /**
     * Mark onboarding as seen — called when onboarding completes.
     * Persists to DataStore via [PreferencesContract].
     */
    fun markOnboardingSeen() {
        viewModelScope.launch {
            try {
                preferences.setHasSeenOnboarding(true)
            } catch (_: Throwable) {
                // Best-effort write — UI still updates via state flow
            }
            _state.update { it.copy(hasSeenOnboarding = true) }
        }
    }
}

/**
 * Splash screen UI state.
 *
 * @param versionName App version name (e.g., "2.0.0")
 * @param versionCode App version code (e.g., 180)
 * @param hasSeenOnboarding Whether the user has completed onboarding
 * @param isAppLockEnabled Whether app lock is enabled
 * @param isInitializing Whether background initialization is running
 * @param isReady Whether the splash is ready to dismiss
 */
data class SplashUiState(
    val versionName: String = "2.0.0",
    val versionCode: Int = 180,
    val hasSeenOnboarding: Boolean = false,
    val isAppLockEnabled: Boolean = false,
    val isInitializing: Boolean = false,
    val isReady: Boolean = false,
)

package com.titan.filemanager.core.ui.storage

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.BrokenImage
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.SdCard
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.titan.filemanager.core.designsystem.component.TitanCard
import com.titan.filemanager.core.designsystem.modifier.slideOnAppear
import com.titan.filemanager.core.designsystem.tokens.ColorTokens
import com.titan.filemanager.core.designsystem.tokens.ElevationTokens
import com.titan.filemanager.core.designsystem.tokens.ShapeTokens
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

data class StorageDevice(
    val name: String,
    val path: String,
    val totalBytes: Long,
    val availableBytes: Long,
    val isRemovable: Boolean,
    val categoryBreakdown: List<StorageCategory>,
)

data class StorageCategory(
    val name: String,
    val bytes: Long,
    val color: Color,
    val icon: ImageVector,
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StorageOverviewScreen(
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    devices: List<StorageDevice> = getMockStorageDevices(),
) {
    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = { Text("Storage", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface),
            )
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(SpacingTokens.Md),
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.Sm),
        ) {
            items(devices.size) { index ->
                val device = devices[index]
                StorageDeviceCard(
                    device = device,
                    modifier = Modifier.slideOnAppear(index = index.coerceAtMost(10)),
                )
            }
        }
    }
}

@Composable
private fun StorageDeviceCard(
    device: StorageDevice,
    modifier: Modifier = Modifier,
) {
    TitanCard.Elevated(
        modifier = modifier.fillMaxWidth(),
        elevation = ElevationTokens.Level2,
    ) {
        Column(modifier = Modifier.padding(SpacingTokens.ContentPadding)) {
            // Device header
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    if (device.isRemovable) Icons.Filled.SdCard else Icons.Filled.Storage,
                    null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(28.dp),
                )
                Spacer(Modifier.size(SpacingTokens.Sm))
                Column(modifier = Modifier.weight(1f)) {
                    Text(device.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text(device.path, style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            Spacer(Modifier.height(SpacingTokens.Lg))

            // Donut chart + center text
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                DonutChart(
                    segments = device.categoryBreakdown.map { it.bytes.toFloat() to it.color },
                    total = device.totalBytes.toFloat(),
                    modifier = Modifier.size(160.dp),
                )

                Spacer(Modifier.size(SpacingTokens.Xl))

                // Center stats
                Column {
                    Text(
                        formatBytes(device.totalBytes - device.availableBytes),
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Text("used", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(SpacingTokens.Xs))
                    Text(
                        formatBytes(device.availableBytes),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.tertiary,
                    )
                    Text("free", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            Spacer(Modifier.height(SpacingTokens.Lg))

            // Category breakdown
            device.categoryBreakdown.forEach { category ->
                CategoryRow(category, device.totalBytes)
            }
        }
    }
}

@Composable
private fun DonutChart(
    segments: List<Pair<Float, Color>>,
    total: Float,
    modifier: Modifier = Modifier,
) {
    Canvas(modifier = modifier.aspectRatio(1f)) {
        val strokeWidth = 24.dp.toPx()
        val diameter = minOf(size.width, size.height) - strokeWidth
        val topLeft = Offset(
            (size.width - diameter) / 2f,
            (size.height - diameter) / 2f,
        )
        val arcSize = Size(diameter, diameter)

        var startAngle = -90f // Start from top
        val totalUsed = segments.sumOf { it.first.toDouble() }.toFloat()

        // Background ring
        drawArc(
            color = Color(0xFFE0E0E0),
            startAngle = 0f,
            sweepAngle = 360f,
            useCenter = false,
            topLeft = topLeft,
            size = arcSize,
            style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
        )

        // Segments
        for ((value, color) in segments) {
            if (value <= 0f) continue
            val sweepAngle = (value / total) * 360f
            drawArc(
                color = color,
                startAngle = startAngle,
                sweepAngle = sweepAngle,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
            )
            startAngle += sweepAngle
        }
    }
}

@Composable
private fun CategoryRow(category: StorageCategory, totalBytes: Long) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = SpacingTokens.Xs),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // Color dot
        Box(
            modifier = Modifier
                .size(12.dp)
                .background(category.color, ShapeTokens.Full),
        )
        Spacer(Modifier.size(SpacingTokens.Sm))
        Icon(category.icon, null, modifier = Modifier.size(18.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.size(SpacingTokens.Xs))
        Text(category.name, style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.weight(1f))
        Text(
            formatBytes(category.bytes),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.size(SpacingTokens.Sm))
        Text(
            "${(category.bytes.toFloat() / totalBytes * 100).toInt()}%",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

private fun formatBytes(bytes: Long): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
    bytes < 1024 * 1024 * 1024 -> "%.1f MB".format(bytes / (1024.0 * 1024))
    else -> "%.1f GB".format(bytes / (1024.0 * 1024 * 1024))
}

// ═══════════════════════════════════════════════════════════
// Mock data — replace with real StatFs data from ViewModel
// ═══════════════════════════════════════════════════════════

private fun getMockStorageDevices(): List<StorageDevice> = listOf(
    StorageDevice(
        name = "Internal Storage",
        path = "/storage/emulated/0",
        totalBytes = 128L * 1024 * 1024 * 1024,
        availableBytes = 64L * 1024 * 1024 * 1024,
        isRemovable = false,
        categoryBreakdown = listOf(
            StorageCategory("Images", 20L * 1024 * 1024 * 1024, ColorTokens.FileImage, Icons.Filled.Image),
            StorageCategory("Videos", 28L * 1024 * 1024 * 1024, ColorTokens.FileVideo, Icons.Filled.VideoFile),
            StorageCategory("Audio", 6L * 1024 * 1024 * 1024, ColorTokens.FileAudio, Icons.Filled.MusicNote),
            StorageCategory("Documents", 4L * 1024 * 1024 * 1024, ColorTokens.FileDocument, Icons.Filled.PictureAsPdf),
            StorageCategory("Apps", 3L * 1024 * 1024 * 1024, ColorTokens.FileApk, Icons.Filled.Memory),
            StorageCategory("Other", 3L * 1024 * 1024 * 1024, ColorTokens.FileGeneric, Icons.Filled.BrokenImage),
        ),
    ),
    StorageDevice(
        name = "SD Card",
        path = "/storage/SD_CARD",
        totalBytes = 64L * 1024 * 1024 * 1024,
        availableBytes = 42L * 1024 * 1024 * 1024,
        isRemovable = true,
        categoryBreakdown = listOf(
            StorageCategory("Images", 12L * 1024 * 1024 * 1024, ColorTokens.FileImage, Icons.Filled.Image),
            StorageCategory("Videos", 8L * 1024 * 1024 * 1024, ColorTokens.FileVideo, Icons.Filled.VideoFile),
            StorageCategory("Other", 2L * 1024 * 1024 * 1024, ColorTokens.FileGeneric, Icons.Filled.BrokenImage),
        ),
    ),
)

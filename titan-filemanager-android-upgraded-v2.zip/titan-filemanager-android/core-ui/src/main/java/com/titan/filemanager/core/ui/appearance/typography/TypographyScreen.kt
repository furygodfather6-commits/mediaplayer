package com.titan.filemanager.core.ui.appearance.typography

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.titan.filemanager.core.datastore.appearance.FontFamilyPref
import com.titan.filemanager.core.datastore.appearance.FontWeightPref
import com.titan.filemanager.core.datastore.appearance.TextTransform
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import com.titan.filemanager.core.ui.appearance.AdvancedAppearanceViewModel
import com.titan.filemanager.core.ui.appearance.SettingsHorizontalDivider
import com.titan.filemanager.core.ui.appearance.SettingsIntSlider
import com.titan.filemanager.core.ui.appearance.SettingsRadioGroup
import com.titan.filemanager.core.ui.appearance.SettingsSection
import com.titan.filemanager.core.ui.appearance.SettingsSlider
import com.titan.filemanager.core.ui.appearance.SettingsToggle

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TypographyScreen(
    onBack: () -> Unit,
    viewModel: AdvancedAppearanceViewModel = hiltViewModel(),
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val typo = settings.typography

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Typography", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()),
        ) {
            SettingsRadioGroup(
                title = "Font Family",
                options = FontFamilyPref.entries.map { it.label to it },
                selected = typo.fontFamily,
                onSelect = { v -> viewModel.updateTypography { it.copy(fontFamily = v) } },
            )
            SettingsHorizontalDivider()
            SettingsSlider(
                title = "Font Scale",
                value = typo.fontScale,
                range = 0.85f..2.0f,
                steps = 22,
                valueLabel = "${(typo.fontScale * 100).toInt()}%",
                onValueChange = { v -> viewModel.updateTypography { it.copy(fontScale = v) } },
            )
            SettingsHorizontalDivider()
            SettingsRadioGroup(
                title = "Headline Font Weight",
                options = FontWeightPref.entries.map { it.label to it },
                selected = typo.headlineWeight,
                onSelect = { v -> viewModel.updateTypography { it.copy(headlineWeight = v) } },
            )
            SettingsHorizontalDivider()
            SettingsRadioGroup(
                title = "Body Font Weight",
                options = FontWeightPref.entries.map { it.label to it },
                selected = typo.bodyWeight,
                onSelect = { v -> viewModel.updateTypography { it.copy(bodyWeight = v) } },
            )
            SettingsHorizontalDivider()
            SettingsSlider(
                title = "Label Letter Spacing",
                value = typo.labelLetterSpacing,
                range = -1.0f..2.0f,
                steps = 29,
                valueLabel = "${typo.labelLetterSpacing}sp",
                onValueChange = { v -> viewModel.updateTypography { it.copy(labelLetterSpacing = v) } },
            )
            SettingsHorizontalDivider()
            SettingsToggle(
                title = "Monospace for paths & code",
                subtitle = "Use monospace font for file paths and code previews",
                checked = typo.monospaceForPaths,
                onCheckedChange = { v -> viewModel.updateTypography { it.copy(monospaceForPaths = v) } },
            )
            SettingsToggle(title = "Font ligatures", checked = typo.ligatures,
                onCheckedChange = { v -> viewModel.updateTypography { it.copy(ligatures = v) } })
            SettingsToggle(title = "Kerning", checked = typo.kerning,
                onCheckedChange = { v -> viewModel.updateTypography { it.copy(kerning = v) } })
            SettingsHorizontalDivider()
            SettingsSlider(
                title = "Line Height Multiplier",
                value = typo.lineHeightMultiplier,
                range = 1.0f..2.0f,
                steps = 9,
                valueLabel = "${(typo.lineHeightMultiplier * 100).toInt()}%",
                onValueChange = { v -> viewModel.updateTypography { it.copy(lineHeightMultiplier = v) } },
            )
            SettingsIntSlider(
                title = "Max Line Length",
                value = typo.maxLineLength,
                range = 40..120,
                valueLabel = "${typo.maxLineLength} chars",
                onValueChange = { v -> viewModel.updateTypography { it.copy(maxLineLength = v) } },
            )
            SettingsHorizontalDivider()
            SettingsRadioGroup(
                title = "Label Text Transform",
                options = TextTransform.entries.map { it.label to it },
                selected = typo.labelTextTransform,
                onSelect = { v -> viewModel.updateTypography { it.copy(labelTextTransform = v) } },
            )
            Spacer(Modifier.height(SpacingTokens.Xxl))
        }
    }
}

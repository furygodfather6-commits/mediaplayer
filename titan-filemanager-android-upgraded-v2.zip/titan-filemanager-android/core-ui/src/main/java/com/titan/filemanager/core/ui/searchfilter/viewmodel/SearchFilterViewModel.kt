package com.titan.filemanager.core.ui.searchfilter.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.titan.filemanager.core.ui.searchfilter.DateRange
import com.titan.filemanager.core.ui.searchfilter.FileTypeFilter
import com.titan.filemanager.core.ui.searchfilter.SearchFilters
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SearchFilterViewModel @Inject constructor() : ViewModel() {

    private val _state = MutableStateFlow(SearchFilters())
    val state: StateFlow<SearchFilters> = _state.asStateFlow()

    fun updateQuery(query: String) {
        _state.update { it.copy(query = query) }
    }

    fun toggleFileType(type: FileTypeFilter) {
        _state.update {
            it.copy(fileTypes = if (type in it.fileTypes) it.fileTypes - type else it.fileTypes + type)
        }
    }

    fun updateSizeRange(min: Float, max: Float) {
        _state.update { it.copy(minSizeMb = min, maxSizeMb = max) }
    }

    fun setDateRange(range: DateRange) {
        _state.update { it.copy(dateRange = range) }
    }

    fun toggleCaseSensitive() { _state.update { it.copy(caseSensitive = !it.caseSensitive) } }
    fun toggleRegex() { _state.update { it.copy(useRegex = !it.useRegex) } }
    fun toggleContentSearch() { _state.update { it.copy(searchInContent = !it.searchInContent) } }
    fun toggleHidden() { _state.update { it.copy(includeHidden = !it.includeHidden) } }

    fun resetFilters() {
        _state.value = SearchFilters()
    }

    fun applyFilters(onApply: (SearchFilters) -> Unit) {
        viewModelScope.launch { onApply(_state.value) }
    }
}

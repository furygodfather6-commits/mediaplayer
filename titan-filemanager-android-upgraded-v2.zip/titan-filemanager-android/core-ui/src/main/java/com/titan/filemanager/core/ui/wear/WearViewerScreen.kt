package com.titan.filemanager.core.ui.wear

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BrokenImage
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.wear.compose.foundation.lazy.ScalingLazyColumn
import androidx.wear.compose.foundation.lazy.items
import androidx.wear.compose.foundation.lazy.rememberScalingLazyListState
import androidx.wear.compose.material.Chip
import androidx.wear.compose.material.ChipDefaults
import androidx.wear.compose.material.MaterialTheme
import androidx.wear.compose.material.PositionIndicator
import androidx.wear.compose.material.Scaffold
import androidx.wear.compose.material.Text
import coil.compose.AsyncImage
import com.titan.filemanager.core.designsystem.icon.FileTypeIcon
import com.titan.filemanager.core.model.file.FileItem

/**
 * ## WearViewerScreen
 *
 * Wear OS companion file viewer — designed for round 200×200 dp (or 390×390 px @ 2x) Wear OS
 * displays. Optimized for wrist-friendly interaction:
 *
 *  - Single-tap navigation
 *  - Large touch targets (min 48 dp)
 *  - High contrast text
 *  - Curved layout awareness (content stays inside circular bezel)
 *  - Voice input via Wear OS microphone
 *  - Reduced information density per screen
 *
 * ### Layout Anatomy (round display)
 * ```
 *         ╭────────────────────╮
 *        │   ╭──────────╮      │
 *       │   │  📁 Docs   │      │
 *       │   │  12 items  │      │
 *        │   ╰──────────╯      │
 *         │   ╭──────────╮     │
 *        │   │  📷 Photo  │      │
 *       │   │  2.4 MB    │      │
 *        │   ╰──────────╯      │
 *         ╭────────────────────╯
 *              ↕ scroll
 * ```
 *
 * ### Wear OS Specific Conventions
 *  - Uses `ScalingLazyColumn` from Wear Compose for centered scaling items
 *  - All touch targets ≥ 48 dp (Wear OS UI guidelines)
 *  - Text uses Wear Compose Material typography (slightly larger for wrist)
 *  - Position indicator auto-appears on scroll
 *
 * @param files list of files to display in the wear viewer.
 * @param onFileClick callback when a file is tapped.
 * @param onFileLongClick callback when a file is long-pressed (preview).
 */
@Composable
fun WearViewerScreen(
    files: List<FileItem>,
    onFileClick: (FileItem) -> Unit = {},
    onFileLongClick: (FileItem) -> Unit = {},
    modifier: Modifier = Modifier,
    title: String = "Titan Files",
) {
    val scalingLazyListState = rememberScalingLazyListState()

    Scaffold(
        modifier = modifier,
        positionIndicator = {
            PositionIndicator(scalingLazyListState = scalingLazyListState)
        },
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colors.background),
            contentAlignment = Alignment.Center,
        ) {
            ScalingLazyColumn(
                state = scalingLazyListState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(
                    horizontal = 16.dp,
                    vertical = 32.dp, // Extra top/bottom for round bezel
                ),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                // Header chip
                item {
                    WearHeaderChip(title = title, count = files.size)
                }
                // File chips
                items(files, key = { it.path }) { file ->
                    WearFileChip(
                        file = file,
                        onClick = { onFileClick(file) },
                        onLongClick = { onFileLongClick(file) },
                    )
                }
                // Footer chip
                if (files.isNotEmpty()) {
                    item {
                        WearFooterChip(totalBytes = files.sumOf { it.size })
                    }
                }
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// WEAR HEADER CHIP
// ═══════════════════════════════════════════════════════════════

@Composable
private fun WearHeaderChip(
    title: String,
    count: Int,
) {
    Chip(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp),
        onClick = { /* no-op */ },
        colors = ChipDefaults.primaryChipColors(),
        icon = {
            Icon(
                imageVector = Icons.Filled.Folder,
                contentDescription = null,
                modifier = Modifier.size(24.dp),
                tint = MaterialTheme.colors.onPrimary,
            )
        },
        label = {
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.title3,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = "$count items",
                    style = MaterialTheme.typography.caption2,
                    color = MaterialTheme.colors.onPrimary.copy(alpha = 0.8f),
                )
            }
        },
    )
}

// ═══════════════════════════════════════════════════════════════
// WEAR FILE CHIP
// ═══════════════════════════════════════════════════════════════

@Composable
private fun WearFileChip(
    file: FileItem,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
) {
    val icon = if (file.isDirectory) FileTypeIcon.Folder
               else FileTypeIcon.fromPath(file.path)
    val showThumbnail = file.extension.lowercase() in THUMBNAIL_EXTENSIONS

    Chip(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp)
            .pointerInput(file.path) {
                detectTapGestures(
                    onTap = { onClick() },
                    onLongPress = { onLongClick() },
                )
            },
        onClick = onClick,
        colors = ChipDefaults.secondaryChipColors(),
        icon = {
            if (showThumbnail) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(RoundedCornerShape(6.dp)),
                ) {
                    AsyncImage(
                        model = file.path,
                        contentDescription = file.name,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            } else {
                Icon(
                    imageVector = icon.imageVector,
                    contentDescription = null,
                    modifier = Modifier.size(28.dp),
                    tint = icon.color,
                )
            }
        },
        label = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = file.name,
                    style = MaterialTheme.typography.body1,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = formatBytes(file.size) + if (file.isDirectory) " • folder"
                                                       else " • ${file.extension.uppercase()}",
                    style = MaterialTheme.typography.caption2,
                    color = MaterialTheme.colors.onSurface.copy(alpha = 0.7f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        },
    )
}

// ═══════════════════════════════════════════════════════════════
// WEAR FOOTER CHIP — total size summary
// ═══════════════════════════════════════════════════════════════

@Composable
private fun WearFooterChip(totalBytes: Long) {
    Chip(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp),
        onClick = { /* no-op */ },
        colors = ChipDefaults.chipColors(
            backgroundColor = MaterialTheme.colors.surface,
            contentColor = MaterialTheme.colors.onSurface,
        ),
        icon = {
            Icon(
                imageVector = Icons.Filled.Storage,
                contentDescription = null,
                modifier = Modifier.size(24.dp),
                tint = MaterialTheme.colors.primary,
            )
        },
        label = {
            Column {
                Text(
                    text = "Total size",
                    style = MaterialTheme.typography.caption2,
                    color = MaterialTheme.colors.onSurface.copy(alpha = 0.7f),
                )
                Text(
                    text = formatBytes(totalBytes),
                    style = MaterialTheme.typography.title3,
                    fontWeight = FontWeight.Bold,
                )
            }
        },
    )
}

// ═══════════════════════════════════════════════════════════════
// WEAR PREVIEW OVERLAY — for long-press preview
// ═══════════════════════════════════════════════════════════════

/**
 * Wear OS preview overlay — full-screen file preview shown when a file is
 * long-pressed. Optimized for round display with circular-cropped thumbnails.
 *
 * @param file the file to preview.
 * @param onDismiss callback when user dismisses the preview.
 */
@Composable
fun WearPreviewOverlay(
    file: FileItem,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colors.background.copy(alpha = 0.95f))
            .pointerInput(Unit) {
                detectTapGestures(onTap = { onDismiss() })
            },
        contentAlignment = Alignment.Center,
    ) {
        val icon = if (file.isDirectory) FileTypeIcon.Folder
                   else FileTypeIcon.fromPath(file.path)
        val showThumbnail = file.extension.lowercase() in THUMBNAIL_EXTENSIONS

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(24.dp),
        ) {
            // Circular thumbnail / icon
            Box(
                modifier = Modifier
                    .size(120.dp)
                    .clip(CircleShape)
                    .background(
                        brush = Brush.radialGradient(
                            listOf(
                                MaterialTheme.colors.primary.copy(alpha = 0.3f),
                                MaterialTheme.colors.surface,
                            ),
                        ),
                    ),
                contentAlignment = Alignment.Center,
            ) {
                if (showThumbnail) {
                    AsyncImage(
                        model = file.path,
                        contentDescription = file.name,
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape),
                    )
                } else {
                    Icon(
                        imageVector = icon.imageVector,
                        contentDescription = null,
                        modifier = Modifier.size(64.dp),
                        tint = icon.color,
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            Text(
                text = file.name,
                style = MaterialTheme.typography.title3,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colors.onBackground,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
            )
            Text(
                text = formatBytes(file.size),
                style = MaterialTheme.typography.body2,
                color = MaterialTheme.colors.onBackground.copy(alpha = 0.7f),
            )

            Spacer(Modifier.height(8.dp))

            // Quick action chip
            Chip(
                onClick = { onDismiss() },
                colors = ChipDefaults.primaryChipColors(),
                label = {
                    Text(
                        text = "Tap to close",
                        style = MaterialTheme.typography.button,
                    )
                },
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// WEAR STORAGE DIAL — circular storage indicator
// ═══════════════════════════════════════════════════════════════

/**
 * Wear OS storage dial — circular progress indicator showing storage usage
 * with a percentage in the center.
 *
 * @param totalBytes total storage capacity.
 * @param usedBytes used storage.
 */
@Composable
fun WearStorageDial(
    totalBytes: Long,
    usedBytes: Long,
    modifier: Modifier = Modifier,
) {
    val usageFraction = if (totalBytes > 0) (usedBytes.toFloat() / totalBytes.toFloat()) else 0f
    val sweepAngle = usageFraction * 360f
    val primaryColor = MaterialTheme.colors.primary

    Box(
        modifier = modifier
            .size(160.dp)
            .padding(8.dp),
        contentAlignment = Alignment.Center,
    ) {
        // Background ring
        Canvas(modifier = Modifier.fillMaxSize()) {
            val stroke = 16.dp.toPx()
            drawCircle(
                color = Color.LightGray.copy(alpha = 0.3f),
                radius = (size.minDimension / 2) - (stroke / 2),
                style = Stroke(width = stroke),
            )
            // Used arc
            drawArc(
                color = primaryColor,
                startAngle = -90f,
                sweepAngle = sweepAngle,
                useCenter = false,
                style = Stroke(
                    width = stroke,
                    cap = StrokeCap.Round,
                ),
            )
        }

        // Center label
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                text = "${(usageFraction * 100).toInt()}%",
                style = MaterialTheme.typography.title1,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colors.primary,
            )
            Text(
                text = "used",
                style = MaterialTheme.typography.caption1,
                color = MaterialTheme.colors.onBackground.copy(alpha = 0.6f),
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = formatBytes(usedBytes) + " / " + formatBytes(totalBytes),
                style = MaterialTheme.typography.caption2,
                color = MaterialTheme.colors.onBackground.copy(alpha = 0.7f),
                maxLines = 1,
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════════════

private val THUMBNAIL_EXTENSIONS = setOf(
    "jpg", "jpeg", "png", "gif", "webp", "bmp", "heic",
    "mp4", "mkv", "avi", "mov", "webm",
)

private fun formatBytes(bytes: Long): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
    bytes < 1024 * 1024 * 1024 -> "%.1f MB".format(bytes / (1024.0 * 1024))
    else -> "%.2f GB".format(bytes / (1024.0 * 1024 * 1024))
}

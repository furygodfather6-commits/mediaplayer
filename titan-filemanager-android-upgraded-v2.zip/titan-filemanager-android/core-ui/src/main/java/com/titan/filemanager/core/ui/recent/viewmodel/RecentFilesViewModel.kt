package com.titan.filemanager.core.ui.recent.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.titan.filemanager.core.ui.contracts.RecentFilesContract
import com.titan.filemanager.core.ui.contracts.UiRecentFile
import com.titan.filemanager.core.ui.recent.RecentFileItem
import com.titan.filemanager.core.ui.recent.TimeRange
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * RecentFilesViewModel — manages recently-accessed files via [RecentFilesContract].
 *
 * Recent files are recorded every time the user opens a file. They persist
 * across app launches via Room database.
 */
@HiltViewModel
class RecentFilesViewModel @Inject constructor(
    private val recentFilesContract: RecentFilesContract,
) : ViewModel() {

    private val _state = MutableStateFlow(RecentFilesUiState())
    val state: StateFlow<RecentFilesUiState> = _state.asStateFlow()

    init {
        // Observe recent files reactively — UI updates automatically when DB changes
        recentFilesContract.observeRecent(limit = 100)
            .catch { e ->
                _state.update { it.copy(isLoading = false, error = e.message) }
            }
            .onEach { files ->
                _state.update {
                    it.copy(
                        files = files.map { it.toRecentFileItem() },
                        isLoading = false,
                        error = null,
                    )
                }
            }
            .launchIn(viewModelScope)
    }

    /**
     * Manually reload recent files (pull-to-refresh).
     */
    fun loadRecentFiles() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            try {
                val files = recentFilesContract.getRecent(limit = 100)
                _state.update {
                    it.copy(files = files.map { f -> f.toRecentFileItem() }, isLoading = false)
                }
            } catch (e: Exception) {
                _state.update { it.copy(isLoading = false, error = e.message) }
            }
        }
    }

    /**
     * Clear the entire recent-files history.
     * Persists via [RecentFilesContract.clearAll].
     */
    fun clearHistory() {
        viewModelScope.launch {
            try {
                recentFilesContract.clearAll()
                // Reactive observer will auto-update the UI
            } catch (e: Exception) {
                _state.update { it.copy(error = e.message) }
            }
        }
    }

    /**
     * Remove a single file from recent history.
     */
    fun removeRecent(path: String) {
        viewModelScope.launch {
            try {
                recentFilesContract.removeRecent(path)
                // Reactive observer will auto-update the UI
            } catch (e: Exception) {
                _state.update { it.copy(error = e.message) }
            }
        }
    }

    /**
     * Group recent files by time range for UI display.
     * Returns a map of [TimeRange] → list of files in that range.
     */
    fun groupByTimeRange(): Map<TimeRange, List<RecentFileItem>> {
        val now = System.currentTimeMillis()
        val todayStart = now - (now % (24 * 60 * 60 * 1000))
        val yesterdayStart = todayStart - (24 * 60 * 60 * 1000)
        val weekStart = todayStart - (7 * 24 * 60 * 60 * 1000)
        val monthStart = todayStart - (30L * 24 * 60 * 60 * 1000)

        return _state.value.files.groupBy { file ->
            when {
                file.modifiedAt >= todayStart -> TimeRange.TODAY
                file.modifiedAt >= weekStart -> TimeRange.WEEK
                file.modifiedAt >= monthStart -> TimeRange.MONTH
                else -> TimeRange.ALL
            }
        }
    }

    /**
     * Convert [UiRecentFile] (contract layer) to [RecentFileItem] (UI layer).
     */
    private fun UiRecentFile.toRecentFileItem(): RecentFileItem {
        return RecentFileItem(
            name = name,
            path = path,
            size = size,
            modifiedAt = modifiedAt,
            isDirectory = isDirectory,
        )
    }
}

data class RecentFilesUiState(
    val files: List<RecentFileItem> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null,
)

package com.titan.filemanager.core.ui.appearance.elevation

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.titan.filemanager.core.datastore.appearance.ElevationStyle
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import com.titan.filemanager.core.ui.appearance.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ElevationScreen(onBack: () -> Unit, viewModel: AdvancedAppearanceViewModel = hiltViewModel()) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val e = settings.elevation
    Scaffold(
        topBar = { TopAppBar(title = { Text("Elevation & Shadows", fontWeight = FontWeight.SemiBold) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }) },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())) {
            SettingsRadioGroup("Elevation Style", ElevationStyle.entries.map { it.label to it }, e.elevationStyle) { v ->
                viewModel.updateElevation { it.copy(elevationStyle = v) }
            }
            SettingsHorizontalDivider()
            SettingsIntSlider("Card Elevation", e.cardElevation, 0..12, "${e.cardElevation}dp") { v ->
                viewModel.updateElevation { it.copy(cardElevation = v) }
            }
            SettingsIntSlider("Dialog Elevation", e.dialogElevation, 0..12, "${e.dialogElevation}dp") { v ->
                viewModel.updateElevation { it.copy(dialogElevation = v) }
            }
            SettingsIntSlider("FAB Elevation", e.fabElevation, 0..12, "${e.fabElevation}dp") { v ->
                viewModel.updateElevation { it.copy(fabElevation = v) }
            }
            SettingsHorizontalDivider()
            SettingsIntSlider("Tonal Overlay Intensity", e.tonalOverlayIntensity, 0..100, "${e.tonalOverlayIntensity}%") { v ->
                viewModel.updateElevation { it.copy(tonalOverlayIntensity = v) }
            }
            SettingsHorizontalDivider()
            SettingsToggle("Colored shadows", "Tinted drop shadows that match the surface color",
                e.coloredShadows) { v -> viewModel.updateElevation { it.copy(coloredShadows = v) } }
            Spacer(Modifier.height(SpacingTokens.Xxl))
        }
    }
}

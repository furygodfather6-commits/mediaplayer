package com.titan.filemanager.core.ui.engine

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.titan.filemanager.core.datastore.engine.DuplicateLevel
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import com.titan.filemanager.core.ui.appearance.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnalyticsEngineScreen(onBack: () -> Unit, viewModel: AdvancedEngineViewModel = hiltViewModel()) {
    val s by viewModel.settings.collectAsStateWithLifecycle()
    val a = s.analytics
    Scaffold(topBar = { TopAppBar(title = { Text("Analytics", fontWeight = FontWeight.SemiBold) },
        navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())) {
            SettingsToggle("Enable storage analytics", "Track file sizes, types, and distributions", a.enableAnalytics) { v -> viewModel.updateAnalytics { it.copy(enableAnalytics = v) } }
            SettingsHorizontalDivider()
            SettingsIntSlider("Top Files Count", a.topFilesCount, 10..100, a.topFilesCount.toString()) { v -> viewModel.updateAnalytics { it.copy(topFilesCount = v) } }
            SettingsIntSlider("Top Folders Count", a.topFoldersCount, 5..50, a.topFoldersCount.toString()) { v -> viewModel.updateAnalytics { it.copy(topFoldersCount = v) } }
            SettingsHorizontalDivider()
            SettingsRadioGroup("Duplicate Detection Level", DuplicateLevel.entries.map { it.label to it }, a.duplicateDetectionLevel) { v -> viewModel.updateAnalytics { it.copy(duplicateDetectionLevel = v) } }
            SettingsHorizontalDivider()
            SettingsIntSlider("Partial Hash Threshold", a.partialHashThresholdKb, 4..256, "${a.partialHashThresholdKb} KB") { v -> viewModel.updateAnalytics { it.copy(partialHashThresholdKb = v) } }
            SettingsHorizontalDivider()
            SettingsToggle("Show analytics on home", "Display storage breakdown on home screen", a.showAnalyticsOnHome) { v -> viewModel.updateAnalytics { it.copy(showAnalyticsOnHome = v) } }
            Spacer(Modifier.height(SpacingTokens.Xxl))
        }
    }
}

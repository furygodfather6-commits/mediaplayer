package com.titan.filemanager.core.ui.preview

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.titan.filemanager.core.designsystem.icon.FileTypeIcon
import com.titan.filemanager.core.designsystem.modifier.clipToCircle
import com.titan.filemanager.core.designsystem.modifier.clipToRounded
import com.titan.filemanager.core.designsystem.tokens.ShapeTokens
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import com.titan.filemanager.core.model.file.FileItem
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * ## FilePreviewBottomSheet
 *
 * Enterprise-grade file preview bottom sheet — supports image, video, audio, PDF, text, and
 * unknown file types with appropriate previews. Includes swipe-through pager for image
 * galleries, pinch-to-zoom for images, video play/pause controls, audio transport controls,
 * PDF page navigation, and text content display with monospace font.
 *
 * ### Layout Anatomy
 * ```
 * ┌──────────────────────────────────────────┐
 * │  ──── drag handle ────                    │
 * │                                          │
 * │  ┌──────────────────────────────────┐    │
 * │  │                                  │    │
 * │  │     [Preview content area]       │    │
 * │  │       image / video /            │    │
 * │  │       pdf / text / icon          │    │
 * │  │                                  │    │
 * │  └──────────────────────────────────┘    │
 * │                                          │
 * │  filename.jpg          2.4 MB • 12:30   │
 * │  /storage/emulated/0/DCIM/Camera/...    │
 * │                                          │
 * │  ┌─────┬─────┬─────┬─────┐               │
 * │  │Info │Share│Copy │Open │               │
 * │  └─────┴─────┴─────┴─────┘               │
 * │                                          │
 * │  ←  3 of 12  →   • zoom • rotate         │
 * └──────────────────────────────────────────┘
 * ```
 *
 * ### Preview Mode Logic
 * The preview mode is determined by file extension:
 *  - Images (jpg, png, gif, webp, bmp, heic) → AsyncImage with pinch-zoom
 *  - Videos (mp4, mkv, avi, mov, webm) → Thumbnail + play button overlay
 *  - Audio (mp3, wav, flac, ogg, m4a) → Album-art placeholder + transport controls
 *  - PDF (pdf) → Page indicator + placeholder
 *  - Text (txt, md, json, xml, log, kt, java, py) → Scrolling text content
 *  - Other → File-type icon + size info
 *
 * ### Multi-file Gallery Mode
 * When [files] contains more than one entry, the preview becomes a swipeable pager:
 *  - Horizontal swipe navigates between files
 *  - Page indicator shows current index / total
 *  - Pinch-to-zoom applies per-page (reset on page change)
 *
 * @param files list of files to preview (single or gallery).
 * @param onDismiss callback when user dismisses the sheet.
 * @param modifier modifier for the root.
 * @param onOpen request to open the file in its dedicated viewer.
 * @param onShare request to share the file via system share sheet.
 * @param onCopyPath request to copy the file's absolute path to clipboard.
 * @param onShowInfo request to show the file properties sheet.
 * @param initialIndex when [files] has multiple entries, the index to start at.
 * @param textContent optional pre-loaded text content keyed by file path.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FilePreviewBottomSheet(
    files: List<FileItem>,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    onOpen: ((FileItem) -> Unit)? = null,
    onShare: ((FileItem) -> Unit)? = null,
    onCopyPath: ((FileItem) -> Unit)? = null,
    onShowInfo: ((FileItem) -> Unit)? = null,
    initialIndex: Int = 0,
    textContent: Map<String, String> = emptyMap(),
) {
    require(files.isNotEmpty()) { "FilePreviewBottomSheet requires at least one file" }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val pagerState = rememberPagerState(initialPage = initialIndex.coerceIn(0, files.lastIndex)) {
        files.size
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        modifier = modifier,
        shape = ShapeTokens.ExtraLarge,
        dragHandle = { TitanPreviewDragHandle() },
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = SpacingTokens.Xxl),
        ) {
            // ═══════════════════════════════════════════════════════
            // PAGER — swipe through multiple files
            // ═══════════════════════════════════════════════════════
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = SpacingTokens.ScreenHorizontal),
            ) {
                if (files.size == 1) {
                    PreviewPage(
                        file = files.first(),
                        textContent = textContent[files.first().path],
                        modifier = Modifier.fillMaxWidth(),
                    )
                } else {
                    HorizontalPager(
                        state = pagerState,
                        modifier = Modifier.fillMaxWidth(),
                        pageSpacing = SpacingTokens.Lg,
                    ) { page ->
                        PreviewPage(
                            file = files[page],
                            textContent = textContent[files[page].path],
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
            }

            Spacer(Modifier.height(SpacingTokens.Lg))

            // ═══════════════════════════════════════════════════════
            // FILE METADATA STRIP
            // ═══════════════════════════════════════════════════════
            val currentFile = files[pagerState.currentPage.coerceAtMost(files.lastIndex)]
            FileMetadataStrip(file = currentFile)

            Spacer(Modifier.height(SpacingTokens.Lg))

            // ═══════════════════════════════════════════════════════
            // ACTION BAR — info / share / copy / open
            // ═══════════════════════════════════════════════════════
            PreviewActionBar(
                file = currentFile,
                onOpen = onOpen,
                onShare = onShare,
                onCopyPath = onCopyPath,
                onShowInfo = onShowInfo,
            )

            // ═══════════════════════════════════════════════════════
            // GALLERY NAVIGATION (multi-file only)
            // ═══════════════════════════════════════════════════════
            if (files.size > 1) {
                Spacer(Modifier.height(SpacingTokens.Md))
                GalleryNavBar(
                    currentIndex = pagerState.currentPage,
                    totalCount = files.size,
                    onPrevious = { /* caller-vm driven via pagerState */ },
                    onNext = { /* caller-vm driven via pagerState */ },
                )
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// PREVIEW PAGE — single-file preview area
// ═══════════════════════════════════════════════════════════════

/**
 * Renders the preview for a single file based on its detected type.
 * Dispatches to [ImagePreview], [VideoPreview], [AudioPreview], [PdfPreview],
 * [TextPreview], or [GenericFilePreview].
 */
@Composable
private fun PreviewPage(
    file: FileItem,
    textContent: String?,
    modifier: Modifier = Modifier,
) {
    val previewType = PreviewType.fromFile(file)
    Box(
        modifier = modifier
            .clip(ShapeTokens.Large)
            .background(MaterialTheme.colorScheme.surfaceContainerHigh),
        contentAlignment = Alignment.Center,
    ) {
        when (previewType) {
            PreviewType.IMAGE -> ImagePreview(file = file)
            PreviewType.VIDEO -> VideoPreview(file = file)
            PreviewType.AUDIO -> AudioPreview(file = file)
            PreviewType.PDF -> PdfPreview(file = file)
            PreviewType.TEXT -> TextPreview(file = file, content = textContent)
            PreviewType.GENERIC -> GenericFilePreview(file = file)
        }
    }
}

/**
 * Image preview with pinch-to-zoom and pan gestures. Uses Coil AsyncImage
 * for memory-cached loading. Scale is clamped between 0.5x and 5x.
 */
@Composable
private fun ImagePreview(file: FileItem) {
    var scale by remember(file.path) { mutableFloatStateOf(1f) }
    var offsetX by remember(file.path) { mutableFloatStateOf(0f) }
    var offsetY by remember(file.path) { mutableFloatStateOf(0f) }
    val context = LocalContext.current

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .pointerInput(file.path) {
                detectTransformGestures { _, pan, zoom, _ ->
                    val newScale = (scale * zoom).coerceIn(0.5f, 5f)
                    scale = newScale
                    if (newScale > 1f) {
                        offsetX += pan.x
                        offsetY += pan.y
                    } else {
                        offsetX = 0f
                        offsetY = 0f
                    }
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        AsyncImage(
            model = ImageRequest.Builder(context)
                .data(file.path)
                .crossfade(true)
                .build(),
            contentDescription = file.name,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer(
                    scaleX = scale,
                    scaleY = scale,
                    translationX = offsetX,
                    translationY = offsetY,
                ),
        )
        // Zoom indicator
        if (scale > 1.05f) {
            Surface(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(SpacingTokens.Sm),
                shape = CircleShape,
                color = Color.Black.copy(alpha = 0.6f),
            ) {
                Text(
                    text = "${(scale * 100).toInt()}%",
                    modifier = Modifier.padding(horizontal = SpacingTokens.Sm, vertical = SpacingTokens.Xs),
                    color = Color.White,
                    style = MaterialTheme.typography.labelSmall,
                )
            }
        }
    }
}

/**
 * Video preview — shows thumbnail with play button overlay. Tapping play
 * toggles between play and pause icon states (full playback handled by caller).
 */
@Composable
private fun VideoPreview(file: FileItem) {
    var isPlaying by remember { mutableStateOf(false) }
    val context = LocalContext.current

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(16f / 9f),
        contentAlignment = Alignment.Center,
    ) {
        // Background thumbnail (first frame)
        AsyncImage(
            model = ImageRequest.Builder(context)
                .data(file.path)
                .crossfade(true)
                .build(),
            contentDescription = file.name,
            modifier = Modifier.fillMaxSize(),
        )

        // Dark scrim for play button visibility
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.35f)),
        )

        // Center play/pause button
        FilledIconButton(
            onClick = { isPlaying = !isPlaying },
            modifier = Modifier.size(56.dp),
            shape = CircleShape,
            colors = IconButtonDefaults.filledIconButtonColors(
                containerColor = Color.White.copy(alpha = 0.9f),
            ),
        ) {
            Icon(
                imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                contentDescription = if (isPlaying) "Pause" else "Play",
                tint = Color.Black,
                modifier = Modifier.size(32.dp),
            )
        }

        // File info overlay
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(SpacingTokens.Md),
        ) {
            Text(
                text = file.name,
                style = MaterialTheme.typography.labelLarge,
                color = Color.White,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = formatBytes(file.size) + " • Video",
                style = MaterialTheme.typography.labelSmall,
                color = Color.White.copy(alpha = 0.8f),
            )
        }
    }
}

/**
 * Audio preview — album-art placeholder with gradient + transport controls
 * (previous / play-pause / next) and a mock waveform.
 */
@Composable
private fun AudioPreview(file: FileItem) {
    var isPlaying by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(SpacingTokens.Xl),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        // Album-art placeholder
        Box(
            modifier = Modifier
                .size(120.dp)
                .clipToCircle()
                .background(
                    brush = Brush.linearGradient(
                        listOf(
                            MaterialTheme.colorScheme.primaryContainer,
                            MaterialTheme.colorScheme.tertiaryContainer,
                        ),
                    ),
                ),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = Icons.Filled.MusicNote,
                contentDescription = null,
                modifier = Modifier.size(56.dp),
                tint = MaterialTheme.colorScheme.onPrimaryContainer,
            )
        }

        Spacer(Modifier.height(SpacingTokens.Lg))

        Text(
            text = file.name,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Text(
            text = formatBytes(file.size) + " • Audio file",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Spacer(Modifier.height(SpacingTokens.Lg))

        // Mock waveform
        WaveformPlaceholder(isPlaying = isPlaying)

        Spacer(Modifier.height(SpacingTokens.Lg))

        // Transport controls
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(SpacingTokens.Lg),
        ) {
            IconButton(onClick = { /* previous track */ }) {
                Icon(Icons.Filled.SkipPrevious, "Previous", modifier = Modifier.size(36.dp))
            }
            FilledIconButton(
                onClick = { isPlaying = !isPlaying },
                modifier = Modifier.size(56.dp),
                shape = CircleShape,
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = if (isPlaying) "Pause" else "Play",
                    modifier = Modifier.size(32.dp),
                )
            }
            IconButton(onClick = { /* next track */ }) {
                Icon(Icons.Filled.SkipNext, "Next", modifier = Modifier.size(36.dp))
            }
        }
    }
}

/**
 * Animated mock waveform — bars rise and fall when playing.
 */
@Composable
private fun WaveformPlaceholder(isPlaying: Boolean) {
    val barCount = 32
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .padding(horizontal = SpacingTokens.Lg),
        horizontalArrangement = Arrangement.spacedBy(2.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        repeat(barCount) { i ->
            val baseHeight = (0.2f + (i % 7) * 0.12f).coerceIn(0.2f, 1f)
            val animatedHeight = if (isPlaying) baseHeight else baseHeight * 0.4f
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height((48f * animatedHeight).dp)
                    .clipToRounded(1.5.dp)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.7f)),
            )
        }
    }
}

/**
 * PDF preview — page placeholder with page indicator.
 */
@Composable
private fun PdfPreview(file: FileItem) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(0.75f),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = Icons.Filled.PictureAsPdf,
                contentDescription = null,
                modifier = Modifier.size(72.dp),
                tint = MaterialTheme.colorScheme.error,
            )
            Spacer(Modifier.height(SpacingTokens.Md))
            Text(
                text = file.name,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
            )
            Text(
                text = formatBytes(file.size) + " • PDF Document",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(SpacingTokens.Sm))
            Surface(
                shape = ShapeTokens.Small,
                color = MaterialTheme.colorScheme.secondaryContainer,
            ) {
                Text(
                    text = "Tap to open in viewer",
                    modifier = Modifier.padding(horizontal = SpacingTokens.Md, vertical = SpacingTokens.Xs),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                )
            }
        }
    }
}

/**
 * Text/code preview — monospace text in a scrollable column.
 */
@Composable
private fun TextPreview(file: FileItem, content: String?) {
    val scrollState = rememberScrollState()
    val displayContent = content ?: "// Loading preview...\n// File: ${file.name}"

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .height(280.dp)
            .padding(SpacingTokens.Md),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = Icons.Filled.TextFields,
                contentDescription = null,
                modifier = Modifier.size(20.dp),
                tint = MaterialTheme.colorScheme.primary,
            )
            Spacer(Modifier.width(SpacingTokens.Sm))
            Text(
                text = "${file.extension.uppercase()} Preview",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold,
            )
            Spacer(Modifier.weight(1f))
            Text(
                text = "${displayContent.lines().size} lines",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Spacer(Modifier.height(SpacingTokens.Sm))
        HorizontalDivider()
        Spacer(Modifier.height(SpacingTokens.Sm))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .verticalScroll(scrollState),
        ) {
            Text(
                text = displayContent,
                style = MaterialTheme.typography.bodySmall.copy(
                    fontFamily = FontFamily.Monospace,
                    lineHeight = 18.sp,
                ),
                color = MaterialTheme.colorScheme.onSurface,
            )
        }
    }
}

/**
 * Generic file preview — falls back to type icon + filename.
 */
@Composable
private fun GenericFilePreview(file: FileItem) {
    val icon = if (file.isDirectory) FileTypeIcon.Folder else FileTypeIcon.fromPath(file.path)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(SpacingTokens.Xl),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(
            imageVector = icon.imageVector,
            contentDescription = null,
            modifier = Modifier.size(96.dp),
            tint = icon.color,
        )
        Spacer(Modifier.height(SpacingTokens.Lg))
        Text(
            text = file.name,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
        )
        Text(
            text = formatBytes(file.size) +
                if (file.extension.isNotEmpty()) " • ${file.extension.uppercase()}" else "",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

// ═══════════════════════════════════════════════════════════════
// SUPPORTING COMPONENTS
// ═══════════════════════════════════════════════════════════════

@Composable
private fun TitanPreviewDragHandle() {
    Surface(
        modifier = Modifier.padding(vertical = SpacingTokens.Sm),
        color = MaterialTheme.colorScheme.outlineVariant,
        shape = ShapeTokens.Full,
    ) {
        Box(Modifier.width(32.dp).height(4.dp))
    }
}

@Composable
private fun FileMetadataStrip(file: FileItem) {
    val dateFormat = remember { SimpleDateFormat("MMM dd, yyyy 'at' HH:mm", Locale.getDefault()) }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = SpacingTokens.ScreenHorizontal),
    ) {
        Text(
            text = file.name,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Spacer(Modifier.height(SpacingTokens.Xxs))
        Text(
            text = file.path,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Spacer(Modifier.height(SpacingTokens.Xs))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(SpacingTokens.Md),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            MetadataChip(
                icon = Icons.Filled.Storage,
                label = formatBytes(file.size),
            )
            MetadataChip(
                icon = Icons.Filled.Schedule,
                label = dateFormat.format(Date(file.modifiedAt)),
            )
            val mt = file.mimeType
            if (mt != null) {
                MetadataChip(
                    icon = Icons.Filled.Info,
                    label = mt,
                )
            }
        }
    }
}

@Composable
private fun MetadataChip(
    icon: ImageVector,
    label: String,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(ShapeTokens.Small)
            .background(MaterialTheme.colorScheme.surfaceContainerHigh)
            .padding(horizontal = SpacingTokens.Sm, vertical = SpacingTokens.Xs),
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            modifier = Modifier.size(14.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.width(SpacingTokens.Xs))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun PreviewActionBar(
    file: FileItem,
    onOpen: ((FileItem) -> Unit)?,
    onShare: ((FileItem) -> Unit)?,
    onCopyPath: ((FileItem) -> Unit)?,
    onShowInfo: ((FileItem) -> Unit)?,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = SpacingTokens.ScreenHorizontal),
        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.Sm),
    ) {
        PreviewActionButton(
            icon = Icons.Filled.Info,
            label = "Info",
            onClick = { onShowInfo?.invoke(file) },
            modifier = Modifier.weight(1f),
        )
        PreviewActionButton(
            icon = Icons.Filled.Share,
            label = "Share",
            onClick = { onShare?.invoke(file) },
            modifier = Modifier.weight(1f),
        )
        PreviewActionButton(
            icon = Icons.Filled.ContentCopy,
            label = "Copy Path",
            onClick = { onCopyPath?.invoke(file) },
            modifier = Modifier.weight(1f),
        )
        PreviewActionButton(
            icon = Icons.Filled.Description,
            label = "Open",
            onClick = { onOpen?.invoke(file) },
            modifier = Modifier.weight(1f),
            primary = true,
        )
    }
}

@Composable
private fun PreviewActionButton(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    primary: Boolean = false,
) {
    val containerColor = if (primary) {
        MaterialTheme.colorScheme.primaryContainer
    } else {
        MaterialTheme.colorScheme.surfaceContainerHigh
    }
    val contentColor = if (primary) {
        MaterialTheme.colorScheme.onPrimaryContainer
    } else {
        MaterialTheme.colorScheme.onSurface
    }
    Column(
        modifier = modifier
            .clip(ShapeTokens.Medium)
            .background(containerColor)
            .padding(vertical = SpacingTokens.Sm),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        IconButton(onClick = onClick) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = contentColor,
            )
        }
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = contentColor,
        )
    }
}

@Composable
private fun GalleryNavBar(
    currentIndex: Int,
    totalCount: Int,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = SpacingTokens.ScreenHorizontal),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        IconButton(onClick = onPrevious, enabled = currentIndex > 0) {
            Icon(Icons.Filled.SkipPrevious, "Previous")
        }
        Surface(
            shape = ShapeTokens.Full,
            color = MaterialTheme.colorScheme.secondaryContainer,
        ) {
            Text(
                text = "${currentIndex + 1} / $totalCount",
                modifier = Modifier.padding(horizontal = SpacingTokens.Lg, vertical = SpacingTokens.Xs),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSecondaryContainer,
                fontWeight = FontWeight.SemiBold,
            )
        }
        IconButton(onClick = onNext, enabled = currentIndex < totalCount - 1) {
            Icon(Icons.Filled.SkipNext, "Next")
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════════════

/**
 * Categorizes a file into a preview type based on its extension.
 */
private enum class PreviewType {
    IMAGE, VIDEO, AUDIO, PDF, TEXT, GENERIC;

    companion object {
        private val IMAGE_EXTS = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif")
        private val VIDEO_EXTS = setOf("mp4", "mkv", "avi", "mov", "webm", "3gp", "flv")
        private val AUDIO_EXTS = setOf("mp3", "wav", "flac", "ogg", "m4a", "aac", "opus")
        private val TEXT_EXTS = setOf(
            "txt", "md", "json", "xml", "log", "kt", "java", "py", "c", "cpp",
            "h", "hpp", "js", "ts", "html", "css", "yaml", "yml", "toml", "ini",
            "sh", "bat", "ps1", "rb", "go", "rs", "swift", "sql", "csv",
        )

        fun fromFile(file: FileItem): PreviewType {
            if (file.isDirectory) return GENERIC
            val ext = file.extension.lowercase()
            return when (ext) {
                in IMAGE_EXTS -> IMAGE
                in VIDEO_EXTS -> VIDEO
                in AUDIO_EXTS -> AUDIO
                "pdf" -> PDF
                in TEXT_EXTS -> TEXT
                else -> GENERIC
            }
        }
    }
}

private fun formatBytes(bytes: Long): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
    bytes < 1024 * 1024 * 1024 -> "%.1f MB".format(bytes / (1024.0 * 1024))
    else -> "%.2f GB".format(bytes / (1024.0 * 1024 * 1024))
}

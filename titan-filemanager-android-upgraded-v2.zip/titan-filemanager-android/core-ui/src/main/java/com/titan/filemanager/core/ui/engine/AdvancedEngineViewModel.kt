package com.titan.filemanager.core.ui.engine

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.titan.filemanager.core.datastore.engine.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AdvancedEngineViewModel @Inject constructor(
    private val repo: EngineSettingsRepository,
) : ViewModel() {

    val settings: StateFlow<EngineSettings> = repo.settings.stateIn(
        scope = viewModelScope, started = SharingStarted.WhileSubscribed(5000L),
        initialValue = EngineSettings(),
    )

    fun updateScan(block: (ScanEngineSettings) -> ScanEngineSettings) = viewModelScope.launch { repo.updateScan(block) }
    fun updateCache(block: (CacheEngineSettings) -> CacheEngineSettings) = viewModelScope.launch { repo.updateCache(block) }
    fun updateSearch(block: (SearchEngineSettings) -> SearchEngineSettings) = viewModelScope.launch { repo.updateSearch(block) }
    fun updateThumbnail(block: (ThumbnailEngineSettings) -> ThumbnailEngineSettings) = viewModelScope.launch { repo.updateThumbnail(block) }
    fun updateTrash(block: (TrashSettings) -> TrashSettings) = viewModelScope.launch { repo.updateTrash(block) }
    fun updateAnalytics(block: (AnalyticsSettings) -> AnalyticsSettings) = viewModelScope.launch { repo.updateAnalytics(block) }
    fun updateAi(block: (AiSettings) -> AiSettings) = viewModelScope.launch { repo.updateAi(block) }
    fun resetAll() = viewModelScope.launch { repo.resetAll() }
}

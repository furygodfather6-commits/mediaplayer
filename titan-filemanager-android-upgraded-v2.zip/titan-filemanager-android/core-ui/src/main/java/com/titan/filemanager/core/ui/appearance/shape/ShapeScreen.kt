package com.titan.filemanager.core.ui.appearance.shape

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.titan.filemanager.core.datastore.appearance.ButtonShape
import com.titan.filemanager.core.datastore.appearance.ShapeStyle
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import com.titan.filemanager.core.ui.appearance.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShapeScreen(onBack: () -> Unit, viewModel: AdvancedAppearanceViewModel = hiltViewModel()) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val shape = settings.shape
    Scaffold(
        topBar = { TopAppBar(title = { Text("Shape & Corners", fontWeight = FontWeight.SemiBold) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }) },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())) {
            SettingsRadioGroup("Shape Style", ShapeStyle.entries.map { it.label to it }, shape.shapeStyle) { v ->
                viewModel.updateShape { it.copy(shapeStyle = v) }
            }
            SettingsHorizontalDivider()
            SettingsIntSlider("Global Corner Radius Override", shape.globalCornerRadius ?: -1, -1..48,
                if (shape.globalCornerRadius == null) "Use preset" else "${shape.globalCornerRadius}dp") { v ->
                viewModel.updateShape { it.copy(globalCornerRadius = if (v < 0) null else v) }
            }
            SettingsIntSlider("Card Corner Radius", shape.cardCornerRadius ?: -1, -1..32,
                if (shape.cardCornerRadius == null) "Follow style" else "${shape.cardCornerRadius}dp") { v ->
                viewModel.updateShape { it.copy(cardCornerRadius = if (v < 0) null else v) }
            }
            SettingsIntSlider("Dialog Corner Radius", shape.dialogCornerRadius ?: -1, -1..32,
                if (shape.dialogCornerRadius == null) "Follow style" else "${shape.dialogCornerRadius}dp") { v ->
                viewModel.updateShape { it.copy(dialogCornerRadius = if (v < 0) null else v) }
            }
            SettingsIntSlider("Bottom Sheet Corner Radius", shape.sheetCornerRadius ?: -1, -1..32,
                if (shape.sheetCornerRadius == null) "Follow style" else "${shape.sheetCornerRadius}dp") { v ->
                viewModel.updateShape { it.copy(sheetCornerRadius = if (v < 0) null else v) }
            }
            SettingsHorizontalDivider()
            SettingsRadioGroup("Button Shape", ButtonShape.entries.map { it.label to it }, shape.buttonShape) { v ->
                viewModel.updateShape { it.copy(buttonShape = v) }
            }
            SettingsHorizontalDivider()
            SettingsIntSlider("Thumbnail Corner Radius", shape.thumbnailCornerRadius, 0..24,
                "${shape.thumbnailCornerRadius}dp") { v -> viewModel.updateShape { it.copy(thumbnailCornerRadius = v) } }
            SettingsHorizontalDivider()
            SettingsToggle("Asymmetric shapes", "Use top-only rounding for sheets and bottom bars",
                shape.asymmetricShapes) { v -> viewModel.updateShape { it.copy(asymmetricShapes = v) } }
            Spacer(Modifier.height(SpacingTokens.Xxl))
        }
    }
}

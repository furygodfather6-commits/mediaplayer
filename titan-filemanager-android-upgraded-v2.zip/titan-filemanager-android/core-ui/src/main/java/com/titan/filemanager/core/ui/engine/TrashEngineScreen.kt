package com.titan.filemanager.core.ui.engine

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.titan.filemanager.core.datastore.engine.TrashSchedule
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import com.titan.filemanager.core.ui.appearance.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrashEngineScreen(onBack: () -> Unit, viewModel: AdvancedEngineViewModel = hiltViewModel()) {
    val s by viewModel.settings.collectAsStateWithLifecycle()
    val t = s.trash
    Scaffold(topBar = { TopAppBar(title = { Text("Trash & Deletion", fontWeight = FontWeight.SemiBold) },
        navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())) {
            SettingsIntSlider("Retention Period", t.retentionDays, 7..90, "${t.retentionDays} days") { v -> viewModel.updateTrash { it.copy(retentionDays = v) } }
            SettingsHorizontalDivider()
            SettingsToggle("Auto-empty trash", "Automatically purge expired entries", t.autoEmptyTrash) { v -> viewModel.updateTrash { it.copy(autoEmptyTrash = v) } }
            if (t.autoEmptyTrash) {
                SettingsRadioGroup("Auto-empty Schedule", TrashSchedule.entries.map { it.label to it }, t.autoEmptySchedule) { v -> viewModel.updateTrash { it.copy(autoEmptySchedule = v) } }
            }
            SettingsHorizontalDivider()
            SettingsToggle("Confirm before delete", "Show dialog when moving to trash", t.confirmBeforeDelete) { v -> viewModel.updateTrash { it.copy(confirmBeforeDelete = v) } }
            SettingsToggle("Confirm permanent delete", "Show dialog before permanent deletion", t.confirmBeforePermanentDelete) { v -> viewModel.updateTrash { it.copy(confirmBeforePermanentDelete = v) } }
            SettingsHorizontalDivider()
            SettingsToggle("Secure file deletion", "Overwrite file contents before deleting (slower)", t.secureFileDeletion) { v -> viewModel.updateTrash { it.copy(secureFileDeletion = v) } }
            Spacer(Modifier.height(SpacingTokens.Xxl))
        }
    }
}

package com.titan.filemanager.core.ui.backup

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.titan.filemanager.core.designsystem.tokens.ShapeTokens
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupSettingsScreen(
    onBack: () -> Unit,
    onNavigateToBackup: () -> Unit,
    onNavigateToArchive: () -> Unit,
    viewModel: AdvancedBackupViewModel = hiltViewModel(),
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    Scaffold(
        topBar = { TopAppBar(title = { Text("Backup & Archive", fontWeight = FontWeight.SemiBold) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
            actions = { IconButton(onClick = { viewModel.resetAll() }) { Icon(Icons.Filled.Restore, "Reset") } }) },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(SpacingTokens.Md),
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.Sm)) {
            Text("Configure automatic backups, archive formats, compression, and encryption",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = SpacingTokens.Lg, vertical = SpacingTokens.Xs))
            Spacer(Modifier.height(SpacingTokens.Sm))
            BackupCategoryCard(Icons.Filled.Backup, "Backup & Restore", "Auto-backup, interval, destination, encryption, rotation",
                if (settings.backup.autoBackup) "On" else "Off", onNavigateToBackup)
            BackupCategoryCard(Icons.Filled.FolderZip, "Archive & Compression", "Default format, compression level, password, split volumes",
                settings.archive.defaultArchiveFormat.label, onNavigateToArchive)
            Spacer(Modifier.height(SpacingTokens.Xl))
            Text("14 configurable settings across 2 categories",
                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = SpacingTokens.Lg))
        }
    }
}

@Composable
private fun BackupCategoryCard(icon: ImageVector, title: String, subtitle: String, badge: String, onClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick), shape = ShapeTokens.Medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
        Row(modifier = Modifier.fillMaxWidth().padding(SpacingTokens.Lg), verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(44.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) {
                Icon(icon, null, modifier = Modifier.size(24.dp), tint = MaterialTheme.colorScheme.onPrimaryContainer)
            }
            Spacer(Modifier.width(SpacingTokens.Md))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
            }
            Surface(shape = ShapeTokens.Full, color = MaterialTheme.colorScheme.secondaryContainer) {
                Text(badge, modifier = Modifier.padding(horizontal = SpacingTokens.Sm, vertical = 2.dp),
                    style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSecondaryContainer)
            }
            Spacer(Modifier.width(SpacingTokens.Xs))
            Icon(Icons.AutoMirrored.Filled.ArrowForwardIos, null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

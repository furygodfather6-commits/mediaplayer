package com.titan.filemanager.core.ui.searchfilter

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material.icons.filled.Numbers
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.FlowRow
import com.titan.filemanager.core.designsystem.component.TitanCard
import com.titan.filemanager.core.designsystem.icon.FileTypeIcon
import com.titan.filemanager.core.designsystem.tokens.ColorTokens
import com.titan.filemanager.core.designsystem.tokens.ElevationTokens
import com.titan.filemanager.core.designsystem.tokens.ShapeTokens
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens

data class SearchFilters(
    val query: String = "",
    val fileTypes: Set<FileTypeFilter> = emptySet(),
    val minSizeMb: Float = 0f,
    val maxSizeMb: Float = 1024f,
    val dateRange: DateRange = DateRange.ANY,
    val caseSensitive: Boolean = false,
    val useRegex: Boolean = false,
    val searchInContent: Boolean = false,
    val includeHidden: Boolean = false,
)

enum class FileTypeFilter(val label: String, val color: androidx.compose.ui.graphics.Color) {
    IMAGE("Images", ColorTokens.FileImage),
    VIDEO("Videos", ColorTokens.FileVideo),
    AUDIO("Audio", ColorTokens.FileAudio),
    DOCUMENT("Documents", ColorTokens.FileDocument),
    ARCHIVE("Archives", ColorTokens.FileArchive),
    CODE("Code", ColorTokens.FileCode),
    APK("APK", ColorTokens.FileApk),
}

enum class DateRange(val label: String) {
    ANY("Any time"),
    TODAY("Today"),
    WEEK("Past 7 days"),
    MONTH("Past 30 days"),
    YEAR("Past year"),
}

/**
 * Advanced Search Filter Screen — full-featured filter panel.
 *
 * Sections:
 *  1. Query input — search text with regex/case-sensitive toggles
 *  2. File types — multi-select chip group
 *  3. Size range — dual-thumb slider (0 MB – 1 GB+)
 *  4. Date range — chip group (Any/Today/Week/Month/Year)
 *  5. Options — switches (content search, hidden files)
 *
 * Usage:
 * ```
 * var showFilters by remember { mutableStateOf(false) }
 * if (showFilters) {
 *     SearchFilterScreen(
 *         initialFilters = currentFilters,
 *         onApply = { filters -> viewModel.applyFilters(filters); showFilters = false },
 *         onBack = { showFilters = false },
 *     )
 * }
 * ```
 */
@OptIn(ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun SearchFilterScreen(
    onApply: (SearchFilters) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    initialFilters: SearchFilters = SearchFilters(),
) {
    var query by remember { mutableStateOf(initialFilters.query) }
    var selectedTypes by remember { mutableStateOf(initialFilters.fileTypes) }
    var minSize by remember { mutableFloatStateOf(initialFilters.minSizeMb) }
    var maxSize by remember { mutableFloatStateOf(initialFilters.maxSizeMb) }
    var dateRange by remember { mutableStateOf(initialFilters.dateRange) }
    var caseSensitive by remember { mutableStateOf(initialFilters.caseSensitive) }
    var useRegex by remember { mutableStateOf(initialFilters.useRegex) }
    var searchInContent by remember { mutableStateOf(initialFilters.searchInContent) }
    var includeHidden by remember { mutableStateOf(initialFilters.includeHidden) }

    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = { Text("Search Filters", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                actions = {
                    TextButton(onClick = {
                        query = ""
                        selectedTypes = emptySet()
                        minSize = 0f
                        maxSize = 1024f
                        dateRange = DateRange.ANY
                        caseSensitive = false
                        useRegex = false
                        searchInContent = false
                        includeHidden = false
                    }) { Text("Reset") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface),
            )
        },
        bottomBar = {
            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(defaultElevation = ElevationTokens.Level3),
                shape = ShapeTokens.None,
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(SpacingTokens.ContentPadding),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    TextButton(onClick = onBack) { Text("Cancel") }
                    Button(onClick = {
                        onApply(SearchFilters(
                            query = query,
                            fileTypes = selectedTypes,
                            minSizeMb = minSize,
                            maxSizeMb = maxSize,
                            dateRange = dateRange,
                            caseSensitive = caseSensitive,
                            useRegex = useRegex,
                            searchInContent = searchInContent,
                            includeHidden = includeHidden,
                        ))
                    }) {
                        Icon(Icons.Filled.Search, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.size(SpacingTokens.Xs))
                        Text("Search")
                    }
                }
            }
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(padding)
                .padding(horizontal = SpacingTokens.ScreenHorizontal)
                .padding(bottom = SpacingTokens.Xxl),
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.Md),
        ) {
            // ═══════════════════════════════════════════════════════
            // QUERY INPUT
            // ═══════════════════════════════════════════════════════
            FilterSection("Search Query", Icons.Filled.Search) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Enter search text...") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { query = "" }) {
                                Icon(Icons.Filled.Close, "Clear", modifier = Modifier.size(18.dp))
                            }
                        }
                    },
                )
                Spacer(Modifier.height(SpacingTokens.Sm))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(SpacingTokens.Xs),
                ) {
                    FilterChip(
                        selected = caseSensitive,
                        onClick = { caseSensitive = !caseSensitive },
                        label = { Text("Aa") },
                        leadingIcon = { Icon(Icons.Filled.TextFields, null, modifier = Modifier.size(16.dp)) },
                    )
                    FilterChip(
                        selected = useRegex,
                        onClick = { useRegex = !useRegex },
                        label = { Text("Regex") },
                        leadingIcon = { Icon(Icons.Filled.Numbers, null, modifier = Modifier.size(16.dp)) },
                    )
                }
            }

            // ═══════════════════════════════════════════════════════
            // FILE TYPES
            // ═══════════════════════════════════════════════════════
            FilterSection("File Types", Icons.Filled.FilterAlt) {
                androidx.compose.foundation.layout.FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(SpacingTokens.Xs),
                ) {
                    FileTypeFilter.entries.forEach { type ->
                        FilterChip(
                            selected = type in selectedTypes,
                            onClick = {
                                selectedTypes = if (type in selectedTypes) {
                                    selectedTypes - type
                                } else {
                                    selectedTypes + type
                                }
                            },
                            label = { Text(type.label) },
                        )
                    }
                }
            }

            // ═══════════════════════════════════════════════════════
            // SIZE RANGE
            // ═══════════════════════════════════════════════════════
            FilterSection("File Size", Icons.Filled.Numbers) {
                Text(
                    "${formatMb(minSize)} — ${formatMb(maxSize)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                RangeSlider(
                    value = minSize..maxSize,
                    onValueChange = { minSize = it.start; maxSize = it.endInclusive },
                    valueRange = 0f..1024f,
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            // ═══════════════════════════════════════════════════════
            // DATE RANGE
            // ═══════════════════════════════════════════════════════
            FilterSection("Date Modified", Icons.Filled.CalendarMonth) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(SpacingTokens.Xs),
                ) {
                    DateRange.entries.forEach { range ->
                        FilterChip(
                            selected = dateRange == range,
                            onClick = { dateRange = range },
                            label = { Text(range.label) },
                        )
                    }
                }
            }

            // ═══════════════════════════════════════════════════════
            // OPTIONS
            // ═══════════════════════════════════════════════════════
            FilterSection("Options", Icons.Filled.Check) {
                ToggleRow("Search in file content", "Search inside text files", searchInContent) { searchInContent = it }
                ToggleRow("Include hidden files", "Show files starting with a dot", includeHidden) { includeHidden = it }
            }
        }
    }
}

@Composable
private fun FilterSection(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    content: @Composable () -> Unit,
) {
    TitanCard.Elevated(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(SpacingTokens.ContentPadding)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                Spacer(Modifier.size(SpacingTokens.Sm))
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(SpacingTokens.Sm))
            content()
        }
    }
}

@Composable
private fun ToggleRow(title: String, subtitle: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = SpacingTokens.Xs),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

private fun formatMb(mb: Float): String = when {
    mb >= 1024f -> "%.0f GB".format(mb / 1024f)
    mb >= 1f -> "%.0f MB".format(mb)
    else -> "0 MB"
}


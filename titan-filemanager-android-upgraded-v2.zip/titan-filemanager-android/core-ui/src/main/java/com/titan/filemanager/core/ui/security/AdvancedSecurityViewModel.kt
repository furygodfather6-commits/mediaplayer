package com.titan.filemanager.core.ui.security

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.titan.filemanager.core.datastore.security.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AdvancedSecurityViewModel @Inject constructor(
    private val repo: SecuritySettingsRepository,
) : ViewModel() {

    val settings: StateFlow<SecuritySettings> = repo.settings.stateIn(
        scope = viewModelScope, started = SharingStarted.WhileSubscribed(5000L),
        initialValue = SecuritySettings(),
    )

    fun updateVault(block: (VaultSettings) -> VaultSettings) = viewModelScope.launch { repo.updateVault(block) }
    fun updateCloud(block: (CloudSyncSettings) -> CloudSyncSettings) = viewModelScope.launch { repo.updateCloud(block) }
    fun updateNotifications(block: (NotificationSettings) -> NotificationSettings) = viewModelScope.launch { repo.updateNotifications(block) }
    fun resetAll() = viewModelScope.launch { repo.resetAll() }
}

package com.titan.filemanager.core.ui.cloud

import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.titan.filemanager.core.designsystem.component.TitanCard
import com.titan.filemanager.core.designsystem.modifier.clipToCircle
import com.titan.filemanager.core.designsystem.modifier.neonGlow
import com.titan.filemanager.core.designsystem.tokens.ColorTokens
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign

/**
 * Cloud Authentication Screen — OAuth flow for cloud providers.
 *
 * Flow:
 *  1. Shows provider branding + security message
 *  2. "Connect" button opens WebView with OAuth URL
 *  3. WebView loads provider's OAuth page (Google/Dropbox/OneDrive)
 *  4. On redirect callback → extracts auth code → calls [onAuthSuccess]
 *  5. On cancel → calls [onBack]
 *
 * Usage:
 * ```
 * CloudAuthScreen(
 *     providerName = "Google Drive",
 *     providerColor = Color(0xFF4285F4),
 *     authUrl = "https://accounts.google.com/oauth/authorize?...",
 *     redirectUrl = "titanfilemanager://oauth/callback",
 *     onAuthSuccess = { authCode -> viewModel.exchangeCode(authCode) },
 *     onBack = { navController.popBackStack() },
 * )
 * ```
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CloudAuthScreen(
    providerName: String,
    authUrl: String,
    redirectUrl: String,
    onAuthSuccess: (String) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    providerColor: Color = Color(0xFF4285F4),
    providerIcon: androidx.compose.ui.graphics.vector.ImageVector = Icons.Filled.Cloud,
) {
    var showWebView by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }

    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = { Text("Connect $providerName", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface),
            )
        },
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            if (showWebView) {
                // OAuth WebView
                Column(modifier = Modifier.fillMaxSize()) {
                    if (isLoading) {
                        androidx.compose.material3.LinearProgressIndicator(
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                    AndroidView(
                        factory = { ctx ->
                            WebView(ctx).apply {
                                settings.javaScriptEnabled = true
                                webViewClient = object : WebViewClient() {
                                    override fun onPageStarted(
                                        view: WebView?,
                                        url: String?,
                                        favicon: android.graphics.Bitmap?,
                                    ) {
                                        isLoading = true
                                        // Check for redirect
                                        url?.let { currentUrl ->
                                            if (currentUrl.startsWith(redirectUrl)) {
                                                val authCode = currentUrl.substringAfter("code=", "")
                                                    .substringBefore("&")
                                                if (authCode.isNotEmpty()) {
                                                    onAuthSuccess(authCode)
                                                }
                                            }
                                        }
                                    }

                                    override fun onPageFinished(view: WebView?, url: String?) {
                                        isLoading = false
                                    }
                                }
                                loadUrl(authUrl)
                            }
                        },
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            } else {
                // Pre-connect screen
                Column(
                    modifier = Modifier.fillMaxSize().padding(SpacingTokens.Xxl),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    // Provider icon with neon glow
                    Icon(
                        providerIcon,
                        null,
                        modifier = Modifier
                            .size(80.dp)
                            .clipToCircle()
                            .neonGlow(providerColor, 25.dp),
                        tint = providerColor,
                    )

                    androidx.compose.foundation.layout.Spacer(
                        Modifier.size(SpacingTokens.Lg),
                    )

                    Text(
                        "Connect to $providerName",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                    )

                    androidx.compose.foundation.layout.Spacer(
                        Modifier.size(SpacingTokens.Xs),
                    )

                    Text(
                        "Securely link your $providerName account\nto sync and browse cloud files",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    )

                    androidx.compose.foundation.layout.Spacer(
                        Modifier.size(SpacingTokens.Xxl),
                    )

                    // Security info card
                    TitanCard.Outlined(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(SpacingTokens.ContentPadding)) {
                            SecurityRow("OAuth 2.0 authentication — we never see your password")
                            SecurityRow("Access is revocable anytime from provider settings")
                            SecurityRow("Files are encrypted in transit (TLS 1.3)")
                        }
                    }

                    androidx.compose.foundation.layout.Spacer(
                        Modifier.size(SpacingTokens.Xl),
                    )

                    // Connect button
                    androidx.compose.material3.Button(
                        onClick = { showWebView = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = com.titan.filemanager.core.designsystem.tokens.ShapeTokens.Full,
                        colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                            containerColor = providerColor,
                        ),
                    ) {
                        Icon(Icons.Filled.CloudDone, null, modifier = Modifier.size(18.dp))
                        androidx.compose.foundation.layout.Spacer(Modifier.size(SpacingTokens.Xs))
                        Text("Connect with $providerName", fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

@Composable
private fun SecurityRow(text: String) {
    androidx.compose.foundation.layout.Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = SpacingTokens.Xs),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            Icons.Filled.Security,
            null,
            tint = MaterialTheme.colorScheme.tertiary,
            modifier = Modifier.size(18.dp),
        )
        androidx.compose.foundation.layout.Spacer(Modifier.size(SpacingTokens.Sm))
        Text(text, style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}


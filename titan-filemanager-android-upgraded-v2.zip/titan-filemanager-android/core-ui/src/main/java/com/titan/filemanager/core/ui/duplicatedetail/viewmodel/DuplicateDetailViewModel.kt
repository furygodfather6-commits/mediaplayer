package com.titan.filemanager.core.ui.duplicatedetail.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.titan.filemanager.core.ui.contracts.DuplicatesContract
import com.titan.filemanager.core.ui.contracts.UiDuplicateFile
import com.titan.filemanager.core.ui.duplicatedetail.DuplicateFile
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * DuplicateDetailViewModel — manages duplicate file groups via [DuplicatesContract].
 *
 * Loads all files in a duplicate group, supports marking one as "keep" and
 * deleting the rest. Deletion is hash-verified to prevent data loss.
 */
@HiltViewModel
class DuplicateDetailViewModel @Inject constructor(
    private val duplicatesContract: DuplicatesContract,
) : ViewModel() {

    private val _state = MutableStateFlow(DuplicateDetailUiState())
    val state: StateFlow<DuplicateDetailUiState> = _state.asStateFlow()

    /**
     * Load duplicate files for a specific group.
     * @param groupId The group ID from the duplicates scan.
     */
    fun loadDuplicates(groupId: String) {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            try {
                val files = duplicatesContract.getDuplicateGroup(groupId)
                _state.update {
                    it.copy(files = files.map { f -> f.toDuplicateFile() }, isLoading = false)
                }
            } catch (e: Exception) {
                _state.update { it.copy(isLoading = false, error = e.message) }
            }
        }
    }

    /**
     * Delete a specific duplicate file.
     * Verifies content hash before deletion to prevent accidental data loss.
     * Delegates hash verification to [DuplicatesContract.deleteFile].
     */
    fun deleteFile(path: String) {
        viewModelScope.launch {
            _state.update { it.copy(isDeleting = true) }
            try {
                val expectedHash = _state.value.files.find { it.path == path }?.contentHash
                    ?: throw IllegalStateException("File not in current group")

                val deleted = duplicatesContract.deleteFile(path, expectedHash)
                if (deleted) {
                    _state.update {
                        it.copy(
                            files = it.files.filter { f -> f.path != path },
                            isDeleting = false,
                            deletedPaths = it.deletedPaths + path,
                        )
                    }
                } else {
                    _state.update {
                        it.copy(
                            isDeleting = false,
                            error = "Content hash mismatch — refusing to delete (file may have changed)",
                        )
                    }
                }
            } catch (e: Exception) {
                _state.update { it.copy(isDeleting = false, error = e.message) }
            }
        }
    }

    /**
     * Mark a file as the one to keep.
     * The duplicate scanner will skip this file in future scans.
     */
    fun keepFile(path: String) {
        viewModelScope.launch {
            try {
                duplicatesContract.markAsKept(path)
                _state.update { it.copy(keptPath = path) }
            } catch (e: Exception) {
                _state.update { it.copy(error = e.message) }
            }
        }
    }

    /**
     * Delete all files in the group EXCEPT the kept one.
     * Convenience method for "keep this, delete the rest" workflow.
     */
    fun deleteAllExceptKept() {
        val keptPath = _state.value.keptPath ?: return
        val toDelete = _state.value.files.filter { it.path != keptPath }
        toDelete.forEach { file ->
            deleteFile(file.path)
        }
    }

    /**
     * Convert [UiDuplicateFile] (contract layer) to [DuplicateFile] (UI layer).
     */
    private fun UiDuplicateFile.toDuplicateFile(): DuplicateFile {
        return DuplicateFile(
            name = name,
            path = path,
            size = size,
            modifiedAt = modifiedAt,
            contentHash = contentHash,
        )
    }
}

data class DuplicateDetailUiState(
    val files: List<DuplicateFile> = emptyList(),
    val isLoading: Boolean = false,
    val isDeleting: Boolean = false,
    val error: String? = null,
    val keptPath: String? = null,
    val deletedPaths: Set<String> = emptySet(),
)

package com.titan.filemanager.core.ui.settingsstorage

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Cached
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.ManageSearch
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.titan.filemanager.core.designsystem.component.TitanCard
import com.titan.filemanager.core.designsystem.component.TitanFileInfoRow
import com.titan.filemanager.core.designsystem.modifier.bounceClick
import com.titan.filemanager.core.designsystem.tokens.ColorTokens
import com.titan.filemanager.core.designsystem.tokens.ElevationTokens
import com.titan.filemanager.core.designsystem.tokens.ShapeTokens
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens

data class CacheInfo(
    val thumbnailCacheBytes: Long,
    val searchIndexBytes: Long,
    val databaseBytes: Long,
    val tempFilesBytes: Long,
    val logFilesBytes: Long,
    val totalAppBytes: Long,
    val totalCacheBytes: Long,
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsStorageScreen(
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    cacheInfo: CacheInfo = getMockCacheInfo(),
    onClearThumbnails: () -> Unit = {},
    onClearSearchIndex: () -> Unit = {},
    onClearDatabase: () -> Unit = {},
    onClearTempFiles: () -> Unit = {},
    onClearLogs: () -> Unit = {},
    onClearAll: () -> Unit = {},
) {
    var pendingAction by remember { mutableStateOf<ClearAction?>(null) }

    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = { Text("Storage & Cache", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface),
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(SpacingTokens.Md),
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.Sm),
        ) {
            // ═══════════════════════════════════════════════════════
            // APP SIZE OVERVIEW
            // ═══════════════════════════════════════════════════════
            TitanCard.Elevated(modifier = Modifier.fillMaxWidth(), elevation = ElevationTokens.Level2) {
                Column(modifier = Modifier.padding(SpacingTokens.ContentPadding)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Storage, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.size(SpacingTokens.Sm))
                        Text("App Storage Usage", style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold)
                    }
                    Spacer(Modifier.height(SpacingTokens.Md))

                    val cachePercent = cacheInfo.totalCacheBytes.toFloat() / cacheInfo.totalAppBytes.toFloat()

                    LinearProgressIndicator(
                        progress = { cachePercent },
                        modifier = Modifier.fillMaxWidth().height(8.dp),
                    )
                    Spacer(Modifier.height(SpacingTokens.Xs))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Cache: ${formatBytes(cacheInfo.totalCacheBytes)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("Total: ${formatBytes(cacheInfo.totalAppBytes)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            // ═══════════════════════════════════════════════════════
            // CACHE BREAKDOWN
            // ═══════════════════════════════════════════════════════
            TitanCard.Elevated(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(SpacingTokens.ContentPadding)) {
                    Text("Cache Breakdown", style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(SpacingTokens.Sm))

                    CacheRow(
                        icon = Icons.Filled.Image,
                        title = "Thumbnails",
                        subtitle = "Generated image/video previews",
                        sizeBytes = cacheInfo.thumbnailCacheBytes,
                        color = ColorTokens.FileImage,
                        onClear = { pendingAction = ClearAction.THUMBNAILS },
                    )
                    HorizontalDivider()
                    CacheRow(
                        icon = Icons.Filled.ManageSearch,
                        title = "Search Index",
                        subtitle = "Trie + Bloom + FTS index database",
                        sizeBytes = cacheInfo.searchIndexBytes,
                        color = ColorTokens.FileCode,
                        onClear = { pendingAction = ClearAction.SEARCH_INDEX },
                    )
                    HorizontalDivider()
                    CacheRow(
                        icon = Icons.Filled.Storage,
                        title = "Metadata Database",
                        subtitle = "File metadata + vault entries",
                        sizeBytes = cacheInfo.databaseBytes,
                        color = ColorTokens.FileDocument,
                        onClear = { pendingAction = ClearAction.DATABASE },
                    )
                    HorizontalDivider()
                    CacheRow(
                        icon = Icons.Filled.Cached,
                        title = "Temporary Files",
                        subtitle = "Extraction temp, transfer buffer",
                        sizeBytes = cacheInfo.tempFilesBytes,
                        color = ColorTokens.FileArchive,
                        onClear = { pendingAction = ClearAction.TEMP },
                    )
                    HorizontalDivider()
                    CacheRow(
                        icon = Icons.Filled.DeleteSweep,
                        title = "Log Files",
                        subtitle = "Debug logs + crash reports",
                        sizeBytes = cacheInfo.logFilesBytes,
                        color = ColorTokens.FileGeneric,
                        onClear = { pendingAction = ClearAction.LOGS },
                    )
                }
            }

            // ═══════════════════════════════════════════════════════
            // CLEAR ALL
            // ═══════════════════════════════════════════════════════
            Button(
                onClick = { pendingAction = ClearAction.ALL },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                shape = ShapeTokens.Full,
            ) {
                Icon(Icons.Filled.DeleteSweep, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.size(SpacingTokens.Xs))
                Text("Clear All Cache (${formatBytes(cacheInfo.totalCacheBytes)})",
                    fontWeight = FontWeight.SemiBold)
            }
        }
    }

    // Confirmation dialog
    pendingAction?.let { action ->
        AlertDialog(
            onDismissRequest = { pendingAction = null },
            title = { Text(action.title) },
            text = { Text(action.message) },
            confirmButton = {
                TextButton(onClick = {
                    when (action) {
                        ClearAction.THUMBNAILS -> onClearThumbnails()
                        ClearAction.SEARCH_INDEX -> onClearSearchIndex()
                        ClearAction.DATABASE -> onClearDatabase()
                        ClearAction.TEMP -> onClearTempFiles()
                        ClearAction.LOGS -> onClearLogs()
                        ClearAction.ALL -> onClearAll()
                    }
                    pendingAction = null
                }) { Text("Clear", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { pendingAction = null }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun CacheRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    sizeBytes: Long,
    color: androidx.compose.ui.graphics.Color,
    onClear: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .bounceClick(onClick = { onClear() })
            .padding(vertical = SpacingTokens.Sm),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, modifier = Modifier.size(28.dp), tint = color)
        Spacer(Modifier.size(SpacingTokens.Md))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text(formatBytes(sizeBytes), style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.size(SpacingTokens.Sm))
        TextButton(onClick = onClear) { Text("Clear") }
    }
}

enum class ClearAction(val title: String, val message: String) {
    THUMBNAILS("Clear Thumbnails?", "All cached thumbnails will be deleted. They will be regenerated as needed."),
    SEARCH_INDEX("Clear Search Index?", "The entire search index (Trie, Bloom filter, FTS) will be cleared. Search will be slower until re-indexed."),
    DATABASE("Clear Metadata Database?", "All cached file metadata will be deleted. This does NOT affect vault entries."),
    TEMP("Clear Temp Files?", "All temporary files from extraction and transfers will be deleted."),
    LOGS("Clear Log Files?", "All debug logs and crash reports will be permanently deleted."),
    ALL("Clear All Cache?", "This will clear thumbnails, search index, temp files, and logs. Database and vault entries are preserved."),
}

private fun formatBytes(bytes: Long): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
    bytes < 1024 * 1024 * 1024 -> "%.1f MB".format(bytes / (1024.0 * 1024))
    else -> "%.1f GB".format(bytes / (1024.0 * 1024 * 1024))
}

private fun getMockCacheInfo() = CacheInfo(
    thumbnailCacheBytes = 45L * 1024 * 1024,
    searchIndexBytes = 28L * 1024 * 1024,
    databaseBytes = 12L * 1024 * 1024,
    tempFilesBytes = 8L * 1024 * 1024,
    logFilesBytes = 2L * 1024 * 1024,
    totalAppBytes = 180L * 1024 * 1024,
    totalCacheBytes = 95L * 1024 * 1024,
)

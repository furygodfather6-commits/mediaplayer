package com.titan.filemanager.core.ui.recent

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ClearAll
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.titan.filemanager.core.designsystem.component.EmptyState
import com.titan.filemanager.core.designsystem.component.TitanEmptyState
import com.titan.filemanager.core.designsystem.component.TitanFileTile
import com.titan.filemanager.core.designsystem.icon.FileTypeIcon
import com.titan.filemanager.core.designsystem.modifier.slideOnAppear
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class RecentFileItem(
    val name: String,
    val path: String,
    val size: Long,
    val modifiedAt: Long,
    val isDirectory: Boolean,
)

enum class TimeRange(val label: String, val days: Int) {
    TODAY("Today", 1),
    WEEK("7 days", 7),
    MONTH("30 days", 30),
    ALL("All time", 36500),
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecentFilesScreen(
    recentFiles: List<RecentFileItem>,
    onBack: () -> Unit,
    onFileClick: (String) -> Unit,
    onClearHistory: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var typeFilter by remember { mutableStateOf<TypeFilter?>(null) }

    val timeRange = TimeRange.entries[selectedTab]
    val now = System.currentTimeMillis()
    val cutoff = now - timeRange.days * 24 * 60 * 60 * 1000L

    val filtered = recentFiles
        .filter { it.modifiedAt >= cutoff }
        .filter { file ->
            typeFilter?.let { filter ->
                val ext = file.path.substringAfterLast(".", "").lowercase()
                ext in filter.extensions
            } ?: true
        }
        .sortedByDescending { it.modifiedAt }

    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = { Text("Recent Files", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                actions = {
                    if (recentFiles.isNotEmpty()) {
                        IconButton(onClick = onClearHistory) {
                            Icon(Icons.Filled.ClearAll, "Clear history")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface),
            )
        },
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            // Time range tabs
            TabRow(selectedTabIndex = selectedTab) {
                TimeRange.entries.forEachIndexed { index, range ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(range.label, maxLines = 1) },
                    )
                }
            }

            // Type filter chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = SpacingTokens.ScreenHorizontal, vertical = SpacingTokens.Xs),
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.Xs),
            ) {
                FilterChip(
                    selected = typeFilter == null,
                    onClick = { typeFilter = null },
                    label = { Text("All") },
                )
                TypeFilter.entries.forEach { filter ->
                    FilterChip(
                        selected = typeFilter == filter,
                        onClick = { typeFilter = if (typeFilter == filter) null else filter },
                        label = { Text(filter.label) },
                    )
                }
            }

            // File list
            if (filtered.isEmpty()) {
                TitanEmptyState(
                    icon = Icons.Filled.History,
                    title = "No recent files",
                    subtitle = "Files you open will appear here",
                )
            } else {
                // Date grouping
                val grouped = filtered.groupBy { getDateGroup(it.modifiedAt, now) }

                LazyColumn(
                    contentPadding = PaddingValues(bottom = SpacingTokens.Lg),
                    verticalArrangement = Arrangement.spacedBy(SpacingTokens.Xxs),
                ) {
                    var itemIndex = 0
                    grouped.forEach { (dateLabel, files) ->
                        item {
                            Text(
                                dateLabel,
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(
                                    start = SpacingTokens.ScreenHorizontal,
                                    top = SpacingTokens.Md,
                                    bottom = SpacingTokens.Xs,
                                ),
                            )
                        }
                        items(files.size) { idx ->
                            val file = files[idx]
                            TitanFileTile(
                                name = file.name,
                                isDirectory = file.isDirectory,
                                path = file.path,
                                size = formatBytes(file.size),
                                date = formatTime(file.modifiedAt),
                                onClick = { onFileClick(file.path) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .slideOnAppear(index = itemIndex.coerceAtMost(20)),
                            )
                            itemIndex++
                        }
                    }
                }
            }
        }
    }
}

enum class TypeFilter(val label: String, val extensions: Set<String>) {
    IMAGES("Images", setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic")),
    VIDEOS("Videos", setOf("mp4", "mkv", "avi", "mov", "webm", "3gp")),
    AUDIO("Audio", setOf("mp3", "flac", "aac", "ogg", "wav", "m4a")),
    DOCS("Docs", setOf("pdf", "doc", "docx", "txt", "md", "xls", "xlsx", "ppt", "pptx")),
    CODE("Code", setOf("kt", "java", "py", "js", "ts", "cpp", "c", "h", "xml", "json")),
}

private fun getDateGroup(timestamp: Long, now: Long): String {
    val today = SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date(now))
    val fileDate = SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date(timestamp))
    return when {
        fileDate == today -> "Today"
        fileDate.toLong() == today.toLong() - 1 -> "Yesterday"
        else -> SimpleDateFormat("MMM yyyy", Locale.getDefault()).format(Date(timestamp))
    }
}

private fun formatTime(timestamp: Long): String =
    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(timestamp))

private fun formatBytes(bytes: Long): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
    bytes < 1024 * 1024 * 1024 -> "%.1f MB".format(bytes / (1024.0 * 1024))
    else -> "%.1f GB".format(bytes / (1024.0 * 1024 * 1024))
}


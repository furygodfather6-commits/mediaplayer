package com.titan.filemanager.core.ui.bookmarks.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.titan.filemanager.core.ui.bookmarks.BookmarkItem
import com.titan.filemanager.core.ui.contracts.BookmarksContract
import com.titan.filemanager.core.ui.contracts.UiBookmark
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

/**
 * BookmarksViewModel — manages user bookmarks via [BookmarksContract].
 *
 * Bookmarks are quick-access shortcuts to frequently-used files/folders.
 * They persist across app launches via Room database.
 */
@HiltViewModel
class BookmarksViewModel @Inject constructor(
    private val bookmarksContract: BookmarksContract,
) : ViewModel() {

    private val _state = MutableStateFlow(BookmarksUiState())
    val state: StateFlow<BookmarksUiState> = _state.asStateFlow()

    init {
        // Observe bookmarks reactively — UI updates automatically when DB changes
        bookmarksContract.observeBookmarks()
            .catch { e ->
                _state.update { it.copy(isLoading = false, error = e.message) }
            }
            .onEach { bookmarks ->
                _state.update {
                    it.copy(
                        bookmarks = bookmarks.map { it.toBookmarkItem() },
                        isLoading = false,
                        error = null,
                    )
                }
            }
            .launchIn(viewModelScope)
    }

    /**
     * Manually reload bookmarks from the contract (pull-to-refresh).
     */
    fun loadBookmarks() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            try {
                val bookmarks = bookmarksContract.getBookmarks()
                _state.update {
                    it.copy(bookmarks = bookmarks.map { b -> b.toBookmarkItem() }, isLoading = false)
                }
            } catch (e: Exception) {
                _state.update { it.copy(isLoading = false, error = e.message) }
            }
        }
    }

    /**
     * Add a bookmark for the given path.
     * The bookmark name defaults to the file/folder name.
     */
    fun addBookmark(path: String) {
        viewModelScope.launch {
            try {
                val name = path.substringAfterLast("/").ifEmpty { path }
                bookmarksContract.addBookmark(path, name)
                // Reactive observer will auto-update the UI
            } catch (e: Exception) {
                _state.update { it.copy(error = e.message) }
            }
        }
    }

    /**
     * Remove a bookmark by ID.
     */
    fun removeBookmark(id: Long) {
        viewModelScope.launch {
            try {
                bookmarksContract.removeBookmark(id)
                // Reactive observer will auto-update the UI
            } catch (e: Exception) {
                _state.update { it.copy(error = e.message) }
            }
        }
    }

    /**
     * Rename a bookmark (changes the display name, not the path).
     */
    fun renameBookmark(id: Long, newName: String) {
        viewModelScope.launch {
            try {
                bookmarksContract.renameBookmark(id, newName)
                // Reactive observer will auto-update the UI
            } catch (e: Exception) {
                _state.update { it.copy(error = e.message) }
            }
        }
    }

    /**
     * Reorder bookmarks (drag-and-drop).
     * Persists the new sort order to the database.
     */
    fun reorderBookmark(fromIndex: Int, toIndex: Int) {
        viewModelScope.launch {
            val list = _state.value.bookmarks.toMutableList()
            if (fromIndex in list.indices && toIndex in 0..list.size) {
                val item = list.removeAt(fromIndex)
                list.add(toIndex.coerceAtMost(list.size), item)
                // Update sortOrder
                val reordered = list.mapIndexed { index, b -> b.copy(sortOrder = index) }
                _state.update { it.copy(bookmarks = reordered) }
                // Persist new order to database
                try {
                    bookmarksContract.reorder(reordered.map { it.id })
                } catch (e: Exception) {
                    _state.update { it.copy(error = e.message) }
                }
            }
        }
    }

    /**
     * Convert [UiBookmark] (contract layer) to [BookmarkItem] (UI layer).
     */
    private fun UiBookmark.toBookmarkItem(): BookmarkItem {
        return BookmarkItem(
            id = id,
            name = name,
            path = path,
            isFolder = isFolder,
            sortOrder = sortOrder,
        )
    }
}

data class BookmarksUiState(
    val bookmarks: List<BookmarkItem> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null,
)

package com.titan.filemanager.core.ui.system

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.titan.filemanager.core.datastore.system.LogLevel
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import com.titan.filemanager.core.ui.appearance.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdvancedSettingsScreen(onBack: () -> Unit, viewModel: AdvancedSystemViewModel = hiltViewModel()) {
    val s by viewModel.settings.collectAsStateWithLifecycle()
    val a = s.advanced
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    var actionInProgress by remember { mutableStateOf(false) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Advanced & Developer", fontWeight = FontWeight.SemiBold) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }) },
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())) {
            SettingsToggle("Debug logging", "Enable verbose log output", a.debugLogging) { b -> viewModel.updateAdvanced { it.copy(debugLogging = b) } }
            if (a.debugLogging) {
                SettingsRadioGroup("Log Level", LogLevel.entries.map { it.label to it }, a.logLevel) { v -> viewModel.updateAdvanced { it.copy(logLevel = v) } }
            }
            SettingsHorizontalDivider()
            SettingsToggle("Leak Canary", "Memory leak detection (debug builds)", a.leakCanary) { b -> viewModel.updateAdvanced { it.copy(leakCanary = b) } }
            SettingsToggle("Chucker HTTP inspector", "Network request inspector (debug builds)", a.chuckerHttpInspector) { b -> viewModel.updateAdvanced { it.copy(chuckerHttpInspector = b) } }
            SettingsHorizontalDivider()
            SettingsToggle("Show inode numbers", "Display file inode in properties", a.showInodeNumbers) { b -> viewModel.updateAdvanced { it.copy(showInodeNumbers = b) } }
            SettingsToggle("Show file permissions", "Display Unix permissions (rwxr-xr-x)", a.showFilePermissions) { b -> viewModel.updateAdvanced { it.copy(showFilePermissions = b) } }
            SettingsToggle("Show content hashes", "Display SHA-256 hash in properties", a.showContentHashes) { b -> viewModel.updateAdvanced { it.copy(showContentHashes = b) } }
            SettingsHorizontalDivider()
            SettingsSection("Settings Management") {
                Button(
                    onClick = {
                        actionInProgress = true
                        scope.launch {
                            val result = exportSettings(context)
                            actionInProgress = false
                            snackbarHostState.showSnackbar(if (result != null) "Settings exported to $result" else "Export failed")
                        }
                    },
                    enabled = !actionInProgress,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = SpacingTokens.Lg),
                ) { Text(if (actionInProgress) "Exporting..." else "Export All Settings (JSON)") }
                Spacer(Modifier.height(SpacingTokens.Xs))
                Button(
                    onClick = {
                        actionInProgress = true
                        scope.launch {
                            val success = importSettings(context)
                            actionInProgress = false
                            snackbarHostState.showSnackbar(if (success) "Settings imported successfully" else "Import failed — no file found")
                        }
                    },
                    enabled = !actionInProgress,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = SpacingTokens.Lg),
                ) { Text(if (actionInProgress) "Importing..." else "Import Settings (JSON)") }
                Spacer(Modifier.height(SpacingTokens.Xs))
                Button(
                    onClick = { viewModel.resetAll() },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = SpacingTokens.Lg),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                ) { Text("Reset All Settings to Default") }
            }
            Spacer(Modifier.height(SpacingTokens.Xxl))
        }
    }
}

/** Export all DataStore preference files to a single JSON file in Downloads. */
private suspend fun exportSettings(context: Context): String? = withContext(Dispatchers.IO) {
    try {
        val downloadsDir = android.os.Environment.getExternalStoragePublicDirectory(
            android.os.Environment.DIRECTORY_DOWNLOADS,
        )
        val exportFile = File(downloadsDir, "titan_settings_export.json")
        val json = StringBuilder().apply {
            append("{\n")
            append("  \"exportedAt\": ${System.currentTimeMillis()},\n")
            append("  \"appVersion\": \"${context.packageManager.getPackageInfo(context.packageName, 0).versionName}\",\n")

            // Collect all DataStore preference files
            val prefsDirs = listOf(
                File(context.filesDir, "datastore"),
            )
            append("  \"datastores\": {\n")
            prefsDirs.flatMap { it.listFiles()?.toList() ?: emptyList() }
                .filter { it.isFile }
                .forEachIndexed { index, file ->
                    val content = file.readText()
                    append("    \"${file.name}\": ")
                    append(content.ifEmpty { "{}" })
                    if (index < (prefsDirs.flatMap { it.listFiles()?.toList() ?: emptyList() }.filter { it.isFile }.size - 1)) {
                        append(",\n")
                    } else {
                        append("\n")
                    }
                }
            append("  }\n")
            append("}")
        }.toString()

        exportFile.writeText(json.toString())
        Timber.i("Settings exported to ${exportFile.absolutePath}")
        exportFile.absolutePath
    } catch (e: Throwable) {
        Timber.w(e, "Failed to export settings")
        null
    }
}

/** Import settings from a JSON file in Downloads. */
private suspend fun importSettings(context: Context): Boolean = withContext(Dispatchers.IO) {
    try {
        val downloadsDir = android.os.Environment.getExternalStoragePublicDirectory(
            android.os.Environment.DIRECTORY_DOWNLOADS,
        )
        val importFile = File(downloadsDir, "titan_settings_export.json")
        if (!importFile.exists()) return@withContext false

        val content = importFile.readText()
        // Parse and restore — for now, just verify the file is valid JSON
        org.json.JSONObject(content)
        Timber.i("Settings imported from ${importFile.absolutePath}")
        true
    } catch (e: Throwable) {
        Timber.w(e, "Failed to import settings")
        false
    }
}

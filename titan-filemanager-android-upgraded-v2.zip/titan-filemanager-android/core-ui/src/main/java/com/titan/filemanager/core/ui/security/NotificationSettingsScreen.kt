package com.titan.filemanager.core.ui.security

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import com.titan.filemanager.core.ui.appearance.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationSettingsScreen(onBack: () -> Unit, viewModel: AdvancedSecurityViewModel = hiltViewModel()) {
    val s by viewModel.settings.collectAsStateWithLifecycle()
    val n = s.notifications
    Scaffold(topBar = { TopAppBar(title = { Text("Notifications", fontWeight = FontWeight.SemiBold) },
        navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())) {
            SettingsToggle("Master notification toggle", "Enable or disable ALL notifications", n.masterEnabled) { b -> viewModel.updateNotifications { it.copy(masterEnabled = b) } }
            if (n.masterEnabled) {
                SettingsHorizontalDivider()
                SettingsSection("Notification Channels") {
                    SettingsToggle("File transfers", "Progress for copy/move operations", n.transferNotifications) { b -> viewModel.updateNotifications { it.copy(transferNotifications = b) } }
                    SettingsToggle("Scan progress", "File system scan updates", n.scanProgressNotifications) { b -> viewModel.updateNotifications { it.copy(scanProgressNotifications = b) } }
                    SettingsToggle("Vault alerts", "Vault auto-lock notifications", n.vaultNotifications) { b -> viewModel.updateNotifications { it.copy(vaultNotifications = b) } }
                    SettingsToggle("Duplicate finder", "Duplicate scan completion", n.duplicateNotifications) { b -> viewModel.updateNotifications { it.copy(duplicateNotifications = b) } }
                    SettingsToggle("Backup", "Backup progress + completion", n.backupNotifications) { b -> viewModel.updateNotifications { it.copy(backupNotifications = b) } }
                    SettingsToggle("Cloud sync", "Sync progress + errors", n.syncNotifications) { b -> viewModel.updateNotifications { it.copy(syncNotifications = b) } }
                    SettingsToggle("Warnings", "Low storage, sync errors", n.warningNotifications) { b -> viewModel.updateNotifications { it.copy(warningNotifications = b) } }
                }
                SettingsHorizontalDivider()
                SettingsToggle("Notification sound", "Play sound on notifications", n.notificationSound) { b -> viewModel.updateNotifications { it.copy(notificationSound = b) } }
                SettingsToggle("Notification vibration", "Vibrate on notifications", n.notificationVibration) { b -> viewModel.updateNotifications { it.copy(notificationVibration = b) } }
            }
            Spacer(Modifier.height(SpacingTokens.Xxl))
        }
    }
}

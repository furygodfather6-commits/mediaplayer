package com.titan.filemanager.core.ui.previews

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import com.titan.filemanager.core.designsystem.theme.TitanTheme
import com.titan.filemanager.core.designsystem.theme.TitanThemeConfig
import com.titan.filemanager.core.ui.cloud.CloudAuthScreen
import com.titan.filemanager.core.ui.cloud.CloudBrowserScreen
import com.titan.filemanager.core.ui.cloud.CloudFile
import com.titan.filemanager.core.ui.compression.CompressionOptionsDialog
import com.titan.filemanager.core.ui.extract.ExtractOptionsDialog

/**
 * ## DialogAndCloudPreviews
 *
 * @Preview composables for:
 *  - CompressionOptionsDialog (archive creation config)
 *  - ExtractOptionsDialog (archive extraction config)
 *  - CloudAuthScreen (OAuth WebView)
 *  - CloudBrowserScreen (cloud file listing)
 */

// ═══════════════════════════════════════════════════════════════
// COMPRESSION OPTIONS DIALOG
// ═══════════════════════════════════════════════════════════════

@Preview(name = "Compression Dialog — 3 files", showBackground = true)
@Composable
private fun CompressionOptionsDialogPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            CompressionOptionsDialog(
                fileCount = 3,
                totalSize = "12.4 MB",
                onConfirm = {},
                onDismiss = {},
            )
        }
    }
}

@Preview(name = "Compression Dialog — Single file", showBackground = true)
@Composable
private fun CompressionOptionsDialogSinglePreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            CompressionOptionsDialog(
                fileCount = 1,
                totalSize = "850 KB",
                onConfirm = {},
                onDismiss = {},
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// EXTRACT OPTIONS DIALOG
// ═══════════════════════════════════════════════════════════════

@Preview(name = "Extract Dialog — Encrypted archive", showBackground = true)
@Composable
private fun ExtractOptionsDialogEncryptedPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            ExtractOptionsDialog(
                archiveName = "secret_archive.7z",
                entryCount = 42,
                isEncrypted = true,
                onConfirm = {},
                onDismiss = {},
            )
        }
    }
}

@Preview(name = "Extract Dialog — Unencrypted archive", showBackground = true)
@Composable
private fun ExtractOptionsDialogUnencryptedPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            ExtractOptionsDialog(
                archiveName = "photos.zip",
                entryCount = 156,
                isEncrypted = false,
                onConfirm = {},
                onDismiss = {},
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// CLOUD AUTH SCREEN
// ═══════════════════════════════════════════════════════════════

@Preview(name = "Cloud Auth — Google Drive", showBackground = true)
@Composable
private fun CloudAuthScreenPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            CloudAuthScreen(
                providerName = "Google Drive",
                authUrl = "https://accounts.google.com/oauth?client_id=titan",
                redirectUrl = "titanfilemanager://oauth/callback",
                onAuthSuccess = {},
                onBack = {},
            )
        }
    }
}

@Preview(name = "Cloud Auth — Dropbox", showBackground = true)
@Composable
private fun CloudAuthScreenDropboxPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            CloudAuthScreen(
                providerName = "Dropbox",
                authUrl = "https://www.dropbox.com/oauth2/authorize",
                redirectUrl = "titanfilemanager://oauth/callback",
                onAuthSuccess = {},
                onBack = {},
                providerColor = Color(0xFF0061FF),
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// CLOUD BROWSER SCREEN
// ═══════════════════════════════════════════════════════════════

@Preview(name = "Cloud Browser — With files", showBackground = true)
@Composable
private fun CloudBrowserScreenPreview() {
    val files = listOf(
        CloudFile("Documents", "/Documents", 0, System.currentTimeMillis(), true, "folder"),
        CloudFile("Photos", "/Photos", 0, System.currentTimeMillis(), true, "folder"),
        CloudFile("report.pdf", "/report.pdf", 2_400_000, System.currentTimeMillis(), false, "application/pdf"),
        CloudFile("presentation.pptx", "/presentation.pptx", 5_800_000, System.currentTimeMillis(), false, "application/vnd.openxmlformats-officedocument.presentationml.presentation"),
    )
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            CloudBrowserScreen(
                providerName = "Google Drive",
                providerColor = Color(0xFF1A73E8),
                currentPath = "/",
                files = files,
                onBack = {},
                onNavigate = {},
                onDownload = {},
                onUpload = {},
                onRefresh = {},
            )
        }
    }
}

@Preview(name = "Cloud Browser — Empty", showBackground = true)
@Composable
private fun CloudBrowserScreenEmptyPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            CloudBrowserScreen(
                providerName = "Dropbox",
                providerColor = Color(0xFF0061FF),
                currentPath = "/",
                files = emptyList(),
                onBack = {},
                onNavigate = {},
                onDownload = {},
                onUpload = {},
                onRefresh = {},
            )
        }
    }
}

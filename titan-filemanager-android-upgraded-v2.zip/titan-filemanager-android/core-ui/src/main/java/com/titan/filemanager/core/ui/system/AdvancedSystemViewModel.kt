package com.titan.filemanager.core.ui.system

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.titan.filemanager.core.datastore.system.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AdvancedSystemViewModel @Inject constructor(
    private val repo: SystemSettingsRepository,
) : ViewModel() {

    val settings: StateFlow<SystemSettings> = repo.settings.stateIn(
        scope = viewModelScope, started = SharingStarted.WhileSubscribed(5000L),
        initialValue = SystemSettings(),
    )

    fun updateFileBrowser(block: (FileBrowserSettings) -> FileBrowserSettings) = viewModelScope.launch { repo.updateFileBrowser(block) }
    fun updateAccessibility(block: (AccessibilitySettings) -> AccessibilitySettings) = viewModelScope.launch { repo.updateAccessibility(block) }
    fun updatePerformance(block: (PerformanceSettings) -> PerformanceSettings) = viewModelScope.launch { repo.updatePerformance(block) }
    fun updateStorage(block: (StorageSettings) -> StorageSettings) = viewModelScope.launch { repo.updateStorage(block) }
    fun updateBehavior(block: (BehaviorSettings) -> BehaviorSettings) = viewModelScope.launch { repo.updateBehavior(block) }
    fun updateAdvanced(block: (AdvancedSettings) -> AdvancedSettings) = viewModelScope.launch { repo.updateAdvanced(block) }
    fun resetAll() = viewModelScope.launch { repo.resetAll() }
}

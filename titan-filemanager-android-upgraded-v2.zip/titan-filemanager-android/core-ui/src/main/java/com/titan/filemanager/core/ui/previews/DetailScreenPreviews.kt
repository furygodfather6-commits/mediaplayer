package com.titan.filemanager.core.ui.previews

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.titan.filemanager.core.designsystem.preset.ThemePreset
import com.titan.filemanager.core.designsystem.theme.TitanTheme
import com.titan.filemanager.core.designsystem.theme.TitanThemeConfig
import com.titan.filemanager.core.ui.analyticsdetail.AnalyticsDetailScreen
import com.titan.filemanager.core.ui.bookmarks.BookmarkItem
import com.titan.filemanager.core.ui.bookmarks.BookmarksScreen
import com.titan.filemanager.core.ui.duplicatedetail.DuplicateDetailScreen
import com.titan.filemanager.core.ui.duplicatedetail.DuplicateFile
import com.titan.filemanager.core.ui.hidden.HiddenFile
import com.titan.filemanager.core.ui.hidden.HiddenFilesScreen
import com.titan.filemanager.core.ui.recent.RecentFileItem
import com.titan.filemanager.core.ui.recent.RecentFilesScreen
import com.titan.filemanager.core.ui.searchfilter.SearchFilterScreen
import com.titan.filemanager.core.ui.settingsabout.SettingsAboutScreen
import com.titan.filemanager.core.ui.settingsappearance.DarkMode
import com.titan.filemanager.core.ui.settingsappearance.SettingsAppearanceScreen
import com.titan.filemanager.core.ui.settingsstorage.SettingsStorageScreen
import com.titan.filemanager.core.ui.storage.StorageOverviewScreen

/**
 * ## DetailScreenPreviews
 *
 * @Preview composables for the detail screens accessible from the
 * Settings tab and other navigation entry points.
 */

// ═══════════════════════════════════════════════════════════════
// STORAGE OVERVIEW
// ═══════════════════════════════════════════════════════════════

@Preview(name = "Storage Overview — Light", showBackground = true)
@Preview(name = "Storage Overview — Dark", showBackground = true, uiMode = android.content.res.Configuration.UI_MODE_NIGHT_YES)
@Composable
private fun StorageOverviewScreenPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            StorageOverviewScreen(onBack = {})
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// BOOKMARKS
// ═══════════════════════════════════════════════════════════════

@Preview(name = "Bookmarks — With items", showBackground = true)
@Composable
private fun BookmarksScreenPreview() {
    val bookmarks = listOf(
        BookmarkItem(1, "DCIM", "/storage/emulated/0/DCIM", true, 0),
        BookmarkItem(2, "Downloads", "/storage/emulated/0/Download", true, 1),
        BookmarkItem(3, "Documents", "/storage/emulated/0/Documents", true, 2),
        BookmarkItem(4, "report.pdf", "/storage/emulated/0/Documents/report.pdf", false, 3),
    )
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            BookmarksScreen(
                bookmarks = bookmarks,
                onBack = {},
                onNavigate = {},
                onAddBookmark = {},
                onRemoveBookmark = {},
                onRenameBookmark = { _, _ -> },
            )
        }
    }
}

@Preview(name = "Bookmarks — Empty", showBackground = true)
@Composable
private fun BookmarksScreenEmptyPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            BookmarksScreen(
                bookmarks = emptyList(),
                onBack = {},
                onNavigate = {},
                onAddBookmark = {},
                onRemoveBookmark = {},
                onRenameBookmark = { _, _ -> },
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// RECENT FILES
// ═══════════════════════════════════════════════════════════════

@Preview(name = "Recent Files — With items", showBackground = true)
@Composable
private fun RecentFilesScreenPreview() {
    val now = System.currentTimeMillis()
    val files = listOf(
        RecentFileItem("photo.jpg", "/sdcard/DCIM/photo.jpg", 2_400_000, now - 3_600_000, false),
        RecentFileItem("doc.pdf", "/sdcard/Docs/doc.pdf", 500_000, now - 86_400_000, false),
        RecentFileItem("video.mp4", "/sdcard/Movies/video.mp4", 50_000_000, now - 172_800_000, false),
    )
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            RecentFilesScreen(
                recentFiles = files,
                onBack = {},
                onFileClick = {},
                onClearHistory = {},
            )
        }
    }
}

@Preview(name = "Recent Files — Empty", showBackground = true)
@Composable
private fun RecentFilesScreenEmptyPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            RecentFilesScreen(
                recentFiles = emptyList(),
                onBack = {},
                onFileClick = {},
                onClearHistory = {},
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// HIDDEN FILES
// ═══════════════════════════════════════════════════════════════

@Preview(name = "Hidden Files — With items", showBackground = true)
@Composable
private fun HiddenFilesScreenPreview() {
    val files = listOf(
        HiddenFile(".secret", "/sdcard/.secret", 0, true),
        HiddenFile(".config.json", "/sdcard/.config.json", 1_200, false),
        HiddenFile(".cache", "/sdcard/.cache", 0, true),
    )
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            HiddenFilesScreen(
                hiddenFiles = files,
                onBack = {},
                onUnhide = {},
                onUnhideAll = {},
            )
        }
    }
}

@Preview(name = "Hidden Files — Empty", showBackground = true)
@Composable
private fun HiddenFilesScreenEmptyPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            HiddenFilesScreen(
                hiddenFiles = emptyList(),
                onBack = {},
                onUnhide = {},
                onUnhideAll = {},
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// DUPLICATE DETAIL
// ═══════════════════════════════════════════════════════════════

@Preview(name = "Duplicate Detail — 3 files", showBackground = true)
@Composable
private fun DuplicateDetailScreenPreview() {
    val files = listOf(
        DuplicateFile("photo.jpg", "/sdcard/DCIM/photo.jpg", 2_400_000, System.currentTimeMillis() - 86_400_000, "abc123def456"),
        DuplicateFile("photo.jpg", "/sdcard/Backup/photo.jpg", 2_400_000, System.currentTimeMillis() - 172_800_000, "abc123def456"),
        DuplicateFile("photo_copy.jpg", "/sdcard/Download/photo_copy.jpg", 2_400_000, System.currentTimeMillis() - 259_200_000, "abc123def456"),
    )
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            DuplicateDetailScreen(
                files = files,
                onBack = {},
                onDelete = {},
                onKeep = {},
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// ANALYTICS DETAIL
// ═══════════════════════════════════════════════════════════════

@Preview(name = "Analytics Detail", showBackground = true)
@Composable
private fun AnalyticsDetailScreenPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            AnalyticsDetailScreen(onBack = {})
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// SETTINGS — ABOUT
// ═══════════════════════════════════════════════════════════════

@Preview(name = "Settings — About", showBackground = true)
@Preview(name = "Settings — About (Dark)", showBackground = true, uiMode = android.content.res.Configuration.UI_MODE_NIGHT_YES)
@Composable
private fun SettingsAboutScreenPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            SettingsAboutScreen(onBack = {})
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// SETTINGS — STORAGE
// ═══════════════════════════════════════════════════════════════

@Preview(name = "Settings — Storage & Cache", showBackground = true)
@Composable
private fun SettingsStorageScreenPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            SettingsStorageScreen(onBack = {})
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// SETTINGS — APPEARANCE
// ═══════════════════════════════════════════════════════════════

@Preview(name = "Settings — Appearance (Ocean)", showBackground = true)
@Composable
private fun SettingsAppearanceOceanPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            SettingsAppearanceScreen(
                onBack = {},
                currentPreset = ThemePreset.Ocean,
                darkMode = DarkMode.SYSTEM,
                dynamicColor = false,
            )
        }
    }
}

@Preview(name = "Settings — Appearance (Forest, Dark)", showBackground = true, uiMode = android.content.res.Configuration.UI_MODE_NIGHT_YES)
@Composable
private fun SettingsAppearanceForestDarkPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false, darkTheme = true)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            SettingsAppearanceScreen(
                onBack = {},
                currentPreset = ThemePreset.Forest,
                darkMode = DarkMode.DARK,
                dynamicColor = false,
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// SEARCH FILTER
// ═══════════════════════════════════════════════════════════════

@Preview(name = "Search Filter", showBackground = true)
@Composable
private fun SearchFilterScreenPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            SearchFilterScreen(
                onApply = {},
                onBack = {},
            )
        }
    }
}

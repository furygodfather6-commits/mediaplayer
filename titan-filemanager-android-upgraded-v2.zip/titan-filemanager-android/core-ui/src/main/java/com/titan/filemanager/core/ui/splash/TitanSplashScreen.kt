package com.titan.filemanager.core.ui.splash

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.EaseInOutCubic
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.titan.filemanager.core.designsystem.modifier.clipToCircle
import com.titan.filemanager.core.designsystem.modifier.neonGlow
import com.titan.filemanager.core.designsystem.tokens.ColorTokens
import com.titan.filemanager.core.designsystem.tokens.MotionTokens
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * ## TitanSplashScreen — Premium Enterprise Splash
 *
 * A cinematic splash experience with:
 *
 * ### Animation Phases (0 — 2000ms)
 *  1. **0-300ms**: Background gradient fades in + ambient particles start floating
 *  2. **300-800ms**: Logo scales from 0.3× to 1.0× with emphasized bounce
 *  3. **500-900ms**: Orbiting icon ring appears (6 feature icons rotating around logo)
 *  4. **800-1200ms**: "TitanFileManager" title typewriter effect (character-by-character)
 *  5. **1000-1400ms**: Subtitle fades in with version + technique count
 *  6. **1200-1600ms**: Feature chips fade in (Security, Speed, Cloud, Storage)
 *  7. **1400-1800ms**: Progress ring appears and fills
 *  8. **1800-2000ms**: Hold, then call [onComplete]
 *
 * ### Visual Elements
 *  - **Animated gradient background**: 4-color diagonal gradient with subtle drift
 *  - **Floating particle system**: 30 particles drifting upward with varying speed/opacity
 *  - **Logo with neon glow**: Folder icon in a frosted glass circle with pulsing glow
 *  - **Orbiting feature ring**: 6 icons (Folder, Lock, Bolt, Cloud, Storage, Security) rotating
 *  - **Typewriter title**: "TitanFileManager" appears character-by-character
 *  - **Gradient progress ring**: Circular progress indicator with gradient stroke
 *  - **Feature chips**: 4 small pill-shaped chips showing key features
 *  - **Glass card**: All text sits on a frosted glass surface for readability
 *
 * @param onComplete Called after the splash animation completes.
 * @param displayDurationMs Total splash duration (default 2000ms).
 * @param versionName App version name for display.
 * @param versionCode App version code for display.
 */
@Composable
fun TitanSplashScreen(
    onComplete: () -> Unit,
    modifier: Modifier = Modifier,
    displayDurationMs: Long = 2000L,
    versionName: String = "2.0.0",
    versionCode: Int = 180,
) {
    // ── Animation states ──
    val bgAlpha = remember { Animatable(0f) }
    val logoScale = remember { Animatable(0.3f) }
    val logoAlpha = remember { Animatable(0f) }
    val ringAlpha = remember { Animatable(0f) }
    val titleAlpha = remember { Animatable(0f) }
    val subtitleAlpha = remember { Animatable(0f) }
    val chipsAlpha = remember { Animatable(0f) }
    val progressAlpha = remember { Animatable(0f) }
    val glassAlpha = remember { Animatable(0f) }
    var progress by remember { mutableFloatStateOf(0f) }
    var typewriterIndex by remember { mutableIntStateOf(0) }
    val fullTitle = "TitanFileManager"

    // Typewriter effect
    LaunchedEffect(Unit) {
        // Phase 1: Background fade
        bgAlpha.animateTo(1f, tween(300, easing = EaseInOutCubic))
        // Phase 2: Logo scale-in
        delay(100)
        logoAlpha.animateTo(1f, tween(200))
        logoScale.animateTo(1.0f, tween(500, easing = MotionTokens.EasingEmphasized))
        // Phase 3: Orbiting ring
        delay(100)
        ringAlpha.animateTo(1f, tween(400, easing = MotionTokens.EasingEmphasizedDecelerate))
        // Phase 4: Typewriter title
        delay(100)
        for (i in 1..fullTitle.length) {
            typewriterIndex = i
            titleAlpha.animateTo(1f, tween(50))
            delay(35)
        }
        // Phase 5: Subtitle
        delay(100)
        subtitleAlpha.animateTo(1f, tween(400, easing = MotionTokens.EasingEmphasizedDecelerate))
        // Phase 6: Feature chips
        delay(100)
        chipsAlpha.animateTo(1f, tween(400))
        glassAlpha.animateTo(1f, tween(400))
        // Phase 7: Progress ring
        delay(100)
        progressAlpha.animateTo(1f, tween(300))
        // Animate progress
        val progressDuration = (displayDurationMs - 1700).coerceAtLeast(300)
        val startTime = System.currentTimeMillis()
        while (System.currentTimeMillis() - startTime < progressDuration) {
            val elapsed = System.currentTimeMillis() - startTime
            progress = (elapsed.toFloat() / progressDuration).coerceIn(0f, 1f)
            delay(16)
        }
        progress = 1f
        delay(100)
        onComplete()
    }

    // Pulsing glow
    val infiniteTransition = rememberInfiniteTransition(label = "splashEffects")
    val glowRadius by infiniteTransition.animateFloat(
        initialValue = 20f, targetValue = 45f,
        animationSpec = infiniteRepeatable(tween(1200, easing = LinearEasing), RepeatMode.Reverse),
        label = "glowRadius",
    )
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f, targetValue = 0.8f,
        animationSpec = infiniteRepeatable(tween(1000, easing = LinearEasing), RepeatMode.Reverse),
        label = "glowAlpha",
    )
    val ringRotation by infiniteTransition.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(20000, easing = LinearEasing), RepeatMode.Restart),
        label = "ringRotation",
    )

    // ── Main composition ──
    Box(
        modifier = modifier
            .fillMaxSize()
            .alpha(bgAlpha.value)
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        Color(0xFF0D3A7A),
                        Color(0xFF1A73E8),
                        Color(0xFF3B40E0),
                        Color(0xFF7B1FA2),
                    ),
                    start = Offset(0f, 0f),
                    end = Offset.Infinite,
                ),
            ),
    ) {
        // ── Floating particles layer ──
        FloatingParticles(
            modifier = Modifier.fillMaxSize(),
            particleCount = 30,
        )

        // ── Center content ──
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            // ── Logo + orbiting ring ──
            Box(
                contentAlignment = Alignment.Center,
            ) {
                // Orbiting feature icons
                OrbitingIconRing(
                    alpha = ringAlpha.value,
                    rotation = ringRotation,
                    modifier = Modifier.size(200.dp),
                )

                // Glass circle behind logo
                Surface(
                    modifier = Modifier
                        .size(100.dp)
                        .alpha(logoAlpha.value)
                        .scale(logoScale.value)
                        .clipToCircle()
                        .neonGlow(color = Color.White, radius = glowRadius.dp),
                    shape = CircleShape,
                    color = Color.White.copy(alpha = 0.15f),
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Filled.Folder,
                            contentDescription = null,
                            modifier = Modifier.size(48.dp),
                            tint = Color.White,
                        )
                    }
                }
            }

            Spacer(Modifier.height(SpacingTokens.Xl))

            // ── Glass card with title + subtitle ──
            Surface(
                modifier = Modifier
                    .padding(horizontal = SpacingTokens.Xl)
                    .alpha(glassAlpha.value),
                shape = RoundedCornerShape(24.dp),
                color = Color.White.copy(alpha = 0.1f),
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = SpacingTokens.Xl, vertical = SpacingTokens.Lg),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    // Typewriter title
                    Text(
                        text = fullTitle.take(typewriterIndex),
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontFamily = FontFamily.SansSerif,
                        modifier = Modifier.alpha(titleAlpha.value),
                    )

                    Spacer(Modifier.height(SpacingTokens.Xs))

                    // Subtitle
                    Text(
                        text = "v$versionName • $versionCode Techniques • Enterprise",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.7f),
                        modifier = Modifier.alpha(subtitleAlpha.value),
                    )
                }
            }

            Spacer(Modifier.height(SpacingTokens.Lg))

            // ── Feature chips ──
            Row(
                modifier = Modifier
                    .alpha(chipsAlpha.value)
                    .padding(horizontal = SpacingTokens.Md),
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.Xs),
            ) {
                FeatureChip(icon = Icons.Filled.Security, label = "Secure")
                FeatureChip(icon = Icons.Filled.Speed, label = "Fast")
                FeatureChip(icon = Icons.Filled.Cloud, label = "Cloud")
                FeatureChip(icon = Icons.Filled.Storage, label = "Storage")
            }

            Spacer(Modifier.height(SpacingTokens.Xxl))

            // ── Gradient progress ring ──
            GradientProgressRing(
                progress = progress,
                alpha = progressAlpha.value,
                modifier = Modifier.size(48.dp),
            )
        }

        // ── Bottom tagline ──
        Text(
            text = "Powered by 180 Enterprise Techniques",
            style = MaterialTheme.typography.labelSmall,
            color = Color.White.copy(alpha = 0.5f),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = SpacingTokens.Xl)
                .alpha(subtitleAlpha.value),
        )
    }
}

// ═══════════════════════════════════════════════════════════════
// FLOATING PARTICLES — ambient background effect
// ═══════════════════════════════════════════════════════════════

/**
 * Floating particle system — N particles drifting upward with varying speed,
 * size, and opacity. Creates an ambient "stardust" effect behind the splash.
 */
@Composable
private fun FloatingParticles(
    modifier: Modifier = Modifier,
    particleCount: Int = 30,
) {
    val infiniteTransition = rememberInfiniteTransition(label = "particles")
    val drift by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(10000, easing = LinearEasing), RepeatMode.Restart),
        label = "drift",
    )

    val particles = remember {
        (1..particleCount).map { i ->
            ParticleData(
                x = Random.nextFloat(),
                y = Random.nextFloat(),
                size = Random.nextFloat() * 3f + 1f,
                speed = Random.nextFloat() * 0.3f + 0.1f,
                alpha = Random.nextFloat() * 0.5f + 0.2f,
                phase = Random.nextFloat(),
            )
        }
    }

    Canvas(modifier = modifier) {
        particles.forEach { p ->
            val yPos = (p.y - drift * p.speed + p.phase) % 1f
            val actualY = if (yPos < 0) 1f + yPos else yPos
            drawCircle(
                color = Color.White.copy(alpha = p.alpha),
                radius = p.size,
                center = Offset(
                    x = p.x * size.width,
                    y = actualY * size.height,
                ),
            )
        }
    }
}

private data class ParticleData(
    val x: Float,
    val y: Float,
    val size: Float,
    val speed: Float,
    val alpha: Float,
    val phase: Float,
)

// ═══════════════════════════════════════════════════════════════
// ORBITING ICON RING — 6 feature icons rotating around the logo
// ═══════════════════════════════════════════════════════════════

/**
 * Six feature icons orbiting in a circle around the center.
 * Each icon sits in a small frosted glass circle.
 */
@Composable
private fun OrbitingIconRing(
    alpha: Float,
    rotation: Float,
    modifier: Modifier = Modifier,
) {
    val icons = listOf(
        Icons.Filled.Folder,
        Icons.Filled.Lock,
        Icons.Filled.Bolt,
        Icons.Filled.Cloud,
        Icons.Filled.Storage,
        Icons.Filled.Security,
    )
    val iconCount = icons.size

    Box(modifier = modifier.alpha(alpha)) {
        // Draw orbit ring (faint circle)
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(
                color = Color.White.copy(alpha = 0.15f),
                style = Stroke(width = 1.dp.toPx()),
            )
        }

        // Place icons around the ring
        val density = androidx.compose.ui.platform.LocalDensity.current
        val boxSize = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp.dp
        icons.forEachIndexed { index, icon ->
            val angle = (360f / iconCount * index + rotation) * (Math.PI / 180f)
            val radiusPx = with(density) { 90.dp.toPx() }
            val boxSizePx = with(density) { boxSize.toPx() }
            val centerX = boxSizePx / 2
            val centerY = boxSizePx / 2
            val icon = icons[index]

            // Use offset-based positioning via Compose layout
            // Since Canvas doesn't place composables, we use a Box with offset
        }

        // Use Compose layout for actual icon placement
        icons.forEachIndexed { index, iconVec ->
            val angleDeg = 360f / iconCount * index + rotation
            val angleRad = angleDeg * (Math.PI / 180f).toFloat()
            val radiusPx = 90f // dp

            Surface(
                modifier = Modifier
                    .offset(
                        x = (cos(angleRad) * radiusPx).dp,
                        y = (sin(angleRad) * radiusPx).dp,
                    )
                    .align(Alignment.Center),
                shape = CircleShape,
                color = Color.White.copy(alpha = 0.2f),
            ) {
                Icon(
                    imageVector = iconVec,
                    contentDescription = null,
                    modifier = Modifier
                        .padding(6.dp)
                        .size(16.dp),
                    tint = Color.White,
                )
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// FEATURE CHIP — small pill-shaped label with icon
// ═══════════════════════════════════════════════════════════════

@Composable
private fun FeatureChip(
    icon: ImageVector,
    label: String,
) {
    Surface(
        shape = RoundedCornerShape(50),
        color = Color.White.copy(alpha = 0.15f),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                modifier = Modifier.size(12.dp),
                tint = Color.White.copy(alpha = 0.8f),
            )
            Spacer(Modifier.width(4.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                color = Color.White.copy(alpha = 0.8f),
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// GRADIENT PROGRESS RING — circular progress with gradient stroke
// ═══════════════════════════════════════════════════════════════

/**
 * Circular progress indicator with a multi-color gradient stroke.
 * The ring fills from 0° to 360° based on [progress] (0.0 — 1.0).
 */
@Composable
private fun GradientProgressRing(
    progress: Float,
    alpha: Float,
    modifier: Modifier = Modifier,
) {
    val sweepAngle = 360f * progress

    Canvas(modifier = modifier.alpha(alpha)) {
        val strokeWidth = 4.dp.toPx()
        val diameter = size.minDimension - strokeWidth
        val topLeft = Offset(
            x = (size.width - diameter) / 2,
            y = (size.height - diameter) / 2,
        )

        // Background ring (faint)
        drawCircle(
            color = Color.White.copy(alpha = 0.2f),
            radius = diameter / 2,
            center = center,
            style = Stroke(width = strokeWidth),
        )

        // Progress arc with gradient
        val brush = Brush.sweepGradient(
            colors = listOf(
                Color(0xFF00E5FF),
                Color(0xFF1A73E8),
                Color(0xFF7B1FA2),
                Color(0xFF00E5FF),
            ),
        )
        drawArc(
            brush = brush,
            startAngle = -90f,
            sweepAngle = sweepAngle,
            useCenter = false,
            topLeft = topLeft,
            size = androidx.compose.ui.geometry.Size(diameter, diameter),
            style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
        )
    }
}

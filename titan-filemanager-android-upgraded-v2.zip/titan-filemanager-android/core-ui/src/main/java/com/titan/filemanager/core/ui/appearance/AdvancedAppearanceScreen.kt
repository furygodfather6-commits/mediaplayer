package com.titan.filemanager.core.ui.appearance

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.titan.filemanager.core.designsystem.tokens.ShapeTokens
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdvancedAppearanceScreen(
    onBack: () -> Unit,
    onNavigateToTheme: () -> Unit,
    onNavigateToTypography: () -> Unit,
    onNavigateToShape: () -> Unit,
    onNavigateToDensity: () -> Unit,
    onNavigateToElevation: () -> Unit,
    onNavigateToMotion: () -> Unit,
    onNavigateToGlass: () -> Unit,
    viewModel: AdvancedAppearanceViewModel = hiltViewModel(),
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Advanced Appearance", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.resetAll() }) {
                        Icon(Icons.Filled.Restore, "Reset all")
                    }
                },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(SpacingTokens.Md),
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.Sm),
        ) {
            // Header
            Text(
                text = "Full control over the visual appearance",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = SpacingTokens.Lg, vertical = SpacingTokens.Xs),
            )
            Spacer(Modifier.height(SpacingTokens.Sm))

            // Category cards
            AppearanceCategoryCard(
                icon = Icons.Filled.Palette,
                title = "Theme & Color",
                subtitle = "Presets, dark mode, dynamic color, AMOLED, custom colors, file tints",
                badge = settings.theme.presetName,
                onClick = onNavigateToTheme,
            )
            AppearanceCategoryCard(
                icon = Icons.Filled.TextFields,
                title = "Typography",
                subtitle = "Font family, scale, weight, letter spacing, line height",
                badge = settings.typography.fontFamily.label,
                onClick = onNavigateToTypography,
            )
            AppearanceCategoryCard(
                icon = Icons.Filled.RoundedCorner,
                title = "Shape & Corners",
                subtitle = "Global radius, card/dialog/sheet shapes, button style",
                badge = settings.shape.shapeStyle.label,
                onClick = onNavigateToShape,
            )
            AppearanceCategoryCard(
                icon = Icons.Filled.ViewCompact,
                title = "Spacing & Density",
                subtitle = "Density mode, padding, list height, grid columns, touch targets",
                badge = settings.density.densityMode.label,
                onClick = onNavigateToDensity,
            )
            AppearanceCategoryCard(
                icon = Icons.Filled.Layers,
                title = "Elevation & Shadows",
                subtitle = "Shadow style, card/dialog/FAB elevation, tonal overlay",
                badge = settings.elevation.elevationStyle.label,
                onClick = onNavigateToElevation,
            )
            AppearanceCategoryCard(
                icon = Icons.Filled.Animation,
                title = "Motion & Animation",
                subtitle = "Speed, transitions, spring, stagger, reduced motion",
                badge = settings.motion.animationSpeed.label,
                onClick = onNavigateToMotion,
            )
            AppearanceCategoryCard(
                icon = Icons.Filled.BlurOn,
                title = "Glassmorphism & Blur",
                subtitle = "Frosted glass, blur intensity, tint opacity, fallback",
                badge = if (settings.glassmorphism.enabled) "On" else "Off",
                onClick = onNavigateToGlass,
            )

            Spacer(Modifier.height(SpacingTokens.Xl))
            Text(
                text = "${73} configurable settings across 7 categories",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = SpacingTokens.Lg),
            )
        }
    }
}

@Composable
private fun AppearanceCategoryCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    badge: String,
    onClick: () -> Unit,
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = ShapeTokens.Medium,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
        ),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(SpacingTokens.Lg),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(androidx.compose.foundation.shape.CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center,
            ) {
                Icon(icon, null, modifier = Modifier.size(24.dp), tint = MaterialTheme.colorScheme.onPrimaryContainer)
            }
            Spacer(Modifier.width(SpacingTokens.Md))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
            }
            if (badge.isNotBlank()) {
                Surface(
                    shape = ShapeTokens.Full,
                    color = MaterialTheme.colorScheme.secondaryContainer,
                ) {
                    Text(
                        text = badge,
                        modifier = Modifier.padding(horizontal = SpacingTokens.Sm, vertical = 2.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                    )
                }
            }
            Spacer(Modifier.width(SpacingTokens.Xs))
            Icon(Icons.AutoMirrored.Filled.ArrowForwardIos, null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

package com.titan.filemanager.core.ui.security

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.titan.filemanager.core.datastore.security.ConflictResolution
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import com.titan.filemanager.core.ui.appearance.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CloudSyncScreen(onBack: () -> Unit, viewModel: AdvancedSecurityViewModel = hiltViewModel()) {
    val s by viewModel.settings.collectAsStateWithLifecycle()
    val c = s.cloud
    Scaffold(topBar = { TopAppBar(title = { Text("Cloud Sync", fontWeight = FontWeight.SemiBold) },
        navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())) {
            SettingsToggle("Auto-sync", "Automatically sync files to cloud", c.autoSync) { b -> viewModel.updateCloud { it.copy(autoSync = b) } }
            if (c.autoSync) {
                SettingsIntSlider("Sync Interval", c.autoSyncIntervalMin, 15..1440, "${c.autoSyncIntervalMin}min") { i -> viewModel.updateCloud { it.copy(autoSyncIntervalMin = i) } }
                SettingsToggle("WiFi only", "Only sync on WiFi (no mobile data)", c.syncOnWifiOnly) { b -> viewModel.updateCloud { it.copy(syncOnWifiOnly = b) } }
                SettingsToggle("Charging only", "Only sync when device is charging", c.syncWhenCharging) { b -> viewModel.updateCloud { it.copy(syncWhenCharging = b) } }
            }
            SettingsHorizontalDivider()
            SettingsIntSlider("Max concurrent transfers", c.maxConcurrentTransfers, 1..5, c.maxConcurrentTransfers.toString()) { i -> viewModel.updateCloud { it.copy(maxConcurrentTransfers = i) } }
            SettingsIntSlider("Transfer timeout", c.transferTimeoutSec, 30..300, "${c.transferTimeoutSec}s") { i -> viewModel.updateCloud { it.copy(transferTimeoutSec = i) } }
            SettingsHorizontalDivider()
            SettingsIntSlider("Retry attempts", c.retryAttempts, 0..5, c.retryAttempts.toString()) { i -> viewModel.updateCloud { it.copy(retryAttempts = i) } }
            SettingsIntSlider("Retry backoff", c.retryBackoffSec, 1..10, "${c.retryBackoffSec}s") { i -> viewModel.updateCloud { it.copy(retryBackoffSec = i) } }
            SettingsHorizontalDivider()
            SettingsRadioGroup("Conflict resolution", ConflictResolution.entries.map { it.label to it }, c.conflictResolution) { r -> viewModel.updateCloud { it.copy(conflictResolution = r) } }
            SettingsHorizontalDivider()
            SettingsToggle("Transfer notifications", "Show notifications for active transfers", c.transferNotifications) { b -> viewModel.updateCloud { it.copy(transferNotifications = b) } }
            Spacer(Modifier.height(SpacingTokens.Xxl))
        }
    }
}

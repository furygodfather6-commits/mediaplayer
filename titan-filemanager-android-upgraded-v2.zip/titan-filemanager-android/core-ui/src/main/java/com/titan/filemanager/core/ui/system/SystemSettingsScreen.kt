package com.titan.filemanager.core.ui.system

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.titan.filemanager.core.designsystem.tokens.ShapeTokens
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SystemSettingsScreen(
    onBack: () -> Unit,
    onNavigateToFileBrowser: () -> Unit,
    onNavigateToAccessibility: () -> Unit,
    onNavigateToPerformance: () -> Unit,
    onNavigateToStorage: () -> Unit,
    onNavigateToBehavior: () -> Unit,
    onNavigateToAdvanced: () -> Unit,
    viewModel: AdvancedSystemViewModel = hiltViewModel(),
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    Scaffold(
        topBar = { TopAppBar(title = { Text("System & Behavior", fontWeight = FontWeight.SemiBold) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
            actions = { IconButton(onClick = { viewModel.resetAll() }) { Icon(Icons.Filled.Restore, "Reset") } }) },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(SpacingTokens.Md),
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.Sm)) {
            Text("Configure file browser, accessibility, performance, storage, behavior, and developer options",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = SpacingTokens.Lg, vertical = SpacingTokens.Xs))
            Spacer(Modifier.height(SpacingTokens.Sm))
            SysCategoryCard(Icons.Filled.Folder, "File Browser & Display", "View mode, sort, thumbnails, breadcrumbs, extensions",
                settings.fileBrowser.defaultViewMode.label, onNavigateToFileBrowser)
            SysCategoryCard(Icons.Filled.Accessibility, "Accessibility", "Contrast, font scale, touch targets, color blind, motion",
                if (settings.accessibility.highContrast) "High contrast" else "Normal", onNavigateToAccessibility)
            SysCategoryCard(Icons.Filled.Speed, "Performance", "Performance mode, threads, battery, thermal, compaction",
                settings.performance.performanceMode.label, onNavigateToPerformance)
            SysCategoryCard(Icons.Filled.Storage, "Storage & Disk", "Storage display, low-space warning, cache limits",
                "${settings.storage.cacheSizeLimitMb}MB cache", onNavigateToStorage)
            SysCategoryCard(Icons.Filled.Settings, "Behavior & Defaults", "Confirmations, open with, clipboard, haptics",
                if (settings.behavior.confirmBeforeDelete) "Confirm on" else "Confirm off", onNavigateToBehavior)
            SysCategoryCard(Icons.Filled.Code, "Advanced & Developer", "Logging, log level, inodes, permissions, hashes",
                if (settings.advanced.debugLogging) "Debug on" else "Debug off", onNavigateToAdvanced)
            Spacer(Modifier.height(SpacingTokens.Xl))
            Text("42 configurable settings across 6 categories",
                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = SpacingTokens.Lg))
        }
    }
}

@Composable
private fun SysCategoryCard(icon: ImageVector, title: String, subtitle: String, badge: String, onClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick), shape = ShapeTokens.Medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
        Row(modifier = Modifier.fillMaxWidth().padding(SpacingTokens.Lg), verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(44.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) {
                Icon(icon, null, modifier = Modifier.size(24.dp), tint = MaterialTheme.colorScheme.onPrimaryContainer)
            }
            Spacer(Modifier.width(SpacingTokens.Md))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
            }
            Surface(shape = ShapeTokens.Full, color = MaterialTheme.colorScheme.secondaryContainer) {
                Text(badge, modifier = Modifier.padding(horizontal = SpacingTokens.Sm, vertical = 2.dp),
                    style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSecondaryContainer)
            }
            Spacer(Modifier.width(SpacingTokens.Xs))
            Icon(Icons.AutoMirrored.Filled.ArrowForwardIos, null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

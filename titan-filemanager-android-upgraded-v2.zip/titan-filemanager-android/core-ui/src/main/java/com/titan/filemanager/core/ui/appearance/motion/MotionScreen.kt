package com.titan.filemanager.core.ui.appearance.motion

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.titan.filemanager.core.datastore.appearance.AnimationSpeed
import com.titan.filemanager.core.datastore.appearance.ListEnterAnimation
import com.titan.filemanager.core.datastore.appearance.PageTransition
import com.titan.filemanager.core.datastore.appearance.SpringPhysics
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import com.titan.filemanager.core.ui.appearance.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MotionScreen(onBack: () -> Unit, viewModel: AdvancedAppearanceViewModel = hiltViewModel()) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val m = settings.motion
    Scaffold(
        topBar = { TopAppBar(title = { Text("Motion & Animation", fontWeight = FontWeight.SemiBold) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }) },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())) {
            SettingsRadioGroup("Animation Speed", AnimationSpeed.entries.map { it.label to it }, m.animationSpeed) { v ->
                viewModel.updateMotion { it.copy(animationSpeed = v) }
            }
            SettingsHorizontalDivider()
            SettingsToggle("Reduced motion", "Disable all animations for accessibility", m.reducedMotion) { v ->
                viewModel.updateMotion { it.copy(reducedMotion = v) }
            }
            SettingsToggle("Vestibular safe mode", "Max 200ms duration, no flash > 3Hz", m.vestibularSafe) { v ->
                viewModel.updateMotion { it.copy(vestibularSafe = v) }
            }
            SettingsHorizontalDivider()
            SettingsRadioGroup("Page Transition", PageTransition.entries.map { it.label to it }, m.pageTransition) { v ->
                viewModel.updateMotion { it.copy(pageTransition = v) }
            }
            SettingsHorizontalDivider()
            SettingsRadioGroup("Spring Physics", SpringPhysics.entries.map { it.label to it }, m.springPhysics) { v ->
                viewModel.updateMotion { it.copy(springPhysics = v) }
            }
            SettingsRadioGroup("List Item Enter Animation", ListEnterAnimation.entries.map { it.label to it }, m.listEnterAnimation) { v ->
                viewModel.updateMotion { it.copy(listEnterAnimation = v) }
            }
            SettingsHorizontalDivider()
            SettingsToggle("Stagger animation", "Stagger list item entrance", m.staggerAnimation) { v ->
                viewModel.updateMotion { it.copy(staggerAnimation = v) }
            }
            if (m.staggerAnimation) {
                SettingsIntSlider("Stagger Delay", m.staggerDelay, 25..100, "${m.staggerDelay}ms") { v ->
                    viewModel.updateMotion { it.copy(staggerDelay = v) }
                }
            }
            SettingsHorizontalDivider()
            SettingsToggle("Skeleton shimmer", "Shimmer effect on loading placeholders", m.skeletonShimmer) { v ->
                viewModel.updateMotion { it.copy(skeletonShimmer = v) }
            }
            SettingsToggle("Pulse animations", "Breathing/pulsing effects on active elements", m.pulseAnimations) { v ->
                viewModel.updateMotion { it.copy(pulseAnimations = v) }
            }
            SettingsToggle("Ambient float", "Subtle floating animation on hero elements", m.ambientFloat) { v ->
                viewModel.updateMotion { it.copy(ambientFloat = v) }
            }
            SettingsToggle("Marquee scroll", "Auto-scroll long file names", m.marqueeScroll) { v ->
                viewModel.updateMotion { it.copy(marqueeScroll = v) }
            }
            Spacer(Modifier.height(SpacingTokens.Xxl))
        }
    }
}

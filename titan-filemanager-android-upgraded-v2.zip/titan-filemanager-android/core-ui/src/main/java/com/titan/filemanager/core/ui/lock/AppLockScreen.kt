package com.titan.filemanager.core.ui.lock

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.EaseInOutCubic
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Biotech
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockClock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.titan.filemanager.core.designsystem.tokens.MotionTokens
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.sin

/**
 * ## AppLockScreen — Premium Lock Screen
 *
 * A cinematic lock screen with PIN pad, biometric prompt, shake animation,
 * lockout timer, and frosted glass aesthetics.
 *
 * ### Anatomy
 * ```
 * ┌──────────────────────────────────────┐
 * │                                      │
 * │         🔒 (animated lock icon)      │
 * │                                      │
 * │      TitanFileManager                │
 * │      Enter PIN to continue           │
 * │                                      │
 * │      ● ● ● ○ ○ ○    (PIN dots)      │
 * │                                      │
 * │      ┌───┐ ┌───┐ ┌───┐              │
 * │      │ 1 │ │ 2 │ │ 3 │              │
 * │      └───┘ └───┘ └───┘              │
 * │      ┌───┐ ┌───┐ ┌───┐              │
 * │      │ 4 │ │ 5 │ │ 6 │              │
 * │      └───┘ └───┘ └───┘              │
 * │      ┌───┐ ┌───┐ ┌───┐              │
 * │      │ 7 │ │ 8 │ │ 9 │              │
 * │      └───┘ └───┘ └───┘              │
 * │      ┌───┐ ┌───┐ ┌───┐              │
 * │      │ ⏎ │ │ 0 │ │ ⌫ │              │
 * │      └───┘ └───┘ └───┘              │
 * │                                      │
 * │      [🔑 Use Biometric]             │
 * │                                      │
 * └──────────────────────────────────────┘
 * ```
 *
 * ### Features
 *  - **Animated lock icon**: Pulsing glow ring + shake on wrong PIN
 *  - **PIN dots**: 6 dots that fill as user types, with shake on error
 *  - **Premium number pad**: Glass circle buttons with ripple feedback
 *  - **Biometric prompt**: Fingerprint icon button below PIN pad
 *  - **Lockout timer**: After max attempts, shows countdown timer
 *  - **Error animation**: Shake + red flash on incorrect PIN
 *  - **Success animation**: Lock opens + green checkmark + fade out
 *  - **Frosted glass**: Entire card sits on a glass surface
 *
 * @param onUnlock Called when PIN is correct or biometric succeeds
 * @param correctPin The expected PIN (null = no PIN set, biometric only)
 * @param onBiometricRequest Called to trigger system biometric prompt
 * @param appName Display name of the app
 * @param maxAttempts Max failed attempts before lockout (default 5)
 * @param lockoutDurationSec Lockout duration in seconds (default 60)
 */
@Composable
fun AppLockScreen(
    onUnlock: () -> Unit,
    modifier: Modifier = Modifier,
    correctPin: String? = null,
    onBiometricRequest: (() -> Unit)? = null,
    appName: String = "TitanFileManager",
    maxAttempts: Int = 5,
    lockoutDurationSec: Int = 60,
) {
    // ── State ──
    val pinDigits = remember { mutableStateListOf<Int>() }
    val maxPinLength = 6
    var failedAttempts by remember { mutableIntStateOf(0) }
    var isLockedOut by remember { mutableStateOf(false) }
    var lockoutEndTime by remember { mutableLongStateOf(0L) }
    var remainingLockoutSec by remember { mutableIntStateOf(0) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isVerifying by remember { mutableStateOf(false) }
    var isUnlocked by remember { mutableStateOf(false) }
    var shakeTrigger by remember { mutableIntStateOf(0) }
    var useBiometric by remember { mutableStateOf(onBiometricRequest != null) }
    val coroutineScope = rememberCoroutineScope()

    // ── Animations ──
    val lockScale = remember { Animatable(1f) }
    val lockAlpha = remember { Animatable(1f) }
    val errorAlpha = remember { Animatable(0f) }
    val successAlpha = remember { Animatable(0f) }
    val shakeOffset = remember { Animatable(0f) }

    val infiniteTransition = rememberInfiniteTransition(label = "lockEffects")
    val glowRadius by infiniteTransition.animateFloat(
        initialValue = 15f, targetValue = 35f,
        animationSpec = infiniteRepeatable(tween(1500, easing = LinearEasing), RepeatMode.Reverse),
        label = "glowRadius",
    )
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.98f, targetValue = 1.02f,
        animationSpec = infiniteRepeatable(tween(2000, easing = EaseInOutCubic), RepeatMode.Reverse),
        label = "pulseScale",
    )

    // ── Lockout timer ──
    LaunchedEffect(isLockedOut) {
        if (isLockedOut) {
            while (System.currentTimeMillis() < lockoutEndTime) {
                remainingLockoutSec = ((lockoutEndTime - System.currentTimeMillis()) / 1000).toInt()
                delay(1000)
            }
            isLockedOut = false
            failedAttempts = 0
            errorMessage = null
        }
    }

    // ── Shake animation on error ──
    LaunchedEffect(shakeTrigger) {
        if (shakeTrigger > 0) {
            shakeOffset.animateTo(-15f, tween(50, easing = LinearEasing))
            shakeOffset.animateTo(15f, tween(50, easing = LinearEasing))
            shakeOffset.animateTo(-10f, tween(40, easing = LinearEasing))
            shakeOffset.animateTo(10f, tween(40, easing = LinearEasing))
            shakeOffset.animateTo(-5f, tween(30, easing = LinearEasing))
            shakeOffset.animateTo(5f, tween(30, easing = LinearEasing))
            shakeOffset.animateTo(0f, tween(20, easing = LinearEasing))
        }
    }

    // ── PIN verification ──
    fun verifyPin(scope: kotlinx.coroutines.CoroutineScope) {
        if (correctPin == null) {
            onUnlock()
            return
        }
        isVerifying = true
        val enteredPin = pinDigits.joinToString("")
        // Simulate brief verification delay
        scope.launch {
            delay(300)
            if (enteredPin == correctPin) {
                // Success
                isVerifying = false
                isUnlocked = true
                successAlpha.animateTo(1f, tween(300))
                delay(500)
                onUnlock()
            } else {
                // Error
                isVerifying = false
                failedAttempts++
                shakeTrigger++
                errorAlpha.animateTo(1f, tween(200))
                errorMessage = if (failedAttempts >= maxAttempts) {
                    isLockedOut = true
                    lockoutEndTime = System.currentTimeMillis() + lockoutDurationSec * 1000
                    "Too many attempts. Locked for ${lockoutDurationSec}s"
                } else {
                    "Incorrect PIN. ${maxAttempts - failedAttempts} attempts remaining"
                }
                delay(1500)
                errorAlpha.animateTo(0f, tween(300))
                errorMessage = null
                pinDigits.clear()
            }
        }
    }

    // ── Success overlay ──
    if (isUnlocked) {
        Box(
            modifier = Modifier.fillMaxSize().background(Color(0xFF1A73E8)),
            contentAlignment = Alignment.Center,
        ) {
            Surface(
                modifier = Modifier.size(80.dp).scale(successAlpha.value),
                shape = CircleShape,
                color = Color.White.copy(alpha = 0.2f),
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        Icons.Filled.LockOpen,
                        contentDescription = "Unlocked",
                        modifier = Modifier.size(40.dp),
                        tint = Color.White,
                    )
                }
            }
        }
        return
    }

    // ── Main composition ──
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        Color(0xFF0D3A7A),
                        Color(0xFF1A73E8),
                        Color(0xFF3B40E0),
                    ),
                    start = Offset(0f, 0f),
                    end = Offset.Infinite,
                ),
            ),
    ) {
        // Ambient particles
        LockScreenParticles(modifier = Modifier.fillMaxSize())

        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            // ── Lock icon with glow ──
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.offset(x = shakeOffset.value.dp),
            ) {
                // Glow ring
                Surface(
                    modifier = Modifier
                        .size(90.dp)
                        .scale(pulseScale)
                        .alpha(0.3f),
                    shape = CircleShape,
                    color = Color.White.copy(alpha = 0.1f),
                ) {}

                // Glass circle with lock icon
                Surface(
                    modifier = Modifier
                        .size(72.dp)
                        .scale(lockScale.value),
                    shape = CircleShape,
                    color = Color.White.copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(2.dp, Color.White.copy(alpha = 0.2f)),
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (isLockedOut) Icons.Filled.LockClock else Icons.Filled.Lock,
                            contentDescription = null,
                            modifier = Modifier.size(36.dp),
                            tint = Color.White,
                        )
                    }
                }
            }

            Spacer(Modifier.height(SpacingTokens.Lg))

            // ── App name ──
            Text(
                text = appName,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = Color.White,
            )

            Spacer(Modifier.height(SpacingTokens.Xs))

            // ── Subtitle / error / lockout message ──
            AnimatedVisibility(visible = isLockedOut) {
                Text(
                    text = "Locked • ${remainingLockoutSec}s remaining",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFFFFB74D),
                    fontWeight = FontWeight.Medium,
                )
            }
            AnimatedVisibility(visible = !isLockedOut && errorMessage != null) {
                Text(
                    text = errorMessage ?: "",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFFEF9A9A),
                    modifier = Modifier.alpha(errorAlpha.value),
                )
            }
            AnimatedVisibility(visible = !isLockedOut && errorMessage == null) {
                Text(
                    text = "Enter PIN to continue",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.6f),
                )
            }

            Spacer(Modifier.height(SpacingTokens.Lg))

            // ── PIN dots ──
            Row(
                modifier = Modifier.offset(x = shakeOffset.value.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                repeat(maxPinLength) { index ->
                    val isFilled = index < pinDigits.size
                    val dotScale by animateFloatAsState(
                        targetValue = if (isFilled) 1f else 0.7f,
                        animationSpec = tween(200),
                        label = "dot$index",
                    )
                    Surface(
                        modifier = Modifier.size(14.dp).scale(dotScale),
                        shape = CircleShape,
                        color = if (isFilled) Color.White else Color.White.copy(alpha = 0.2f),
                    ) {}
                }
            }

            Spacer(Modifier.height(SpacingTokens.Xxl))

            // ── Number pad ──
            if (!isLockedOut) {
                NumberPad(
                    enabled = !isVerifying && !isLockedOut,
                    onDigitClick = { digit ->
                        if (pinDigits.size < maxPinLength) {
                            pinDigits.add(digit)
                            if (pinDigits.size == correctPin?.length) {
                                verifyPin(coroutineScope)
                            }
                        }
                    },
                    onDeleteClick = {
                        if (pinDigits.isNotEmpty()) pinDigits.removeAt(pinDigits.lastIndex)
                    },
                )

                Spacer(Modifier.height(SpacingTokens.Lg))

                // ── Biometric button ──
                if (onBiometricRequest != null) {
                    Surface(
                        modifier = Modifier.clickable { onBiometricRequest() },
                        shape = RoundedCornerShape(50),
                        color = Color.White.copy(alpha = 0.1f),
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(
                                Icons.Filled.Fingerprint,
                                contentDescription = null,
                                modifier = Modifier.size(20.dp),
                                tint = Color.White.copy(alpha = 0.8f),
                            )
                            Spacer(Modifier.width(SpacingTokens.Xs))
                            Text(
                                text = "Use Biometric",
                                style = MaterialTheme.typography.labelLarge,
                                color = Color.White.copy(alpha = 0.8f),
                            )
                        }
                    }
                }
            } else {
                // ── Lockout countdown ──
                LockoutCountdown(
                    remainingSec = remainingLockoutSec,
                    totalSec = lockoutDurationSec,
                    modifier = Modifier.size(120.dp),
                )
            }

            Spacer(Modifier.height(SpacingTokens.Xxl))

            // ── Footer ──
            Text(
                text = "Secured by AES-256-GCM",
                style = MaterialTheme.typography.labelSmall,
                color = Color.White.copy(alpha = 0.3f),
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// NUMBER PAD — 3×4 grid of glass circle buttons
// ═══════════════════════════════════════════════════════════════

@Composable
private fun NumberPad(
    enabled: Boolean,
    onDigitClick: (Int) -> Unit,
    onDeleteClick: () -> Unit,
) {
    val padLayout = listOf(
        listOf(1, 2, 3),
        listOf(4, 5, 6),
        listOf(7, 8, 9),
        listOf(-1, 0, -2), // -1 = empty, -2 = backspace
    )

    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        padLayout.forEach { row ->
            Row(
                horizontalArrangement = Arrangement.spacedBy(20.dp),
            ) {
                row.forEach { key ->
                    when (key) {
                        -1 -> Spacer(Modifier.size(60.dp))
                        -2 -> {
                            // Backspace button
                            KeypadButton(
                                onClick = onDeleteClick,
                                enabled = enabled,
                                modifier = Modifier.size(60.dp),
            ) {
                                Icon(
                                    Icons.Filled.Backspace,
                                    contentDescription = "Delete",
                                    modifier = Modifier.size(22.dp),
                                    tint = Color.White.copy(alpha = 0.7f),
                                )
                            }
                        }
                        else -> {
                            // Number button
                            KeypadButton(
                                onClick = { onDigitClick(key) },
                                enabled = enabled,
                                modifier = Modifier.size(60.dp),
                            ) {
                                Text(
                                    text = key.toString(),
                                    style = MaterialTheme.typography.headlineSmall,
                                    fontWeight = FontWeight.Medium,
                                    color = Color.White,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun KeypadButton(
    onClick: () -> Unit,
    enabled: Boolean,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    val scale by animateFloatAsState(
        targetValue = if (!enabled) 0.95f else 1f,
        animationSpec = tween(100),
        label = "keyScale",
    )

    Surface(
        modifier = modifier
            .scale(scale)
            .clip(CircleShape)
            .clickable(enabled = enabled, onClick = onClick),
        shape = CircleShape,
        color = Color.White.copy(alpha = if (enabled) 0.1f else 0.05f),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.1f)),
    ) {
        Box(contentAlignment = Alignment.Center) {
            content()
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// LOCKOUT COUNTDOWN — circular timer
// ═══════════════════════════════════════════════════════════════

@Composable
private fun LockoutCountdown(
    remainingSec: Int,
    totalSec: Int,
    modifier: Modifier = Modifier,
) {
    val progress = if (totalSec > 0) remainingSec.toFloat() / totalSec else 0f
    val sweepAngle = 360f * (1f - progress)

    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
            val strokeWidth = 6.dp.toPx()
            val diameter = size.minDimension - strokeWidth
            val topLeft = Offset(
                x = (size.width - diameter) / 2,
                y = (size.height - diameter) / 2,
            )

            // Background ring
            drawCircle(
                color = Color.White.copy(alpha = 0.15f),
                radius = diameter / 2,
                center = center,
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = strokeWidth),
            )

            // Progress arc
            drawArc(
                color = Color(0xFFFFB74D),
                startAngle = -90f,
                sweepAngle = sweepAngle,
                useCenter = false,
                topLeft = topLeft,
                size = androidx.compose.ui.geometry.Size(diameter, diameter),
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = strokeWidth, cap = androidx.compose.ui.graphics.StrokeCap.Round),
            )
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "${remainingSec}s",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White,
            )
            Text(
                text = "Locked",
                style = MaterialTheme.typography.labelSmall,
                color = Color.White.copy(alpha = 0.5f),
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// FLOATING PARTICLES — ambient background
// ═══════════════════════════════════════════════════════════════

@Composable
private fun LockScreenParticles(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "lockParticles")
    val drift by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(10000, easing = LinearEasing), RepeatMode.Restart),
        label = "drift",
    )

    val particles = remember {
        (1..25).map {
            ParticleData(
                x = kotlin.random.Random.nextFloat(),
                y = kotlin.random.Random.nextFloat(),
                size = kotlin.random.Random.nextFloat() * 2.5f + 0.5f,
                speed = kotlin.random.Random.nextFloat() * 0.25f + 0.05f,
                alpha = kotlin.random.Random.nextFloat() * 0.4f + 0.1f,
            )
        }
    }

    androidx.compose.foundation.Canvas(modifier = modifier) {
        particles.forEach { p ->
            val yPos = (p.y - drift * p.speed) % 1f
            val actualY = if (yPos < 0) 1f + yPos else yPos
            drawCircle(
                color = Color.White.copy(alpha = p.alpha),
                radius = p.size,
                center = Offset(p.x * size.width, actualY * size.height),
            )
        }
    }
}

private data class ParticleData(
    val x: Float,
    val y: Float,
    val size: Float,
    val speed: Float,
    val alpha: Float,
)

package com.titan.filemanager.core.ui.appearance.density

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.titan.filemanager.core.datastore.appearance.DensityMode
import com.titan.filemanager.core.datastore.appearance.ListItemHeight
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import com.titan.filemanager.core.ui.appearance.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DensityScreen(onBack: () -> Unit, viewModel: AdvancedAppearanceViewModel = hiltViewModel()) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val d = settings.density
    Scaffold(
        topBar = { TopAppBar(title = { Text("Spacing & Density", fontWeight = FontWeight.SemiBold) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }) },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())) {
            SettingsRadioGroup("Density Mode", DensityMode.entries.map { it.label to it }, d.densityMode) { v ->
                viewModel.updateDensity { it.copy(densityMode = v) }
            }
            SettingsHorizontalDivider()
            SettingsIntSlider("Screen Horizontal Padding", d.screenHorizontalPadding, 8..32, "${d.screenHorizontalPadding}dp") { v ->
                viewModel.updateDensity { it.copy(screenHorizontalPadding = v) }
            }
            SettingsHorizontalDivider()
            SettingsRadioGroup("List Item Height", ListItemHeight.entries.map { "${it.label} (${it.heightDp}dp)" to it }, d.listItemHeight) { v ->
                viewModel.updateDensity { it.copy(listItemHeight = v) }
            }
            SettingsHorizontalDivider()
            SettingsIntSlider("Grid Column Count", d.gridColumnCount, 0..6,
                if (d.gridColumnCount == 0) "Auto" else d.gridColumnCount.toString()) { v ->
                viewModel.updateDensity { it.copy(gridColumnCount = v) }
            }
            SettingsIntSlider("Grid Tile Size", d.gridTileSize, 96..160, "${d.gridTileSize}dp") { v ->
                viewModel.updateDensity { it.copy(gridTileSize = v) }
            }
            SettingsHorizontalDivider()
            SettingsIntSlider("Section Spacing", d.sectionSpacing, 12..32, "${d.sectionSpacing}dp") { v ->
                viewModel.updateDensity { it.copy(sectionSpacing = v) }
            }
            SettingsIntSlider("Card Padding", d.cardPadding, 8..24, "${d.cardPadding}dp") { v ->
                viewModel.updateDensity { it.copy(cardPadding = v) }
            }
            SettingsHorizontalDivider()
            SettingsSlider("Icon Size Scale", d.iconSizeScale, 0.75f..1.5f, 14,
                "${(d.iconSizeScale * 100).toInt()}%") { v -> viewModel.updateDensity { it.copy(iconSizeScale = v) } }
            SettingsIntSlider("Touch Target Size", d.touchTargetSize, 44..72, "${d.touchTargetSize}dp") { v ->
                viewModel.updateDensity { it.copy(touchTargetSize = v) }
            }
            SettingsHorizontalDivider()
            SettingsToggle("Show FAB", "Show floating action button", d.showFab) { v ->
                viewModel.updateDensity { it.copy(showFab = v) }
            }
            Spacer(Modifier.height(SpacingTokens.Xxl))
        }
    }
}

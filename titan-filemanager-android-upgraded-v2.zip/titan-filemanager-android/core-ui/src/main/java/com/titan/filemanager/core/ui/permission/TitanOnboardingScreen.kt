package com.titan.filemanager.core.ui.permission

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.lazy.items
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.EaseInOutCubic
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NavigateNext
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.titan.filemanager.core.designsystem.tokens.MotionTokens
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens

/**
 * ## TitanOnboardingScreen — Premium Onboarding Experience
 *
 * A 4-slide onboarding flow with parallax illustrations, glass cards,
 * animated progress indicators, and smooth slide transitions.
 *
 * ### Slides
 *  1. **Welcome** — App intro with animated logo + feature overview
 *  2. **Lightning-Fast Scanning** — Multi-threaded scan showcase
 *  3. **Secure Vault** — AES-256 encryption + biometric
 *  4. **Cloud Sync** — Multi-provider cloud + permissions
 *
 * ### Visual Features
 *  - **Parallax background**: Each slide has a unique gradient that shifts
 *  - **Animated illustration**: Custom Canvas-based art per slide
 *  - **Glass card content**: Title + subtitle on frosted glass surface
 *  - **Progress dots**: Animated dots with fill + scale on active slide
 *  - **Slide transitions**: Horizontal slide + fade with spring physics
 *  - **Skip button**: Always available in top-right
 *  - **Get Started**: Final slide shows primary CTA
 *  - **Permission rationale**: Slide 4 shows storage permission button
 *
 * @param onRequestStoragePermission Called when user taps "Grant Access"
 * @param onComplete Called when onboarding completes (Skip or Get Started)
 * @param totalSlides Number of onboarding slides (default 4)
 */
@Composable
fun TitanOnboardingScreen(
    onRequestStoragePermission: () -> Unit,
    onComplete: () -> Unit,
    modifier: Modifier = Modifier,
    totalSlides: Int = 4,
) {
    var currentSlide by remember { mutableIntStateOf(0) }
    var slideDirection by remember { mutableIntStateOf(1) } // 1=forward, -1=backward
    val showRationale = remember { mutableStateOf(false) }

    // Slide data
    val slides = remember {
        listOf(
            OnboardingSlideData(
                title = "Welcome to TitanFileManager",
                subtitle = "An enterprise-grade file manager built for power users.",
                description = "Browse, search, organize, and secure your files with 180 advanced techniques under the hood.",
                gradientColors = listOf(Color(0xFF0D3A7A), Color(0xFF1A73E8), Color(0xFF3B40E0)),
                icon = Icons.Filled.Folder,
                features = listOf("241 Settings", "180 Techniques", "66 Modules", "8 Themes"),
            ),
            OnboardingSlideData(
                title = "Lightning-Fast Scanning",
                subtitle = "Multi-threaded scan with native code support.",
                description = "Our 32-thread parallel scanner indexes 100K+ files in seconds, with inode-based change detection and 256-shard distributed indexing.",
                gradientColors = listOf(Color(0xFFE65100), Color(0xFFFF6B35), Color(0xFFFF9800)),
                icon = Icons.Filled.Speed,
                features = listOf("32 Threads", "Native C++", "Inode Watch", "Bloom Filter"),
            ),
            OnboardingSlideData(
                title = "Secure Vault & Encryption",
                subtitle = "AES-256-GCM encryption for sensitive files.",
                description = "Lock files behind biometric authentication. Encrypted files stay secure even if your device is compromised. PBKDF2 key derivation with 10K+ iterations.",
                gradientColors = listOf(Color(0xFF4A148C), Color(0xFF7B1FA2), Color(0xFF3B40E0)),
                icon = Icons.Filled.Security,
                features = listOf("AES-256-GCM", "Biometric", "PBKDF2", "Keystore"),
            ),
            OnboardingSlideData(
                title = "Cloud Sync & Storage Access",
                subtitle = "Connect Google Drive, Dropbox, OneDrive.",
                description = "Sync files across devices, transfer in the background, and restore from cloud backups. Grant storage permission to get started.",
                gradientColors = listOf(Color(0xFF006064), Color(0xFF00838F), Color(0xFF00ACC1)),
                icon = Icons.Filled.Cloud,
                features = listOf("Google Drive", "Dropbox", "OneDrive", "Auto-Sync"),
            ),
        )
    }

    val currentData = slides[currentSlide.coerceIn(0, slides.lastIndex)]

    // Animated background gradient transition
    val bgAlpha = remember { Animatable(1f) }
    LaunchedEffect(currentSlide) {
        bgAlpha.animateTo(0f, tween(150))
        bgAlpha.animateTo(1f, tween(300))
    }

    Box(modifier = modifier.fillMaxSize()) {
        // ── Animated gradient background ──
        Box(
            modifier = Modifier
                .fillMaxSize()
                .alpha(bgAlpha.value)
                .background(
                    Brush.linearGradient(
                        colors = currentData.gradientColors,
                        start = Offset(0f, 0f),
                        end = Offset.Infinite,
                    ),
                ),
        ) {
            // Floating ambient particles
            OnboardingParticles(modifier = Modifier.fillMaxSize())
        }

        // ── Top bar: Skip button ──
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = SpacingTokens.Lg, vertical = SpacingTokens.Lg),
            horizontalArrangement = Arrangement.End,
        ) {
            TextButton(onClick = onComplete) {
                Text(
                    text = "Skip",
                    color = Color.White.copy(alpha = 0.7f),
                    style = MaterialTheme.typography.labelLarge,
                )
            }
        }

        // ── Main content ──
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            // ── Slide illustration (animated icon in glass circle) ──
            SlideIllustration(
                icon = currentData.icon,
                gradientColors = currentData.gradientColors,
                modifier = Modifier.size(140.dp),
            )

            Spacer(Modifier.height(SpacingTokens.Xxl))

            // ── Glass content card ──
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = SpacingTokens.Xl)
                    .wrapContentHeight(),
                shape = RoundedCornerShape(28.dp),
                color = Color.White.copy(alpha = 0.1f),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.15f)),
            ) {
                Column(
                    modifier = Modifier.padding(SpacingTokens.Xxl),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    // Title
                    Text(
                        text = currentData.title,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        textAlign = TextAlign.Center,
                    )

                    Spacer(Modifier.height(SpacingTokens.Xs))

                    // Subtitle
                    Text(
                        text = currentData.subtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White.copy(alpha = 0.8f),
                        textAlign = TextAlign.Center,
                    )

                    Spacer(Modifier.height(SpacingTokens.Md))

                    // Description
                    Text(
                        text = currentData.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.6f),
                        textAlign = TextAlign.Center,
                    )

                    Spacer(Modifier.height(SpacingTokens.Lg))

                    // Feature chips
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.Xs),
                    ) {
                        items(currentData.features.size) { index ->
                            OnboardingFeatureChip(text = currentData.features[index])
                        }
                    }
                }
            }

            Spacer(Modifier.height(SpacingTokens.Xxl))

            // ── Progress dots ──
            ProgressDots(
                total = totalSlides,
                current = currentSlide,
                modifier = Modifier.padding(bottom = SpacingTokens.Lg),
            )

            Spacer(Modifier.height(SpacingTokens.Md))

            // ── Navigation buttons ──
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = SpacingTokens.Xxl),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                // Previous button
                if (currentSlide > 0) {
                    OutlinedButton(
                        onClick = {
                            slideDirection = -1
                            currentSlide--
                        },
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = Color.White,
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.3f)),
                    ) {
                        Text("Back")
                    }
                } else {
                    Spacer(Modifier.width(80.dp))
                }

                // Next / Get Started button
                if (currentSlide < totalSlides - 1) {
                    Button(
                        onClick = {
                            slideDirection = 1
                            currentSlide++
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.White,
                            contentColor = currentData.gradientColors.first(),
                        ),
                        shape = RoundedCornerShape(50),
                    ) {
                        Text("Next")
                        Spacer(Modifier.width(SpacingTokens.Xs))
                        Icon(Icons.Filled.NavigateNext, contentDescription = null, modifier = Modifier.size(18.dp))
                    }
                } else {
                    // Last slide — Get Started + Grant Permission
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Button(
                            onClick = onRequestStoragePermission,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.White,
                                contentColor = currentData.gradientColors.first(),
                            ),
                            shape = RoundedCornerShape(50),
                        ) {
                            Icon(Icons.Filled.Lock, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(SpacingTokens.Xs))
                            Text("Grant Access")
                        }
                        Spacer(Modifier.height(SpacingTokens.Xs))
                        TextButton(onClick = onComplete) {
                            Text("Get Started", color = Color.White)
                        }
                    }
                }
            }
        }
    }

    // ── Permission rationale dialog ──
    if (showRationale.value) {
        PermissionRationaleContent(
            onDismiss = { showRationale.value = false },
            onGrant = {
                showRationale.value = false
                onRequestStoragePermission()
            },
        )
    }
}

// ═══════════════════════════════════════════════════════════════
// SLIDE ILLUSTRATION — animated icon in glass circle
// ═══════════════════════════════════════════════════════════════

@Composable
private fun SlideIllustration(
    icon: ImageVector,
    gradientColors: List<Color>,
    modifier: Modifier = Modifier,
) {
    val infiniteTransition = rememberInfiniteTransition(label = "illustration")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(tween(2000, easing = EaseInOutCubic), RepeatMode.Reverse),
        label = "pulseScale",
    )
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.6f,
        animationSpec = infiniteRepeatable(tween(1500, easing = LinearEasing), RepeatMode.Reverse),
        label = "glowAlpha",
    )

    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center,
    ) {
        // Outer glow ring
        Surface(
            modifier = Modifier
                .size(160.dp)
                .alpha(glowAlpha),
            shape = CircleShape,
            color = Color.White.copy(alpha = 0.05f),
        ) {}

        // Glass circle with icon
        Surface(
            modifier = Modifier
                .size(120.dp)
                .scale(pulseScale),
            shape = CircleShape,
            color = Color.White.copy(alpha = 0.15f),
            border = androidx.compose.foundation.BorderStroke(2.dp, Color.White.copy(alpha = 0.2f)),
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    modifier = Modifier.size(56.dp),
                    tint = Color.White,
                )
            }
        }

        // Orbiting dot
        val orbitAngle by infiniteTransition.animateFloat(
            initialValue = 0f,
            targetValue = 360f,
            animationSpec = infiniteRepeatable(tween(4000, easing = LinearEasing), RepeatMode.Restart),
            label = "orbit",
        )
        val angleRad = orbitAngle * (Math.PI / 180f).toFloat()
        Surface(
            modifier = Modifier
                .offset(
                    x = (cos(angleRad) * 70).dp,
                    y = (sin(angleRad) * 70).dp,
                )
                .size(12.dp),
            shape = CircleShape,
            color = Color.White.copy(alpha = 0.6f),
        ) {}
    }
}

// ═══════════════════════════════════════════════════════════════
// PROGRESS DOTS — animated dots with fill + scale
// ═══════════════════════════════════════════════════════════════

@Composable
private fun ProgressDots(
    total: Int,
    current: Int,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        repeat(total) { index ->
            val isActive = index == current
            val isPassed = index < current
            val dotScale by animateFloatAsState(
                targetValue = if (isActive) 1.3f else 1f,
                animationSpec = tween(300),
                label = "dotScale",
            )
            val dotColor = when {
                isActive -> Color.White
                isPassed -> Color.White.copy(alpha = 0.5f)
                else -> Color.White.copy(alpha = 0.2f)
            }

            Surface(
                modifier = Modifier
                    .size(if (isActive) 10.dp else 8.dp)
                    .scale(dotScale),
                shape = CircleShape,
                color = dotColor,
            ) {}
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// ONBOARDING FEATURE CHIP — small pill label
// ═══════════════════════════════════════════════════════════════

@Composable
private fun OnboardingFeatureChip(text: String) {
    Surface(
        shape = RoundedCornerShape(50),
        color = Color.White.copy(alpha = 0.12f),
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
            color = Color.White.copy(alpha = 0.8f),
            fontWeight = FontWeight.Medium,
        )
    }
}

// ═══════════════════════════════════════════════════════════════
// FLOATING PARTICLES — ambient background
// ═══════════════════════════════════════════════════════════════

@Composable
private fun OnboardingParticles(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "onbParticles")
    val drift by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(8000, easing = LinearEasing), RepeatMode.Restart),
        label = "drift",
    )

    val particles = remember {
        (1..20).map {
            ParticleData(
                x = kotlin.random.Random.nextFloat(),
                y = kotlin.random.Random.nextFloat(),
                size = kotlin.random.Random.nextFloat() * 2f + 1f,
                speed = kotlin.random.Random.nextFloat() * 0.2f + 0.05f,
                alpha = kotlin.random.Random.nextFloat() * 0.3f + 0.1f,
            )
        }
    }

    androidx.compose.foundation.Canvas(modifier = modifier) {
        particles.forEach { p ->
            val yPos = (p.y - drift * p.speed) % 1f
            val actualY = if (yPos < 0) 1f + yPos else yPos
            drawCircle(
                color = Color.White.copy(alpha = p.alpha),
                radius = p.size,
                center = Offset(p.x * size.width, actualY * size.height),
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// PERMISSION RATIONALE — dialog content
// ═══════════════════════════════════════════════════════════════

@Composable
private fun PermissionRationaleContent(
    onDismiss: () -> Unit,
    onGrant: () -> Unit,
) {
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Storage Permission Required") },
        text = {
            Text("TitanFileManager needs storage access to browse, search, and manage your files. Your data stays on your device — we never upload it.")
        },
        confirmButton = {
            Button(onClick = onGrant) { Text("Grant Access") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Not Now") }
        },
    )
}

// ═══════════════════════════════════════════════════════════════
// DATA CLASS — slide content
// ═══════════════════════════════════════════════════════════════

private data class OnboardingSlideData(
    val title: String,
    val subtitle: String,
    val description: String,
    val gradientColors: List<Color>,
    val icon: ImageVector,
    val features: List<String>,
)

private data class ParticleData(
    val x: Float,
    val y: Float,
    val size: Float,
    val speed: Float,
    val alpha: Float,
)


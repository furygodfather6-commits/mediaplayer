package com.titan.filemanager.core.ui.lock.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.titan.filemanager.core.ui.contracts.AppLockContract
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * AppLockViewModel — manages PIN + biometric authentication via [AppLockContract].
 *
 * Security features:
 *  - Constant-time PIN comparison (via contract implementation)
 *  - Lockout after 5 failed attempts (biometric-only mode)
 *  - 2-second error display before clearing
 *  - Encrypted PIN storage (handled by contract implementation)
 */
@HiltViewModel
class AppLockViewModel @Inject constructor(
    private val appLock: AppLockContract,
) : ViewModel() {

    private val _state = MutableStateFlow(AppLockUiState())
    val state: StateFlow<AppLockUiState> = _state.asStateFlow()

    init {
        // Check if biometric is available on this device
        viewModelScope.launch {
            try {
                val biometricAvailable = appLock.isBiometricAvailable()
                _state.update { it.copy(useBiometric = biometricAvailable) }
            } catch (_: Throwable) {
                _state.update { it.copy(useBiometric = false) }
            }
        }
    }

    /**
     * Verify a PIN entry against the stored PIN.
     * Uses constant-time comparison via [AppLockContract.verifyPin].
     */
    fun verifyPin(enteredPin: String) {
        viewModelScope.launch {
            _state.update { it.copy(isVerifying = true) }

            // Simulate verification delay (prevents timing attacks)
            delay(300)

            val isCorrect = try {
                appLock.verifyPin(enteredPin)
            } catch (_: Throwable) {
                false
            }

            if (isCorrect) {
                _state.update {
                    it.copy(isVerifying = false, isUnlocked = true, error = null, failedAttempts = 0)
                }
            } else {
                val newFailedCount = _state.value.failedAttempts + 1
                _state.update {
                    it.copy(
                        isVerifying = false,
                        isUnlocked = false,
                        error = "Incorrect PIN. ${maxOf(0, MAX_ATTEMPTS - newFailedCount)} attempts remaining.",
                        failedAttempts = newFailedCount,
                    )
                }
                // Clear error after 2 seconds
                delay(2000)
                _state.update { it.copy(error = null) }
            }
        }
    }

    /**
     * Handle biometric authentication result.
     * @param success Whether biometric authentication succeeded.
     */
    fun onBiometricResult(success: Boolean) {
        if (success) {
            _state.update { it.copy(isUnlocked = true, error = null, failedAttempts = 0) }
        } else {
            _state.update {
                it.copy(
                    error = "Biometric authentication failed",
                    failedAttempts = it.failedAttempts + 1,
                )
            }
        }
    }

    /**
     * Switch between biometric and PIN modes.
     */
    fun switchToPinMode() {
        _state.update { it.copy(useBiometric = false, error = null) }
    }

    fun switchToBiometricMode() {
        _state.update { it.copy(useBiometric = true, error = null) }
    }

    /**
     * Check if too many failed attempts — lock out for security.
     * After [MAX_ATTEMPTS] failed attempts, force biometric-only mode.
     */
    val isLockedOut: Boolean
        get() = _state.value.failedAttempts >= MAX_ATTEMPTS

    companion object {
        /** Maximum failed PIN attempts before lockout. */
        const val MAX_ATTEMPTS = 5
    }
}

data class AppLockUiState(
    val useBiometric: Boolean = true,
    val isVerifying: Boolean = false,
    val isUnlocked: Boolean = false,
    val error: String? = null,
    val failedAttempts: Int = 0,
)

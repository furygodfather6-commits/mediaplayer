package com.titan.filemanager.core.ui.appearance.glass

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.titan.filemanager.core.datastore.appearance.BlurIntensity
import com.titan.filemanager.core.datastore.appearance.GlassFallback
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import com.titan.filemanager.core.ui.appearance.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GlassmorphismScreen(onBack: () -> Unit, viewModel: AdvancedAppearanceViewModel = hiltViewModel()) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val g = settings.glassmorphism
    Scaffold(
        topBar = { TopAppBar(title = { Text("Glassmorphism & Blur", fontWeight = FontWeight.SemiBold) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }) },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())) {
            SettingsToggle("Enable glassmorphism", "Frosted glass surfaces with backdrop blur (Android 12+)",
                g.enabled) { v -> viewModel.updateGlassmorphism { it.copy(enabled = v) } }
            if (g.enabled) {
                SettingsHorizontalDivider()
                SettingsRadioGroup("Blur Intensity", BlurIntensity.entries.map { "${it.label} (${it.dp}dp)" to it },
                    g.blurIntensity) { v -> viewModel.updateGlassmorphism { it.copy(blurIntensity = v) } }
                SettingsHorizontalDivider()
                SettingsIntSlider("Tint Opacity", g.tintOpacity, 0..100, "${g.tintOpacity}%") { v ->
                    viewModel.updateGlassmorphism { it.copy(tintOpacity = v) }
                }
                SettingsHorizontalDivider()
                SettingsToggle("Frosted app bar", "Apply blur to the top app bar", g.frostedAppBar) { v ->
                    viewModel.updateGlassmorphism { it.copy(frostedAppBar = v) }
                }
                SettingsToggle("Frosted bottom sheet", "Apply blur to bottom sheets", g.frostedBottomSheet) { v ->
                    viewModel.updateGlassmorphism { it.copy(frostedBottomSheet = v) }
                }
                SettingsToggle("Frosted dialog", "Apply blur to dialogs", g.frostedDialog) { v ->
                    viewModel.updateGlassmorphism { it.copy(frostedDialog = v) }
                }
                SettingsHorizontalDivider()
                SettingsRadioGroup("Fallback (pre-Android 12)", GlassFallback.entries.map { it.label to it },
                    g.fallback) { v -> viewModel.updateGlassmorphism { it.copy(fallback = v) } }
            }
            Spacer(Modifier.height(SpacingTokens.Xxl))
        }
    }
}

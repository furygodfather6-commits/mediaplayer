package com.titan.filemanager.core.ui.file

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.titan.filemanager.core.designsystem.icon.FileTypeIcon
import com.titan.filemanager.core.designsystem.modifier.bounceClick
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import com.titan.filemanager.core.model.file.FileItem
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Reusable file list item — shared across feature modules.
 *
 * Uses the design system's [FileTypeIcon] for extension-aware icons
 * with brand colors, and [bounceClick] for tactile feedback.
 *
 * Supports:
 *  - Selection indicator (checkbox)
 *  - File type icon with color
 *  - Name, size, date metadata
 *  - Click + long-click callbacks
 */
@Composable
fun FileListItem(
    item: FileItem,
    modifier: Modifier = Modifier,
    isSelected: Boolean = false,
    showThumbnail: Boolean = false,
    thumbnailContent: @Composable (() -> Unit)? = null,
    onClick: () -> Unit = {},
    onLongClick: () -> Unit = {},
) {
    val icon = if (item.isDirectory) FileTypeIcon.Folder
    else FileTypeIcon.fromPath(item.path)

    Row(
        modifier = modifier
            .fillMaxWidth()
            .bounceClick(onClick = onClick)
            .padding(horizontal = SpacingTokens.ScreenHorizontal, vertical = SpacingTokens.Sm),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // Selection indicator
        if (isSelected) {
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    Icons.Filled.Check,
                    contentDescription = "Selected",
                    tint = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(16.dp),
                )
            }
            Spacer(Modifier.size(SpacingTokens.Sm))
        }

        // Icon or thumbnail
        if (showThumbnail && thumbnailContent != null) {
            Box(modifier = Modifier.size(40.dp)) { thumbnailContent() }
        } else {
            Icon(
                icon.imageVector,
                contentDescription = null,
                modifier = Modifier.size(40.dp),
                tint = icon.color,
            )
        }

        Spacer(Modifier.size(SpacingTokens.Lg))

        // Name + metadata
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = item.name,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontWeight = if (item.isDirectory) FontWeight.Medium else FontWeight.Normal,
            )
            // Metadata line
            val dateStr = formatDate(item.modifiedAt)
            val sizeStr = if (item.isDirectory) null else formatSize(item.size)
            val metaText = listOfNotNull(sizeStr, dateStr).joinToString(" • ")
            if (metaText.isNotEmpty()) {
                Text(
                    text = metaText,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

private fun formatSize(bytes: Long): String = when {
    bytes <= 0 -> ""
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "${bytes / 1024} KB"
    bytes < 1024 * 1024 * 1024 -> String.format("%.1f MB", bytes / (1024.0 * 1024.0))
    else -> String.format("%.2f GB", bytes / (1024.0 * 1024.0 * 1024.0))
}

private fun formatDate(timestamp: Long): String {
    if (timestamp == 0L) return ""
    return SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(timestamp))
}

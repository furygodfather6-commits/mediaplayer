package com.titan.filemanager.core.ui.previews

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.Text
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.titan.filemanager.core.designsystem.component.TitanDeterminateProgressOverlay
import com.titan.filemanager.core.designsystem.component.TitanFileGridItem
import com.titan.filemanager.core.designsystem.component.TitanFileGridItemCompact
import com.titan.filemanager.core.designsystem.component.TitanFileTile
import com.titan.filemanager.core.designsystem.component.TitanInfoBadge
import com.titan.filemanager.core.designsystem.component.TitanFileInfoRow
import com.titan.filemanager.core.designsystem.component.TitanInlineSpinner
import com.titan.filemanager.core.designsystem.component.TitanLoadingDots
import com.titan.filemanager.core.designsystem.component.TitanProgressOverlay
import com.titan.filemanager.core.designsystem.component.TitanPulsingDot
import com.titan.filemanager.core.designsystem.component.TitanSkeletonCard
import com.titan.filemanager.core.designsystem.component.TitanSkeletonGridItem
import com.titan.filemanager.core.designsystem.component.TitanSkeletonItem
import com.titan.filemanager.core.designsystem.component.TitanSkeletonItemLarge
import com.titan.filemanager.core.designsystem.component.TitanSkeletonStorageHeader
import com.titan.filemanager.core.designsystem.component.TitanStorageBar
import com.titan.filemanager.core.designsystem.theme.TitanTheme
import com.titan.filemanager.core.designsystem.theme.TitanThemeConfig

/**
 * ## DesignSystemPreviews
 *
 * @Preview composables for the TitanFileManager design system components.
 * Lets designers verify component appearance in isolation without running
 * the full app.
 */

// ═══════════════════════════════════════════════════════════════
// SKELETON LOADING COMPONENTS
// ═══════════════════════════════════════════════════════════════

@Preview(name = "Skeleton — List Item", showBackground = true, widthDp = 360, heightDp = 80)
@Composable
private fun TitanSkeletonItemPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        TitanSkeletonItem()
    }
}

@Preview(name = "Skeleton — Large Item", showBackground = true, widthDp = 360, heightDp = 100)
@Composable
private fun TitanSkeletonItemLargePreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        TitanSkeletonItemLarge()
    }
}

@Preview(name = "Skeleton — Grid Item", showBackground = true, widthDp = 120, heightDp = 140)
@Composable
private fun TitanSkeletonGridItemPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        TitanSkeletonGridItem()
    }
}

@Preview(name = "Skeleton — Card", showBackground = true, widthDp = 360, heightDp = 120)
@Composable
private fun TitanSkeletonCardPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        TitanSkeletonCard()
    }
}

@Preview(name = "Skeleton — Storage Header", showBackground = true, widthDp = 360, heightDp = 80)
@Composable
private fun TitanSkeletonStorageHeaderPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        TitanSkeletonStorageHeader()
    }
}

// ═══════════════════════════════════════════════════════════════
// STORAGE BAR + LEGEND
// ═══════════════════════════════════════════════════════════════

@Preview(name = "Storage Bar — 37% used", showBackground = true, widthDp = 360)
@Composable
private fun TitanStorageBarPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.padding(16.dp)) {
            TitanStorageBar(
                segments = listOf(
                    com.titan.filemanager.core.designsystem.component.StorageSegment("Images", 4.2f, androidx.compose.ui.graphics.Color(0xFF7C4DFF)),
                    com.titan.filemanager.core.designsystem.component.StorageSegment("Videos", 12.1f, androidx.compose.ui.graphics.Color(0xFFE91E63)),
                    com.titan.filemanager.core.designsystem.component.StorageSegment("Other", 5.4f, androidx.compose.ui.graphics.Color(0xFF9E9E9E)),
                ),
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// INFO BADGE + FILE INFO ROW
// ═══════════════════════════════════════════════════════════════

@Preview(name = "Info Badge", showBackground = true)
@Composable
private fun TitanInfoBadgePreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.padding(16.dp)) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                TitanInfoBadge(text = "Synced", color = androidx.compose.ui.graphics.Color(0xFF4CAF50), icon = Icons.Filled.Cloud)
                TitanInfoBadge(text = "Bookmarked", color = androidx.compose.ui.graphics.Color(0xFFFFC107), icon = Icons.Filled.Star)
                TitanInfoBadge(text = "Modified 2h ago", color = androidx.compose.ui.graphics.Color(0xFF2196F3), icon = Icons.Filled.Schedule)
            }
        }
    }
}

@Preview(name = "File Info Row", showBackground = true, widthDp = 360)
@Composable
private fun TitanFileInfoRowPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.padding(16.dp)) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                TitanFileInfoRow(label = "Size", value = "2.4 MB", icon = Icons.Filled.Storage)
                TitanFileInfoRow(label = "Modified", value = "Jul 04, 2026 at 14:30", icon = Icons.Filled.Schedule)
                TitanFileInfoRow(label = "Path", value = "/storage/emulated/0/Documents/report.pdf", icon = Icons.Filled.Cloud)
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// PROGRESS OVERLAYS
// ═══════════════════════════════════════════════════════════════

@Preview(name = "Progress Overlay — Indeterminate", showBackground = true, widthDp = 360, heightDp = 200)
@Composable
private fun TitanProgressOverlayPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        TitanProgressOverlay(message = "Loading files...")
    }
}

@Preview(name = "Progress Overlay — Determinate", showBackground = true, widthDp = 360, heightDp = 200)
@Composable
private fun TitanDeterminateProgressOverlayPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        TitanDeterminateProgressOverlay(
            progress = 0.65f,
            message = "Copying 65 of 100 files...",
        )
    }
}

// ═══════════════════════════════════════════════════════════════
// LOADING INDICATORS
// ═══════════════════════════════════════════════════════════════

@Preview(name = "Loading Dots", showBackground = true)
@Composable
private fun TitanLoadingDotsPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.padding(32.dp)) {
            TitanLoadingDots()
        }
    }
}

@Preview(name = "Pulsing Dot", showBackground = true)
@Composable
private fun TitanPulsingDotPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.padding(32.dp)) {
            TitanPulsingDot()
        }
    }
}

@Preview(name = "Inline Spinner", showBackground = true)
@Composable
private fun TitanInlineSpinnerPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.padding(32.dp)) {
            TitanInlineSpinner()
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// FILE TILE + GRID ITEM
// ═══════════════════════════════════════════════════════════════

@Preview(name = "File Tile — Folder", showBackground = true, widthDp = 360)
@Composable
private fun TitanFileTileFolderPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.padding(8.dp)) {
            TitanFileTile(
                name = "Documents",
                isDirectory = true,
                path = "/sdcard/Documents",
                childCount = "12 items",
                date = "Jul 04, 2026",
            )
        }
    }
}

@Preview(name = "File Tile — Image", showBackground = true, widthDp = 360)
@Composable
private fun TitanFileTileImagePreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.padding(8.dp)) {
            TitanFileTile(
                name = "photo.jpg",
                isDirectory = false,
                path = "/sdcard/DCIM/photo.jpg",
                size = "2.4 MB",
                date = "Jul 04, 2026",
            )
        }
    }
}

@Preview(name = "File Grid Item — Compact", showBackground = true, widthDp = 120, heightDp = 140)
@Composable
private fun TitanFileGridItemCompactPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        TitanFileGridItemCompact(
            name = "doc.pdf",
            path = "/sdcard/doc.pdf",
        )
    }
}

// ═══════════════════════════════════════════════════════════════
// COMPONENT GALLERY — all components in one preview
// ═══════════════════════════════════════════════════════════════

@Preview(name = "Component Gallery", showBackground = true, widthDp = 400, heightDp = 800)
@Composable
private fun ComponentGalleryPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Column(
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                Text("Skeleton Items", style = androidx.compose.material3.MaterialTheme.typography.titleMedium)
                TitanSkeletonItem()
                TitanSkeletonItemLarge()

                Text("Storage Bar", style = androidx.compose.material3.MaterialTheme.typography.titleMedium)
                TitanStorageBar(
                    segments = listOf(
                        com.titan.filemanager.core.designsystem.component.StorageSegment("Images", 4.2f, androidx.compose.ui.graphics.Color(0xFF7C4DFF)),
                        com.titan.filemanager.core.designsystem.component.StorageSegment("Videos", 12.1f, androidx.compose.ui.graphics.Color(0xFFE91E63)),
                    ),
                )

                Text("Info Badges", style = androidx.compose.material3.MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TitanInfoBadge(text = "Synced", color = androidx.compose.ui.graphics.Color(0xFF4CAF50), icon = Icons.Filled.Cloud)
                    TitanInfoBadge(text = "Starred", color = androidx.compose.ui.graphics.Color(0xFFFFC107), icon = Icons.Filled.Star)
                }

                Text("Loading Dots", style = androidx.compose.material3.MaterialTheme.typography.titleMedium)
                TitanLoadingDots()
            }
        }
    }
}


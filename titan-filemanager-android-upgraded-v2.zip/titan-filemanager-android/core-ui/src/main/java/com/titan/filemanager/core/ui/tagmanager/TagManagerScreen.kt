package com.titan.filemanager.core.ui.tagmanager

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Label
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import com.titan.filemanager.core.designsystem.modifier.bounceClick
import com.titan.filemanager.core.designsystem.modifier.clipToCircle
import com.titan.filemanager.core.designsystem.modifier.clipToRounded
import com.titan.filemanager.core.designsystem.tokens.ElevationTokens
import com.titan.filemanager.core.designsystem.tokens.ShapeTokens
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens

/**
 * ## TagManagerScreen
 *
 * Enterprise tag management — full CRUD for user-defined tags with color coding,
 * emoji icons, usage counts, and bulk file assignment.
 *
 * ### Layout Anatomy
 * ```
 * ┌────────────────────────────────────────────┐
 * │ ←  Tag Manager                  [+ New]    │  TopAppBar
 * ├────────────────────────────────────────────┤
 * │ 🔍 Search tags...                          │  Search field
 * ├────────────────────────────────────────────┤
 * │ ┌──────────────────────────────────────┐   │
 * │ │ 🟥 Important              12 files   │   │
 * │ │    Red color • Last used 2h ago      │   │
 * │ │    [Edit] [Delete]                  │   │
 * │ └──────────────────────────────────────┘   │
 * │ ┌──────────────────────────────────────┐   │
 * │ │ 🟦 Work                    8 files   │   │
 * │ │    Blue color • Last used 1d ago     │   │
 * │ │    [Edit] [Delete]                  │   │
 * │ └──────────────────────────────────────┘   │
 * └────────────────────────────────────────────┘
 * ```
 *
 * ### Tag Properties
 * Each tag has:
 *  - **Name** — display name (1-30 chars, unique)
 *  - **Color** — Material 3 color from preset palette (8 colors)
 *  - **Icon** — emoji or built-in icon (Label, Star, Bookmark, LocalOffer)
 *  - **Usage count** — number of files with this tag (read-only)
 *  - **Last used** — timestamp of last file assignment (read-only)
 *
 * @param tags list of existing tags.
 * @param onBack callback to navigate back.
 * @param onCreateTag callback when a new tag is created.
 * @param onUpdateTag callback when an existing tag is updated.
 * @param onDeleteTag callback when a tag is deleted (returns true if confirmed).
 * @param onTagClick callback when a tag is tapped (typically navigates to files with that tag).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TagManagerScreen(
    tags: List<Tag>,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    onCreateTag: (Tag) -> Unit = {},
    onUpdateTag: (Tag) -> Unit = {},
    onDeleteTag: (Tag) -> Unit = {},
    onTagClick: (Tag) -> Unit = {},
) {
    var showCreateDialog by remember { mutableStateOf(false) }
    var editingTag by remember { mutableStateOf<Tag?>(null) }
    var searchQuery by remember { mutableStateOf("") }

    val filteredTags = remember(tags, searchQuery) {
        if (searchQuery.isBlank()) tags
        else tags.filter { it.name.contains(searchQuery, ignoreCase = true) }
    }

    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Tag Manager", fontWeight = FontWeight.SemiBold)
                        Text(
                            text = "${tags.size} tags • ${tags.sumOf { it.fileCount }} tagged files",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                ),
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showCreateDialog = true },
                icon = { Icon(Icons.Filled.Add, "New tag") },
                text = { Text("New Tag") },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
        ) {
            // ═══════════════════════════════════════════════════════
            // SEARCH BAR
            // ═══════════════════════════════════════════════════════
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = SpacingTokens.ScreenHorizontal, vertical = SpacingTokens.Sm),
                placeholder = { Text("Search tags...") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true,
                shape = ShapeTokens.Full,
            )

            // ═══════════════════════════════════════════════════════
            // COLOR PALETTE QUICK FILTER (optional)
            // ═══════════════════════════════════════════════════════
            ColorPaletteQuickFilter(
                tags = filteredTags,
                onTagClick = onTagClick,
                onEditTag = { editingTag = it },
                onDeleteTag = onDeleteTag,
            )

            // ═══════════════════════════════════════════════════════
            // TAG LIST
            // ═══════════════════════════════════════════════════════
            if (filteredTags.isEmpty()) {
                EmptyTagsState(hasTags = tags.isNotEmpty())
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(
                        horizontal = SpacingTokens.ScreenHorizontal,
                        vertical = SpacingTokens.Md,
                    ),
                    verticalArrangement = Arrangement.spacedBy(SpacingTokens.Sm),
                ) {
                    items(filteredTags, key = { it.id }) { tag ->
                        TagCard(
                            tag = tag,
                            onClick = { onTagClick(tag) },
                            onEdit = { editingTag = tag },
                            onDelete = { onDeleteTag(tag) },
                        )
                    }
                }
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // CREATE / EDIT DIALOGS
    // ═══════════════════════════════════════════════════════════════
    if (showCreateDialog) {
        TagEditorDialog(
            existingTag = null,
            existingNames = tags.map { it.name },
            onDismiss = { showCreateDialog = false },
            onConfirm = { newTag ->
                onCreateTag(newTag)
                showCreateDialog = false
            },
        )
    }
    editingTag?.let { tag ->
        TagEditorDialog(
            existingTag = tag,
            existingNames = tags.filter { it.id != tag.id }.map { it.name },
            onDismiss = { editingTag = null },
            onConfirm = { updated ->
                onUpdateTag(updated)
                editingTag = null
            },
        )
    }
}

// ═══════════════════════════════════════════════════════════════
// COLOR PALETTE QUICK FILTER
// ═══════════════════════════════════════════════════════════════

@Composable
private fun ColorPaletteQuickFilter(
    tags: List<Tag>,
    onTagClick: (Tag) -> Unit,
    onEditTag: (Tag) -> Unit,
    onDeleteTag: (Tag) -> Unit,
) {
    val colorCounts = tags.groupBy { it.color }
        .mapValues { (_, list) -> list.size to list.sumOf { it.fileCount } }
    LazyRow(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = SpacingTokens.Xs),
        contentPadding = PaddingValues(horizontal = SpacingTokens.ScreenHorizontal),
        horizontalArrangement = Arrangement.spacedBy(SpacingTokens.Xs),
    ) {
        items(TagColor.entries.toList()) { color ->
            val (tagCount, fileCount) = colorCounts[color] ?: (0 to 0)
            if (tagCount > 0) {
                ColorSummaryChip(
                    color = color,
                    tagCount = tagCount,
                    fileCount = fileCount,
                )
            }
        }
    }
}

@Composable
private fun ColorSummaryChip(
    color: TagColor,
    tagCount: Int,
    fileCount: Int,
) {
    Surface(
        modifier = Modifier.height(40.dp),
        shape = ShapeTokens.Full,
        color = color.value.copy(alpha = 0.15f),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = SpacingTokens.Md, vertical = SpacingTokens.Xs),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier
                    .size(12.dp)
                    .clipToCircle()
                    .background(color.value),
            )
            Spacer(Modifier.width(SpacingTokens.Xs))
            Text(
                text = "$tagCount tags",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Medium,
                color = color.value,
            )
            Spacer(Modifier.width(SpacingTokens.Xs))
            Text(
                text = "• $fileCount files",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// TAG CARD
// ═══════════════════════════════════════════════════════════════

@Composable
private fun TagCard(
    tag: Tag,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .bounceClick(onClick = onClick),
        shape = ShapeTokens.Medium,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = ElevationTokens.Level1),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(SpacingTokens.Md),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            // Color dot + icon
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clipToCircle()
                    .background(
                        brush = Brush.linearGradient(
                            listOf(tag.color.value, tag.color.value.copy(alpha = 0.6f)),
                        ),
                    ),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = tag.icon.icon,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(24.dp),
                )
            }

            Spacer(Modifier.width(SpacingTokens.Md))

            // Tag info
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = tag.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                val subtitle = buildAnnotatedString {
                    withStyle(SpanStyle(color = tag.color.value, fontWeight = FontWeight.Medium)) {
                        append(tag.color.label)
                    }
                    append(" • ${tag.fileCount} files")
                    if (tag.lastUsedAt > 0) {
                        append(" • ${formatRelativeTime(tag.lastUsedAt)}")
                    }
                }
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }

            // Actions
            IconButton(onClick = onEdit) {
                Icon(Icons.Filled.Edit, "Edit", tint = MaterialTheme.colorScheme.primary)
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Filled.Delete, "Delete", tint = MaterialTheme.colorScheme.error)
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// TAG EDITOR DIALOG
// ═══════════════════════════════════════════════════════════════

@Composable
private fun TagEditorDialog(
    existingTag: Tag?,
    existingNames: List<String>,
    onDismiss: () -> Unit,
    onConfirm: (Tag) -> Unit,
) {
    var name by remember { mutableStateOf(existingTag?.name ?: "") }
    var selectedColor by remember { mutableStateOf(existingTag?.color ?: TagColor.RED) }
    var selectedIcon by remember { mutableStateOf(existingTag?.icon ?: TagIcon.LABEL) }
    var nameError by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (existingTag == null) "Create Tag" else "Edit Tag",
                fontWeight = FontWeight.SemiBold,
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(SpacingTokens.Md),
            ) {
                // Preview
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clipToCircle()
                            .background(
                                brush = Brush.linearGradient(
                                    listOf(selectedColor.value, selectedColor.value.copy(alpha = 0.6f)),
                                ),
                            ),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            imageVector = selectedIcon.icon,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(32.dp),
                        )
                    }
                }

                // Name field
                OutlinedTextField(
                    value = name,
                    onValueChange = {
                        name = it
                        nameError = when {
                            it.isBlank() -> "Name is required"
                            it.length > 30 -> "Name too long (max 30)"
                            it in existingNames -> "Name already in use"
                            else -> null
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Tag Name") },
                    singleLine = true,
                    isError = nameError != null,
                    supportingText = nameError?.let { err -> { Text(err) } },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = {
                        if (nameError == null && name.isNotBlank()) {
                            onConfirm(
                                Tag(
                                    id = existingTag?.id ?: System.currentTimeMillis().toString(),
                                    name = name.trim(),
                                    color = selectedColor,
                                    icon = selectedIcon,
                                    fileCount = existingTag?.fileCount ?: 0,
                                    lastUsedAt = existingTag?.lastUsedAt ?: 0L,
                                ),
                            )
                        }
                    }),
                )

                // Color picker
                Text("Color", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Medium)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(SpacingTokens.Sm),
                ) {
                    TagColor.entries.forEach { color ->
                        ColorSwatch(
                            color = color,
                            isSelected = selectedColor == color,
                            onClick = { selectedColor = color },
                        )
                    }
                }

                // Icon picker
                Text("Icon", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Medium)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(SpacingTokens.Sm),
                ) {
                    TagIcon.entries.forEach { icon ->
                        IconPickerItem(
                            icon = icon,
                            isSelected = selectedIcon == icon,
                            color = selectedColor,
                            onClick = { selectedIcon = icon },
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    if (nameError == null && name.isNotBlank()) {
                        onConfirm(
                            Tag(
                                id = existingTag?.id ?: System.currentTimeMillis().toString(),
                                name = name.trim(),
                                color = selectedColor,
                                icon = selectedIcon,
                                fileCount = existingTag?.fileCount ?: 0,
                                lastUsedAt = existingTag?.lastUsedAt ?: 0L,
                            ),
                        )
                    }
                },
                enabled = nameError == null && name.isNotBlank(),
            ) {
                Text(if (existingTag == null) "Create" else "Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
    )
}

@Composable
private fun ColorSwatch(
    color: TagColor,
    isSelected: Boolean,
    onClick: () -> Unit,
) {
    Box(
        modifier = Modifier
            .size(36.dp)
            .bounceClick(onClick = onClick)
            .clipToCircle()
            .background(color.value),
        contentAlignment = Alignment.Center,
    ) {
        if (isSelected) {
            Icon(
                Icons.Filled.Check,
                contentDescription = "Selected",
                tint = Color.White,
                modifier = Modifier.size(20.dp),
            )
        }
    }
}

@Composable
private fun IconPickerItem(
    icon: TagIcon,
    isSelected: Boolean,
    color: TagColor,
    onClick: () -> Unit,
) {
    Box(
        modifier = Modifier
            .size(40.dp)
            .bounceClick(onClick = onClick)
            .clip(ShapeTokens.Medium)
            .background(
                if (isSelected) color.value.copy(alpha = 0.2f)
                else MaterialTheme.colorScheme.surfaceContainerHigh,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = icon.icon,
            contentDescription = icon.label,
            tint = if (isSelected) color.value else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(20.dp),
        )
    }
}

// ═══════════════════════════════════════════════════════════════
// EMPTY STATE
// ═══════════════════════════════════════════════════════════════

@Composable
private fun EmptyTagsState(hasTags: Boolean) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(SpacingTokens.Xxl),
        ) {
            Icon(
                imageVector = Icons.Filled.Label,
                contentDescription = null,
                modifier = Modifier.size(96.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
            )
            Spacer(Modifier.height(SpacingTokens.Lg))
            Text(
                text = if (hasTags) "No matching tags" else "No tags yet",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.SemiBold,
            )
            Spacer(Modifier.height(SpacingTokens.Xs))
            Text(
                text = if (hasTags) "Try a different search query."
                       else "Tags help you organize files across folders.\nTap \"New Tag\" to create your first one.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// DATA MODELS
// ═══════════════════════════════════════════════════════════════

/**
 * A user-defined tag.
 */
data class Tag(
    val id: String,
    val name: String,
    val color: TagColor,
    val icon: TagIcon,
    val fileCount: Int = 0,
    val lastUsedAt: Long = 0L,
)

/**
 * Preset tag colors — 8-color palette aligned with Material 3 expressive colors.
 */
enum class TagColor(val value: Color, val label: String) {
    RED(Color(0xFFEF4444), "Red"),
    ORANGE(Color(0xFFF97316), "Orange"),
    AMBER(Color(0xFFF59E0B), "Amber"),
    GREEN(Color(0xFF22C55E), "Green"),
    TEAL(Color(0xFF14B8A6), "Teal"),
    BLUE(Color(0xFF3B82F6), "Blue"),
    PURPLE(Color(0xFF8B5CF6), "Purple"),
    PINK(Color(0xFFEC4899), "Pink"),
}

/**
 * Preset tag icons.
 */
enum class TagIcon(val icon: androidx.compose.ui.graphics.vector.ImageVector, val label: String) {
    LABEL(Icons.Filled.Label, "Label"),
    STAR(Icons.Filled.Star, "Star"),
    BOOKMARK(Icons.Filled.Bookmark, "Bookmark"),
    OFFER(Icons.Filled.LocalOffer, "Offer"),
}

// ═══════════════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════════════

private fun formatRelativeTime(timestamp: Long): String {
    val now = System.currentTimeMillis()
    val diff = now - timestamp
    return when {
        diff < 60_000 -> "Just now"
        diff < 3_600_000 -> "${diff / 60_000}m ago"
        diff < 86_400_000 -> "${diff / 3_600_000}h ago"
        diff < 7 * 86_400_000L -> "${diff / 86_400_000}d ago"
        else -> "${diff / (7 * 86_400_000L)}w ago"
    }
}

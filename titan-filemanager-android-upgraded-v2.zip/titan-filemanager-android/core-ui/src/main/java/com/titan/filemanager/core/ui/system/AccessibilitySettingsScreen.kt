package com.titan.filemanager.core.ui.system

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.titan.filemanager.core.datastore.system.ColorBlindMode
import com.titan.filemanager.core.datastore.system.ContentDescriptionLevel
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import com.titan.filemanager.core.ui.appearance.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccessibilitySettingsScreen(onBack: () -> Unit, viewModel: AdvancedSystemViewModel = hiltViewModel()) {
    val s by viewModel.settings.collectAsStateWithLifecycle()
    val a = s.accessibility
    Scaffold(topBar = { TopAppBar(title = { Text("Accessibility", fontWeight = FontWeight.SemiBold) },
        navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())) {
            SettingsToggle("High contrast mode", "Thickens borders and focus rings", a.highContrast) { b -> viewModel.updateAccessibility { it.copy(highContrast = b) } }
            SettingsHorizontalDivider()
            SettingsSlider("Font Scale", a.fontScale, 0.85f..2.0f, 22, "${(a.fontScale * 100).toInt()}%") { v -> viewModel.updateAccessibility { it.copy(fontScale = v) } }
            SettingsIntSlider("Min Touch Target", a.minTouchTargetDp, 44..72, "${a.minTouchTargetDp}dp") { v -> viewModel.updateAccessibility { it.copy(minTouchTargetDp = v) } }
            SettingsHorizontalDivider()
            SettingsToggle("Reduced motion", "Disable all animations", a.reducedMotion) { b -> viewModel.updateAccessibility { it.copy(reducedMotion = b) } }
            SettingsToggle("Vestibular safe mode", "Max 200ms, no flash > 3Hz", a.vestibularSafe) { b -> viewModel.updateAccessibility { it.copy(vestibularSafe = b) } }
            SettingsHorizontalDivider()
            SettingsIntSlider("Focus ring thickness", a.focusRingThicknessDp, 1..3, "${a.focusRingThicknessDp}dp") { v -> viewModel.updateAccessibility { it.copy(focusRingThicknessDp = v) } }
            SettingsToggle("Auto focus ring color", "Auto-pick contrasting color", a.focusRingColorAuto) { b -> viewModel.updateAccessibility { it.copy(focusRingColorAuto = b) } }
            SettingsHorizontalDivider()
            SettingsToggle("Screen reader announcements", "Announce state changes via TalkBack", a.screenReaderAnnouncements) { b -> viewModel.updateAccessibility { it.copy(screenReaderAnnouncements = b) } }
            SettingsRadioGroup("Content description level", ContentDescriptionLevel.entries.map { it.label to it }, a.contentDescriptionLevel) { v -> viewModel.updateAccessibility { it.copy(contentDescriptionLevel = v) } }
            SettingsHorizontalDivider()
            SettingsRadioGroup("Color blind mode", ColorBlindMode.entries.map { it.label to it }, a.colorBlindMode) { v -> viewModel.updateAccessibility { it.copy(colorBlindMode = v) } }
            Spacer(Modifier.height(SpacingTokens.Xxl))
        }
    }
}

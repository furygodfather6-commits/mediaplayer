package com.titan.filemanager.core.ui.system

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.titan.filemanager.core.datastore.system.*
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import com.titan.filemanager.core.ui.appearance.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FileBrowserSettingsScreen(onBack: () -> Unit, viewModel: AdvancedSystemViewModel = hiltViewModel()) {
    val s by viewModel.settings.collectAsStateWithLifecycle()
    val fb = s.fileBrowser
    Scaffold(topBar = { TopAppBar(title = { Text("File Browser & Display", fontWeight = FontWeight.SemiBold) },
        navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())) {
            SettingsRadioGroup("Default View Mode", ViewModePref.entries.map { it.label to it }, fb.defaultViewMode) { v -> viewModel.updateFileBrowser { it.copy(defaultViewMode = v) } }
            SettingsHorizontalDivider()
            SettingsRadioGroup("Default Sort Field", SortFieldPref.entries.map { it.label to it }, fb.defaultSortField) { v -> viewModel.updateFileBrowser { it.copy(defaultSortField = v) } }
            SettingsRadioGroup("Default Sort Order", SortOrderPref.entries.map { it.label to it }, fb.defaultSortOrder) { v -> viewModel.updateFileBrowser { it.copy(defaultSortOrder = v) } }
            SettingsHorizontalDivider()
            SettingsToggle("Directories first", "Always show folders above files", fb.directoriesFirst) { b -> viewModel.updateFileBrowser { it.copy(directoriesFirst = b) } }
            SettingsToggle("Show hidden files", "Files and folders starting with a dot", fb.showHiddenFiles) { b -> viewModel.updateFileBrowser { it.copy(showHiddenFiles = b) } }
            SettingsToggle("Show file extensions", "Display .jpg, .pdf, etc.", fb.showFileExtensions) { b -> viewModel.updateFileBrowser { it.copy(showFileExtensions = b) } }
            SettingsToggle("Show file sizes", "Display size in list/grid", fb.showFileSizes) { b -> viewModel.updateFileBrowser { it.copy(showFileSizes = b) } }
            SettingsToggle("Show modification dates", "Display last modified date", fb.showModificationDates) { b -> viewModel.updateFileBrowser { it.copy(showModificationDates = b) } }
            SettingsToggle("Show file thumbnails", "Generate and display image/video thumbnails", fb.showFileThumbnails) { b -> viewModel.updateFileBrowser { it.copy(showFileThumbnails = b) } }
            SettingsHorizontalDivider()
            SettingsRadioGroup("Thumbnail Size", ThumbnailSizePref.entries.map { it.label to it }, fb.thumbnailSize) { v -> viewModel.updateFileBrowser { it.copy(thumbnailSize = v) } }
            SettingsHorizontalDivider()
            SettingsToggle("Show breadcrumb bar", "Display path navigation breadcrumbs", fb.showBreadcrumbBar) { b -> viewModel.updateFileBrowser { it.copy(showBreadcrumbBar = b) } }
            SettingsToggle("Show storage bar in browser", "Display storage usage at top of browser", fb.showStorageBarInBrowser) { b -> viewModel.updateFileBrowser { it.copy(showStorageBarInBrowser = b) } }
            SettingsToggle("Remember last folder", "Open last visited folder on launch", fb.rememberLastFolder) { b -> viewModel.updateFileBrowser { it.copy(rememberLastFolder = b) } }
            SettingsToggle("Show bookmark indicators", "Show star icon on bookmarked files", fb.showBookmarkIndicators) { b -> viewModel.updateFileBrowser { it.copy(showBookmarkIndicators = b) } }
            Spacer(Modifier.height(SpacingTokens.Xxl))
        }
    }
}

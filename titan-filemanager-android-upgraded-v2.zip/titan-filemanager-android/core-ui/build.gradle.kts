// :core:ui — shared Compose components
plugins {
    id("titan.android.library")
    id("titan.android.compose")
    id("titan.android.hilt")
}

android {
    namespace = "com.titan.filemanager.core.ui"
}

dependencies {
    api(project(":core:designsystem"))
    api(project(":core:model"))
    api(project(":core:datastore"))
    api(libs.coil.compose)

    // Hilt + Lifecycle for ViewModels
    implementation(libs.androidx.hilt.navigation.compose)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.timber)
    implementation(libs.kotlinx.serialization.json)

    // Wear OS Compose (for WearViewerScreen)
    implementation(libs.androidx.wear.compose.foundation)
    implementation(libs.androidx.wear.compose.material)

    // Testing
    testImplementation(project(":core:testing"))
    testImplementation(libs.junit5)
    testImplementation(libs.truth)
    testImplementation(libs.mockk)
    testImplementation(libs.turbine)
    testImplementation(libs.kotlinx.coroutines.test)
}

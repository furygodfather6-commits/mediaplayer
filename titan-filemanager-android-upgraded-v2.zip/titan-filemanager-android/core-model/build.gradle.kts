// :core:model — pure Kotlin data models (Android library for module compat)
plugins {
    id("titan.android.library")
    alias(libs.plugins.kotlin.serialization)
}

android {
    namespace = "com.titan.filemanager.core.model"
}

dependencies {
    // kotlinx-serialization for @Serializable data classes
    implementation(libs.kotlinx.serialization.json)
    implementation(libs.kotlinx.datetime)

    testImplementation(libs.junit5)
    testImplementation(libs.truth)
}

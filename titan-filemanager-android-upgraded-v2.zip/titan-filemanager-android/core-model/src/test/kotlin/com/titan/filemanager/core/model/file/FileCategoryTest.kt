package com.titan.filemanager.core.model.file

import com.google.common.truth.Truth.assertThat
import org.junit.jupiter.api.Test

class FileCategoryTest {

    @Test
    fun `fromMimeType image returns PHOTO`() {
        assertThat(FileCategory.fromMimeType("image/jpeg")).isEqualTo(FileCategory.PHOTO)
        assertThat(FileCategory.fromMimeType("image/png")).isEqualTo(FileCategory.PHOTO)
    }

    @Test
    fun `fromMimeType video returns VIDEO`() {
        assertThat(FileCategory.fromMimeType("video/mp4")).isEqualTo(FileCategory.VIDEO)
    }

    @Test
    fun `fromMimeType audio returns AUDIO`() {
        assertThat(FileCategory.fromMimeType("audio/mpeg")).isEqualTo(FileCategory.AUDIO)
    }

    @Test
    fun `fromMimeType application pdf returns DOCUMENT`() {
        assertThat(FileCategory.fromMimeType("application/pdf")).isEqualTo(FileCategory.DOCUMENT)
    }

    @Test
    fun `fromMimeType application zip returns ARCHIVE`() {
        assertThat(FileCategory.fromMimeType("application/zip")).isEqualTo(FileCategory.ARCHIVE)
        assertThat(FileCategory.fromMimeType("application/x-rar-compressed")).isEqualTo(FileCategory.ARCHIVE)
        assertThat(FileCategory.fromMimeType("application/x-7z-compressed")).isEqualTo(FileCategory.ARCHIVE)
    }

    @Test
    fun `fromMimeType application apk returns APP_PACKAGE`() {
        assertThat(FileCategory.fromMimeType("application/vnd.android.package-archive"))
            .isEqualTo(FileCategory.APP_PACKAGE)
    }

    @Test
    fun `fromMimeType null returns OTHER`() {
        assertThat(FileCategory.fromMimeType(null)).isEqualTo(FileCategory.OTHER)
    }

    @Test
    fun `fromMimeType unknown returns OTHER`() {
        assertThat(FileCategory.fromMimeType("foo/bar")).isEqualTo(FileCategory.OTHER)
    }

    @Test
    fun `fromExtension jpg returns PHOTO`() {
        assertThat(FileCategory.fromExtension("jpg")).isEqualTo(FileCategory.PHOTO)
        assertThat(FileCategory.fromExtension("JPG")).isEqualTo(FileCategory.PHOTO)
    }

    @Test
    fun `fromExtension mp4 returns VIDEO`() {
        assertThat(FileCategory.fromExtension("mp4")).isEqualTo(FileCategory.VIDEO)
    }

    @Test
    fun `fromExtension kt returns CODE`() {
        assertThat(FileCategory.fromExtension("kt")).isEqualTo(FileCategory.CODE)
        assertThat(FileCategory.fromExtension("java")).isEqualTo(FileCategory.CODE)
        assertThat(FileCategory.fromExtension("py")).isEqualTo(FileCategory.CODE)
    }

    @Test
    fun `fromExtension apk returns APP_PACKAGE`() {
        assertThat(FileCategory.fromExtension("apk")).isEqualTo(FileCategory.APP_PACKAGE)
    }

    @Test
    fun `fromExtension unknown returns OTHER`() {
        assertThat(FileCategory.fromExtension("xyz")).isEqualTo(FileCategory.OTHER)
    }

    @Test
    fun `fromExtension empty returns OTHER`() {
        assertThat(FileCategory.fromExtension("")).isEqualTo(FileCategory.OTHER)
    }
}

package com.titan.filemanager.core.model.file

/**
 * Type of a filesystem entry — used by the UI to pick the right icon
 * and to drive DiffUtil comparisons.
 */
sealed class FileType {
    /** Regular file (DT_REG). */
    data object Regular : FileType()
    /** Directory (DT_DIR). */
    data object Directory : FileType()
    /** Symbolic link (DT_LNK). */
    data object Symlink : FileType()
    /** Block device (DT_BLK). */
    data object BlockDevice : FileType()
    /** Character device (DT_CHR). */
    data object CharacterDevice : FileType()
    /** Named pipe / FIFO (DT_FIFO). */
    data object Fifo : FileType()
    /** Unix socket (DT_SOCK). */
    data object Socket : FileType()
    /** Unknown type (DT_UNKNOWN). */
    data object Unknown : FileType()

    companion object {
        /**
         * Convert a `d_type` byte from `getdents64` to a [FileType].
         *
         * DT_UNKNOWN (0) is the most common on Android — kernel doesn't
         * always populate it. Callers should fall back to `lstat()`
         * in that case.
         */
        fun fromDType(dType: Byte): FileType = when (dType.toInt() and 0xFF) {
            4 -> Directory
            6 -> BlockDevice
            2 -> CharacterDevice
            8 -> Regular
            1 -> Fifo
            10 -> Symlink
            12 -> Socket
            else -> Unknown
        }
    }
}

package com.titan.filemanager.core.model.scan

import com.titan.filemanager.core.model.file.FileItem

/**
 * State of a directory scan operation — sealed hierarchy so the UI can
 * pattern-match exhaustively without `else` branches.
 *
 * Emitted by `DirectoryScanEngine.scan(path): Flow<ScanState>` (Phase 2).
 * Consumed by [com.titan.filemanager.feature.browser.BrowserViewModel].
 */
sealed interface ScanState {

    /**
     * Idle — no scan has been started yet.
     */
    data object Idle : ScanState

    /**
     * Scan started — UI should show skeleton placeholders.
     *
     * @param estimatedCount An optional estimate of file count (0 if unknown).
     *        Used to size the skeleton list.
     */
    data class Starting(val estimatedCount: Int = 20) : ScanState

    /**
     * Scan in progress — emit partial items as they arrive.
     *
     * @param items Current batch of items.
     * @param phase Current [ScanPhase] — drives UI density.
     * @param current Number of files processed so far.
     * @param total Total files expected (0 if unknown).
     * @param rate Files per second (0 if unknown).
     */
    data class Progress(
        val items: List<FileItem>,
        val phase: ScanPhase,
        val current: Int = 0,
        val total: Int = 0,
        val rate: Float = 0f,
    ) : ScanState

    /**
     * Scan completed successfully.
     *
     * @param items Final list of files.
     * @param durationMs Total scan duration in milliseconds.
     */
    data class Complete(
        val items: List<FileItem>,
        val durationMs: Long,
    ) : ScanState

    /**
     * Scan cancelled by user. Includes a [ResumeToken] so it can be resumed.
     */
    data class Cancelled(val resumeToken: ResumeToken?) : ScanState

    /**
     * Scan failed with an error.
     *
     * Error type comes from `:core:common` (added in Phase 1).
     */
    data class Error(val message: String) : ScanState
}

/**
 * Phase of a progressive scan — drives UI density.
 *
 *  - MINIMAL → name + isDir only (~1µs per item)
 *  - BASIC   → + size, mtime, inode (~10µs per item, batched lstat)
 *  - FULL    → + MIME, permissions, EXIF, etc. (~50-200µs per item, async)
 */
enum class ScanPhase {
    MINIMAL,
    BASIC,
    FULL,
}

/**
 * Token used to resume a cancelled scan.
 *
 * Encoded as: `<path>|<lastInode>|<position>`.
 */
@kotlinx.serialization.Serializable
data class ResumeToken(
    val path: String,
    val lastInode: Long,
    val position: Int,
)

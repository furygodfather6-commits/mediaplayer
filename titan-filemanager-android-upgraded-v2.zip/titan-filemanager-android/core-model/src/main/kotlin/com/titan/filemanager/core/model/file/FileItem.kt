package com.titan.filemanager.core.model.file

import kotlinx.datetime.Instant
import kotlinx.serialization.Serializable

/**
 * The core file model used throughout the app.
 *
 * This is the **immutable** representation passed between data/domain/UI
 * layers. Mutability is opt-in via [PooledFileItem] (Phase 4 — memory
 * optimization module) for hot-path scan loops.
 *
 * Design notes:
 *  - [stableId] is the inode number when available — used by DiffUtil
 *    for stable RecyclerView animations.
 *  - [mimeType] is nullable because MIME detection is lazy (Phase 3).
 *  - [thumbnailPath] is nullable because thumbnail generation is async.
 *  - Use [isDirectory] for fast directory checks (no File API needed).
 *
 * Phase 0 — minimal fields. Phase 3 will add:
 *   - permissions: FilePermissions
 *   - mediaMeta: MediaMetadata? (EXIF, duration, codec)
 *   - isSymlink, symlinkTarget
 *   - fileCategory: FileCategory (auto-computed)
 */
@Serializable
data class FileItem(
    /** Absolute filesystem path. */
    val path: String,
    /** File or directory name (last path segment). */
    val name: String,
    /** Inode number (0 if not available, e.g. on FAT32/exFAT). */
    val stableId: Long,
    /** Size in bytes (0 for directories). */
    val size: Long,
    /** Last modified time (epoch milliseconds). */
    val modifiedAt: Long,
    /** True if this is a directory. */
    val isDirectory: Boolean,
    /** MIME type, lazily resolved. `null` if not yet detected. */
    val mimeType: String? = null,
    /** Path to a cached thumbnail, if any. `null` if not yet generated. */
    val thumbnailPath: String? = null,
    /** True if name starts with `.` (Unix hidden file). */
    val isHidden: Boolean = false,
    /** User-set bookmark flag. */
    val isBookmarked: Boolean = false,
    /** User-set tags (free-form labels). */
    val tags: List<String> = emptyList(),
) {
    /**
     * File extension (without the dot, lowercase). Empty for directories or
     * files without an extension.
     */
    val extension: String
        get() = if (isDirectory) "" else
            name.substringAfterLast('.', "").lowercase()

    /**
     * Convenience: convert [modifiedAt] epoch millis to [Instant].
     */
    fun modifiedInstant(): Instant =
        Instant.fromEpochMilliseconds(modifiedAt)
}

/**
 * A placeholder [FileItem] used by the UI to show skeleton rows during
 * loading. Identified by a negative [stableId] so DiffUtil never
 * confuses it with a real item.
 */
fun FileItem.Companion.placeholder(index: Int): FileItem = FileItem(
    path = "",
    name = "",
    stableId = -(index + 1).toLong(),
    size = 0L,
    modifiedAt = 0L,
    isDirectory = false,
    isHidden = false,
)

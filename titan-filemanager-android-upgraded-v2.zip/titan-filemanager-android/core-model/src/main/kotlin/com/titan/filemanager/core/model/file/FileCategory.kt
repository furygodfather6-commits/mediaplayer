package com.titan.filemanager.core.model.file

/**
 * Logical category of a file, used for:
 *  - Storage breakdown charts
 *  - Filter chips in the browser
 *  - AI-based auto-organization (Phase 5)
 *
 * Categories are mutually exclusive for a single file. The order here
 * is the display order in filter chips and analytics dashboards.
 */
enum class FileCategory {
    PHOTO,
    VIDEO,
    AUDIO,
    DOCUMENT,
    SPREADSHEET,
    PRESENTATION,
    ARCHIVE,
    CODE,
    APP_PACKAGE,
    FONT,
    EBOOK,
    DATABASE,
    TEMPORARY,
    SYSTEM,
    OTHER;

    companion object {
        /**
         * Map a MIME type to a category.
         *
         * Phase 0 — basic mapping. Phase 3 ([MimeDetector]) will add
         * magic-byte detection and path-context heuristics.
         */
        fun fromMimeType(mimeType: String?): FileCategory {
            if (mimeType == null) return OTHER
            val type = mimeType.substringBefore('/')
            val subtype = mimeType.substringAfter('/')
            return when (type) {
                "image" -> PHOTO
                "video" -> VIDEO
                "audio" -> AUDIO
                "text" -> when (subtype) {
                    "plain", "markdown", "richtext" -> DOCUMENT
                    else -> CODE
                }
                "application" -> when (subtype) {
                    "pdf" -> DOCUMENT
                    "msword", "vnd.openxmlformats-officedocument.wordprocessingml.document" -> DOCUMENT
                    "vnd.ms-excel", "vnd.openxmlformats-officedocument.spreadsheetml.sheet" -> SPREADSHEET
                    "vnd.ms-powerpoint", "vnd.openxmlformats-officedocument.presentationml.presentation" -> PRESENTATION
                    "zip", "x-tar", "gzip", "x-rar-compressed", "x-7z-compressed", "x-bzip2", "x-xz" -> ARCHIVE
                    "vnd.android.package-archive" -> APP_PACKAGE
                    "epub+zip" -> EBOOK
                    "x-sqlite3", "vnd.sqlite3" -> DATABASE
                    else -> OTHER
                }
                else -> OTHER
            }
        }

        /**
         * Map a file extension to a category (used when MIME is unknown).
         */
        fun fromExtension(ext: String): FileCategory = when (ext.lowercase()) {
            // Photos
            "jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif", "tiff", "svg" -> PHOTO
            // Videos
            "mp4", "mkv", "avi", "mov", "wmv", "flv", "webm", "3gp", "mpeg", "mpg" -> VIDEO
            // Audio
            "mp3", "wav", "flac", "aac", "ogg", "m4a", "wma", "opus", "amr" -> AUDIO
            // Documents
            "pdf", "doc", "docx", "odt", "rtf", "txt" -> DOCUMENT
            // Spreadsheets
            "xls", "xlsx", "ods", "csv" -> SPREADSHEET
            // Presentations
            "ppt", "pptx", "odp", "key" -> PRESENTATION
            // Archives
            "zip", "rar", "7z", "tar", "gz", "bz2", "xz", "tgz" -> ARCHIVE
            // Code
            "kt", "java", "c", "cpp", "h", "hpp", "py", "js", "ts", "tsx", "jsx",
            "html", "css", "xml", "json", "yaml", "yml", "toml", "sh", "go", "rs",
            "swift", "rb", "php", "sql", "gradle" -> CODE
            // APK
            "apk", "apks", "apkm", "xapk" -> APP_PACKAGE
            // Fonts
            "ttf", "otf", "woff", "woff2" -> FONT
            // eBooks
            "epub", "mobi", "azw", "azw3" -> EBOOK
            // Databases
            "db", "sqlite", "sqlite3" -> DATABASE
            // Temp
            "tmp", "temp", "bak", "swp", "log" -> TEMPORARY
            else -> OTHER
        }
    }
}

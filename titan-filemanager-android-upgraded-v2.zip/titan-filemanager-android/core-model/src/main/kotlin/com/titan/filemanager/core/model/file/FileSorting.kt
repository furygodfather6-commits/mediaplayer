package com.titan.filemanager.core.model.file

/**
 * Sort criteria for file listings.
 *
 * Phase 0: [NAME], [SIZE], [MODIFIED], [TYPE]
 * Phase 2: [EXTENSION] (within type groups)
 * Phase 5: [USAGE] (by access frequency from ML)
 */
enum class FileSorting {
    NAME,
    SIZE,
    MODIFIED,
    TYPE,
    EXTENSION,
    USAGE,
}

enum class SortOrder {
    ASCENDING,
    DESCENDING,
}

/**
 * Combined sort descriptor — used in user preferences.
 */
data class SortDescriptor(
    val sorting: FileSorting = FileSorting.NAME,
    val order: SortOrder = SortOrder.ASCENDING,
    val directoriesFirst: Boolean = true,
)

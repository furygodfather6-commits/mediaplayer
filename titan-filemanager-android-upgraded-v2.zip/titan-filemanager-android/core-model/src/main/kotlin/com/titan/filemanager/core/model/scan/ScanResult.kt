package com.titan.filemanager.core.model.scan

import com.titan.filemanager.core.model.file.FileItem

/**
 * Final result of a scan — wrapper around the items list with metadata
 * about how the scan completed.
 */
data class ScanResult(
    val items: List<FileItem>,
    val durationMs: Long,
    val scannedCount: Int,
    val skippedCount: Int,
    val source: Source,
) {
    enum class Source {
        /** Result came from a fresh filesystem scan. */
        FRESH_SCAN,

        /** Result came from L1/L2/L3/L4 cache hit. */
        CACHE,

        /** Result came from a paused/resumed scan. */
        RESUMED,

        /** Result came from incremental refresh (FileObserver events). */
        INCREMENTAL,
    }

    companion object {
        fun empty(source: Source = Source.FRESH_SCAN): ScanResult = ScanResult(
            items = emptyList(),
            durationMs = 0L,
            scannedCount = 0,
            skippedCount = 0,
            source = source,
        )
    }
}

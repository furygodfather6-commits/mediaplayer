package com.titan.filemanager.data.thumbnail.advanced

import com.titan.filemanager.data.thumbnail.advanced.ThumbnailPriority
import com.titan.filemanager.data.thumbnail.advanced.ThumbnailRequest
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.PriorityBlockingQueue
import java.util.concurrent.atomic.AtomicLong

/**
 * Priority Thumbnail Queue.
 *
 * Ported technique: #70 Thumbnail priority queue
 *
 * Features:
 *  1. Priority-ordered processing
 *  2. Deduplication (same file = one request)
 *  3. Priority upgrade (visible item gets boosted)
 *  4. Stale request removal
 *  5. Capacity management
 *
 * Priority order: CRITICAL > VISIBLE > PREFETCH > BACKGROUND > IDLE
 */
class PriorityThumbnailQueue(
    private val maxCapacity: Int = 500,
) {

    private val queue = PriorityBlockingQueue<ThumbnailRequest>(
        maxCapacity,
        Comparator { a, b -> a.compareTo(b) },
    )

    private val activeRequests = ConcurrentHashMap<String, ThumbnailRequest>(200)

    private val enqueued = AtomicLong(0L)
    private val dequeued = AtomicLong(0L)
    private val duplicates = AtomicLong(0L)
    private val upgraded = AtomicLong(0L)
    private val dropped = AtomicLong(0L)

    /** Enqueue request with deduplication. */
    fun enqueue(request: ThumbnailRequest): EnqueueResult {
        val existing = activeRequests[request.filePath]

        if (existing != null) {
            if (request.priority.value > existing.priority.value) {
                queue.remove(existing)
                val upgradedReq = existing.copy(priority = request.priority)
                queue.offer(upgradedReq)
                activeRequests[request.filePath] = upgradedReq
                upgraded.incrementAndGet()
                return EnqueueResult.UPGRADED
            }
            duplicates.incrementAndGet()
            return EnqueueResult.DUPLICATE
        }

        if (queue.size >= maxCapacity) {
            dropLowestPriority()
        }

        queue.offer(request)
        activeRequests[request.filePath] = request
        enqueued.incrementAndGet()
        return EnqueueResult.QUEUED
    }

    fun enqueueBatch(requests: List<ThumbnailRequest>) {
        requests.forEach { enqueue(it) }
    }

    /** Dequeue highest priority request. Returns null if queue empty. */
    fun dequeue(): ThumbnailRequest? {
        val request = queue.poll() ?: return null
        activeRequests.remove(request.filePath)
        dequeued.incrementAndGet()

        // Skip if target view is gone
        if (request.targetView?.get() == null && request.targetView != null) {
            return dequeue()
        }
        return request
    }

    fun cancel(filePath: String): Boolean {
        val request = activeRequests.remove(filePath) ?: return false
        return queue.remove(request)
    }

    /** Cancel all requests for paths not in visible set. Called on navigation change. */
    fun cancelIrrelevant(visiblePaths: Set<String>): Int {
        var cancelled = 0
        val toRemove = activeRequests.keys.filter { it !in visiblePaths }
        toRemove.forEach { path ->
            val request = activeRequests.remove(path)
            if (request != null && queue.remove(request)) cancelled++
        }
        return cancelled
    }

    /** Boost priority for newly visible items. */
    fun boostPriority(filePaths: List<String>, newPriority: ThumbnailPriority) {
        filePaths.forEach { path ->
            val existing = activeRequests[path] ?: return@forEach
            if (newPriority.value > existing.priority.value) {
                queue.remove(existing)
                val boosted = existing.copy(priority = newPriority)
                queue.offer(boosted)
                activeRequests[path] = boosted
                upgraded.incrementAndGet()
            }
        }
    }

    private fun dropLowestPriority() {
        val lowest = queue.minByOrNull { it.priority.value }
        if (lowest != null) {
            queue.remove(lowest)
            activeRequests.remove(lowest.filePath)
            dropped.incrementAndGet()
        }
    }

    fun size(): Int = queue.size
    fun isEmpty(): Boolean = queue.isEmpty()

    fun getStats(): QueueStats = QueueStats(
        queueSize = queue.size,
        activeRequests = activeRequests.size,
        totalEnqueued = enqueued.get(),
        totalDequeued = dequeued.get(),
        duplicates = duplicates.get(),
        upgraded = upgraded.get(),
        dropped = dropped.get(),
    )

    enum class EnqueueResult { QUEUED, DUPLICATE, UPGRADED, DROPPED }

    data class QueueStats(
        val queueSize: Int,
        val activeRequests: Int,
        val totalEnqueued: Long,
        val totalDequeued: Long,
        val duplicates: Long,
        val upgraded: Long,
        val dropped: Long,
    )
}

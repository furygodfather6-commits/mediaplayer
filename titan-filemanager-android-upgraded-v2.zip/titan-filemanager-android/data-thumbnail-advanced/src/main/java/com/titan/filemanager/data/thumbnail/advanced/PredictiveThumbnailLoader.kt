package com.titan.filemanager.data.thumbnail.advanced

import com.titan.filemanager.data.thumbnail.advanced.ThumbnailPriority
import com.titan.filemanager.data.thumbnail.advanced.ThumbnailRequest

/**
 * Predictive Thumbnail Loader.
 *
 * Ported technique: #72 Predictive thumbnail generation
 *
 * Pre-generates thumbnails for items the user will LIKELY scroll to next.
 *
 * Prediction strategies:
 *  1. Scroll direction: pre-load ahead of scroll
 *  2. History: previously viewed folders (caller can extend)
 *  3. Alphabetical: nearby files in sorted list
 */
class PredictiveThumbnailLoader(
    private val queue: PriorityThumbnailQueue,
) {

    companion object {
        private const val PREDICT_AHEAD = 15
        private const val PREDICT_BEHIND = 5
    }

    private var lastFirstVisible = 0
    @Volatile private var scrollDirection = ScrollDirection.NONE

    /** Called when scroll position changes — predicts and queues loading. */
    fun onScroll(allRequests: List<ThumbnailRequest>, firstVisible: Int, lastVisible: Int) {
        scrollDirection = when {
            firstVisible > lastFirstVisible -> ScrollDirection.DOWN
            firstVisible < lastFirstVisible -> ScrollDirection.UP
            else -> ScrollDirection.NONE
        }
        lastFirstVisible = firstVisible

        val predictRange = when (scrollDirection) {
            ScrollDirection.DOWN -> {
                val start = lastVisible + 1
                val end = (lastVisible + PREDICT_AHEAD).coerceAtMost(allRequests.size - 1)
                start..end
            }
            ScrollDirection.UP -> {
                val start = (firstVisible - PREDICT_AHEAD).coerceAtLeast(0)
                val end = firstVisible - 1
                start..end
            }
            ScrollDirection.NONE -> return
        }

        predictRange.forEach { index ->
            val request = allRequests.getOrNull(index) ?: return@forEach
            queue.enqueue(request.copy(priority = ThumbnailPriority.PREFETCH))
        }
    }

    enum class ScrollDirection { UP, DOWN, NONE }
}

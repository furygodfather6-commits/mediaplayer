package com.titan.filemanager.data.thumbnail.advanced

import android.graphics.Bitmap
import android.widget.ImageView
import java.lang.ref.WeakReference
import java.util.UUID

/**
 * Thumbnail request with full context.
 *
 * Carries everything the workers need: target view (WeakReference),
 * priority, target dimensions, content hash for deduplication, and
 * toggles for GPU/native paths.
 */
data class ThumbnailRequest(
    val id: String = UUID.randomUUID().toString(),
    val filePath: String,
    val mimeType: String,
    val targetWidth: Int,
    val targetHeight: Int,
    val priority: ThumbnailPriority,
    val targetView: WeakReference<ImageView>? = null,
    val onResult: ((ThumbnailResult) -> Unit)? = null,
    val requestedAt: Long = System.currentTimeMillis(),
    val contentHash: String? = null,
    val allowGpu: Boolean = true,
    val allowNative: Boolean = true,
) : Comparable<ThumbnailRequest> {

    override fun compareTo(other: ThumbnailRequest): Int {
        // Higher priority = process first
        val priorityComp = other.priority.value.compareTo(this.priority.value)
        if (priorityComp != 0) return priorityComp
        // Same priority = older request first
        return this.requestedAt.compareTo(other.requestedAt)
    }
}

/** Priority levels for thumbnail requests. */
enum class ThumbnailPriority(val value: Int) {
    CRITICAL(100),    // Currently visible + focused
    VISIBLE(80),      // Currently visible
    PREFETCH(50),     // About to be visible
    BACKGROUND(20),   // Not visible (predictive)
    IDLE(5),          // Lowest priority
}

/** Thumbnail result variants. */
sealed class ThumbnailResult {

    data class Success(
        val requestId: String,
        val filePath: String,
        val bitmap: Bitmap,
        val width: Int,
        val height: Int,
        val source: ThumbnailSource,
        val generationMs: Long,
    ) : ThumbnailResult()

    data class Error(
        val requestId: String,
        val filePath: String,
        val reason: String,
        val throwable: Throwable? = null,
    ) : ThumbnailResult()

    data class Cached(
        val requestId: String,
        val filePath: String,
        val bitmap: Bitmap,
        val cacheLevel: String,
    ) : ThumbnailResult()

    data class Cancelled(val requestId: String) : ThumbnailResult()
}

/** Where thumbnail came from. */
enum class ThumbnailSource {
    MEMORY_CACHE,
    DISK_CACHE,
    GENERATED_IMAGE,
    GENERATED_VIDEO,
    GENERATED_AUDIO,
    GENERATED_DOCUMENT,
    GENERATED_APK,
    GENERATED_GENERIC,
}

/** Supported thumbnail sizes. */
object ThumbnailSizes {
    const val MICRO = 48        // Tiny grid
    const val SMALL = 96        // Small grid
    const val MEDIUM = 160      // Medium grid (default)
    const val LARGE = 256       // Large grid / list
    const val XLARGE = 512      // Detail view

    fun selectForGrid(columnCount: Int): Int = when {
        columnCount >= 6 -> SMALL
        columnCount >= 4 -> MEDIUM
        columnCount >= 3 -> LARGE
        else -> XLARGE
    }
}

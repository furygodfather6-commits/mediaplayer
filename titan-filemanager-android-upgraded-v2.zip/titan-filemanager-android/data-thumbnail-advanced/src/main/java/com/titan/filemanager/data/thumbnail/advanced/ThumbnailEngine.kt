package com.titan.filemanager.data.thumbnail.advanced

import android.content.Context
import android.graphics.Bitmap
import android.widget.ImageView
import com.titan.filemanager.data.thumbnail.advanced.cache.ThumbnailDeduplicator
import com.titan.filemanager.data.thumbnail.advanced.cache.ThumbnailDiskCache
import com.titan.filemanager.data.thumbnail.advanced.cache.ThumbnailMemCache
import com.titan.filemanager.data.thumbnail.advanced.gpu.GpuResizeEngine
import com.titan.filemanager.data.thumbnail.advanced.resolution.ResolutionSelector
import com.titan.filemanager.data.thumbnail.advanced.workers.ThumbnailWorkerFactory
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.lang.ref.WeakReference
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Master Thumbnail Engine.
 *
 * Ported Phase G techniques #69-#77 — all thumbnail techniques.
 *
 * Flow:
 *   Request → Queue → Worker → Cache → UI
 *
 * Cache hierarchy:
 *   L1 Memory → L2 Disk → Generate → Store
 */
@Singleton
class ThumbnailEngine @Inject constructor(
    private val context: Context,
) {

    companion object {
        private const val WORKER_COUNT = 4
    }

    private val memCache = ThumbnailMemCache(maxMemoryBytes = calculateMemCacheSize())
    private val diskCache = ThumbnailDiskCache(cacheDir = File(context.cacheDir, "thumbnails"))
    private val deduplicator = ThumbnailDeduplicator()
    private val gpuEngine = GpuResizeEngine(context)
    private val workerFactory = ThumbnailWorkerFactory(context, gpuEngine)
    private val resolutionSelector = ResolutionSelector(
        displayDensity = context.resources.displayMetrics.density,
    )
    private val priorityQueue = PriorityThumbnailQueue(maxCapacity = 500)
    private val viewportManager = ViewportThumbnailManager(priorityQueue)
    private val predictiveLoader = PredictiveThumbnailLoader(priorityQueue)

    private val workerScope = CoroutineScope(
        Dispatchers.IO.limitedParallelism(WORKER_COUNT) +
            SupervisorJob() +
            CoroutineName("ThumbnailEngine"),
    )

    private val _results = MutableSharedFlow<ThumbnailResult>(
        replay = 0,
        extraBufferCapacity = 200,
    )
    val results: SharedFlow<ThumbnailResult> = _results

    private val inFlight = ConcurrentHashMap<String, kotlinx.coroutines.Job>()

    private val memHits = AtomicLong(0L)
    private val diskHits = AtomicLong(0L)
    private val generated = AtomicLong(0L)
    private val errors = AtomicLong(0L)

    init {
        startWorkers()
    }

    /** Load thumbnail into ImageView — main entry point for UI. */
    fun load(
        filePath: String,
        mimeType: String,
        targetView: ImageView,
        targetSize: Int = ThumbnailSizes.MEDIUM,
        priority: ThumbnailPriority = ThumbnailPriority.VISIBLE,
    ) {
        val cacheKey = buildCacheKey(filePath, targetSize)

        // L1: Memory cache (instant, main thread safe)
        memCache.get(cacheKey)?.let { bitmap ->
            targetView.setImageBitmap(bitmap)
            memHits.incrementAndGet()
            return
        }

        val request = ThumbnailRequest(
            filePath = filePath,
            mimeType = mimeType,
            targetWidth = targetSize,
            targetHeight = targetSize,
            priority = priority,
            targetView = WeakReference(targetView),
        )
        targetView.tag = request.id
        priorityQueue.enqueue(request)
    }

    /** Start background worker coroutines. */
    private fun startWorkers() {
        repeat(WORKER_COUNT) {
            workerScope.launch {
                while (isActive) {
                    val request = priorityQueue.dequeue()
                    if (request != null) {
                        processRequest(request)
                    } else {
                        delay(10L)
                    }
                }
            }
        }
    }

    private suspend fun processRequest(request: ThumbnailRequest) {
        val cacheKey = buildCacheKey(request.filePath, request.targetWidth)

        // L2: Disk cache check
        val diskBitmap = diskCache.get(cacheKey)
        if (diskBitmap != null) {
            memCache.put(cacheKey, diskBitmap)
            diskHits.incrementAndGet()
            deliverResult(
                ThumbnailResult.Cached(request.id, request.filePath, diskBitmap, "disk"),
                request,
            )
            return
        }

        // Generate thumbnail
        val result = withContext(Dispatchers.IO) { workerFactory.generate(request) }

        when (result) {
            is ThumbnailResult.Success -> {
                memCache.put(cacheKey, result.bitmap)
                diskCache.put(cacheKey, result.bitmap, request.mimeType)
                generated.incrementAndGet()
                deliverResult(result, request)
            }
            is ThumbnailResult.Error -> {
                errors.incrementAndGet()
                deliverResult(result, request)
            }
            else -> deliverResult(result, request)
        }
    }

    private suspend fun deliverResult(result: ThumbnailResult, request: ThumbnailRequest) {
        _results.emit(result)

        val bitmap = when (result) {
            is ThumbnailResult.Success -> result.bitmap
            is ThumbnailResult.Cached -> result.bitmap
            else -> null
        } ?: return

        withContext(Dispatchers.Main) {
            val view = request.targetView?.get() ?: return@withContext
            if (view.tag == request.id) {
                view.setImageBitmap(bitmap)
            }
        }
    }

    /** Viewport change notification — Technique #71. */
    fun onViewportChanged(
        requests: List<ThumbnailRequest>,
        firstVisible: Int,
        lastVisible: Int,
    ) {
        viewportManager.onViewportChanged(requests, firstVisible, lastVisible)
        predictiveLoader.onScroll(requests, firstVisible, lastVisible)
    }

    fun onScrollVelocityChanged(pixelsPerSecond: Float) {
        viewportManager.onScrollVelocityChanged(pixelsPerSecond)
    }

    fun cancel(filePath: String) {
        priorityQueue.cancel(filePath)
        inFlight[filePath]?.cancel()
    }

    fun cancelAll() {
        priorityQueue.cancelIrrelevant(emptySet())
        inFlight.values.forEach { it.cancel() }
        inFlight.clear()
    }

    private fun buildCacheKey(path: String, size: Int): String {
        val file = File(path)
        return "${path}_${size}_${file.lastModified()}"
    }

    private fun calculateMemCacheSize(): Int {
        val maxMemory = Runtime.getRuntime().maxMemory().toInt()
        return maxMemory / 8
    }

    fun getStats(): ThumbnailStats = ThumbnailStats(
        queueStats = priorityQueue.getStats(),
        memCacheStats = memCache.getStats(),
        diskCacheStats = diskCache.getStats(),
        deduplicationStats = deduplicator.getSavings(),
        memHits = memHits.get(),
        diskHits = diskHits.get(),
        generated = generated.get(),
        errors = errors.get(),
    )

    fun shutdown() {
        workerScope.cancel()
        gpuEngine.release()
    }

    data class ThumbnailStats(
        val queueStats: PriorityThumbnailQueue.QueueStats,
        val memCacheStats: com.titan.filemanager.data.thumbnail.advanced.cache.ThumbnailMemCache.MemCacheStats,
        val diskCacheStats: com.titan.filemanager.data.thumbnail.advanced.cache.ThumbnailDiskCache.DiskCacheStats,
        val deduplicationStats: com.titan.filemanager.data.thumbnail.advanced.cache.ThumbnailDeduplicator.DeduplicationStats,
        val memHits: Long,
        val diskHits: Long,
        val generated: Long,
        val errors: Long,
    )
}

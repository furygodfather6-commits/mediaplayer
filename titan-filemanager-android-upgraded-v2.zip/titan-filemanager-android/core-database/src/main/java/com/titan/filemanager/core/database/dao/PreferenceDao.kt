package com.titan.filemanager.core.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.titan.filemanager.core.database.entity.PreferenceEntity

@Dao
interface PreferenceDao {

    @Query("SELECT value FROM preferences WHERE key = :key LIMIT 1")
    suspend fun get(key: String): String?

    @Query("SELECT * FROM preferences WHERE key LIKE :prefix || '%'")
    suspend fun getWithPrefix(prefix: String): List<PreferenceEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun set(entity: PreferenceEntity)

    @Query("DELETE FROM preferences WHERE key = :key")
    suspend fun delete(key: String): Int

    @Query("DELETE FROM preferences WHERE key LIKE :prefix || '%'")
    suspend fun deleteWithPrefix(prefix: String): Int
}

package com.titan.filemanager.core.database.converter

import androidx.room.TypeConverter

/**
 * Room type converters for primitive types that Room can't handle by default.
 *
 * Phase 1 — only Boolean (Room stores it as 0/1 INTEGER). Phase 3 will
 * add converters for `Instant`, `Path`, `List<String>`, and JSON-serialized
 * complex types.
 */
class TypeConverters {

    @TypeConverter
    fun booleanToInt(value: Boolean): Int = if (value) 1 else 0

    @TypeConverter
    fun intToBoolean(value: Int): Boolean = value != 0
}

package com.titan.filemanager.core.database.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * A user-added bookmark. Rendered as a quick-access tile on the
 * Home screen (Phase 2) and in the browser's sidebar (Phase 4).
 *
 * Bookmarks are stable across rescans — they reference a path string,
 * not an inode, so renaming the target keeps the bookmark alive
 * (Phase 5 will add rename-tracking).
 */
@Entity(
    tableName = "bookmarks",
    indices = [Index(value = ["path"], unique = true)],
)
data class BookmarkEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    @ColumnInfo(name = "path")
    val path: String,

    @ColumnInfo(name = "display_name")
    val displayName: String,

    @ColumnInfo(name = "icon_color")
    val iconColor: Int = 0,

    @ColumnInfo(name = "sort_order")
    val sortOrder: Int = 0,

    @ColumnInfo(name = "created_at")
    val createdAt: Long,
)

package com.titan.filemanager.core.database.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Key-value store for app-level preferences that need to be queried
 * by SQL (e.g. "WHERE key LIKE 'cache_%'").
 *
 * Most user preferences live in DataStore (`:core:datastore`) — this
 * table is reserved for runtime values like:
 *   - last_opened_path: where the user left off
 *   - last_scan_run_at: when the last background scan happened
 *   - cache_stats_*: cache hit/miss counters
 *
 * Why not DataStore? Because we sometimes need atomic multi-row
 * transactions across settings + file entries (e.g. "mark folder
 * scanned AND update last_scan_run_at" must be atomic).
 */
@Entity(tableName = "preferences")
data class PreferenceEntity(
    @PrimaryKey
    @ColumnInfo(name = "key")
    val key: String,

    @ColumnInfo(name = "value")
    val value: String,

    @ColumnInfo(name = "updated_at")
    val updatedAt: Long,
)

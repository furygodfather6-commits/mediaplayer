package com.titan.filemanager.core.database.instrumentation

import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import timber.log.Timber
import java.util.concurrent.atomic.AtomicLong

/**
 * Tracks per-table row counts + DB file size + WAL file size.
 *
 * Used by the diagnostic screen in Settings (Phase 4) to show users
 * "Database size: 12.4 MB, 5,420 cached files, WAL: 2.1 MB".
 *
 * All queries are synchronous and cheap — designed to run on a
 * background thread every few seconds.
 */
class DatabaseHealthMonitor(
    private val database: RoomDatabase,
) {

    private val openHelper get() = database.openHelper

    /**
     * Snapshot of DB health metrics. Read-only, cheap to compute.
     */
    data class HealthSnapshot(
        val dbFileSizeBytes: Long,
        val walFileSizeBytes: Long,
        val fileCount: Long,
        val bookmarkCount: Long,
        val recentCount: Long,
        val hiddenCount: Long,
        val preferenceCount: Long,
        val pageSizeBytes: Long,
        val walCheckpointPages: Long,
    )

    suspend fun snapshot(): HealthSnapshot {
        val db = openHelper.writableDatabase
        return HealthSnapshot(
            dbFileSizeBytes = db.path?.let { java.io.File(it).length() } ?: 0L,
            walFileSizeBytes = db.path?.let { java.io.File("$it-wal").let { f -> if (f.exists()) f.length() else 0L } } ?: 0L,
            fileCount = countRows(db, "files"),
            bookmarkCount = countRows(db, "bookmarks"),
            recentCount = countRows(db, "recent_files"),
            hiddenCount = countRows(db, "hidden_folders"),
            preferenceCount = countRows(db, "preferences"),
            pageSizeBytes = queryLong(db, "PRAGMA page_size"),
            walCheckpointPages = queryLong(db, "PRAGMA wal_checkpoint(PASSIVE)") // returns 3 cols, last is checkpointed pages
                .let { 0L }, // simplified — actual implementation will parse
        )
    }

    /**
     * Run a WAL checkpoint (TRUNCATE mode) — used by the periodic
     * cleanup worker (Phase 2) to keep WAL file size bounded.
     */
    suspend fun checkpoint() {
        database.runInTransaction {
            val db = openHelper.writableDatabase
            db.execSQL("PRAGMA wal_checkpoint(TRUNCATE)")
            Timber.i("WAL checkpoint complete")
        }
    }

    private fun countRows(db: SupportSQLiteDatabase, table: String): Long =
        queryLong(db, "SELECT COUNT(*) FROM $table")

    private fun queryLong(db: SupportSQLiteDatabase, sql: String): Long {
        db.query(sql).use { cursor ->
            return if (cursor.moveToFirst()) cursor.getLong(0) else 0L
        }
    }
}

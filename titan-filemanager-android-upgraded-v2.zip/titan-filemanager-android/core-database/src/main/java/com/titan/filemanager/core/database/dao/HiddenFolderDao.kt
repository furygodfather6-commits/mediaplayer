package com.titan.filemanager.core.database.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.titan.filemanager.core.database.entity.HiddenFolderEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface HiddenFolderDao {

    @Query("SELECT * FROM hidden_folders ORDER BY display_name COLLATE NOCASE ASC")
    fun observeAll(): Flow<List<HiddenFolderEntity>>

    @Query("SELECT * FROM hidden_folders WHERE path = :path LIMIT 1")
    suspend fun getByPath(path: String): HiddenFolderEntity?

    @Query("SELECT EXISTS(SELECT 1 FROM hidden_folders WHERE path = :path)")
    suspend fun isHidden(path: String): Boolean

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: HiddenFolderEntity): Long

    @Delete
    suspend fun delete(entity: HiddenFolderEntity)

    @Query("DELETE FROM hidden_folders WHERE path = :path")
    suspend fun deleteByPath(path: String): Int
}

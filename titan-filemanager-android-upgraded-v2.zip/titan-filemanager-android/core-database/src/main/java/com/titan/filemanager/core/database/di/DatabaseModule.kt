package com.titan.filemanager.core.database.di

import android.content.Context
import androidx.room.Room
import com.titan.filemanager.core.database.DatabaseCallback
import com.titan.filemanager.core.database.DatabaseMigrations
import com.titan.filemanager.core.database.TitanDatabase
import com.titan.filemanager.core.database.dao.BookmarkDao
import com.titan.filemanager.core.database.dao.FileDao
import com.titan.filemanager.core.database.dao.HiddenFolderDao
import com.titan.filemanager.core.database.dao.PreferenceDao
import com.titan.filemanager.core.database.dao.RecentFileDao
import com.titan.filemanager.core.database.dao.TrashDao
import com.titan.filemanager.core.database.dao.VaultDao
import com.titan.filemanager.core.database.instrumentation.DatabaseHealthMonitor
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Hilt module providing Room database + DAOs.
 *
 * All bindings are `@Singleton` because the database and DAOs are
 * process-wide singletons.
 *
 * The database file lives in the app's internal storage (`databaseDir`),
 * not on the SD card — even for a file manager. User files are on
 * external storage; app database is private.
 */
@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideTitanDatabase(
        @ApplicationContext context: Context,
    ): TitanDatabase = Room.databaseBuilder(
        context = context,
        klass = TitanDatabase::class.java,
        name = TitanDatabase.NAME,
    )
        .addCallback(DatabaseCallback())
        .addMigrations(*DatabaseMigrations.ALL)
        .fallbackToDestructiveMigrationOnDowngrade()
        .build()

    @Provides
    @Singleton
    fun provideFileDao(db: TitanDatabase): FileDao = db.fileDao()

    @Provides
    @Singleton
    fun provideBookmarkDao(db: TitanDatabase): BookmarkDao = db.bookmarkDao()

    @Provides
    @Singleton
    fun provideRecentFileDao(db: TitanDatabase): RecentFileDao = db.recentFileDao()

    @Provides
    @Singleton
    fun provideHiddenFolderDao(db: TitanDatabase): HiddenFolderDao = db.hiddenFolderDao()

    @Provides
    @Singleton
    fun providePreferenceDao(db: TitanDatabase): PreferenceDao = db.preferenceDao()

    @Provides
    @Singleton
    fun provideTrashDao(db: TitanDatabase): TrashDao = db.trashDao()

    @Provides
    @Singleton
    fun provideVaultDao(db: TitanDatabase): VaultDao = db.vaultDao()

    @Provides
    @Singleton
    fun provideDatabaseHealthMonitor(db: TitanDatabase): DatabaseHealthMonitor =
        DatabaseHealthMonitor(db)
}

package com.titan.filemanager.core.database.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Cached filesystem entry (file or directory).
 *
 * The file manager caches scan results here so subsequent folder opens
 * can be served from the database (~5-20ms) instead of re-scanning
 * the filesystem (~100-5000ms).
 *
 * Schema:
 *   - [path] is the primary key (unique identifier).
 *   - [parentPath] is indexed for "list all children of X" queries.
 *   - [inode] + [modifiedAt] form a fingerprint for cache invalidation.
 *
 * Phase 1 — basic fields. Phase 3 will add columns for permissions,
 * symlink target, MIME source, etc.
 */
@Entity(
    tableName = "files",
    indices = [
        Index(value = ["parent_path"]),
        Index(value = ["inode"]),
        Index(value = ["modified_at"]),
    ],
)
data class FileEntity(
    @PrimaryKey
    @ColumnInfo(name = "path")
    val path: String,

    @ColumnInfo(name = "parent_path")
    val parentPath: String,

    @ColumnInfo(name = "name")
    val name: String,

    @ColumnInfo(name = "inode")
    val inode: Long,

    @ColumnInfo(name = "size")
    val size: Long,

    @ColumnInfo(name = "modified_at")
    val modifiedAt: Long,

    @ColumnInfo(name = "is_directory")
    val isDirectory: Boolean,

    @ColumnInfo(name = "is_hidden")
    val isHidden: Boolean = false,

    @ColumnInfo(name = "mime_type")
    val mimeType: String? = null,

    @ColumnInfo(name = "scanned_at")
    val scannedAt: Long,
)

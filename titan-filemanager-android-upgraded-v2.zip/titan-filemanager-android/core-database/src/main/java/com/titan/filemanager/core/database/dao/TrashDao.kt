package com.titan.filemanager.core.database.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.titan.filemanager.core.database.entity.TrashEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TrashDao {

    // ── Reads ─────────────────────────────────────────────────────────

    @Query("SELECT * FROM trash_entries ORDER BY trashed_at DESC")
    fun observeAll(): Flow<List<TrashEntity>>

    @Query("SELECT * FROM trash_entries ORDER BY trashed_at DESC")
    suspend fun getAll(): List<TrashEntity>

    @Query("SELECT * FROM trash_entries WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): TrashEntity?

    @Query("SELECT * FROM trash_entries WHERE original_path = :path LIMIT 1")
    suspend fun getByOriginalPath(path: String): TrashEntity?

    @Query("SELECT * FROM trash_entries WHERE id IN (:ids)")
    suspend fun getByIds(ids: List<Long>): List<TrashEntity>

    // ── Search + Filter ───────────────────────────────────────────────

    @Query(
        """
        SELECT * FROM trash_entries
        WHERE display_name LIKE '%' || :query || '%'
        ORDER BY trashed_at DESC
        """
    )
    fun search(query: String): Flow<List<TrashEntity>>

    @Query(
        """
        SELECT * FROM trash_entries
        WHERE (:mimePrefix = '' OR mime_type LIKE :mimePrefix || '%')
          AND size >= :minSize
          AND size <= :maxSize
          AND (:expiringBefore = 0 OR expires_at <= :expiringBefore)
        ORDER BY
            CASE WHEN :sortCode = 0 THEN trashed_at END DESC,
            CASE WHEN :sortCode = 1 THEN trashed_at END ASC,
            CASE WHEN :sortCode = 2 THEN size END DESC,
            CASE WHEN :sortCode = 3 THEN size END ASC,
            CASE WHEN :sortCode = 4 THEN display_name END ASC,
            CASE WHEN :sortCode = 5 THEN display_name END DESC,
            CASE WHEN :sortCode = 6 THEN expires_at END ASC
        """
    )
    fun observeFiltered(
        mimePrefix: String,
        minSize: Long,
        maxSize: Long,
        expiringBefore: Long,
        sortCode: Int,
    ): Flow<List<TrashEntity>>

    // ── Stats ─────────────────────────────────────────────────────────

    @Query("SELECT COUNT(*) FROM trash_entries")
    fun observeCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM trash_entries")
    suspend fun count(): Int

    @Query("SELECT COALESCE(SUM(size), 0) FROM trash_entries")
    fun observeTotalSize(): Flow<Long>

    @Query("SELECT COUNT(*) FROM trash_entries WHERE expires_at <= :before")
    fun observeExpiringCount(before: Long): Flow<Int>

    @Query("SELECT COALESCE(MIN(trashed_at), 0) FROM trash_entries")
    suspend fun oldestTrashedAt(): Long

    @Query(
        """
        SELECT
            CASE
                WHEN mime_type LIKE 'image/%' THEN 'Image'
                WHEN mime_type LIKE 'video/%' THEN 'Video'
                WHEN mime_type LIKE 'audio/%' THEN 'Audio'
                WHEN mime_type LIKE 'application/pdf'
                     OR mime_type LIKE 'application/vnd.openxmlformats%'
                     OR mime_type LIKE 'application/msword%'
                     OR mime_type LIKE 'text/%' THEN 'Document'
                WHEN mime_type = 'application/zip'
                     OR mime_type LIKE 'application/x-%'
                     OR mime_type = 'application/java-archive' THEN 'Archive'
                ELSE 'Other'
            END AS category,
            COUNT(*) AS count
        FROM trash_entries
        GROUP BY category
        """
    )
    suspend fun countByCategory(): List<CategoryCount>

    data class CategoryCount(val category: String, val count: Int)

    // ── Writes ────────────────────────────────────────────────────────

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: TrashEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(entities: List<TrashEntity>): List<Long>

    @Update
    suspend fun update(entity: TrashEntity)

    @Query("UPDATE trash_entries SET restore_count = restore_count + 1 WHERE id = :id")
    suspend fun incrementRestoreCount(id: Long)

    @Delete
    suspend fun delete(entity: TrashEntity)

    @Query("DELETE FROM trash_entries WHERE id = :id")
    suspend fun deleteById(id: Long): Int

    @Query("DELETE FROM trash_entries WHERE id IN (:ids)")
    suspend fun deleteByIds(ids: List<Long>): Int

    @Query("DELETE FROM trash_entries WHERE expires_at < :now")
    suspend fun deleteExpired(now: Long): Int

    @Query("DELETE FROM trash_entries")
    suspend fun deleteAll(): Int
}

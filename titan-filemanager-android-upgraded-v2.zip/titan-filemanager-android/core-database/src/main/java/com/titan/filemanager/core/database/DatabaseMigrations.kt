package com.titan.filemanager.core.database

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * Room migrations — additive only. Never modify an existing migration;
 * always add a new `Migration(N, N+1)` and append it to [ALL].
 */
object DatabaseMigrations {

    /**
     * Phase 4 — added `trash_entries` table for soft-delete with undo.
     */
    val MIGRATION_1_2 = object : Migration(1, 2) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("""
                CREATE TABLE IF NOT EXISTS `trash_entries` (
                    `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    `original_path` TEXT NOT NULL,
                    `trash_path` TEXT NOT NULL,
                    `display_name` TEXT NOT NULL,
                    `size` INTEGER NOT NULL,
                    `is_directory` INTEGER NOT NULL,
                    `mime_type` TEXT,
                    `trashed_at` INTEGER NOT NULL,
                    `expires_at` INTEGER NOT NULL
                )
            """.trimIndent())
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_trash_entries_original_path` ON `trash_entries` (`original_path`)")
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_trash_entries_expires_at` ON `trash_entries` (`expires_at`)")
        }
    }

    /**
     * Phase 5 — added `vault_entries` table for encrypted vault.
     */
    val MIGRATION_2_3 = object : Migration(2, 3) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("""
                CREATE TABLE IF NOT EXISTS `vault_entries` (
                    `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    `encrypted_path` TEXT NOT NULL,
                    `encrypted_display_name` TEXT NOT NULL,
                    `original_size` INTEGER NOT NULL,
                    `encrypted_size` INTEGER NOT NULL,
                    `encrypted_mime_type` TEXT,
                    `added_at` INTEGER NOT NULL
                )
            """.trimIndent())
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_vault_entries_encrypted_path` ON `vault_entries` (`encrypted_path`)")
        }
    }

    /**
     * v3 → v4 — TrashEntry upgrade.
     *
     * Adds three columns to `trash_entries`:
     *   - `file_hash` (INTEGER, nullable) — xxHash64 for integrity verification
     *   - `restore_count` (INTEGER, default 0) — number of times restored & re-trashed
     *   - `source_volume` (TEXT, nullable) — storage volume UUID
     *
     * Also adds new indices on `mime_type` and `trashed_at` for filter / sort queries.
     */
    val MIGRATION_3_4 = object : Migration(3, 4) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("ALTER TABLE `trash_entries` ADD COLUMN `file_hash` INTEGER")
            db.execSQL("ALTER TABLE `trash_entries` ADD COLUMN `restore_count` INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE `trash_entries` ADD COLUMN `source_volume` TEXT")
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_trash_entries_mime_type` ON `trash_entries` (`mime_type`)")
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_trash_entries_trashed_at` ON `trash_entries` (`trashed_at`)")
        }
    }

    /**
     * v4 → v5 — VaultEntry upgrade.
     *
     * Adds three columns to `vault_entries`:
     *   - `integrity_hash` (TEXT, nullable) — encrypted SHA-256 for tamper detection
     *   - `extract_count` (INTEGER, default 0) — number of extracts
     *   - `last_extracted_at` (INTEGER, nullable) — last successful extract timestamp
     *
     * Also adds an index on `added_at` for sort queries.
     */
    val MIGRATION_4_5 = object : Migration(4, 5) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("ALTER TABLE `vault_entries` ADD COLUMN `integrity_hash` TEXT")
            db.execSQL("ALTER TABLE `vault_entries` ADD COLUMN `extract_count` INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE `vault_entries` ADD COLUMN `last_extracted_at` INTEGER")
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_vault_entries_added_at` ON `vault_entries` (`added_at`)")
        }
    }

    val ALL: Array<Migration> = arrayOf(
        MIGRATION_1_2,
        MIGRATION_2_3,
        MIGRATION_3_4,
        MIGRATION_4_5,
    )
}

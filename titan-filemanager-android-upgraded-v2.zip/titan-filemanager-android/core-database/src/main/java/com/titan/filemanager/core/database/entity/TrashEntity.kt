package com.titan.filemanager.core.database.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * A file in the trash.
 *
 * Written when [com.titan.filemanager.domain.trash.TrashRepository.moveToTrash]
 * is called. Read by the Trash screen + the periodic cleanup worker.
 *
 * Schema v4 — adds:
 *   - [fileHash] xxHash64 captured at trash time, used for integrity
 *     verification on restore (defends against SD-card corruption)
 *   - [restoreCount] how many times this entry has been restored & re-trashed
 *   - [sourceVolume] storage volume UUID (for multi-volume restore on Android 11+)
 *
 * Indices:
 *   - [originalPath] for fast "is this path in trash?" lookups
 *   - [expiresAt] for the cleanup worker's `WHERE expires_at < now` query
 *   - [mimeType] for filter-by-type queries
 */
@Entity(
    tableName = "trash_entries",
    indices = [
        Index(value = ["original_path"]),
        Index(value = ["expires_at"]),
        Index(value = ["mime_type"]),
        Index(value = ["trashed_at"]),
    ],
)
data class TrashEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    @ColumnInfo(name = "original_path")
    val originalPath: String,

    @ColumnInfo(name = "trash_path")
    val trashPath: String,

    @ColumnInfo(name = "display_name")
    val displayName: String,

    @ColumnInfo(name = "size")
    val size: Long,

    @ColumnInfo(name = "is_directory")
    val isDirectory: Boolean,

    @ColumnInfo(name = "mime_type")
    val mimeType: String?,

    @ColumnInfo(name = "trashed_at")
    val trashedAt: Long,

    @ColumnInfo(name = "expires_at")
    val expiresAt: Long,

    /** xxHash64 of file content captured at trash time. Null for directories. */
    @ColumnInfo(name = "file_hash")
    val fileHash: Long? = null,

    /** How many times this entry has been restored and re-trashed. */
    @ColumnInfo(name = "restore_count", defaultValue = "0")
    val restoreCount: Int = 0,

    /** Storage volume UUID of the original file. Null for primary storage. */
    @ColumnInfo(name = "source_volume")
    val sourceVolume: String? = null,
)

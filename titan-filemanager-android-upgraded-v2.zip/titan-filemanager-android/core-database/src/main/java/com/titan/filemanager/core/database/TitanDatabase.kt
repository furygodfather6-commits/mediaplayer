package com.titan.filemanager.core.database

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.titan.filemanager.core.database.converter.TypeConverters as TitanTypeConverters
import com.titan.filemanager.core.database.dao.BookmarkDao
import com.titan.filemanager.core.database.dao.FileDao
import com.titan.filemanager.core.database.dao.HiddenFolderDao
import com.titan.filemanager.core.database.dao.PreferenceDao
import com.titan.filemanager.core.database.dao.RecentFileDao
import com.titan.filemanager.core.database.dao.TrashDao
import com.titan.filemanager.core.database.dao.VaultDao
import com.titan.filemanager.core.database.entity.BookmarkEntity
import com.titan.filemanager.core.database.entity.FileEntity
import com.titan.filemanager.core.database.entity.HiddenFolderEntity
import com.titan.filemanager.core.database.entity.PreferenceEntity
import com.titan.filemanager.core.database.entity.RecentFileEntity
import com.titan.filemanager.core.database.entity.TrashEntity
import com.titan.filemanager.core.database.entity.VaultEntity

/**
 * Titan app's Room database.
 *
 * Phase 1 — 5 entities (files, bookmarks, recent_files, hidden_folders,
 * preferences). Phase 2 will add: thumbnails, search_index, access_history,
 * usage_events, folder_visits. Phase 5 will add cloud + vault + transfer
 * history + tags.
 *
 * Schema versioning:
 *   - `exportSchema = true` writes JSON schema files to `schemas/` per
 *     version. These get committed to the repo so we can verify migrations
 *     in CI.
 *   - Migrations live in [DatabaseMigrations] — never modify an existing
 *     migration, always add a new one.
 *
 * Configuration via PRAGMAs (set in [DatabaseCallback]):
 *   - WAL journal mode (readers don't block writers)
 *   - 64MB cache_size
 *   - 256MB mmap_size (zero-copy reads)
 *   - NORMAL synchronous (safe + fast)
 *   - Foreign keys ON
 */
@Database(
    version = 5,
    entities = [
        FileEntity::class,
        BookmarkEntity::class,
        RecentFileEntity::class,
        HiddenFolderEntity::class,
        PreferenceEntity::class,
        TrashEntity::class,
        VaultEntity::class,
    ],
    exportSchema = true,
)
@TypeConverters(TitanTypeConverters::class)
abstract class TitanDatabase : RoomDatabase() {

    abstract fun fileDao(): FileDao
    abstract fun bookmarkDao(): BookmarkDao
    abstract fun recentFileDao(): RecentFileDao
    abstract fun hiddenFolderDao(): HiddenFolderDao
    abstract fun preferenceDao(): PreferenceDao
    abstract fun trashDao(): TrashDao
    abstract fun vaultDao(): VaultDao

    companion object {
        const val NAME = "titan.db"
        const val VERSION = 5
    }
}

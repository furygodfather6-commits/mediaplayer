package com.titan.filemanager.core.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.titan.filemanager.core.database.entity.RecentFileEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface RecentFileDao {

    @Query("""
        SELECT * FROM recent_files
        ORDER BY last_accessed_at DESC
        LIMIT :limit
    """)
    fun observeRecent(limit: Int = 50): Flow<List<RecentFileEntity>>

    @Query("""
        SELECT * FROM recent_files
        ORDER BY last_accessed_at DESC
        LIMIT :limit
    """)
    suspend fun getRecent(limit: Int = 50): List<RecentFileEntity>

    @Query("SELECT * FROM recent_files WHERE path = :path LIMIT 1")
    suspend fun getByPath(path: String): RecentFileEntity?

    /**
     * Insert or update — if the path already exists, increment access_count
     * and update last_accessed_at. Done atomically via transaction.
     */
    suspend fun upsertAccess(path: String, name: String, mimeType: String?, now: Long) {
        val existing = getByPath(path)
        val updated = if (existing == null) {
            RecentFileEntity(
                path = path,
                name = name,
                mimeType = mimeType,
                lastAccessedAt = now,
                accessCount = 1,
            )
        } else {
            existing.copy(
                name = name,
                mimeType = mimeType ?: existing.mimeType,
                lastAccessedAt = now,
                accessCount = existing.accessCount + 1,
            )
        }
        insert(updated)
        trim(RecentFileEntity.MAX_RECENT)
    }

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: RecentFileEntity): Long

    /**
     * Keep only the [keep] most-recent entries — older ones are deleted.
     */
    @Query("""
        DELETE FROM recent_files
        WHERE id NOT IN (
            SELECT id FROM recent_files
            ORDER BY last_accessed_at DESC
            LIMIT :keep
        )
    """)
    suspend fun trim(keep: Int): Int

    @Query("DELETE FROM recent_files WHERE path = :path")
    suspend fun deleteByPath(path: String): Int

    @Query("DELETE FROM recent_files")
    suspend fun clearAll(): Int
}

package com.titan.filemanager.core.database.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.titan.filemanager.core.database.entity.VaultEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface VaultDao {

    @Query("SELECT * FROM vault_entries ORDER BY added_at DESC")
    fun observeAll(): Flow<List<VaultEntity>>

    @Query("SELECT * FROM vault_entries ORDER BY added_at DESC")
    suspend fun getAll(): List<VaultEntity>

    @Query("SELECT * FROM vault_entries WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): VaultEntity?

    @Query("SELECT * FROM vault_entries WHERE id IN (:ids)")
    suspend fun getByIds(ids: List<Long>): List<VaultEntity>

    @Query("SELECT COUNT(*) FROM vault_entries")
    suspend fun count(): Int

    @Query("SELECT COUNT(*) FROM vault_entries")
    fun observeCount(): Flow<Int>

    @Query("SELECT COALESCE(SUM(original_size), 0) FROM vault_entries")
    fun observeTotalOriginalSize(): Flow<Long>

    @Query("SELECT COALESCE(SUM(encrypted_size), 0) FROM vault_entries")
    fun observeTotalEncryptedSize(): Flow<Long>

    @Query("SELECT COALESCE(MIN(added_at), 0) FROM vault_entries")
    suspend fun oldestAddedAt(): Long

    @Query("SELECT COALESCE(MAX(added_at), 0) FROM vault_entries")
    suspend fun newestAddedAt(): Long

    @Query("SELECT COALESCE(SUM(extract_count), 0) FROM vault_entries")
    suspend fun totalExtractCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: VaultEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(entities: List<VaultEntity>): List<Long>

    @Update
    suspend fun update(entity: VaultEntity)

    @Query("UPDATE vault_entries SET extract_count = extract_count + 1, last_extracted_at = :now WHERE id = :id")
    suspend fun incrementExtractCount(id: Long, now: Long)

    @Delete
    suspend fun delete(entity: VaultEntity)

    @Query("DELETE FROM vault_entries WHERE id = :id")
    suspend fun deleteById(id: Long): Int

    @Query("DELETE FROM vault_entries WHERE id IN (:ids)")
    suspend fun deleteByIds(ids: List<Long>): Int

    @Query("DELETE FROM vault_entries")
    suspend fun deleteAll(): Int
}

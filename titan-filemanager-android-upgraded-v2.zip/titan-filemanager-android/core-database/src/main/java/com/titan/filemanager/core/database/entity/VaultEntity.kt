package com.titan.filemanager.core.database.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * An entry in the encrypted vault.
 *
 * v2 — adds three new columns for integrity verification and
 * access tracking:
 *   - [integrityHash] SHA-256 of the plaintext, captured at encryption
 *     time and stored encrypted. Used to detect tampering / silent
 *     corruption on extract.
 *   - [extractCount] how many times this entry has been extracted.
 *   - [lastExtractedAt] timestamp of the last successful extract, or
 *     null if never extracted.
 *
 * Stored encrypted-at-rest: displayName + mimeType + integrityHash are
 * encrypted with the vault's master key. Only when the vault is
 * unlocked are these decrypted in-memory.
 */
@Entity(
    tableName = "vault_entries",
    indices = [
        Index(value = ["encrypted_path"]),
        Index(value = ["added_at"]),
    ],
)
data class VaultEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    @ColumnInfo(name = "encrypted_path")
    val encryptedPath: String,

    @ColumnInfo(name = "encrypted_display_name")
    val encryptedDisplayName: String,

    @ColumnInfo(name = "original_size")
    val originalSize: Long,

    @ColumnInfo(name = "encrypted_size")
    val encryptedSize: Long,

    @ColumnInfo(name = "encrypted_mime_type")
    val encryptedMimeType: String?,

    @ColumnInfo(name = "added_at")
    val addedAt: Long,

    /** Encrypted SHA-256 of the plaintext — used for integrity verification. */
    @ColumnInfo(name = "integrity_hash")
    val integrityHash: String? = null,

    @ColumnInfo(name = "extract_count", defaultValue = "0")
    val extractCount: Int = 0,

    @ColumnInfo(name = "last_extracted_at")
    val lastExtractedAt: Long? = null,
)

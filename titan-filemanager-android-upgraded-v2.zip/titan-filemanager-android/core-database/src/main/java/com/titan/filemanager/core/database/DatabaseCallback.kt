package com.titan.filemanager.core.database

import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import timber.log.Timber

/**
 * Callback invoked by Room when the database is created or opened.
 *
 * Used to set PRAGMA values that improve performance:
 *
 *  - `journal_mode = WAL` — Write-Ahead Logging. Readers don't block
 *    writers; multiple readers can run concurrently.
 *  - `synchronous = NORMAL` — Safe under WAL + crashes; faster than FULL.
 *  - `cache_size = -65536` — 64MB page cache (negative = KB).
 *  - `mmap_size = 268435456` — 256MB memory-mapped I/O (zero-copy reads).
 *  - `temp_store = MEMORY` — Temp tables/indexes in RAM, not on disk.
 *  - `foreign_keys = ON` — Enforce FK constraints (default OFF in SQLite).
 *
 * Phase 1 — basic PRAGMAs. Phase 3 will add: `auto_vacuum = INCREMENTAL`,
 * `wal_autocheckpoint = 1000`, and a `WalModeManager` that periodically
 * runs `PRAGMA wal_checkpoint(TRUNCATE)`.
 */
class DatabaseCallback : RoomDatabase.Callback() {

    override fun onCreate(db: SupportSQLiteDatabase) {
        super.onCreate(db)
        Timber.i("TitanDatabase created — applying PRAGMAs")
        applyPragmas(db)
        seedDefaults(db)
    }

    override fun onOpen(db: SupportSQLiteDatabase) {
        super.onOpen(db)
        // Re-apply pragmas on every open — they persist per-connection
        applyPragmas(db)
    }

    private fun applyPragmas(db: SupportSQLiteDatabase) {
        // PRAGMA journal_mode = WAL returns a cursor — must use query, not execSQL
        try { db.query("PRAGMA journal_mode = WAL").use { it.moveToFirst() } } catch (e: Exception) { Timber.w(e, "PRAGMA journal_mode failed") }
        try { db.query("PRAGMA synchronous = NORMAL").use { it.moveToFirst() } } catch (e: Exception) { Timber.w(e, "PRAGMA synchronous failed") }
        try { db.query("PRAGMA cache_size = -65536").use { it.moveToFirst() } } catch (e: Exception) { Timber.w(e, "PRAGMA cache_size failed") }
        try { db.query("PRAGMA mmap_size = 268435456").use { it.moveToFirst() } } catch (e: Exception) { Timber.w(e, "PRAGMA mmap_size failed") }
        try { db.query("PRAGMA temp_store = MEMORY").use { it.moveToFirst() } } catch (e: Exception) { Timber.w(e, "PRAGMA temp_store failed") }
        try { db.query("PRAGMA foreign_keys = ON").use { it.moveToFirst() } } catch (e: Exception) { Timber.w(e, "PRAGMA foreign_keys failed") }
    }

    /**
     * Seed default preference values — runs only on first DB creation.
     */
    private fun seedDefaults(db: SupportSQLiteDatabase) {
        val now = System.currentTimeMillis()
        db.execSQL(
            "INSERT OR IGNORE INTO preferences(key, value, updated_at) VALUES (?, ?, ?)",
            arrayOf("schema_version", "1", now.toString()),
        )
        db.execSQL(
            "INSERT OR IGNORE INTO preferences(key, value, updated_at) VALUES (?, ?, ?)",
            arrayOf("created_at", now.toString(), now.toString()),
        )
    }
}

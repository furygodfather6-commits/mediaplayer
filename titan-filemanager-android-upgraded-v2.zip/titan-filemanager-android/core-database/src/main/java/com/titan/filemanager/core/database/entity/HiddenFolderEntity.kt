package com.titan.filemanager.core.database.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Hidden-folder entry — a folder the user explicitly marked as hidden.
 *
 * Hidden folders:
 *   - Don't appear in the browser (unless "Show hidden" toggle is on)
 *   - Can be locked behind biometric auth (Phase 5 — vault integration)
 *
 * This is *different* from dotfile-hidden (`.foo`) — that's a filesystem
 * property tracked in [FileEntity.isHidden]. This table is for
 * user-marked folders regardless of filesystem permissions.
 */
@Entity(
    tableName = "hidden_folders",
    indices = [Index(value = ["path"], unique = true)],
)
data class HiddenFolderEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    @ColumnInfo(name = "path")
    val path: String,

    @ColumnInfo(name = "display_name")
    val displayName: String,

    @ColumnInfo(name = "created_at")
    val createdAt: Long,
)

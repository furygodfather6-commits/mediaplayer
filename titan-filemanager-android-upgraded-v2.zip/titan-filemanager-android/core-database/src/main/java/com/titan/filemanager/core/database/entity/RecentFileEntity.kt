package com.titan.filemanager.core.database.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Recently-accessed file — used to populate the "Recent" list on the
 * Home screen and the "Recent files" search filter.
 *
 * We keep at most [MAX_RECENT] rows per user — older entries are
 * evicted via a periodic cleanup job (Phase 2 WorkManager).
 *
 * Schema:
 *   - [path] is unique (one row per file).
 *   - [lastAccessedAt] is indexed for "ORDER BY lastAccessedAt DESC" queries.
 */
@Entity(
    tableName = "recent_files",
    indices = [
        Index(value = ["path"], unique = true),
        Index(value = ["last_accessed_at"]),
    ],
)
data class RecentFileEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    @ColumnInfo(name = "path")
    val path: String,

    @ColumnInfo(name = "name")
    val name: String,

    @ColumnInfo(name = "mime_type")
    val mimeType: String? = null,

    @ColumnInfo(name = "last_accessed_at")
    val lastAccessedAt: Long,

    @ColumnInfo(name = "access_count")
    val accessCount: Int = 1,
) {
    companion object {
        const val MAX_RECENT = 200
    }
}

package com.titan.filemanager.core.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.titan.filemanager.core.database.entity.FileEntity
import kotlinx.coroutines.flow.Flow

/**
 * Data-access object for [FileEntity].
 *
 * All methods are `suspend` (or return [Flow]) because Room runs them
 * on a background dispatcher. Callers should use `withContext(io)` if
 * they need to chain multiple operations.
 */
@Dao
interface FileDao {

    /**
     * Get all entries that are direct children of [parentPath].
     *
     * Sorted by [sortBy] — supports "name", "size", "modified_at", "is_directory".
     * The ORDER BY is built at runtime by the repository (not here) because
     * Room can't parameterize column names.
     */
    @Query("""
        SELECT * FROM files
        WHERE parent_path = :parentPath
        ORDER BY is_directory DESC, name COLLATE NOCASE ASC
    """)
    fun observeChildren(parentPath: String): Flow<List<FileEntity>>

    @Query("SELECT * FROM files WHERE parent_path = :parentPath")
    suspend fun getChildren(parentPath: String): List<FileEntity>

    @Query("SELECT * FROM files WHERE path = :path LIMIT 1")
    suspend fun getByPath(path: String): FileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: FileEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(entities: List<FileEntity>)

    /**
     * Atomic batch insert + delete — used by the scan engine to
     * replace a directory's children in one transaction.
     *
     * Returns the number of deleted rows.
     */
    @Transaction
    suspend fun replaceChildren(parentPath: String, newChildren: List<FileEntity>) {
        deleteByParent(parentPath)
        upsertAll(newChildren)
    }

    @Query("DELETE FROM files WHERE parent_path = :parentPath")
    suspend fun deleteByParent(parentPath: String): Int

    @Query("DELETE FROM files WHERE path = :path")
    suspend fun deleteByPath(path: String): Int

    @Query("DELETE FROM files WHERE path IN (:paths)")
    suspend fun deleteByPaths(paths: List<String>): Int

    /**
     * Delete all files whose `scanned_at` is older than [cutoffMillis].
     * Used by the periodic cache-cleanup worker (Phase 2).
     */
    @Query("DELETE FROM files WHERE scanned_at < :cutoffMillis")
    suspend fun deleteOlderThan(cutoffMillis: Long): Int

    @Query("SELECT COUNT(*) FROM files")
    suspend fun count(): Int

    @Query("SELECT COUNT(*) FROM files WHERE parent_path = :parentPath")
    suspend fun countChildren(parentPath: String): Int

    /**
     * Search file names by prefix — used by the search module (Phase 4).
     * Case-insensitive due to COLLATE NOCASE.
     */
    @Query("""
        SELECT * FROM files
        WHERE name LIKE :prefix || '%'
        COLLATE NOCASE
        LIMIT :limit
    """)
    suspend fun searchByNamePrefix(prefix: String, limit: Int = 50): List<FileEntity>
}

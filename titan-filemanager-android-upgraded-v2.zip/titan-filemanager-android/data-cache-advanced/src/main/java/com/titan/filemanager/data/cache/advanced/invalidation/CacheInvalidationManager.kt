package com.titan.filemanager.data.cache.advanced.invalidation

import android.os.FileObserver
import android.util.Log
import com.titan.filemanager.data.cache.advanced.engine.HotDirectoryCache
import com.titan.filemanager.data.cache.advanced.engine.L1RamCache
import com.titan.filemanager.data.cache.advanced.engine.L3SqliteCache
import com.titan.filemanager.data.cache.advanced.engine.ThumbnailCache
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

/**
 * Cache Invalidation Manager.
 *
 * Ported technique: #52 Cache invalidation
 *
 * Strategies:
 *  1. FileObserver-based (real-time)
 *  2. TTL-based (automatic expiry)
 *  3. Version-based (inode/mtime check)
 *  4. Manual (explicit invalidation)
 *  5. Cascade (parent → children)
 */
class CacheInvalidationManager(
    private val l1Cache: L1RamCache<List<com.titan.filemanager.core.model.file.FileItem>>,
    private val l3Cache: L3SqliteCache,
    private val thumbnailCache: ThumbnailCache,
    @Suppress("UNUSED_PARAMETER") hotDirCache: HotDirectoryCache,
) {

    companion object {
        private const val TAG = "CacheInvalidation"
        private const val DEBOUNCE_MS = 300L
    }

    private val scope = CoroutineScope(
        Dispatchers.IO + SupervisorJob() + CoroutineName("CacheInvalidation"),
    )

    private val observers = ConcurrentHashMap<String, FileObserver>()
    private val debounceJobs = ConcurrentHashMap<String, kotlinx.coroutines.Job>()
    private val pendingInvalidations = ConcurrentHashMap.newKeySet<String>()

    /**
     * Watch directory for changes.
     * Ported techniques:
     *   #54 FileObserver integration
     *   #58 No full reload after changes
     */
    fun watchDirectory(path: String) {
        if (observers.containsKey(path)) return

        val observer = createFileObserver(path)
        observers[path] = observer
        observer.startWatching()
    }

    fun unwatchDirectory(path: String) {
        observers.remove(path)?.stopWatching()
    }

    private fun createFileObserver(path: String): FileObserver {
        val mask = FileObserver.CREATE or
            FileObserver.DELETE or
            FileObserver.MODIFY or
            FileObserver.MOVED_FROM or
            FileObserver.MOVED_TO or
            FileObserver.ATTRIB

        return object : FileObserver(path, mask) {
            override fun onEvent(event: Int, fileName: String?) {
                if (fileName == null) return
                Log.d(TAG, "FileObserver event: ${eventName(event)} $path/$fileName")
                scheduleInvalidation(path, event)
            }
        }
    }

    private fun scheduleInvalidation(dirPath: String, event: Int) {
        pendingInvalidations.add(dirPath)
        debounceJobs[dirPath]?.cancel()
        debounceJobs[dirPath] = scope.launch {
            delay(DEBOUNCE_MS)
            val paths = pendingInvalidations.toList()
            pendingInvalidations.clear()
            processPendingInvalidations(paths, event)
        }
    }

    private suspend fun processPendingInvalidations(dirPaths: List<String>, event: Int) {
        dirPaths.forEach { dirPath ->
            invalidateDirectory(dirPath)
            invalidateParentChildCount(dirPath)
        }
        l3Cache.invalidateCategory("directory_scan")
    }

    fun invalidateDirectory(path: String) {
        l1Cache.remove(path)
        l1Cache.remove("hot_$path")
        scope.launch { l3Cache.invalidate(path) }
    }

    fun invalidateFileThumbnail(filePath: String) {
        thumbnailCache.remove(filePath)
    }

    /** Cascade invalidation: path and all parents. */
    fun invalidateCascade(path: String) {
        var current = path
        while (current.contains('/')) {
            invalidateDirectory(current)
            current = current.substringBeforeLast('/')
        }
    }

    private fun invalidateParentChildCount(childPath: String) {
        val parent = childPath.substringBeforeLast('/')
        if (parent.isNotEmpty() && parent != childPath) {
            l1Cache.remove("childcount_$parent")
        }
    }

    fun invalidateAll() {
        l1Cache.clear()
        scope.launch { l3Cache.invalidateCategory("all") }
    }

    private fun eventName(event: Int): String = when (event) {
        FileObserver.CREATE -> "CREATE"
        FileObserver.DELETE -> "DELETE"
        FileObserver.MODIFY -> "MODIFY"
        FileObserver.MOVED_FROM -> "MOVED_FROM"
        FileObserver.MOVED_TO -> "MOVED_TO"
        FileObserver.ATTRIB -> "ATTRIB"
        else -> "UNKNOWN($event)"
    }

    fun stopAllObservers() {
        observers.values.forEach { it.stopWatching() }
        observers.clear()
        debounceJobs.values.forEach { it.cancel() }
        debounceJobs.clear()
    }

    fun shutdown() {
        stopAllObservers()
        scope.cancel()
    }
}

package com.titan.filemanager.data.cache.advanced.engine

import com.titan.filemanager.data.cache.advanced.model.CacheEntryPriority
import com.titan.filemanager.data.cache.advanced.model.CacheStats
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream

/**
 * L2 Compressed RAM Cache.
 *
 * Ported technique: #41 L2 compressed RAM cache
 *
 * Properties:
 *  - Data stored as GZIP-compressed bytes
 *  - 3-5× more items fit in same RAM budget
 *  - Slight decompression overhead (~1-2ms)
 *  - Best for metadata (text-heavy compresses well)
 *
 * Compression ratio targets:
 *  - FileItem list: 70-80% compression
 *  - Metadata strings: 60-75% compression
 *  - Paths/names: 65-80% compression
 */
class L2CompressedRamCache<T>(
    private val name: String,
    private val maxSizeBytes: Long,
    private val serializer: CacheSerializer<T>,
    private val defaultTtlMs: Long = 5 * 60_000L,  // 5 minutes
) {

    private val storage = ConcurrentHashMap<String, CompressedEntry>(200)

    private val currentSizeBytes = AtomicLong(0L)
    private val hitCount = AtomicLong(0L)
    private val missCount = AtomicLong(0L)
    private val evictionCount = AtomicLong(0L)
    private val totalUncompressedBytes = AtomicLong(0L)
    private val totalCompressedBytes = AtomicLong(0L)

    /** GET with decompression. ~1-2ms overhead. */
    fun get(key: String): T? {
        val entry = storage[key]

        if (entry == null) {
            missCount.incrementAndGet()
            return null
        }

        if (System.currentTimeMillis() > entry.expiresAt) {
            remove(key)
            missCount.incrementAndGet()
            return null
        }

        entry.lastAccess = System.currentTimeMillis()
        entry.accessCount++
        hitCount.incrementAndGet()

        return try {
            val decompressed = decompress(entry.compressedData)
            serializer.deserialize(decompressed)
        } catch (_: Exception) {
            remove(key)
            null
        }
    }

    /** PUT with compression. */
    fun put(
        key: String,
        value: T,
        ttlMs: Long = defaultTtlMs,
        priority: CacheEntryPriority = CacheEntryPriority.NORMAL,
    ): Boolean {
        val serialized = serializer.serialize(value)
        val compressed = compress(serialized)

        totalUncompressedBytes.addAndGet(serialized.size.toLong())
        totalCompressedBytes.addAndGet(compressed.size.toLong())

        if (currentSizeBytes.get() + compressed.size > maxSizeBytes) {
            evictLRU(compressed.size.toLong())
        }

        val entry = CompressedEntry(
            key = key,
            compressedData = compressed,
            uncompressedSize = serialized.size.toLong(),
            expiresAt = System.currentTimeMillis() + ttlMs,
            priority = priority,
        )

        val old = storage.put(key, entry)
        old?.let { currentSizeBytes.addAndGet(-it.compressedData.size.toLong()) }
        currentSizeBytes.addAndGet(compressed.size.toLong())
        return true
    }

    fun remove(key: String): Boolean {
        val entry = storage.remove(key) ?: return false
        currentSizeBytes.addAndGet(-entry.compressedData.size.toLong())
        return true
    }

    private fun compress(data: ByteArray): ByteArray {
        val baos = ByteArrayOutputStream(data.size / 3)
        GZIPOutputStream(baos).use { gzip -> gzip.write(data) }
        return baos.toByteArray()
    }

    private fun decompress(compressed: ByteArray): ByteArray {
        val bais = ByteArrayInputStream(compressed)
        return GZIPInputStream(bais).use { gzip -> gzip.readBytes() }
    }

    private fun evictLRU(requiredBytes: Long) {
        var freed = 0L
        val sorted = storage.values
            .filter { it.priority != CacheEntryPriority.CRITICAL }
            .sortedBy { it.lastAccess }

        for (entry in sorted) {
            if (freed >= requiredBytes) break
            storage.remove(entry.key)?.let {
                freed += it.compressedData.size.toLong()
                currentSizeBytes.addAndGet(-it.compressedData.size.toLong())
                evictionCount.incrementAndGet()
            }
        }
    }

    fun getCompressionRatio(): Float {
        val uncompressed = totalUncompressedBytes.get()
        val compressed = totalCompressedBytes.get()
        return if (compressed > 0) uncompressed.toFloat() / compressed.toFloat() else 1f
    }

    fun getStats(): CacheStats {
        val hits = hitCount.get()
        val total = hits + missCount.get()
        return CacheStats(
            levelName = "L2-$name",
            itemCount = storage.size,
            sizeBytes = currentSizeBytes.get(),
            maxSizeBytes = maxSizeBytes,
            hitCount = hits,
            missCount = missCount.get(),
            evictionCount = evictionCount.get(),
            hitRate = if (total > 0) hits.toFloat() / total else 0f,
            utilizationPercent = currentSizeBytes.get().toFloat() / maxSizeBytes * 100f,
        )
    }

    fun clear() {
        storage.clear()
        currentSizeBytes.set(0L)
    }

    /** Interface for serializing cache values. */
    interface CacheSerializer<T> {
        fun serialize(value: T): ByteArray
        fun deserialize(data: ByteArray): T
    }

    private data class CompressedEntry(
        val key: String,
        val compressedData: ByteArray,
        val uncompressedSize: Long,
        val expiresAt: Long,
        val priority: CacheEntryPriority,
        var lastAccess: Long = System.currentTimeMillis(),
        var accessCount: Int = 0,
    )
}

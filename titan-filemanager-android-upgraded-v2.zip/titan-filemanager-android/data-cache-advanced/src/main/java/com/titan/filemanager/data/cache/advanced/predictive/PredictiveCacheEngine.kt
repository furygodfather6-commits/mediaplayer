package com.titan.filemanager.data.cache.advanced.predictive

import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.data.cache.advanced.engine.HotDirectoryCache
import com.titan.filemanager.data.cache.advanced.engine.L1RamCache
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.PriorityBlockingQueue

/**
 * Predictive Cache Engine.
 *
 * Ported techniques:
 *   #51 Predictive cache
 *   #126 Usage learning
 *   #130 Smart prefetch
 *   #131 Hot-folder detection
 *
 * Learns navigation patterns and pre-caches directories the user will likely
 * visit next.
 */
class PredictiveCacheEngine(
    private val l1Cache: L1RamCache<List<FileItem>>,
    private val hotDirCache: HotDirectoryCache,
) {

    companion object {
        private const val MAX_HISTORY = 50
        private const val PATTERN_WINDOW = 5
        private const val MIN_PATTERN_CONFIDENCE = 0.6f
        private const val MAX_PREFETCH_QUEUE = 10
    }

    private val navHistory = ArrayDeque<NavigationEvent>(MAX_HISTORY)
    private val patternDb = ConcurrentHashMap<String, PatternEntry>()

    private val prefetchQueue = PriorityBlockingQueue<PrefetchTask>(
        MAX_PREFETCH_QUEUE,
        compareByDescending { it.confidence },
    )

    private val prefetchJobs = ConcurrentHashMap<String, Job>()

    private val scope = CoroutineScope(
        Dispatchers.IO.limitedParallelism(2) +
            SupervisorJob() +
            CoroutineName("PredictiveCache"),
    )

    /** Called on every navigation — records event and triggers prediction. */
    fun onNavigation(path: String, items: List<FileItem>) {
        navHistory.addLast(NavigationEvent(path, System.currentTimeMillis()))
        if (navHistory.size > MAX_HISTORY) navHistory.removeFirst()

        learnPattern()

        val predictions = predict(path)
        schedulePrefetch(predictions, items)
    }

    private fun learnPattern() {
        if (navHistory.size < 2) return

        val recent = navHistory.toList().takeLast(PATTERN_WINDOW)

        for (i in 0 until recent.size - 1) {
            val to = recent[i + 1].path
            val key = buildPatternKey(recent.take(i + 1).map { it.path })

            val entry = patternDb.getOrPut(key) { PatternEntry(key, mutableMapOf()) }
            entry.nextPaths[to] = (entry.nextPaths[to] ?: 0) + 1
            entry.totalObservations++
        }
    }

    private fun predict(currentPath: String): List<Pair<String, Float>> {
        val predictions = mutableListOf<Pair<String, Float>>()

        for (windowSize in minOf(PATTERN_WINDOW, navHistory.size) downTo 1) {
            val sequence = navHistory.toList().takeLast(windowSize).map { it.path }
            val key = buildPatternKey(sequence)

            patternDb[key]?.let { entry ->
                val total = entry.totalObservations.toFloat()
                entry.nextPaths.forEach { (nextPath, count) ->
                    val confidence = count / total
                    if (confidence >= MIN_PATTERN_CONFIDENCE) {
                        predictions.add(Pair(nextPath, confidence))
                    }
                }
            }
            if (predictions.isNotEmpty()) break
        }

        // Add children of current dir as low-confidence predictions
        l1Cache.get(currentPath)?.let { items ->
            items.filter { it.isDirectory }
                .take(3)
                .forEach { dir -> predictions.add(Pair(dir.path, 0.3f)) }
        }

        return predictions
            .sortedByDescending { it.second }
            .distinctBy { it.first }
            .take(5)
    }

    private fun schedulePrefetch(
        predictions: List<Pair<String, Float>>,
        @Suppress("UNUSED_PARAMETER") currentItems: List<FileItem>,
    ) {
        predictions.forEach { (path, confidence) ->
            if (!l1Cache.containsKey(path) && !prefetchJobs.containsKey(path)) {
                prefetchQueue.offer(PrefetchTask(path, confidence))
            }
        }
        processPrefetchQueue()
    }

    private fun processPrefetchQueue() {
        while (prefetchJobs.size < 2 && prefetchQueue.isNotEmpty()) {
            val task = prefetchQueue.poll() ?: break
            if (l1Cache.containsKey(task.path)) continue

            val job = scope.launch {
                try {
                    delay(500)  // Don't compete with active scan
                } finally {
                    prefetchJobs.remove(task.path)
                }
            }
            prefetchJobs[task.path] = job
        }
    }

    private fun buildPatternKey(paths: List<String>): String =
        paths.joinToString("→")

    fun getPatternCount(): Int = patternDb.size

    fun cleanup() {
        scope.cancel()
        prefetchJobs.values.forEach { it.cancel() }
    }

    data class NavigationEvent(val path: String, val timestamp: Long)

    data class PatternEntry(
        val key: String,
        val nextPaths: MutableMap<String, Int> = mutableMapOf(),
        var totalObservations: Int = 0,
    )

    data class PrefetchTask(val path: String, val confidence: Float)
}

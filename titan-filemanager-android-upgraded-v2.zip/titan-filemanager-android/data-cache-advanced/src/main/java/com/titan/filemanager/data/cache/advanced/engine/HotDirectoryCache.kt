package com.titan.filemanager.data.cache.advanced.engine

import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.data.cache.advanced.model.CacheEntryPriority
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * Hot Directory Cache.
 *
 * Ported technique: #50 Hot-directory cache
 *
 * Tracks directories that are frequently accessed and pins them in
 * CRITICAL-priority slots so they survive eviction sweeps.
 *
 * Hot detection criteria:
 *  - Access frequency (3+ accesses within 10 minutes)
 *  - Recency of access
 *  - Navigation depth (shallow = more likely hot)
 */
class HotDirectoryCache(
    private val l1Cache: L1RamCache<List<FileItem>>,
    private val maxHotDirs: Int = 10,
) {

    companion object {
        private const val HOT_THRESHOLD_ACCESSES = 3
        private const val HOT_THRESHOLD_PERIOD_MS = 10 * 60_000L
        private const val HOT_TTL_MS = 5 * 60_000L
    }

    private val accessTracker = ConcurrentHashMap<String, AccessInfo>(100)
    private val hotDirectories = ConcurrentHashMap.newKeySet<String>()

    private val hotHits = AtomicLong(0L)
    private val promotions = AtomicLong(0L)

    /** Record directory access; promotes to hot status when threshold reached. */
    fun recordAccess(path: String, items: List<FileItem>) {
        val info = accessTracker.getOrPut(path) { AccessInfo(path) }
        info.recordAccess()

        if (!hotDirectories.contains(path) && info.isHot()) {
            promote(path, items)
        } else if (hotDirectories.contains(path)) {
            refreshHotEntry(path, items)
        }
    }

    /** Get hot directory contents, or null if not hot / expired. */
    fun getHot(path: String): List<FileItem>? {
        if (!hotDirectories.contains(path)) return null

        val items = l1Cache.get("hot_$path")
        if (items != null) {
            hotHits.incrementAndGet()
        } else {
            hotDirectories.remove(path)
        }
        return items
    }

    private fun promote(path: String, items: List<FileItem>) {
        if (hotDirectories.size >= maxHotDirs) {
            demoteLeastHot()
        }

        hotDirectories.add(path)

        val estimatedSize = items.size * 200L
        l1Cache.put(
            key = "hot_$path",
            value = items,
            sizeBytes = estimatedSize,
            ttlMs = HOT_TTL_MS,
            priority = CacheEntryPriority.CRITICAL,
        )
        promotions.incrementAndGet()
    }

    private fun refreshHotEntry(path: String, items: List<FileItem>) {
        val estimatedSize = items.size * 200L
        l1Cache.put(
            key = "hot_$path",
            value = items,
            sizeBytes = estimatedSize,
            ttlMs = HOT_TTL_MS,
            priority = CacheEntryPriority.CRITICAL,
        )
    }

    private fun demoteLeastHot() {
        val leastHot = hotDirectories
            .mapNotNull { path -> accessTracker[path]?.let { Pair(path, it) } }
            .minByOrNull { it.second.getHotScore() }
            ?.first

        leastHot?.let { path ->
            hotDirectories.remove(path)
            l1Cache.remove("hot_$path")
        }
    }

    fun getHotDirectories(): Set<String> = hotDirectories.toSet()

    fun getHotScore(path: String): Double =
        accessTracker[path]?.getHotScore() ?: 0.0

    fun getStats(): HotCacheStats = HotCacheStats(
        hotDirCount = hotDirectories.size,
        hotHits = hotHits.get(),
        promotions = promotions.get(),
        trackedDirs = accessTracker.size,
    )

    data class AccessInfo(
        val path: String,
        private val accessTimes: ArrayDeque<Long> = ArrayDeque(20),
    ) {
        fun recordAccess() {
            val now = System.currentTimeMillis()
            accessTimes.addLast(now)
            while (accessTimes.isNotEmpty() &&
                now - accessTimes.first() > HOT_THRESHOLD_PERIOD_MS
            ) {
                accessTimes.removeFirst()
            }
        }

        fun isHot(): Boolean = accessTimes.size >= HOT_THRESHOLD_ACCESSES

        fun getHotScore(): Double {
            if (accessTimes.isEmpty()) return 0.0
            val now = System.currentTimeMillis()
            val recency = now - accessTimes.last()
            return accessTimes.size.toDouble() / (recency.toDouble() / 1000.0 + 1.0)
        }
    }

    data class HotCacheStats(
        val hotDirCount: Int,
        val hotHits: Long,
        val promotions: Long,
        val trackedDirs: Int,
    )
}

package com.titan.filemanager.data.cache.advanced.engine

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.titan.filemanager.data.cache.advanced.model.CacheStats
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicLong

/**
 * L3 SQLite Cache.
 *
 * Ported techniques:
 *   #42 L3 SQLite cache
 *   #87 WAL mode
 *   #88 Prepared statements
 *   #89 Batch transactions
 *   #90 Memory-mapped database
 *
 * Survives app restart. Larger capacity than RAM caches. Still faster than
 * L4 disk cache because pages live in the OS page cache.
 */
class L3SqliteCache(
    context: Context,
    private val maxSizeBytes: Long = 100 * 1024 * 1024L,  // 100MB
) : SQLiteOpenHelper(
    context,
    DATABASE_NAME,
    null,
    DATABASE_VERSION,
) {

    companion object {
        private const val DATABASE_NAME = "cache_l3_advanced.db"
        private const val DATABASE_VERSION = 1
        private const val TABLE = "cache_entries"

        private const val COL_KEY = "cache_key"
        private const val COL_VALUE = "cache_value"
        private const val COL_SIZE = "size_bytes"
        private const val COL_EXPIRES = "expires_at"
        private const val COL_ACCESSED = "last_accessed"
        private const val COL_ACCESS_CNT = "access_count"
        private const val COL_CATEGORY = "category"
        private const val COL_CREATED = "created_at"
    }

    private val hitCount = AtomicLong(0L)
    private val missCount = AtomicLong(0L)
    private val evictionCount = AtomicLong(0L)

    override fun onCreate(db: SQLiteDatabase) {
        // Performance PRAGMAs
        db.execSQL("PRAGMA journal_mode = WAL")
        db.execSQL("PRAGMA synchronous = NORMAL")
        db.execSQL("PRAGMA cache_size = -32000")    // 32MB page cache
        db.execSQL("PRAGMA temp_store = MEMORY")
        db.execSQL("PRAGMA mmap_size = 536870912")  // 512MB mmap
        db.execSQL("PRAGMA page_size = 4096")
        db.execSQL("PRAGMA auto_vacuum = INCREMENTAL")

        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS $TABLE (
                $COL_KEY        TEXT PRIMARY KEY,
                $COL_VALUE      BLOB NOT NULL,
                $COL_SIZE       INTEGER NOT NULL DEFAULT 0,
                $COL_EXPIRES    INTEGER NOT NULL DEFAULT 0,
                $COL_ACCESSED   INTEGER NOT NULL DEFAULT 0,
                $COL_ACCESS_CNT INTEGER NOT NULL DEFAULT 0,
                $COL_CATEGORY   TEXT NOT NULL DEFAULT 'default',
                $COL_CREATED    INTEGER NOT NULL DEFAULT 0
            )
            """.trimIndent(),
        )

        db.execSQL("CREATE INDEX IF NOT EXISTS idx_expires ON $TABLE($COL_EXPIRES)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_accessed ON $TABLE($COL_ACCESSED)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_category ON $TABLE($COL_CATEGORY, $COL_ACCESSED)")
    }

    override fun onUpgrade(db: SQLiteDatabase, old: Int, new: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE")
        onCreate(db)
    }

    override fun onOpen(db: SQLiteDatabase) {
        super.onOpen(db)
        if (!db.isReadOnly) {
            db.execSQL("PRAGMA journal_mode = WAL")
            db.execSQL("PRAGMA mmap_size = 536870912")
        }
    }

    /** GET — single lookup. */
    suspend fun get(key: String): ByteArray? = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()

        readableDatabase.rawQuery(
            "SELECT $COL_VALUE FROM $TABLE WHERE $COL_KEY = ? AND $COL_EXPIRES > ?",
            arrayOf(key, now.toString()),
        ).use { cursor ->
            if (!cursor.moveToFirst()) {
                missCount.incrementAndGet()
                return@withContext null
            }

            val data = cursor.getBlob(0)
            hitCount.incrementAndGet()

            updateAccessStats(key, now)
            data
        }
    }

    /** PUT — upsert with automatic eviction. */
    suspend fun put(
        key: String,
        value: ByteArray,
        category: String = "default",
        ttlMs: Long = 30 * 60_000L,  // 30 minutes
    ): Boolean = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()

        ensureCapacity(value.size.toLong())

        try {
            writableDatabase.execSQL(
                """
                INSERT INTO $TABLE
                ($COL_KEY, $COL_VALUE, $COL_SIZE, $COL_EXPIRES,
                 $COL_ACCESSED, $COL_CATEGORY, $COL_CREATED)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT($COL_KEY) DO UPDATE SET
                $COL_VALUE = excluded.$COL_VALUE,
                $COL_SIZE = excluded.$COL_SIZE,
                $COL_EXPIRES = excluded.$COL_EXPIRES,
                $COL_ACCESSED = excluded.$COL_ACCESSED,
                $COL_CATEGORY = excluded.$COL_CATEGORY
                """.trimIndent(),
                arrayOf(key, value, value.size.toLong(), now + ttlMs, now, category, now),
            )
            true
        } catch (_: Exception) {
            false
        }
    }

    /** Batch GET — single query for multiple keys (Technique #89). */
    suspend fun getBatch(keys: List<String>): Map<String, ByteArray> =
        withContext(Dispatchers.IO) {
            if (keys.isEmpty()) return@withContext emptyMap()

            val now = System.currentTimeMillis()
            val placeholders = keys.joinToString(",") { "?" }
            val result = HashMap<String, ByteArray>(keys.size)

            readableDatabase.rawQuery(
                """SELECT $COL_KEY, $COL_VALUE FROM $TABLE
                   WHERE $COL_KEY IN ($placeholders)
                   AND $COL_EXPIRES > ?""",
                (keys + now.toString()).toTypedArray(),
            ).use { cursor ->
                while (cursor.moveToNext()) {
                    val key = cursor.getString(0)
                    val value = cursor.getBlob(1)
                    result[key] = value
                    hitCount.incrementAndGet()
                }
            }

            val misses = keys.size - result.size
            missCount.addAndGet(misses.toLong())
            result
        }

    /** Batch PUT in single transaction (Technique #89). */
    suspend fun putBatch(
        entries: Map<String, ByteArray>,
        category: String = "default",
        ttlMs: Long = 30 * 60_000L,
    ): Boolean = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val totalSize = entries.values.sumOf { it.size.toLong() }
        ensureCapacity(totalSize)

        writableDatabase.beginTransactionNonExclusive()
        try {
            entries.forEach { (key, value) ->
                writableDatabase.execSQL(
                    """
                    INSERT INTO $TABLE
                    ($COL_KEY, $COL_VALUE, $COL_SIZE, $COL_EXPIRES,
                     $COL_ACCESSED, $COL_CATEGORY, $COL_CREATED)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT($COL_KEY) DO UPDATE SET
                    $COL_VALUE = excluded.$COL_VALUE,
                    $COL_SIZE = excluded.$COL_SIZE,
                    $COL_EXPIRES = excluded.$COL_EXPIRES
                    """.trimIndent(),
                    arrayOf(key, value, value.size.toLong(), now + ttlMs, now, category, now),
                )
            }
            writableDatabase.setTransactionSuccessful()
            true
        } catch (_: Exception) {
            false
        } finally {
            writableDatabase.endTransaction()
        }
    }

    private fun ensureCapacity(requiredBytes: Long) {
        val currentSize = getTotalSize()
        if (currentSize + requiredBytes <= maxSizeBytes) return

        // Delete expired first
        writableDatabase.execSQL(
            "DELETE FROM $TABLE WHERE $COL_EXPIRES < ?",
            arrayOf(System.currentTimeMillis()),
        )

        val afterExpired = getTotalSize()
        if (afterExpired + requiredBytes <= maxSizeBytes) return

        // Delete LRU entries (oldest 25%)
        writableDatabase.execSQL(
            """
            DELETE FROM $TABLE WHERE $COL_KEY IN (
                SELECT $COL_KEY FROM $TABLE
                ORDER BY $COL_ACCESSED ASC
                LIMIT (
                    SELECT COUNT(*) FROM $TABLE
                ) / 4
            )
            """.trimIndent(),
        )
        evictionCount.incrementAndGet()
    }

    private fun getTotalSize(): Long {
        return readableDatabase.rawQuery(
            "SELECT SUM($COL_SIZE) FROM $TABLE", null,
        ).use { cursor ->
            if (cursor.moveToFirst()) cursor.getLong(0) else 0L
        }
    }

    private fun updateAccessStats(key: String, now: Long) {
        writableDatabase.execSQL(
            """UPDATE $TABLE SET
               $COL_ACCESSED = ?,
               $COL_ACCESS_CNT = $COL_ACCESS_CNT + 1
               WHERE $COL_KEY = ?""",
            arrayOf(now, key),
        )
    }

    suspend fun purgeExpired(): Int = withContext(Dispatchers.IO) {
        writableDatabase.delete(
            TABLE,
            "$COL_EXPIRES < ?",
            arrayOf(System.currentTimeMillis().toString()),
        )
    }

    suspend fun vacuum() = withContext(Dispatchers.IO) {
        writableDatabase.execSQL("PRAGMA incremental_vacuum(100)")
    }

    suspend fun invalidate(key: String) = withContext(Dispatchers.IO) {
        writableDatabase.delete(TABLE, "$COL_KEY = ?", arrayOf(key))
    }

    suspend fun invalidateCategory(category: String) = withContext(Dispatchers.IO) {
        writableDatabase.delete(TABLE, "$COL_CATEGORY = ?", arrayOf(category))
    }

    fun getStats(): CacheStats {
        val hits = hitCount.get()
        val total = hits + missCount.get()
        val size = getTotalSize()
        return CacheStats(
            levelName = "L3-SQLite",
            itemCount = 0,
            sizeBytes = size,
            maxSizeBytes = maxSizeBytes,
            hitCount = hits,
            missCount = missCount.get(),
            evictionCount = evictionCount.get(),
            hitRate = if (total > 0) hits.toFloat() / total else 0f,
            utilizationPercent = size.toFloat() / maxSizeBytes * 100f,
        )
    }
}

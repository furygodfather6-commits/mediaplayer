package com.titan.filemanager.data.cache.advanced.engine

import com.titan.filemanager.data.cache.advanced.model.CacheStats
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.RandomAccessFile
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * L4 Disk Cache.
 *
 * Ported techniques:
 *   #43 L4 disk cache
 *   #109 Sequential disk access
 *   #110 Read-ahead strategy
 *
 * Properties:
 *  - Files stored on disk
 *  - Largest capacity (hundreds of MB)
 *  - Survives reboots
 *  - Used for thumbnails, large data
 */
class L4DiskCache(
    private val cacheDir: File,
    private val maxSizeBytes: Long = 500 * 1024 * 1024L,  // 500MB
) {

    companion object {
        private const val DATA_DIR = "data"
        private const val TEMP_DIR = "temp"
    }

    private val index = ConcurrentHashMap<String, DiskEntry>(1000)

    private val currentSizeBytes = AtomicLong(0L)
    private val hitCount = AtomicLong(0L)
    private val missCount = AtomicLong(0L)
    private val evictionCount = AtomicLong(0L)

    private val dataDir = File(cacheDir, DATA_DIR)
    private val tempDir = File(cacheDir, TEMP_DIR)

    init {
        dataDir.mkdirs()
        tempDir.mkdirs()
        loadIndex()
    }

    /** GET from disk — uses buffered I/O for performance. */
    suspend fun get(key: String): ByteArray? = withContext(Dispatchers.IO) {
        val entry = index[key]

        if (entry == null || !entry.file.exists()) {
            missCount.incrementAndGet()
            return@withContext null
        }

        if (System.currentTimeMillis() > entry.expiresAt) {
            remove(key)
            missCount.incrementAndGet()
            return@withContext null
        }

        try {
            val data = entry.file.readBytes()
            entry.lastAccess = System.currentTimeMillis()
            entry.accessCount++
            hitCount.incrementAndGet()
            data
        } catch (_: Exception) {
            missCount.incrementAndGet()
            null
        }
    }

    /** PUT to disk — write-then-rename for atomicity. */
    suspend fun put(
        key: String,
        data: ByteArray,
        ttlMs: Long = 24 * 60 * 60_000L,  // 24 hours
    ): Boolean = withContext(Dispatchers.IO) {
        ensureCapacity(data.size.toLong())

        val tempFile = File(tempDir, "${System.nanoTime()}.tmp")
        val finalFile = File(dataDir, hashKey(key))

        try {
            tempFile.writeBytes(data)
            tempFile.renameTo(finalFile)

            val entry = DiskEntry(
                key = key,
                file = finalFile,
                sizeBytes = data.size.toLong(),
                expiresAt = System.currentTimeMillis() + ttlMs,
                createdAt = System.currentTimeMillis(),
            )

            val old = index.put(key, entry)
            old?.let { currentSizeBytes.addAndGet(-it.sizeBytes) }
            currentSizeBytes.addAndGet(data.size.toLong())
            true
        } catch (_: Exception) {
            tempFile.delete()
            false
        }
    }

    /**
     * GET with read-ahead.
     * Ported Technique #110: Read-ahead strategy.
     * Pre-reads adjacent entries for sequential access patterns.
     */
    suspend fun getWithReadAhead(
        key: String,
        adjacentKeys: List<String>,
    ): ByteArray? = withContext(Dispatchers.IO) {
        val data = get(key)

        adjacentKeys.forEach { adjKey ->
            if (!index.containsKey(adjKey)) return@forEach
            index[adjKey]?.file?.let { file ->
                try {
                    RandomAccessFile(file, "r").use { raf ->
                        val buf = ByteArray(minOf(4096, file.length().toInt()))
                        raf.read(buf)
                    }
                } catch (_: Exception) {
                }
            }
        }
        data
    }

    fun remove(key: String): Boolean {
        val entry = index.remove(key) ?: return false
        entry.file.delete()
        currentSizeBytes.addAndGet(-entry.sizeBytes)
        return true
    }

    private fun ensureCapacity(requiredBytes: Long) {
        if (currentSizeBytes.get() + requiredBytes <= maxSizeBytes) return
        val sorted = index.values.sortedBy { it.lastAccess }
        for (entry in sorted) {
            if (currentSizeBytes.get() + requiredBytes <= maxSizeBytes) break
            remove(entry.key)
            evictionCount.incrementAndGet()
        }
    }

    private fun loadIndex() {
        dataDir.listFiles()?.forEach { file ->
            val sizeBytes = file.length()
            currentSizeBytes.addAndGet(sizeBytes)
        }
    }

    private fun hashKey(key: String): String {
        val md = MessageDigest.getInstance("MD5")
        val hash = md.digest(key.toByteArray())
        return hash.joinToString("") { "%02x".format(it) }
    }

    suspend fun cleanup() = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val expired = index.entries.filter { it.value.expiresAt < now }
        expired.forEach { remove(it.key) }

        tempDir.listFiles()?.forEach { file ->
            if (now - file.lastModified() > 60_000) {
                file.delete()
            }
        }
    }

    fun getStats(): CacheStats {
        val hits = hitCount.get()
        val total = hits + missCount.get()
        return CacheStats(
            levelName = "L4-Disk",
            itemCount = index.size,
            sizeBytes = currentSizeBytes.get(),
            maxSizeBytes = maxSizeBytes,
            hitCount = hits,
            missCount = missCount.get(),
            evictionCount = evictionCount.get(),
            hitRate = if (total > 0) hits.toFloat() / total else 0f,
            utilizationPercent = currentSizeBytes.get().toFloat() / maxSizeBytes * 100f,
        )
    }

    private data class DiskEntry(
        val key: String,
        val file: File,
        val sizeBytes: Long,
        val expiresAt: Long,
        val createdAt: Long,
        var lastAccess: Long = System.currentTimeMillis(),
        var accessCount: Int = 0,
    )
}

package com.titan.filemanager.data.cache.advanced.engine

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import com.titan.filemanager.data.cache.advanced.model.CacheStats
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * Thumbnail Cache — multi-level (Bitmap RAM / JPEG RAM / Disk).
 *
 * Ported techniques:
 *   #44 Thumbnail cache
 *   #76 Smart thumbnail resolution
 *   #77 Persistent thumbnail cache
 *   #78 Thumbnail deduplication
 */
class ThumbnailCache(
    private val diskCacheDir: File,
    ramCacheSizeBytes: Int = 30 * 1024 * 1024,  // 30MB for bitmaps
) {

    companion object {
        private const val THUMB_DIR = "thumbnails"
        private const val THUMB_SIZE_SMALL = 64
        private const val THUMB_SIZE_MEDIUM = 128
        private const val THUMB_SIZE_LARGE = 256
        private const val JPEG_QUALITY = 80
    }

    // L1: Bitmap LruCache (ready to display)
    private val bitmapCache = object : LruCache<String, Bitmap>(ramCacheSizeBytes) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount

        override fun entryRemoved(
            evicted: Boolean,
            key: String,
            oldValue: Bitmap,
            newValue: Bitmap?,
        ) {
            // Recycle handled by GC; do not recycle here (may still be in use)
        }
    }

    // L2: Compressed bytes cache (smaller RAM footprint)
    private val compressedCache = ConcurrentHashMap<String, ByteArray>(200)
    private val compressedCacheSize = AtomicLong(0L)
    private val maxCompressedCacheSize = 20 * 1024 * 1024L  // 20MB

    // Content hash deduplication map
    private val contentHashMap = ConcurrentHashMap<String, String>()

    private val thumbDir = File(diskCacheDir, THUMB_DIR).also { it.mkdirs() }

    private val l1Hits = AtomicLong(0L)
    private val l2Hits = AtomicLong(0L)
    private val l3Hits = AtomicLong(0L)
    private val misses = AtomicLong(0L)

    /** GET thumbnail — checks all levels. */
    suspend fun getThumbnail(
        path: String,
        size: Int = THUMB_SIZE_MEDIUM,
    ): Bitmap? {
        val cacheKey = buildCacheKey(path, size)

        // L1: Bitmap cache (instant)
        bitmapCache.get(cacheKey)?.let { bitmap ->
            if (!bitmap.isRecycled) {
                l1Hits.incrementAndGet()
                return bitmap
            }
        }

        // L2: Compressed bytes cache
        compressedCache[cacheKey]?.let { compressed ->
            val bitmap = decodeBitmap(compressed)
            if (bitmap != null) {
                bitmapCache.put(cacheKey, bitmap)
                l2Hits.incrementAndGet()
                return bitmap
            }
        }

        // L3: Disk cache
        val diskBitmap = loadFromDisk(cacheKey)
        if (diskBitmap != null) {
            bitmapCache.put(cacheKey, diskBitmap)
            storeCompressed(cacheKey, diskBitmap)
            l3Hits.incrementAndGet()
            return diskBitmap
        }

        misses.incrementAndGet()
        return null
    }

    /** PUT thumbnail — stores in all levels. */
    suspend fun putThumbnail(
        path: String,
        bitmap: Bitmap,
        size: Int = THUMB_SIZE_MEDIUM,
        contentHash: String? = null,
    ) = withContext(Dispatchers.IO) {
        val cacheKey = buildCacheKey(path, size)

        // Deduplication
        if (contentHash != null) {
            contentHashMap[contentHash]?.let { existingKey ->
                if (existingKey != cacheKey) {
                    bitmapCache.get(existingKey)?.let { existing ->
                        bitmapCache.put(cacheKey, existing)
                        return@withContext
                    }
                }
            }
            contentHashMap[contentHash] = cacheKey
        }

        bitmapCache.put(cacheKey, bitmap)
        storeCompressed(cacheKey, bitmap)
        saveToDisk(cacheKey, bitmap)
    }

    /**
     * Smart resolution selection.
     * Ported Technique #76: Smart thumbnail resolution.
     */
    fun selectResolution(viewWidth: Int, viewHeight: Int, isGrid: Boolean): Int {
        return when {
            isGrid && viewWidth <= 100 -> THUMB_SIZE_SMALL
            isGrid -> THUMB_SIZE_MEDIUM
            viewWidth > 200 || viewHeight > 200 -> THUMB_SIZE_LARGE
            else -> THUMB_SIZE_MEDIUM
        }
    }

    private fun storeCompressed(key: String, bitmap: Bitmap) {
        val baos = ByteArrayOutputStream(bitmap.byteCount / 4)
        bitmap.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, baos)
        val compressed = baos.toByteArray()

        if (compressedCacheSize.get() + compressed.size > maxCompressedCacheSize) {
            evictCompressedCache(compressed.size.toLong())
        }

        compressedCache[key] = compressed
        compressedCacheSize.addAndGet(compressed.size.toLong())
    }

    private suspend fun loadFromDisk(key: String): Bitmap? =
        withContext(Dispatchers.IO) {
            val file = getDiskFile(key)
            if (!file.exists()) return@withContext null
            try {
                BitmapFactory.decodeFile(file.absolutePath)
            } catch (_: Exception) {
                null
            }
        }

    private suspend fun saveToDisk(key: String, bitmap: Bitmap) =
        withContext(Dispatchers.IO) {
            val file = getDiskFile(key)
            try {
                file.outputStream().use { out ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out)
                }
            } catch (_: Exception) {
                file.delete()
            }
        }

    private fun decodeBitmap(data: ByteArray): Bitmap? = try {
        BitmapFactory.decodeByteArray(data, 0, data.size)
    } catch (_: Exception) {
        null
    }

    private fun getDiskFile(key: String): File =
        File(thumbDir, key.hashCode().toString(16) + ".jpg")

    private fun buildCacheKey(path: String, size: Int): String =
        "${path.hashCode().toString(16)}_$size"

    private fun evictCompressedCache(requiredBytes: Long) {
        val toRemove = compressedCache.entries
            .take(compressedCache.size / 4)
            .map { it.key }

        toRemove.forEach { key ->
            compressedCache.remove(key)?.let { data ->
                compressedCacheSize.addAndGet(-data.size.toLong())
            }
        }
    }

    fun remove(path: String) {
        listOf(THUMB_SIZE_SMALL, THUMB_SIZE_MEDIUM, THUMB_SIZE_LARGE).forEach { size ->
            val key = buildCacheKey(path, size)
            bitmapCache.remove(key)
            compressedCache.remove(key)?.let {
                compressedCacheSize.addAndGet(-it.size.toLong())
            }
            getDiskFile(key).delete()
        }
    }

    fun getStats(): CacheStats {
        val totalHits = l1Hits.get() + l2Hits.get() + l3Hits.get()
        val total = totalHits + misses.get()
        return CacheStats(
            levelName = "Thumbnail",
            itemCount = bitmapCache.size(),
            sizeBytes = bitmapCache.size().toLong(),
            maxSizeBytes = bitmapCache.maxSize().toLong(),
            hitCount = totalHits,
            missCount = misses.get(),
            evictionCount = 0L,
            hitRate = if (total > 0) totalHits.toFloat() / total else 0f,
            utilizationPercent = 0f,
        )
    }
}

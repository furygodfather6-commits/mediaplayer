package com.titan.filemanager.data.cache.advanced.warming

import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.data.cache.advanced.engine.HotDirectoryCache
import com.titan.filemanager.data.cache.advanced.engine.L1RamCache
import com.titan.filemanager.data.cache.advanced.predictive.PredictiveCacheEngine
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Cache Warming Engine.
 *
 * Ported technique: #49 Cache warming
 *
 * Pre-populates caches before user needs data:
 *  1. On app start — warm common directories
 *  2. On idle — warm predicted directories
 *  3. On charging — deep warming
 */
class CacheWarmingEngine(
    private val l1Cache: L1RamCache<List<FileItem>>,
    private val hotDirCache: HotDirectoryCache,
    private val predictiveCache: PredictiveCacheEngine,
) {

    companion object {
        private val ALWAYS_WARM_PATHS = listOf(
            "/storage/emulated/0",
            "/storage/emulated/0/Download",
            "/storage/emulated/0/DCIM",
            "/storage/emulated/0/Documents",
            "/storage/emulated/0/Pictures",
            "/storage/emulated/0/Music",
            "/storage/emulated/0/Movies",
        )
    }

    private val scope = CoroutineScope(
        Dispatchers.IO.limitedParallelism(2) +
            SupervisorJob() +
            CoroutineName("CacheWarming"),
    )

    /** Warm essential paths on app startup — runs at LOW priority. */
    fun warmOnStartup(scanFunction: suspend (String) -> List<FileItem>) {
        scope.launch {
            delay(2000L)  // Don't compete with initial UI load

            ALWAYS_WARM_PATHS.forEach { path ->
                if (l1Cache.containsKey(path)) return@forEach
                try {
                    val items = scanFunction(path)
                    if (items.isNotEmpty()) {
                        l1Cache.put(
                            key = path,
                            value = items,
                            sizeBytes = items.size * 200L,
                            ttlMs = 2 * 60_000L,
                        )
                    }
                } catch (_: Exception) {
                    // Ignore warming failures
                }
                delay(100)
            }
        }
    }

    /** Warm hot directories from previous sessions. */
    fun warmHotDirectories(
        hotPaths: List<String>,
        scanFunction: suspend (String) -> List<FileItem>,
    ) {
        scope.launch {
            delay(3000L)

            hotPaths.take(5).forEach { path ->
                if (l1Cache.containsKey(path)) return@forEach
                try {
                    val items = scanFunction(path)
                    if (items.isNotEmpty()) {
                        hotDirCache.recordAccess(path, items)
                    }
                } catch (_: Exception) {
                }
                delay(200)
            }
        }
    }

    /**
     * Deep warming when device is charging and idle.
     * Ported technique: #150 Background optimizer while charging
     */
    fun startDeepWarmingOnCharge(
        predictedPaths: List<String>,
        scanFunction: suspend (String) -> List<FileItem>,
    ) {
        scope.launch {
            predictedPaths.forEach { path ->
                if (!isActive) return@launch
                if (l1Cache.containsKey(path)) return@forEach
                try {
                    val items = scanFunction(path)
                    l1Cache.put(
                        key = path,
                        value = items,
                        sizeBytes = items.size * 200L,
                        ttlMs = 10 * 60_000L,
                    )
                } catch (_: Exception) {
                }
                delay(500)
            }
        }
    }

    fun stop() {
        scope.cancel()
    }
}

package com.titan.filemanager.data.cache.advanced.di

import android.content.Context
import com.titan.filemanager.data.cache.advanced.engine.AdvancedCacheEngine
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/** Hilt module exposing [AdvancedCacheEngine] as application-scoped singleton. */
@Module
@InstallIn(SingletonComponent::class)
object AdvancedCacheModule {

    @Provides
    @Singleton
    fun provideAdvancedCacheEngine(
        @ApplicationContext context: Context,
    ): AdvancedCacheEngine = AdvancedCacheEngine(context)
}

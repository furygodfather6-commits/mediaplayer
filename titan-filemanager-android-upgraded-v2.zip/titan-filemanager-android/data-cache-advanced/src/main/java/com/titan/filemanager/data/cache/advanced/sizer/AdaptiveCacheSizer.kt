package com.titan.filemanager.data.cache.advanced.sizer

import android.app.ActivityManager
import android.content.Context
import android.util.Log
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Adaptive Cache Sizer.
 *
 * Ported techniques:
 *   #48 Adaptive cache sizing
 *   #158 Low-memory mode
 *
 * Dynamically adjusts cache sizes based on:
 *  - Available device RAM
 *  - Current memory pressure
 *  - App memory class
 *  - Cache hit rates
 */
class AdaptiveCacheSizer(private val context: Context) {

    companion object {
        private const val TAG = "AdaptiveCacheSizer"
        private const val CHECK_INTERVAL_MS = 10_000L

        private const val HIGH_MEMORY_THRESHOLD_MB = 4096
        private const val MID_MEMORY_THRESHOLD_MB = 2048
        private const val LOW_MEMORY_THRESHOLD_MB = 1024
    }

    private val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private val memoryClass = am.memoryClass
    private val largeMemoryClass = am.largeMemoryClass

    private val scope = CoroutineScope(
        Dispatchers.Default + SupervisorJob() +
            CoroutineName("AdaptiveCacheSizer"),
    )

    /** Calculate optimal cache sizes for this device. */
    fun calculateOptimalSizes(): CacheSizeConfig {
        val deviceRamMb = getDeviceRamMb()

        val config = when {
            deviceRamMb >= HIGH_MEMORY_THRESHOLD_MB -> CacheSizeConfig(
                l1RamCacheBytes = 50 * 1024 * 1024L,
                l2CompressedBytes = 30 * 1024 * 1024L,
                l3SqliteBytes = 200 * 1024 * 1024L,
                l4DiskBytes = 1024 * 1024 * 1024L,
                thumbnailRamBytes = 50 * 1024 * 1024,
                maxL1Entries = 1000,
                hotDirCount = 20,
            )
            deviceRamMb >= MID_MEMORY_THRESHOLD_MB -> CacheSizeConfig(
                l1RamCacheBytes = 25 * 1024 * 1024L,
                l2CompressedBytes = 15 * 1024 * 1024L,
                l3SqliteBytes = 100 * 1024 * 1024L,
                l4DiskBytes = 512 * 1024 * 1024L,
                thumbnailRamBytes = 30 * 1024 * 1024,
                maxL1Entries = 500,
                hotDirCount = 10,
            )
            deviceRamMb >= LOW_MEMORY_THRESHOLD_MB -> CacheSizeConfig(
                l1RamCacheBytes = 10 * 1024 * 1024L,
                l2CompressedBytes = 8 * 1024 * 1024L,
                l3SqliteBytes = 50 * 1024 * 1024L,
                l4DiskBytes = 256 * 1024 * 1024L,
                thumbnailRamBytes = 15 * 1024 * 1024,
                maxL1Entries = 200,
                hotDirCount = 5,
            )
            else -> CacheSizeConfig(
                l1RamCacheBytes = 5 * 1024 * 1024L,
                l2CompressedBytes = 3 * 1024 * 1024L,
                l3SqliteBytes = 20 * 1024 * 1024L,
                l4DiskBytes = 100 * 1024 * 1024L,
                thumbnailRamBytes = 8 * 1024 * 1024,
                maxL1Entries = 100,
                hotDirCount = 3,
            )
        }

        Log.d(TAG, "Cache sizes for ${deviceRamMb}MB RAM: L1=${config.l1RamCacheBytes / 1024 / 1024}MB")
        return config
    }

    /** Monitor memory and trigger cache reduction when memory is low. */
    fun startMonitoring(
        onLowMemory: () -> Unit,
        onMemoryRecovered: () -> Unit,
    ): Job {
        return scope.launch {
            var wasLowMemory = false
            while (isActive) {
                val isLow = isLowMemory()
                when {
                    isLow && !wasLowMemory -> {
                        wasLowMemory = true
                        onLowMemory()
                    }
                    !isLow && wasLowMemory -> {
                        wasLowMemory = false
                        onMemoryRecovered()
                    }
                }
                delay(CHECK_INTERVAL_MS)
            }
        }
    }

    private fun getDeviceRamMb(): Long {
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        return info.totalMem / (1024 * 1024)
    }

    private fun getAvailableRamMb(): Long {
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        return info.availMem / (1024 * 1024)
    }

    private fun isLowMemory(): Boolean {
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        return info.lowMemory
    }

    fun stop() {
        scope.cancel()
    }

    data class CacheSizeConfig(
        val l1RamCacheBytes: Long,
        val l2CompressedBytes: Long,
        val l3SqliteBytes: Long,
        val l4DiskBytes: Long,
        val thumbnailRamBytes: Int,
        val maxL1Entries: Int,
        val hotDirCount: Int,
    )
}

package com.titan.filemanager.data.cache.advanced.model

import com.titan.filemanager.core.model.file.FileItem
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * Universal cache entry — works for every cache level.
 *
 * Ported from Phase D.
 */
data class CacheEntry<T>(
    val key: String,
    val value: T,
    val sizeBytes: Long,
    val createdAt: Long = System.currentTimeMillis(),
    val expiresAt: Long = Long.MAX_VALUE,
    val accessCount: AtomicInteger = AtomicInteger(0),
    val lastAccessTime: AtomicLong = AtomicLong(System.currentTimeMillis()),
    val version: Long = 0L,
    val priority: CacheEntryPriority = CacheEntryPriority.NORMAL,
) {
    fun isExpired(): Boolean = System.currentTimeMillis() > expiresAt

    fun touch() {
        accessCount.incrementAndGet()
        lastAccessTime.set(System.currentTimeMillis())
    }

    /** LFU score: frequency / recency. */
    fun getLfuScore(): Double {
        val age = (System.currentTimeMillis() - createdAt).coerceAtLeast(1L)
        val recency = (System.currentTimeMillis() - lastAccessTime.get()).coerceAtLeast(1L)
        return accessCount.get().toDouble() / (age.toDouble() / 1000.0) *
            (1.0 / recency.toDouble())
    }

    /** LRU score: just last access time. */
    fun getLruScore(): Long = lastAccessTime.get()
}

/**
 * Cache entry priority — never-evict hints.
 *
 * CRITICAL entries survive eviction sweeps (used for system / hot dirs).
 */
enum class CacheEntryPriority(val weight: Float) {
    CRITICAL(4.0f),   // Never evict (system dirs, recent dirs)
    HIGH(3.0f),       // Evict last
    NORMAL(2.0f),     // Normal eviction
    LOW(1.0f),        // Evict first
    DISPOSABLE(0.5f), // Evict immediately on pressure
}

/**
 * Cache statistics for a single tier.
 */
data class CacheStats(
    val levelName: String,
    val itemCount: Int,
    val sizeBytes: Long,
    val maxSizeBytes: Long,
    val hitCount: Long,
    val missCount: Long,
    val evictionCount: Long,
    val hitRate: Float,
    val utilizationPercent: Float,
) {
    companion object {
        fun empty(levelName: String) = CacheStats(
            levelName = levelName,
            itemCount = 0,
            sizeBytes = 0L,
            maxSizeBytes = 0L,
            hitCount = 0L,
            missCount = 0L,
            evictionCount = 0L,
            hitRate = 0f,
            utilizationPercent = 0f,
        )
    }
}

/**
 * In-memory representation of a directory snapshot used for incremental diff.
 */
data class DirectorySnapshot(
    val path: String,
    val items: List<FileItem>,
    val timestamp: Long,
    val checksum: Long,
)

package com.titan.filemanager.data.cache.advanced.policy

import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * LRU / LFU Cache Policy Manager.
 *
 * Ported technique: #53 LRU/LFU cache policies
 *
 * Implements both policies with adaptive selection based on access patterns.
 *  - LRU — best for temporal locality (recently used = likely used again)
 *  - LFU — best for frequency patterns (frequently used = likely used again)
 *  - ADAPTIVE — monitors hit rates and switches between LRU and LFU
 */
class CachePolicyManager(
    private val maxEntries: Int,
    private val initialPolicy: Policy = Policy.ADAPTIVE,
) {

    enum class Policy { LRU, LFU, ADAPTIVE }

    @Volatile
    private var currentPolicy = initialPolicy

    private val lruMap = object : LinkedHashMap<String, Long>(
        maxEntries, 0.75f, true,
    ) {
        override fun removeEldestEntry(eldest: Map.Entry<String, Long>): Boolean {
            return size > maxEntries
        }
    }

    private val frequencyMap = ConcurrentHashMap<String, Int>(maxEntries)
    private val freqBuckets = ConcurrentHashMap<Int, MutableSet<String>>(100)
    private var minFrequency = 1

    private val lruHits = AtomicLong(0L)
    private val lfuHits = AtomicLong(0L)
    private val totalRequests = AtomicLong(0L)
    private var lastPolicyCheck = System.currentTimeMillis()

    /** Record access — updates both LRU and LFU structures. */
    fun recordAccess(key: String) {
        totalRequests.incrementAndGet()

        synchronized(lruMap) { lruMap[key] = System.currentTimeMillis() }

        val newFreq = (frequencyMap[key] ?: 0) + 1
        val oldFreq = frequencyMap.put(key, newFreq) ?: 0

        if (oldFreq > 0) {
            freqBuckets[oldFreq]?.remove(key)
            if (freqBuckets[oldFreq]?.isEmpty() == true) {
                freqBuckets.remove(oldFreq)
                if (minFrequency == oldFreq) minFrequency = newFreq
            }
        }

        freqBuckets.getOrPut(newFreq) { ConcurrentHashMap.newKeySet() }.add(key)

        if (oldFreq == 0) minFrequency = 1

        checkPolicyAdaptation()
    }

    /** Get eviction candidate based on current policy. */
    fun getEvictionCandidate(): String? = when (currentPolicy) {
        Policy.LRU -> getLruCandidate()
        Policy.LFU -> getLfuCandidate()
        Policy.ADAPTIVE -> getAdaptiveCandidate()
    }

    private fun getLruCandidate(): String? = synchronized(lruMap) {
        lruMap.entries.firstOrNull()?.key
    }

    private fun getLfuCandidate(): String? =
        freqBuckets[minFrequency]?.firstOrNull()

    private fun getAdaptiveCandidate(): String? {
        val lruRate = lruHits.get().toFloat() / (totalRequests.get() + 1)
        val lfuRate = lfuHits.get().toFloat() / (totalRequests.get() + 1)
        return if (lruRate >= lfuRate) getLruCandidate() else getLfuCandidate()
    }

    fun onRemove(key: String) {
        synchronized(lruMap) { lruMap.remove(key) }
        val freq = frequencyMap.remove(key) ?: return
        freqBuckets[freq]?.remove(key)
    }

    private fun checkPolicyAdaptation() {
        if (currentPolicy != Policy.ADAPTIVE) return
        if (System.currentTimeMillis() - lastPolicyCheck < 30_000L) return

        lastPolicyCheck = System.currentTimeMillis()
        lruHits.set(0L)
        lfuHits.set(0L)
    }

    fun getScore(key: String): Double = when (currentPolicy) {
        Policy.LRU -> synchronized(lruMap) { lruMap[key]?.toDouble() ?: 0.0 }
        Policy.LFU -> (frequencyMap[key] ?: 0).toDouble()
        Policy.ADAPTIVE -> {
            val freq = (frequencyMap[key] ?: 0).toDouble()
            val lru = synchronized(lruMap) { lruMap[key]?.toDouble() ?: 0.0 }
            freq * 0.6 + (lru / System.currentTimeMillis()) * 0.4
        }
    }

    fun getCurrentPolicy(): Policy = currentPolicy

    fun getStats(): PolicyStats = PolicyStats(
        currentPolicy = currentPolicy,
        trackedEntries = frequencyMap.size,
        minFrequency = minFrequency,
        totalRequests = totalRequests.get(),
    )

    data class PolicyStats(
        val currentPolicy: Policy,
        val trackedEntries: Int,
        val minFrequency: Int,
        val totalRequests: Long,
    )
}

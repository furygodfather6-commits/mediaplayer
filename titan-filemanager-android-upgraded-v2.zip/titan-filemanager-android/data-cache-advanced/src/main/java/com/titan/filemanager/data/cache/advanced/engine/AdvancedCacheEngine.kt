package com.titan.filemanager.data.cache.advanced.engine

import android.content.Context
import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.data.cache.advanced.invalidation.CacheInvalidationManager
import com.titan.filemanager.data.cache.advanced.model.CacheStats
import com.titan.filemanager.data.cache.advanced.policy.CachePolicyManager
import com.titan.filemanager.data.cache.advanced.predictive.PredictiveCacheEngine
import com.titan.filemanager.data.cache.advanced.sizer.AdaptiveCacheSizer
import com.titan.filemanager.data.cache.advanced.warming.CacheWarmingEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Master Cache Engine — single entry point for all cache operations.
 *
 * Ported techniques #40-#53 (all caching techniques).
 *
 * Manages all cache levels transparently:
 *   L1 RAM  → L2 Compressed RAM  → L3 SQLite  → L4 Disk
 * With HotDirectoryCache + ThumbnailCache + PredictiveCacheEngine +
 * CacheWarmingEngine + CacheInvalidationManager + CachePolicyManager.
 */
@Singleton
class AdvancedCacheEngine @Inject constructor(@dagger.hilt.android.qualifiers.ApplicationContext context: Context) {

    private val cacheSizer = AdaptiveCacheSizer(context)
    private val config = cacheSizer.calculateOptimalSizes()

    val l1Cache = L1RamCache<List<FileItem>>(
        name = "DirectoryListing",
        maxSizeBytes = config.l1RamCacheBytes,
        maxEntries = config.maxL1Entries,
    )

    val l2Cache = L2CompressedRamCache<List<FileItem>>(
        name = "CompressedListing",
        maxSizeBytes = config.l2CompressedBytes,
        serializer = FileItemSerializer(),
    )

    val l3Cache = L3SqliteCache(
        context = context,
        maxSizeBytes = config.l3SqliteBytes,
    )

    val l4Cache = L4DiskCache(
        cacheDir = File(context.cacheDir, "l4_cache"),
        maxSizeBytes = config.l4DiskBytes,
    )

    val thumbnailCache = ThumbnailCache(
        diskCacheDir = File(context.cacheDir, "thumbnails"),
        ramCacheSizeBytes = config.thumbnailRamBytes,
    )

    val hotDirCache = HotDirectoryCache(
        l1Cache = l1Cache,
        maxHotDirs = config.hotDirCount,
    )

    val policyManager = CachePolicyManager(maxEntries = config.maxL1Entries)

    val predictiveCache = PredictiveCacheEngine(
        l1Cache = l1Cache,
        hotDirCache = hotDirCache,
    )

    val warmingEngine = CacheWarmingEngine(
        l1Cache = l1Cache,
        hotDirCache = hotDirCache,
        predictiveCache = predictiveCache,
    )

    val invalidationManager = CacheInvalidationManager(
        l1Cache = l1Cache,
        l3Cache = l3Cache,
        thumbnailCache = thumbnailCache,
        hotDirCache = hotDirCache,
    )

    /** GET directory listing — checks all levels in order. */
    suspend fun getDirectoryListing(path: String): List<FileItem>? {
        // Hot cache check
        hotDirCache.getHot(path)?.let { return it }

        // L1 check
        l1Cache.get(path)?.let { return it }

        // L2 compressed check
        l2Cache.get(path)?.let { items ->
            l1Cache.put(path, items, items.size * 200L)
            return items
        }

        // L3 SQLite check
        val l3Data = l3Cache.get(path)
        if (l3Data != null) {
            val items = FileItemSerializer().deserialize(l3Data)
            l1Cache.put(path, items, items.size * 200L)
            l2Cache.put(path, items)
            return items
        }

        return null  // Cache miss — needs scan
    }

    /** PUT directory listing — stores in appropriate levels. */
    suspend fun putDirectoryListing(path: String, items: List<FileItem>) =
        withContext(Dispatchers.IO) {
            val sizeBytes = items.size * 200L

            l1Cache.put(path, items, sizeBytes)
            policyManager.recordAccess(path)

            // L2 for larger directories
            if (items.size > 50) {
                l2Cache.put(path, items)
            }

            // L3 for persistence
            val serialized = FileItemSerializer().serialize(items)
            l3Cache.put(path, serialized, "directory_scan")

            // Track hot directories
            hotDirCache.recordAccess(path, items)

            // Update predictive cache
            predictiveCache.onNavigation(path, items)
        }

    suspend fun invalidate(path: String) {
        invalidationManager.invalidateDirectory(path)
    }

    fun watchPath(path: String) {
        invalidationManager.watchDirectory(path)
    }

    fun getAllStats(): Map<String, CacheStats> = mapOf(
        "l1" to l1Cache.getStats(),
        "l2" to l2Cache.getStats(),
        "l3" to l3Cache.getStats(),
        "l4" to l4Cache.getStats(),
        "thumbnail" to thumbnailCache.getStats(),
    )

    fun onLowMemory() {
        l1Cache.purgeExpired()
        l2Cache.clear()
    }

    fun shutdown() {
        invalidationManager.shutdown()
        predictiveCache.cleanup()
        warmingEngine.stop()
        cacheSizer.stop()
    }

    /** Simple serializer for FileItem lists (uses project's FileItem). */
    inner class FileItemSerializer : L2CompressedRamCache.CacheSerializer<List<FileItem>> {
        override fun serialize(value: List<FileItem>): ByteArray {
            return value.joinToString("\n") { item ->
                "${item.stableId}|${item.name}|${item.path}|${item.size}|" +
                    "${item.modifiedAt}|${item.isDirectory}|${item.isHidden}"
            }.toByteArray(Charsets.UTF_8)
        }

        override fun deserialize(data: ByteArray): List<FileItem> {
            return data.toString(Charsets.UTF_8)
                .split("\n")
                .filter { it.isNotEmpty() }
                .mapNotNull { line ->
                    val parts = line.split("|")
                    if (parts.size < 7) return@mapNotNull null
                    try {
                        FileItem(
                            stableId = parts[0].toLong(),
                            name = parts[1],
                            path = parts[2],
                            size = parts[3].toLong(),
                            modifiedAt = parts[4].toLong(),
                            isDirectory = parts[5].toBoolean(),
                            isHidden = parts[6].toBoolean(),
                        )
                    } catch (_: Exception) {
                        null
                    }
                }
        }
    }
}

package com.titan.filemanager.data.cache.advanced.engine

import com.titan.filemanager.data.cache.advanced.model.CacheEntry
import com.titan.filemanager.data.cache.advanced.model.CacheEntryPriority
import com.titan.filemanager.data.cache.advanced.model.CacheStats
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * L1 RAM Cache — Ultra Fast.
 *
 * Ported technique: #40 L1 RAM cache
 *
 * Properties:
 *  - Pure in-memory storage backed by [ConcurrentHashMap] for O(1) thread-safe ops
 *  - LRU eviction policy
 *  - Configurable max size + entry count
 *  - Zero serialization overhead
 *
 * Target: <1ms access time. Capacity: 10-50MB depending on device RAM.
 */
class L1RamCache<T>(
    private val name: String,
    private val maxSizeBytes: Long,
    private val maxEntries: Int = 500,
    private val defaultTtlMs: Long = 60_000L,  // 1 minute
) {

    // Primary storage: O(1) get/put
    private val storage = ConcurrentHashMap<String, CacheEntry<T>>(
        maxEntries, 0.75f, 4,
    )

    // LRU tracking (access-ordered)
    @Volatile
    private var lruOrder = LinkedHashMap<String, Long>(
        maxEntries, 0.75f, true,  // accessOrder = true
    )
    private val lruLock = Any()

    private val currentSizeBytes = AtomicLong(0L)
    private val hitCount = AtomicLong(0L)
    private val missCount = AtomicLong(0L)
    private val evictionCount = AtomicLong(0L)

    /** GET — O(1) operation. Ultra fast, no I/O, no parsing. */
    fun get(key: String): T? {
        val entry = storage[key]

        if (entry == null) {
            missCount.incrementAndGet()
            return null
        }

        if (entry.isExpired()) {
            remove(key)
            missCount.incrementAndGet()
            return null
        }

        entry.touch()
        updateLruOrder(key)
        hitCount.incrementAndGet()
        return entry.value
    }

    /** PUT — O(1) amortized. May trigger eviction. */
    fun put(
        key: String,
        value: T,
        sizeBytes: Long,
        ttlMs: Long = defaultTtlMs,
        priority: CacheEntryPriority = CacheEntryPriority.NORMAL,
    ): Boolean {
        val entry = CacheEntry(
            key = key,
            value = value,
            sizeBytes = sizeBytes,
            expiresAt = System.currentTimeMillis() + ttlMs,
            priority = priority,
        )

        val projectedSize = currentSizeBytes.get() + sizeBytes
        if (projectedSize > maxSizeBytes || storage.size >= maxEntries) {
            val freed = evict(sizeBytes)
            if (freed < sizeBytes && storage.size >= maxEntries) {
                return false  // Cannot make space
            }
        }

        val old = storage.put(key, entry)
        if (old != null) {
            currentSizeBytes.addAndGet(-old.sizeBytes)
        }
        currentSizeBytes.addAndGet(sizeBytes)
        updateLruOrder(key)
        return true
    }

    /** REMOVE — O(1). */
    fun remove(key: String): Boolean {
        val entry = storage.remove(key) ?: return false
        currentSizeBytes.addAndGet(-entry.sizeBytes)
        synchronized(lruLock) { lruOrder.remove(key) }
        return true
    }

    /** CHECK contains — O(1) without affecting LRU. */
    fun containsKey(key: String): Boolean {
        val entry = storage[key] ?: return false
        return !entry.isExpired()
    }

    /**
     * LRU Eviction — removes oldest-accessed entries until space freed.
     * CRITICAL-priority entries are never evicted.
     */
    private fun evict(requiredBytes: Long): Long {
        var freed = 0L
        val toEvict = mutableListOf<String>()

        synchronized(lruLock) {
            val iter = lruOrder.entries.iterator()
            while (iter.hasNext() && freed < requiredBytes) {
                val entry = iter.next()
                val cacheEntry = storage[entry.key]

                if (cacheEntry?.priority == CacheEntryPriority.CRITICAL) continue

                toEvict.add(entry.key)
                freed += cacheEntry?.sizeBytes ?: 0L
                iter.remove()
            }
        }

        toEvict.forEach { key ->
            storage.remove(key)?.let { entry ->
                currentSizeBytes.addAndGet(-entry.sizeBytes)
                evictionCount.incrementAndGet()
            }
        }
        return freed
    }

    /** Purge expired entries — call periodically for memory cleanup. */
    fun purgeExpired(): Int {
        val now = System.currentTimeMillis()
        val expired = storage.entries
            .filter { it.value.expiresAt < now }
            .map { it.key }
        expired.forEach { remove(it) }
        return expired.size
    }

    /** Bulk get for batch operations. */
    fun getMultiple(keys: List<String>): Map<String, T> {
        val result = HashMap<String, T>(keys.size)
        keys.forEach { key -> get(key)?.let { result[key] = it } }
        return result
    }

    /**
     * Invalidate all entries with prefix.
     * E.g. invalidate("/sdcard/DCIM/") removes all DCIM entries.
     */
    fun invalidateByPrefix(prefix: String): Int {
        val toRemove = storage.keys.filter { it.startsWith(prefix) }
        toRemove.forEach { remove(it) }
        return toRemove.size
    }

    fun clear() {
        storage.clear()
        synchronized(lruLock) { lruOrder.clear() }
        currentSizeBytes.set(0L)
    }

    fun size(): Int = storage.size

    fun getSizeBytes(): Long = currentSizeBytes.get()

    private fun updateLruOrder(key: String) {
        synchronized(lruLock) {
            lruOrder[key] = System.currentTimeMillis()
        }
    }

    fun getStats(): CacheStats {
        val hits = hitCount.get()
        val misses = missCount.get()
        val total = hits + misses
        return CacheStats(
            levelName = "L1-$name",
            itemCount = storage.size,
            sizeBytes = currentSizeBytes.get(),
            maxSizeBytes = maxSizeBytes,
            hitCount = hits,
            missCount = misses,
            evictionCount = evictionCount.get(),
            hitRate = if (total > 0) hits.toFloat() / total else 0f,
            utilizationPercent = currentSizeBytes.get().toFloat() / maxSizeBytes * 100f,
        )
    }
}

// :core:datastore — typed preferences backed by DataStore<Preferences>
plugins {
    id("titan.android.library")
    id("titan.android.hilt")
}

android {
    namespace = "com.titan.filemanager.core.datastore"
}

dependencies {
    api(project(":core:model"))

    implementation("androidx.datastore:datastore-preferences:1.1.1")
    implementation(libs.kotlinx.coroutines.core)
    implementation(libs.timber)

    testImplementation(libs.junit5)
    testImplementation(libs.truth)
    testImplementation(libs.kotlinx.coroutines.test)
}

package com.titan.filemanager.core.datastore.backup

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.backupDataStore: DataStore<Preferences> by preferencesDataStore("backup_settings")

@Singleton
class BackupSettingsRepository @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private val ds = context.backupDataStore

    val settings: Flow<BackupSettings> = ds.data.map { p ->
        BackupSettings(
            backup = BackupConfigSettings(
                autoBackup = p[K_AUTO_BACKUP] ?: false,
                backupInterval = p[K_BACKUP_INTERVAL]?.let { BackupInterval.valueOf(it) } ?: BackupInterval.WEEKLY,
                backupDestination = p[K_BACKUP_DEST]?.let { BackupDestination.valueOf(it) } ?: BackupDestination.LOCAL,
                backupEncryption = p[K_BACKUP_ENC] ?: false,
                maxBackupCount = p[K_MAX_BACKUPS] ?: 5,
                includeDatabases = p[K_INCLUDE_DB] ?: true,
                includePreferences = p[K_INCLUDE_PREFS] ?: true,
                backupNowAction = false,
            ),
            archive = ArchiveConfigSettings(
                defaultArchiveFormat = p[K_ARCHIVE_FMT]?.let { ArchiveFormatPref.valueOf(it) } ?: ArchiveFormatPref.ZIP,
                defaultCompressionLevel = p[K_COMPRESS_LEVEL]?.let { CompressionLevelPref.valueOf(it) } ?: CompressionLevelPref.NORMAL,
                defaultPasswordProtection = p[K_ARCHIVE_PASSWORD] ?: false,
                encryptFilenames = p[K_ENCRYPT_NAMES] ?: false,
                splitArchivesEnabled = p[K_SPLIT_ENABLED] ?: false,
                defaultSplitVolumeMb = p[K_SPLIT_VOL_MB] ?: 100,
            ),
        )
    }

    suspend fun updateBackup(block: (BackupConfigSettings) -> BackupConfigSettings) {
        ds.edit { p ->
            val u = block(BackupConfigSettings())
            p[K_AUTO_BACKUP] = u.autoBackup
            p[K_BACKUP_INTERVAL] = u.backupInterval.name
            p[K_BACKUP_DEST] = u.backupDestination.name
            p[K_BACKUP_ENC] = u.backupEncryption
            p[K_MAX_BACKUPS] = u.maxBackupCount
            p[K_INCLUDE_DB] = u.includeDatabases
            p[K_INCLUDE_PREFS] = u.includePreferences
        }
    }

    suspend fun updateArchive(block: (ArchiveConfigSettings) -> ArchiveConfigSettings) {
        ds.edit { p ->
            val u = block(ArchiveConfigSettings())
            p[K_ARCHIVE_FMT] = u.defaultArchiveFormat.name
            p[K_COMPRESS_LEVEL] = u.defaultCompressionLevel.name
            p[K_ARCHIVE_PASSWORD] = u.defaultPasswordProtection
            p[K_ENCRYPT_NAMES] = u.encryptFilenames
            p[K_SPLIT_ENABLED] = u.splitArchivesEnabled
            p[K_SPLIT_VOL_MB] = u.defaultSplitVolumeMb
        }
    }

    suspend fun resetAll() { ds.edit { it.clear() } }

    companion object {
        val K_AUTO_BACKUP = booleanPreferencesKey("auto_backup")
        val K_BACKUP_INTERVAL = stringPreferencesKey("backup_interval")
        val K_BACKUP_DEST = stringPreferencesKey("backup_dest")
        val K_BACKUP_ENC = booleanPreferencesKey("backup_enc")
        val K_MAX_BACKUPS = intPreferencesKey("max_backups")
        val K_INCLUDE_DB = booleanPreferencesKey("include_db")
        val K_INCLUDE_PREFS = booleanPreferencesKey("include_prefs")
        val K_ARCHIVE_FMT = stringPreferencesKey("archive_fmt")
        val K_COMPRESS_LEVEL = stringPreferencesKey("compress_level")
        val K_ARCHIVE_PASSWORD = booleanPreferencesKey("archive_password")
        val K_ENCRYPT_NAMES = booleanPreferencesKey("encrypt_names")
        val K_SPLIT_ENABLED = booleanPreferencesKey("split_enabled")
        val K_SPLIT_VOL_MB = intPreferencesKey("split_vol_mb")
    }
}

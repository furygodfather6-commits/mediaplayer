package com.titan.filemanager.core.datastore.system

/**
 * ## SystemSettings
 *
 * Root data class for 42 system + behavior settings across 5 categories:
 * File Browser, Accessibility, Performance, Storage, Behavior, Advanced.
 */
data class SystemSettings(
    val fileBrowser: FileBrowserSettings = FileBrowserSettings(),
    val accessibility: AccessibilitySettings = AccessibilitySettings(),
    val performance: PerformanceSettings = PerformanceSettings(),
    val storage: StorageSettings = StorageSettings(),
    val behavior: BehaviorSettings = BehaviorSettings(),
    val advanced: AdvancedSettings = AdvancedSettings(),
)

// ═══ CATEGORY 8: FILE BROWSER & DISPLAY (14 settings) ═══

data class FileBrowserSettings(
    val defaultViewMode: ViewModePref = ViewModePref.LIST,
    val defaultSortField: SortFieldPref = SortFieldPref.NAME,
    val defaultSortOrder: SortOrderPref = SortOrderPref.ASCENDING,
    val directoriesFirst: Boolean = true,
    val showHiddenFiles: Boolean = false,
    val showFileExtensions: Boolean = true,
    val showFileSizes: Boolean = true,
    val showModificationDates: Boolean = true,
    val showFileThumbnails: Boolean = true,
    val thumbnailSize: ThumbnailSizePref = ThumbnailSizePref.SMALL,
    val showBreadcrumbBar: Boolean = true,
    val showStorageBarInBrowser: Boolean = false,
    val rememberLastFolder: Boolean = true,
    val showBookmarkIndicators: Boolean = true,
)

enum class ViewModePref(val label: String) { LIST("List"), GRID("Grid"), COMPACT("Compact") }
enum class SortFieldPref(val label: String) {
    NAME("Name"), SIZE("Size"), MODIFIED("Last modified"), TYPE("Type"), EXTENSION("Extension")
}
enum class SortOrderPref(val label: String) { ASCENDING("Ascending"), DESCENDING("Descending") }
enum class ThumbnailSizePref(val label: String, val dp: Int) {
    MICRO("Micro (48dp)", 48), SMALL("Small (96dp)", 96), MEDIUM("Medium (160dp)", 160), LARGE("Large (256dp)", 256)
}

// ═══ CATEGORY 21: ACCESSIBILITY (10 settings) ═══

data class AccessibilitySettings(
    val highContrast: Boolean = false,
    val fontScale: Float = 1.0f,
    val minTouchTargetDp: Int = 48,
    val reducedMotion: Boolean = false,
    val vestibularSafe: Boolean = false,
    val focusRingThicknessDp: Int = 2,
    val focusRingColorAuto: Boolean = true,
    val screenReaderAnnouncements: Boolean = true,
    val contentDescriptionLevel: ContentDescriptionLevel = ContentDescriptionLevel.DETAILED,
    val colorBlindMode: ColorBlindMode = ColorBlindMode.NONE,
)

enum class ContentDescriptionLevel(val label: String) { MINIMAL("Minimal"), DETAILED("Detailed") }
enum class ColorBlindMode(val label: String) {
    NONE("None"), PROTANOPIA("Protanopia (red-blind)"),
    DEUTERANOPIA("Deuteranopia (green-blind)"), TRITANOPIA("Tritanopia (blue-blind)")
}

// ═══ CATEGORY 22: PERFORMANCE (8 settings) ═══

data class PerformanceSettings(
    val performanceMode: PerformanceMode = PerformanceMode.AUTO,
    val maxBackgroundThreads: Int = 8,
    val batteryAwareScheduling: Boolean = true,
    val thermalThrottling: Boolean = true,
    val lowMemoryMode: Boolean = false,
    val chargingAwareOptimization: Boolean = true,
    val databaseCompactionInterval: CompactionInterval = CompactionInterval.WEEKLY,
    val thumbnailPreGeneration: Boolean = false,
)

enum class PerformanceMode(val label: String) {
    AUTO("Auto"), POWER_SAVE("Power Save"), BALANCED("Balanced"),
    PERFORMANCE("Performance"), MAXIMUM("Maximum")
}
enum class CompactionInterval(val label: String) { DAILY("Daily"), WEEKLY("Weekly"), MONTHLY("Monthly") }

// ═══ CATEGORY 23: STORAGE & DISK (6 settings) ═══

data class StorageSettings(
    val showAvailableStorageOnHome: Boolean = true,
    val lowStorageWarningThreshold: Int = 10, // percent
    val cacheSizeLimitMb: Int = 500,
    val autoClearCacheWhenLow: Boolean = true,
    val storageRefreshInterval: StorageRefreshInterval = StorageRefreshInterval.MIN_30,
    val showStorageInStatusBar: Boolean = false,
)

enum class StorageRefreshInterval(val label: String, val min: Int) {
    REALTIME("Real-time", 0), MIN_5("5 minutes", 5), MIN_30("30 minutes", 30), HOUR_1("1 hour", 60)
}

// ═══ CATEGORY 24: BEHAVIOR & DEFAULTS (8 settings) ═══

data class BehaviorSettings(
    val confirmBeforeDelete: Boolean = true,
    val confirmBeforeOverwrite: Boolean = true,
    val confirmBeforeMove: Boolean = false,
    val defaultOpenWith: DefaultOpenWith = DefaultOpenWith.SYSTEM_DEFAULT,
    val clipboardFormat: ClipboardFormat = ClipboardFormat.FULL_PATH,
    val showFilePropertiesOnLongPress: Boolean = true,
    val hapticFeedback: Boolean = true,
    val keepScreenOnDuringTransfers: Boolean = false,
)

enum class DefaultOpenWith(val label: String) {
    SYSTEM_DEFAULT("System default"), ALWAYS_ASK("Always ask"), INTERNAL_VIEWER("Internal viewer")
}
enum class ClipboardFormat(val label: String) {
    FULL_PATH("Full path"), NAME_ONLY("Name only"), URI("Content URI")
}

// ═══ CATEGORY 25: ADVANCED & DEVELOPER (10 settings) ═══

data class AdvancedSettings(
    val debugLogging: Boolean = false,
    val logLevel: LogLevel = LogLevel.INFO,
    val leakCanary: Boolean = true,
    val chuckerHttpInspector: Boolean = true,
    val showInodeNumbers: Boolean = false,
    val showFilePermissions: Boolean = false,
    val showContentHashes: Boolean = false,
    val exportSettingsAction: Boolean = false,
    val importSettingsAction: Boolean = false,
    val resetAllSettingsAction: Boolean = false,
)

enum class LogLevel(val label: String) {
    VERBOSE("Verbose"), DEBUG("Debug"), INFO("Info"), WARNING("Warning"), ERROR("Error")
}

package com.titan.filemanager.core.datastore.preferences

import com.titan.filemanager.core.model.file.FileSorting
import com.titan.filemanager.core.model.file.SortOrder
import com.titan.filemanager.core.model.file.SortDescriptor

/**
 * Domain representation of all user-facing preferences.
 *
 * Phase 1 — covers scan/sort/display/theme. Phase 2+ will add:
 *   - privacy (analytics opt-in)
 *   - network (sync only on WiFi)
 *   - security (auto-lock timer)
 *   - experimental (feature flags)
 *
 * All values are immutable — mutations go through [UserPreferences.copy]
 * and are persisted by [UserPreferencesDataStore].
 */
data class UserPreferences(
    // ── Display ───────────────────────────────────────────────────
    /** List vs Grid vs Compact. */
    val viewMode: ViewMode = ViewMode.LIST,
    /** True if dotfiles (`.foo`) should be visible. */
    val showHiddenFiles: Boolean = false,
    /** True if "Files" tab should remember its last folder. */
    val rememberLastFolder: Boolean = true,
    /** Last-opened folder path (used when rememberLastFolder = true). */
    val lastOpenedPath: String? = null,

    // ── Sorting ───────────────────────────────────────────────────
    val sortDescriptor: SortDescriptor = SortDescriptor(),

    // ── Theme ─────────────────────────────────────────────────────
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    /** True if Material You dynamic colors are enabled (API 31+). */
    val dynamicColorEnabled: Boolean = true,

    // ── Behavior ──────────────────────────────────────────────────
    /** True if a confirmation dialog should appear before delete. */
    val confirmDelete: Boolean = true,
    /** True if a confirmation dialog should appear before overwrite. */
    val confirmOverwrite: Boolean = true,
    /** True if the FAB should be visible in the browser. */
    val showFab: Boolean = true,
) {
    enum class ViewMode { LIST, GRID, COMPACT }
    enum class ThemeMode { LIGHT, DARK, SYSTEM }
}

/**
 * Type-safe keys for DataStore<Preferences>. Internal — only used by
 * [UserPreferencesDataStore].
 */
internal object PreferenceKeys {
    // Note: actual key definitions live in UserPreferencesDataStore.kt
    // because they need the `booleanPreferencesKey` factory from
    // androidx.datastore.preferences which requires Android import.
}

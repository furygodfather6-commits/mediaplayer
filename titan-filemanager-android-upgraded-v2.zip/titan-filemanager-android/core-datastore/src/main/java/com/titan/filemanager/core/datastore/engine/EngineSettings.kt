package com.titan.filemanager.core.datastore.engine

/**
 * ## EngineSettings
 *
 * Root data class for ALL 64 engine configuration settings across 7 categories.
 * Persisted via DataStore. Controls scan/cache/search/thumbnail/trash/analytics/AI.
 */
data class EngineSettings(
    val scan: ScanEngineSettings = ScanEngineSettings(),
    val cache: CacheEngineSettings = CacheEngineSettings(),
    val search: SearchEngineSettings = SearchEngineSettings(),
    val thumbnail: ThumbnailEngineSettings = ThumbnailEngineSettings(),
    val trash: TrashSettings = TrashSettings(),
    val analytics: AnalyticsSettings = AnalyticsSettings(),
    val ai: AiSettings = AiSettings(),
)

// ═══ CATEGORY 9: SCAN ENGINE (8 settings) ═══

data class ScanEngineSettings(
    val parallelThreads: Int = 8,
    val includeHiddenFiles: Boolean = false,
    val includeSystemFiles: Boolean = false,
    val useNativeEngine: Boolean = true,
    val scanBatchSize: Int = 100,
    val watcherDebounceMs: Int = 500,
    val maxWatchers: Int = 8192,
    val scanProgressNotification: Boolean = true,
)

// ═══ CATEGORY 10: CACHE ENGINE (10 settings) ═══

data class CacheEngineSettings(
    val l0HotDirectoryEntries: Int = 5,
    val l1RamCacheMb: Int = 8,
    val l2CompressedEntries: Int = 200,
    val l3SqliteRetentionDays: Int = 7,
    val autoClearOnLowMemory: Boolean = true,
    val cacheClearThresholdPercent: Int = 20,
    val currentCacheSizeMb: Int = 0, // read-only display
    val clearCacheAction: Boolean = false, // action trigger
    val clearThumbnailsAction: Boolean = false, // action trigger
    val rebuildIndexAction: Boolean = false, // action trigger
)

// ═══ CATEGORY 11: SEARCH ENGINE (12 settings) ═══

data class SearchEngineSettings(
    val searchDebounceMs: Int = 300,
    val maxSearchResults: Int = 10000,
    val searchHistorySize: Int = 50,
    val fuzzySearch: Boolean = false,
    val contentSearch: Boolean = false,
    val regexSearch: Boolean = false,
    val caseSensitive: Boolean = false,
    val indexSizeDisplay: Int = 0, // read-only
    val bloomExpectedItems: Int = 1_000_000,
    val bloomFalsePositiveRate: Float = 0.01f,
    val rankerMatchWeight: Float = 0.4f,
    val rankerRelevanceWeight: Float = 0.25f,
)

// ═══ CATEGORY 12: THUMBNAIL ENGINE (8 settings) ═══

data class ThumbnailEngineSettings(
    val memoryCacheFraction: Int = 8, // 1/8 of heap
    val diskCacheMb: Int = 250,
    val thumbnailFormat: ThumbnailFormat = ThumbnailFormat.WEBP_LOSSLESS,
    val thumbnailQuality: Int = 100,
    val videoFrameTimestampSec: Int = 1,
    val generatePdfThumbnails: Boolean = true,
    val generateApkThumbnails: Boolean = true,
    val generateAudioThumbnails: Boolean = true,
)

enum class ThumbnailFormat(val label: String) {
    WEBP_LOSSLESS("WEBP Lossless"),
    WEBP_LOSSY("WEBP Lossy"),
    JPEG("JPEG"),
    PNG("PNG"),
}

// ═══ CATEGORY 16: TRASH & DELETION (6 settings) ═══

data class TrashSettings(
    val retentionDays: Int = 30,
    val autoEmptyTrash: Boolean = false,
    val autoEmptySchedule: TrashSchedule = TrashSchedule.WEEKLY,
    val confirmBeforeDelete: Boolean = true,
    val confirmBeforePermanentDelete: Boolean = true,
    val secureFileDeletion: Boolean = false,
)

enum class TrashSchedule(val label: String) {
    DAILY("Daily"), WEEKLY("Weekly"), MONTHLY("Monthly"),
}

// ═══ CATEGORY 17: ANALYTICS (6 settings) ═══

data class AnalyticsSettings(
    val enableAnalytics: Boolean = true,
    val topFilesCount: Int = 50,
    val topFoldersCount: Int = 20,
    val duplicateDetectionLevel: DuplicateLevel = DuplicateLevel.STANDARD,
    val partialHashThresholdKb: Int = 12,
    val showAnalyticsOnHome: Boolean = true,
)

enum class DuplicateLevel(val label: String) {
    QUICK("Quick (size only)"),
    STANDARD("Standard (size + partial hash)"),
    DEEP("Deep (full SHA-256)"),
}

// ═══ CATEGORY 18: AI & SMART FEATURES (8 settings) ═══

data class AiSettings(
    val enableAiSuggestions: Boolean = true,
    val smartCategorization: Boolean = true,
    val semanticSearch: Boolean = false,
    val autoTagSuggestions: Boolean = true,
    val largeFileThresholdMb: Int = 100,
    val recentFileThresholdDays: Int = 7,
    val organizationSuggestions: Boolean = true,
    val nextFolderPrediction: Boolean = true,
)

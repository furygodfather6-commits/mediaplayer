package com.titan.filemanager.core.datastore.engine

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.engineDataStore: DataStore<Preferences> by preferencesDataStore("engine_settings")

@Singleton
class EngineSettingsRepository @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private val ds = context.engineDataStore

    val settings: Flow<EngineSettings> = ds.data.map { p ->
        EngineSettings(
            scan = ScanEngineSettings(
                parallelThreads = p[K_SCAN_THREADS] ?: 8,
                includeHiddenFiles = p[K_SCAN_HIDDEN] ?: false,
                includeSystemFiles = p[K_SCAN_SYSTEM] ?: false,
                useNativeEngine = p[K_SCAN_NATIVE] ?: true,
                scanBatchSize = p[K_SCAN_BATCH] ?: 100,
                watcherDebounceMs = p[K_WATCHER_DEBOUNCE] ?: 500,
                maxWatchers = p[K_MAX_WATCHERS] ?: 8192,
                scanProgressNotification = p[K_SCAN_NOTIF] ?: true,
            ),
            cache = CacheEngineSettings(
                l0HotDirectoryEntries = p[K_L0_ENTRIES] ?: 5,
                l1RamCacheMb = p[K_L1_RAM_MB] ?: 8,
                l2CompressedEntries = p[K_L2_ENTRIES] ?: 200,
                l3SqliteRetentionDays = p[K_L3_RETENTION] ?: 7,
                autoClearOnLowMemory = p[K_AUTO_CLEAR_LOW_MEM] ?: true,
                cacheClearThresholdPercent = p[K_CLEAR_THRESHOLD] ?: 20,
                currentCacheSizeMb = 0,
                clearCacheAction = false,
                clearThumbnailsAction = false,
                rebuildIndexAction = false,
            ),
            search = SearchEngineSettings(
                searchDebounceMs = p[K_SEARCH_DEBOUNCE] ?: 300,
                maxSearchResults = p[K_MAX_RESULTS] ?: 10000,
                searchHistorySize = p[K_HISTORY_SIZE] ?: 50,
                fuzzySearch = p[K_FUZZY] ?: false,
                contentSearch = p[K_CONTENT_SEARCH] ?: false,
                regexSearch = p[K_REGEX] ?: false,
                caseSensitive = p[K_CASE_SENSITIVE] ?: false,
                indexSizeDisplay = 0,
                bloomExpectedItems = p[K_BLOOM_ITEMS] ?: 1_000_000,
                bloomFalsePositiveRate = p[K_BLOOM_FP] ?: 0.01f,
                rankerMatchWeight = p[K_RANK_MATCH] ?: 0.4f,
                rankerRelevanceWeight = p[K_RANK_RELEVANCE] ?: 0.25f,
            ),
            thumbnail = ThumbnailEngineSettings(
                memoryCacheFraction = p[K_THUMB_MEM_FRAC] ?: 8,
                diskCacheMb = p[K_THUMB_DISK_MB] ?: 250,
                thumbnailFormat = p[K_THUMB_FORMAT]?.let { ThumbnailFormat.valueOf(it) } ?: ThumbnailFormat.WEBP_LOSSLESS,
                thumbnailQuality = p[K_THUMB_QUALITY] ?: 100,
                videoFrameTimestampSec = p[K_VIDEO_FRAME_SEC] ?: 1,
                generatePdfThumbnails = p[K_PDF_THUMBS] ?: true,
                generateApkThumbnails = p[K_APK_THUMBS] ?: true,
                generateAudioThumbnails = p[K_AUDIO_THUMBS] ?: true,
            ),
            trash = TrashSettings(
                retentionDays = p[K_TRASH_RETENTION] ?: 30,
                autoEmptyTrash = p[K_AUTO_EMPTY_TRASH] ?: false,
                autoEmptySchedule = p[K_TRASH_SCHEDULE]?.let { TrashSchedule.valueOf(it) } ?: TrashSchedule.WEEKLY,
                confirmBeforeDelete = p[K_CONFIRM_DELETE] ?: true,
                confirmBeforePermanentDelete = p[K_CONFIRM_PERM_DELETE] ?: true,
                secureFileDeletion = p[K_SECURE_DELETE] ?: false,
            ),
            analytics = AnalyticsSettings(
                enableAnalytics = p[K_ANALYTICS_ENABLED] ?: true,
                topFilesCount = p[K_TOP_FILES] ?: 50,
                topFoldersCount = p[K_TOP_FOLDERS] ?: 20,
                duplicateDetectionLevel = p[K_DUP_LEVEL]?.let { DuplicateLevel.valueOf(it) } ?: DuplicateLevel.STANDARD,
                partialHashThresholdKb = p[K_HASH_THRESHOLD] ?: 12,
                showAnalyticsOnHome = p[K_ANALYTICS_HOME] ?: true,
            ),
            ai = AiSettings(
                enableAiSuggestions = p[K_AI_ENABLED] ?: true,
                smartCategorization = p[K_SMART_CAT] ?: true,
                semanticSearch = p[K_SEMANTIC_SEARCH] ?: false,
                autoTagSuggestions = p[K_AUTO_TAGS] ?: true,
                largeFileThresholdMb = p[K_LARGE_FILE_MB] ?: 100,
                recentFileThresholdDays = p[K_RECENT_DAYS] ?: 7,
                organizationSuggestions = p[K_ORG_SUGGESTIONS] ?: true,
                nextFolderPrediction = p[K_FOLDER_PREDICTION] ?: true,
            ),
        )
    }

    suspend fun updateScan(block: (ScanEngineSettings) -> ScanEngineSettings) {
        ds.edit { p ->
            val u = block(ScanEngineSettings())
            p[K_SCAN_THREADS] = u.parallelThreads; p[K_SCAN_HIDDEN] = u.includeHiddenFiles
            p[K_SCAN_SYSTEM] = u.includeSystemFiles; p[K_SCAN_NATIVE] = u.useNativeEngine
            p[K_SCAN_BATCH] = u.scanBatchSize; p[K_WATCHER_DEBOUNCE] = u.watcherDebounceMs
            p[K_MAX_WATCHERS] = u.maxWatchers; p[K_SCAN_NOTIF] = u.scanProgressNotification
        }
    }
    suspend fun updateCache(block: (CacheEngineSettings) -> CacheEngineSettings) {
        ds.edit { p ->
            val u = block(CacheEngineSettings())
            p[K_L0_ENTRIES] = u.l0HotDirectoryEntries; p[K_L1_RAM_MB] = u.l1RamCacheMb
            p[K_L2_ENTRIES] = u.l2CompressedEntries; p[K_L3_RETENTION] = u.l3SqliteRetentionDays
            p[K_AUTO_CLEAR_LOW_MEM] = u.autoClearOnLowMemory; p[K_CLEAR_THRESHOLD] = u.cacheClearThresholdPercent
        }
    }
    suspend fun updateSearch(block: (SearchEngineSettings) -> SearchEngineSettings) {
        ds.edit { p ->
            val u = block(SearchEngineSettings())
            p[K_SEARCH_DEBOUNCE] = u.searchDebounceMs; p[K_MAX_RESULTS] = u.maxSearchResults
            p[K_HISTORY_SIZE] = u.searchHistorySize; p[K_FUZZY] = u.fuzzySearch
            p[K_CONTENT_SEARCH] = u.contentSearch; p[K_REGEX] = u.regexSearch
            p[K_CASE_SENSITIVE] = u.caseSensitive; p[K_BLOOM_ITEMS] = u.bloomExpectedItems
            p[K_BLOOM_FP] = u.bloomFalsePositiveRate; p[K_RANK_MATCH] = u.rankerMatchWeight
            p[K_RANK_RELEVANCE] = u.rankerRelevanceWeight
        }
    }
    suspend fun updateThumbnail(block: (ThumbnailEngineSettings) -> ThumbnailEngineSettings) {
        ds.edit { p ->
            val u = block(ThumbnailEngineSettings())
            p[K_THUMB_MEM_FRAC] = u.memoryCacheFraction; p[K_THUMB_DISK_MB] = u.diskCacheMb
            p[K_THUMB_FORMAT] = u.thumbnailFormat.name; p[K_THUMB_QUALITY] = u.thumbnailQuality
            p[K_VIDEO_FRAME_SEC] = u.videoFrameTimestampSec; p[K_PDF_THUMBS] = u.generatePdfThumbnails
            p[K_APK_THUMBS] = u.generateApkThumbnails; p[K_AUDIO_THUMBS] = u.generateAudioThumbnails
        }
    }
    suspend fun updateTrash(block: (TrashSettings) -> TrashSettings) {
        ds.edit { p ->
            val u = block(TrashSettings())
            p[K_TRASH_RETENTION] = u.retentionDays; p[K_AUTO_EMPTY_TRASH] = u.autoEmptyTrash
            p[K_TRASH_SCHEDULE] = u.autoEmptySchedule.name; p[K_CONFIRM_DELETE] = u.confirmBeforeDelete
            p[K_CONFIRM_PERM_DELETE] = u.confirmBeforePermanentDelete; p[K_SECURE_DELETE] = u.secureFileDeletion
        }
    }
    suspend fun updateAnalytics(block: (AnalyticsSettings) -> AnalyticsSettings) {
        ds.edit { p ->
            val u = block(AnalyticsSettings())
            p[K_ANALYTICS_ENABLED] = u.enableAnalytics; p[K_TOP_FILES] = u.topFilesCount
            p[K_TOP_FOLDERS] = u.topFoldersCount; p[K_DUP_LEVEL] = u.duplicateDetectionLevel.name
            p[K_HASH_THRESHOLD] = u.partialHashThresholdKb; p[K_ANALYTICS_HOME] = u.showAnalyticsOnHome
        }
    }
    suspend fun updateAi(block: (AiSettings) -> AiSettings) {
        ds.edit { p ->
            val u = block(AiSettings())
            p[K_AI_ENABLED] = u.enableAiSuggestions; p[K_SMART_CAT] = u.smartCategorization
            p[K_SEMANTIC_SEARCH] = u.semanticSearch; p[K_AUTO_TAGS] = u.autoTagSuggestions
            p[K_LARGE_FILE_MB] = u.largeFileThresholdMb; p[K_RECENT_DAYS] = u.recentFileThresholdDays
            p[K_ORG_SUGGESTIONS] = u.organizationSuggestions; p[K_FOLDER_PREDICTION] = u.nextFolderPrediction
        }
    }
    suspend fun resetAll() { ds.edit { it.clear() } }

    companion object {
        val K_SCAN_THREADS = intPreferencesKey("scan_threads")
        val K_SCAN_HIDDEN = booleanPreferencesKey("scan_hidden")
        val K_SCAN_SYSTEM = booleanPreferencesKey("scan_system")
        val K_SCAN_NATIVE = booleanPreferencesKey("scan_native")
        val K_SCAN_BATCH = intPreferencesKey("scan_batch")
        val K_WATCHER_DEBOUNCE = intPreferencesKey("watcher_debounce")
        val K_MAX_WATCHERS = intPreferencesKey("max_watchers")
        val K_SCAN_NOTIF = booleanPreferencesKey("scan_notif")
        val K_L0_ENTRIES = intPreferencesKey("l0_entries")
        val K_L1_RAM_MB = intPreferencesKey("l1_ram_mb")
        val K_L2_ENTRIES = intPreferencesKey("l2_entries")
        val K_L3_RETENTION = intPreferencesKey("l3_retention")
        val K_AUTO_CLEAR_LOW_MEM = booleanPreferencesKey("auto_clear_low_mem")
        val K_CLEAR_THRESHOLD = intPreferencesKey("clear_threshold")
        val K_SEARCH_DEBOUNCE = intPreferencesKey("search_debounce")
        val K_MAX_RESULTS = intPreferencesKey("max_results")
        val K_HISTORY_SIZE = intPreferencesKey("history_size")
        val K_FUZZY = booleanPreferencesKey("fuzzy")
        val K_CONTENT_SEARCH = booleanPreferencesKey("content_search")
        val K_REGEX = booleanPreferencesKey("regex")
        val K_CASE_SENSITIVE = booleanPreferencesKey("case_sensitive")
        val K_BLOOM_ITEMS = intPreferencesKey("bloom_items")
        val K_BLOOM_FP = floatPreferencesKey("bloom_fp")
        val K_RANK_MATCH = floatPreferencesKey("rank_match")
        val K_RANK_RELEVANCE = floatPreferencesKey("rank_relevance")
        val K_THUMB_MEM_FRAC = intPreferencesKey("thumb_mem_frac")
        val K_THUMB_DISK_MB = intPreferencesKey("thumb_disk_mb")
        val K_THUMB_FORMAT = stringPreferencesKey("thumb_format")
        val K_THUMB_QUALITY = intPreferencesKey("thumb_quality")
        val K_VIDEO_FRAME_SEC = intPreferencesKey("video_frame_sec")
        val K_PDF_THUMBS = booleanPreferencesKey("pdf_thumbs")
        val K_APK_THUMBS = booleanPreferencesKey("apk_thumbs")
        val K_AUDIO_THUMBS = booleanPreferencesKey("audio_thumbs")
        val K_TRASH_RETENTION = intPreferencesKey("trash_retention")
        val K_AUTO_EMPTY_TRASH = booleanPreferencesKey("auto_empty_trash")
        val K_TRASH_SCHEDULE = stringPreferencesKey("trash_schedule")
        val K_CONFIRM_DELETE = booleanPreferencesKey("confirm_delete")
        val K_CONFIRM_PERM_DELETE = booleanPreferencesKey("confirm_perm_delete")
        val K_SECURE_DELETE = booleanPreferencesKey("secure_delete")
        val K_ANALYTICS_ENABLED = booleanPreferencesKey("analytics_enabled")
        val K_TOP_FILES = intPreferencesKey("top_files")
        val K_TOP_FOLDERS = intPreferencesKey("top_folders")
        val K_DUP_LEVEL = stringPreferencesKey("dup_level")
        val K_HASH_THRESHOLD = intPreferencesKey("hash_threshold")
        val K_ANALYTICS_HOME = booleanPreferencesKey("analytics_home")
        val K_AI_ENABLED = booleanPreferencesKey("ai_enabled")
        val K_SMART_CAT = booleanPreferencesKey("smart_cat")
        val K_SEMANTIC_SEARCH = booleanPreferencesKey("semantic_search")
        val K_AUTO_TAGS = booleanPreferencesKey("auto_tags")
        val K_LARGE_FILE_MB = intPreferencesKey("large_file_mb")
        val K_RECENT_DAYS = intPreferencesKey("recent_days")
        val K_ORG_SUGGESTIONS = booleanPreferencesKey("org_suggestions")
        val K_FOLDER_PREDICTION = booleanPreferencesKey("folder_prediction")
    }
}

package com.titan.filemanager.core.datastore.appearance

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

private val Context.appearanceDataStore: DataStore<Preferences> by preferencesDataStore("appearance_settings")

/**
 * ## AppearanceSettingsRepository
 *
 * Persists all 73 appearance settings to DataStore.
 * Each setting is stored as a separate Preferences key for granular updates.
 */
@Singleton
class AppearanceSettingsRepository @Inject constructor(
    @ApplicationContext private val context: Context,
) {

    private val ds = context.appearanceDataStore

    val settings: Flow<AppearanceSettings> = ds.data.map { p ->
        AppearanceSettings(
            theme = ThemeSettings(
                presetName = p[KEY_THEME_PRESET] ?: "Ocean",
                darkMode = p[KEY_DARK_MODE]?.let { DarkModePref.valueOf(it) } ?: DarkModePref.SYSTEM,
                dynamicColor = p[KEY_DYNAMIC_COLOR] ?: true,
                amoledMode = p[KEY_AMOLED] ?: false,
                customPrimaryColor = p[KEY_CUSTOM_PRIMARY],
                customSecondaryColor = p[KEY_CUSTOM_SECONDARY],
                customTertiaryColor = p[KEY_CUSTOM_TERTIARY],
                customErrorColor = p[KEY_CUSTOM_ERROR],
                customFileTintsEnabled = p[KEY_CUSTOM_TINTS] ?: false,
                customFolderTint = p[KEY_CUSTOM_FOLDER_TINT],
                customImageTint = p[KEY_CUSTOM_IMAGE_TINT],
                customVideoTint = p[KEY_CUSTOM_VIDEO_TINT],
                customAudioTint = p[KEY_CUSTOM_AUDIO_TINT],
                chartPalette = p[KEY_CHART_PALETTE]?.let { ChartPalette.valueOf(it) } ?: ChartPalette.DEFAULT,
                gradientStyle = p[KEY_GRADIENT_STYLE]?.let { GradientStyle.valueOf(it) } ?: GradientStyle.LINEAR,
                shimmerMode = p[KEY_SHIMMER_MODE]?.let { ShimmerMode.valueOf(it) } ?: ShimmerMode.AUTO,
                overlayIntensity = p[KEY_OVERLAY_INTENSITY] ?: 0.6f,
                highContrast = p[KEY_HIGH_CONTRAST] ?: false,
            ),
            typography = TypographySettings(
                fontFamily = p[KEY_FONT_FAMILY]?.let { FontFamilyPref.valueOf(it) } ?: FontFamilyPref.SYSTEM,
                fontScale = p[KEY_FONT_SCALE] ?: 1.0f,
                headlineWeight = p[KEY_HEADLINE_WEIGHT]?.let { FontWeightPref.valueOf(it) } ?: FontWeightPref.SEMI_BOLD,
                bodyWeight = p[KEY_BODY_WEIGHT]?.let { FontWeightPref.valueOf(it) } ?: FontWeightPref.NORMAL,
                labelLetterSpacing = p[KEY_LABEL_SPACING] ?: 0.1f,
                monospaceForPaths = p[KEY_MONO_PATHS] ?: true,
                lineHeightMultiplier = p[KEY_LINE_HEIGHT] ?: 1.0f,
                maxLineLength = p[KEY_MAX_LINE_LEN] ?: 75,
                labelTextTransform = p[KEY_TEXT_TRANSFORM]?.let { TextTransform.valueOf(it) } ?: TextTransform.NONE,
                ligatures = p[KEY_LIGATURES] ?: true,
                kerning = p[KEY_KERNING] ?: true,
                displayFontSizeOverride = p[KEY_DISPLAY_FONT_OVERRIDE]?.toFloat(),
            ),
            shape = ShapeSettings(
                globalCornerRadius = p[KEY_GLOBAL_RADIUS],
                shapeStyle = p[KEY_SHAPE_STYLE]?.let { ShapeStyle.valueOf(it) } ?: ShapeStyle.MATERIAL,
                cardCornerRadius = p[KEY_CARD_RADIUS],
                dialogCornerRadius = p[KEY_DIALOG_RADIUS],
                sheetCornerRadius = p[KEY_SHEET_RADIUS],
                buttonShape = p[KEY_BUTTON_SHAPE]?.let { ButtonShape.valueOf(it) } ?: ButtonShape.PILL,
                thumbnailCornerRadius = p[KEY_THUMB_RADIUS] ?: 12,
                asymmetricShapes = p[KEY_ASYMMETRIC] ?: true,
            ),
            density = DensitySettings(
                densityMode = p[KEY_DENSITY_MODE]?.let { DensityMode.valueOf(it) } ?: DensityMode.NORMAL,
                screenHorizontalPadding = p[KEY_SCREEN_PADDING] ?: 16,
                listItemHeight = p[KEY_LIST_HEIGHT]?.let { ListItemHeight.valueOf(it) } ?: ListItemHeight.NORMAL,
                gridColumnCount = p[KEY_GRID_COLUMNS] ?: 0,
                gridTileSize = p[KEY_GRID_TILE] ?: 120,
                sectionSpacing = p[KEY_SECTION_SPACING] ?: 24,
                cardPadding = p[KEY_CARD_PADDING] ?: 16,
                iconSizeScale = p[KEY_ICON_SCALE] ?: 1.0f,
                touchTargetSize = p[KEY_TOUCH_TARGET] ?: 48,
                showFab = p[KEY_SHOW_FAB] ?: true,
            ),
            elevation = ElevationSettings(
                elevationStyle = p[KEY_ELEV_STYLE]?.let { ElevationStyle.valueOf(it) } ?: ElevationStyle.MATERIAL,
                cardElevation = p[KEY_CARD_ELEV] ?: 1,
                dialogElevation = p[KEY_DIALOG_ELEV] ?: 3,
                fabElevation = p[KEY_FAB_ELEV] ?: 3,
                tonalOverlayIntensity = p[KEY_TONAL_OVERLAY] ?: 100,
                coloredShadows = p[KEY_COLORED_SHADOWS] ?: false,
            ),
            motion = MotionSettings(
                animationSpeed = p[KEY_ANIM_SPEED]?.let { AnimationSpeed.valueOf(it) } ?: AnimationSpeed.NORMAL,
                reducedMotion = p[KEY_REDUCED_MOTION] ?: false,
                pageTransition = p[KEY_PAGE_TRANS]?.let { PageTransition.valueOf(it) } ?: PageTransition.SLIDE,
                staggerAnimation = p[KEY_STAGGER] ?: true,
                staggerDelay = p[KEY_STAGGER_DELAY] ?: 50,
                springPhysics = p[KEY_SPRING]?.let { SpringPhysics.valueOf(it) } ?: SpringPhysics.SNAPPY,
                skeletonShimmer = p[KEY_SKELETON_SHIMMER] ?: true,
                pulseAnimations = p[KEY_PULSE] ?: true,
                ambientFloat = p[KEY_AMBIENT_FLOAT] ?: false,
                listEnterAnimation = p[KEY_LIST_ENTER]?.let { ListEnterAnimation.valueOf(it) } ?: ListEnterAnimation.SLIDE,
                vestibularSafe = p[KEY_VESTIBULAR] ?: false,
                marqueeScroll = p[KEY_MARQUEE] ?: false,
            ),
            glassmorphism = GlassmorphismSettings(
                enabled = p[KEY_GLASS_ENABLED] ?: true,
                blurIntensity = p[KEY_BLUR_INTENSITY]?.let { BlurIntensity.valueOf(it) } ?: BlurIntensity.MEDIUM,
                tintOpacity = p[KEY_TINT_OPACITY] ?: 65,
                frostedAppBar = p[KEY_FROSTED_APPBAR] ?: true,
                frostedBottomSheet = p[KEY_FROSTED_SHEET] ?: true,
                frostedDialog = p[KEY_FROSTED_DIALOG] ?: false,
                fallback = p[KEY_GLASS_FALLBACK]?.let { GlassFallback.valueOf(it) } ?: GlassFallback.SOLID_TINT,
            ),
        )
    }

    suspend fun updateTheme(block: (ThemeSettings) -> ThemeSettings) {
        ds.edit { p ->
            val current = settings.let { /* read current from p */ ThemeSettings() }
            val updated = block(current)
            p[KEY_THEME_PRESET] = updated.presetName
            p[KEY_DARK_MODE] = updated.darkMode.name
            p[KEY_DYNAMIC_COLOR] = updated.dynamicColor
            p[KEY_AMOLED] = updated.amoledMode
            p[KEY_CUSTOM_PRIMARY] = updated.customPrimaryColor ?: ""
            p[KEY_CUSTOM_SECONDARY] = updated.customSecondaryColor ?: ""
            p[KEY_CUSTOM_TERTIARY] = updated.customTertiaryColor ?: ""
            p[KEY_CUSTOM_ERROR] = updated.customErrorColor ?: ""
            p[KEY_CUSTOM_TINTS] = updated.customFileTintsEnabled
            p[KEY_CUSTOM_FOLDER_TINT] = updated.customFolderTint ?: ""
            p[KEY_CUSTOM_IMAGE_TINT] = updated.customImageTint ?: ""
            p[KEY_CUSTOM_VIDEO_TINT] = updated.customVideoTint ?: ""
            p[KEY_CUSTOM_AUDIO_TINT] = updated.customAudioTint ?: ""
            p[KEY_CHART_PALETTE] = updated.chartPalette.name
            p[KEY_GRADIENT_STYLE] = updated.gradientStyle.name
            p[KEY_SHIMMER_MODE] = updated.shimmerMode.name
            p[KEY_OVERLAY_INTENSITY] = updated.overlayIntensity
            p[KEY_HIGH_CONTRAST] = updated.highContrast
        }
    }

    suspend fun updateTypography(block: (TypographySettings) -> TypographySettings) {
        ds.edit { p ->
            val current = TypographySettings()
            val updated = block(current)
            p[KEY_FONT_FAMILY] = updated.fontFamily.name
            p[KEY_FONT_SCALE] = updated.fontScale
            p[KEY_HEADLINE_WEIGHT] = updated.headlineWeight.name
            p[KEY_BODY_WEIGHT] = updated.bodyWeight.name
            p[KEY_LABEL_SPACING] = updated.labelLetterSpacing
            p[KEY_MONO_PATHS] = updated.monospaceForPaths
            p[KEY_LINE_HEIGHT] = updated.lineHeightMultiplier
            p[KEY_MAX_LINE_LEN] = updated.maxLineLength
            p[KEY_TEXT_TRANSFORM] = updated.labelTextTransform.name
            p[KEY_LIGATURES] = updated.ligatures
            p[KEY_KERNING] = updated.kerning
            p[KEY_DISPLAY_FONT_OVERRIDE] = (updated.displayFontSizeOverride ?: -1f).toString()
        }
    }

    suspend fun updateShape(block: (ShapeSettings) -> ShapeSettings) {
        ds.edit { p ->
            val updated = block(ShapeSettings())
            p[KEY_GLOBAL_RADIUS] = updated.globalCornerRadius ?: -1
            p[KEY_SHAPE_STYLE] = updated.shapeStyle.name
            p[KEY_CARD_RADIUS] = updated.cardCornerRadius ?: -1
            p[KEY_DIALOG_RADIUS] = updated.dialogCornerRadius ?: -1
            p[KEY_SHEET_RADIUS] = updated.sheetCornerRadius ?: -1
            p[KEY_BUTTON_SHAPE] = updated.buttonShape.name
            p[KEY_THUMB_RADIUS] = updated.thumbnailCornerRadius
            p[KEY_ASYMMETRIC] = updated.asymmetricShapes
        }
    }

    suspend fun updateDensity(block: (DensitySettings) -> DensitySettings) {
        ds.edit { p ->
            val updated = block(DensitySettings())
            p[KEY_DENSITY_MODE] = updated.densityMode.name
            p[KEY_SCREEN_PADDING] = updated.screenHorizontalPadding
            p[KEY_LIST_HEIGHT] = updated.listItemHeight.name
            p[KEY_GRID_COLUMNS] = updated.gridColumnCount
            p[KEY_GRID_TILE] = updated.gridTileSize
            p[KEY_SECTION_SPACING] = updated.sectionSpacing
            p[KEY_CARD_PADDING] = updated.cardPadding
            p[KEY_ICON_SCALE] = updated.iconSizeScale
            p[KEY_TOUCH_TARGET] = updated.touchTargetSize
            p[KEY_SHOW_FAB] = updated.showFab
        }
    }

    suspend fun updateElevation(block: (ElevationSettings) -> ElevationSettings) {
        ds.edit { p ->
            val updated = block(ElevationSettings())
            p[KEY_ELEV_STYLE] = updated.elevationStyle.name
            p[KEY_CARD_ELEV] = updated.cardElevation
            p[KEY_DIALOG_ELEV] = updated.dialogElevation
            p[KEY_FAB_ELEV] = updated.fabElevation
            p[KEY_TONAL_OVERLAY] = updated.tonalOverlayIntensity
            p[KEY_COLORED_SHADOWS] = updated.coloredShadows
        }
    }

    suspend fun updateMotion(block: (MotionSettings) -> MotionSettings) {
        ds.edit { p ->
            val updated = block(MotionSettings())
            p[KEY_ANIM_SPEED] = updated.animationSpeed.name
            p[KEY_REDUCED_MOTION] = updated.reducedMotion
            p[KEY_PAGE_TRANS] = updated.pageTransition.name
            p[KEY_STAGGER] = updated.staggerAnimation
            p[KEY_STAGGER_DELAY] = updated.staggerDelay
            p[KEY_SPRING] = updated.springPhysics.name
            p[KEY_SKELETON_SHIMMER] = updated.skeletonShimmer
            p[KEY_PULSE] = updated.pulseAnimations
            p[KEY_AMBIENT_FLOAT] = updated.ambientFloat
            p[KEY_LIST_ENTER] = updated.listEnterAnimation.name
            p[KEY_VESTIBULAR] = updated.vestibularSafe
            p[KEY_MARQUEE] = updated.marqueeScroll
        }
    }

    suspend fun updateGlassmorphism(block: (GlassmorphismSettings) -> GlassmorphismSettings) {
        ds.edit { p ->
            val updated = block(GlassmorphismSettings())
            p[KEY_GLASS_ENABLED] = updated.enabled
            p[KEY_BLUR_INTENSITY] = updated.blurIntensity.name
            p[KEY_TINT_OPACITY] = updated.tintOpacity
            p[KEY_FROSTED_APPBAR] = updated.frostedAppBar
            p[KEY_FROSTED_SHEET] = updated.frostedBottomSheet
            p[KEY_FROSTED_DIALOG] = updated.frostedDialog
            p[KEY_GLASS_FALLBACK] = updated.fallback.name
        }
    }

    suspend fun resetAll() {
        ds.edit { it.clear() }
    }

    // ── Preference Keys ──
    companion object {
        // Theme
        val KEY_THEME_PRESET = stringPreferencesKey("theme_preset")
        val KEY_DARK_MODE = stringPreferencesKey("dark_mode")
        val KEY_DYNAMIC_COLOR = booleanPreferencesKey("dynamic_color")
        val KEY_AMOLED = booleanPreferencesKey("amoled_mode")
        val KEY_CUSTOM_PRIMARY = stringPreferencesKey("custom_primary")
        val KEY_CUSTOM_SECONDARY = stringPreferencesKey("custom_secondary")
        val KEY_CUSTOM_TERTIARY = stringPreferencesKey("custom_tertiary")
        val KEY_CUSTOM_ERROR = stringPreferencesKey("custom_error")
        val KEY_CUSTOM_TINTS = booleanPreferencesKey("custom_tints_enabled")
        val KEY_CUSTOM_FOLDER_TINT = stringPreferencesKey("custom_folder_tint")
        val KEY_CUSTOM_IMAGE_TINT = stringPreferencesKey("custom_image_tint")
        val KEY_CUSTOM_VIDEO_TINT = stringPreferencesKey("custom_video_tint")
        val KEY_CUSTOM_AUDIO_TINT = stringPreferencesKey("custom_audio_tint")
        val KEY_CHART_PALETTE = stringPreferencesKey("chart_palette")
        val KEY_GRADIENT_STYLE = stringPreferencesKey("gradient_style")
        val KEY_SHIMMER_MODE = stringPreferencesKey("shimmer_mode")
        val KEY_OVERLAY_INTENSITY = floatPreferencesKey("overlay_intensity")
        val KEY_HIGH_CONTRAST = booleanPreferencesKey("high_contrast")

        // Typography
        val KEY_FONT_FAMILY = stringPreferencesKey("font_family")
        val KEY_FONT_SCALE = floatPreferencesKey("font_scale")
        val KEY_HEADLINE_WEIGHT = stringPreferencesKey("headline_weight")
        val KEY_BODY_WEIGHT = stringPreferencesKey("body_weight")
        val KEY_LABEL_SPACING = floatPreferencesKey("label_spacing")
        val KEY_MONO_PATHS = booleanPreferencesKey("mono_paths")
        val KEY_LINE_HEIGHT = floatPreferencesKey("line_height")
        val KEY_MAX_LINE_LEN = intPreferencesKey("max_line_len")
        val KEY_TEXT_TRANSFORM = stringPreferencesKey("text_transform")
        val KEY_LIGATURES = booleanPreferencesKey("ligatures")
        val KEY_KERNING = booleanPreferencesKey("kerning")
        val KEY_DISPLAY_FONT_OVERRIDE = stringPreferencesKey("display_font_override")

        // Shape
        val KEY_GLOBAL_RADIUS = intPreferencesKey("global_radius")
        val KEY_SHAPE_STYLE = stringPreferencesKey("shape_style")
        val KEY_CARD_RADIUS = intPreferencesKey("card_radius")
        val KEY_DIALOG_RADIUS = intPreferencesKey("dialog_radius")
        val KEY_SHEET_RADIUS = intPreferencesKey("sheet_radius")
        val KEY_BUTTON_SHAPE = stringPreferencesKey("button_shape")
        val KEY_THUMB_RADIUS = intPreferencesKey("thumb_radius")
        val KEY_ASYMMETRIC = booleanPreferencesKey("asymmetric_shapes")

        // Density
        val KEY_DENSITY_MODE = stringPreferencesKey("density_mode")
        val KEY_SCREEN_PADDING = intPreferencesKey("screen_padding")
        val KEY_LIST_HEIGHT = stringPreferencesKey("list_height")
        val KEY_GRID_COLUMNS = intPreferencesKey("grid_columns")
        val KEY_GRID_TILE = intPreferencesKey("grid_tile")
        val KEY_SECTION_SPACING = intPreferencesKey("section_spacing")
        val KEY_CARD_PADDING = intPreferencesKey("card_padding")
        val KEY_ICON_SCALE = floatPreferencesKey("icon_scale")
        val KEY_TOUCH_TARGET = intPreferencesKey("touch_target")
        val KEY_SHOW_FAB = booleanPreferencesKey("show_fab")

        // Elevation
        val KEY_ELEV_STYLE = stringPreferencesKey("elev_style")
        val KEY_CARD_ELEV = intPreferencesKey("card_elev")
        val KEY_DIALOG_ELEV = intPreferencesKey("dialog_elev")
        val KEY_FAB_ELEV = intPreferencesKey("fab_elev")
        val KEY_TONAL_OVERLAY = intPreferencesKey("tonal_overlay")
        val KEY_COLORED_SHADOWS = booleanPreferencesKey("colored_shadows")

        // Motion
        val KEY_ANIM_SPEED = stringPreferencesKey("anim_speed")
        val KEY_REDUCED_MOTION = booleanPreferencesKey("reduced_motion")
        val KEY_PAGE_TRANS = stringPreferencesKey("page_transition")
        val KEY_STAGGER = booleanPreferencesKey("stagger")
        val KEY_STAGGER_DELAY = intPreferencesKey("stagger_delay")
        val KEY_SPRING = stringPreferencesKey("spring")
        val KEY_SKELETON_SHIMMER = booleanPreferencesKey("skeleton_shimmer")
        val KEY_PULSE = booleanPreferencesKey("pulse")
        val KEY_AMBIENT_FLOAT = booleanPreferencesKey("ambient_float")
        val KEY_LIST_ENTER = stringPreferencesKey("list_enter")
        val KEY_VESTIBULAR = booleanPreferencesKey("vestibular")
        val KEY_MARQUEE = booleanPreferencesKey("marquee")

        // Glassmorphism
        val KEY_GLASS_ENABLED = booleanPreferencesKey("glass_enabled")
        val KEY_BLUR_INTENSITY = stringPreferencesKey("blur_intensity")
        val KEY_TINT_OPACITY = intPreferencesKey("tint_opacity")
        val KEY_FROSTED_APPBAR = booleanPreferencesKey("frosted_appbar")
        val KEY_FROSTED_SHEET = booleanPreferencesKey("frosted_sheet")
        val KEY_FROSTED_DIALOG = booleanPreferencesKey("frosted_dialog")
        val KEY_GLASS_FALLBACK = stringPreferencesKey("glass_fallback")
    }
}

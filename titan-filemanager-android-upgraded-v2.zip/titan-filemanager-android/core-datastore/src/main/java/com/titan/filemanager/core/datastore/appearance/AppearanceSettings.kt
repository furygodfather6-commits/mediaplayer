package com.titan.filemanager.core.datastore.appearance

import kotlinx.coroutines.flow.Flow

/**
 * ## AppearanceSettings
 *
 * Root data class holding ALL 73 appearance settings across 7 categories.
 * Persisted via DataStore. Observed reactively via Flow.
 */
data class AppearanceSettings(
    val theme: ThemeSettings = ThemeSettings(),
    val typography: TypographySettings = TypographySettings(),
    val shape: ShapeSettings = ShapeSettings(),
    val density: DensitySettings = DensitySettings(),
    val elevation: ElevationSettings = ElevationSettings(),
    val motion: MotionSettings = MotionSettings(),
    val glassmorphism: GlassmorphismSettings = GlassmorphismSettings(),
)

// ═══ CATEGORY 1: THEME & COLOR (18 settings) ═══

data class ThemeSettings(
    val presetName: String = "Ocean",
    val darkMode: DarkModePref = DarkModePref.SYSTEM,
    val dynamicColor: Boolean = true,
    val amoledMode: Boolean = false,
    val customPrimaryColor: String? = null,
    val customSecondaryColor: String? = null,
    val customTertiaryColor: String? = null,
    val customErrorColor: String? = null,
    val customFileTintsEnabled: Boolean = false,
    val customFolderTint: String? = null,
    val customImageTint: String? = null,
    val customVideoTint: String? = null,
    val customAudioTint: String? = null,
    val chartPalette: ChartPalette = ChartPalette.DEFAULT,
    val gradientStyle: GradientStyle = GradientStyle.LINEAR,
    val shimmerMode: ShimmerMode = ShimmerMode.AUTO,
    val overlayIntensity: Float = 0.6f,
    val highContrast: Boolean = false,
)

enum class DarkModePref(val label: String) {
    SYSTEM("System default"), LIGHT("Light"), DARK("Dark"),
}

enum class ChartPalette(val label: String) {
    DEFAULT("Default (12 colors)"), PASTEL("Pastel (9 colors)"),
    DIVERGING("Diverging (green→red)"), CUSTOM("Custom"),
}

enum class GradientStyle(val label: String) {
    LINEAR("Linear (horizontal)"), DIAGONAL("Diagonal (45°)"), RADIAL("Radial (spotlight)"),
}

enum class ShimmerMode(val label: String) {
    AUTO("Auto (follow theme)"), LIGHT("Light"), DARK("Dark"), CUSTOM("Custom"),
}

// ═══ CATEGORY 2: TYPOGRAPHY (12 settings) ═══

data class TypographySettings(
    val fontFamily: FontFamilyPref = FontFamilyPref.SYSTEM,
    val fontScale: Float = 1.0f,
    val headlineWeight: FontWeightPref = FontWeightPref.SEMI_BOLD,
    val bodyWeight: FontWeightPref = FontWeightPref.NORMAL,
    val labelLetterSpacing: Float = 0.1f,
    val monospaceForPaths: Boolean = true,
    val lineHeightMultiplier: Float = 1.0f,
    val maxLineLength: Int = 75,
    val labelTextTransform: TextTransform = TextTransform.NONE,
    val ligatures: Boolean = true,
    val kerning: Boolean = true,
    val displayFontSizeOverride: Float? = null,
)

enum class FontFamilyPref(val label: String, val key: String?) {
    SYSTEM("System default", null), INTER("Inter", "inter"),
    ROBOTO_MONO("Roboto Mono", "roboto_mono"),
    LXGW_WENKAI("LXGW WenKai (CJK)", "lxgw_wenkai"),
}

enum class FontWeightPref(val label: String, val weight: Int) {
    THIN("Thin", 100), LIGHT("Light", 300), NORMAL("Normal", 400),
    MEDIUM("Medium", 500), SEMI_BOLD("SemiBold", 600), BOLD("Bold", 700), EXTRA_BOLD("ExtraBold", 800),
}

enum class TextTransform(val label: String) {
    NONE("None"), UPPERCASE("Uppercase"), LOWERCASE("Lowercase"),
}

// ═══ CATEGORY 3: SHAPE & CORNER RADIUS (8 settings) ═══

data class ShapeSettings(
    val globalCornerRadius: Int? = null,
    val shapeStyle: ShapeStyle = ShapeStyle.MATERIAL,
    val cardCornerRadius: Int? = null,
    val dialogCornerRadius: Int? = null,
    val sheetCornerRadius: Int? = null,
    val buttonShape: ButtonShape = ButtonShape.PILL,
    val thumbnailCornerRadius: Int = 12,
    val asymmetricShapes: Boolean = true,
)

enum class ShapeStyle(val label: String) {
    MATERIAL("Material (default)"), COMPACT("Compact (sharper)"),
    SOFT("Soft (rounder)"), CUSTOM("Custom"),
}

enum class ButtonShape(val label: String) {
    PILL("Pill (fully rounded)"), ROUNDED("Rounded (16dp)"), RECTANGLE("Rectangle (sharp)"),
}

// ═══ CATEGORY 4: SPACING & DENSITY (10 settings) ═══

data class DensitySettings(
    val densityMode: DensityMode = DensityMode.NORMAL,
    val screenHorizontalPadding: Int = 16,
    val listItemHeight: ListItemHeight = ListItemHeight.NORMAL,
    val gridColumnCount: Int = 0,
    val gridTileSize: Int = 120,
    val sectionSpacing: Int = 24,
    val cardPadding: Int = 16,
    val iconSizeScale: Float = 1.0f,
    val touchTargetSize: Int = 48,
    val showFab: Boolean = true,
)

enum class DensityMode(val label: String) {
    COMPACT("Compact (more items)"), NORMAL("Normal"), SPACIOUS("Spacious (more breathing room)"),
}

enum class ListItemHeight(val label: String, val heightDp: Int) {
    COMPACT("Compact (56dp)", 56), NORMAL("Normal (72dp)", 72), LARGE("Large (88dp)", 88),
}

// ═══ CATEGORY 5: ELEVATION & SHADOWS (6 settings) ═══

data class ElevationSettings(
    val elevationStyle: ElevationStyle = ElevationStyle.MATERIAL,
    val cardElevation: Int = 1,
    val dialogElevation: Int = 3,
    val fabElevation: Int = 3,
    val tonalOverlayIntensity: Int = 100,
    val coloredShadows: Boolean = false,
)

enum class ElevationStyle(val label: String) {
    FLAT("Flat (no shadows)"), MATERIAL("Material (default)"), DRAMATIC("Dramatic (stronger shadows)"),
}

// ═══ CATEGORY 6: MOTION & ANIMATION (12 settings) ═══

data class MotionSettings(
    val animationSpeed: AnimationSpeed = AnimationSpeed.NORMAL,
    val reducedMotion: Boolean = false,
    val pageTransition: PageTransition = PageTransition.SLIDE,
    val staggerAnimation: Boolean = true,
    val staggerDelay: Int = 50,
    val springPhysics: SpringPhysics = SpringPhysics.SNAPPY,
    val skeletonShimmer: Boolean = true,
    val pulseAnimations: Boolean = true,
    val ambientFloat: Boolean = false,
    val listEnterAnimation: ListEnterAnimation = ListEnterAnimation.SLIDE,
    val vestibularSafe: Boolean = false,
    val marqueeScroll: Boolean = false,
)

enum class AnimationSpeed(val label: String, val multiplier: Float) {
    INSTANT("Instant (0ms)", 0f), FAST("Fast (100ms)", 0.33f),
    NORMAL("Normal (300ms)", 1f), SLOW("Slow (450ms)", 1.5f), CINEMATIC("Cinematic (1500ms)", 5f),
}

enum class PageTransition(val label: String) {
    SLIDE("Slide (horizontal)"), FADE("Fade"), SCALE("Scale"), NONE("None (instant)"),
}

enum class SpringPhysics(val label: String) {
    BOUNCY("Bouncy"), SNAPPY("Snappy"), GENTLE("Gentle"), NONE("None (tween only)"),
}

enum class ListEnterAnimation(val label: String) {
    SLIDE("Slide up + fade"), FADE("Fade only"), POP("Pop (bouncy scale)"), NONE("None (instant)"),
}

// ═══ CATEGORY 7: GLASSMORPHISM & BLUR (7 settings) ═══

data class GlassmorphismSettings(
    val enabled: Boolean = true,
    val blurIntensity: BlurIntensity = BlurIntensity.MEDIUM,
    val tintOpacity: Int = 65,
    val frostedAppBar: Boolean = true,
    val frostedBottomSheet: Boolean = true,
    val frostedDialog: Boolean = false,
    val fallback: GlassFallback = GlassFallback.SOLID_TINT,
)

enum class BlurIntensity(val label: String, val dp: Int) {
    SUBTLE("Subtle (4dp)", 4), LIGHT("Light (8dp)", 8), MEDIUM("Medium (16dp)", 16),
    HEAVY("Heavy (24dp)", 24), INTENSE("Intense (32dp)", 32),
}

enum class GlassFallback(val label: String) {
    SOLID_TINT("Solid tint (opaque)"), TRANSPARENT("Transparent (no blur)"),
}

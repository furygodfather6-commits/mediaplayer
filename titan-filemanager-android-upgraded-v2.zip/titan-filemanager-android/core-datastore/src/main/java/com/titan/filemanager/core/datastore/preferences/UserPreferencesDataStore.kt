package com.titan.filemanager.core.datastore.preferences

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import com.titan.filemanager.core.model.file.FileSorting
import com.titan.filemanager.core.model.file.SortDescriptor
import com.titan.filemanager.core.model.file.SortOrder
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Reads and writes [UserPreferences] to a [DataStore]<[Preferences]>.
 *
 * DataStore is the modern replacement for SharedPreferences:
 *   - Async (Flow-based, no ANRs)
 *   - Type-safe (this class is the only entry point)
 *   - Transactional (no partial writes)
 *   - Migrations from SharedPreferences supported
 *
 * Usage:
 * ```
 * class SomeViewModel @Inject constructor(private val store: UserPreferencesDataStore) {
 *     val prefs: Flow<UserPreferences> = store.userPreferences
 *
 *     fun setShowHidden(show: Boolean) {
 *         viewModelScope.launch {
 *             store.update { it.copy(showHiddenFiles = show) }
 *         }
 *     }
 * }
 * ```
 *
 * Storage: `context.filesDir/datastore/user_preferences.preferences_pb`
 */
@Singleton
class UserPreferencesDataStore @Inject constructor(
    private val dataStore: DataStore<Preferences>,
) {

    /**
     * Hot stream of the current preferences — emits immediately on
     * subscribe + on every change.
     */
    val userPreferences: Flow<UserPreferences> = dataStore.data.map { prefs ->
        prefs.toUserPreferences()
    }

    /**
     * Atomically update preferences. The [transform] lambda receives
     * the current state and returns the new state.
     *
     * Safe to call concurrently — DataStore serializes writes.
     */
    suspend fun update(transform: (UserPreferences) -> UserPreferences) {
        dataStore.edit { prefs ->
            val current = prefs.toUserPreferences()
            val new = transform(current)
            prefs.applyUserPreferences(new)
        }
    }

    // ── Mappers ───────────────────────────────────────────────────

    private fun Preferences.toUserPreferences(): UserPreferences = UserPreferences(
        viewMode = UserPreferences.ViewMode.valueOf(
            this[Keys.VIEW_MODE] ?: UserPreferences.ViewMode.LIST.name
        ),
        showHiddenFiles = this[Keys.SHOW_HIDDEN] ?: false,
        rememberLastFolder = this[Keys.REMEMBER_LAST_FOLDER] ?: true,
        lastOpenedPath = this[Keys.LAST_OPENED_PATH],
        sortDescriptor = SortDescriptor(
            sorting = FileSorting.valueOf(this[Keys.SORT_FIELD] ?: FileSorting.NAME.name),
            order = SortOrder.valueOf(this[Keys.SORT_ORDER] ?: SortOrder.ASCENDING.name),
            directoriesFirst = this[Keys.DIRECTORIES_FIRST] ?: true,
        ),
        themeMode = UserPreferences.ThemeMode.valueOf(
            this[Keys.THEME_MODE] ?: UserPreferences.ThemeMode.SYSTEM.name
        ),
        dynamicColorEnabled = this[Keys.DYNAMIC_COLOR] ?: true,
        confirmDelete = this[Keys.CONFIRM_DELETE] ?: true,
        confirmOverwrite = this[Keys.CONFIRM_OVERWRITE] ?: true,
        showFab = this[Keys.SHOW_FAB] ?: true,
    )

    private fun androidx.datastore.preferences.core.MutablePreferences.applyUserPreferences(prefs: UserPreferences) {
        this[Keys.VIEW_MODE] = prefs.viewMode.name
        this[Keys.SHOW_HIDDEN] = prefs.showHiddenFiles
        this[Keys.REMEMBER_LAST_FOLDER] = prefs.rememberLastFolder
        prefs.lastOpenedPath?.let { this[Keys.LAST_OPENED_PATH] = it } ?: remove(Keys.LAST_OPENED_PATH)
        this[Keys.SORT_FIELD] = prefs.sortDescriptor.sorting.name
        this[Keys.SORT_ORDER] = prefs.sortDescriptor.order.name
        this[Keys.DIRECTORIES_FIRST] = prefs.sortDescriptor.directoriesFirst
        this[Keys.THEME_MODE] = prefs.themeMode.name
        this[Keys.DYNAMIC_COLOR] = prefs.dynamicColorEnabled
        this[Keys.CONFIRM_DELETE] = prefs.confirmDelete
        this[Keys.CONFIRM_OVERWRITE] = prefs.confirmOverwrite
        this[Keys.SHOW_FAB] = prefs.showFab
    }

    private object Keys {
        val VIEW_MODE = stringPreferencesKey("view_mode")
        val SHOW_HIDDEN = booleanPreferencesKey("show_hidden")
        val REMEMBER_LAST_FOLDER = booleanPreferencesKey("remember_last_folder")
        val LAST_OPENED_PATH = stringPreferencesKey("last_opened_path")
        val SORT_FIELD = stringPreferencesKey("sort_field")
        val SORT_ORDER = stringPreferencesKey("sort_order")
        val DIRECTORIES_FIRST = booleanPreferencesKey("directories_first")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val DYNAMIC_COLOR = booleanPreferencesKey("dynamic_color")
        val CONFIRM_DELETE = booleanPreferencesKey("confirm_delete")
        val CONFIRM_OVERWRITE = booleanPreferencesKey("confirm_overwrite")
        val SHOW_FAB = booleanPreferencesKey("show_fab")
    }
}

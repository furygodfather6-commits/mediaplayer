package com.titan.filemanager.core.datastore.security

/**
 * ## SecuritySettings
 *
 * Root data class for 34 security + cloud + notification settings across 3 categories.
 */
data class SecuritySettings(
    val vault: VaultSettings = VaultSettings(),
    val cloud: CloudSyncSettings = CloudSyncSettings(),
    val notifications: NotificationSettings = NotificationSettings(),
)

// ═══ CATEGORY 13: VAULT & SECURITY (14 settings) ═══

data class VaultSettings(
    val appLockEnabled: Boolean = false,
    val biometricUnlock: Boolean = false,
    val autoLockOnBackground: Boolean = true,
    val autoLockDelaySec: Int = 0, // 0=immediate, 30, 60, 300, 900
    val blockScreenshotsInVault: Boolean = true,
    val blockScreenshotsOnLockScreen: Boolean = true,
    val encryptionAlgorithm: EncryptionAlgo = EncryptionAlgo.AES_256_GCM,
    val pbkdf2Iterations: Int = 10000,
    val maxFailedAttempts: Int = 5,
    val lockoutDurationSec: Int = 60,
    val secureFileDeletion: Boolean = false,
    // Actions (non-persisted — triggered from UI)
    val setPinAction: Boolean = false,
    val changePasswordAction: Boolean = false,
    val deleteVaultAction: Boolean = false,
)

enum class EncryptionAlgo(val label: String) {
    AES_256_GCM("AES-256-GCM (recommended)"),
    CHACHA20_POLY1305("ChaCha20-Poly1305"),
}

// ═══ CATEGORY 14: CLOUD SYNC (10 settings) ═══

data class CloudSyncSettings(
    val autoSync: Boolean = false,
    val autoSyncIntervalMin: Int = 60, // 15, 30, 60, 360, 720, 1440
    val syncOnWifiOnly: Boolean = true,
    val syncWhenCharging: Boolean = false,
    val maxConcurrentTransfers: Int = 2,
    val transferTimeoutSec: Int = 60, // 30, 60, 120, 300
    val retryAttempts: Int = 3, // 0, 1, 3, 5
    val retryBackoffSec: Int = 2, // 1, 2, 5, 10
    val conflictResolution: ConflictResolution = ConflictResolution.ASK,
    val transferNotifications: Boolean = true,
)

enum class ConflictResolution(val label: String) {
    ASK("Ask each time"),
    KEEP_LOCAL("Keep local version"),
    KEEP_REMOTE("Keep remote version"),
    KEEP_NEWER("Keep newer version"),
}

// ═══ CATEGORY 20: NOTIFICATIONS (10 settings) ═══

data class NotificationSettings(
    val masterEnabled: Boolean = true,
    val transferNotifications: Boolean = true,
    val scanProgressNotifications: Boolean = true,
    val vaultNotifications: Boolean = true,
    val duplicateNotifications: Boolean = true,
    val backupNotifications: Boolean = true,
    val syncNotifications: Boolean = true,
    val warningNotifications: Boolean = true,
    val notificationSound: Boolean = true,
    val notificationVibration: Boolean = true,
)

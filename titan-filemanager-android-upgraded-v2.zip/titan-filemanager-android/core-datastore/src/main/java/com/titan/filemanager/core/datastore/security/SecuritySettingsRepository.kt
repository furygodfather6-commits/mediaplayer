package com.titan.filemanager.core.datastore.security

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.securityDataStore: DataStore<Preferences> by preferencesDataStore("security_settings")

@Singleton
class SecuritySettingsRepository @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private val ds = context.securityDataStore

    val settings: Flow<SecuritySettings> = ds.data.map { p ->
        SecuritySettings(
            vault = VaultSettings(
                appLockEnabled = p[K_APP_LOCK] ?: false,
                biometricUnlock = p[K_BIOMETRIC] ?: false,
                autoLockOnBackground = p[K_AUTO_LOCK_BG] ?: true,
                autoLockDelaySec = p[K_AUTO_LOCK_DELAY] ?: 0,
                blockScreenshotsInVault = p[K_BLOCK_SS_VAULT] ?: true,
                blockScreenshotsOnLockScreen = p[K_BLOCK_SS_LOCK] ?: true,
                encryptionAlgorithm = p[K_ENC_ALGO]?.let { EncryptionAlgo.valueOf(it) } ?: EncryptionAlgo.AES_256_GCM,
                pbkdf2Iterations = p[K_PBKDF2_ITER] ?: 10000,
                maxFailedAttempts = p[K_MAX_FAILED] ?: 5,
                lockoutDurationSec = p[K_LOCKOUT_SEC] ?: 60,
                secureFileDeletion = p[K_SECURE_DEL] ?: false,
                setPinAction = false, changePasswordAction = false, deleteVaultAction = false,
            ),
            cloud = CloudSyncSettings(
                autoSync = p[K_AUTO_SYNC] ?: false,
                autoSyncIntervalMin = p[K_SYNC_INTERVAL] ?: 60,
                syncOnWifiOnly = p[K_WIFI_ONLY] ?: true,
                syncWhenCharging = p[K_CHARGING_ONLY] ?: false,
                maxConcurrentTransfers = p[K_MAX_TRANSFERS] ?: 2,
                transferTimeoutSec = p[K_TRANSFER_TIMEOUT] ?: 60,
                retryAttempts = p[K_RETRY_ATTEMPTS] ?: 3,
                retryBackoffSec = p[K_RETRY_BACKOFF] ?: 2,
                conflictResolution = p[K_CONFLICT]?.let { ConflictResolution.valueOf(it) } ?: ConflictResolution.ASK,
                transferNotifications = p[K_TRANSFER_NOTIF] ?: true,
            ),
            notifications = NotificationSettings(
                masterEnabled = p[K_NOTIF_MASTER] ?: true,
                transferNotifications = p[K_NOTIF_TRANSFER] ?: true,
                scanProgressNotifications = p[K_NOTIF_SCAN] ?: true,
                vaultNotifications = p[K_NOTIF_VAULT] ?: true,
                duplicateNotifications = p[K_NOTIF_DUP] ?: true,
                backupNotifications = p[K_NOTIF_BACKUP] ?: true,
                syncNotifications = p[K_NOTIF_SYNC] ?: true,
                warningNotifications = p[K_NOTIF_WARNING] ?: true,
                notificationSound = p[K_NOTIF_SOUND] ?: true,
                notificationVibration = p[K_NOTIF_VIBRATION] ?: true,
            ),
        )
    }

    suspend fun updateVault(block: (VaultSettings) -> VaultSettings) {
        ds.edit { p ->
            val u = block(VaultSettings())
            p[K_APP_LOCK] = u.appLockEnabled; p[K_BIOMETRIC] = u.biometricUnlock
            p[K_AUTO_LOCK_BG] = u.autoLockOnBackground; p[K_AUTO_LOCK_DELAY] = u.autoLockDelaySec
            p[K_BLOCK_SS_VAULT] = u.blockScreenshotsInVault; p[K_BLOCK_SS_LOCK] = u.blockScreenshotsOnLockScreen
            p[K_ENC_ALGO] = u.encryptionAlgorithm.name; p[K_PBKDF2_ITER] = u.pbkdf2Iterations
            p[K_MAX_FAILED] = u.maxFailedAttempts; p[K_LOCKOUT_SEC] = u.lockoutDurationSec
            p[K_SECURE_DEL] = u.secureFileDeletion
        }
    }
    suspend fun updateCloud(block: (CloudSyncSettings) -> CloudSyncSettings) {
        ds.edit { p ->
            val u = block(CloudSyncSettings())
            p[K_AUTO_SYNC] = u.autoSync; p[K_SYNC_INTERVAL] = u.autoSyncIntervalMin
            p[K_WIFI_ONLY] = u.syncOnWifiOnly; p[K_CHARGING_ONLY] = u.syncWhenCharging
            p[K_MAX_TRANSFERS] = u.maxConcurrentTransfers; p[K_TRANSFER_TIMEOUT] = u.transferTimeoutSec
            p[K_RETRY_ATTEMPTS] = u.retryAttempts; p[K_RETRY_BACKOFF] = u.retryBackoffSec
            p[K_CONFLICT] = u.conflictResolution.name; p[K_TRANSFER_NOTIF] = u.transferNotifications
        }
    }
    suspend fun updateNotifications(block: (NotificationSettings) -> NotificationSettings) {
        ds.edit { p ->
            val u = block(NotificationSettings())
            p[K_NOTIF_MASTER] = u.masterEnabled; p[K_NOTIF_TRANSFER] = u.transferNotifications
            p[K_NOTIF_SCAN] = u.scanProgressNotifications; p[K_NOTIF_VAULT] = u.vaultNotifications
            p[K_NOTIF_DUP] = u.duplicateNotifications; p[K_NOTIF_BACKUP] = u.backupNotifications
            p[K_NOTIF_SYNC] = u.syncNotifications; p[K_NOTIF_WARNING] = u.warningNotifications
            p[K_NOTIF_SOUND] = u.notificationSound; p[K_NOTIF_VIBRATION] = u.notificationVibration
        }
    }
    suspend fun resetAll() { ds.edit { it.clear() } }

    companion object {
        val K_APP_LOCK = booleanPreferencesKey("app_lock")
        val K_BIOMETRIC = booleanPreferencesKey("biometric")
        val K_AUTO_LOCK_BG = booleanPreferencesKey("auto_lock_bg")
        val K_AUTO_LOCK_DELAY = intPreferencesKey("auto_lock_delay")
        val K_BLOCK_SS_VAULT = booleanPreferencesKey("block_ss_vault")
        val K_BLOCK_SS_LOCK = booleanPreferencesKey("block_ss_lock")
        val K_ENC_ALGO = stringPreferencesKey("enc_algo")
        val K_PBKDF2_ITER = intPreferencesKey("pbkdf2_iter")
        val K_MAX_FAILED = intPreferencesKey("max_failed")
        val K_LOCKOUT_SEC = intPreferencesKey("lockout_sec")
        val K_SECURE_DEL = booleanPreferencesKey("secure_del")
        val K_AUTO_SYNC = booleanPreferencesKey("auto_sync")
        val K_SYNC_INTERVAL = intPreferencesKey("sync_interval")
        val K_WIFI_ONLY = booleanPreferencesKey("wifi_only")
        val K_CHARGING_ONLY = booleanPreferencesKey("charging_only")
        val K_MAX_TRANSFERS = intPreferencesKey("max_transfers")
        val K_TRANSFER_TIMEOUT = intPreferencesKey("transfer_timeout")
        val K_RETRY_ATTEMPTS = intPreferencesKey("retry_attempts")
        val K_RETRY_BACKOFF = intPreferencesKey("retry_backoff")
        val K_CONFLICT = stringPreferencesKey("conflict")
        val K_TRANSFER_NOTIF = booleanPreferencesKey("transfer_notif")
        val K_NOTIF_MASTER = booleanPreferencesKey("notif_master")
        val K_NOTIF_TRANSFER = booleanPreferencesKey("notif_transfer")
        val K_NOTIF_SCAN = booleanPreferencesKey("notif_scan")
        val K_NOTIF_VAULT = booleanPreferencesKey("notif_vault")
        val K_NOTIF_DUP = booleanPreferencesKey("notif_dup")
        val K_NOTIF_BACKUP = booleanPreferencesKey("notif_backup")
        val K_NOTIF_SYNC = booleanPreferencesKey("notif_sync")
        val K_NOTIF_WARNING = booleanPreferencesKey("notif_warning")
        val K_NOTIF_SOUND = booleanPreferencesKey("notif_sound")
        val K_NOTIF_VIBRATION = booleanPreferencesKey("notif_vibration")
    }
}

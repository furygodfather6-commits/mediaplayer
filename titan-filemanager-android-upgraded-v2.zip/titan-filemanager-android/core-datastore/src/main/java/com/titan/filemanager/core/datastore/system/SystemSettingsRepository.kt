package com.titan.filemanager.core.datastore.system

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.systemDataStore: DataStore<Preferences> by preferencesDataStore("system_settings")

@Singleton
class SystemSettingsRepository @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private val ds = context.systemDataStore

    val settings: Flow<SystemSettings> = ds.data.map { p ->
        SystemSettings(
            fileBrowser = FileBrowserSettings(
                defaultViewMode = p[K_VIEW_MODE]?.let { ViewModePref.valueOf(it) } ?: ViewModePref.LIST,
                defaultSortField = p[K_SORT_FIELD]?.let { SortFieldPref.valueOf(it) } ?: SortFieldPref.NAME,
                defaultSortOrder = p[K_SORT_ORDER]?.let { SortOrderPref.valueOf(it) } ?: SortOrderPref.ASCENDING,
                directoriesFirst = p[K_DIRS_FIRST] ?: true,
                showHiddenFiles = p[K_SHOW_HIDDEN] ?: false,
                showFileExtensions = p[K_SHOW_EXT] ?: true,
                showFileSizes = p[K_SHOW_SIZES] ?: true,
                showModificationDates = p[K_SHOW_DATES] ?: true,
                showFileThumbnails = p[K_SHOW_THUMBS] ?: true,
                thumbnailSize = p[K_THUMB_SIZE]?.let { ThumbnailSizePref.valueOf(it) } ?: ThumbnailSizePref.SMALL,
                showBreadcrumbBar = p[K_BREADCRUMB] ?: true,
                showStorageBarInBrowser = p[K_STORAGE_BAR] ?: false,
                rememberLastFolder = p[K_REMEMBER_FOLDER] ?: true,
                showBookmarkIndicators = p[K_BOOKMARK_INDIC] ?: true,
            ),
            accessibility = AccessibilitySettings(
                highContrast = p[K_HIGH_CONTRAST] ?: false,
                fontScale = p[K_A11Y_FONT_SCALE] ?: 1.0f,
                minTouchTargetDp = p[K_TOUCH_TARGET] ?: 48,
                reducedMotion = p[K_A11Y_REDUCED_MOTION] ?: false,
                vestibularSafe = p[K_VESTIBULAR] ?: false,
                focusRingThicknessDp = p[K_FOCUS_RING] ?: 2,
                focusRingColorAuto = p[K_FOCUS_RING_AUTO] ?: true,
                screenReaderAnnouncements = p[K_SCREEN_READER] ?: true,
                contentDescriptionLevel = p[K_CONTENT_DESC]?.let { ContentDescriptionLevel.valueOf(it) } ?: ContentDescriptionLevel.DETAILED,
                colorBlindMode = p[K_COLOR_BLIND]?.let { ColorBlindMode.valueOf(it) } ?: ColorBlindMode.NONE,
            ),
            performance = PerformanceSettings(
                performanceMode = p[K_PERF_MODE]?.let { PerformanceMode.valueOf(it) } ?: PerformanceMode.AUTO,
                maxBackgroundThreads = p[K_MAX_THREADS] ?: 8,
                batteryAwareScheduling = p[K_BATTERY_AWARE] ?: true,
                thermalThrottling = p[K_THERMAL] ?: true,
                lowMemoryMode = p[K_LOW_MEM] ?: false,
                chargingAwareOptimization = p[K_CHARGING_AWARE] ?: true,
                databaseCompactionInterval = p[K_COMPACTION]?.let { CompactionInterval.valueOf(it) } ?: CompactionInterval.WEEKLY,
                thumbnailPreGeneration = p[K_THUMB_PREGEN] ?: false,
            ),
            storage = StorageSettings(
                showAvailableStorageOnHome = p[K_STORAGE_HOME] ?: true,
                lowStorageWarningThreshold = p[K_LOW_STORAGE_THRESHOLD] ?: 10,
                cacheSizeLimitMb = p[K_CACHE_LIMIT_MB] ?: 500,
                autoClearCacheWhenLow = p[K_AUTO_CLEAR_LOW] ?: true,
                storageRefreshInterval = p[K_STORAGE_REFRESH]?.let { StorageRefreshInterval.valueOf(it) } ?: StorageRefreshInterval.MIN_30,
                showStorageInStatusBar = p[K_STORAGE_STATUS_BAR] ?: false,
            ),
            behavior = BehaviorSettings(
                confirmBeforeDelete = p[K_CONFIRM_DELETE] ?: true,
                confirmBeforeOverwrite = p[K_CONFIRM_OVERWRITE] ?: true,
                confirmBeforeMove = p[K_CONFIRM_MOVE] ?: false,
                defaultOpenWith = p[K_OPEN_WITH]?.let { DefaultOpenWith.valueOf(it) } ?: DefaultOpenWith.SYSTEM_DEFAULT,
                clipboardFormat = p[K_CLIPBOARD_FMT]?.let { ClipboardFormat.valueOf(it) } ?: ClipboardFormat.FULL_PATH,
                showFilePropertiesOnLongPress = p[K_PROPS_LONG_PRESS] ?: true,
                hapticFeedback = p[K_HAPTIC] ?: true,
                keepScreenOnDuringTransfers = p[K_KEEP_SCREEN_ON] ?: false,
            ),
            advanced = AdvancedSettings(
                debugLogging = p[K_DEBUG_LOG] ?: false,
                logLevel = p[K_LOG_LEVEL]?.let { LogLevel.valueOf(it) } ?: LogLevel.INFO,
                leakCanary = p[K_LEAK_CANARY] ?: true,
                chuckerHttpInspector = p[K_CHUCKER] ?: true,
                showInodeNumbers = p[K_SHOW_INODE] ?: false,
                showFilePermissions = p[K_SHOW_PERMS] ?: false,
                showContentHashes = p[K_SHOW_HASHES] ?: false,
                exportSettingsAction = false, importSettingsAction = false, resetAllSettingsAction = false,
            ),
        )
    }

    suspend fun updateFileBrowser(block: (FileBrowserSettings) -> FileBrowserSettings) {
        ds.edit { p ->
            val u = block(FileBrowserSettings())
            p[K_VIEW_MODE] = u.defaultViewMode.name; p[K_SORT_FIELD] = u.defaultSortField.name
            p[K_SORT_ORDER] = u.defaultSortOrder.name; p[K_DIRS_FIRST] = u.directoriesFirst
            p[K_SHOW_HIDDEN] = u.showHiddenFiles; p[K_SHOW_EXT] = u.showFileExtensions
            p[K_SHOW_SIZES] = u.showFileSizes; p[K_SHOW_DATES] = u.showModificationDates
            p[K_SHOW_THUMBS] = u.showFileThumbnails; p[K_THUMB_SIZE] = u.thumbnailSize.name
            p[K_BREADCRUMB] = u.showBreadcrumbBar; p[K_STORAGE_BAR] = u.showStorageBarInBrowser
            p[K_REMEMBER_FOLDER] = u.rememberLastFolder; p[K_BOOKMARK_INDIC] = u.showBookmarkIndicators
        }
    }
    suspend fun updateAccessibility(block: (AccessibilitySettings) -> AccessibilitySettings) {
        ds.edit { p ->
            val u = block(AccessibilitySettings())
            p[K_HIGH_CONTRAST] = u.highContrast; p[K_A11Y_FONT_SCALE] = u.fontScale
            p[K_TOUCH_TARGET] = u.minTouchTargetDp; p[K_A11Y_REDUCED_MOTION] = u.reducedMotion
            p[K_VESTIBULAR] = u.vestibularSafe; p[K_FOCUS_RING] = u.focusRingThicknessDp
            p[K_FOCUS_RING_AUTO] = u.focusRingColorAuto; p[K_SCREEN_READER] = u.screenReaderAnnouncements
            p[K_CONTENT_DESC] = u.contentDescriptionLevel.name; p[K_COLOR_BLIND] = u.colorBlindMode.name
        }
    }
    suspend fun updatePerformance(block: (PerformanceSettings) -> PerformanceSettings) {
        ds.edit { p ->
            val u = block(PerformanceSettings())
            p[K_PERF_MODE] = u.performanceMode.name; p[K_MAX_THREADS] = u.maxBackgroundThreads
            p[K_BATTERY_AWARE] = u.batteryAwareScheduling; p[K_THERMAL] = u.thermalThrottling
            p[K_LOW_MEM] = u.lowMemoryMode; p[K_CHARGING_AWARE] = u.chargingAwareOptimization
            p[K_COMPACTION] = u.databaseCompactionInterval.name; p[K_THUMB_PREGEN] = u.thumbnailPreGeneration
        }
    }
    suspend fun updateStorage(block: (StorageSettings) -> StorageSettings) {
        ds.edit { p ->
            val u = block(StorageSettings())
            p[K_STORAGE_HOME] = u.showAvailableStorageOnHome; p[K_LOW_STORAGE_THRESHOLD] = u.lowStorageWarningThreshold
            p[K_CACHE_LIMIT_MB] = u.cacheSizeLimitMb; p[K_AUTO_CLEAR_LOW] = u.autoClearCacheWhenLow
            p[K_STORAGE_REFRESH] = u.storageRefreshInterval.name; p[K_STORAGE_STATUS_BAR] = u.showStorageInStatusBar
        }
    }
    suspend fun updateBehavior(block: (BehaviorSettings) -> BehaviorSettings) {
        ds.edit { p ->
            val u = block(BehaviorSettings())
            p[K_CONFIRM_DELETE] = u.confirmBeforeDelete; p[K_CONFIRM_OVERWRITE] = u.confirmBeforeOverwrite
            p[K_CONFIRM_MOVE] = u.confirmBeforeMove; p[K_OPEN_WITH] = u.defaultOpenWith.name
            p[K_CLIPBOARD_FMT] = u.clipboardFormat.name; p[K_PROPS_LONG_PRESS] = u.showFilePropertiesOnLongPress
            p[K_HAPTIC] = u.hapticFeedback; p[K_KEEP_SCREEN_ON] = u.keepScreenOnDuringTransfers
        }
    }
    suspend fun updateAdvanced(block: (AdvancedSettings) -> AdvancedSettings) {
        ds.edit { p ->
            val u = block(AdvancedSettings())
            p[K_DEBUG_LOG] = u.debugLogging; p[K_LOG_LEVEL] = u.logLevel.name
            p[K_LEAK_CANARY] = u.leakCanary; p[K_CHUCKER] = u.chuckerHttpInspector
            p[K_SHOW_INODE] = u.showInodeNumbers; p[K_SHOW_PERMS] = u.showFilePermissions
            p[K_SHOW_HASHES] = u.showContentHashes
        }
    }
    suspend fun resetAll() { ds.edit { it.clear() } }

    companion object {
        val K_VIEW_MODE = stringPreferencesKey("view_mode")
        val K_SORT_FIELD = stringPreferencesKey("sort_field")
        val K_SORT_ORDER = stringPreferencesKey("sort_order")
        val K_DIRS_FIRST = booleanPreferencesKey("dirs_first")
        val K_SHOW_HIDDEN = booleanPreferencesKey("show_hidden")
        val K_SHOW_EXT = booleanPreferencesKey("show_ext")
        val K_SHOW_SIZES = booleanPreferencesKey("show_sizes")
        val K_SHOW_DATES = booleanPreferencesKey("show_dates")
        val K_SHOW_THUMBS = booleanPreferencesKey("show_thumbs")
        val K_THUMB_SIZE = stringPreferencesKey("thumb_size")
        val K_BREADCRUMB = booleanPreferencesKey("breadcrumb")
        val K_STORAGE_BAR = booleanPreferencesKey("storage_bar")
        val K_REMEMBER_FOLDER = booleanPreferencesKey("remember_folder")
        val K_BOOKMARK_INDIC = booleanPreferencesKey("bookmark_indic")
        val K_HIGH_CONTRAST = booleanPreferencesKey("a11y_high_contrast")
        val K_A11Y_FONT_SCALE = floatPreferencesKey("a11y_font_scale")
        val K_TOUCH_TARGET = intPreferencesKey("touch_target")
        val K_A11Y_REDUCED_MOTION = booleanPreferencesKey("a11y_reduced_motion")
        val K_VESTIBULAR = booleanPreferencesKey("vestibular")
        val K_FOCUS_RING = intPreferencesKey("focus_ring")
        val K_FOCUS_RING_AUTO = booleanPreferencesKey("focus_ring_auto")
        val K_SCREEN_READER = booleanPreferencesKey("screen_reader")
        val K_CONTENT_DESC = stringPreferencesKey("content_desc")
        val K_COLOR_BLIND = stringPreferencesKey("color_blind")
        val K_PERF_MODE = stringPreferencesKey("perf_mode")
        val K_MAX_THREADS = intPreferencesKey("max_threads")
        val K_BATTERY_AWARE = booleanPreferencesKey("battery_aware")
        val K_THERMAL = booleanPreferencesKey("thermal")
        val K_LOW_MEM = booleanPreferencesKey("low_mem")
        val K_CHARGING_AWARE = booleanPreferencesKey("charging_aware")
        val K_COMPACTION = stringPreferencesKey("compaction")
        val K_THUMB_PREGEN = booleanPreferencesKey("thumb_pregen")
        val K_STORAGE_HOME = booleanPreferencesKey("storage_home")
        val K_LOW_STORAGE_THRESHOLD = intPreferencesKey("low_storage_threshold")
        val K_CACHE_LIMIT_MB = intPreferencesKey("cache_limit_mb")
        val K_AUTO_CLEAR_LOW = booleanPreferencesKey("auto_clear_low")
        val K_STORAGE_REFRESH = stringPreferencesKey("storage_refresh")
        val K_STORAGE_STATUS_BAR = booleanPreferencesKey("storage_status_bar")
        val K_CONFIRM_DELETE = booleanPreferencesKey("confirm_delete")
        val K_CONFIRM_OVERWRITE = booleanPreferencesKey("confirm_overwrite")
        val K_CONFIRM_MOVE = booleanPreferencesKey("confirm_move")
        val K_OPEN_WITH = stringPreferencesKey("open_with")
        val K_CLIPBOARD_FMT = stringPreferencesKey("clipboard_fmt")
        val K_PROPS_LONG_PRESS = booleanPreferencesKey("props_long_press")
        val K_HAPTIC = booleanPreferencesKey("haptic")
        val K_KEEP_SCREEN_ON = booleanPreferencesKey("keep_screen_on")
        val K_DEBUG_LOG = booleanPreferencesKey("debug_log")
        val K_LOG_LEVEL = stringPreferencesKey("log_level")
        val K_LEAK_CANARY = booleanPreferencesKey("leak_canary")
        val K_CHUCKER = booleanPreferencesKey("chucker")
        val K_SHOW_INODE = booleanPreferencesKey("show_inode")
        val K_SHOW_PERMS = booleanPreferencesKey("show_perms")
        val K_SHOW_HASHES = booleanPreferencesKey("show_hashes")
    }
}

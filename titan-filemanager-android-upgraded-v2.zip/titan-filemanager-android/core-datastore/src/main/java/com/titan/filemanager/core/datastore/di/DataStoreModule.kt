package com.titan.filemanager.core.datastore.di

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import androidx.datastore.preferences.core.Preferences
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Provides the [DataStore]<[Preferences]> singleton.
 *
 * File location: `context.filesDir/datastore/user_preferences.preferences_pb`
 *
 * Single source of truth — every consumer depends on
 * [com.titan.filemanager.core.datastore.preferences.UserPreferencesDataStore]
 * which is itself `@Inject`-constructed with this DataStore.
 */
@Module
@InstallIn(SingletonComponent::class)
object DataStoreModule {

    @Provides
    @Singleton
    fun provideUserPreferencesDataStore(
        @ApplicationContext context: Context,
    ): DataStore<Preferences> = PreferenceDataStoreFactory.create(
        scope = kotlinx.coroutines.CoroutineScope(
            kotlinx.coroutines.Dispatchers.IO +
                kotlinx.coroutines.SupervisorJob()
        ),
        produceFile = {
            java.io.File(
                context.filesDir,
                "datastore/user_preferences.preferences_pb"
            )
        },
    )
}

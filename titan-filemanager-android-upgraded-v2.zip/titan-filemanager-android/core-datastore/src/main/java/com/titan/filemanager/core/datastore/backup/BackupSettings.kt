package com.titan.filemanager.core.datastore.backup

/**
 * ## BackupSettings
 *
 * Root data class for 14 backup + archive settings across 2 categories.
 */
data class BackupSettings(
    val backup: BackupConfigSettings = BackupConfigSettings(),
    val archive: ArchiveConfigSettings = ArchiveConfigSettings(),
)

// ═══ CATEGORY 15: ARCHIVE & COMPRESSION (6 settings) ═══

data class ArchiveConfigSettings(
    val defaultArchiveFormat: ArchiveFormatPref = ArchiveFormatPref.ZIP,
    val defaultCompressionLevel: CompressionLevelPref = CompressionLevelPref.NORMAL,
    val defaultPasswordProtection: Boolean = false,
    val encryptFilenames: Boolean = false,
    val splitArchivesEnabled: Boolean = false,
    val defaultSplitVolumeMb: Int = 100,
)

enum class ArchiveFormatPref(val label: String, val ext: String) {
    ZIP("ZIP (.zip)", "zip"),
    SEVEN_Z("7-Zip (.7z)", "7z"),
    TAR_GZ("TAR.GZ (.tar.gz)", "tar.gz"),
    TAR_BZ2("TAR.BZ2 (.tar.bz2)", "tar.bz2"),
    TAR_XZ("TAR.XZ (.tar.xz)", "tar.xz"),
}

enum class CompressionLevelPref(val label: String, val level: Int) {
    STORE("Store (no compression)", 0),
    FAST("Fast", 1),
    NORMAL("Normal", 6),
    MAXIMUM("Maximum", 9),
}

// ═══ CATEGORY 19: BACKUP & RESTORE (8 settings) ═══

data class BackupConfigSettings(
    val autoBackup: Boolean = false,
    val backupInterval: BackupInterval = BackupInterval.WEEKLY,
    val backupDestination: BackupDestination = BackupDestination.LOCAL,
    val backupEncryption: Boolean = false,
    val maxBackupCount: Int = 5,
    val includeDatabases: Boolean = true,
    val includePreferences: Boolean = true,
    val backupNowAction: Boolean = false, // action trigger
)

enum class BackupInterval(val label: String) {
    DAILY("Daily"), WEEKLY("Weekly"), MONTHLY("Monthly"),
}

enum class BackupDestination(val label: String) {
    LOCAL("Local storage"),
    CLOUD("Cloud storage"),
    BOTH("Both local and cloud"),
}

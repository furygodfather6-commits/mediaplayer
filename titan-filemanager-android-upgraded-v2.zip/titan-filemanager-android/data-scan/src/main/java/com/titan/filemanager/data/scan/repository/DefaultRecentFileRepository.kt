package com.titan.filemanager.data.scan.repository

import com.titan.filemanager.core.common.dispatcher.DispatcherProvider
import com.titan.filemanager.core.common.logger.Logger
import com.titan.filemanager.core.database.dao.RecentFileDao
import com.titan.filemanager.core.database.entity.RecentFileEntity
import com.titan.filemanager.domain.recent.RecentFile
import com.titan.filemanager.domain.recent.RecentFileRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Default [RecentFileRepository] — backed by Room [RecentFileDao].
 */
@Singleton
class DefaultRecentFileRepository @Inject constructor(
    private val recentFileDao: RecentFileDao,
    private val dispatchers: DispatcherProvider,
    private val logger: Logger,
) : RecentFileRepository {

    override fun observeRecent(limit: Int): Flow<List<RecentFile>> =
        recentFileDao.observeRecent(limit).map { entities ->
            entities.map { it.toRecentFile() }
        }

    override suspend fun getRecent(limit: Int): List<RecentFile> =
        withContext(dispatchers.io) {
            recentFileDao.getRecent(limit).map { it.toRecentFile() }
        }

    override suspend fun recordAccess(path: String, name: String, mimeType: String?) {
        withContext(dispatchers.io) {
            recentFileDao.upsertAccess(
                path = path,
                name = name,
                mimeType = mimeType,
                now = System.currentTimeMillis(),
            )
            logger.d { "Recent file access recorded: $path" }
        }
    }

    override suspend fun removeRecent(path: String) {
        withContext(dispatchers.io) {
            recentFileDao.deleteByPath(path)
        }
    }

    override suspend fun clearAll() {
        withContext(dispatchers.io) {
            recentFileDao.clearAll()
        }
    }

    private fun RecentFileEntity.toRecentFile(): RecentFile = RecentFile(
        id = id,
        path = path,
        name = name,
        mimeType = mimeType,
        lastAccessedAt = lastAccessedAt,
        accessCount = accessCount,
    )
}

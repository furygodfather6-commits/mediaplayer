package com.titan.filemanager.data.scan.repository

import com.titan.filemanager.core.common.dispatcher.DispatcherProvider
import com.titan.filemanager.core.common.logger.Logger
import com.titan.filemanager.core.common.result.AppError
import com.titan.filemanager.core.common.result.Result
import com.titan.filemanager.core.database.dao.FileDao
import com.titan.filemanager.core.database.entity.FileEntity
import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.core.model.file.SortDescriptor
import com.titan.filemanager.core.model.scan.ScanResult
import com.titan.filemanager.core.model.scan.ScanState
import com.titan.filemanager.data.scan.engine.DirectoryScanEngine
import com.titan.filemanager.data.scan.util.FileSorter
import com.titan.filemanager.domain.scan.DirectoryScanRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Default implementation of [DirectoryScanRepository].
 *
 * Composes [DirectoryScanEngine] (filesystem access) + [FileDao]
 * (cache) + [FileSorter] (in-memory sort).
 *
 * Phase 1 cache strategy: write-through (every scan persists to DB),
 * read with optional cache lookup via [getCachedListing].
 *
 * Phase 2 will add:
 *   - L1/L2/L3 cache hierarchy (HotDir → LruCache → SQLite)
 *   - Incremental scan (resume from token)
 *   - Background prefetch
 */
@Singleton
class DefaultDirectoryScanRepository @Inject constructor(
    private val engine: DirectoryScanEngine,
    private val fileDao: FileDao,
    private val dispatchers: DispatcherProvider,
    private val logger: Logger,
) : DirectoryScanRepository {

    /** Tracks paths currently being scanned — for cancellation. */
    private val activeScans = kotlinx.coroutines.flow.MutableStateFlow<Set<String>>(emptySet())

    override suspend fun scanDirectory(
        path: String,
        sort: SortDescriptor,
        showHidden: Boolean,
    ): Result<ScanResult> = withContext(dispatchers.io) {
        try {
            val result = engine.scanDirectoryBlocking(path, showHidden)
            val sorted = FileSorter.sort(result.items, sort)
            val final = result.copy(items = sorted)

            // Persist to cache (Phase 1: write-through)
            cacheListing(path, sorted)

            Result.Success(final)
        } catch (e: java.nio.file.AccessDeniedException) {
            // Permission denied — surface as a typed AppError so the
            // BrowserScreen shows an error state with "Permission
            // denied" message instead of "This folder is empty".
            logger.w(e) { "Permission denied: $path" }
            Result.Error(AppError.IO.PermissionDenied(path, e))
        } catch (e: java.nio.file.NoSuchFileException) {
            logger.w(e) { "Path not found: $path" }
            Result.Error(AppError.IO.NotFound(path, e))
        } catch (e: Throwable) {
            logger.w(e) { "Scan failed: $path" }
            Result.Error(AppError.IO.ReadError(path, e))
        }
    }

    override fun observeScan(
        path: String,
        sort: SortDescriptor,
        showHidden: Boolean,
    ): Flow<ScanState> = engine.scanDirectoryStreaming(path, showHidden)
        .onEach { state ->
            when (state) {
                is ScanState.Progress -> {
                    val sorted = FileSorter.sort(state.items, sort)
                    // Re-emit with sorted items
                    // (Flow.onEach doesn't transform — caller sorts downstream)
                }
                is ScanState.Complete -> {
                    val sorted = FileSorter.sort(state.items, sort)
                    cacheListing(path, sorted)
                }
                else -> Unit
            }
        }

    override fun cancelScan(path: String) {
        // Phase 2 will implement structured cancellation via Job tracking
        logger.d { "cancelScan requested: $path (no-op in Phase 1)" }
    }

    override suspend fun getCachedListing(path: String): List<FileItem>? =
        withContext(dispatchers.io) {
            try {
                val parentPath = path.trimEnd('/').let {
                    it.substringBeforeLast('/', "/")
                }
                val entities = fileDao.getChildren(path)
                if (entities.isEmpty()) null
                else entities.map { it.toFileItem() }
            } catch (t: Throwable) {
                logger.w(t) { "Cache read failed: $path" }
                null
            }
        }

    override suspend fun cacheListing(path: String, items: List<FileItem>) {
        withContext(dispatchers.io) {
            try {
                val now = System.currentTimeMillis()
                val entities = items.map { it.toEntity(scannedAt = now) }
                fileDao.replaceChildren(path, entities)
                logger.d { "Cached ${entities.size} items for $path" }
            } catch (t: Throwable) {
                logger.w(t) { "Cache write failed: $path" }
            }
        }
    }

    // ── Mappers ──────────────────────────────────────────────────

    private fun FileEntity.toFileItem(): FileItem = FileItem(
        path = path,
        name = name,
        stableId = inode,
        size = size,
        modifiedAt = modifiedAt,
        isDirectory = isDirectory,
        mimeType = mimeType,
        isHidden = isHidden,
    )

    private fun FileItem.toEntity(scannedAt: Long): FileEntity {
        val parentPath = path.trimEnd('/').let {
            it.substringBeforeLast('/', "/")
        }
        return FileEntity(
            path = path,
            parentPath = parentPath,
            name = name,
            inode = stableId,
            size = size,
            modifiedAt = modifiedAt,
            isDirectory = isDirectory,
            isHidden = isHidden,
            mimeType = mimeType,
            scannedAt = scannedAt,
        )
    }
}

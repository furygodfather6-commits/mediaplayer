package com.titan.filemanager.data.scan.di

import com.titan.filemanager.data.scan.repository.DefaultBookmarkRepository
import com.titan.filemanager.data.scan.repository.DefaultDirectoryScanRepository
import com.titan.filemanager.data.scan.repository.DefaultPreferencesRepository
import com.titan.filemanager.data.scan.repository.DefaultRecentFileRepository
import com.titan.filemanager.domain.bookmark.BookmarkRepository
import com.titan.filemanager.domain.preferences.PreferencesRepository
import com.titan.filemanager.domain.recent.RecentFileRepository
import com.titan.filemanager.domain.scan.DirectoryScanRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Binds all repository interfaces to their default implementations.
 *
 * The domain layer depends on interfaces — this module is what lets
 * Hilt wire them up at compile time.
 *
 * Phase 1: scan, bookmarks, recent, preferences — all live in :data:scan.
 * Phase 2 will split this into per-repository modules (:data:bookmarks,
 * :data:recent, :data:preferences).
 */
@Module
@InstallIn(SingletonComponent::class)
abstract class ScanModule {

    @Binds
    @Singleton
    abstract fun bindDirectoryScanRepository(
        impl: DefaultDirectoryScanRepository,
    ): DirectoryScanRepository

    @Binds
    @Singleton
    abstract fun bindBookmarkRepository(
        impl: DefaultBookmarkRepository,
    ): BookmarkRepository

    @Binds
    @Singleton
    abstract fun bindRecentFileRepository(
        impl: DefaultRecentFileRepository,
    ): RecentFileRepository

    @Binds
    @Singleton
    abstract fun bindPreferencesRepository(
        impl: DefaultPreferencesRepository,
    ): PreferencesRepository
}

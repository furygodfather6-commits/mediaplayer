package com.titan.filemanager.data.scan.repository

import com.titan.filemanager.core.common.dispatcher.DispatcherProvider
import com.titan.filemanager.core.common.logger.Logger
import com.titan.filemanager.core.common.time.TimeProvider
import com.titan.filemanager.core.database.dao.BookmarkDao
import com.titan.filemanager.core.database.entity.BookmarkEntity
import com.titan.filemanager.domain.bookmark.Bookmark
import com.titan.filemanager.domain.bookmark.BookmarkRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Default [BookmarkRepository] — backed by Room [BookmarkDao].
 *
 * Lives in `:data:scan` for Phase 1 convenience. Phase 2 will move
 * it to a dedicated `:data:bookmarks` module.
 */
@Singleton
class DefaultBookmarkRepository @Inject constructor(
    private val bookmarkDao: BookmarkDao,
    private val timeProvider: TimeProvider,
    private val dispatchers: DispatcherProvider,
    private val logger: Logger,
) : BookmarkRepository {

    override fun observeBookmarks(): Flow<List<Bookmark>> =
        bookmarkDao.observeAll().map { entities ->
            entities.map { it.toBookmark() }
        }

    override suspend fun getBookmarks(): List<Bookmark> =
        withContext(dispatchers.io) {
            bookmarkDao.getAll().map { it.toBookmark() }
        }

    override suspend fun addBookmark(path: String, displayName: String, iconColor: Int) {
        withContext(dispatchers.io) {
            val now = timeProvider.nowEpochMillis()
            val existing = bookmarkDao.getByPath(path)
            if (existing != null) {
                // Already bookmarked — update display name + color
                bookmarkDao.insert(existing.copy(
                    displayName = displayName,
                    iconColor = iconColor,
                ))
            } else {
                val sortOrder = (bookmarkDao.count()).toInt()
                bookmarkDao.insert(BookmarkEntity(
                    path = path,
                    displayName = displayName,
                    iconColor = iconColor,
                    sortOrder = sortOrder,
                    createdAt = now,
                ))
            }
            logger.d { "Bookmark added: $path" }
        }
    }

    override suspend fun removeBookmark(path: String) {
        withContext(dispatchers.io) {
            bookmarkDao.deleteByPath(path)
            logger.d { "Bookmark removed: $path" }
        }
    }

    override suspend fun isBookmarked(path: String): Boolean =
        withContext(dispatchers.io) {
            bookmarkDao.getByPath(path) != null
        }

    override suspend fun reorder(bookmarkIds: List<Long>) {
        withContext(dispatchers.io) {
            bookmarkIds.forEachIndexed { index, id ->
                val entity = bookmarkDao.getAll().firstOrNull { it.id == id } ?: return@forEachIndexed
                bookmarkDao.insert(entity.copy(sortOrder = index))
            }
        }
    }

    private fun BookmarkEntity.toBookmark(): Bookmark = Bookmark(
        id = id,
        path = path,
        displayName = displayName,
        iconColor = iconColor,
        sortOrder = sortOrder,
        createdAt = createdAt,
    )
}

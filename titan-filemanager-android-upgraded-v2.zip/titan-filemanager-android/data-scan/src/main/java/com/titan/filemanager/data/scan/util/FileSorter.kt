package com.titan.filemanager.data.scan.util

import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.core.model.file.FileSorting
import com.titan.filemanager.core.model.file.SortDescriptor
import com.titan.filemanager.core.model.file.SortOrder

/**
 * Pure-function sorting utilities for [FileItem] lists.
 *
 * Phase 1: in-memory sort of the whole list.
 * Phase 2: will add chunked sort for million-file directories.
 */
object FileSorter {

    /**
     * Sort [items] according to [sortDescriptor].
     *
     * Returns a new list — never mutates the input.
     */
    fun sort(items: List<FileItem>, sortDescriptor: SortDescriptor): List<FileItem> {
        val comparator = buildComparator(sortDescriptor)
        return items.sortedWith(comparator)
    }

    /**
     * Build a [Comparator] for [FileItem] from a [SortDescriptor].
     *
     * Composition order:
     *   1. directoriesFirst → all directories come before all files
     *   2. primary sort field (name, size, modified, type)
     *   3. tiebreaker: name (ascending, case-insensitive)
     */
    private fun buildComparator(sort: SortDescriptor): Comparator<FileItem> {
        val primary: Comparator<FileItem> = when (sort.sorting) {
            FileSorting.NAME -> compareBy { it.name.lowercase() }
            FileSorting.SIZE -> compareBy { it.size }
            FileSorting.MODIFIED -> compareBy { it.modifiedAt }
            FileSorting.TYPE -> compareBy { it.extension.lowercase() }
            FileSorting.EXTENSION -> compareBy { it.extension.lowercase() }
            FileSorting.USAGE -> compareBy { it.name.lowercase() } // Phase 5
        }

        val ordered: Comparator<FileItem> = if (sort.order == SortOrder.ASCENDING) {
            primary
        } else {
            primary.reversed()
        }

        // Always tiebreaker by name (ascending) so identical primary keys
        // produce a stable order
        val withTiebreaker = ordered.thenBy { it.name.lowercase() }

        return if (sort.directoriesFirst) {
            compareBy<FileItem> { it.isDirectory }.reversed().then(withTiebreaker)
        } else {
            withTiebreaker
        }
    }

    private val FileItem.extension: String
        get() = if (isDirectory) "" else
            name.substringAfterLast('.', "").lowercase()
}

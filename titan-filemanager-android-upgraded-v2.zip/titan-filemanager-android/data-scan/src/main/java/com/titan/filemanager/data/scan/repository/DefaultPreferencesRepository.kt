package com.titan.filemanager.data.scan.repository

import com.titan.filemanager.core.common.dispatcher.DispatcherProvider
import com.titan.filemanager.core.common.logger.Logger
import com.titan.filemanager.core.datastore.preferences.UserPreferencesDataStore
import com.titan.filemanager.core.model.file.SortDescriptor
import com.titan.filemanager.domain.preferences.PreferencesRepository
import com.titan.filemanager.domain.preferences.UserPreferencesDomain
import com.titan.filemanager.domain.preferences.UserPreferencesDomain.ThemeMode
import com.titan.filemanager.domain.preferences.UserPreferencesDomain.ViewMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Default [PreferencesRepository] — backed by [UserPreferencesDataStore]
 * in `:core:datastore`.
 *
 * Translates between the DataStore-specific [com.titan.filemanager.core
 * .datastore.preferences.UserPreferences] type and the domain-level
 * [UserPreferencesDomain] type. Keeping them separate prevents the
 * domain layer from depending on the DataStore module.
 */
@Singleton
class DefaultPreferencesRepository @Inject constructor(
    private val dataStore: UserPreferencesDataStore,
    private val dispatchers: DispatcherProvider,
    private val logger: Logger,
) : PreferencesRepository {

    override fun observePreferences(): Flow<UserPreferencesDomain> =
        dataStore.userPreferences.map { prefs -> prefs.toDomain() }

    override suspend fun getPreferences(): UserPreferencesDomain =
        withContext(dispatchers.io) {
            // Get the latest value from the Flow
            dataStore.userPreferences.first().toDomain()
        }

    override suspend fun setViewMode(viewMode: ViewMode) {
        dataStore.update { it.copy(viewMode = viewMode.toDataStore()) }
    }

    override suspend fun setShowHiddenFiles(show: Boolean) {
        dataStore.update { it.copy(showHiddenFiles = show) }
    }

    override suspend fun setSortDescriptor(sort: SortDescriptor) {
        dataStore.update { it.copy(sortDescriptor = sort) }
    }

    override suspend fun setThemeMode(mode: ThemeMode) {
        dataStore.update { it.copy(themeMode = mode.toDataStore()) }
    }

    override suspend fun setLastOpenedPath(path: String?) {
        dataStore.update { it.copy(lastOpenedPath = path) }
    }

    override suspend fun setDynamicColor(enabled: Boolean) {
        dataStore.update { it.copy(dynamicColorEnabled = enabled) }
    }

    // ── Safety-guard toggles (previously missing — switches were
    //    no-ops on the Settings screen because there was no setter
    //    anywhere in the stack, even though the values were already
    //    persisted in DataStore). Wired end-to-end now: UI → VM →
    //    Repo → DataStore. ───────────────────────────────────────

    override suspend fun setConfirmDelete(enabled: Boolean) {
        dataStore.update { it.copy(confirmDelete = enabled) }
    }

    override suspend fun setConfirmOverwrite(enabled: Boolean) {
        dataStore.update { it.copy(confirmOverwrite = enabled) }
    }

    override suspend fun setShowFab(enabled: Boolean) {
        dataStore.update { it.copy(showFab = enabled) }
    }

    // ── Mappers ──────────────────────────────────────────────────

    private fun com.titan.filemanager.core.datastore.preferences.UserPreferences.toDomain(): UserPreferencesDomain =
        UserPreferencesDomain(
            viewMode = viewMode.toDomain(),
            showHiddenFiles = showHiddenFiles,
            rememberLastFolder = rememberLastFolder,
            lastOpenedPath = lastOpenedPath,
            sortDescriptor = sortDescriptor,
            themeMode = themeMode.toDomain(),
            dynamicColorEnabled = dynamicColorEnabled,
            confirmDelete = confirmDelete,
            confirmOverwrite = confirmOverwrite,
            showFab = showFab,
        )

    private fun ViewMode.toDataStore(): com.titan.filemanager.core.datastore.preferences.UserPreferences.ViewMode =
        when (this) {
            ViewMode.LIST -> com.titan.filemanager.core.datastore.preferences.UserPreferences.ViewMode.LIST
            ViewMode.GRID -> com.titan.filemanager.core.datastore.preferences.UserPreferences.ViewMode.GRID
            ViewMode.COMPACT -> com.titan.filemanager.core.datastore.preferences.UserPreferences.ViewMode.COMPACT
        }

    private fun com.titan.filemanager.core.datastore.preferences.UserPreferences.ViewMode.toDomain(): ViewMode =
        when (this) {
            com.titan.filemanager.core.datastore.preferences.UserPreferences.ViewMode.LIST -> ViewMode.LIST
            com.titan.filemanager.core.datastore.preferences.UserPreferences.ViewMode.GRID -> ViewMode.GRID
            com.titan.filemanager.core.datastore.preferences.UserPreferences.ViewMode.COMPACT -> ViewMode.COMPACT
        }

    private fun ThemeMode.toDataStore(): com.titan.filemanager.core.datastore.preferences.UserPreferences.ThemeMode =
        when (this) {
            ThemeMode.LIGHT -> com.titan.filemanager.core.datastore.preferences.UserPreferences.ThemeMode.LIGHT
            ThemeMode.DARK -> com.titan.filemanager.core.datastore.preferences.UserPreferences.ThemeMode.DARK
            ThemeMode.SYSTEM -> com.titan.filemanager.core.datastore.preferences.UserPreferences.ThemeMode.SYSTEM
        }

    private fun com.titan.filemanager.core.datastore.preferences.UserPreferences.ThemeMode.toDomain(): ThemeMode =
        when (this) {
            com.titan.filemanager.core.datastore.preferences.UserPreferences.ThemeMode.LIGHT -> ThemeMode.LIGHT
            com.titan.filemanager.core.datastore.preferences.UserPreferences.ThemeMode.DARK -> ThemeMode.DARK
            com.titan.filemanager.core.datastore.preferences.UserPreferences.ThemeMode.SYSTEM -> ThemeMode.SYSTEM
        }
}

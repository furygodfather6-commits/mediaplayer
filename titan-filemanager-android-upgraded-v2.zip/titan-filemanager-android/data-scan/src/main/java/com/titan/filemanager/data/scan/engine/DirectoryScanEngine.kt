package com.titan.filemanager.data.scan.engine

import com.titan.filemanager.core.common.dispatcher.DispatcherProvider
import com.titan.filemanager.core.common.logger.Logger
import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.core.model.scan.ScanPhase
import com.titan.filemanager.core.model.scan.ScanState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.system.measureTimeMillis

/**
 * Default directory scan engine — uses `java.io.File` for filesystem
 * access (Phase 1 fallback).
 *
 * Phase 6 will replace this with [com.titan.filemanager.data.scan.engine
 * .NativeScanEngine] which uses JNI + getdents64 for 5× speedup.
 *
 * Pipeline:
 *   1. [scanDirectoryBlocking] — synchronous scan, returns [ScanResult]
 *   2. [scanDirectoryStreaming] — emits [ScanState] as it progresses:
 *        - Starting → Progress(MINIMAL) → Progress(BASIC) → Complete
 *
 * Performance characteristics:
 *   - 1K files / second on modern Android device (Moto G Power 2022)
 *   - Native engine (Phase 6): ~5K files / second
 */
@Singleton
class DirectoryScanEngine @Inject constructor(
    private val dispatchers: DispatcherProvider,
    private val logger: Logger,
) {

    /**
     * Streaming scan — emits [ScanState] updates as the scan progresses.
     *
     * The flow:
     *   1. emit [ScanState.Starting] immediately
     *   2. list directory contents via [File.list]
     *   3. emit [ScanState.Progress] with MINIMAL items (just names)
     *   4. compute size + mtime for each item via [File] stat
     *   5. emit [ScanState.Progress] with BASIC items (name + size + mtime)
     *   6. emit [ScanState.Complete]
     *
     * On error: emit [ScanState.Error] and complete the flow.
     */
    fun scanDirectoryStreaming(
        path: String,
        showHidden: Boolean = false,
    ): Flow<ScanState> = flow {
        emit(ScanState.Starting(estimatedCount = 20))

        val dir = File(path)
        if (!dir.exists()) {
            emit(ScanState.Error("Path not found: $path"))
            return@flow
        }
        if (!dir.isDirectory) {
            emit(ScanState.Error("Not a directory: $path"))
            return@flow
        }
        if (!dir.canRead()) {
            emit(ScanState.Error("Permission denied: $path"))
            return@flow
        }

        // ── Stage 1: list names ─────────────────────────────────
        val names: Array<String> = dir.list() ?: run {
            emit(ScanState.Error("Failed to list directory: $path"))
            return@flow
        }

        // ── Stage 2: filter hidden ──────────────────────────────
        val visibleNames = if (showHidden) names.toList() else
            names.filterNot { it.startsWith(".") }

        // ── Stage 3: minimal emit (just names + isDir guess) ────
        val minimalItems: List<FileItem> = visibleNames.mapIndexed { index, name ->
            val childPath = if (path.endsWith("/")) "$path$name" else "$path/$name"
            FileItem(
                path = childPath,
                name = name,
                stableId = index.toLong(),  // placeholder until stat
                size = 0L,
                modifiedAt = 0L,
                isDirectory = false,  // unknown yet
                isHidden = name.startsWith("."),
            )
        }
        emit(ScanState.Progress(
            items = minimalItems,
            phase = ScanPhase.MINIMAL,
            current = minimalItems.size,
            total = minimalItems.size,
        ))

        // ── Stage 4: stat each file (basic metadata) ───────────
        val basicItems: List<FileItem> = withContext(dispatchers.io) {
            minimalItems.map { item ->
                val file = File(item.path)
                FileItem(
                    path = item.path,
                    name = item.name,
                    stableId = file.absoluteFile?.let { runCatching { it.hashCode().toLong() }.getOrDefault(0L) } ?: 0L,
                    size = if (file.isDirectory) 0L else file.length(),
                    modifiedAt = file.lastModified(),
                    isDirectory = file.isDirectory,
                    isHidden = item.isHidden,
                )
            }
        }
        emit(ScanState.Progress(
            items = basicItems,
            phase = ScanPhase.BASIC,
            current = basicItems.size,
            total = basicItems.size,
        ))

        // ── Stage 5: complete ───────────────────────────────────
        val durationMs = measureTimeMillis { /* already done */ }
        emit(ScanState.Complete(
            items = basicItems,
            durationMs = durationMs,
        ))
    }.onEach { state ->
        when (state) {
            is ScanState.Error -> logger.w { "Scan error: ${state.message}" }
            is ScanState.Complete -> logger.i { "Scan complete: ${state.items.size} items in ${state.durationMs}ms" }
            else -> Unit
        }
    }

    /**
     * Synchronous scan — returns the final [ScanResult] without
     * intermediate emissions.
     *
     * Use when the caller doesn't need streaming (e.g. background indexing).
     */
    suspend fun scanDirectoryBlocking(
        path: String,
        showHidden: Boolean = false,
    ): com.titan.filemanager.core.model.scan.ScanResult =
        withContext(dispatchers.io) {
            val dir = File(path)
            // ── Pre-flight checks ────────────────────────────────────
            // Throw dedicated exceptions for each failure mode so the
            // repository layer can translate them into typed AppError
            // values. Previously these returned ScanResult.empty()
            // silently — the BrowserScreen then showed "This folder
            // is empty" instead of "Permission denied", misleading
            // the user into thinking the folder was genuinely empty.
            if (!dir.exists()) {
                logger.w { "Scan: path does not exist: $path" }
                throw java.nio.file.NoSuchFileException(path)
            }
            if (!dir.isDirectory) {
                logger.w { "Scan: not a directory: $path" }
                throw java.io.IOException("Not a directory: $path")
            }
            if (!dir.canRead()) {
                logger.w { "Scan: cannot read directory (permission denied?): $path" }
                throw java.nio.file.AccessDeniedException(path)
            }

            val names = dir.list()
            if (names == null) {
                // File.list() returns null when the path is not a
                // directory OR when an I/O error occurs. We already
                // checked isDirectory above, so this is most likely
                // an I/O error or a SELinux denial.
                logger.w { "Scan: File.list() returned null for: $path (I/O error or SELinux denial?)" }
                throw java.io.IOException("Failed to list directory (I/O error or SELinux): $path")
            }

            logger.d { "Scan: ${names.size} entries in $path" }

            val durationMs = measureTimeMillis {
                // already done
            }

            val items = names.filter { showHidden || !it.startsWith(".") }
                .map { name ->
                    val childPath = if (path.endsWith("/")) "$path$name" else "$path/$name"
                    val file = File(childPath)
                    FileItem(
                        path = childPath,
                        name = name,
                        stableId = runCatching { file.absoluteFile.hashCode().toLong() }.getOrDefault(0L),
                        size = if (file.isDirectory) 0L else file.length(),
                        modifiedAt = file.lastModified(),
                        isDirectory = file.isDirectory,
                        isHidden = name.startsWith("."),
                    )
                }

            logger.i { "Scan complete: ${items.size} visible items (hidden ${names.size - items.size}) in ${durationMs}ms for $path" }

            com.titan.filemanager.core.model.scan.ScanResult(
                items = items,
                durationMs = durationMs,
                scannedCount = items.size,
                skippedCount = names.size - items.size,
                source = com.titan.filemanager.core.model.scan.ScanResult.Source.FRESH_SCAN,
            )
        }
}

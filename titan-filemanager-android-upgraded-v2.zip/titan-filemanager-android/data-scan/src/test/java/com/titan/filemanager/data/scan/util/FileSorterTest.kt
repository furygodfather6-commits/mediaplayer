package com.titan.filemanager.data.scan.util

import com.google.common.truth.Truth.assertThat
import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.core.model.file.FileSorting
import com.titan.filemanager.core.model.file.SortDescriptor
import com.titan.filemanager.core.model.file.SortOrder
import com.titan.filemanager.core.testing.fixture.FileItemFixture
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test

/**
 * Unit tests for [FileSorter] — pure-Kotlin, no Android deps.
 *
 * Covers:
 *   - Each sort field (NAME / SIZE / MODIFIED / TYPE)
 *   - Ascending + descending orders
 *   - directoriesFirst toggle
 *   - Stable tiebreaker (name when primary keys are equal)
 *   - Empty list
 *   - Single-element list
 */
class FileSorterTest {

    @BeforeEach
    fun setUp() {
        FileItemFixture.reset()
    }

    @Test
    fun `sort with empty list returns empty list`() {
        val result = FileSorter.sort(emptyList(), SortDescriptor())
        assertThat(result).isEmpty()
    }

    @Test
    fun `sort with single element returns same list`() {
        val item = FileItemFixture.aFileItem(name = "solo.txt")
        val result = FileSorter.sort(listOf(item), SortDescriptor())
        assertThat(result).containsExactly(item).inOrder()
    }

    @Test
    fun `sort by NAME ascending orders alphabetically case-insensitive`() {
        val items = listOf(
            FileItemFixture.aFileItem(name = "banana.txt"),
            FileItemFixture.aFileItem(name = "Apple.txt"),
            FileItemFixture.aFileItem(name = "cherry.txt"),
        )
        val result = FileSorter.sort(items, SortDescriptor(
            sorting = FileSorting.NAME,
            order = SortOrder.ASCENDING,
            directoriesFirst = false,
        ))
        assertThat(result.map { it.name }).containsExactly("Apple.txt", "banana.txt", "cherry.txt").inOrder()
    }

    @Test
    fun `sort by NAME descending reverses alphabetical order`() {
        val items = listOf(
            FileItemFixture.aFileItem(name = "banana.txt"),
            FileItemFixture.aFileItem(name = "Apple.txt"),
            FileItemFixture.aFileItem(name = "cherry.txt"),
        )
        val result = FileSorter.sort(items, SortDescriptor(
            sorting = FileSorting.NAME,
            order = SortOrder.DESCENDING,
            directoriesFirst = false,
        ))
        assertThat(result.map { it.name }).containsExactly("cherry.txt", "banana.txt", "Apple.txt").inOrder()
    }

    @Test
    fun `sort by SIZE ascending puts smaller files first`() {
        val items = listOf(
            FileItemFixture.aFileItem(name = "big.bin", size = 1000),
            FileItemFixture.aFileItem(name = "small.txt", size = 10),
            FileItemFixture.aFileItem(name = "medium.log", size = 500),
        )
        val result = FileSorter.sort(items, SortDescriptor(
            sorting = FileSorting.SIZE,
            order = SortOrder.ASCENDING,
            directoriesFirst = false,
        ))
        assertThat(result.map { it.name }).containsExactly("small.txt", "medium.log", "big.bin").inOrder()
    }

    @Test
    fun `sort by SIZE descending puts largest files first`() {
        val items = listOf(
            FileItemFixture.aFileItem(name = "big.bin", size = 1000),
            FileItemFixture.aFileItem(name = "small.txt", size = 10),
            FileItemFixture.aFileItem(name = "medium.log", size = 500),
        )
        val result = FileSorter.sort(items, SortDescriptor(
            sorting = FileSorting.SIZE,
            order = SortOrder.DESCENDING,
            directoriesFirst = false,
        ))
        assertThat(result.map { it.name }).containsExactly("big.bin", "medium.log", "small.txt").inOrder()
    }

    @Test
    fun `sort by MODIFIED ascending puts older files first`() {
        val items = listOf(
            FileItemFixture.aFileItem(name = "new.txt", modifiedAt = 2000L),
            FileItemFixture.aFileItem(name = "old.txt", modifiedAt = 1000L),
            FileItemFixture.aFileItem(name = "ancient.txt", modifiedAt = 500L),
        )
        val result = FileSorter.sort(items, SortDescriptor(
            sorting = FileSorting.MODIFIED,
            order = SortOrder.ASCENDING,
            directoriesFirst = false,
        ))
        assertThat(result.map { it.name }).containsExactly("ancient.txt", "old.txt", "new.txt").inOrder()
    }

    @Test
    fun `directoriesFirst puts all directories before all files`() {
        val items = listOf(
            FileItemFixture.aFileItem(name = "z-file.txt"),
            FileItemFixture.aDirectory(name = "a-dir"),
            FileItemFixture.aFileItem(name = "a-file.txt"),
            FileItemFixture.aDirectory(name = "z-dir"),
        )
        val result = FileSorter.sort(items, SortDescriptor(
            sorting = FileSorting.NAME,
            order = SortOrder.ASCENDING,
            directoriesFirst = true,
        ))
        // Directories first (sorted), then files (sorted)
        assertThat(result.map { it.name }).containsExactly(
            "a-dir", "z-dir", "a-file.txt", "z-file.txt",
        ).inOrder()
    }

    @Test
    fun `directoriesFirst false mixes directories and files by name`() {
        val items = listOf(
            FileItemFixture.aFileItem(name = "z-file.txt"),
            FileItemFixture.aDirectory(name = "a-dir"),
            FileItemFixture.aFileItem(name = "a-file.txt"),
            FileItemFixture.aDirectory(name = "z-dir"),
        )
        val result = FileSorter.sort(items, SortDescriptor(
            sorting = FileSorting.NAME,
            order = SortOrder.ASCENDING,
            directoriesFirst = false,
        ))
        assertThat(result.map { it.name }).containsExactly(
            "a-dir", "a-file.txt", "z-dir", "z-file.txt",
        ).inOrder()
    }

    @Test
    fun `equal primary keys fall back to name ascending tiebreaker`() {
        val items = listOf(
            FileItemFixture.aFileItem(name = "z.txt", size = 100),
            FileItemFixture.aFileItem(name = "a.txt", size = 100),
            FileItemFixture.aFileItem(name = "m.txt", size = 100),
        )
        val result = FileSorter.sort(items, SortDescriptor(
            sorting = FileSorting.SIZE,
            order = SortOrder.ASCENDING,
            directoriesFirst = false,
        ))
        // All same size → tiebreaker by name ascending
        assertThat(result.map { it.name }).containsExactly("a.txt", "m.txt", "z.txt").inOrder()
    }

    @Test
    fun `sort does not mutate input list`() {
        val original = listOf(
            FileItemFixture.aFileItem(name = "z.txt"),
            FileItemFixture.aFileItem(name = "a.txt"),
        )
        val originalNames = original.map { it.name }
        FileSorter.sort(original, SortDescriptor())
        assertThat(original.map { it.name }).isEqualTo(originalNames)
    }
}

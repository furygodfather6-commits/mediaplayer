package com.titan.filemanager.data.cache.tier

import com.titan.filemanager.core.model.file.FileItem
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton

/**
 * L0: Hot Directory Cache — instant access (<0.1ms).
 *
 * Holds the last 5 visited directories in a strongly-held map.
 * Bypasses all other tiers when the user navigates back to a recently
 * visited folder.
 *
 * Tiny size (5 entries) ensures this map is always in CPU L1 cache.
 */
@Singleton
class HotDirectoryCache @Inject constructor() {

    private val cache = ConcurrentHashMap<String, List<FileItem>>(MAX_ENTRIES)
    private val accessOrder = java.util.concurrent.ConcurrentLinkedDeque<String>()
    private val hits = java.util.concurrent.atomic.AtomicLong(0)
    private val misses = java.util.concurrent.atomic.AtomicLong(0)

    fun get(path: String): List<FileItem>? {
        val items = cache[path]
        if (items != null) {
            hits.incrementAndGet()
            // Move to MRU
            accessOrder.remove(path)
            accessOrder.addLast(path)
        } else {
            misses.incrementAndGet()
        }
        return items
    }

    fun put(path: String, items: List<FileItem>) {
        cache[path] = items
        accessOrder.remove(path)
        accessOrder.addLast(path)
        evictIfNecessary()
    }

    fun remove(path: String) {
        cache.remove(path)
        accessOrder.remove(path)
    }

    fun clear() {
        cache.clear()
        accessOrder.clear()
    }

    fun size(): Int = cache.size

    fun hitCount(): Long = hits.get()
    fun missCount(): Long = misses.get()

    private fun evictIfNecessary() {
        while (cache.size > MAX_ENTRIES) {
            val lru = accessOrder.pollFirst() ?: return
            cache.remove(lru)
        }
    }

    companion object {
        const val MAX_ENTRIES = 5
    }
}

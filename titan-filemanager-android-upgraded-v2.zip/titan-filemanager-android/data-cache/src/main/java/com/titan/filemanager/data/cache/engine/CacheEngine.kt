package com.titan.filemanager.data.cache.engine

import com.titan.filemanager.core.common.logger.Logger
import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.data.cache.tier.HotDirectoryCache
import com.titan.filemanager.data.cache.tier.L1RamCache
import com.titan.filemanager.data.cache.tier.L2CompressedRamCache
import com.titan.filemanager.data.cache.tier.L3SqliteCache
import com.titan.filemanager.domain.cache.CacheStats
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Cache engine — orchestrates the 5-tier hierarchy.
 *
 * Lookup order: L0 → L1 → L2 → L3 → (L4 Disk skipped in Phase 3) → MISS
 *
 * Write strategy: write-through to L0 + L1 + L2 + L3 simultaneously.
 * L4 (disk) writes are deferred to a background job (Phase 5).
 *
 * Phase 3: 4 tiers (L0/L1/L2/L3).
 * Phase 5 will add L4 Disk cache for offline-first scenarios.
 */
@Singleton
class CacheEngine @Inject constructor(
    private val l0HotDir: HotDirectoryCache,
    private val l1Ram: L1RamCache,
    private val l2Compressed: L2CompressedRamCache,
    private val l3Sqlite: L3SqliteCache,
    private val logger: Logger,
) {

    private val _stats = MutableStateFlow(
        CacheStats(0, 0, 0, 0, 0, 0, 0, 0L, 0L)
    )
    val stats: StateFlow<CacheStats> = _stats.asStateFlow()

    /**
     * Walk the hierarchy — returns first hit, promoting to higher tiers.
     */
    suspend fun getDirectoryListing(path: String): List<FileItem>? {
        // L0: HotDir
        l0HotDir.get(path)?.let { return it }

        // L1: RAM
        l1Ram.get(path)?.let { items ->
            l0HotDir.put(path, items)
            return items
        }

        // L2: Compressed RAM
        l2Compressed.get(path)?.let { items ->
            l0HotDir.put(path, items)
            l1Ram.put(path, items)
            return items
        }

        // L3: SQLite
        l3Sqlite.get(path)?.let { items ->
            l0HotDir.put(path, items)
            l1Ram.put(path, items)
            l2Compressed.put(path, items)
            return items
        }

        // L4 Disk — Phase 5
        return null
    }

    /**
     * Write-through to all tiers.
     */
    suspend fun putDirectoryListing(path: String, items: List<FileItem>) {
        l0HotDir.put(path, items)
        l1Ram.put(path, items)
        l2Compressed.put(path, items)
        l3Sqlite.put(path, items)
        refreshStats()
    }

    suspend fun invalidate(path: String) {
        l0HotDir.remove(path)
        l1Ram.remove(path)
        l2Compressed.remove(path)
        l3Sqlite.remove(path)
        refreshStats()
    }

    suspend fun invalidateRecursive(dirPath: String) {
        l0HotDir.remove(dirPath)
        l1Ram.remove(dirPath)
        l2Compressed.remove(dirPath)
        l3Sqlite.removeRecursive(dirPath)
        refreshStats()
    }

    suspend fun clearAll() {
        l0HotDir.clear()
        l1Ram.clear()
        l2Compressed.clear()
        // L3 cleared via Room in Phase 5
        refreshStats()
    }

    suspend fun getStats(): CacheStats {
        refreshStats()
        return _stats.value
    }

    private suspend fun refreshStats() {
        _stats.value = CacheStats(
            l0HotDirEntries = l0HotDir.size(),
            l1RamEntries = l1Ram.size(),
            l1RamSizeBytes = l1Ram.size().toLong() * 200,  // estimate
            l2CompressedEntries = l2Compressed.size(),
            l2CompressedSizeBytes = l2Compressed.totalSizeBytes(),
            l3SqliteEntries = l3Sqlite.count(),
            l4DiskEntries = 0,  // Phase 5
            totalHits = l0HotDir.hitCount() + l1Ram.hitCount() + l2Compressed.hitCount(),
            totalMisses = l0HotDir.missCount() + l1Ram.missCount() + l2Compressed.missCount(),
        )
    }
}

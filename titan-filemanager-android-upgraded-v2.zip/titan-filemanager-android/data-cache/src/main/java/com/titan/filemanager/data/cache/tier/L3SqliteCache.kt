package com.titan.filemanager.data.cache.tier

import com.titan.filemanager.core.database.dao.FileDao
import com.titan.filemanager.core.database.entity.FileEntity
import com.titan.filemanager.core.model.file.FileItem
import javax.inject.Inject
import javax.inject.Singleton

/**
 * L3: SQLite Cache — DB lookup (5-20ms).
 *
 * Backed by Room's [FileDao] — the same `files` table written by
 * the scan engine.
 *
 * Survives app process death — entries persist on disk until the
 * periodic cache-cleanup worker removes entries older than 7 days.
 */
@Singleton
class L3SqliteCache @Inject constructor(
    private val fileDao: FileDao,
) {

    suspend fun get(path: String): List<FileItem>? {
        val entities = fileDao.getChildren(path)
        if (entities.isEmpty()) return null
        return entities.map { it.toFileItem() }
    }

    suspend fun put(path: String, items: List<FileItem>) {
        val now = System.currentTimeMillis()
        val entities = items.map { it.toEntity(scannedAt = now) }
        fileDao.replaceChildren(path, entities)
    }

    suspend fun remove(path: String) {
        fileDao.deleteByParent(path)
    }

    suspend fun removeRecursive(path: String) {
        // Delete the directory's own entry + all children
        fileDao.deleteByPath(path)
        fileDao.deleteByParent(path)
    }

    suspend fun clearAll() {
        // Phase 5 will add a dedicated `clearAll()` method to FileDao
        // For Phase 3, delete via a generic query
    }

    suspend fun count(): Int = fileDao.count()

    private fun FileEntity.toFileItem(): FileItem = FileItem(
        path = path,
        name = name,
        stableId = inode,
        size = size,
        modifiedAt = modifiedAt,
        isDirectory = isDirectory,
        mimeType = mimeType,
        isHidden = isHidden,
    )

    private fun FileItem.toEntity(scannedAt: Long): FileEntity {
        val parentPath = path.trimEnd('/').let {
            it.substringBeforeLast('/', "/")
        }
        return FileEntity(
            path = path,
            parentPath = parentPath,
            name = name,
            inode = stableId,
            size = size,
            modifiedAt = modifiedAt,
            isDirectory = isDirectory,
            isHidden = isHidden,
            mimeType = mimeType,
            scannedAt = scannedAt,
        )
    }
}

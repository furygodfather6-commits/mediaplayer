package com.titan.filemanager.data.cache.tier

import com.titan.filemanager.core.model.file.FileItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedDeque
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream
import javax.inject.Inject
import javax.inject.Singleton

/**
 * L2: Compressed RAM Cache — decompress (1-3ms).
 *
 * Stores GZIP-compressed JSON of directory listings.
 * Compression ratio: ~5-10× for text-heavy metadata (paths, names).
 *
 * Trade-off: ~1-2ms decompression overhead, but 5-10× more items fit
 * in the same RAM budget.
 */
@Singleton
class L2CompressedRamCache @Inject constructor() {

    private val cache = ConcurrentHashMap<String, ByteArray>(MAX_ENTRIES)
    private val accessOrder = ConcurrentLinkedDeque<String>()
    private val hits = java.util.concurrent.atomic.AtomicLong(0)
    private val misses = java.util.concurrent.atomic.AtomicLong(0)

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = false
    }

    suspend fun get(path: String): List<FileItem>? = withContext(Dispatchers.Default) {
        val compressed = cache[path]
        if (compressed != null) {
            hits.incrementAndGet()
            // Move to MRU
            accessOrder.remove(path)
            accessOrder.addLast(path)
            try {
                decompress(compressed)
            } catch (e: Exception) {
                null
            }
        } else {
            misses.incrementAndGet()
            null
        }
    }

    suspend fun put(path: String, items: List<FileItem>) = withContext(Dispatchers.Default) {
        try {
            val compressed = compress(items)
            cache[path] = compressed
            accessOrder.remove(path)
            accessOrder.addLast(path)
            evictIfNecessary()
        } catch (e: Exception) {
            // Silently drop on compression failure
        }
    }

    fun remove(path: String) {
        cache.remove(path)
        accessOrder.remove(path)
    }

    fun clear() {
        cache.clear()
        accessOrder.clear()
    }

    fun size(): Int = cache.size

    fun totalSizeBytes(): Long = cache.values.sumOf { it.size.toLong() }

    fun hitCount(): Long = hits.get()
    fun missCount(): Long = misses.get()

    private fun compress(items: List<FileItem>): ByteArray {
        val jsonStr = json.encodeToString(
            kotlinx.serialization.builtins.ListSerializer(SerializableFileItem.serializer()),
            items.map { it.toSerializable() },
        )
        val rawBytes = jsonStr.toByteArray(Charsets.UTF_8)
        val bos = ByteArrayOutputStream(rawBytes.size / 4)
        GZIPOutputStream(bos).use { it.write(rawBytes) }
        return bos.toByteArray()
    }

    private fun decompress(compressed: ByteArray): List<FileItem> {
        val rawBytes = GZIPInputStream(ByteArrayInputStream(compressed)).use { it.readBytes() }
        val jsonStr = String(rawBytes, Charsets.UTF_8)
        val serializable = json.decodeFromString(
            kotlinx.serialization.builtins.ListSerializer(SerializableFileItem.serializer()),
            jsonStr,
        )
        return serializable.map { it.toFileItem() }
    }

    private fun evictIfNecessary() {
        while (cache.size > MAX_ENTRIES) {
            val lru = accessOrder.pollFirst() ?: return
            cache.remove(lru)
        }
    }

    @Serializable
    private data class SerializableFileItem(
        val path: String,
        val name: String,
        val stableId: Long,
        val size: Long,
        val modifiedAt: Long,
        val isDirectory: Boolean,
        val mimeType: String? = null,
        val isHidden: Boolean = false,
    )

    private fun FileItem.toSerializable() = SerializableFileItem(
        path, name, stableId, size, modifiedAt, isDirectory, mimeType, isHidden,
    )

    private fun SerializableFileItem.toFileItem() = FileItem(
        path = path,
        name = name,
        stableId = stableId,
        size = size,
        modifiedAt = modifiedAt,
        isDirectory = isDirectory,
        mimeType = mimeType,
        isHidden = isHidden,
    )

    companion object {
        const val MAX_ENTRIES = 200
    }
}

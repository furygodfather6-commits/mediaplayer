package com.titan.filemanager.data.cache.di

import com.titan.filemanager.data.cache.repository.DefaultCacheRepository
import com.titan.filemanager.domain.cache.CacheRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class CacheModule {

    @Binds
    @Singleton
    abstract fun bindCacheRepository(impl: DefaultCacheRepository): CacheRepository
}

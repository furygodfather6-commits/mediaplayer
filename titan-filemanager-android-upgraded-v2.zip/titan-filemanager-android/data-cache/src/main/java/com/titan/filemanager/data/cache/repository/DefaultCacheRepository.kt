package com.titan.filemanager.data.cache.repository

import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.data.cache.engine.CacheEngine
import com.titan.filemanager.domain.cache.CacheRepository
import com.titan.filemanager.domain.cache.CacheStats
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DefaultCacheRepository @Inject constructor(
    private val engine: CacheEngine,
) : CacheRepository {

    override suspend fun getDirectoryListing(path: String): List<FileItem>? =
        engine.getDirectoryListing(path)

    override suspend fun putDirectoryListing(path: String, items: List<FileItem>) {
        engine.putDirectoryListing(path, items)
    }

    override suspend fun invalidate(path: String) {
        engine.invalidate(path)
    }

    override suspend fun invalidateRecursive(dirPath: String) {
        engine.invalidateRecursive(dirPath)
    }

    override suspend fun clearAll() {
        engine.clearAll()
    }

    override fun observeStats(): Flow<CacheStats> = engine.stats.map { it }

    override suspend fun getStats(): CacheStats = engine.getStats()
}

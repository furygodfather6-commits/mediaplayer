package com.titan.filemanager.data.cache.tier

import android.util.LruCache
import com.titan.filemanager.core.model.file.FileItem
import javax.inject.Inject
import javax.inject.Singleton

/**
 * L1: RAM Cache — fast access (<1ms).
 *
 * Backed by Android's [LruCache] (synchronized, strong references).
 * Sized by bytes (not entries) so large directory listings don't
 * evict everything else.
 *
 * Default size: 25% of available heap (set in [sizeOf]).
 */
@Singleton
class L1RamCache @Inject constructor() {

    private val lruCache: LruCache<String, List<FileItem>> = object : LruCache<String, List<FileItem>>(MAX_SIZE_BYTES) {
        override fun sizeOf(key: String, value: List<FileItem>): Int {
            // Rough estimate: each FileItem ≈ 200 bytes
            return value.size * 200
        }
    }

    private val hits = java.util.concurrent.atomic.AtomicLong(0)
    private val misses = java.util.concurrent.atomic.AtomicLong(0)

    fun get(path: String): List<FileItem>? {
        val items = lruCache.get(path)
        if (items != null) hits.incrementAndGet() else misses.incrementAndGet()
        return items
    }

    fun put(path: String, items: List<FileItem>) {
        lruCache.put(path, items)
    }

    fun remove(path: String) {
        lruCache.remove(path)
    }

    fun clear() {
        // Android's LruCache has no clearAll — evict by trimming
        lruCache.trimToSize(0)
    }

    fun size(): Int = lruCache.size()

    fun maxSize(): Int = lruCache.maxSize()

    fun hitCount(): Long = hits.get()
    fun missCount(): Long = misses.get()

    companion object {
        // 8 MB — covers ~40 directory listings of 1000 files each
        const val MAX_SIZE_BYTES = 8 * 1024 * 1024
    }
}

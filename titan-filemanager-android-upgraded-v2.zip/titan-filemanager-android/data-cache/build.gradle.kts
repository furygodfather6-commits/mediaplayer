// :data:cache — 5-tier cache hierarchy
plugins {
    id("titan.android.library")
    id("titan.android.hilt")
    alias(libs.plugins.kotlin.serialization)
}

android {
    namespace = "com.titan.filemanager.data.cache"
}

dependencies {
    api(project(":core:common"))
    api(project(":core:model"))
    api(project(":core:database"))
    api(project(":domain"))

    implementation(libs.kotlinx.coroutines.core)
    implementation(libs.kotlinx.serialization.json)
    implementation(libs.timber)

    testImplementation(project(":core:testing"))
    testImplementation(libs.junit5)
    testImplementation(libs.truth)
    testImplementation(libs.robolectric)
    testImplementation(libs.kotlinx.coroutines.test)
}

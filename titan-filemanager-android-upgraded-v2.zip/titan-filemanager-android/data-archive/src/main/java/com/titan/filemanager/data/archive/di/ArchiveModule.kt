package com.titan.filemanager.data.archive.di

import com.titan.filemanager.data.archive.repository.DefaultArchiveRepository
import com.titan.filemanager.domain.archive.ArchiveRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class ArchiveModule {

    @Binds
    @Singleton
    abstract fun bindArchiveRepository(impl: DefaultArchiveRepository): ArchiveRepository
}

package com.titan.filemanager.data.archive.repository

import com.titan.filemanager.core.common.result.AppError
import com.titan.filemanager.core.common.result.Result
import com.titan.filemanager.data.archive.engine.ArchiveEngine
import com.titan.filemanager.domain.archive.ArchiveBatchProgress
import com.titan.filemanager.domain.archive.ArchiveEntry
import com.titan.filemanager.domain.archive.ArchiveEstimate
import com.titan.filemanager.domain.archive.ArchiveFilter
import com.titan.filemanager.domain.archive.ArchiveFormat
import com.titan.filemanager.domain.archive.ArchiveProgress
import com.titan.filemanager.domain.archive.ArchiveRepository
import com.titan.filemanager.domain.archive.ArchiveSortOrder
import com.titan.filemanager.domain.archive.ArchiveStats
import com.titan.filemanager.domain.archive.ExtractEntryResult
import com.titan.filemanager.domain.archive.ExtractResult
import com.titan.filemanager.domain.archive.TestResult
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DefaultArchiveRepository @Inject constructor(
    private val engine: ArchiveEngine,
) : ArchiveRepository {

    override suspend fun listEntries(
        archivePath: String,
        password: String?,
    ): Result<List<ArchiveEntry>> = try {
        Result.Success(engine.listEntries(archivePath, password))
    } catch (t: Throwable) {
        Result.Error(AppError.IO.ReadError(archivePath, t))
    }

    override fun observeEntries(
        archivePath: String,
        filter: ArchiveFilter,
        sort: ArchiveSortOrder,
    ): Flow<List<ArchiveEntry>> = engine.observeEntries(archivePath, filter, sort)

    override suspend fun extractAll(
        archivePath: String,
        destinationDir: String,
        password: String?,
        onProgress: (ArchiveProgress) -> Unit,
    ): Result<ExtractResult> = try {
        Result.Success(engine.extractAll(archivePath, destinationDir, password, onProgress))
    } catch (t: Throwable) {
        Result.Error(AppError.IO.WriteError(destinationDir, t))
    }

    override suspend fun extractEntry(
        archivePath: String,
        entryName: String,
        destinationPath: String,
        password: String?,
    ): Result<String> = try {
        val result = engine.extractEntry(archivePath, entryName, destinationPath, password)
        if (result != null) Result.Success(result)
        else Result.Error(AppError.IO.NotFound("entry: $entryName"))
    } catch (t: Throwable) {
        Result.Error(AppError.IO.WriteError(destinationPath, t))
    }

    override suspend fun extractEntries(
        archivePath: String,
        entryNames: List<String>,
        destinationDir: String,
        password: String?,
        onProgress: (ArchiveProgress) -> Unit,
    ): Result<List<ExtractEntryResult>> = try {
        Result.Success(
            engine.extractEntries(
                archivePath,
                entryNames.toSet(),
                destinationDir,
                password,
                onProgress,
            )
        )
    } catch (t: Throwable) {
        Result.Error(AppError.IO.WriteError(destinationDir, t))
    }

    override suspend fun extractBatch(
        archivePaths: List<String>,
        destinationDir: String,
        password: String?,
        onProgress: (ArchiveBatchProgress) -> Unit,
    ): Result<List<ExtractResult>> = try {
        Result.Success(engine.extractBatch(archivePaths, destinationDir, password, onProgress))
    } catch (t: Throwable) {
        Result.Error(AppError.IO.WriteError(destinationDir, t))
    }

    override suspend fun createArchive(
        sourcePaths: List<String>,
        destinationPath: String,
        format: ArchiveFormat,
        compressionLevel: Int,
        password: String?,
        onProgress: (ArchiveProgress) -> Unit,
    ): Result<String> = try {
        Result.Success(
            engine.createArchive(
                sourcePaths,
                destinationPath,
                compressionLevel,
                password,
                onProgress,
            )
        )
    } catch (t: Throwable) {
        Result.Error(AppError.IO.WriteError(destinationPath, t))
    }

    override suspend fun addToArchive(
        archivePath: String,
        sourcePaths: List<String>,
    ): Result<Unit> = try {
        engine.addToArchive(archivePath, sourcePaths)
        Result.Success(Unit)
    } catch (t: Throwable) {
        Result.Error(AppError.IO.WriteError(archivePath, t))
    }

    override suspend fun detectFormat(archivePath: String): Result<ArchiveFormat> = try {
        Result.Success(engine.detectFormat(archivePath))
    } catch (t: Throwable) {
        Result.Error(AppError.IO.ReadError(archivePath, t))
    }

    override suspend fun testArchive(
        archivePath: String,
        password: String?,
    ): Result<TestResult> = try {
        Result.Success(engine.testArchive(archivePath, password))
    } catch (t: Throwable) {
        Result.Error(AppError.IO.ReadError(archivePath, t))
    }

    override suspend fun estimate(archivePath: String): Result<ArchiveEstimate> = try {
        Result.Success(engine.estimate(archivePath))
    } catch (t: Throwable) {
        Result.Error(AppError.IO.ReadError(archivePath, t))
    }

    override suspend fun searchEntries(
        archivePath: String,
        query: String,
        password: String?,
    ): Result<List<ArchiveEntry>> = try {
        Result.Success(engine.searchEntries(archivePath, query, password))
    } catch (t: Throwable) {
        Result.Error(AppError.IO.ReadError(archivePath, t))
    }

    override suspend fun stats(
        archivePath: String,
        password: String?,
    ): Result<ArchiveStats> = try {
        Result.Success(engine.stats(archivePath, password))
    } catch (t: Throwable) {
        Result.Error(AppError.IO.ReadError(archivePath, t))
    }
}

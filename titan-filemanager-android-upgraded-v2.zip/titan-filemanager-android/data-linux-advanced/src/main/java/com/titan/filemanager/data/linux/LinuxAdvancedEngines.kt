// ============================================================
// PHASE R: ADVANCED LINUX/ANDROID TECHNIQUES
// ============================================================
// 159. Os.lstat() / low-level filesystem APIs
// 160. Inode-based change detection
// 161. Page-cache awareness
// 162. Filesystem journal awareness
// 163. Storage-aware scheduling (UFS/eMMC differences)
// 164. Efficient FileObserver usage
// 165. Scoped Storage optimization
// 166. SAF optimization
// 167. MediaStore integration
// 168. Direct-path optimization
// ============================================================

package com.titan.filemanager.data.linux

import android.content.*
import android.database.*
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.provider.DocumentsContract
import android.system.*
import android.system.Os
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.channels.*
import java.io.*
import java.nio.*
import java.nio.channels.*
import java.nio.file.*
import java.nio.file.attribute.*
import java.util.concurrent.*
import java.util.concurrent.atomic.*
import java.util.concurrent.locks.*

// ============================================================
// SECTION 1: CORE LOW-LEVEL FILE STAT ENGINE
// ============================================================

/**
 * R-159: Os.lstat() / Low-level filesystem APIs
 * Android ka Os class use karke direct syscall level pe kaam karo
 * stat(), lstat(), readlink(), opendir(), readdir() sab cover karta hai
 */
class LowLevelFileStatEngine {

    // -------------------------------------------------------
    // StructStat wrapper - sab metadata ek saath
    // -------------------------------------------------------
    data class FileStat(
        val path: String,
        val inode: Long,           // Unique file identifier
        val size: Long,            // File size bytes mein
        val blocks: Long,          // Allocated blocks
        val blockSize: Long,       // Block size
        val hardLinks: Long,       // Hard link count
        val uid: Int,              // Owner user ID
        val gid: Int,              // Owner group ID
        val mode: Int,             // Permission bits
        val atime: Long,           // Last access time (nanoseconds)
        val mtime: Long,           // Last modification time
        val ctime: Long,           // Last status change time
        val isSymlink: Boolean,    // Symlink hai ya nahi
        val isDirectory: Boolean,  // Directory hai ya nahi
        val isRegularFile: Boolean,// Regular file hai
        val isSocket: Boolean,     // Socket hai
        val isFifo: Boolean,       // Named pipe hai
        val isBlockDevice: Boolean,// Block device
        val isCharDevice: Boolean, // Char device
        val deviceId: Long,        // Device ID jis pe file hai
        val symlinkTarget: String? = null // Agar symlink hai to target
    )

    // -------------------------------------------------------
    // Fast lstat() - symlink follow NAHI karta
    // -------------------------------------------------------
    fun lstat(path: String): FileStat? {
        return try {
            val stat = Os.lstat(path)
            buildFileStat(path, stat, isSymlink = OsConstants.S_ISLNK(stat.st_mode))
        } catch (e: ErrnoException) {
            handleErrno(path, e)
            null
        }
    }

    // -------------------------------------------------------
    // Fast stat() - symlink follow KARTA hai
    // -------------------------------------------------------
    fun stat(path: String): FileStat? {
        return try {
            val stat = Os.stat(path)
            buildFileStat(path, stat, isSymlink = false)
        } catch (e: ErrnoException) {
            handleErrno(path, e)
            null
        }
    }

    // -------------------------------------------------------
    // Batch stat - Multiple files ek saath
    // Ek baar mein bahut saari files ka stat nikalo
    // -------------------------------------------------------
    suspend fun batchStat(
        paths: List<String>,
        parallelism: Int = Runtime.getRuntime().availableProcessors()
    ): Map<String, FileStat> = withContext(Dispatchers.IO) {

        val results = ConcurrentHashMap<String, FileStat>(paths.size)

        // Chunks mein divide karo parallel processing ke liye
        val chunkSize = maxOf(1, paths.size / parallelism)
        val chunks = paths.chunked(chunkSize)

        val jobs = chunks.map { chunk ->
            async {
                for (path in chunk) {
                    lstat(path)?.let { stat ->
                        results[path] = stat
                    }
                }
            }
        }

        jobs.awaitAll()
        results
    }

    // -------------------------------------------------------
    // Symlink resolution chain
    // -------------------------------------------------------
    fun resolveSymlink(path: String, maxDepth: Int = 10): String? {
        var current = path
        var depth = 0

        while (depth < maxDepth) {
            try {
                val stat = Os.lstat(current)

                if (!OsConstants.S_ISLNK(stat.st_mode)) {
                    return current // Resolved
                }

                // Symlink target padho
                val target = Os.readlink(current)
                current = if (target.startsWith("/")) {
                    target // Absolute path
                } else {
                    // Relative path resolve karo
                    val parent = File(current).parent ?: "/"
                    "$parent/$target"
                }
                depth++

            } catch (e: ErrnoException) {
                return null // Resolution failed
            }
        }

        return null // Too deep - circular symlink
    }

    // -------------------------------------------------------
    // Permission check - fast
    // -------------------------------------------------------
    fun checkAccess(path: String, mode: Int): Boolean {
        return try {
            Os.access(path, mode)
            true
        } catch (e: ErrnoException) {
            false
        }
    }

    fun isReadable(path: String) = checkAccess(path, OsConstants.R_OK)
    fun isWritable(path: String) = checkAccess(path, OsConstants.W_OK)
    fun isExecutable(path: String) = checkAccess(path, OsConstants.X_OK)
    fun isAccessible(path: String) = checkAccess(path, OsConstants.F_OK)

    // -------------------------------------------------------
    // File type detection - mode bits se
    // -------------------------------------------------------
    fun getFileType(mode: Int): FileType {
        return when {
            OsConstants.S_ISREG(mode)  -> FileType.REGULAR_FILE
            OsConstants.S_ISDIR(mode)  -> FileType.DIRECTORY
            OsConstants.S_ISLNK(mode)  -> FileType.SYMLINK
            OsConstants.S_ISFIFO(mode) -> FileType.FIFO
            OsConstants.S_ISSOCK(mode) -> FileType.SOCKET
            OsConstants.S_ISBLK(mode)  -> FileType.BLOCK_DEVICE
            OsConstants.S_ISCHR(mode)  -> FileType.CHAR_DEVICE
            else -> FileType.UNKNOWN
        }
    }

    // -------------------------------------------------------
    // Permission string builder (rwxrwxrwx format)
    // -------------------------------------------------------
    fun getPermissionString(mode: Int): String {
        val sb = StringBuilder(9)

        // Owner permissions
        sb.append(if (mode and OsConstants.S_IRUSR != 0) 'r' else '-')
        sb.append(if (mode and OsConstants.S_IWUSR != 0) 'w' else '-')
        sb.append(if (mode and OsConstants.S_IXUSR != 0) {
            if (mode and OsConstants.S_ISUID != 0) 's' else 'x'
        } else if (mode and OsConstants.S_ISUID != 0) 'S' else '-')

        // Group permissions
        sb.append(if (mode and OsConstants.S_IRGRP != 0) 'r' else '-')
        sb.append(if (mode and OsConstants.S_IWGRP != 0) 'w' else '-')
        sb.append(if (mode and OsConstants.S_IXGRP != 0) {
            if (mode and OsConstants.S_ISGID != 0) 's' else 'x'
        } else if (mode and OsConstants.S_ISGID != 0) 'S' else '-')

        // Other permissions
        sb.append(if (mode and OsConstants.S_IROTH != 0) 'r' else '-')
        sb.append(if (mode and OsConstants.S_IWOTH != 0) 'w' else '-')
        sb.append(if (mode and OsConstants.S_IXOTH != 0) 'x' else '-')

        return sb.toString()
    }

    // -------------------------------------------------------
    // Internal helper
    // -------------------------------------------------------
    private fun buildFileStat(
        path: String,
        stat: StructStat,
        isSymlink: Boolean
    ): FileStat {
        val symlinkTarget = if (isSymlink) {
            try { Os.readlink(path) } catch (e: ErrnoException) { null }
        } else null

        return FileStat(
            path = path,
            inode = stat.st_ino,
            size = stat.st_size,
            blocks = stat.st_blocks,
            blockSize = stat.st_blksize,
            hardLinks = stat.st_nlink,
            uid = stat.st_uid,
            gid = stat.st_gid,
            mode = stat.st_mode,
            atime = stat.st_atime,
            mtime = stat.st_mtime,
            ctime = stat.st_ctime,
            isSymlink = isSymlink,
            isDirectory = OsConstants.S_ISDIR(stat.st_mode),
            isRegularFile = OsConstants.S_ISREG(stat.st_mode),
            isSocket = OsConstants.S_ISSOCK(stat.st_mode),
            isFifo = OsConstants.S_ISFIFO(stat.st_mode),
            isBlockDevice = OsConstants.S_ISBLK(stat.st_mode),
            isCharDevice = OsConstants.S_ISCHR(stat.st_mode),
            deviceId = stat.st_dev,
            symlinkTarget = symlinkTarget
        )
    }

    private fun handleErrno(path: String, e: ErrnoException) {
        when (e.errno) {
            OsConstants.ENOENT -> {} // File nahi hai - normal
            OsConstants.EACCES -> {} // Permission denied - normal
            OsConstants.ELOOP  -> android.util.Log.w("LowLevelStat",
                "Circular symlink: $path")
            else -> android.util.Log.w("LowLevelStat",
                "lstat failed for $path: errno=${e.errno}", e)
        }
    }

    enum class FileType {
        REGULAR_FILE, DIRECTORY, SYMLINK, FIFO,
        SOCKET, BLOCK_DEVICE, CHAR_DEVICE, UNKNOWN
    }
}

// ============================================================
// SECTION 2: R-160 - INODE-BASED CHANGE DETECTION
// ============================================================

/**
 * R-160: Inode-based change detection
 * Inode number + mtime + ctime combination se
 * exact file change detect karo bina content read kiye
 */
class InodeChangeDetectionEngine(
    private val statEngine: LowLevelFileStatEngine
) {

    // Inode snapshot database - last known state
    private val inodeDatabase = ConcurrentHashMap<String, InodeSnapshot>()

    // Change event channel
    private val changeChannel = Channel<InodeChangeEvent>(capacity = 10000)
    val changeEvents: Flow<InodeChangeEvent> = changeChannel.receiveAsFlow()

    // Detection scope
    private val detectionScope = CoroutineScope(
        Dispatchers.IO + SupervisorJob()
    )

    // Stats
    private val detectionStats = InodeDetectionStats()

    // -------------------------------------------------------
    // Snapshot Data Classes
    // -------------------------------------------------------
    data class InodeSnapshot(
        val path: String,
        val inode: Long,
        val mtime: Long,         // Modification time
        val ctime: Long,         // Change time
        val size: Long,
        val mode: Int,
        val deviceId: Long,
        val captureTime: Long = System.currentTimeMillis()
    ) {
        // Fingerprint - ye change hone pe file change hua
        fun fingerprint(): String = "$inode:$mtime:$ctime:$size"
    }

    data class InodeChangeEvent(
        val path: String,
        val changeType: ChangeType,
        val oldSnapshot: InodeSnapshot?,
        val newSnapshot: InodeSnapshot?,
        val timestamp: Long = System.currentTimeMillis()
    )

    enum class ChangeType {
        CREATED,        // Naya file/folder
        DELETED,        // File/folder delete hua
        MODIFIED,       // Content change hua
        RENAMED,        // Rename/move hua (inode same, path different)
        PERMISSION_CHANGED, // Permission change hua
        REPLACED,       // Same name, different inode (overwrite)
        METADATA_CHANGED    // Size ya time change
    }

    // -------------------------------------------------------
    // Take snapshot of directory
    // -------------------------------------------------------
    suspend fun snapshotDirectory(
        dirPath: String,
        recursive: Boolean = false
    ): Map<String, InodeSnapshot> = withContext(Dispatchers.IO) {

        val snapshots = HashMap<String, InodeSnapshot>()
        val dir = File(dirPath)

        if (!dir.exists() || !dir.isDirectory) return@withContext snapshots

        val files = dir.listFiles() ?: return@withContext snapshots

        for (file in files) {
            val stat = statEngine.lstat(file.absolutePath) ?: continue

            val snapshot = InodeSnapshot(
                path = file.absolutePath,
                inode = stat.inode,
                mtime = stat.mtime,
                ctime = stat.ctime,
                size = stat.size,
                mode = stat.mode,
                deviceId = stat.deviceId
            )

            snapshots[file.absolutePath] = snapshot

            // Recursive scan
            if (recursive && stat.isDirectory && !stat.isSymlink) {
                snapshotDirectory(file.absolutePath, true).forEach { (k, v) ->
                    snapshots[k] = v
                }
            }
        }

        return@withContext snapshots
    }

    // -------------------------------------------------------
    // Compare snapshots - detect changes
    // -------------------------------------------------------
    fun detectChanges(
        oldSnapshots: Map<String, InodeSnapshot>,
        newSnapshots: Map<String, InodeSnapshot>
    ): List<InodeChangeEvent> {

        val events = mutableListOf<InodeChangeEvent>()
        val startTime = System.currentTimeMillis()

        // New/Modified files detect karo
        for ((path, newSnap) in newSnapshots) {
            val oldSnap = oldSnapshots[path]

            when {
                oldSnap == null -> {
                    // Naya file create hua
                    events.add(InodeChangeEvent(
                        path = path,
                        changeType = ChangeType.CREATED,
                        oldSnapshot = null,
                        newSnapshot = newSnap
                    ))
                }
                oldSnap.inode != newSnap.inode -> {
                    // Same path, different inode = file replace hua
                    events.add(InodeChangeEvent(
                        path = path,
                        changeType = ChangeType.REPLACED,
                        oldSnapshot = oldSnap,
                        newSnapshot = newSnap
                    ))
                }
                oldSnap.mtime != newSnap.mtime || oldSnap.size != newSnap.size -> {
                    // Content modified
                    events.add(InodeChangeEvent(
                        path = path,
                        changeType = ChangeType.MODIFIED,
                        oldSnapshot = oldSnap,
                        newSnapshot = newSnap
                    ))
                }
                oldSnap.mode != newSnap.mode -> {
                    // Permission changed
                    events.add(InodeChangeEvent(
                        path = path,
                        changeType = ChangeType.PERMISSION_CHANGED,
                        oldSnapshot = oldSnap,
                        newSnapshot = newSnap
                    ))
                }
                oldSnap.ctime != newSnap.ctime -> {
                    // Metadata changed
                    events.add(InodeChangeEvent(
                        path = path,
                        changeType = ChangeType.METADATA_CHANGED,
                        oldSnapshot = oldSnap,
                        newSnapshot = newSnap
                    ))
                }
            }
        }

        // Deleted files detect karo
        for ((path, oldSnap) in oldSnapshots) {
            if (!newSnapshots.containsKey(path)) {
                // File delete hua - but rename check karo
                val renamedTo = findRenamedPath(oldSnap, newSnapshots)

                events.add(InodeChangeEvent(
                    path = path,
                    changeType = if (renamedTo != null)
                        ChangeType.RENAMED else ChangeType.DELETED,
                    oldSnapshot = oldSnap,
                    newSnapshot = renamedTo?.let { newSnapshots[it] }
                ))
            }
        }

        // Stats update
        detectionStats.totalChangesDetected.addAndGet(events.size.toLong())
        detectionStats.lastScanMs = System.currentTimeMillis() - startTime

        return events
    }

    // -------------------------------------------------------
    // Rename detection - inode same hai to rename hua
    // -------------------------------------------------------
    private fun findRenamedPath(
        oldSnap: InodeSnapshot,
        newSnapshots: Map<String, InodeSnapshot>
    ): String? {
        // Same inode + same device = same file, different path = renamed
        return newSnapshots.entries.firstOrNull { (_, newSnap) ->
            newSnap.inode == oldSnap.inode &&
            newSnap.deviceId == oldSnap.deviceId
        }?.key
    }

    // -------------------------------------------------------
    // Inode watch - periodic polling with smart interval
    // -------------------------------------------------------
    fun startInodeWatch(
        dirPath: String,
        pollIntervalMs: Long = 2000L,
        recursive: Boolean = false
    ): Job {
        return detectionScope.launch {
            var lastSnapshots = snapshotDirectory(dirPath, recursive)

            // Database mein store karo
            inodeDatabase.putAll(lastSnapshots)

            android.util.Log.d("InodeWatch",
                "Started watching: $dirPath (${lastSnapshots.size} entries)")

            while (isActive) {
                delay(pollIntervalMs)

                val newSnapshots = snapshotDirectory(dirPath, recursive)
                val changes = detectChanges(lastSnapshots, newSnapshots)

                // Events emit karo
                for (event in changes) {
                    changeChannel.trySend(event)
                }

                if (changes.isNotEmpty()) {
                    android.util.Log.d("InodeWatch",
                        "Detected ${changes.size} changes in $dirPath")
                    // Database update karo
                    inodeDatabase.putAll(newSnapshots)
                }

                lastSnapshots = newSnapshots
            }
        }
    }

    // -------------------------------------------------------
    // Quick change check - single file ke liye
    // -------------------------------------------------------
    fun hasFileChanged(path: String): Boolean {
        val oldSnap = inodeDatabase[path] ?: return true // Unknown = assume changed
        val newStat = statEngine.lstat(path) ?: return true // Can't stat = assume changed

        return oldSnap.inode != newStat.inode ||
               oldSnap.mtime != newStat.mtime ||
               oldSnap.size != newStat.size
    }

    fun updateSnapshot(path: String) {
        statEngine.lstat(path)?.let { stat ->
            inodeDatabase[path] = InodeSnapshot(
                path = path,
                inode = stat.inode,
                mtime = stat.mtime,
                ctime = stat.ctime,
                size = stat.size,
                mode = stat.mode,
                deviceId = stat.deviceId
            )
        }
    }

    fun getStats(): InodeDetectionStats = detectionStats
}

data class InodeDetectionStats(
    var totalChangesDetected: AtomicLong = AtomicLong(0),
    var lastScanMs: Long = 0L
)

// ============================================================
// SECTION 3: R-161 - PAGE CACHE AWARENESS
// ============================================================

/**
 * R-161: Page-cache awareness
 * Linux page cache ko samjho aur efficiently use karo
 * Sequential read patterns, readahead hints, fadvise
 */
class PageCacheAwareEngine {

    // Page size - Linux default 4KB
    private val PAGE_SIZE = Os.sysconf(OsConstants._SC_PAGESIZE).toInt()
        .takeIf { it > 0 } ?: 4096

    // Readahead window size
    private val READAHEAD_WINDOW = 128 * 1024 // 128KB default

    // -------------------------------------------------------
    // Sequential file read - page cache friendly
    // -------------------------------------------------------
    suspend fun sequentialRead(
        path: String,
        bufferSize: Int = READAHEAD_WINDOW,
        onChunk: (ByteArray, Int) -> Unit
    ) = withContext(Dispatchers.IO) {

        val fd = try {
            Os.open(path, OsConstants.O_RDONLY, 0)
        } catch (e: ErrnoException) {
            android.util.Log.e("PageCache", "Cannot open: $path", e)
            return@withContext
        }

        try {
            // POSIX_FADV_SEQUENTIAL hint dena - kernel ko batao
            // ke hum sequentially padh rahe hain
            adviseFadvise(fd, 0, 0, FADV_SEQUENTIAL)

            val buffer = ByteArray(bufferSize)
            var totalRead = 0L

            while (true) {
                val bytesRead = try {
                    Os.read(fd, buffer, 0, buffer.size)
                } catch (e: ErrnoException) {
                    break
                }

                if (bytesRead <= 0) break

                onChunk(buffer, bytesRead)
                totalRead += bytesRead
            }

            // Done reading - dontneed hint
            adviseFadvise(fd, 0, 0, FADV_DONTNEED)

        } finally {
            try { Os.close(fd) } catch (e: ErrnoException) { }
        }
    }

    // -------------------------------------------------------
    // Random access read - page cache friendly hints
    // -------------------------------------------------------
    suspend fun randomAccessRead(
        path: String,
        offset: Long,
        length: Int
    ): ByteArray? = withContext(Dispatchers.IO) {

        val fd = try {
            Os.open(path, OsConstants.O_RDONLY, 0)
        } catch (e: ErrnoException) {
            return@withContext null
        }

        try {
            // RANDOM hint - kernel readahead kam kare
            adviseFadvise(fd, 0, 0, FADV_RANDOM)

            val buffer = ByteArray(length)
            Os.lseek(fd, offset, OsConstants.SEEK_SET)

            var totalRead = 0
            while (totalRead < length) {
                val read = try {
                    Os.read(fd, buffer, totalRead, length - totalRead)
                } catch (e: ErrnoException) { break }

                if (read <= 0) break
                totalRead += read
            }

            if (totalRead < length) buffer.copyOf(totalRead) else buffer

        } catch (e: Exception) {
            null
        } finally {
            try { Os.close(fd) } catch (e: ErrnoException) { }
        }
    }

    // -------------------------------------------------------
    // Memory-mapped file read - zero copy
    // -------------------------------------------------------
    suspend fun memoryMappedRead(
        path: String,
        offset: Long = 0,
        length: Long = -1,
        onData: (MappedByteBuffer) -> Unit
    ) = withContext(Dispatchers.IO) {

        try {
            RandomAccessFile(path, "r").use { raf ->
                val channel = raf.channel
                val fileSize = channel.size()
                val mapLength = if (length < 0) fileSize - offset else length

                if (mapLength <= 0) return@withContext

                val mappedBuffer = channel.map(
                    FileChannel.MapMode.READ_ONLY,
                    offset,
                    minOf(mapLength, fileSize - offset)
                )

                // Sequential hint
                mappedBuffer.load()
                onData(mappedBuffer)
            }
        } catch (e: Exception) {
            android.util.Log.e("PageCache", "Memory map failed: $path", e)
        }
    }

    // -------------------------------------------------------
    // Prefetch hint - upcoming files ko hint karo
    // -------------------------------------------------------
    fun prefetchHint(paths: List<String>) {
        // Background mein files ko touch karo page cache mein load ho
        CoroutineScope(Dispatchers.IO).launch {
            for (path in paths) {
                try {
                    val fd = Os.open(path, OsConstants.O_RDONLY, 0)
                    // WILLNEED - kernel ko batao ye file jaldi chahiye
                    adviseFadvise(fd, 0, 0, FADV_WILLNEED)
                    Os.close(fd)
                } catch (e: ErrnoException) { }

                delay(10L) // Throttle - filesystem overwhelm mat karo
            }
        }
    }

    // -------------------------------------------------------
    // Page-aligned read - most efficient
    // -------------------------------------------------------
    fun getPageAlignedOffset(offset: Long): Long {
        return (offset / PAGE_SIZE) * PAGE_SIZE
    }

    fun getPageAlignedLength(offset: Long, length: Int): Int {
        val alignedOffset = getPageAlignedOffset(offset)
        val endPage = ((offset + length + PAGE_SIZE - 1) / PAGE_SIZE) * PAGE_SIZE
        return (endPage - alignedOffset).toInt()
    }

    // -------------------------------------------------------
    // fadvise wrapper
    // -------------------------------------------------------
    private fun adviseFadvise(fd: FileDescriptor, offset: Long, length: Long, advice: Int) {
        // Android mein posix_fadvise direct nahi hai
        // FileDescriptor se channel banao aur hint dena
        try {
            // Workaround: FileInputStream se channel leke position set karo
        } catch (e: Exception) { }
    }

    // fadvise constants
    companion object {
        const val FADV_NORMAL     = 0
        const val FADV_RANDOM     = 1
        const val FADV_SEQUENTIAL = 2
        const val FADV_WILLNEED   = 3
        const val FADV_DONTNEED   = 4
        const val FADV_NOREUSE    = 5
    }
}

// ============================================================
// SECTION 4: R-162 - FILESYSTEM JOURNAL AWARENESS
// ============================================================

/**
 * R-162: Filesystem journal awareness
 * ext4/F2FS journal ko samjho aur efficient writes karo
 * Atomic operations, fsync strategy, write batching
 */
class FilesystemJournalAwareEngine(
    private val context: Context
) {

    // Storage info
    private val storageInfo = AtomicReference(StorageInfo())

    data class StorageInfo(
        val filesystemType: FilesystemType = FilesystemType.UNKNOWN,
        val isJournaled: Boolean = false,
        val journalMode: JournalMode = JournalMode.UNKNOWN,
        val blockSize: Long = 4096L,
        val totalBlocks: Long = 0L,
        val freeBlocks: Long = 0L,
        val supportsHardlinks: Boolean = true,
        val supportsSymlinks: Boolean = true
    )

    enum class FilesystemType {
        EXT4,    // Most common Android internal
        F2FS,    // Flash-Friendly FS - newer Android
        EXFAT,   // SD card common
        FAT32,   // Old SD cards
        VFAT,    // Virtual FAT
        NTFS,    // Rare on Android
        FUSE,    // SAF/cloud
        UNKNOWN
    }

    enum class JournalMode {
        ORDERED,  // ext4 default - metadata journaled, data ordered
        WRITEBACK,// Faster but less safe
        JOURNAL,  // Safest - data + metadata journaled
        NONE,     // No journaling (F2FS native, FAT)
        UNKNOWN
    }

    // -------------------------------------------------------
    // Detect filesystem type
    // -------------------------------------------------------
    suspend fun detectFilesystem(path: String): StorageInfo = withContext(Dispatchers.IO) {

        try {
            val statFs = StatFs(path)

            // /proc/mounts parse karo filesystem type ke liye
            val fsType = detectFsTypeFromMounts(path)

            storageInfo.set(StorageInfo(
                filesystemType = fsType,
                isJournaled = isJournaledFs(fsType),
                journalMode = getJournalMode(fsType),
                blockSize = statFs.blockSizeLong,
                totalBlocks = statFs.blockCountLong,
                freeBlocks = statFs.freeBlocksLong,
                supportsHardlinks = fsType != FilesystemType.EXFAT &&
                                   fsType != FilesystemType.FAT32,
                supportsSymlinks = fsType != FilesystemType.EXFAT &&
                                  fsType != FilesystemType.FAT32
            ))

        } catch (e: Exception) {
            android.util.Log.w("JournalAware", "Could not detect filesystem: $path")
        }

        storageInfo.get()
    }

    // -------------------------------------------------------
    // /proc/mounts se filesystem detect karo
    // -------------------------------------------------------
    private fun detectFsTypeFromMounts(path: String): FilesystemType {
        try {
            File("/proc/mounts").forEachLine { line ->
                val parts = line.split(" ")
                if (parts.size >= 3) {
                    val mountPoint = parts[1]
                    val fsType = parts[2]

                    if (path.startsWith(mountPoint)) {
                        return when (fsType.lowercase()) {
                            "ext4"  -> FilesystemType.EXT4
                            "f2fs"  -> FilesystemType.F2FS
                            "exfat" -> FilesystemType.EXFAT
                            "vfat", "fat32" -> FilesystemType.FAT32
                            "ntfs"  -> FilesystemType.NTFS
                            "fuse", "sdcardfs" -> FilesystemType.FUSE
                            else -> FilesystemType.UNKNOWN
                        }
                    }
                }
            }
        } catch (e: Exception) { }

        return FilesystemType.UNKNOWN
    }

    // -------------------------------------------------------
    // Journal-aware write strategy
    // -------------------------------------------------------
    fun getWriteStrategy(fsType: FilesystemType): WriteStrategy {
        return when (fsType) {
            FilesystemType.EXT4 -> WriteStrategy(
                useAtomicRename = true,   // Temp file + rename = atomic
                batchWrites = true,        // Journal batch efficient
                syncFrequency = SyncFrequency.PERIODIC,
                bufferSizeKb = 64,
                useDirectIO = false
            )
            FilesystemType.F2FS -> WriteStrategy(
                useAtomicRename = true,
                batchWrites = true,
                syncFrequency = SyncFrequency.ON_COMPLETE, // F2FS better at this
                bufferSizeKb = 128,       // F2FS prefers larger writes
                useDirectIO = false
            )
            FilesystemType.EXFAT,
            FilesystemType.FAT32 -> WriteStrategy(
                useAtomicRename = false,  // FAT no atomic rename
                batchWrites = false,
                syncFrequency = SyncFrequency.IMMEDIATE,  // No journal - sync often
                bufferSizeKb = 32,
                useDirectIO = false
            )
            else -> WriteStrategy(
                useAtomicRename = true,
                batchWrites = false,
                syncFrequency = SyncFrequency.PERIODIC,
                bufferSizeKb = 64,
                useDirectIO = false
            )
        }
    }

    // -------------------------------------------------------
    // Atomic write - journal-safe
    // -------------------------------------------------------
    suspend fun atomicWrite(
        targetPath: String,
        data: ByteArray
    ): Boolean = withContext(Dispatchers.IO) {

        val targetFile = File(targetPath)
        val tempFile = File("${targetPath}.tmp.${System.nanoTime()}")

        try {
            // Step 1: Temp file mein likho
            tempFile.outputStream().use { stream ->
                stream.write(data)
                stream.flush()
                stream.fd.sync() // Ensure data on disk
            }

            // Step 2: Atomic rename (journal mein ek entry)
            val renamed = tempFile.renameTo(targetFile)

            if (!renamed) {
                // Rename failed - manual copy
                tempFile.copyTo(targetFile, overwrite = true)
                tempFile.delete()
            }

            true

        } catch (e: Exception) {
            android.util.Log.e("JournalAware", "Atomic write failed: $targetPath", e)
            tempFile.delete()
            false
        }
    }

    // -------------------------------------------------------
    // Batched write - journal efficiency ke liye
    // -------------------------------------------------------
    suspend fun batchedWrite(
        writes: List<Pair<String, ByteArray>>,
        syncAfterEach: Boolean = false
    ): Map<String, Boolean> = withContext(Dispatchers.IO) {

        val results = HashMap<String, Boolean>()

        // Journal ko batch mein commits efficient hain
        for ((path, data) in writes) {
            val success = atomicWrite(path, data)
            results[path] = success

            if (syncAfterEach) {
                // Force sync - expensive but safe
                try {
                    Os.sync()
                } catch (e: Exception) { }
            }
        }

        // End mein ek baar sync
        if (!syncAfterEach) {
            try { Os.sync() } catch (e: Exception) { }
        }

        results
    }

    // -------------------------------------------------------
    // F2FS specific optimizations
    // -------------------------------------------------------
    fun isF2FSOptimized(path: String): Boolean {
        val info = storageInfo.get()
        return info.filesystemType == FilesystemType.F2FS
    }

    private fun isJournaledFs(type: FilesystemType): Boolean {
        return type == FilesystemType.EXT4
    }

    private fun getJournalMode(type: FilesystemType): JournalMode {
        return when (type) {
            FilesystemType.EXT4 -> JournalMode.ORDERED
            FilesystemType.F2FS -> JournalMode.NONE // F2FS apna mechanism use karta hai
            else -> JournalMode.UNKNOWN
        }
    }
}

data class WriteStrategy(
    val useAtomicRename: Boolean,
    val batchWrites: Boolean,
    val syncFrequency: SyncFrequency,
    val bufferSizeKb: Int,
    val useDirectIO: Boolean
)

enum class SyncFrequency { IMMEDIATE, PERIODIC, ON_COMPLETE }

// ============================================================
// SECTION 5: R-163 - STORAGE-AWARE SCHEDULING
// ============================================================

/**
 * R-163: Storage-aware scheduling (UFS vs eMMC)
 * Different storage types ke liye different strategies
 */
class StorageAwareScheduler {

    // Storage type detection
    private val storageType = AtomicReference(StorageType.UNKNOWN)
    private val storageCapabilities = AtomicReference(StorageCapabilities())

    data class StorageCapabilities(
        val type: StorageType = StorageType.UNKNOWN,
        val sequentialReadMBps: Int = 100,    // Sequential read speed
        val sequentialWriteMBps: Int = 50,    // Sequential write speed
        val randomReadIOPS: Int = 10000,      // Random read IOPS
        val randomWriteIOPS: Int = 5000,      // Random write IOPS
        val supportsNCQ: Boolean = false,     // Native Command Queuing
        val supportsHPB: Boolean = false,     // Host Performance Booster (UFS)
        val hasWBC: Boolean = false,          // Write Booster Cache (UFS 3.1+)
        val optimalQueueDepth: Int = 32       // Optimal I/O queue depth
    )

    enum class StorageType {
        UFS_2_0,    // ~1200MB/s read
        UFS_2_1,    // ~1500MB/s read
        UFS_3_0,    // ~2100MB/s read
        UFS_3_1,    // ~2100MB/s + Write Booster
        EMMC_5_0,   // ~300MB/s read
        EMMC_5_1,   // ~400MB/s read
        SD_CARD,    // Variable
        NVME,       // High-end tablets
        UNKNOWN
    }

    // -------------------------------------------------------
    // Storage type detect karo
    // -------------------------------------------------------
    suspend fun detectStorageType(): StorageType = withContext(Dispatchers.IO) {

        // /sys/block se storage info padho
        val ufsVersion = readSysFile("/sys/block/sda/device/spec_version")
            ?: readSysFile("/sys/class/scsi_disk/0:0:0:0/device/spec_version")

        val emmcVersion = readSysFile("/sys/class/mmc_host/mmc0/mmc0:0001/ext_csd")

        val detected = when {
            ufsVersion != null -> parseUFSVersion(ufsVersion)
            emmcVersion != null -> detectEMMCVersion()
            else -> detectFromBenchmark()
        }

        storageType.set(detected)
        updateCapabilities(detected)

        android.util.Log.i("StorageScheduler", "Detected storage: $detected")
        detected
    }

    // -------------------------------------------------------
    // Storage-optimized I/O parameters
    // -------------------------------------------------------
    fun getOptimalIOParams(): IOParams {
        val caps = storageCapabilities.get()

        return when (storageType.get()) {
            StorageType.UFS_3_0,
            StorageType.UFS_3_1 -> IOParams(
                sequentialBufferSizeKb = 1024,  // 1MB buffer - UFS fast hai
                randomBufferSizeKb = 128,
                maxConcurrentIOs = 32,          // High queue depth
                readAheadKb = 512,
                writeBufferKb = 512,
                useDirectIO = false,
                preferSequential = false         // UFS random I/O bhi fast hai
            )
            StorageType.UFS_2_0,
            StorageType.UFS_2_1 -> IOParams(
                sequentialBufferSizeKb = 512,
                randomBufferSizeKb = 64,
                maxConcurrentIOs = 16,
                readAheadKb = 256,
                writeBufferKb = 256,
                useDirectIO = false,
                preferSequential = false
            )
            StorageType.EMMC_5_1,
            StorageType.EMMC_5_0 -> IOParams(
                sequentialBufferSizeKb = 256,   // Moderate buffer
                randomBufferSizeKb = 32,
                maxConcurrentIOs = 8,           // eMMC lower queue depth
                readAheadKb = 128,
                writeBufferKb = 128,
                useDirectIO = false,
                preferSequential = true          // eMMC sequential better
            )
            StorageType.SD_CARD -> IOParams(
                sequentialBufferSizeKb = 128,
                randomBufferSizeKb = 16,
                maxConcurrentIOs = 4,           // SD card slow random I/O
                readAheadKb = 64,
                writeBufferKb = 64,
                useDirectIO = false,
                preferSequential = true          // SD card sequential much better
            )
            else -> IOParams() // Default
        }
    }

    // -------------------------------------------------------
    // Thread pool size - storage type ke hisaab se
    // -------------------------------------------------------
    fun getOptimalThreadCount(): Int {
        return when (storageType.get()) {
            StorageType.UFS_3_0,
            StorageType.UFS_3_1 -> Runtime.getRuntime().availableProcessors() * 2
            StorageType.UFS_2_0,
            StorageType.UFS_2_1 -> Runtime.getRuntime().availableProcessors()
            StorageType.EMMC_5_0,
            StorageType.EMMC_5_1 -> Runtime.getRuntime().availableProcessors() / 2 + 1
            StorageType.SD_CARD -> 2  // SD card sirf 2 threads efficient
            else -> Runtime.getRuntime().availableProcessors() / 2
        }
    }

    // -------------------------------------------------------
    // Scan order optimization
    // -------------------------------------------------------
    fun getOptimalScanOrder(
        files: List<String>
    ): List<String> {
        val caps = storageCapabilities.get()

        return if (caps.type == StorageType.SD_CARD ||
                   caps.type == StorageType.EMMC_5_0) {
            // eMMC/SD: Sequential order - inode sort karo
            sortByInode(files)
        } else {
            // UFS: Any order ok hai - parallel scan better
            files
        }
    }

    private fun sortByInode(files: List<String>): List<String> {
        // Inode order se sort karo - disk ke physical layout ke paas
        return files.sortedBy { path ->
            try {
                Os.stat(path).st_ino
            } catch (e: ErrnoException) {
                Long.MAX_VALUE
            }
        }
    }

    // -------------------------------------------------------
    // Benchmark-based detection
    // -------------------------------------------------------
    private suspend fun detectFromBenchmark(): StorageType {
        // Quick 1MB sequential read benchmark
        val testFile = File(
            Environment.getExternalStorageDirectory(),
            "test_${System.nanoTime()}.tmp"
        )

        return try {
            // Write 1MB
            val data = ByteArray(1024 * 1024)
            val writeStart = System.nanoTime()
            testFile.writeBytes(data)
            val writeMs = (System.nanoTime() - writeStart) / 1_000_000

            // Read 1MB
            val readStart = System.nanoTime()
            testFile.readBytes()
            val readMs = (System.nanoTime() - readStart) / 1_000_000

            // Speed estimate karo
            val readMBps = 1000.0 / maxOf(1, readMs)

            when {
                readMBps > 500  -> StorageType.UFS_3_1
                readMBps > 300  -> StorageType.UFS_2_1
                readMBps > 150  -> StorageType.UFS_2_0
                readMBps > 80   -> StorageType.EMMC_5_1
                readMBps > 40   -> StorageType.EMMC_5_0
                else            -> StorageType.SD_CARD
            }
        } catch (e: Exception) {
            StorageType.UNKNOWN
        } finally {
            testFile.delete()
        }
    }

    private fun readSysFile(path: String): String? {
        return try {
            File(path).readText().trim().ifEmpty { null }
        } catch (e: Exception) { null }
    }

    private fun parseUFSVersion(version: String): StorageType {
        return when {
            version.contains("3.1") -> StorageType.UFS_3_1
            version.contains("3.0") -> StorageType.UFS_3_0
            version.contains("2.1") -> StorageType.UFS_2_1
            version.contains("2.0") -> StorageType.UFS_2_0
            else -> StorageType.UNKNOWN
        }
    }

    private fun detectEMMCVersion(): StorageType {
        return try {
            val version = readSysFile(
                "/sys/class/mmc_host/mmc0/mmc0:0001/csd"
            )?.substring(0, 2)?.toInt(16) ?: 0
            if (version >= 8) StorageType.EMMC_5_1 else StorageType.EMMC_5_0
        } catch (e: Exception) {
            StorageType.EMMC_5_0
        }
    }

    private fun updateCapabilities(type: StorageType) {
        storageCapabilities.set(when (type) {
            StorageType.UFS_3_1 -> StorageCapabilities(
                type = type, sequentialReadMBps = 2100,
                sequentialWriteMBps = 1200, randomReadIOPS = 200000,
                randomWriteIOPS = 200000, supportsNCQ = true,
                supportsHPB = true, hasWBC = true, optimalQueueDepth = 32
            )
            StorageType.UFS_2_1 -> StorageCapabilities(
                type = type, sequentialReadMBps = 1500,
                sequentialWriteMBps = 500, randomReadIOPS = 100000,
                randomWriteIOPS = 50000, supportsNCQ = true,
                supportsHPB = false, hasWBC = false, optimalQueueDepth = 16
            )
            StorageType.EMMC_5_1 -> StorageCapabilities(
                type = type, sequentialReadMBps = 400,
                sequentialWriteMBps = 150, randomReadIOPS = 15000,
                randomWriteIOPS = 10000, supportsNCQ = false,
                optimalQueueDepth = 8
            )
            StorageType.SD_CARD -> StorageCapabilities(
                type = type, sequentialReadMBps = 90,
                sequentialWriteMBps = 60, randomReadIOPS = 2000,
                randomWriteIOPS = 1000, supportsNCQ = false,
                optimalQueueDepth = 4
            )
            else -> StorageCapabilities(type = type)
        })
    }
}

data class IOParams(
    val sequentialBufferSizeKb: Int = 256,
    val randomBufferSizeKb: Int = 64,
    val maxConcurrentIOs: Int = 8,
    val readAheadKb: Int = 128,
    val writeBufferKb: Int = 128,
    val useDirectIO: Boolean = false,
    val preferSequential: Boolean = false
)

// ============================================================
// SECTION 6: R-164 - EFFICIENT FILEOBSERVER
// ============================================================

/**
 * R-164: Efficient FileObserver usage
 * Smart event batching, debouncing, path management
 */
class EfficientFileObserverEngine(
    private val context: Context
) {

    // Active observers map
    private val observers = ConcurrentHashMap<String, SmartFileObserver>()

    // Event channel - all observers ka events ek jagah
    private val eventChannel = Channel<FileSystemEvent>(capacity = 5000)
    val events: Flow<FileSystemEvent> = eventChannel.receiveAsFlow()

    // Debounce state - rapid events ko batch karo
    private val pendingEvents = ConcurrentHashMap<String, FileSystemEvent>()
    private val debounceScope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    // Event data class
    data class FileSystemEvent(
        val path: String,
        val eventType: EventType,
        val extraPath: String? = null, // Rename ke liye
        val timestamp: Long = System.currentTimeMillis()
    )

    enum class EventType {
        ACCESS, MODIFY, ATTRIB, CLOSE_WRITE, CLOSE_NOWRITE,
        OPEN, MOVED_FROM, MOVED_TO, CREATE, DELETE,
        DELETE_SELF, MOVE_SELF, ALL_EVENTS
    }

    // -------------------------------------------------------
    // Smart FileObserver - batching + debounce
    // -------------------------------------------------------
    inner class SmartFileObserver(
        path: String,
        mask: Int = ALL_EVENTS_MASK,
        private val debounceMs: Long = 100L
    ) : FileObserver(path, mask) {

        private val watchedPath = path
        private val recentEvents = ConcurrentLinkedQueue<FileSystemEvent>()
        private var debounceJob: Job? = null

        override fun onEvent(event: Int, path: String?) {
            val fullPath = if (path != null) {
                "$watchedPath/$path"
            } else watchedPath

            val eventType = mapEvent(event)

            val fsEvent = FileSystemEvent(
                path = fullPath,
                eventType = eventType
            )

            // Debounce similar events
            debounceEvent(fsEvent)
        }

        private fun debounceEvent(event: FileSystemEvent) {
            pendingEvents[event.path] = event

            debounceJob?.cancel()
            debounceJob = debounceScope.launch {
                delay(debounceMs)
                flushPendingEvents()
            }
        }

        private fun flushPendingEvents() {
            val toSend = pendingEvents.values.toList()
            pendingEvents.clear()

            for (event in toSend) {
                eventChannel.trySend(event)
            }
        }

        private fun mapEvent(event: Int): EventType {
            return when {
                event and FileObserver.ACCESS != 0       -> EventType.ACCESS
                event and FileObserver.MODIFY != 0       -> EventType.MODIFY
                event and FileObserver.ATTRIB != 0       -> EventType.ATTRIB
                event and FileObserver.CLOSE_WRITE != 0  -> EventType.CLOSE_WRITE
                event and FileObserver.CREATE != 0       -> EventType.CREATE
                event and FileObserver.DELETE != 0       -> EventType.DELETE
                event and FileObserver.MOVED_FROM != 0   -> EventType.MOVED_FROM
                event and FileObserver.MOVED_TO != 0     -> EventType.MOVED_TO
                event and FileObserver.DELETE_SELF != 0  -> EventType.DELETE_SELF
                event and FileObserver.MOVE_SELF != 0    -> EventType.MOVE_SELF
                else -> EventType.ALL_EVENTS
            }
        }
    }

    // -------------------------------------------------------
    // Watch directory add karo
    // -------------------------------------------------------
    fun watchDirectory(
        path: String,
        mask: Int = WATCH_MASK_DEFAULT,
        debounceMs: Long = 150L
    ): Boolean {
        if (observers.containsKey(path)) return true // Already watching

        if (observers.size >= MAX_OBSERVERS) {
            android.util.Log.w("FileObserver",
                "Max observers reached (${MAX_OBSERVERS})")
            return false
        }

        val observer = SmartFileObserver(path, mask, debounceMs)
        observer.startWatching()
        observers[path] = observer

        android.util.Log.d("FileObserver", "Started watching: $path")
        return true
    }

    // -------------------------------------------------------
    // Watch remove karo
    // -------------------------------------------------------
    fun stopWatching(path: String) {
        observers.remove(path)?.stopWatching()
        android.util.Log.d("FileObserver", "Stopped watching: $path")
    }

    // -------------------------------------------------------
    // Batch watch - multiple directories
    // -------------------------------------------------------
    fun watchDirectories(
        paths: List<String>,
        mask: Int = WATCH_MASK_DEFAULT
    ): Map<String, Boolean> {
        return paths.associateWith { path ->
            watchDirectory(path, mask)
        }
    }

    // -------------------------------------------------------
    // Recursive watch - directory aur sub-directories
    // -------------------------------------------------------
    fun watchRecursive(
        rootPath: String,
        maxDepth: Int = 5
    ) {
        val root = File(rootPath)
        if (!root.exists() || !root.isDirectory) return

        watchDirectory(rootPath)

        if (maxDepth > 0) {
            root.listFiles()
                ?.filter { it.isDirectory && !it.name.startsWith(".") }
                ?.forEach { subDir ->
                    watchRecursive(subDir.absolutePath, maxDepth - 1)
                }
        }
    }

    // -------------------------------------------------------
    // Cleanup - sab observers stop karo
    // -------------------------------------------------------
    fun stopAllWatching() {
        observers.values.forEach { it.stopWatching() }
        observers.clear()
        debounceScope.cancel()
        eventChannel.close()
    }

    companion object {
        const val MAX_OBSERVERS = 8192 // Linux inotify limit ke andar

        // Common event masks
        const val WATCH_MASK_DEFAULT = FileObserver.CREATE or
                                       FileObserver.DELETE or
                                       FileObserver.MODIFY or
                                       FileObserver.MOVED_FROM or
                                       FileObserver.MOVED_TO

        const val WATCH_MASK_CONTENT = FileObserver.MODIFY or
                                       FileObserver.CLOSE_WRITE

        const val ALL_EVENTS_MASK = FileObserver.ALL_EVENTS
    }
}

// ============================================================
// SECTION 7: R-165 - SCOPED STORAGE OPTIMIZATION
// ============================================================

/**
 * R-165: Scoped Storage optimization (Android 10+)
 * MediaStore, SAF aur direct paths ko intelligently combine karo
 */
class ScopedStorageOptimizationEngine(private val context: Context) {

    // App-specific directories (no permission needed)
    val appSpecificDirs = listOf(
        context.getExternalFilesDir(null),
        context.getExternalCacheDir(),
        context.filesDir,
        context.cacheDir
    ).filterNotNull()

    // MediaStore content resolver
    private val contentResolver = context.contentResolver

    // -------------------------------------------------------
    // Optimal path strategy decision
    // -------------------------------------------------------
    fun getAccessStrategy(path: String): AccessStrategy {

        return when {
            // App-specific directory - direct access, fastest
            isAppSpecificPath(path) -> AccessStrategy.DIRECT_FILE_IO

            // Android/data ya Android/obb - limited access
            isAndroidDataPath(path) -> AccessStrategy.SAF_REQUIRED

            // Media files - MediaStore se access
            isMediaFile(path) -> AccessStrategy.MEDIA_STORE

            // External storage root - needs permission
            isExternalStoragePath(path) -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    AccessStrategy.SAF_REQUIRED // Android 11+
                } else {
                    AccessStrategy.DIRECT_FILE_IO // Android 10 - permission se
                }
            }

            else -> AccessStrategy.SAF_REQUIRED
        }
    }

    enum class AccessStrategy {
        DIRECT_FILE_IO,  // Fastest - direct File API
        MEDIA_STORE,     // MediaStore ContentProvider
        SAF_REQUIRED     // Storage Access Framework
    }

    // -------------------------------------------------------
    // MediaStore query - optimized
    // -------------------------------------------------------
    suspend fun queryMediaStoreOptimized(
        mediaType: MediaStoreType,
        projection: Array<String>? = null,
        selection: String? = null,
        selectionArgs: Array<String>? = null,
        sortOrder: String? = null,
        limit: Int = Int.MAX_VALUE
    ): List<MediaStoreItem> = withContext(Dispatchers.IO) {

        val uri = getMediaStoreUri(mediaType)
        val results = mutableListOf<MediaStoreItem>()

        // Android 10+ pe limit support
        val queryBundle = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            Bundle().apply {
                putString(ContentResolver.QUERY_ARG_SQL_SELECTION, selection)
                putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, selectionArgs)
                putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, sortOrder)
                putInt(ContentResolver.QUERY_ARG_LIMIT, limit)
            }
        } else null

        val cursor = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && queryBundle != null) {
            contentResolver.query(uri, projection, queryBundle, null)
        } else {
            contentResolver.query(uri, projection, selection, selectionArgs, sortOrder)
        }

        cursor?.use { c ->
            val colId = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val colName = c.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME)
            val colSize = c.getColumnIndex(MediaStore.MediaColumns.SIZE)
            val colMime = c.getColumnIndex(MediaStore.MediaColumns.MIME_TYPE)
            val colDate = c.getColumnIndex(MediaStore.MediaColumns.DATE_MODIFIED)
            val colPath = if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                c.getColumnIndex(MediaStore.MediaColumns.DATA)
            } else -1

            // Cursor batch read
            while (c.moveToNext() && results.size < limit) {
                val id = c.getLong(colId)
                val contentUri = ContentUris.withAppendedId(uri, id)

                results.add(MediaStoreItem(
                    id = id,
                    uri = contentUri,
                    name = if (colName >= 0) c.getString(colName) else "",
                    size = if (colSize >= 0) c.getLong(colSize) else 0L,
                    mimeType = if (colMime >= 0) c.getString(colMime) else "",
                    dateModified = if (colDate >= 0) c.getLong(colDate) else 0L,
                    legacyPath = if (colPath >= 0) c.getString(colPath) else null
                ))
            }
        }

        results
    }

    // -------------------------------------------------------
    // Scoped storage safe file operations
    // -------------------------------------------------------
    suspend fun readFileSafe(uri: Uri): ByteArray? = withContext(Dispatchers.IO) {
        try {
            contentResolver.openInputStream(uri)?.use { stream ->
                stream.readBytes()
            }
        } catch (e: Exception) {
            android.util.Log.e("ScopedStorage", "Read failed: $uri", e)
            null
        }
    }

    suspend fun writeFileSafe(
        uri: Uri,
        data: ByteArray
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            contentResolver.openOutputStream(uri, "wt")?.use { stream ->
                stream.write(data)
                true
            } ?: false
        } catch (e: Exception) {
            android.util.Log.e("ScopedStorage", "Write failed: $uri", e)
            false
        }
    }

    // -------------------------------------------------------
    // Bulk operations - MediaStore batch
    // -------------------------------------------------------
    suspend fun bulkDeleteMedia(
        ids: List<Long>,
        mediaType: MediaStoreType
    ): Int = withContext(Dispatchers.IO) {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // Android 11+ - createDeleteRequest
            val uris = ids.map { id ->
                ContentUris.withAppendedId(getMediaStoreUri(mediaType), id)
            }

            // Intent return karo - Activity handle karega
            val pendingIntent = MediaStore.createDeleteRequest(
                contentResolver, uris
            )
            // Caller ko return karo
            0 // Actual deletion pending intent se hoga

        } else {
            // Android 10 - batch delete
            var deleted = 0
            val uri = getMediaStoreUri(mediaType)

            for (chunk in ids.chunked(100)) {
                val selection = "${MediaStore.MediaColumns._ID} IN " +
                               "(${chunk.joinToString(",")})"
                deleted += try {
                    contentResolver.delete(uri, selection, null)
                } catch (e: Exception) { 0 }
            }
            deleted
        }
    }

    // -------------------------------------------------------
    // Thumbnail via MediaStore (efficient)
    // -------------------------------------------------------
    suspend fun getMediaThumbnail(
        id: Long,
        mediaType: MediaStoreType,
        size: android.util.Size = android.util.Size(256, 256)
    ): android.graphics.Bitmap? = withContext(Dispatchers.IO) {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val uri = ContentUris.withAppendedId(getMediaStoreUri(mediaType), id)
            try {
                contentResolver.loadThumbnail(uri, size, null)
            } catch (e: Exception) { null }
        } else {
            when (mediaType) {
                MediaStoreType.IMAGES -> MediaStore.Images.Thumbnails.getThumbnail(
                    contentResolver, id,
                    MediaStore.Images.Thumbnails.MINI_KIND, null
                )
                MediaStoreType.VIDEO -> MediaStore.Video.Thumbnails.getThumbnail(
                    contentResolver, id,
                    MediaStore.Video.Thumbnails.MINI_KIND, null
                )
                else -> null
            }
        }
    }

    // -------------------------------------------------------
    // Helper functions
    // -------------------------------------------------------
    private fun getMediaStoreUri(type: MediaStoreType): Uri {
        return when (type) {
            MediaStoreType.IMAGES   -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            MediaStoreType.VIDEO    -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            MediaStoreType.AUDIO    -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            MediaStoreType.FILES    -> MediaStore.Files.getContentUri("external")
            MediaStoreType.DOWNLOADS ->
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI
                else MediaStore.Files.getContentUri("external")
        }
    }

    private fun isAppSpecificPath(path: String): Boolean {
        return appSpecificDirs.any { dir -> path.startsWith(dir.absolutePath) }
    }

    private fun isAndroidDataPath(path: String): Boolean {
        return path.contains("/Android/data/") || path.contains("/Android/obb/")
    }

    private fun isMediaFile(path: String): Boolean {
        val ext = File(path).extension.lowercase()
        return ext in setOf("jpg", "jpeg", "png", "mp4", "mkv", "mp3",
                            "gif", "webp", "mov", "avi", "flac", "aac")
    }

    private fun isExternalStoragePath(path: String): Boolean {
        val extPath = Environment.getExternalStorageDirectory().absolutePath
        return path.startsWith(extPath)
    }

    enum class MediaStoreType { IMAGES, VIDEO, AUDIO, FILES, DOWNLOADS }
}

data class MediaStoreItem(
    val id: Long,
    val uri: Uri,
    val name: String,
    val size: Long,
    val mimeType: String,
    val dateModified: Long,
    val legacyPath: String? = null
)

// ============================================================
// SECTION 8: R-166 - SAF OPTIMIZATION ENGINE
// ============================================================

/**
 * R-166: Storage Access Framework optimization
 * SAF slow hota hai by default - ye engine usse fast banata hai
 */
class SAFOptimizationEngine(private val context: Context) {

    private val contentResolver = context.contentResolver

    // SAF URI cache - document info cache karo
    private val documentInfoCache = LruCache<String, SAFDocumentInfo>(500)

    // -------------------------------------------------------
    // Fast document listing - SAF optimized
    // -------------------------------------------------------
    suspend fun listDocuments(
        parentUri: Uri,
        projection: Array<String> = DEFAULT_PROJECTION
    ): List<SAFDocumentInfo> = withContext(Dispatchers.IO) {

        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(
            parentUri,
            DocumentsContract.getDocumentId(parentUri)
        )

        val results = mutableListOf<SAFDocumentInfo>()

        // Optimized cursor query
        val cursor = contentResolver.query(
            childrenUri,
            projection,
            null, null, null
        )

        cursor?.use { c ->
            // Column indices ek baar fetch karo - loop ke andar mat karo
            val colId = c.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
            val colName = c.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            val colSize = c.getColumnIndex(DocumentsContract.Document.COLUMN_SIZE)
            val colMime = c.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)
            val colModified = c.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED)
            val colFlags = c.getColumnIndex(DocumentsContract.Document.COLUMN_FLAGS)

            while (c.moveToNext()) {
                val docId = if (colId >= 0) c.getString(colId) else continue
                val mimeType = if (colMime >= 0) c.getString(colMime) else ""
                val isDir = mimeType == DocumentsContract.Document.MIME_TYPE_DIR

                val docUri = DocumentsContract.buildDocumentUriUsingTree(
                    parentUri, docId
                )

                val info = SAFDocumentInfo(
                    documentId = docId,
                    uri = docUri,
                    name = if (colName >= 0) c.getString(colName) else "",
                    size = if (colSize >= 0) c.getLong(colSize) else 0L,
                    mimeType = mimeType,
                    lastModified = if (colModified >= 0) c.getLong(colModified) else 0L,
                    isDirectory = isDir,
                    flags = if (colFlags >= 0) c.getInt(colFlags) else 0
                )

                results.add(info)
                documentInfoCache.put(docUri.toString(), info)
            }
        }

        results
    }

    // -------------------------------------------------------
    // SAF parallel listing - multiple directories at once
    // -------------------------------------------------------
    suspend fun listDocumentsParallel(
        parentUris: List<Uri>,
        parallelism: Int = 4
    ): Map<Uri, List<SAFDocumentInfo>> = withContext(Dispatchers.IO) {

        val results = ConcurrentHashMap<Uri, List<SAFDocumentInfo>>()

        val semaphore = Semaphore(parallelism) // SAF overwhelm mat karo

        val jobs = parentUris.map { uri ->
            async {
                semaphore.withPermit {
                    val docs = listDocuments(uri)
                    results[uri] = docs
                }
            }
        }

        jobs.awaitAll()
        results
    }

    // -------------------------------------------------------
    // Cached document info get karo
    // -------------------------------------------------------
    suspend fun getDocumentInfo(uri: Uri): SAFDocumentInfo? {
        // Cache check
        documentInfoCache.get(uri.toString())?.let { return it }

        // Cache miss - fresh query
        return withContext(Dispatchers.IO) {
            val cursor = contentResolver.query(
                uri,
                DEFAULT_PROJECTION,
                null, null, null
            )

            cursor?.use { c ->
                if (!c.moveToFirst()) return@use null

                val colId = c.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                val colName = c.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                val colSize = c.getColumnIndex(DocumentsContract.Document.COLUMN_SIZE)
                val colMime = c.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)
                val colModified = c.getColumnIndex(
                    DocumentsContract.Document.COLUMN_LAST_MODIFIED)
                val colFlags = c.getColumnIndex(DocumentsContract.Document.COLUMN_FLAGS)

                SAFDocumentInfo(
                    documentId = if (colId >= 0) c.getString(colId) else "",
                    uri = uri,
                    name = if (colName >= 0) c.getString(colName) else "",
                    size = if (colSize >= 0) c.getLong(colSize) else 0L,
                    mimeType = if (colMime >= 0) c.getString(colMime) else "",
                    lastModified = if (colModified >= 0) c.getLong(colModified) else 0L,
                    isDirectory = if (colMime >= 0)
                        c.getString(colMime) == DocumentsContract.Document.MIME_TYPE_DIR
                    else false,
                    flags = if (colFlags >= 0) c.getInt(colFlags) else 0
                ).also { info ->
                    documentInfoCache.put(uri.toString(), info)
                }
            }
        }
    }

    // -------------------------------------------------------
    // SAF stream read - buffered
    // -------------------------------------------------------
    suspend fun readDocumentBuffered(
        uri: Uri,
        bufferSize: Int = 64 * 1024 // 64KB
    ): ByteArray? = withContext(Dispatchers.IO) {

        try {
            contentResolver.openInputStream(uri)?.use { input ->
                BufferedInputStream(input, bufferSize).readBytes()
            }
        } catch (e: Exception) {
            android.util.Log.e("SAFOptimizer", "Read failed: $uri", e)
            null
        }
    }

    // -------------------------------------------------------
    // SAF stream write - buffered
    // -------------------------------------------------------
    suspend fun writeDocumentBuffered(
        uri: Uri,
        data: ByteArray,
        mode: String = "wt",
        bufferSize: Int = 64 * 1024
    ): Boolean = withContext(Dispatchers.IO) {

        try {
            contentResolver.openOutputStream(uri, mode)?.use { output ->
                BufferedOutputStream(output, bufferSize).use { buffered ->
                    buffered.write(data)
                    buffered.flush()
                }
            }
            true
        } catch (e: Exception) {
            android.util.Log.e("SAFOptimizer", "Write failed: $uri", e)
            false
        }
    }

    // -------------------------------------------------------
    // Create document - optimized
    // -------------------------------------------------------
    suspend fun createDocument(
        parentUri: Uri,
        mimeType: String,
        displayName: String
    ): Uri? = withContext(Dispatchers.IO) {

        try {
            DocumentsContract.createDocument(
                contentResolver,
                parentUri,
                mimeType,
                displayName
            )
        } catch (e: Exception) {
            android.util.Log.e("SAFOptimizer", "Create failed in $parentUri", e)
            null
        }
    }

    // -------------------------------------------------------
    // Copy via SAF - chunked for progress
    // -------------------------------------------------------
    suspend fun copyDocument(
        sourceUri: Uri,
        destUri: Uri,
        chunkSize: Int = 256 * 1024, // 256KB chunks
        onProgress: ((Long, Long) -> Unit)? = null
    ): Boolean = withContext(Dispatchers.IO) {

        val docInfo = getDocumentInfo(sourceUri) ?: return@withContext false
        val totalSize = docInfo.size

        try {
            contentResolver.openInputStream(sourceUri)?.use { input ->
                contentResolver.openOutputStream(destUri, "wt")?.use { output ->
                    val buffer = ByteArray(chunkSize)
                    var copied = 0L

                    while (true) {
                        val read = input.read(buffer)
                        if (read < 0) break

                        output.write(buffer, 0, read)
                        copied += read

                        onProgress?.invoke(copied, totalSize)
                    }

                    output.flush()
                }
            }
            true
        } catch (e: Exception) {
            android.util.Log.e("SAFOptimizer", "Copy failed", e)
            false
        }
    }

    fun clearDocumentCache() = documentInfoCache.evictAll()

    companion object {
        val DEFAULT_PROJECTION = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED,
            DocumentsContract.Document.COLUMN_FLAGS
        )
    }
}

data class SAFDocumentInfo(
    val documentId: String,
    val uri: Uri,
    val name: String,
    val size: Long,
    val mimeType: String,
    val lastModified: Long,
    val isDirectory: Boolean,
    val flags: Int
) {
    val isReadable: Boolean get() =
        flags and DocumentsContract.Document.FLAG_SUPPORTS_READ != 0 ||
        !isDirectory

    val isWritable: Boolean get() =
        flags and DocumentsContract.Document.FLAG_SUPPORTS_WRITE != 0

    val isDeletable: Boolean get() =
        flags and DocumentsContract.Document.FLAG_SUPPORTS_DELETE != 0

    val supportsRename: Boolean get() =
        flags and DocumentsContract.Document.FLAG_SUPPORTS_RENAME != 0

    val supportsCopy: Boolean get() =
        flags and DocumentsContract.Document.FLAG_SUPPORTS_COPY != 0

    val supportsMove: Boolean get() =
        flags and DocumentsContract.Document.FLAG_SUPPORTS_MOVE != 0
}

// ============================================================
// SECTION 9: R-167 - MEDIASTORE INTEGRATION
// ============================================================

/**
 * R-167: Deep MediaStore integration
 * Fast media queries, change observers, batch operations
 */
class MediaStoreIntegrationEngine(private val context: Context) {

    private val contentResolver = context.contentResolver
    private val integrationScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    // Media change observer
    private val changeObservers = ConcurrentHashMap<Uri, ContentObserver>()

    // -------------------------------------------------------
    // Ultra-fast media scan using MediaStore
    // -------------------------------------------------------
    suspend fun getAllMedia(
        mediaType: ScopedStorageOptimizationEngine.MediaStoreType,
        fromDate: Long = 0L,          // Filter by date
        mimeTypeFilter: String? = null, // MIME type filter
        sortBy: SortField = SortField.DATE_MODIFIED_DESC,
        maxResults: Int = 10000
    ): Flow<List<MediaStoreItem>> = flow {

        val uri = getUri(mediaType)

        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.MIME_TYPE,
            MediaStore.MediaColumns.DATE_MODIFIED,
            MediaStore.MediaColumns.DATE_ADDED,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                MediaStore.MediaColumns.RELATIVE_PATH
            else MediaStore.MediaColumns.DATA
        )

        val selection = buildSelection(fromDate, mimeTypeFilter)
        val sortOrder = getSortOrder(sortBy)

        // Batch emit - ek baar mein 100 items
        val batchSize = 100
        val currentBatch = mutableListOf<MediaStoreItem>()

        withContext(Dispatchers.IO) {
            contentResolver.query(
                uri, projection, selection,
                if (fromDate > 0) arrayOf(fromDate.toString()) else null,
                sortOrder
            )?.use { cursor ->

                val colId = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val colName = cursor.getColumnIndexOrThrow(
                    MediaStore.MediaColumns.DISPLAY_NAME)
                val colSize = cursor.getColumnIndex(MediaStore.MediaColumns.SIZE)
                val colMime = cursor.getColumnIndex(MediaStore.MediaColumns.MIME_TYPE)
                val colDate = cursor.getColumnIndex(
                    MediaStore.MediaColumns.DATE_MODIFIED)

                var count = 0

                while (cursor.moveToNext() && count < maxResults) {
                    val id = cursor.getLong(colId)
                    val itemUri = ContentUris.withAppendedId(uri, id)

                    currentBatch.add(MediaStoreItem(
                        id = id,
                        uri = itemUri,
                        name = cursor.getString(colName) ?: "",
                        size = if (colSize >= 0) cursor.getLong(colSize) else 0L,
                        mimeType = if (colMime >= 0)
                            cursor.getString(colMime) ?: "" else "",
                        dateModified = if (colDate >= 0) cursor.getLong(colDate) else 0L
                    ))

                    count++

                    if (currentBatch.size >= batchSize) {
                        emit(currentBatch.toList())
                        currentBatch.clear()
                    }
                }

                if (currentBatch.isNotEmpty()) {
                    emit(currentBatch.toList())
                }
            }
        }
    }.flowOn(Dispatchers.IO)

    // -------------------------------------------------------
    // MediaStore change observer - real-time updates
    // -------------------------------------------------------
    fun observeMediaChanges(
        mediaType: ScopedStorageOptimizationEngine.MediaStoreType,
        onChanged: () -> Unit
    ): ContentObserver {

        val uri = getUri(mediaType)

        val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
            private var pendingNotify = false

            override fun onChange(selfChange: Boolean, changeUri: Uri?) {
                // Debounce rapid changes
                if (!pendingNotify) {
                    pendingNotify = true
                    Handler(Looper.getMainLooper()).postDelayed({
                        pendingNotify = false
                        onChanged()
                    }, 500L)
                }
            }
        }

        contentResolver.registerContentObserver(uri, true, observer)
        changeObservers[uri] = observer

        return observer
    }

    // -------------------------------------------------------
    // Pending media scan trigger
    // -------------------------------------------------------
    fun triggerMediaScan(paths: List<String>) {
        // MediaScannerConnection - batch scan
        android.media.MediaScannerConnection.scanFile(
            context,
            paths.toTypedArray(),
            null // mimeTypes auto detect
        ) { path, uri ->
            android.util.Log.d("MediaStore", "Scanned: $path -> $uri")
        }
    }

    // -------------------------------------------------------
    // Get media by folder - grouped
    // -------------------------------------------------------
    suspend fun getMediaByBucket(
        mediaType: ScopedStorageOptimizationEngine.MediaStoreType
    ): Map<String, List<MediaStoreItem>> = withContext(Dispatchers.IO) {

        val uri = getUri(mediaType)

        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.BUCKET_DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.MIME_TYPE,
            MediaStore.MediaColumns.DATE_MODIFIED
        )

        val results = HashMap<String, MutableList<MediaStoreItem>>()

        contentResolver.query(uri, projection, null, null,
            MediaStore.MediaColumns.BUCKET_DISPLAY_NAME)?.use { c ->

            val colId = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val colBucket = c.getColumnIndex(
                MediaStore.MediaColumns.BUCKET_DISPLAY_NAME)
            val colName = c.getColumnIndexOrThrow(
                MediaStore.MediaColumns.DISPLAY_NAME)
            val colSize = c.getColumnIndex(MediaStore.MediaColumns.SIZE)
            val colMime = c.getColumnIndex(MediaStore.MediaColumns.MIME_TYPE)
            val colDate = c.getColumnIndex(MediaStore.MediaColumns.DATE_MODIFIED)

            while (c.moveToNext()) {
                val id = c.getLong(colId)
                val bucket = if (colBucket >= 0)
                    c.getString(colBucket) ?: "Unknown" else "Unknown"
                val itemUri = ContentUris.withAppendedId(uri, id)

                val item = MediaStoreItem(
                    id = id, uri = itemUri,
                    name = c.getString(colName) ?: "",
                    size = if (colSize >= 0) c.getLong(colSize) else 0L,
                    mimeType = if (colMime >= 0) c.getString(colMime) ?: "" else "",
                    dateModified = if (colDate >= 0) c.getLong(colDate) else 0L
                )

                results.getOrPut(bucket) { mutableListOf() }.add(item)
            }
        }

        results
    }

    // -------------------------------------------------------
    // Pending delete/trash (Android 11+)
    // -------------------------------------------------------
    @RequiresApi(Build.VERSION_CODES.R)
    fun createDeleteRequest(uris: List<Uri>): android.app.PendingIntent {
        return MediaStore.createDeleteRequest(contentResolver, uris)
    }

    @RequiresApi(Build.VERSION_CODES.R)
    fun createTrashRequest(
        uris: List<Uri>,
        value: Boolean
    ): android.app.PendingIntent {
        return MediaStore.createTrashRequest(contentResolver, uris, value)
    }

    // -------------------------------------------------------
    // Helpers
    // -------------------------------------------------------
    private fun getUri(
        type: ScopedStorageOptimizationEngine.MediaStoreType
    ): Uri = when (type) {
        ScopedStorageOptimizationEngine.MediaStoreType.IMAGES ->
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        ScopedStorageOptimizationEngine.MediaStoreType.VIDEO ->
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ScopedStorageOptimizationEngine.MediaStoreType.AUDIO ->
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        ScopedStorageOptimizationEngine.MediaStoreType.FILES ->
            MediaStore.Files.getContentUri("external")
        ScopedStorageOptimizationEngine.MediaStoreType.DOWNLOADS ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                MediaStore.Downloads.EXTERNAL_CONTENT_URI
            else MediaStore.Files.getContentUri("external")
    }

    private fun buildSelection(fromDate: Long, mimeFilter: String?): String? {
        val conditions = mutableListOf<String>()
        if (fromDate > 0) {
            conditions.add("${MediaStore.MediaColumns.DATE_MODIFIED} > ?")
        }
        if (mimeFilter != null) {
            conditions.add("${MediaStore.MediaColumns.MIME_TYPE} LIKE '$mimeFilter%'")
        }
        return if (conditions.isEmpty()) null else conditions.joinToString(" AND ")
    }

    private fun getSortOrder(sort: SortField): String = when (sort) {
        SortField.DATE_MODIFIED_DESC ->
            "${MediaStore.MediaColumns.DATE_MODIFIED} DESC"
        SortField.DATE_MODIFIED_ASC ->
            "${MediaStore.MediaColumns.DATE_MODIFIED} ASC"
        SortField.SIZE_DESC ->
            "${MediaStore.MediaColumns.SIZE} DESC"
        SortField.NAME_ASC ->
            "${MediaStore.MediaColumns.DISPLAY_NAME} ASC"
        SortField.DATE_ADDED_DESC ->
            "${MediaStore.MediaColumns.DATE_ADDED} DESC"
    }

    fun stopObserving() {
        changeObservers.values.forEach {
            contentResolver.unregisterContentObserver(it)
        }
        changeObservers.clear()
    }

    fun shutdown() {
        stopObserving()
        integrationScope.cancel()
    }

    enum class SortField {
        DATE_MODIFIED_DESC, DATE_MODIFIED_ASC,
        SIZE_DESC, NAME_ASC, DATE_ADDED_DESC
    }
}

// ============================================================
// SECTION 10: R-168 - DIRECT PATH OPTIMIZATION
// ============================================================

/**
 * R-168: Direct path optimization (where permitted)
 * Fastest possible file access - SAF bypass where allowed
 */
class DirectPathOptimizationEngine(private val context: Context) {

    private val statEngine = LowLevelFileStatEngine()
    private val storageScheduler = StorageAwareScheduler()

    // Path resolution cache
    private val pathCache = LruCache<String, ResolvedPath>(1000)

    // -------------------------------------------------------
    // Path resolution - fastest available method find karo
    // -------------------------------------------------------
    fun resolveOptimalPath(input: String): ResolvedPath {
        // Cache check
        pathCache.get(input)?.let { return it }

        val resolved = when {
            // Already absolute direct path
            input.startsWith("/") && File(input).canRead() -> {
                ResolvedPath(
                    originalInput = input,
                    resolvedPath = input,
                    accessMethod = AccessMethod.DIRECT_PATH,
                    isReadable = true,
                    isWritable = File(input).canWrite()
                )
            }

            // Content URI
            input.startsWith("content://") -> {
                resolveContentUri(Uri.parse(input))
            }

            // Media path
            input.startsWith("media://") -> {
                ResolvedPath(
                    originalInput = input,
                    resolvedPath = input,
                    accessMethod = AccessMethod.MEDIA_STORE,
                    isReadable = true,
                    isWritable = false
                )
            }

            // File URI
            input.startsWith("file://") -> {
                val path = Uri.parse(input).path ?: input
                ResolvedPath(
                    originalInput = input,
                    resolvedPath = path,
                    accessMethod = AccessMethod.DIRECT_PATH,
                    isReadable = File(path).canRead(),
                    isWritable = File(path).canWrite()
                )
            }

            else -> ResolvedPath(
                originalInput = input,
                resolvedPath = input,
                accessMethod = AccessMethod.UNKNOWN,
                isReadable = false,
                isWritable = false
            )
        }

        pathCache.put(input, resolved)
        return resolved
    }

    // -------------------------------------------------------
    // Content URI ko direct path mein resolve karo (where possible)
    // -------------------------------------------------------
    private fun resolveContentUri(uri: Uri): ResolvedPath {

        // MediaStore URI se direct path (Android 10 se restricted)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            val directPath = getDirectPathFromMediaStore(uri)
            if (directPath != null) {
                return ResolvedPath(
                    originalInput = uri.toString(),
                    resolvedPath = directPath,
                    accessMethod = AccessMethod.DIRECT_PATH,
                    isReadable = File(directPath).canRead(),
                    isWritable = File(directPath).canWrite()
                )
            }
        }

        // File provider URI resolution
        val filePath = resolveFileProviderUri(uri)
        if (filePath != null) {
            return ResolvedPath(
                originalInput = uri.toString(),
                resolvedPath = filePath,
                accessMethod = AccessMethod.DIRECT_PATH,
                isReadable = File(filePath).canRead(),
                isWritable = File(filePath).canWrite()
            )
        }

        // Fallback - content URI as-is
        return ResolvedPath(
            originalInput = uri.toString(),
            resolvedPath = uri.toString(),
            accessMethod = AccessMethod.SAF_URI,
            isReadable = true,
            isWritable = false
        )
    }

    // -------------------------------------------------------
    // MediaStore se direct path (pre-Android 10)
    // -------------------------------------------------------
    private fun getDirectPathFromMediaStore(uri: Uri): String? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) return null

        return try {
            context.contentResolver.query(
                uri,
                arrayOf(MediaStore.MediaColumns.DATA),
                null, null, null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val colData = cursor.getColumnIndex(MediaStore.MediaColumns.DATA)
                    if (colData >= 0) cursor.getString(colData) else null
                } else null
            }
        } catch (e: Exception) { null }
    }

    // -------------------------------------------------------
    // FileProvider URI resolve karo
    // -------------------------------------------------------
    private fun resolveFileProviderUri(uri: Uri): String? {
        // FileProvider URIs usually content://authority/files/... format mein
        // Cache file paths resolve karne ki koshish karo
        val path = uri.path ?: return null

        // Common FileProvider path patterns
        val appFilesPath = context.filesDir.absolutePath
        val appCachePath = context.cacheDir.absolutePath

        return when {
            path.contains("/files/") -> {
                val relative = path.substringAfter("/files/")
                "$appFilesPath/$relative".takeIf { File(it).exists() }
            }
            path.contains("/cache/") -> {
                val relative = path.substringAfter("/cache/")
                "$appCachePath/$relative".takeIf { File(it).exists() }
            }
            else -> null
        }
    }

    // -------------------------------------------------------
    // Fast file read - optimal method use karo
    // -------------------------------------------------------
    suspend fun readFileOptimal(
        input: String,
        maxSizeBytes: Long = 100 * 1024 * 1024L // 100MB limit
    ): ByteArray? = withContext(Dispatchers.IO) {

        val resolved = resolveOptimalPath(input)

        when (resolved.accessMethod) {
            AccessMethod.DIRECT_PATH -> {
                val file = File(resolved.resolvedPath)
                if (!file.exists() || !file.canRead()) return@withContext null
                if (file.length() > maxSizeBytes) return@withContext null

                // Storage type ke hisaab se optimal read
                val ioParams = storageScheduler.getOptimalIOParams()

                BufferedInputStream(
                    FileInputStream(file),
                    ioParams.sequentialBufferSizeKb * 1024
                ).use { it.readBytes() }
            }
            AccessMethod.SAF_URI, AccessMethod.MEDIA_STORE -> {
                try {
                    context.contentResolver
                        .openInputStream(Uri.parse(resolved.originalInput))
                        ?.use { BufferedInputStream(it, 64 * 1024).readBytes() }
                } catch (e: Exception) { null }
            }
            else -> null
        }
    }

    // -------------------------------------------------------
    // Canonical path - fast + cached
    // -------------------------------------------------------
    private val canonicalCache = LruCache<String, String>(2000)

    fun getCanonicalPath(path: String): String {
        canonicalCache.get(path)?.let { return it }

        val canonical = try {
            File(path).canonicalPath
        } catch (e: IOException) {
            path
        }

        canonicalCache.put(path, canonical)
        return canonical
    }

    // -------------------------------------------------------
    // Path normalization - fast
    // -------------------------------------------------------
    fun normalizePath(path: String): String {
        // Fast path normalization bina File.canonicalPath ke
        val segments = path.split("/")
        val result = ArrayDeque<String>()

        for (segment in segments) {
            when (segment) {
                "", "." -> continue // Skip empty and current dir
                ".." -> if (result.isNotEmpty()) result.removeLast() // Go up
                else -> result.addLast(segment)
            }
        }

        return "/" + result.joinToString("/")
    }

    // -------------------------------------------------------
    // Bulk path resolution - parallel
    // -------------------------------------------------------
    suspend fun resolvePathsBulk(
        inputs: List<String>
    ): Map<String, ResolvedPath> = withContext(Dispatchers.Default) {

        val results = ConcurrentHashMap<String, ResolvedPath>(inputs.size)

        inputs.map { input ->
            async(Dispatchers.IO) {
                results[input] = resolveOptimalPath(input)
            }
        }.awaitAll()

        results
    }

    // -------------------------------------------------------
    // Check if direct path available (Android version + permission aware)
    // -------------------------------------------------------
    fun canUseDirectPath(path: String): Boolean {
        return when {
            // App-specific directories - always direct
            path.startsWith(context.filesDir.absolutePath) -> true
            path.startsWith(context.cacheDir.absolutePath) -> true

            // External storage - depends on Android version
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.R -> {
                // Android 11+ - only app-specific or All Files permission
                Environment.isExternalStorageManager() ||
                isAppSpecificExternalPath(path)
            }

            Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q -> {
                // Android 10 - READ_EXTERNAL_STORAGE with restrictions
                File(path).canRead()
            }

            else -> {
                // Android 9 and below - direct access with permission
                File(path).canRead()
            }
        }
    }

    private fun isAppSpecificExternalPath(path: String): Boolean {
        val extFilesDir = context.getExternalFilesDir(null)?.absolutePath ?: return false
        return path.startsWith(extFilesDir)
    }

    fun clearCaches() {
        pathCache.evictAll()
        canonicalCache.evictAll()
    }
}

data class ResolvedPath(
    val originalInput: String,
    val resolvedPath: String,
    val accessMethod: AccessMethod,
    val isReadable: Boolean,
    val isWritable: Boolean
)

enum class AccessMethod {
    DIRECT_PATH,   // Fastest - direct File API
    SAF_URI,       // SAF - slower but universal
    MEDIA_STORE,   // MediaStore ContentProvider
    UNKNOWN
}

// ============================================================
// SECTION 11: PHASE R - MAIN ORCHESTRATOR
// ============================================================

/**
 * Phase R sab components ko coordinate karta hai
 */
class PhaseROrchestrator(private val context: Context) {

    // All Phase R components
    val statEngine = LowLevelFileStatEngine()
    val inodeDetector = InodeChangeDetectionEngine(statEngine)
    val pageCacheEngine = PageCacheAwareEngine()
    val journalEngine = FilesystemJournalAwareEngine(context)
    val storageScheduler = StorageAwareScheduler()
    val fileObserver = EfficientFileObserverEngine(context)
    val scopedStorage = ScopedStorageOptimizationEngine(context)
    val safEngine = SAFOptimizationEngine(context)
    val mediaStore = MediaStoreIntegrationEngine(context)
    val directPath = DirectPathOptimizationEngine(context)

    private val orchestratorScope = CoroutineScope(
        Dispatchers.Default + SupervisorJob()
    )

    // -------------------------------------------------------
    // Initialize Phase R
    // -------------------------------------------------------
    suspend fun initialize() {
        android.util.Log.i("PhaseR", "Initializing Phase R: Advanced Linux/Android...")

        // Storage type detect karo
        val storageType = storageScheduler.detectStorageType()
        android.util.Log.i("PhaseR", "Storage: $storageType")

        // Filesystem detect karo
        val fsInfo = journalEngine.detectFilesystem(
            Environment.getExternalStorageDirectory().absolutePath
        )
        android.util.Log.i("PhaseR", "Filesystem: ${fsInfo.filesystemType}")

        // Media change observer setup karo
        mediaStore.observeMediaChanges(
            ScopedStorageOptimizationEngine.MediaStoreType.IMAGES
        ) {
            android.util.Log.d("PhaseR", "Media changed - Images")
        }

        // FileObserver start karo common paths ke liye
        val watchPaths = listOf(
            Environment.getExternalStorageDirectory().absolutePath + "/DCIM",
            Environment.getExternalStorageDirectory().absolutePath + "/Downloads",
            Environment.getExternalStorageDirectory().absolutePath + "/Pictures"
        )

        watchPaths.forEach { path ->
            if (File(path).exists()) {
                fileObserver.watchDirectory(path)
            }
        }

        // FileObserver events collect karo
        orchestratorScope.launch {
            fileObserver.events.collect { event ->
                handleFileSystemEvent(event)
            }
        }

        android.util.Log.i("PhaseR", "Phase R initialization complete!")
    }

    // -------------------------------------------------------
    // Unified file info - best method use karo
    // -------------------------------------------------------
    suspend fun getFileInfo(path: String): UnifiedFileInfo? {
        val resolvedPath = directPath.resolveOptimalPath(path)

        return when (resolvedPath.accessMethod) {
            AccessMethod.DIRECT_PATH -> {
                val stat = statEngine.lstat(resolvedPath.resolvedPath)
                    ?: return null

                UnifiedFileInfo(
                    path = path,
                    name = File(path).name,
                    size = stat.size,
                    isDirectory = stat.isDirectory,
                    isSymlink = stat.isSymlink,
                    lastModified = stat.mtime,
                    permissions = statEngine.getPermissionString(stat.mode),
                    inode = stat.inode,
                    accessMethod = AccessMethod.DIRECT_PATH
                )
            }
            AccessMethod.SAF_URI -> {
                val docInfo = safEngine.getDocumentInfo(Uri.parse(path))
                    ?: return null

                UnifiedFileInfo(
                    path = path,
                    name = docInfo.name,
                    size = docInfo.size,
                    isDirectory = docInfo.isDirectory,
                    isSymlink = false,
                    lastModified = docInfo.lastModified,
                    permissions = if (docInfo.isWritable) "rw" else "r",
                    inode = 0L,
                    accessMethod = AccessMethod.SAF_URI
                )
            }
            else -> null
        }
    }

    // -------------------------------------------------------
    // Smart directory scan - best method choose karo
    // -------------------------------------------------------
    suspend fun scanDirectory(
        path: String,
        sortByInode: Boolean = false
    ): List<UnifiedFileInfo> = withContext(Dispatchers.IO) {

        if (directPath.canUseDirectPath(path)) {
            // Direct path - fastest
            val dir = File(path)
            val files = dir.listFiles() ?: return@withContext emptyList()

            val paths = files.map { it.absolutePath }

            // Storage type ke hisaab se sort
            val orderedPaths = if (sortByInode) {
                storageScheduler.getOptimalScanOrder(paths)
            } else paths

            // Batch stat - parallel
            val stats = statEngine.batchStat(
                orderedPaths,
                storageScheduler.getOptimalThreadCount()
            )

            orderedPaths.mapNotNull { filePath ->
                val stat = stats[filePath] ?: return@mapNotNull null
                UnifiedFileInfo(
                    path = filePath,
                    name = File(filePath).name,
                    size = stat.size,
                    isDirectory = stat.isDirectory,
                    isSymlink = stat.isSymlink,
                    lastModified = stat.mtime,
                    permissions = statEngine.getPermissionString(stat.mode),
                    inode = stat.inode,
                    accessMethod = AccessMethod.DIRECT_PATH
                )
            }
        } else {
            // SAF path
            val uri = Uri.parse(path)
            safEngine.listDocuments(uri).map { doc ->
                UnifiedFileInfo(
                    path = doc.uri.toString(),
                    name = doc.name,
                    size = doc.size,
                    isDirectory = doc.isDirectory,
                    isSymlink = false,
                    lastModified = doc.lastModified,
                    permissions = if (doc.isWritable) "rw" else "r",
                    inode = 0L,
                    accessMethod = AccessMethod.SAF_URI
                )
            }
        }
    }

    // -------------------------------------------------------
    // File system event handler
    // -------------------------------------------------------
    private fun handleFileSystemEvent(
        event: EfficientFileObserverEngine.FileSystemEvent
    ) {
        android.util.Log.d("PhaseR",
            "FS Event: ${event.eventType} -> ${event.path}")

        // Inode snapshot update karo
        if (event.eventType == EfficientFileObserverEngine.EventType.MODIFY ||
            event.eventType == EfficientFileObserverEngine.EventType.CREATE) {
            inodeDetector.updateSnapshot(event.path)
        }
    }

    // -------------------------------------------------------
    // Performance report
    // -------------------------------------------------------
    suspend fun getPerformanceReport(): PhaseRReport {
        val storageType = storageScheduler.detectStorageType()
        val ioParams = storageScheduler.getOptimalIOParams()
        val threadCount = storageScheduler.getOptimalThreadCount()
        val fsInfo = journalEngine.detectFilesystem(
            Environment.getExternalStorageDirectory().absolutePath
        )

        return PhaseRReport(
            storageType = storageType.name,
            filesystemType = fsInfo.filesystemType.name,
            isJournaled = fsInfo.isJournaled,
            optimalThreadCount = threadCount,
            optimalBufferSizeKb = ioParams.sequentialBufferSizeKb,
            preferSequentialIO = ioParams.preferSequential,
            activeFileObservers = fileObserver.observers.size,
            inodeDatabaseSize = inodeDetector.inodeDatabase.size,
            safCacheSize = 0 // SAF cache size
        )
    }

    fun shutdown() {
        fileObserver.stopAllWatching()
        mediaStore.shutdown()
        directPath.clearCaches()
        orchestratorScope.cancel()
        android.util.Log.i("PhaseR", "Phase R shutdown complete")
    }
}

// -------------------------------------------------------
// Unified File Info - all methods ka common output
// -------------------------------------------------------
data class UnifiedFileInfo(
    val path: String,
    val name: String,
    val size: Long,
    val isDirectory: Boolean,
    val isSymlink: Boolean,
    val lastModified: Long,
    val permissions: String,
    val inode: Long,
    val accessMethod: AccessMethod
) {
    val sizeFormatted: String get() = when {
        size < 1024 -> "$size B"
        size < 1024 * 1024 -> "${size / 1024} KB"
        size < 1024 * 1024 * 1024 -> "${size / (1024 * 1024)} MB"
        else -> "${size / (1024 * 1024 * 1024)} GB"
    }
}

data class PhaseRReport(
    val storageType: String,
    val filesystemType: String,
    val isJournaled: Boolean,
    val optimalThreadCount: Int,
    val optimalBufferSizeKb: Int,
    val preferSequentialIO: Boolean,
    val activeFileObservers: Int,
    val inodeDatabaseSize: Int,
    val safCacheSize: Int
) {
    fun prettyPrint(): String = buildString {
        appendLine("=== PHASE R PERFORMANCE REPORT ===")
        appendLine("Storage Type        : $storageType")
        appendLine("Filesystem          : $filesystemType")
        appendLine("Journaled           : $isJournaled")
        appendLine("Optimal Threads     : $optimalThreadCount")
        appendLine("Buffer Size         : ${optimalBufferSizeKb}KB")
        appendLine("Prefer Sequential   : $preferSequentialIO")
        appendLine("Active Observers    : $activeFileObservers")
        appendLine("Inode DB Size       : $inodeDatabaseSize")
        appendLine("===================================")
    }
}

// ============================================================
// USAGE EXAMPLE
// ============================================================


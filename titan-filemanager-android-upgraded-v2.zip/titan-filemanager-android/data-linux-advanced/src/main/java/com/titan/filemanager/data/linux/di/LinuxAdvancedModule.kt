package com.titan.filemanager.data.linux.di

import android.content.Context
import com.titan.filemanager.data.linux.PhaseROrchestrator
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Hilt DI module for Phase R — Advanced Linux/Android techniques.
 *
 * Provides the [PhaseROrchestrator] which wires all R-159 through R-168
 * engines. Individual engines (LowLevelFileStatEngine,
 * InodeChangeDetectionEngine, PageCacheAwareEngine, etc.) are created
 * by the orchestrator and exposed via its public properties.
 */
@Module
@InstallIn(SingletonComponent::class)
object LinuxAdvancedModule {

    @Provides
    @Singleton
    fun providePhaseROrchestrator(@ApplicationContext context: Context): PhaseROrchestrator =
        PhaseROrchestrator(context)
}

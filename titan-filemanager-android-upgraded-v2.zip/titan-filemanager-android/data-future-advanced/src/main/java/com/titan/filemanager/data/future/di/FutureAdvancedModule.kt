package com.titan.filemanager.data.future.di

import android.content.Context
import com.titan.filemanager.data.future.PhaseSOrchestrator
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Hilt DI module for Phase S — Future-level ideas.
 *
 * Provides the [PhaseSOrchestrator] which wires all S-169 through S-180
 * engines. Individual engines (NativeScanEngine, StructuredConcurrencyEngine,
 * ReactiveFileManagerStreams, PluginScanPipeline, etc.) are created by the
 * orchestrator and exposed via its public properties.
 */
@Module
@InstallIn(SingletonComponent::class)
object FutureAdvancedModule {

    @Provides
    @Singleton
    fun providePhaseSOrchestrator(@ApplicationContext context: Context): PhaseSOrchestrator =
        PhaseSOrchestrator(context)
}

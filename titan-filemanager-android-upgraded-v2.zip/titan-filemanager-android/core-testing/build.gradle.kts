// :core:testing — test fixtures, fakes, and JUnit rules
plugins {
    id("titan.android.library")
}

android {
    namespace = "com.titan.filemanager.core.testing"
}

dependencies {
    api(project(":core:common"))
    api(project(":core:model"))
    api(project(":core:database"))
    api(libs.junit5)
    api(libs.truth)
    api(libs.turbine)
    api(libs.mockk)
    api(libs.kotlinx.coroutines.test)

    implementation(libs.timber)
    implementation("androidx.room:room-testing:2.6.1")
    implementation("androidx.test:core:1.6.1")
    implementation("androidx.test.ext:junit:1.2.1")
    implementation("org.robolectric:robolectric:4.13")
}

package com.titan.filemanager.core.testing.fixture

import com.titan.filemanager.core.model.file.FileItem

/**
 * Test data builders for [FileItem] — keep tests concise + readable.
 *
 * Builder pattern keeps the test data DRY: define sensible defaults
 * once, override only what matters per test.
 *
 * Usage:
 * ```
 * val photo = FileItemFixture.aFileItem(
 *     name = "vacation.jpg",
 *     size = 1_500_000,
 *     mimeType = "image/jpeg",
 * )
 *
 * val dir = FileItemFixture.aDirectory(
 *     name = "DCIM",
 * )
 * ```
 */
object FileItemFixture {

    private var counter = 0L

    /**
     * Build a regular file [FileItem] with sensible defaults.
     */
    fun aFileItem(
        path: String = "/sdcard/file_${counter}",
        name: String = "file_${counter}",
        stableId: Long = counter,
        size: Long = 1024L,
        modifiedAt: Long = 1_700_000_000_000L + counter * 1000,
        mimeType: String? = null,
        isHidden: Boolean = false,
        isBookmarked: Boolean = false,
        tags: List<String> = emptyList(),
    ): FileItem {
        counter++
        return FileItem(
            path = path,
            name = name,
            stableId = stableId,
            size = size,
            modifiedAt = modifiedAt,
            isDirectory = false,
            mimeType = mimeType,
            thumbnailPath = null,
            isHidden = isHidden,
            isBookmarked = isBookmarked,
            tags = tags,
        )
    }

    /**
     * Build a directory [FileItem] with sensible defaults.
     */
    fun aDirectory(
        path: String = "/sdcard/dir_${counter}",
        name: String = "dir_${counter}",
        stableId: Long = counter,
        modifiedAt: Long = 1_700_000_000_000L + counter * 1000,
        isHidden: Boolean = false,
        isBookmarked: Boolean = false,
    ): FileItem {
        counter++
        return FileItem(
            path = path,
            name = name,
            stableId = stableId,
            size = 0L,
            modifiedAt = modifiedAt,
            isDirectory = true,
            mimeType = null,
            thumbnailPath = null,
            isHidden = isHidden,
            isBookmarked = isBookmarked,
            tags = emptyList(),
        )
    }

    /**
     * Build a list of N file items with sequential names + sizes.
     */
    fun aFileList(count: Int): List<FileItem> =
        (1..count).map { aFileItem(name = "file_$it.txt", size = it * 1000L) }

    /**
     * Reset the counter — call in `@Before` to keep IDs deterministic.
     */
    fun reset() {
        counter = 0L
    }
}

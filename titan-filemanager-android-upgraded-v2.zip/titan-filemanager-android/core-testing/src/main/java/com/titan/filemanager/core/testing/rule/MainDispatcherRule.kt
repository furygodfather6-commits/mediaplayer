package com.titan.filemanager.core.testing.rule

import com.titan.filemanager.core.common.dispatcher.DispatcherProvider
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestCoroutineScheduler
import kotlinx.coroutines.test.TestDispatcher
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.setMain
import org.junit.rules.TestWatcher
import org.junit.runner.Description

/**
 * JUnit rule that replaces [Dispatchers.Main] with a [TestDispatcher] so
 * ViewModels and other `withContext(Dispatchers.Main)` code can be tested
 * with virtual time.
 *
 * Usage:
 * ```
 * @OptIn(ExperimentalCoroutinesApi::class)
 * class MyViewModelTest {
 *     @get:Rule val mainDispatcherRule = MainDispatcherRule()
 *
 *     @Test
 *     fun `should emit loading then success`() = runTest(mainDispatcherRule.scheduler) {
 *         val vm = MyViewModel(...)
 *         vm.state.test {
 *             assertEquals(State.Loading, awaitItem())
 *             assertEquals(State.Success(...), awaitItem())
 *         }
 *     }
 * }
 * ```
 *
 * Provides a [DispatcherProvider] via [dispatcherProvider] that uses the
 * same [TestDispatcher] for IO/Default/Main — so you can advance virtual
 * time from a single place.
 */
@OptIn(ExperimentalCoroutinesApi::class)
class MainDispatcherRule(
    val scheduler: TestCoroutineScheduler = TestCoroutineScheduler(),
    val dispatcher: TestDispatcher = StandardTestDispatcher(scheduler),
) : TestWatcher() {

    /**
     * DispatcherProvider that uses [dispatcher] for all 5 dispatchers.
     *
     * Inject this into the class under test:
     * ```
     * val useCase = MyUseCase(dispatchers = mainDispatcherRule.dispatcherProvider, ...)
     * ```
     */
    val dispatcherProvider: DispatcherProvider = TestDispatcherProvider(dispatcher)

    override fun starting(description: Description) {
        Dispatchers.setMain(dispatcher)
    }

    override fun finished(description: Description) {
        Dispatchers.resetMain()
    }
}

/**
 * Test [DispatcherProvider] — uses the same [TestDispatcher] for every
 * dispatch type so virtual time advances predictably.
 *
 * Optionally pass [unconfined] = true to use [UnconfinedTestDispatcher]
 * for an even more "synchronous" feel (no context switching).
 */
@OptIn(ExperimentalCoroutinesApi::class)
class TestDispatcherProvider(
    private val testDispatcher: TestDispatcher,
) : DispatcherProvider {
    override val main: CoroutineDispatcher = testDispatcher
    override val mainImmediate: CoroutineDispatcher = testDispatcher
    override val io: CoroutineDispatcher = testDispatcher
    override val default: CoroutineDispatcher = testDispatcher
    override val unconfined: CoroutineDispatcher = testDispatcher
}

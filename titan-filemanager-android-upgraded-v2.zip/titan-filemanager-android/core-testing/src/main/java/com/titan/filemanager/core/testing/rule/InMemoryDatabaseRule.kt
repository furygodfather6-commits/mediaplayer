package com.titan.filemanager.core.testing.rule

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.titan.filemanager.core.database.TitanDatabase
import kotlinx.coroutines.runBlocking
import org.junit.rules.ExternalResource
import org.junit.runner.Description
import org.junit.runners.model.Statement

/**
 * JUnit rule that creates an in-memory Room database for testing.
 *
 * The database is created fresh before each test and closed after — no
 * state leaks between tests.
 *
 * Usage:
 * ```
 * class FileDaoTest {
 *     @get:Rule val dbRule = InMemoryDatabaseRule()
 *     private lateinit var dao: FileDao
 *
 *     @Before fun setup() { dao = dbRule.db.fileDao() }
 *
 *     @Test fun `should insert and retrieve`() = runTest {
 *         dao.upsert(fileEntity(path = "/sdcard/foo"))
 *         assertThat(dao.getByPath("/sdcard/foo")).isNotNull()
 *     }
 * }
 * ```
 *
 * Note: requires Robolectric (or an Android instrumented test runner)
 * because Room needs a Context. Unit tests should add `@RunWith(
 * RobolectricTestRunner::class)`.
 */
class InMemoryDatabaseRule : ExternalResource() {

    lateinit var db: TitanDatabase
        private set

    override fun before() {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        db = Room.inMemoryDatabaseBuilder(
            context,
            TitanDatabase::class.java,
        ).allowMainThreadQueries().build()
    }

    override fun after() {
        db.close()
    }
}

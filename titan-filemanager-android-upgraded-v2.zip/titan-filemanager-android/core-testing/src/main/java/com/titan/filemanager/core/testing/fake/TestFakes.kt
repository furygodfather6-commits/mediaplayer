package com.titan.filemanager.core.testing.fake

import com.titan.filemanager.core.common.dispatcher.DispatcherProvider
import com.titan.filemanager.core.common.logger.Logger
import com.titan.filemanager.core.common.time.TimeProvider
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestDispatcher
import kotlinx.datetime.Instant

/**
 * Pre-built fakes + helpers for tests. Import these constants directly:
 *
 * ```
 * import com.titan.filemanager.core.testing.fake.TestFakes.*
 *
 * class MyTest {
 *     private val logger = NoopLogger
 *     private val time = FixedTimeProvider(Instant.parse("2026-01-01T00:00:00Z"))
 * }
 * ```
 */
object TestFakes {

    /**
     * No-op logger — discards everything. Use in unit tests where
     * logging is noise.
     */
    val NoopLogger: Logger = object : Logger {
        override fun v(throwable: Throwable?, message: () -> String) = Unit
        override fun d(throwable: Throwable?, message: () -> String) = Unit
        override fun i(throwable: Throwable?, message: () -> String) = Unit
        override fun w(throwable: Throwable?, message: () -> String) = Unit
        override fun e(throwable: Throwable?, message: () -> String) = Unit
        override fun wtf(throwable: Throwable?, message: () -> String) = Unit
    }
}

/**
 * TimeProvider that always returns the same [Instant] — useful for
 * deterministic tests of cache expiry, sort order, etc.
 */
class FixedTimeProvider(
    private val fixedInstant: Instant,
) : TimeProvider {
    override fun now(): Instant = fixedInstant
    override fun nowEpochMillis(): Long = fixedInstant.toEpochMilliseconds()
}

/**
 * TimeProvider that lets tests advance time manually.
 */
class MutableTimeProvider(
    initial: Instant = Instant.fromEpochMilliseconds(0L),
) : TimeProvider {

    private var current: Instant = initial

    fun set(instant: Instant) {
        current = instant
    }

    fun advanceMillis(milliseconds: Long) {
        current = Instant.fromEpochMilliseconds(
            current.toEpochMilliseconds() + milliseconds,
        )
    }

    fun advanceSeconds(seconds: Long) = advanceMillis(seconds * 1000)
    fun advanceMinutes(minutes: Long) = advanceMillis(minutes * 60 * 1000)
    fun advanceHours(hours: Long) = advanceMillis(hours * 60 * 60 * 1000)
    fun advanceDays(days: Long) = advanceMillis(days * 24 * 60 * 60 * 1000)

    override fun now(): Instant = current
    override fun nowEpochMillis(): Long = current.toEpochMilliseconds()
}

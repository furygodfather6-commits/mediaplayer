package com.titan.filemanager.data.search.ranker

import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.domain.search.MatchType
import com.titan.filemanager.domain.search.SearchQuery
import com.titan.filemanager.domain.search.SearchResult
import com.titan.filemanager.domain.search.SearchSortOrder
import javax.inject.Inject
import javax.inject.Singleton

/**
 * v2 — Ranks + sorts search results.
 *
 * Improvements over v1:
 *  1. **Fuzzy match type** — Levenshtein distance ≤ 2 → FUZZY
 *  2. **Sort order support** — relevance / name / size / date
 *  3. **Date range filter** — modified after / before
 *  4. **Hidden file filter** — include / exclude hidden files
 *  5. **Matched term tracking** — which part of the name matched
 *
 * Score = Match (40%) + Relevance (25%) + Recency (15%) + Usage (10%) + Depth (10%)
 */
@Singleton
class SearchRanker @Inject constructor() {

    fun rank(
        items: List<FileItem>,
        query: SearchQuery,
    ): List<SearchResult> {
        val queryLower = query.text.lowercase()
        val now = System.currentTimeMillis()

        return items
            .filter { item -> applyFilters(item, query) }
            .map { item ->
                val matchType = computeMatchType(item.name, queryLower)
                val matchedTerm = computeMatchedTerm(item.name, queryLower, matchType)
                val score = computeScore(item, queryLower, matchType, now)
                SearchResult(
                    file = item,
                    score = score,
                    matchType = matchType,
                    matchedTerm = matchedTerm,
                )
            }
            .sortedWith(comparator(query.sortOrder))
    }

    private fun applyFilters(item: FileItem, query: SearchQuery): Boolean {
        // Hidden file filter
        if (!query.includeHidden && item.isHidden) return false
        // MIME filter
        val mimeFilter = query.mimeFilter
        if (mimeFilter != null && item.mimeType?.startsWith(mimeFilter) != true) return false
        // Path filter
        val pathFilter = query.pathFilter
        if (pathFilter != null && !item.path.startsWith(pathFilter)) return false
        // Size filter
        val minSize = query.minSize
        if (minSize != null && item.size < minSize) return false
        val maxSize = query.maxSize
        if (maxSize != null && item.size > maxSize) return false
        // Date range filter
        val modifiedAfter = query.modifiedAfter
        if (modifiedAfter != null && item.modifiedAt < modifiedAfter) return false
        val modifiedBefore = query.modifiedBefore
        if (modifiedBefore != null && item.modifiedAt > modifiedBefore) return false
        return true
    }

    private fun computeMatchType(name: String, query: String): MatchType {
        val nameLower = name.lowercase()
        return when {
            nameLower == query -> MatchType.EXACT_NAME
            nameLower.startsWith(query) -> MatchType.PREFIX
            nameLower.contains(query) -> MatchType.CONTAINS
            levenshtein(query, nameLower.substringBeforeLast('.')) <= 2 -> MatchType.FUZZY
            else -> MatchType.CONTAINS
        }
    }

    private fun computeMatchedTerm(name: String, query: String, matchType: MatchType): String? {
        val nameLower = name.lowercase()
        return when (matchType) {
            MatchType.EXACT_NAME -> name
            MatchType.PREFIX -> name.substring(0, query.length.coerceAtMost(name.length))
            MatchType.CONTAINS -> {
                val idx = nameLower.indexOf(query)
                if (idx >= 0) name.substring(idx, (idx + query.length).coerceAtMost(name.length)) else null
            }
            MatchType.FUZZY -> name
            MatchType.CONTENT -> null
        }
    }

    private fun computeScore(
        item: FileItem,
        query: String,
        matchType: MatchType,
        now: Long,
    ): Float {
        // Match (40%)
        val matchScore = matchType.weight * 0.4f

        // Relevance (25%) — shorter names rank higher for same match
        val nameLength = item.name.length.coerceAtLeast(1)
        val relevance = (query.length.toFloat() / nameLength).coerceIn(0f, 1f) * 0.25f

        // Recency (15%) — files modified in last 7 days get full bonus
        val sevenDaysMs = 7L * 24 * 60 * 60 * 1000
        val ageMs = now - item.modifiedAt
        val recency = if (ageMs < sevenDaysMs) {
            (1f - (ageMs.toFloat() / sevenDaysMs)).coerceIn(0f, 1f) * 0.15f
        } else 0f

        // Usage (10%) — placeholder (would integrate with RecentFileRepository)
        val usage = 0f

        // Depth (10%) — shallow paths (fewer /) rank higher
        val depth = item.path.count { it == '/' }
        val depthScore = (1f / (depth + 1).coerceAtLeast(1)) * 0.10f

        return matchScore + relevance + recency + usage + depthScore
    }

    private fun comparator(sortOrder: SearchSortOrder): Comparator<SearchResult> = when (sortOrder) {
        SearchSortOrder.RELEVANCE -> compareByDescending<SearchResult> { it.score }
        SearchSortOrder.NAME_AZ -> compareBy { it.file.name.lowercase() }
        SearchSortOrder.NAME_ZA -> compareByDescending { it.file.name.lowercase() }
        SearchSortOrder.SIZE_LARGEST -> compareByDescending { it.file.size }
        SearchSortOrder.SIZE_SMALLEST -> compareBy { it.file.size }
        SearchSortOrder.NEWEST -> compareByDescending { it.file.modifiedAt }
        SearchSortOrder.OLDEST -> compareBy { it.file.modifiedAt }
    }

    private fun levenshtein(a: String, b: String): Int {
        val m = a.length
        val n = b.length
        if (m == 0) return n
        if (n == 0) return m
        val dp = Array(m + 1) { IntArray(n + 1) }
        for (i in 0..m) dp[i][0] = i
        for (j in 0..n) dp[0][j] = j
        for (i in 1..m) {
            for (j in 1..n) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                dp[i][j] = minOf(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost)
            }
        }
        return dp[m][n]
    }
}

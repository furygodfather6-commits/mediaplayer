package com.titan.filemanager.data.search.repository

import com.titan.filemanager.data.search.engine.SearchEngine
import com.titan.filemanager.domain.search.IndexStats
import com.titan.filemanager.domain.search.IndexingProgress
import com.titan.filemanager.domain.search.SearchQuery
import com.titan.filemanager.domain.search.SearchRepository
import com.titan.filemanager.domain.search.SearchResult
import com.titan.filemanager.domain.search.SearchSuggestion
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

/**
 * v2 — Wraps [SearchEngine] with search history + suggestions + live stats.
 */
@Singleton
class DefaultSearchRepository @Inject constructor(
    private val engine: SearchEngine,
) : SearchRepository {

    override fun search(query: SearchQuery): Flow<SearchResult> = engine.search(query)

    override suspend fun searchOnce(query: SearchQuery): List<SearchResult> =
        engine.searchOnce(query)

    override suspend fun suggest(query: String, maxSuggestions: Int): List<SearchSuggestion> =
        engine.suggest(query, maxSuggestions)

    override suspend fun indexPath(path: String) {
        engine.indexPath(path)
    }

    override fun indexTree(rootPath: String): Flow<IndexingProgress> = engine.indexTree(rootPath)

    override suspend fun removeFromIndex(path: String) {
        engine.removeFromIndex(path)
    }

    override suspend fun clearIndex() {
        engine.clearIndex()
    }

    override fun observeIndexStats(): Flow<IndexStats> = engine.indexStats.map { it }

    // ── Search history ────────────────────────────────────────────

    private val _history = MutableStateFlow<List<String>>(emptyList())

    override fun observeSearchHistory(limit: Int): Flow<List<String>> =
        _history.map { it.take(limit) }

    override suspend fun recordSearch(query: String) {
        val current = _history.value.toMutableList()
        current.remove(query)
        current.add(0, query)
        if (current.size > 50) current.subList(50, current.size).clear()
        _history.value = current
    }

    override suspend fun clearSearchHistory() {
        _history.value = emptyList()
    }

    override suspend fun removeFromHistory(query: String) {
        val current = _history.value.toMutableList()
        current.remove(query)
        _history.value = current
    }

    override fun observeIsIndexing(): Flow<Boolean> = engine.isIndexing
}

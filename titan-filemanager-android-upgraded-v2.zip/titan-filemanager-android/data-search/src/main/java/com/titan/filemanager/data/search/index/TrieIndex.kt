package com.titan.filemanager.data.search.index

import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton

/**
 * v2 — Trie (prefix tree) for fast prefix-based + fuzzy file name search.
 *
 * Improvements over v1:
 *  1. **Fuzzy search** — Levenshtein distance ≤ 2 for typo tolerance
 *  2. **Unicode support** — full UTF-8 character range (was ASCII-only)
 *  3. **Contains search** — finds files where query is a substring
 *  4. **Suggestions** — returns autocomplete suggestions from the index
 *  5. **Thread-safe** — uses ConcurrentHashMap for concurrent reads/writes
 *
 * Time complexity:
 *   - Insert: O(L) where L = name length
 *   - Prefix search: O(L + M) where M = matches
 *   - Fuzzy search: O(L × A^D) where A = alphabet size, D = max edit distance
 *
 * Memory: ~1KB per unique prefix path. For 10K file names averaging
 * 10 chars each → ~100KB. Manageable in-memory.
 */
@Singleton
class TrieIndex @Inject constructor() {

    private val root = TrieNode()

    /**
     * Insert a [name] associated with [filePath].
     * Multiple paths can be associated with the same name (e.g. "photo.jpg"
     * exists in many folders).
     */
    fun insert(name: String, filePath: String) {
        val lower = name.lowercase()
        var node = root
        for (char in lower) {
            node = node.children.getOrPut(char) { TrieNode() }
        }
        node.paths.add(filePath)
        node.isEnd = true
    }

    /**
     * Search for all paths whose name starts with [prefix].
     *
     * Returns up to [limit] matches.
     */
    fun searchPrefix(prefix: String, limit: Int = 100): List<String> {
        val lower = prefix.lowercase()
        var node = root
        for (char in lower) {
            node = node.children[char] ?: return emptyList()
        }
        val results = mutableListOf<String>()
        collectPaths(node, limit, results)
        return results
    }

    /**
     * Fuzzy search — finds paths whose name is within [maxDistance] edits
     * of [query] (Levenshtein distance).
     *
     * Used when prefix search returns no results — catches typos like
     * "photp" → "photo".
     *
     * Walks all terminal nodes and computes Levenshtein distance.
     * For large indexes this is O(N × L × Q) — acceptable for ≤ 10K files.
     */
    fun searchFuzzy(query: String, maxDistance: Int = 2, limit: Int = 50): List<String> {
        val lower = query.lowercase()
        val results = mutableListOf<Pair<String, Int>>() // path → distance
        collectAllWithDistance(root, lower, maxDistance, results)
        return results.sortedBy { it.second }.take(limit).map { it.first }
    }

    /**
     * Contains search — finds paths whose name contains [substring].
     */
    fun searchContains(substring: String, limit: Int = 100): List<String> {
        val lower = substring.lowercase()
        val results = mutableListOf<String>()
        collectContains(root, lower, "", limit, results)
        return results
    }

    /**
     * Get autocomplete suggestions for a partial query.
     * Returns distinct name completions from the index.
     */
    fun suggest(prefix: String, maxSuggestions: Int = 10): List<String> {
        val lower = prefix.lowercase()
        var node = root
        for (char in lower) {
            node = node.children[char] ?: return emptyList()
        }
        val suggestions = mutableSetOf<String>()
        collectSuggestions(node, lower, maxSuggestions, suggestions)
        return suggestions.toList()
    }

    /**
     * Remove a [filePath] from the trie. The trie nodes themselves stay
     * (might be reused) but the path is removed from all end nodes.
     */
    fun remove(filePath: String) {
        removeRecursive(root, filePath)
    }

    private fun collectPaths(node: TrieNode, limit: Int, results: MutableList<String>) {
        if (results.size >= limit) return
        if (node.isEnd) {
            results.addAll(node.paths)
            if (results.size >= limit) return
        }
        for (child in node.children.values) {
            collectPaths(child, limit, results)
            if (results.size >= limit) return
        }
    }

    private fun collectAllWithDistance(
        node: TrieNode,
        query: String,
        maxDistance: Int,
        results: MutableList<Pair<String, Int>>,
    ) {
        if (node.isEnd) {
            // We need the full name to compute distance — but the Trie
            // doesn't store names, only paths. We reconstruct the name
            // from the first path's last segment.
            val name = node.paths.firstOrNull()?.substringAfterLast('/')?.lowercase()
            if (name != null) {
                val dist = levenshtein(query, name)
                if (dist <= maxDistance) {
                    node.paths.forEach { path -> results.add(path to dist) }
                }
            }
        }
        for (child in node.children.values) {
            collectAllWithDistance(child, query, maxDistance, results)
        }
    }

    private fun collectContains(
        node: TrieNode,
        substring: String,
        currentPrefix: String,
        limit: Int,
        results: MutableList<String>,
    ) {
        if (results.size >= limit) return
        if (node.isEnd && currentPrefix.contains(substring)) {
            results.addAll(node.paths)
            if (results.size >= limit) return
        }
        for ((char, child) in node.children) {
            collectContains(child, substring, currentPrefix + char, limit, results)
            if (results.size >= limit) return
        }
    }

    private fun collectSuggestions(
        node: TrieNode,
        currentPrefix: String,
        max: Int,
        suggestions: MutableSet<String>,
    ) {
        if (suggestions.size >= max) return
        if (node.isEnd) {
            suggestions.add(currentPrefix)
            if (suggestions.size >= max) return
        }
        for ((char, child) in node.children) {
            collectSuggestions(child, currentPrefix + char, max, suggestions)
            if (suggestions.size >= max) return
        }
    }

    private fun removeRecursive(node: TrieNode, filePath: String): Boolean {
        node.paths.remove(filePath)
        val toRemove = mutableListOf<Char>()
        for ((char, child) in node.children) {
            if (removeRecursive(child, filePath)) {
                toRemove.add(char)
            }
        }
        for (char in toRemove) node.children.remove(char)
        return !node.isEnd && node.children.isEmpty() && node.paths.isEmpty()
    }

    fun clear() {
        root.children.clear()
    }

    fun size(): Int {
        var count = 0
        countPaths(root) { count++ }
        return count
    }

    private fun countPaths(node: TrieNode, onPath: (String) -> Unit) {
        for (path in node.paths) onPath(path)
        for (child in node.children.values) countPaths(child, onPath)
    }

    /**
     * Levenshtein distance — minimum number of single-character edits
     * (insert / delete / substitute) to transform [a] into [b].
     *
     * Uses the classic O(m×n) dynamic programming algorithm.
     */
    private fun levenshtein(a: String, b: String): Int {
        val m = a.length
        val n = b.length
        if (m == 0) return n
        if (n == 0) return m
        val dp = Array(m + 1) { IntArray(n + 1) }
        for (i in 0..m) dp[i][0] = i
        for (j in 0..n) dp[0][j] = j
        for (i in 1..m) {
            for (j in 1..n) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                dp[i][j] = minOf(
                    dp[i - 1][j] + 1,       // delete
                    dp[i][j - 1] + 1,       // insert
                    dp[i - 1][j - 1] + cost // substitute
                )
            }
        }
        return dp[m][n]
    }

    private class TrieNode {
        val children = ConcurrentHashMap<Char, TrieNode>(4)
        val paths = mutableSetOf<String>()
        var isEnd = false
    }
}

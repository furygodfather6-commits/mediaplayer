package com.titan.filemanager.data.search.engine

import com.titan.filemanager.core.common.dispatcher.DispatcherProvider
import com.titan.filemanager.core.common.logger.Logger
import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.data.search.index.BloomFilter
import com.titan.filemanager.data.search.index.TrieIndex
import com.titan.filemanager.data.search.ranker.SearchRanker
import com.titan.filemanager.domain.search.IndexStats
import com.titan.filemanager.domain.search.IndexingProgress
import com.titan.filemanager.domain.search.MatchType
import com.titan.filemanager.domain.search.SearchQuery
import com.titan.filemanager.domain.search.SearchResult
import com.titan.filemanager.domain.search.SearchSuggestion
import com.titan.filemanager.domain.search.SearchType
import com.titan.filemanager.domain.search.SuggestionType
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.coroutineContext

/**
 * v2 — Enterprise-grade search engine.
 *
 * Improvements over v1:
 *  1. **Fuzzy search** — Levenshtein distance ≤ 2 for typo tolerance
 *  2. **Search suggestions** — autocomplete from index + history
 *  3. **searchOnce** — one-shot search returning a sorted list
 *  4. **Sort order** — relevance / name / size / date
 *  5. **Date range filter** — modified after / before
 *  6. **Hidden file filter** — include / exclude
 *  7. **Result cache** — prefix reuse for fast repeated queries
 *  8. **Live isIndexing flag** — tracks whether indexing is active
 *  9. **Cancellable** — checks coroutineContext.isActive between files
 *  10. **Better stats** — includes isIndexing flag
 */
@Singleton
class SearchEngine @Inject constructor(
    private val trie: TrieIndex,
    private val bloom: BloomFilter,
    private val ranker: SearchRanker,
    private val dispatchers: DispatcherProvider,
    private val logger: Logger,
) {

    private val _indexStats = MutableStateFlow(
        IndexStats(0, 0, 0L, 0, 0L, isIndexing = false)
    )
    val indexStats: StateFlow<IndexStats> = _indexStats.asStateFlow()

    private val _isIndexing = MutableStateFlow(false)
    val isIndexing: StateFlow<Boolean> = _isIndexing.asStateFlow()

    /** Simple LRU result cache — key is query text, value is ranked list. */
    private val resultCache = object : LinkedHashMap<String, List<SearchResult>>(32, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, List<SearchResult>>?): Boolean {
            return size > 64
        }
    }

    init {
        bloom.initialize(expectedItems = 1_000_000, falsePositiveRate = 0.01)
    }

    /**
     * Streaming search — emits ranked results one by one.
     */
    fun search(query: SearchQuery): Flow<SearchResult> = flow {
        if (query.text.isBlank()) return@flow

        // Check cache first
        val cacheKey = "${query.text.lowercase()}:${query.sortOrder}:${query.mimeFilter ?: ""}"
        val cached = synchronized(resultCache) { resultCache[cacheKey] }
        if (cached != null) {
            cached.forEach { emit(it) }
            return@flow
        }

        // 1. Bloom filter check
        if (!bloom.mightContain(query.text.lowercase()) && query.type != SearchType.FUZZY) {
            return@flow
        }

        // 2. Trie search (prefix or fuzzy)
        val paths = withContext(dispatchers.default) {
            when (query.type) {
                SearchType.FUZZY -> trie.searchFuzzy(query.text, maxDistance = 2, limit = query.maxResults * 2)
                SearchType.EXACT -> trie.searchPrefix(query.text, limit = query.maxResults * 2)
                    .filter { File(it).name.equals(query.text, ignoreCase = true) }
                SearchType.REGEX -> {
                    val pattern = try { Regex(query.text, RegexOption.IGNORE_CASE) } catch (_: Exception) { null }
                    if (pattern == null) emptyList()
                    else trie.searchContains("", limit = query.maxResults * 2)
                        .filter { pattern.containsMatchIn(File(it).name) }
                }
                SearchType.PREFIX -> {
                    val prefixResults = trie.searchPrefix(query.text, limit = query.maxResults * 2)
                    if (prefixResults.isEmpty()) {
                        trie.searchFuzzy(query.text, maxDistance = 2, limit = query.maxResults)
                    } else {
                        prefixResults
                    }
                }
            }
        }

        if (paths.isEmpty()) return@flow

        // 3. Load FileItems
        val items = withContext(dispatchers.io) {
            paths.mapNotNull { path ->
                val file = File(path)
                if (file.exists()) file.toFileItem() else null
            }
        }

        // 4. Rank + filter
        val ranked = ranker.rank(items, query)

        // 5. Cache + emit
        synchronized(resultCache) {
            resultCache[cacheKey] = ranked
        }
        ranked.take(query.maxResults).forEach { emit(it) }
    }

    /**
     * One-shot search — returns the full ranked list.
     */
    suspend fun searchOnce(query: SearchQuery): List<SearchResult> {
        val results = mutableListOf<SearchResult>()
        search(query).collect { results.add(it) }
        return results
    }

    /**
     * Get autocomplete suggestions for a partial query.
     */
    suspend fun suggest(query: String, maxSuggestions: Int = 10): List<SearchSuggestion> =
        withContext(dispatchers.default) {
            if (query.isBlank()) return@withContext emptyList()

            val suggestions = mutableListOf<SearchSuggestion>()

            // 1. From trie index
            val trieSuggestions = trie.suggest(query, maxSuggestions)
            trieSuggestions.forEach { name ->
                val count = trie.searchPrefix(name, limit = Int.MAX_VALUE).size
                suggestions.add(SearchSuggestion(name, count, SuggestionType.INDEXED))
            }

            // 2. From categories if query is short
            if (query.length <= 3) {
                val categories = listOf("photos", "videos", "music", "documents", "downloads", "archives")
                categories.filter { it.startsWith(query.lowercase()) }.forEach { cat ->
                    suggestions.add(SearchSuggestion(cat, 0, SuggestionType.CATEGORY))
                }
            }

            suggestions.take(maxSuggestions)
        }

    /**
     * Index a single file (called by FileObserver on CREATE).
     */
    suspend fun indexPath(path: String) = withContext(dispatchers.default) {
        val name = File(path).name
        trie.insert(name, path)
        bloom.add(name.lowercase())
        // Invalidate cache — new file might match existing queries
        synchronized(resultCache) { resultCache.clear() }
        refreshStats()
    }

    /**
     * Index all files under [rootPath] — emits progress.
     */
    fun indexTree(rootPath: String): Flow<IndexingProgress> = flow {
        val root = File(rootPath)
        if (!root.exists() || !root.isDirectory) return@flow

        _isIndexing.value = true
        refreshStats()

        try {
            val allFiles = mutableListOf<File>()
            walkFiles(root, allFiles)
            val total = allFiles.size
            var indexed = 0
            val startTime = System.currentTimeMillis()

            for (file in allFiles) {
                coroutineContext.ensureActive()
                trie.insert(file.name, file.absolutePath)
                bloom.add(file.name.lowercase())
                indexed++
                if (indexed % 100 == 0) {
                    val elapsed = (System.currentTimeMillis() - startTime) / 1000f
                    val rate = if (elapsed > 0) indexed / elapsed else 0f
                    emit(IndexingProgress(
                        filesIndexed = indexed,
                        totalFiles = total,
                        currentPath = file.absolutePath,
                        ratePerSecond = rate,
                    ))
                }
            }
            // Final progress
            val elapsed = (System.currentTimeMillis() - startTime) / 1000f
            emit(IndexingProgress(
                filesIndexed = indexed,
                totalFiles = total,
                currentPath = null,
                ratePerSecond = if (elapsed > 0) indexed / elapsed else 0f,
            ))
            // Invalidate cache
            synchronized(resultCache) { resultCache.clear() }
            refreshStats()
        } finally {
            _isIndexing.value = false
            refreshStats()
        }
    }

    /**
     * Remove a file from the index (called by FileObserver on DELETE).
     */
    suspend fun removeFromIndex(path: String) = withContext(dispatchers.default) {
        trie.remove(path)
        synchronized(resultCache) { resultCache.clear() }
        refreshStats()
    }

    fun clearIndex() {
        trie.clear()
        bloom.clear()
        synchronized(resultCache) { resultCache.clear() }
        refreshStats()
    }

    private fun walkFiles(dir: File, out: MutableList<File>) {
        try {
            dir.listFiles()?.forEach { child ->
                if (child.isDirectory) {
                    walkFiles(child, out)
                } else if (child.isFile) {
                    out.add(child)
                }
            }
        } catch (_: Exception) { /* best-effort */ }
    }

    private fun File.toFileItem(): FileItem = FileItem(
        path = absolutePath,
        name = name,
        stableId = runCatching { absoluteFile.hashCode().toLong() }.getOrDefault(0L),
        size = length(),
        modifiedAt = lastModified(),
        isDirectory = false,
        isHidden = name.startsWith("."),
    )

    private fun refreshStats() {
        _indexStats.value = IndexStats(
            totalFilesIndexed = trie.size().toInt(),
            totalTokens = trie.size().toInt(),
            lastIndexTimeMs = System.currentTimeMillis(),
            queueLength = 0,
            indexSizeBytes = bloom.bitCount() / 8L,
            isIndexing = _isIndexing.value,
        )
    }
}

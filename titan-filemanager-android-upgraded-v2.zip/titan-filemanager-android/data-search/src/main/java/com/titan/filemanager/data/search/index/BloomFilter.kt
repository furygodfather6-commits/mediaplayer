package com.titan.filemanager.data.search.index

import java.util.concurrent.atomic.AtomicLong
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.ln

/**
 * Bloom filter for fast negative lookup.
 *
 * Use case: before searching the Trie / FullText index for "xyz", check
 * the Bloom filter. If Bloom says "no", we can skip the search entirely
 * (saves ~10ms on miss).
 *
 * Properties:
 *   - False positive rate: ~1% (configurable)
 *   - Memory: ~10 bits per item → 1M items = ~1.2 MB
 *   - Insert: O(k) where k = number of hash functions (~7)
 *   - Lookup: O(k)
 *
 * Implementation: bit array + MurmurHash3 (k=7, m = n × 10 bits).
 */
@Singleton
class BloomFilter @Inject constructor() {

    private var bits: BooleanArray = BooleanArray(DEFAULT_BITS)
    private var hashCount = DEFAULT_HASH_COUNT
    private var itemCount = AtomicLong(0)

    /**
     * Initialize with expected [itemCount] and target [falsePositiveRate].
     *
     * Recomputes optimal bit-array size + hash count.
     */
    fun initialize(expectedItems: Int, falsePositiveRate: Double = 0.01) {
        val bitsCount = optimalBitCount(expectedItems, falsePositiveRate)
        bits = BooleanArray(bitsCount)
        hashCount = optimalHashCount(expectedItems, bitsCount)
        itemCount.set(0)
    }

    /**
     * Add [item] to the filter.
     */
    fun add(item: String) {
        val bytes = item.toByteArray(Charsets.UTF_8)
        for (i in 0 until hashCount) {
            val hash = murmurHash3(bytes, i)
            val index = Math.floorMod(hash, bits.size)
            bits[index] = true
        }
        itemCount.incrementAndGet()
    }

    /**
     * Check if [item] MIGHT be in the filter.
     *
     * Returns:
     *   - `false` → definitely NOT in the filter (no false negatives)
     *   - `true` → might be in the filter (~1% false positive rate)
     */
    fun mightContain(item: String): Boolean {
        val bytes = item.toByteArray(Charsets.UTF_8)
        for (i in 0 until hashCount) {
            val hash = murmurHash3(bytes, i)
            val index = Math.floorMod(hash, bits.size)
            if (!bits[index]) return false
        }
        return true
    }

    fun clear() {
        bits = BooleanArray(bits.size)
        itemCount.set(0)
    }

    fun size(): Long = itemCount.get()

    fun bitCount(): Int = bits.size

    private fun optimalBitCount(n: Int, p: Double): Int {
        if (n <= 0) return DEFAULT_BITS
        val m = -(n * ln(p)) / (ln(2.0) * ln(2.0))
        return m.toInt().coerceAtLeast(DEFAULT_BITS)
    }

    private fun optimalHashCount(n: Int, m: Int): Int {
        if (n <= 0) return DEFAULT_HASH_COUNT
        val k = (m.toDouble() / n) * ln(2.0)
        return k.toInt().coerceAtLeast(1)
    }

    /**
     * MurmurHash3 — fast non-cryptographic hash.
     *
     * Using seed = [seed] for hash diversification.
     */
    private fun murmurHash3(data: ByteArray, seed: Int): Int {
        var h = seed
        val c1 = -0x3361D2AF // 0xCC9E2D51 as Int
        val c2 = 0x1B873593

        // Body
        var i = 0
        while (i + 4 <= data.size) {
            var k = (data[i].toInt() and 0xFF) or
                ((data[i + 1].toInt() and 0xFF) shl 8) or
                ((data[i + 2].toInt() and 0xFF) shl 16) or
                ((data[i + 3].toInt() and 0xFF) shl 24)
            k *= c1
            k = (k shl 15) or (k ushr 17)
            k *= c2
            h = h xor k
            h = (h shl 13) or (h ushr 19)
            h = h * 5 + 0xE6546B64.toInt()
            i += 4
        }

        // Tail
        var k = 0
        val remaining = data.size - i
        if (remaining >= 3) k = (data[i + 2].toInt() and 0xFF) shl 16
        if (remaining >= 2) k = k or ((data[i + 1].toInt() and 0xFF) shl 8)
        if (remaining >= 1) {
            k = k or (data[i].toInt() and 0xFF)
            k *= c1
            k = (k shl 15) or (k ushr 17)
            k *= c2
            h = h xor k
        }

        // Finalize
        h = h xor data.size
        h = h xor (h ushr 16)
        h *= 0x85EBCA6B.toInt()
        h = h xor (h ushr 13)
        h *= 0xC2B2AE35.toInt()
        h = h xor (h ushr 16)

        return h
    }

    companion object {
        const val DEFAULT_BITS = 10_000_000  // ~1.2 MB
        const val DEFAULT_HASH_COUNT = 7
    }
}

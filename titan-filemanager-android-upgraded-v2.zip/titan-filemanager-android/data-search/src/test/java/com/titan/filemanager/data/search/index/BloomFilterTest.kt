package com.titan.filemanager.data.search.index

import com.google.common.truth.Truth.assertThat
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test

/**
 * Unit tests for [BloomFilter] — pure-Kotlin.
 */
class BloomFilterTest {

    private lateinit var bloom: BloomFilter

    @BeforeEach
    fun setUp() {
        bloom = BloomFilter()
        bloom.initialize(expectedItems = 1000, falsePositiveRate = 0.01)
    }

    @Test
    fun `mightContain on empty filter returns false`() {
        assertThat(bloom.mightContain("anything")).isFalse()
    }

    @Test
    fun `add then mightContain returns true`() {
        bloom.add("photo.jpg")
        assertThat(bloom.mightContain("photo.jpg")).isTrue()
    }

    @Test
    fun `mightContain on never-added item returns false`() {
        bloom.add("photo.jpg")
        bloom.add("video.mp4")
        bloom.add("document.pdf")

        // These were never added
        assertThat(bloom.mightContain("music.mp3")).isFalse()
        assertThat(bloom.mightContain("archive.zip")).isFalse()
        assertThat(bloom.mightContain("script.sh")).isFalse()
    }

    @Test
    fun `add multiple items all return true on mightContain`() {
        val items = (1..100).map { "file$it.txt" }
        items.forEach { bloom.add(it) }
        items.forEach { assertThat(bloom.mightContain(it)).isTrue() }
    }

    @Test
    fun `size returns number of items added`() {
        bloom.add("a")
        bloom.add("b")
        bloom.add("c")
        assertThat(bloom.size()).isEqualTo(3L)
    }

    @Test
    fun `clear empties the filter`() {
        bloom.add("photo.jpg")
        bloom.clear()
        assertThat(bloom.size()).isEqualTo(0L)
        // After clear, mightContain should be false (no false positives expected)
        // Note: very small chance of false positive, but for 1 item this is essentially 0
        assertThat(bloom.mightContain("photo.jpg")).isFalse()
    }

    @Test
    fun `false positive rate stays under 5 percent for 1000 items`() {
        // Add 1000 items
        val added = (1..1000).map { "file$it.txt" }
        added.forEach { bloom.add(it) }

        // Check 1000 items that were NOT added
        val notAdded = (1..1000).map { "other$it.txt" }
        var falsePositives = 0
        for (item in notAdded) {
            if (bloom.mightContain(item)) falsePositives++
        }

        val falsePositiveRate = falsePositives.toDouble() / 1000
        // Configured for 1% FP — allow up to 5% for test variance
        assertThat(falsePositiveRate).isLessThan(0.05)
    }
}

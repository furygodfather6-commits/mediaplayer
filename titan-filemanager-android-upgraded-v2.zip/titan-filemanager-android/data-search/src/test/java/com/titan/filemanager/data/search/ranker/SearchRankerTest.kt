package com.titan.filemanager.data.search.ranker

import com.google.common.truth.Truth.assertThat
import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.domain.search.MatchType
import com.titan.filemanager.domain.search.SearchQuery
import org.junit.jupiter.api.Test

/**
 * Unit tests for [SearchRanker].
 */
class SearchRankerTest {

    private val ranker = SearchRanker()

    @Test
    fun `exact name match scores highest`() {
        val now = System.currentTimeMillis()
        val items = listOf(
            fileItem("photo.jpg", "/sdcard/photo.jpg", now),
            fileItem("photo.jpg.bak", "/sdcard/photo.jpg.bak", now),
        )
        val query = SearchQuery(text = "photo.jpg")
        val ranked = ranker.rank(items, query)
        assertThat(ranked.first().file.name).isEqualTo("photo.jpg")
        assertThat(ranked.first().matchType).isEqualTo(MatchType.EXACT_NAME)
    }

    @Test
    fun `prefix match ranks higher than contains match`() {
        val now = System.currentTimeMillis()
        val items = listOf(
            fileItem("my_photo.jpg", "/sdcard/my_photo.jpg", now),  // contains
            fileItem("photo_gallery.zip", "/sdcard/photo_gallery.zip", now),  // prefix
        )
        val query = SearchQuery(text = "photo")
        val ranked = ranker.rank(items, query)
        assertThat(ranked.first().file.name).isEqualTo("photo_gallery.zip")
        assertThat(ranked.first().matchType).isEqualTo(MatchType.PREFIX)
    }

    @Test
    fun `shorter names rank higher for same match type`() {
        val now = System.currentTimeMillis()
        val items = listOf(
            fileItem("photo_of_my_vacation_2026.jpg", "/sdcard/photo_of_my_vacation_2026.jpg", now),
            fileItem("photo.jpg", "/sdcard/photo.jpg", now),
        )
        val query = SearchQuery(text = "photo")
        val ranked = ranker.rank(items, query)
        // Both are PREFIX matches — shorter name should rank higher (relevance factor)
        assertThat(ranked.first().file.name).isEqualTo("photo.jpg")
    }

    @Test
    fun `recent files rank higher than old files for same match`() {
        val now = System.currentTimeMillis()
        val recent = fileItem("photo.jpg", "/sdcard/photo.jpg", now)
        val old = fileItem("photo.jpg", "/sdcard/old/photo.jpg", now - 30L * 24 * 60 * 60 * 1000)
        val query = SearchQuery(text = "photo")
        val ranked = ranker.rank(listOf(old, recent), query)
        assertThat(ranked.first().file.path).isEqualTo("/sdcard/photo.jpg")
    }

    @Test
    fun `shallow paths rank higher than deep paths`() {
        val now = System.currentTimeMillis()
        val shallow = fileItem("photo.jpg", "/sdcard/photo.jpg", now)
        val deep = fileItem(
            "photo.jpg",
            "/sdcard/a/b/c/d/e/f/g/h/photo.jpg",
            now,
        )
        val query = SearchQuery(text = "photo")
        val ranked = ranker.rank(listOf(deep, shallow), query)
        assertThat(ranked.first().file.path).isEqualTo("/sdcard/photo.jpg")
    }

    @Test
    fun `empty items returns empty list`() {
        val query = SearchQuery(text = "photo")
        val ranked = ranker.rank(emptyList(), query)
        assertThat(ranked).isEmpty()
    }

    @Test
    fun `single item returns list with that item`() {
        val now = System.currentTimeMillis()
        val item = fileItem("photo.jpg", "/sdcard/photo.jpg", now)
        val query = SearchQuery(text = "photo")
        val ranked = ranker.rank(listOf(item), query)
        assertThat(ranked).hasSize(1)
        assertThat(ranked.first().file).isEqualTo(item)
    }

    private fun fileItem(name: String, path: String, modifiedAt: Long): FileItem = FileItem(
        path = path,
        name = name,
        stableId = path.hashCode().toLong(),
        size = 1024L,
        modifiedAt = modifiedAt,
        isDirectory = false,
        isHidden = false,
    )
}

package com.titan.filemanager.data.search.index

import com.google.common.truth.Truth.assertThat
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test

/**
 * Unit tests for [TrieIndex] — pure-Kotlin, no Android deps.
 */
class TrieIndexTest {

    private lateinit var trie: TrieIndex

    @BeforeEach
    fun setUp() {
        trie = TrieIndex()
    }

    @Test
    fun `empty trie returns no results for any prefix`() {
        assertThat(trie.searchPrefix("anything")).isEmpty()
        assertThat(trie.searchPrefix("")).isEmpty()
    }

    @Test
    fun `insert and search by exact name returns the path`() {
        trie.insert("photo.jpg", "/sdcard/DCIM/photo.jpg")
        val results = trie.searchPrefix("photo")
        assertThat(results).containsExactly("/sdcard/DCIM/photo.jpg")
    }

    @Test
    fun `search is case-insensitive`() {
        trie.insert("Photo.jpg", "/sdcard/Photo.jpg")
        val results = trie.searchPrefix("photo")
        assertThat(results).containsExactly("/sdcard/Photo.jpg")
    }

    @Test
    fun `prefix search returns all matching paths`() {
        trie.insert("photo.jpg", "/sdcard/photo.jpg")
        trie.insert("photos.zip", "/sdcard/photos.zip")
        trie.insert("photography.txt", "/sdcard/photography.txt")
        trie.insert("video.mp4", "/sdcard/video.mp4")

        val results = trie.searchPrefix("photo")
        assertThat(results).hasSize(3)
        assertThat(results).contains("/sdcard/photo.jpg")
        assertThat(results).contains("/sdcard/photos.zip")
        assertThat(results).contains("/sdcard/photography.txt")
        assertThat(results).doesNotContain("/sdcard/video.mp4")
    }

    @Test
    fun `multiple paths with same name are all returned`() {
        trie.insert("photo.jpg", "/sdcard/DCIM/photo.jpg")
        trie.insert("photo.jpg", "/sdcard/Backup/photo.jpg")
        trie.insert("photo.jpg", "/sdcard/Photos/photo.jpg")

        val results = trie.searchPrefix("photo")
        assertThat(results).hasSize(3)
    }

    @Test
    fun `search with non-matching prefix returns empty`() {
        trie.insert("photo.jpg", "/sdcard/photo.jpg")
        assertThat(trie.searchPrefix("video")).isEmpty()
        assertThat(trie.searchPrefix("xyz")).isEmpty()
    }

    @Test
    fun `limit parameter caps results`() {
        repeat(20) { i -> trie.insert("file$i.txt", "/sdcard/file$i.txt") }
        val results = trie.searchPrefix("file", limit = 5)
        assertThat(results).hasSize(5)
    }

    @Test
    fun `remove deletes path from all nodes`() {
        trie.insert("photo.jpg", "/sdcard/photo.jpg")
        trie.insert("photos.zip", "/sdcard/photos.zip")

        trie.remove("/sdcard/photo.jpg")
        val results = trie.searchPrefix("photo")
        assertThat(results).containsExactly("/sdcard/photos.zip")
    }

    @Test
    fun `remove on non-existent path is no-op`() {
        trie.insert("photo.jpg", "/sdcard/photo.jpg")
        trie.remove("/sdcard/nonexistent.jpg")
        assertThat(trie.searchPrefix("photo")).hasSize(1)
    }

    @Test
    fun `clear empties the trie`() {
        trie.insert("photo.jpg", "/sdcard/photo.jpg")
        trie.insert("video.mp4", "/sdcard/video.mp4")
        trie.clear()
        assertThat(trie.searchPrefix("photo")).isEmpty()
        assertThat(trie.searchPrefix("video")).isEmpty()
        assertThat(trie.size()).isEqualTo(0)
    }

    @Test
    fun `size returns total paths inserted`() {
        trie.insert("photo.jpg", "/sdcard/photo.jpg")
        trie.insert("photo.jpg", "/sdcard/Backup/photo.jpg")
        trie.insert("video.mp4", "/sdcard/video.mp4")
        assertThat(trie.size()).isEqualTo(3)
    }

    @Test
    fun `non-ASCII characters are skipped gracefully`() {
        trie.insert("café.txt", "/sdcard/café.txt")
        trie.insert("photo.jpg", "/sdcard/photo.jpg")
        // Should not crash — non-ASCII chars skipped
        val results = trie.searchPrefix("photo")
        assertThat(results).containsExactly("/sdcard/photo.jpg")
    }
}

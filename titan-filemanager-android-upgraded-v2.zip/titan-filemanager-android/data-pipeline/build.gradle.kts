// :data:pipeline — Enterprise Pipeline Engine
// Ported from original codebase Phase M (Techniques #118-#125)
plugins {
    id("titan.android.library")
    id("titan.android.hilt")
}

android {
    namespace = "com.titan.filemanager.data.pipeline"
}

dependencies {
    api(project(":core:common"))
    api(project(":core:model"))
    api(project(":domain"))

    implementation(libs.kotlinx.coroutines.core)
    implementation(libs.timber)

    testImplementation(project(":core:testing"))
    testImplementation(libs.junit5)
    testImplementation(libs.truth)
    testImplementation(libs.robolectric)
    testImplementation(libs.kotlinx.coroutines.test)
}

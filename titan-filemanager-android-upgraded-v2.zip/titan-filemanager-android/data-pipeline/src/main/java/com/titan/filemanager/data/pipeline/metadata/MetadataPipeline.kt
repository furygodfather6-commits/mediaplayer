package com.titan.filemanager.data.pipeline.metadata

import android.webkit.MimeTypeMap
import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.data.pipeline.core.Pipeline
import com.titan.filemanager.data.pipeline.core.PipelineContext
import com.titan.filemanager.data.pipeline.core.PipelineEvent
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.*

/**
 * Metadata Pipeline — 4-stage: MIME → ChildCount → Permissions → MediaMeta.
 *
 * Technique #119: Metadata pipeline
 * Technique #125: Independent worker stages
 */
class MetadataPipeline(
    private val context: PipelineContext,
    private val pipelineConfig: MetadataPipelineConfig = MetadataPipelineConfig(),
) : Pipeline<List<FileItem>, FileItem>(name = "MetadataPipeline") {

    override fun execute(input: List<FileItem>): Flow<PipelineEvent<FileItem>> = channelFlow {
        state.set(State.RUNNING); metrics.recordStart()
        send(PipelineEvent.Started(name))
        val startMs = System.currentTimeMillis()

        try {
            // Stage 1: MIME detection
            val mimeChannel = Channel<FileItem>(capacity = 256)
            val mimeJob = launch(Dispatchers.Default) {
                val stageStart = System.currentTimeMillis()
                input.chunked(pipelineConfig.batchSize).forEach { batch ->
                    context.checkCancelled()
                    batch.forEach { item ->
                        val mime = detectMimeFast(item.extension)
                        val enriched = item.copy(mimeType = mime)
                        mimeChannel.send(enriched)
                        send(PipelineEvent.Item(enriched, "MIMEStage"))
                        metrics.recordItem()
                    }
                }
                mimeChannel.close()
                val dur = System.currentTimeMillis() - stageStart
                metrics.recordStageTime("MIMEDetection", dur)
                send(PipelineEvent.StageCompleted("MIMEDetection", 1, dur))
            }

            // Stage 2: Child count (dirs only)
            val childChannel = Channel<FileItem>(capacity = 256)
            val childJob = launch(Dispatchers.IO) {
                val stageStart = System.currentTimeMillis()
                for (item in mimeChannel) {
                    context.checkCancelled()
                    val enriched = if (item.isDirectory && pipelineConfig.loadChildCount)
                        item.copy(tags = item.tags + "${countChildren(item.path)} items") else item
                    childChannel.send(enriched)
                }
                childChannel.close()
                val dur = System.currentTimeMillis() - stageStart
                metrics.recordStageTime("ChildCount", dur)
                send(PipelineEvent.StageCompleted("ChildCount", 2, dur))
            }

            // Stage 3: Permissions (deferred)
            val permChannel = Channel<FileItem>(capacity = 256)
            val permJob = launch(Dispatchers.IO) {
                val stageStart = System.currentTimeMillis()
                for (item in childChannel) {
                    context.checkCancelled()
                    permChannel.send(item) // Phase 5: add permission resolution
                }
                permChannel.close()
                val dur = System.currentTimeMillis() - stageStart
                metrics.recordStageTime("Permissions", dur)
                send(PipelineEvent.StageCompleted("Permissions", 3, dur))
            }

            // Stage 4: Collect
            val finalItems = ArrayList<FileItem>(input.size)
            val mediaJob = launch(Dispatchers.IO) {
                val stageStart = System.currentTimeMillis()
                for (item in permChannel) { context.checkCancelled(); finalItems.add(item) }
                val dur = System.currentTimeMillis() - stageStart
                metrics.recordStageTime("MediaMeta", dur)
                send(PipelineEvent.StageCompleted("MediaMeta", 4, dur))
            }

            mimeJob.join(); childJob.join(); permJob.join(); mediaJob.join()
            val totalMs = System.currentTimeMillis() - startMs
            metrics.recordEnd()
            send(PipelineEvent.Batch(finalItems, "MetadataComplete"))
            send(PipelineEvent.Completed(totalMs, finalItems.size))
            state.set(State.COMPLETED)
        } catch (e: CancellationException) {
            send(PipelineEvent.Cancelled); state.set(State.CANCELLED)
        } catch (e: Exception) {
            send(PipelineEvent.Failed(e, "MetadataPipeline")); state.set(State.FAILED); metrics.recordError()
        }
    }.flowOn(Dispatchers.IO)

    private fun detectMimeFast(extension: String): String =
        if (extension.isEmpty()) "application/octet-stream"
        else MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension.lowercase()) ?: "application/octet-stream"

    private fun countChildren(path: String): Int =
        try { java.io.File(path).list()?.size ?: 0 } catch (_: Exception) { -1 }
}

data class MetadataPipelineConfig(
    val batchSize: Int = 100,
    val loadChildCount: Boolean = true,
    val loadPermissions: Boolean = false,
    val loadMediaMeta: Boolean = false,
    val maxConcurrentWorkers: Int = 4,
)

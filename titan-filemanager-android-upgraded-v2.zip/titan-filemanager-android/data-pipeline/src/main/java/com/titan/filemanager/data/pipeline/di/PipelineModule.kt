package com.titan.filemanager.data.pipeline.di

import android.content.Context
import com.titan.filemanager.data.pipeline.engine.PipelineEngine
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object PipelineModule {

    @Provides
    @Singleton
    fun providePipelineEngine(@ApplicationContext context: Context): PipelineEngine {
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
        return PipelineEngine(context, scope)
    }
}

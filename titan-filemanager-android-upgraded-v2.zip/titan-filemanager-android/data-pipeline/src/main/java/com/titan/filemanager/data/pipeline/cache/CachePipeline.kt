package com.titan.filemanager.data.pipeline.cache

import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.data.pipeline.core.Pipeline
import com.titan.filemanager.data.pipeline.core.PipelineContext
import com.titan.filemanager.data.pipeline.core.PipelineEvent
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.util.concurrent.ConcurrentHashMap

/**
 * Cache Pipeline — 4-tier: L1 Hot RAM → L2 Warm RAM → L3 SQLite → L4 Disk.
 *
 * Technique #123: Cache pipeline
 * Technique #40-53: All caching techniques
 */
class CachePipeline(
    private val context: PipelineContext,
    private val pipelineConfig: CachePipelineConfig = CachePipelineConfig(),
) : Pipeline<CachePipeline.CacheRequest, CachePipeline.CacheResult>(name = "CachePipeline") {

    data class CacheRequest(val path: String, val requestType: RequestType, val freshData: List<FileItem>? = null)
    enum class RequestType { READ, WRITE, INVALIDATE, WARM }
    data class CacheResult(val path: String, val items: List<FileItem>?, val cacheLevel: CacheLevel, val latencyMs: Long)
    enum class CacheLevel { L1_HOT_RAM, L2_WARM_RAM, L3_SQLITE, L4_DISK, MISS }

    private val l1Cache = java.util.LinkedHashMap<String, CacheEntry>(16, 0.75f, true)
    private val l2Cache = ConcurrentHashMap<String, CacheEntry>(100)

    data class CacheEntry(val items: List<FileItem>, val timestamp: Long, var accessCount: Int = 0) {
        fun isExpired(ttlMs: Long) = System.currentTimeMillis() - timestamp > ttlMs
    }

    override fun execute(input: CacheRequest): Flow<PipelineEvent<CacheResult>> = channelFlow {
        state.set(State.RUNNING)
        val startMs = System.currentTimeMillis()
        send(PipelineEvent.Started(name))

        try {
            val result = when (input.requestType) {
                RequestType.READ -> handleRead(input, startMs)
                RequestType.WRITE -> handleWrite(input, startMs)
                RequestType.INVALIDATE -> handleInvalidate(input, startMs)
                RequestType.WARM -> handleWrite(input, startMs)
            }
            send(PipelineEvent.Item(result, "CachePipeline"))
            send(PipelineEvent.Completed(System.currentTimeMillis() - startMs, 1))
            state.set(State.COMPLETED)
        } catch (e: CancellationException) {
            send(PipelineEvent.Cancelled); state.set(State.CANCELLED)
        } catch (e: Exception) {
            send(PipelineEvent.Failed(e, "CachePipeline")); state.set(State.FAILED)
        }
    }.flowOn(Dispatchers.IO)

    private suspend fun handleRead(input: CacheRequest, startMs: Long): CacheResult = withContext(Dispatchers.IO) {
        val path = input.path
        // L1
        synchronized(l1Cache) {
            l1Cache[path]?.let { entry ->
                if (!entry.isExpired(pipelineConfig.l1TtlMs)) {
                    entry.accessCount++
                    return@withContext CacheResult(path, entry.items, CacheLevel.L1_HOT_RAM, System.currentTimeMillis() - startMs)
                }
                l1Cache.remove(path)
            }
        }
        // L2
        l2Cache[path]?.let { entry ->
            if (!entry.isExpired(pipelineConfig.l2TtlMs)) {
                entry.accessCount++
                if (entry.accessCount > pipelineConfig.promotionThreshold) {
                    synchronized(l1Cache) {
                        if (l1Cache.size >= pipelineConfig.l1MaxSize) l1Cache.entries.firstOrNull()?.let { l1Cache.remove(it.key) }
                        l1Cache[path] = entry
                    }
                }
                return@withContext CacheResult(path, entry.items, CacheLevel.L2_WARM_RAM, System.currentTimeMillis() - startMs)
            }
            l2Cache.remove(path)
        }
        // L3/L4 — Phase 5 integration
        CacheResult(path, null, CacheLevel.MISS, System.currentTimeMillis() - startMs)
    }

    private suspend fun handleWrite(input: CacheRequest, startMs: Long): CacheResult = withContext(Dispatchers.IO) {
        val items = input.freshData ?: return@withContext CacheResult(input.path, null, CacheLevel.MISS, 0)
        val entry = CacheEntry(items, System.currentTimeMillis())
        if (l2Cache.size >= pipelineConfig.l2MaxSize) evictL2()
        l2Cache[input.path] = entry
        CacheResult(input.path, items, CacheLevel.L2_WARM_RAM, System.currentTimeMillis() - startMs)
    }

    private fun handleInvalidate(input: CacheRequest, startMs: Long): CacheResult {
        synchronized(l1Cache) { l1Cache.remove(input.path) }
        l2Cache.remove(input.path)
        return CacheResult(input.path, null, CacheLevel.MISS, System.currentTimeMillis() - startMs)
    }

    private fun evictL2() {
        l2Cache.entries.sortedBy { it.value.timestamp }.take(l2Cache.size / 5).forEach { l2Cache.remove(it.key) }
    }
}

data class CachePipelineConfig(
    val l1MaxSize: Int = 10,
    val l2MaxSize: Int = 100,
    val l1TtlMs: Long = 30_000L,
    val l2TtlMs: Long = 5 * 60_000L,
    val promotionThreshold: Int = 3,
)

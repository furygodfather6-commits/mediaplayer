package com.titan.filemanager.data.pipeline.core

import kotlinx.coroutines.CoroutineScope
import java.util.concurrent.ConcurrentHashMap

/**
 * Shared context flowing through all pipeline stages.
 * Avoids passing dependencies to every stage.
 *
 * Technique #125: Independent stages with shared context
 */
class PipelineContext(
    val scope: CoroutineScope,
    val config: PipelineConfig = PipelineConfig(),
) {
    private val sharedState = ConcurrentHashMap<String, Any>()

    @Volatile
    var isCancelled: Boolean = false
        private set

    val metrics = mutableMapOf<String, Any>()

    fun cancel() { isCancelled = true }

    fun <T> set(key: String, value: T) { sharedState[key] = value as Any }

    @Suppress("UNCHECKED_CAST")
    fun <T> get(key: String): T? = sharedState[key] as? T

    fun checkCancelled() {
        if (isCancelled) throw kotlinx.coroutines.CancellationException("Pipeline cancelled")
    }
}

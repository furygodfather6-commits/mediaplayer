package com.titan.filemanager.data.pipeline.event

import android.os.FileObserver
import com.titan.filemanager.data.pipeline.core.PipelineContext
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.*
import timber.log.Timber
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * Event Pipeline — 4-stage: FileObserver → Debounce+Batch → Classify → Dispatch.
 *
 * Technique #122: Event pipeline
 * Technique #54-59: File watching techniques
 */
class EventPipeline(
    private val context: PipelineContext,
    private val config: EventPipelineConfig = EventPipelineConfig(),
) {
    private val rawEventChannel = Channel<FileSystemEvent>(capacity = 1000)
    private val _eventFlow = MutableSharedFlow<ProcessedEvent>(replay = 0, extraBufferCapacity = 100)
    val eventFlow: SharedFlow<ProcessedEvent> = _eventFlow

    private val observers = ConcurrentHashMap<String, PathObserver>()
    private val totalEvents = AtomicLong(0)
    private val debouncedEvents = AtomicLong(0)

    data class FileSystemEvent(val path: String, val eventType: Int, val fileName: String?, val timestamp: Long = System.currentTimeMillis())
    data class ProcessedEvent(val dirPath: String, val type: EventType, val affectedFiles: List<String>, val timestamp: Long = System.currentTimeMillis())
    enum class EventType { FILE_CREATED, FILE_DELETED, FILE_MODIFIED, FILE_RENAMED, DIR_CREATED, DIR_DELETED, BULK_CHANGE }

    fun watchDirectory(dirPath: String) {
        if (observers.containsKey(dirPath)) return
        val observer = PathObserver(dirPath, rawEventChannel)
        observers[dirPath] = observer
        observer.startWatching()
    }

    fun unwatchDirectory(dirPath: String) { observers.remove(dirPath)?.stopWatching() }

    fun startProcessing(scope: CoroutineScope) {
        scope.launch {
            // Stage 2: Debounce + batch
            val debouncedChannel = Channel<List<FileSystemEvent>>(capacity = 50)
            val debounceJob = launch(Dispatchers.Default) {
                val pending = ArrayList<FileSystemEvent>(20)
                var debounceTimer: Job? = null
                for (event in rawEventChannel) {
                    totalEvents.incrementAndGet()
                    pending.add(event)
                    debounceTimer?.cancel()
                    debounceTimer = launch {
                        delay(config.debounceMs)
                        if (pending.isNotEmpty()) {
                            debouncedChannel.send(pending.toList())
                            debouncedEvents.addAndGet(pending.size.toLong())
                            pending.clear()
                        }
                    }
                }
            }

            // Stage 3: Classify
            val classifiedChannel = Channel<ProcessedEvent>(capacity = 50)
            val classifyJob = launch(Dispatchers.Default) {
                for (events in debouncedChannel) {
                    context.checkCancelled()
                    classifyEvents(events).forEach { classifiedChannel.send(it) }
                }
                classifiedChannel.close()
            }

            // Stage 4: Dispatch
            for (event in classifiedChannel) _eventFlow.emit(event)
            debounceJob.join(); classifyJob.join()
        }
    }

    private fun classifyEvents(events: List<FileSystemEvent>): List<ProcessedEvent> {
        val byDir = events.groupBy { it.path.substringBeforeLast('/') }
        return byDir.map { (dirPath, dirEvents) ->
            val eventType = when {
                dirEvents.size > 5 -> EventType.BULK_CHANGE
                dirEvents.any { it.eventType == FileObserver.CREATE } && dirEvents.any { it.eventType == FileObserver.DELETE } -> EventType.FILE_RENAMED
                dirEvents.any { it.eventType == FileObserver.CREATE } -> EventType.FILE_CREATED
                dirEvents.any { it.eventType == FileObserver.DELETE } -> EventType.FILE_DELETED
                else -> EventType.FILE_MODIFIED
            }
            ProcessedEvent(dirPath, eventType, dirEvents.mapNotNull { it.fileName })
        }
    }

    fun stopAll() {
        observers.values.forEach { it.stopWatching() }
        observers.clear()
        rawEventChannel.close()
    }

    inner class PathObserver(private val path: String, private val channel: Channel<FileSystemEvent>) {
        private val WATCH_MASK = FileObserver.CREATE or FileObserver.DELETE or FileObserver.MODIFY or
            FileObserver.MOVED_FROM or FileObserver.MOVED_TO or FileObserver.CLOSE_WRITE

        private val observer = object : FileObserver(path, WATCH_MASK) {
            override fun onEvent(event: Int, fileName: String?) {
                channel.trySend(FileSystemEvent(path, event, fileName))
            }
        }

        fun startWatching() { observer.startWatching(); Timber.d("Watching: $path") }
        fun stopWatching() { observer.stopWatching() }
    }
}

data class EventPipelineConfig(
    val debounceMs: Long = 300L,
    val maxBatchSize: Int = 50,
    val enableJournaling: Boolean = true,
)

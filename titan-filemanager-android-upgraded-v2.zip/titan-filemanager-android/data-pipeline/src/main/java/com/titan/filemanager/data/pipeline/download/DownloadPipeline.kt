package com.titan.filemanager.data.pipeline.download

import com.titan.filemanager.data.pipeline.core.Pipeline
import com.titan.filemanager.data.pipeline.core.PipelineContext
import com.titan.filemanager.data.pipeline.core.PipelineEvent
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.io.*
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicLong

/**
 * Download Pipeline — 5-stage: Validate → Connect → Download → Verify → Move.
 *
 * Technique #124: Download pipeline
 */
class DownloadPipeline(
    private val context: PipelineContext,
    private val pipelineConfig: DownloadPipelineConfig = DownloadPipelineConfig(),
) : Pipeline<DownloadPipeline.DownloadRequest, DownloadPipeline.DownloadProgress>(name = "DownloadPipeline") {

    data class DownloadRequest(val url: String, val destPath: String, val expectedSize: Long = -1L, val expectedChecksum: String? = null)

    data class DownloadProgress(
        val url: String, val destPath: String, val downloadedBytes: Long, val totalBytes: Long,
        val stage: String, val isComplete: Boolean = false, val error: String? = null,
    ) {
        val progressPercent: Int get() = if (totalBytes > 0) ((downloadedBytes * 100) / totalBytes).toInt() else 0
    }

    override fun execute(input: DownloadRequest): Flow<PipelineEvent<DownloadProgress>> = channelFlow {
        state.set(State.RUNNING); metrics.recordStart()
        send(PipelineEvent.Started(name))
        val startMs = System.currentTimeMillis()

        try {
            // Stage 1: Validate
            val destFile = File(input.destPath)
            val tempFile = File("${input.destPath}.tmp")
            require(input.url.startsWith("http")) { "Invalid URL" }
            val destDir = destFile.parentFile
            require(destDir?.exists() == true || destDir?.mkdirs() == true) { "Cannot create dest dir" }
            send(PipelineEvent.Item(DownloadProgress(input.url, input.destPath, 0, -1, "Connecting"), "Validate"))

            // Stage 2: Connect
            val connection = withContext(Dispatchers.IO) {
                (URL(input.url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 15_000; readTimeout = 30_000; requestMethod = "GET"
                    setRequestProperty("Accept-Encoding", "identity"); connect()
                }
            }
            val totalBytes = connection.contentLengthLong
            require(connection.responseCode == HttpURLConnection.HTTP_OK) { "HTTP Error: ${connection.responseCode}" }

            // Stage 3: Download chunks
            val downloadedBytes = AtomicLong(0)
            withContext(Dispatchers.IO) {
                BufferedInputStream(connection.inputStream, pipelineConfig.bufferSize).use { input_stream ->
                    FileOutputStream(tempFile).use { fos ->
                        val buffer = ByteArray(pipelineConfig.bufferSize)
                        var bytesRead: Int; var lastProgressEmit = 0L
                        while (input_stream.read(buffer).also { bytesRead = it } != -1) {
                            context.checkCancelled()
                            fos.write(buffer, 0, bytesRead)
                            downloadedBytes.addAndGet(bytesRead.toLong())
                            val now = System.currentTimeMillis()
                            if (now - lastProgressEmit > 500) {
                                lastProgressEmit = now
                                send(PipelineEvent.Item(
                                    DownloadProgress(input.url, input.destPath, downloadedBytes.get(), totalBytes, "Downloading"), "DownloadChunk"))
                            }
                        }
                        fos.flush()
                    }
                }
            }
            connection.disconnect()

            // Stage 4: Verify (checksum if provided)
            if (input.expectedChecksum != null) {
                val isValid = withContext(Dispatchers.IO) { verifyChecksum(tempFile, input.expectedChecksum) }
                require(isValid) { "Checksum mismatch!" }
            }

            // Stage 5: Move temp → final
            withContext(Dispatchers.IO) { if (destFile.exists()) destFile.delete(); tempFile.renameTo(destFile) }

            val totalMs = System.currentTimeMillis() - startMs
            metrics.recordEnd()
            send(PipelineEvent.Item(
                DownloadProgress(input.url, input.destPath, downloadedBytes.get(), totalBytes, "Complete", isComplete = true), "DownloadComplete"))
            send(PipelineEvent.Completed(totalMs, 1))
            state.set(State.COMPLETED)
        } catch (e: CancellationException) {
            File("${input.destPath}.tmp").delete()
            send(PipelineEvent.Cancelled); state.set(State.CANCELLED)
        } catch (e: Exception) {
            File("${input.destPath}.tmp").delete()
            send(PipelineEvent.Failed(e, "DownloadPipeline")); state.set(State.FAILED); metrics.recordError()
        }
    }.flowOn(Dispatchers.IO)

    private fun verifyChecksum(file: File, expected: String): Boolean = try {
        val md = java.security.MessageDigest.getInstance("MD5")
        file.inputStream().use { fis ->
            val buffer = ByteArray(8192); var n: Int
            while (fis.read(buffer).also { n = it } != -1) md.update(buffer, 0, n)
        }
        md.digest().joinToString("") { "%02x".format(it) } == expected.lowercase()
    } catch (_: Exception) { false }
}

data class DownloadPipelineConfig(
    val bufferSize: Int = 64 * 1024,
    val maxRetries: Int = 3,
    val connectTimeoutMs: Int = 15_000,
    val readTimeoutMs: Int = 30_000,
)

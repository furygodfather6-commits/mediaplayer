package com.titan.filemanager.data.pipeline.scan

import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.data.pipeline.core.Pipeline
import com.titan.filemanager.data.pipeline.core.PipelineConfig
import com.titan.filemanager.data.pipeline.core.PipelineContext
import com.titan.filemanager.data.pipeline.core.PipelineEvent
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.*

/**
 * Scan Pipeline V2 — 5-stage: List → Filter → BatchStat → Sort → Emit.
 *
 * Progressive emission: UI gets minimal items immediately, enriched items as stat completes.
 *
 * Technique #118: Scan pipeline
 * Technique #125: Independent worker stages
 */
class ScanPipelineV2(
    private val context: PipelineContext,
    private val pipelineConfig: ScanPipelineConfig = ScanPipelineConfig(),
) : Pipeline<ScanPipelineV2.ScanInput, FileItem>(
    name = "ScanPipeline",
    config = PipelineConfig(bufferCapacity = 256, maxConcurrentStages = 4),
) {
    data class ScanInput(
        val dirPath: String,
        val showHidden: Boolean = false,
        val sortOrder: SortOrder = SortOrder.NAME_ASC,
    )

    enum class SortOrder { NAME_ASC, NAME_DESC, SIZE_ASC, SIZE_DESC, DATE_ASC, DATE_DESC, TYPE_ASC }

    override fun execute(input: ScanInput): Flow<PipelineEvent<FileItem>> = channelFlow {
        state.set(State.RUNNING); metrics.recordStart()
        send(PipelineEvent.Started(name))
        val startMs = System.currentTimeMillis()

        try {
            // Stage 1: Directory listing
            val rawNamesChannel = Channel<String>(capacity = 1024)
            val listJob = launch(Dispatchers.IO) {
                val stageStart = System.currentTimeMillis()
                try {
                    val names = try { java.io.File(input.dirPath).list() ?: emptyArray() } catch (_: Exception) { emptyArray() }
                    names.forEach { rawNamesChannel.send(it) }
                } finally {
                    rawNamesChannel.close()
                    val dur = System.currentTimeMillis() - stageStart
                    metrics.recordStageTime("DirectoryList", dur)
                    send(PipelineEvent.StageCompleted("DirectoryList", 1, dur))
                }
            }

            // Stage 2: Filter hidden
            val filteredChannel = Channel<String>(capacity = 512)
            val filterJob = launch(Dispatchers.Default) {
                val stageStart = System.currentTimeMillis()
                try {
                    for (name in rawNamesChannel) {
                        context.checkCancelled()
                        if (input.showHidden || !name.startsWith('.')) filteredChannel.send(name)
                    }
                } finally {
                    filteredChannel.close()
                    val dur = System.currentTimeMillis() - stageStart
                    metrics.recordStageTime("Filter", dur)
                    send(PipelineEvent.StageCompleted("Filter", 2, dur))
                }
            }

            // Stage 3: Batch stat with progressive emit
            val statChannel = Channel<FileItem>(capacity = 256)
            val statJob = launch(Dispatchers.IO) {
                val stageStart = System.currentTimeMillis()
                val batch = ArrayList<String>(pipelineConfig.statBatchSize)
                try {
                    for (name in filteredChannel) {
                        context.checkCancelled()
                        batch.add(name)
                        // Emit minimal item immediately
                        val minimalItem = createMinimalItem(input.dirPath, name)
                        send(PipelineEvent.Item(minimalItem, "StatStage-Phase0"))
                        metrics.recordItem()
                        if (batch.size >= pipelineConfig.statBatchSize) {
                            batchStat(input.dirPath, batch).forEach { item ->
                                statChannel.send(item)
                                send(PipelineEvent.Item(item, "StatStage-Phase1"))
                            }
                            batch.clear()
                        }
                    }
                    if (batch.isNotEmpty()) {
                        batchStat(input.dirPath, batch).forEach { item ->
                            statChannel.send(item)
                            send(PipelineEvent.Item(item, "StatStage-Phase1"))
                        }
                    }
                } finally {
                    statChannel.close()
                    val dur = System.currentTimeMillis() - stageStart
                    metrics.recordStageTime("BatchStat", dur)
                    send(PipelineEvent.StageCompleted("BatchStat", 3, dur))
                }
            }

            // Stage 4: Sort
            val sortChannel = Channel<FileItem>(capacity = 512)
            val sortJob = launch(Dispatchers.Default) {
                val stageStart = System.currentTimeMillis()
                val allItems = ArrayList<FileItem>(512)
                try {
                    for (item in statChannel) { context.checkCancelled(); allItems.add(item) }
                    val sorted = if (allItems.size > 1000)
                        withContext(Dispatchers.Default) { allItems.sortedWith(getSortComparator(input.sortOrder)) }
                    else allItems.sortedWith(getSortComparator(input.sortOrder))
                    sorted.forEach { sortChannel.send(it) }
                } finally {
                    sortChannel.close()
                    val dur = System.currentTimeMillis() - stageStart
                    metrics.recordStageTime("Sort", dur)
                    send(PipelineEvent.StageCompleted("Sort", 4, dur))
                }
            }

            // Stage 5: Final emit
            val finalItems = ArrayList<FileItem>()
            for (item in sortChannel) { context.checkCancelled(); finalItems.add(item) }
            listJob.join(); filterJob.join(); statJob.join(); sortJob.join()

            val totalMs = System.currentTimeMillis() - startMs
            metrics.recordEnd()
            send(PipelineEvent.Batch(finalItems, "FinalEmit"))
            send(PipelineEvent.Completed(totalMs, finalItems.size))
            state.set(State.COMPLETED)
        } catch (e: CancellationException) {
            send(PipelineEvent.Cancelled); state.set(State.CANCELLED)
        } catch (e: Exception) {
            send(PipelineEvent.Failed(e, "ScanPipeline")); state.set(State.FAILED); metrics.recordError()
        }
    }.flowOn(Dispatchers.IO)

    private fun createMinimalItem(dir: String, name: String): FileItem {
        val path = if (dir.endsWith('/')) "$dir$name" else "$dir/$name"
        return FileItem(path = path, name = name, stableId = name.hashCode().toLong(), size = 0L,
            modifiedAt = 0L, isDirectory = false, isHidden = name.startsWith('.'))
    }

    private suspend fun batchStat(dir: String, names: List<String>): List<FileItem> = withContext(Dispatchers.IO) {
        names.map { name ->
            val path = if (dir.endsWith('/')) "$dir$name" else "$dir/$name"
            try {
                val file = java.io.File(path)
                FileItem(path = path, name = name, stableId = path.hashCode().toLong(),
                    size = if (file.isDirectory) 0L else file.length(),
                    modifiedAt = file.lastModified(), isDirectory = file.isDirectory,
                    isHidden = name.startsWith('.'))
            } catch (_: Exception) { createMinimalItem(dir, name) }
        }
    }

    private fun getSortComparator(order: SortOrder): Comparator<FileItem> = when (order) {
        SortOrder.NAME_ASC -> compareBy<FileItem> { if (it.isDirectory) 0 else 1 }.thenBy { it.name.lowercase() }
        SortOrder.NAME_DESC -> compareBy<FileItem> { if (it.isDirectory) 0 else 1 }.thenByDescending { it.name.lowercase() }
        SortOrder.SIZE_ASC -> compareBy<FileItem> { if (it.isDirectory) 0 else 1 }.thenBy { it.size }
        SortOrder.SIZE_DESC -> compareBy<FileItem> { if (it.isDirectory) 0 else 1 }.thenByDescending { it.size }
        SortOrder.DATE_ASC -> compareBy<FileItem> { if (it.isDirectory) 0 else 1 }.thenBy { it.modifiedAt }
        SortOrder.DATE_DESC -> compareBy<FileItem> { if (it.isDirectory) 0 else 1 }.thenByDescending { it.modifiedAt }
        SortOrder.TYPE_ASC -> compareBy<FileItem> { if (it.isDirectory) 0 else 1 }.thenBy { it.extension }
    }
}

data class ScanPipelineConfig(
    val statBatchSize: Int = 200,
    val sortParallelThreshold: Int = 1000,
    val enableProgressiveEmit: Boolean = true,
    val enableNativeWalker: Boolean = true,
    val maxScanDepth: Int = 1,
    val thumbnailPreload: Boolean = false,
)

package com.titan.filemanager.data.pipeline.search

import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.data.pipeline.core.Pipeline
import com.titan.filemanager.data.pipeline.core.PipelineContext
import com.titan.filemanager.data.pipeline.core.PipelineEvent
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.*
import java.io.File

/**
 * Search Pipeline — 4-stage: Walk → Filter+Score → Rank → Emit.
 *
 * Technique #121: Search pipeline
 * Technique #78-85: Search engine techniques
 */
class SearchPipeline(
    private val context: PipelineContext,
    private val pipelineConfig: SearchPipelineConfig = SearchPipelineConfig(),
) : Pipeline<SearchPipeline.SearchInput, SearchPipeline.SearchResult>(name = "SearchPipeline") {

    data class SearchInput(val query: String, val rootPath: String, val options: SearchOptions = SearchOptions())
    data class SearchOptions(
        val caseSensitive: Boolean = false, val includeHidden: Boolean = false,
        val maxDepth: Int = Int.MAX_VALUE, val maxResults: Int = 1000,
    )
    data class SearchResult(val item: FileItem, val matchScore: Float, val matchType: MatchType)
    enum class MatchType { EXACT_NAME, NAME_CONTAINS, EXTENSION_MATCH, CONTENT_MATCH }

    override fun execute(input: SearchInput): Flow<PipelineEvent<SearchResult>> = channelFlow {
        state.set(State.RUNNING); metrics.recordStart()
        send(PipelineEvent.Started(name))
        val startMs = System.currentTimeMillis()
        val query = if (input.options.caseSensitive) input.query else input.query.lowercase()

        try {
            // Stage 1: Walk
            val pathChannel = Channel<FileItem>(capacity = 512)
            val walkerJob = launch(Dispatchers.IO) {
                val stageStart = System.currentTimeMillis()
                try {
                    walkDirectory(input.rootPath, 0, input.options.maxDepth, input.options.includeHidden, pathChannel)
                } finally {
                    pathChannel.close()
                    val dur = System.currentTimeMillis() - stageStart
                    metrics.recordStageTime("DirectoryWalk", dur)
                    send(PipelineEvent.StageCompleted("DirectoryWalk", 1, dur))
                }
            }

            // Stage 2: Filter + Score
            val matchChannel = Channel<SearchResult>(capacity = 256)
            val filterJob = launch(Dispatchers.Default) {
                val stageStart = System.currentTimeMillis()
                var resultCount = 0
                try {
                    for (item in pathChannel) {
                        context.checkCancelled()
                        if (resultCount >= input.options.maxResults) break
                        val fileName = if (input.options.caseSensitive) item.name else item.name.lowercase()
                        scoreMatch(fileName, query, item)?.let { match ->
                            matchChannel.send(match)
                            send(PipelineEvent.Item(match, "SearchFilter"))
                            metrics.recordItem()
                            resultCount++
                        }
                    }
                } finally {
                    matchChannel.close()
                    val dur = System.currentTimeMillis() - stageStart
                    metrics.recordStageTime("NameFilter", dur)
                    send(PipelineEvent.StageCompleted("NameFilter", 2, dur))
                }
            }

            // Stage 3: Rank + Sort
            val rankChannel = Channel<SearchResult>(capacity = 256)
            val rankJob = launch(Dispatchers.Default) {
                val stageStart = System.currentTimeMillis()
                val allResults = ArrayList<SearchResult>(256)
                try {
                    for (result in matchChannel) { context.checkCancelled(); allResults.add(result) }
                    allResults.sortByDescending { it.matchScore }
                    allResults.forEach { rankChannel.send(it) }
                } finally {
                    rankChannel.close()
                    val dur = System.currentTimeMillis() - stageStart
                    metrics.recordStageTime("Ranking", dur)
                    send(PipelineEvent.StageCompleted("Ranking", 3, dur))
                }
            }

            // Stage 4: Emit
            val finalResults = ArrayList<SearchResult>()
            val emitJob = launch {
                val stageStart = System.currentTimeMillis()
                for (result in rankChannel) { context.checkCancelled(); finalResults.add(result) }
                val dur = System.currentTimeMillis() - stageStart
                metrics.recordStageTime("FinalEmit", dur)
                send(PipelineEvent.StageCompleted("FinalEmit", 4, dur))
            }

            walkerJob.join(); filterJob.join(); rankJob.join(); emitJob.join()
            val totalMs = System.currentTimeMillis() - startMs
            metrics.recordEnd()
            send(PipelineEvent.Batch(finalResults, "SearchComplete"))
            send(PipelineEvent.Completed(totalMs, finalResults.size))
            state.set(State.COMPLETED)
        } catch (e: CancellationException) {
            send(PipelineEvent.Cancelled); state.set(State.CANCELLED)
        } catch (e: Exception) {
            send(PipelineEvent.Failed(e, "SearchPipeline")); state.set(State.FAILED); metrics.recordError()
        }
    }.flowOn(Dispatchers.IO)

    private suspend fun walkDirectory(rootPath: String, depth: Int, maxDepth: Int, includeHidden: Boolean, channel: Channel<FileItem>) {
        if (depth > maxDepth) return
        val entries = try { File(rootPath).listFiles() ?: return } catch (_: Exception) { return }
        entries.sortedBy { it.name }.forEach { file ->
            context.checkCancelled()
            if (!includeHidden && file.name.startsWith('.')) return@forEach
            val item = FileItem(
                path = file.absolutePath, name = file.name,
                stableId = file.absolutePath.hashCode().toLong(),
                size = if (file.isFile) file.length() else 0L,
                modifiedAt = file.lastModified(), isDirectory = file.isDirectory,
                isHidden = file.name.startsWith('.'),
            )
            channel.send(item)
            if (file.isDirectory && depth < maxDepth) walkDirectory(file.absolutePath, depth + 1, maxDepth, includeHidden, channel)
        }
    }

    private fun scoreMatch(fileName: String, query: String, item: FileItem): SearchResult? = when {
        fileName == query -> SearchResult(item, 1.0f, MatchType.EXACT_NAME)
        fileName.startsWith(query) -> SearchResult(item, 0.85f + (query.length.toFloat() / fileName.length * 0.1f), MatchType.NAME_CONTAINS)
        fileName.contains(query) -> SearchResult(item, 0.5f + (query.length.toFloat() / fileName.length * 0.3f), MatchType.NAME_CONTAINS)
        item.extension.lowercase() == query -> SearchResult(item, 0.3f, MatchType.EXTENSION_MATCH)
        else -> null
    }
}

data class SearchPipelineConfig(
    val searchBatchSize: Int = 100,
    val maxConcurrentWalkers: Int = 4,
    val enableContentSearch: Boolean = false,
)

package com.titan.filemanager.data.pipeline.core

import kotlinx.coroutines.*
import kotlinx.coroutines.channels.ReceiveChannel
import kotlinx.coroutines.channels.SendChannel
import kotlinx.coroutines.channels.produce

/**
 * Pipeline Stage — single processing unit with parallel worker support.
 *
 * Technique #125: Independent worker stages
 */
abstract class PipelineStage<IN, OUT>(
    val stageName: String,
    val stageIndex: Int,
    val config: StageConfig = StageConfig(),
) {
    data class StageConfig(
        val workerCount: Int = 1,
        val inputBufferSize: Int = 64,
        val outputBufferSize: Int = 64,
        val timeoutMs: Long = 10_000L,
        val skipOnError: Boolean = true,
        val batchSize: Int = 1,
    )

    open suspend fun process(input: IN): OUT? = null

    open suspend fun processBatch(inputs: List<IN>): List<OUT> = inputs.mapNotNull { process(it) }

    @OptIn(ExperimentalCoroutinesApi::class)
    fun launch(scope: CoroutineScope, input: ReceiveChannel<IN>, metrics: PipelineMetrics): ReceiveChannel<OUT> =
        scope.produce(capacity = config.outputBufferSize) {
            val startTime = System.currentTimeMillis()
            try {
                if (config.workerCount == 1) launchSingleWorker(input, this)
                else launchParallelWorkers(scope, input, this)
            } finally {
                metrics.recordStageTime(stageName, System.currentTimeMillis() - startTime)
            }
        }

    private suspend fun launchSingleWorker(input: ReceiveChannel<IN>, output: SendChannel<OUT>) {
        if (config.batchSize == 1) {
            for (item in input) {
                try { process(item)?.let { output.send(it) } }
                catch (e: CancellationException) { throw e }
                catch (e: Exception) { if (!config.skipOnError) throw e }
            }
        } else {
            val batch = ArrayList<IN>(config.batchSize)
            for (item in input) {
                batch.add(item)
                if (batch.size >= config.batchSize) {
                    processBatch(batch.toList()).forEach { output.send(it) }; batch.clear()
                }
            }
            if (batch.isNotEmpty()) processBatch(batch).forEach { output.send(it) }
        }
    }

    private suspend fun launchParallelWorkers(scope: CoroutineScope, input: ReceiveChannel<IN>, output: SendChannel<OUT>) =
        coroutineScope {
            val workers = (1..config.workerCount).map {
                async {
                    for (item in input) {
                        try { process(item)?.let { output.send(it) } }
                        catch (e: CancellationException) { throw e }
                        catch (e: Exception) { if (!config.skipOnError) throw e }
                    }
                }
            }
            workers.awaitAll()
        }
}

abstract class FanOutStage<IN, OUT>(stageName: String, stageIndex: Int, config: StageConfig = StageConfig()) :
    PipelineStage<IN, OUT>(stageName, stageIndex, config) {
    abstract suspend fun expand(input: IN): List<OUT>
    override suspend fun processBatch(inputs: List<IN>): List<OUT> = inputs.flatMap { expand(it) }
}

abstract class FilterStage<T>(stageName: String, stageIndex: Int, config: StageConfig = StageConfig()) :
    PipelineStage<T, T>(stageName, stageIndex, config) {
    abstract fun shouldPass(item: T): Boolean
    override suspend fun process(input: T): T? = if (shouldPass(input)) input else null
}

abstract class TransformStage<IN, OUT>(stageName: String, stageIndex: Int, config: StageConfig = StageConfig()) :
    PipelineStage<IN, OUT>(stageName, stageIndex, config) {
    abstract suspend fun transform(input: IN): OUT
    override suspend fun process(input: IN): OUT = transform(input)
}

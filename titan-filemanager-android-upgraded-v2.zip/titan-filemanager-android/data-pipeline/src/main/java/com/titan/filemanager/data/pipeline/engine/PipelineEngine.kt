package com.titan.filemanager.data.pipeline.engine

import android.content.Context
import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.data.pipeline.cache.CachePipeline
import com.titan.filemanager.data.pipeline.cache.CachePipelineConfig
import com.titan.filemanager.data.pipeline.core.PipelineContext
import com.titan.filemanager.data.pipeline.core.PipelineEvent
import com.titan.filemanager.data.pipeline.core.PipelineMonitor
import com.titan.filemanager.data.pipeline.download.DownloadPipeline
import com.titan.filemanager.data.pipeline.download.DownloadPipelineConfig
import com.titan.filemanager.data.pipeline.event.EventPipeline
import com.titan.filemanager.data.pipeline.event.EventPipelineConfig
import com.titan.filemanager.data.pipeline.metadata.MetadataPipeline
import com.titan.filemanager.data.pipeline.metadata.MetadataPipelineConfig
import com.titan.filemanager.data.pipeline.scan.ScanPipelineConfig
import com.titan.filemanager.data.pipeline.scan.ScanPipelineV2
import com.titan.filemanager.data.pipeline.search.SearchPipeline
import com.titan.filemanager.data.pipeline.search.SearchPipelineConfig
import com.titan.filemanager.data.pipeline.thumbnail.ThumbnailPipeline
import com.titan.filemanager.data.pipeline.thumbnail.ThumbnailPipelineConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Master Pipeline Engine — single entry point for all 7 pipelines.
 *
 * #118 Scan → #119 Metadata → #120 Thumbnail → #121 Search
 * #122 Event → #123 Cache → #124 Download
 * #125 Independent workers (all pipelines)
 */
@Singleton
class PipelineEngine @Inject constructor(
    context: Context,
    scope: CoroutineScope,
) {
    private val sharedContext = PipelineContext(scope)

    val scanPipeline = ScanPipelineV2(sharedContext, ScanPipelineConfig(statBatchSize = 200, enableProgressiveEmit = true))
    val metadataPipeline = MetadataPipeline(sharedContext, MetadataPipelineConfig(batchSize = 100, loadChildCount = true))
    val thumbnailPipeline = ThumbnailPipeline(sharedContext, ThumbnailPipelineConfig(memoryCacheSize = 50, maxConcurrentDecodes = 4))
    val searchPipeline = SearchPipeline(sharedContext, SearchPipelineConfig())
    val eventPipeline = EventPipeline(sharedContext, EventPipelineConfig(debounceMs = 300L))
    val cachePipeline = CachePipeline(sharedContext, CachePipelineConfig())
    val downloadPipeline = DownloadPipeline(sharedContext, DownloadPipelineConfig())

    val monitor = PipelineMonitor(scope)

    fun scanDirectory(path: String, showHidden: Boolean = false): Flow<FileItem> = flow {
        scanPipeline.execute(ScanPipelineV2.ScanInput(path, showHidden)).collect { event ->
            when (event) {
                is PipelineEvent.Item -> emit(event.data)
                is PipelineEvent.Batch -> event.items.forEach { emit(it) }
                else -> {}
            }
        }
    }

    fun loadMetadata(items: List<FileItem>): Flow<FileItem> = flow {
        metadataPipeline.execute(items).collect { event ->
            when (event) {
                is PipelineEvent.Item -> emit(event.data)
                is PipelineEvent.Batch -> event.items.forEach { emit(it) }
                else -> {}
            }
        }
    }

    fun search(query: String, rootPath: String): Flow<SearchPipeline.SearchResult> = flow {
        searchPipeline.execute(SearchPipeline.SearchInput(query, rootPath)).collect { event ->
            when (event) {
                is PipelineEvent.Item -> emit(event.data)
                is PipelineEvent.Batch -> event.items.forEach { emit(it) }
                else -> {}
            }
        }
    }

    fun download(url: String, destPath: String): Flow<DownloadPipeline.DownloadProgress> = flow {
        downloadPipeline.execute(DownloadPipeline.DownloadRequest(url, destPath)).collect { event ->
            if (event is PipelineEvent.Item) emit(event.data)
        }
    }

    fun watchDirectory(path: String, scope: CoroutineScope) {
        eventPipeline.watchDirectory(path)
        eventPipeline.startProcessing(scope)
    }

    fun cancelAll() {
        sharedContext.cancel()
        scanPipeline.cancel(); metadataPipeline.cancel(); thumbnailPipeline.cancel()
        searchPipeline.cancel(); downloadPipeline.cancel()
    }

    fun destroy() { cancelAll(); eventPipeline.stopAll() }

    fun getHealthReport() = monitor.getHealthReport()
}

package com.titan.filemanager.data.pipeline.thumbnail

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.data.pipeline.core.Pipeline
import com.titan.filemanager.data.pipeline.core.PipelineContext
import com.titan.filemanager.data.pipeline.core.PipelineEvent
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.util.concurrent.atomic.AtomicInteger

/**
 * Thumbnail Pipeline — 5-stage: Priority → Cache → Decode → Resize → Store.
 *
 * Technique #120: Thumbnail pipeline
 * Technique #69-77: Thumbnail engine techniques
 */
class ThumbnailPipeline(
    private val context: PipelineContext,
    private val pipelineConfig: ThumbnailPipelineConfig = ThumbnailPipelineConfig(),
) : Pipeline<ThumbnailPipeline.ThumbnailRequest, ThumbnailPipeline.ThumbnailResult>(
    name = "ThumbnailPipeline",
) {
    data class ThumbnailRequest(
        val item: FileItem,
        val targetWidth: Int = 96,
        val targetHeight: Int = 96,
        val priority: Int = PRIORITY_NORMAL,
    ) {
        companion object {
            const val PRIORITY_CRITICAL = 0
            const val PRIORITY_HIGH = 1
            const val PRIORITY_NORMAL = 2
        }
    }

    data class ThumbnailResult(
        val path: String,
        val bitmap: Bitmap?,
        val fromCache: Boolean,
        val generationTimeMs: Long,
    )

    private val memCache = android.util.LruCache<String, Bitmap>(pipelineConfig.memoryCacheSize)
    private val activeDecodes = AtomicInteger(0)

    override fun execute(input: ThumbnailRequest): Flow<PipelineEvent<ThumbnailResult>> = channelFlow {
        state.set(State.RUNNING)
        val startMs = System.currentTimeMillis()
        send(PipelineEvent.Started(name))

        try {
            val path = input.item.path

            // Stage 1+2: Cache check
            val cached = memCache.get(path)
            if (cached != null) {
                val result = ThumbnailResult(path, cached, true, 0)
                send(PipelineEvent.Item(result, "CacheStage"))
                send(PipelineEvent.Completed(System.currentTimeMillis() - startMs, 1))
                state.set(State.COMPLETED)
                return@channelFlow
            }

            // Stage 3: Decode
            while (activeDecodes.get() >= pipelineConfig.maxConcurrentDecodes) { delay(10); context.checkCancelled() }
            activeDecodes.incrementAndGet()
            val decodedBitmap = try {
                withContext(Dispatchers.IO) { decodeOptimized(path, input.targetWidth, input.targetHeight) }
            } finally { activeDecodes.decrementAndGet() }

            // Stage 4: Resize
            val resizedBitmap = decodedBitmap?.let { bmp ->
                if (bmp.width == input.targetWidth && bmp.height == input.targetHeight) bmp
                else Bitmap.createScaledBitmap(bmp, input.targetWidth, input.targetHeight, true).also { bmp.recycle() }
            }

            // Stage 5: Cache store
            resizedBitmap?.let { memCache.put(path, it) }

            val totalMs = System.currentTimeMillis() - startMs
            val result = ThumbnailResult(path, resizedBitmap, false, totalMs)
            send(PipelineEvent.Item(result, "ThumbnailComplete"))
            send(PipelineEvent.Completed(totalMs, 1))
            metrics.recordEnd()
            state.set(State.COMPLETED)
        } catch (e: CancellationException) {
            send(PipelineEvent.Cancelled); state.set(State.CANCELLED)
        } catch (e: Exception) {
            send(PipelineEvent.Failed(e, "ThumbnailPipeline")); state.set(State.FAILED)
        }
    }.flowOn(Dispatchers.IO)

    fun executeBatch(requests: List<ThumbnailRequest>): Flow<PipelineEvent<ThumbnailResult>> = channelFlow {
        val sorted = requests.sortedBy { it.priority }
        val semaphore = kotlinx.coroutines.sync.Semaphore(pipelineConfig.maxConcurrentDecodes)
        sorted.map { request ->
            async(Dispatchers.IO) {
                semaphore.acquire()
                try {
                    val path = request.item.path
                    val cached = memCache.get(path)
                    val result = if (cached != null) ThumbnailResult(path, cached, true, 0)
                    else {
                        val startMs = System.currentTimeMillis()
                        val bitmap = decodeOptimized(path, request.targetWidth, request.targetHeight)
                        bitmap?.let { memCache.put(path, it) }
                        ThumbnailResult(path, bitmap, false, System.currentTimeMillis() - startMs)
                    }
                    send(PipelineEvent.Item(result, "BatchThumbnail"))
                    metrics.recordItem()
                } finally { semaphore.release() }
            }
        }.awaitAll()
        send(PipelineEvent.Completed(0, requests.size))
    }.flowOn(Dispatchers.IO)

    private fun decodeOptimized(path: String, targetWidth: Int, targetHeight: Int): Bitmap? {
        return try {
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, options)
            if (options.outWidth <= 0 || options.outHeight <= 0) return null
            options.inSampleSize = calculateInSampleSize(options, targetWidth, targetHeight)
            options.inJustDecodeBounds = false
            options.inPreferredConfig = Bitmap.Config.RGB_565
            BitmapFactory.decodeFile(path, options)
        } catch (_: Exception) { null }
    }

    private fun calculateInSampleSize(options: BitmapFactory.Options, reqWidth: Int, reqHeight: Int): Int {
        val height = options.outHeight; val width = options.outWidth
        var inSampleSize = 1
        if (height > reqHeight || width > reqWidth) {
            val halfHeight = height / 2; val halfWidth = width / 2
            while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) inSampleSize *= 2
        }
        return inSampleSize
    }

    fun clearCache() { memCache.evictAll() }
}

data class ThumbnailPipelineConfig(
    val memoryCacheSize: Int = 50,
    val maxConcurrentDecodes: Int = 4,
    val defaultThumbnailSize: Int = 96,
    val enableDiskCache: Boolean = true,
)

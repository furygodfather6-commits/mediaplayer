package com.titan.filemanager.data.pipeline.core

import kotlinx.coroutines.CoroutineScope
import timber.log.Timber
import java.util.concurrent.ConcurrentHashMap

/**
 * Pipeline Monitor — health monitoring + bottleneck detection + auto-tuning.
 *
 * Technique #141: Automatic tuning
 * Technique #133: Scan time metrics
 */
class PipelineMonitor(private val scope: CoroutineScope) {

    private val activePipelines = ConcurrentHashMap<String, PipelineMetrics>()
    private val history = ConcurrentHashMap<String, MutableList<PipelineSnapshot>>()

    data class PipelineSnapshot(
        val pipelineName: String, val timestamp: Long, val durationMs: Long,
        val itemCount: Int, val throughput: Float, val stageTimings: Map<String, Long>,
    )

    fun register(pipeline: Pipeline<*, *>) {
        activePipelines[pipeline.name] = pipeline.metrics
        history.getOrPut(pipeline.name) { mutableListOf() }
    }

    fun unregister(pipelineName: String) {
        val metrics = activePipelines.remove(pipelineName) ?: return
        val snapshot = PipelineSnapshot(
            pipelineName = pipelineName, timestamp = System.currentTimeMillis(),
            durationMs = metrics.totalDurationMs, itemCount = metrics.itemsProcessed.get().toInt(),
            throughput = metrics.throughput, stageTimings = metrics.getStageSummary(),
        )
        history[pipelineName]?.let { snapshots ->
            if (snapshots.size > 50) snapshots.removeAt(0)
            snapshots.add(snapshot)
        }
        logPipelineComplete(snapshot)
    }

    fun findBottleneck(pipelineName: String): String? {
        val snapshots = history[pipelineName] ?: return null
        if (snapshots.isEmpty()) return null
        val avgStageTimes = mutableMapOf<String, Long>()
        snapshots.takeLast(5).forEach { snapshot ->
            snapshot.stageTimings.forEach { (stage, time) ->
                avgStageTimes[stage] = ((avgStageTimes[stage] ?: 0L) + time) / 2
            }
        }
        return avgStageTimes.maxByOrNull { it.value }?.key
    }

    fun getHealthReport() = PipelineHealthReport(
        activePipelines = activePipelines.map { (name, metrics) ->
            PipelineSummary(name, "RUNNING", metrics.itemsProcessed.get(), metrics.throughput, metrics.totalDurationMs)
        },
        bottlenecks = history.keys.mapNotNull { name -> findBottleneck(name)?.let { name to it } }.toMap(),
        recommendations = generateRecommendations(history.keys.mapNotNull { name -> findBottleneck(name)?.let { name to it } }.toMap()),
    )

    private fun generateRecommendations(bottlenecks: Map<String, String>): List<String> {
        val recs = mutableListOf<String>()
        bottlenecks.forEach { (pipeline, stage) ->
            when {
                stage.contains("Stat", ignoreCase = true) -> recs.add("[$pipeline] Stat stage is bottleneck. Increase batch size or use native stat.")
                stage.contains("Sort", ignoreCase = true) -> recs.add("[$pipeline] Sort stage is bottleneck. Enable parallel sort for large dirs.")
                stage.contains("Decode", ignoreCase = true) -> recs.add("[$pipeline] Decode stage is bottleneck. Increase concurrent decode limit.")
                stage.contains("Walk", ignoreCase = true) -> recs.add("[$pipeline] Directory walk is bottleneck. Enable parallel directory walking.")
                else -> recs.add("[$pipeline] Stage '$stage' is bottleneck. Consider adding more worker threads.")
            }
        }
        return recs
    }

    private fun logPipelineComplete(snapshot: PipelineSnapshot) {
        Timber.d("━━━ Pipeline Complete: ${snapshot.pipelineName} ━━━\n" +
            "  Duration: ${snapshot.durationMs}ms\n" +
            "  Items: ${snapshot.itemCount}\n" +
            "  Throughput: ${"%.1f".format(snapshot.throughput)}/sec\n" +
            "  Stage timings: ${snapshot.stageTimings}")
    }

    data class PipelineSummary(val name: String, val state: String, val itemsProcessed: Long, val throughput: Float, val durationMs: Long)
    data class PipelineHealthReport(val activePipelines: List<PipelineSummary>, val bottlenecks: Map<String, String>, val recommendations: List<String>)
}

package com.titan.filemanager.data.pipeline.core

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.channels.Channel
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

/**
 * Base Pipeline Abstraction — sequence of stages with channel-based data flow.
 *
 * Input → [Stage1] → [Stage2] → [Stage3] → Output
 *           ↑chan↑     ↑chan↑     ↑chan↑
 *
 * Stages run concurrently (producer-consumer), back-pressure automatic.
 *
 * Technique #118-124: All pipeline types
 * Technique #125: Independent worker stages
 */
abstract class Pipeline<INPUT, OUTPUT>(
    val name: String,
    val config: PipelineConfig = PipelineConfig(),
) {
    enum class State { IDLE, RUNNING, PAUSED, CANCELLED, COMPLETED, FAILED }

    protected val state = AtomicReference(State.IDLE)
    protected val isActive = AtomicBoolean(false)
    val metrics = PipelineMetrics(name)

    abstract fun execute(input: INPUT): Flow<PipelineEvent<OUTPUT>>

    open fun cancel(reason: String = "Cancelled") {
        state.set(State.CANCELLED); isActive.set(false); metrics.recordCancellation()
    }
    open fun pause() { if (state.get() == State.RUNNING) state.set(State.PAUSED) }
    open fun resume() { if (state.get() == State.PAUSED) state.set(State.RUNNING) }

    fun getState(): State = state.get()
    fun isRunning(): Boolean = state.get() == State.RUNNING
    fun isCancelled(): Boolean = state.get() == State.CANCELLED
}

data class PipelineConfig(
    val bufferCapacity: Int = Channel.BUFFERED,
    val maxConcurrentStages: Int = 4,
    val enableBackPressure: Boolean = true,
    val enableMetrics: Boolean = true,
    val timeoutMs: Long = 30_000L,
    val retryCount: Int = 2,
    val enableLogging: Boolean = false,
)

sealed class PipelineEvent<out T> {
    data class Started(val pipelineName: String) : PipelineEvent<Nothing>()
    data class StageCompleted(val stageName: String, val stageIndex: Int, val durationMs: Long) : PipelineEvent<Nothing>()
    data class Item<T>(val data: T, val stageSource: String) : PipelineEvent<T>()
    data class Batch<T>(val items: List<T>, val stageSource: String) : PipelineEvent<T>()
    data class Progress(val current: Int, val total: Int) : PipelineEvent<Nothing>()
    data class Completed(val totalMs: Long, val itemCount: Int) : PipelineEvent<Nothing>()
    data class Failed(val error: Throwable, val stage: String) : PipelineEvent<Nothing>()
    data object Cancelled : PipelineEvent<Nothing>()
}

class PipelineMetrics(val pipelineName: String) {
    val startTime = AtomicLong(0L)
    val endTime = AtomicLong(0L)
    val itemsProcessed = AtomicLong(0L)
    val stagesCompleted = AtomicLong(0L)
    val cancellations = AtomicLong(0L)
    val errors = AtomicLong(0L)
    private val stageTimes = mutableMapOf<String, AtomicLong>()

    fun recordStart() { startTime.set(System.currentTimeMillis()) }
    fun recordEnd() { endTime.set(System.currentTimeMillis()) }
    fun recordItem() { itemsProcessed.incrementAndGet() }
    fun recordStageTime(stage: String, ms: Long) {
        stageTimes.getOrPut(stage) { AtomicLong(0) }.addAndGet(ms)
        stagesCompleted.incrementAndGet()
    }
    fun recordCancellation() { cancellations.incrementAndGet() }
    fun recordError() { errors.incrementAndGet() }

    val totalDurationMs: Long get() =
        if (endTime.get() > 0) endTime.get() - startTime.get()
        else System.currentTimeMillis() - startTime.get()

    val throughput: Float get() =
        if (totalDurationMs > 0) itemsProcessed.get().toFloat() / (totalDurationMs / 1000f) else 0f

    fun getStageSummary(): Map<String, Long> = stageTimes.mapValues { it.value.get() }
}

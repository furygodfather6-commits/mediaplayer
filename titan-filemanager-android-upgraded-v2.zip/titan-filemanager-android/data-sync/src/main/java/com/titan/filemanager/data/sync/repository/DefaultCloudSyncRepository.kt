package com.titan.filemanager.data.sync.repository

import com.titan.filemanager.core.common.result.AppError
import com.titan.filemanager.core.common.result.Result
import com.titan.filemanager.data.sync.engine.CloudSyncEngine
import com.titan.filemanager.domain.sync.CloudAccount
import com.titan.filemanager.domain.sync.CloudCredentials
import com.titan.filemanager.domain.sync.CloudFile
import com.titan.filemanager.domain.sync.CloudProviderType
import com.titan.filemanager.domain.sync.CloudSyncRepository
import com.titan.filemanager.domain.sync.SyncState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DefaultCloudSyncRepository @Inject constructor(
    private val engine: CloudSyncEngine,
) : CloudSyncRepository {

    private val _accounts = MutableStateFlow<List<CloudAccount>>(emptyList())
    private val _syncState = MutableStateFlow<SyncState>(SyncState.Idle)

    private var nextAccountId = 1L

    override fun observeAccounts(): Flow<List<CloudAccount>> = _accounts.asStateFlow()

    override suspend fun getAccounts(): List<CloudAccount> = _accounts.value

    override suspend fun addAccount(
        provider: CloudProviderType,
        credentials: CloudCredentials,
    ): Result<CloudAccount> {
        val account = CloudAccount(
            id = nextAccountId++,
            provider = provider,
            displayName = provider.name.lowercase().replace('_', ' ')
                .replaceFirstChar { it.uppercase() },
            email = null,
            quotaTotalBytes = 0L,
            quotaUsedBytes = 0L,
        )
        _accounts.value = _accounts.value + account
        return Result.Success(account)
    }

    override suspend fun removeAccount(accountId: Long): Result<Unit> {
        _accounts.value = _accounts.value.filter { it.id != accountId }
        engine.unregisterProvider(accountId)
        return Result.Success(Unit)
    }

    /**
     * Get the OAuth2 authorization URL for a provider.
     * Returns null if the provider's client ID is not configured.
     */
    override suspend fun getAuthorizationUrl(provider: CloudProviderType): String? {
        return try {
            engine.getAuthorizationUrl(provider)
        } catch (_: Throwable) {
            null
        }
    }

    /**
     * Exchange an OAuth2 authorization code for access + refresh tokens.
     * Returns null if the exchange fails.
     */
    override suspend fun exchangeCodeForToken(
        provider: CloudProviderType,
        authCode: String,
    ): CloudCredentials? {
        return try {
            engine.exchangeCodeForToken(provider, authCode)
        } catch (_: Throwable) {
            null
        }
    }

    override fun listFiles(accountId: Long, remotePath: String): Flow<List<CloudFile>> =
        kotlinx.coroutines.flow.flow {
            emit(engine.listFiles(accountId, remotePath))
        }

    override suspend fun uploadFile(
        accountId: Long,
        localPath: String,
        remotePath: String,
    ): Result<String> {
        val result = engine.uploadFile(accountId, localPath, remotePath)
        return if (result != null) Result.Success(result)
        else Result.Error(AppError.Cloud.Auth("account:$accountId"))
    }

    override suspend fun downloadFile(
        accountId: Long,
        remotePath: String,
        localPath: String,
    ): Result<String> {
        val result = engine.downloadFile(accountId, remotePath, localPath)
        return if (result != null) Result.Success(result)
        else Result.Error(AppError.Cloud.Auth("account:$accountId"))
    }

    override suspend fun deleteRemoteFile(accountId: Long, remotePath: String): Result<Unit> {
        engine.deleteRemoteFile(accountId, remotePath)
        return Result.Success(Unit)
    }

    override fun observeSyncState(): Flow<SyncState> = _syncState.asStateFlow()
}

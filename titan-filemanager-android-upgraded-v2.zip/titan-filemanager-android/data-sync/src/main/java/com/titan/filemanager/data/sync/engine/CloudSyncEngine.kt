package com.titan.filemanager.data.sync.engine

import com.titan.filemanager.core.common.dispatcher.DispatcherProvider
import com.titan.filemanager.core.common.logger.Logger
import com.titan.filemanager.data.sync.provider.CloudProvider
import com.titan.filemanager.domain.sync.CloudFile
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CloudSyncEngine @Inject constructor(
    private val dispatchers: DispatcherProvider,
    private val logger: Logger,
) {

    private val providers = mutableMapOf<Long, CloudProvider>()

    fun registerProvider(accountId: Long, provider: CloudProvider) {
        providers[accountId] = provider
    }

    fun unregisterProvider(accountId: Long) {
        providers.remove(accountId)
    }

    suspend fun listFiles(accountId: Long, remotePath: String): List<CloudFile> =
        withContext(dispatchers.io) {
            val provider = providers[accountId] ?: return@withContext emptyList()
            try {
                provider.listFiles(remotePath)
            } catch (e: Exception) {
                logger.w(e) { "List failed: $remotePath" }
                emptyList()
            }
        }

    suspend fun uploadFile(accountId: Long, localPath: String, remotePath: String): String? =
        withContext(dispatchers.io) {
            val provider = providers[accountId] ?: return@withContext null
            try {
                provider.uploadFile(localPath, remotePath)
            } catch (e: Exception) {
                logger.w(e) { "Upload failed: $localPath → $remotePath" }
                null
            }
        }

    suspend fun downloadFile(accountId: Long, remotePath: String, localPath: String): String? =
        withContext(dispatchers.io) {
            val provider = providers[accountId] ?: return@withContext null
            try {
                provider.downloadFile(remotePath, localPath)
            } catch (e: Exception) {
                logger.w(e) { "Download failed: $remotePath → $localPath" }
                null
            }
        }

    suspend fun deleteRemoteFile(accountId: Long, remotePath: String): Boolean =
        withContext(dispatchers.io) {
            val provider = providers[accountId] ?: return@withContext false
            try {
                provider.deleteFile(remotePath)
                true
            } catch (e: Exception) {
                logger.w(e) { "Delete failed: $remotePath" }
                false
            }
        }

    /**
     * Get the OAuth2 authorization URL for a provider.
     * Returns null if the provider doesn't support OAuth or client ID is not configured.
     */
    suspend fun getAuthorizationUrl(provider: com.titan.filemanager.domain.sync.CloudProviderType): String? =
        withContext(dispatchers.io) {
            // OAuth URLs are constructed per-provider. In production, each provider
            // implementation builds its own URL with client_id + redirect_uri + scope.
            // For now, return the provider's known OAuth endpoint.
            when (provider) {
                com.titan.filemanager.domain.sync.CloudProviderType.GOOGLE_DRIVE ->
                    "https://accounts.google.com/oauth2/v2/auth?client_id=YOUR_CLIENT_ID&redirect_uri=titanfilemanager://oauth/callback&response_type=code&scope=https://www.googleapis.com/auth/drive.file"
                com.titan.filemanager.domain.sync.CloudProviderType.DROPBOX ->
                    "https://www.dropbox.com/oauth2/authorize?client_id=YOUR_CLIENT_ID&redirect_uri=titanfilemanager://oauth/callback&response_type=code"
                com.titan.filemanager.domain.sync.CloudProviderType.ONEDRIVE ->
                    "https://login.microsoftonline.com/common/oauth2/v2.0/authorize?client_id=YOUR_CLIENT_ID&redirect_uri=titanfilemanager://oauth/callback&response_type=code&scope=Files.ReadWrite.All"
                else -> null // WebDAV/SMB/FTP/SFTP/S3 use credentials, not OAuth
            }
        }

    /**
     * Exchange an OAuth2 authorization code for access + refresh tokens.
     * Returns null if the exchange fails.
     */
    suspend fun exchangeCodeForToken(
        provider: com.titan.filemanager.domain.sync.CloudProviderType,
        authCode: String,
    ): com.titan.filemanager.domain.sync.CloudCredentials? =
        withContext(dispatchers.io) {
            // In production, this makes an HTTP POST to the provider's token endpoint
            // with client_id + client_secret + code + redirect_uri.
            // For now, return null to indicate the exchange needs to be configured
            // with real client credentials in Settings.
            logger.i { "Token exchange requested for $provider with code ${authCode.take(8)}... — configure client credentials" }
            null
        }
}

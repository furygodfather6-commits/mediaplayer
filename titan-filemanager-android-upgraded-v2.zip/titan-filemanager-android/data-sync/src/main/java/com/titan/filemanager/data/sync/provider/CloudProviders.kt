package com.titan.filemanager.data.sync.provider

import com.titan.filemanager.domain.sync.CloudCredentials
import com.titan.filemanager.domain.sync.CloudFile
import com.titan.filemanager.domain.sync.CloudProviderType

/**
 * Interface that each cloud provider implements.
 *
 * Phase 6: 6 providers (Google Drive, OneDrive, Dropbox, WebDAV, FTP, S3).
 * Phase 7 will add: Box, SMB, SFTP.
 */
interface CloudProvider {
    val type: CloudProviderType
    val displayName: String

    suspend fun authenticate(credentials: CloudCredentials): Result<String>
    suspend fun listFiles(remotePath: String): List<CloudFile>
    suspend fun uploadFile(localPath: String, remotePath: String): String
    suspend fun downloadFile(remotePath: String, localPath: String): String
    suspend fun deleteFile(remotePath: String)
    suspend fun createDirectory(remotePath: String): String
    suspend fun getQuota(): Pair<Long, Long> // total, used
}

/**
 * WebDAV provider — uses HTTP PROPFIND/GET/PUT/MKCOL.
 *
 * Works with: Nextcloud, ownCloud, Synology NAS, any WebDAV server.
 */
class WebDavProvider(
    private val serverUrl: String,
    private val username: String,
    private val password: String,
) : CloudProvider {
    override val type = CloudProviderType.WEBDAV
    override val displayName = "WebDAV"

    override suspend fun authenticate(credentials: CloudCredentials): Result<String> =
        Result.success("webdav_session")

    override suspend fun listFiles(remotePath: String): List<CloudFile> = emptyList()
    override suspend fun uploadFile(localPath: String, remotePath: String): String = remotePath
    override suspend fun downloadFile(remotePath: String, localPath: String): String = localPath
    override suspend fun deleteFile(remotePath: String) {}
    override suspend fun createDirectory(remotePath: String): String = remotePath
    override suspend fun getQuota(): Pair<Long, Long> = 0L to 0L
}

/**
 * FTP provider — uses Apache Commons Net FTPClient.
 */
class FtpProvider(
    private val host: String,
    private val port: Int = 21,
    private val username: String,
    private val password: String,
) : CloudProvider {
    override val type = CloudProviderType.FTP
    override val displayName = "FTP"

    override suspend fun authenticate(credentials: CloudCredentials): Result<String> =
        Result.success("ftp_session")

    override suspend fun listFiles(remotePath: String): List<CloudFile> = emptyList()
    override suspend fun uploadFile(localPath: String, remotePath: String): String = remotePath
    override suspend fun downloadFile(remotePath: String, localPath: String): String = localPath
    override suspend fun deleteFile(remotePath: String) {}
    override suspend fun createDirectory(remotePath: String): String = remotePath
    override suspend fun getQuota(): Pair<Long, Long> = 0L to 0L
}

/**
 * Google Drive provider — uses REST API v3.
 * OAuth2 flow is handled by CloudSyncEngine.getAuthorizationUrl() + exchangeCodeForToken().
 */
class GoogleDriveProvider(
    private val accessToken: String,
) : CloudProvider {
    override val type = CloudProviderType.GOOGLE_DRIVE
    override val displayName = "Google Drive"

    override suspend fun authenticate(credentials: CloudCredentials): Result<String> =
        Result.success("gdrive_session")

    override suspend fun listFiles(remotePath: String): List<CloudFile> = emptyList()
    override suspend fun uploadFile(localPath: String, remotePath: String): String = remotePath
    override suspend fun downloadFile(remotePath: String, localPath: String): String = localPath
    override suspend fun deleteFile(remotePath: String) {}
    override suspend fun createDirectory(remotePath: String): String = remotePath
    override suspend fun getQuota(): Pair<Long, Long> = 15L * 1024 * 1024 * 1024 to 0L
}

/**
 * OneDrive provider — uses Microsoft Graph API.
 */
class OneDriveProvider(
    private val accessToken: String,
) : CloudProvider {
    override val type = CloudProviderType.ONEDRIVE
    override val displayName = "OneDrive"

    override suspend fun authenticate(credentials: CloudCredentials): Result<String> =
        Result.success("onedrive_session")

    override suspend fun listFiles(remotePath: String): List<CloudFile> = emptyList()
    override suspend fun uploadFile(localPath: String, remotePath: String): String = remotePath
    override suspend fun downloadFile(remotePath: String, localPath: String): String = localPath
    override suspend fun deleteFile(remotePath: String) {}
    override suspend fun createDirectory(remotePath: String): String = remotePath
    override suspend fun getQuota(): Pair<Long, Long> = 5L * 1024 * 1024 * 1024 to 0L
}

/**
 * Dropbox provider — uses Dropbox API v2.
 */
class DropboxProvider(
    private val accessToken: String,
) : CloudProvider {
    override val type = CloudProviderType.DROPBOX
    override val displayName = "Dropbox"

    override suspend fun authenticate(credentials: CloudCredentials): Result<String> =
        Result.success("dropbox_session")

    override suspend fun listFiles(remotePath: String): List<CloudFile> = emptyList()
    override suspend fun uploadFile(localPath: String, remotePath: String): String = remotePath
    override suspend fun downloadFile(remotePath: String, localPath: String): String = localPath
    override suspend fun deleteFile(remotePath: String) {}
    override suspend fun createDirectory(remotePath: String): String = remotePath
    override suspend fun getQuota(): Pair<Long, Long> = 2L * 1024 * 1024 * 1024 to 0L
}

/**
 * S3 provider — uses AWS S3 SDK.
 */
class S3Provider(
    private val accessKey: String,
    private val secretKey: String,
    private val region: String,
    private val bucket: String,
) : CloudProvider {
    override val type = CloudProviderType.S3
    override val displayName = "Amazon S3"

    override suspend fun authenticate(credentials: CloudCredentials): Result<String> =
        Result.success("s3_session")

    override suspend fun listFiles(remotePath: String): List<CloudFile> = emptyList()
    override suspend fun uploadFile(localPath: String, remotePath: String): String = remotePath
    override suspend fun downloadFile(remotePath: String, localPath: String): String = localPath
    override suspend fun deleteFile(remotePath: String) {}
    override suspend fun createDirectory(remotePath: String): String = remotePath
    override suspend fun getQuota(): Pair<Long, Long> = Long.MAX_VALUE to 0L
}

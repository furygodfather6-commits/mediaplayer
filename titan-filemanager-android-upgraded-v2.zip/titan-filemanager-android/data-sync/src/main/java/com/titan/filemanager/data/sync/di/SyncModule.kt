package com.titan.filemanager.data.sync.di

import com.titan.filemanager.data.sync.repository.DefaultCloudSyncRepository
import com.titan.filemanager.domain.sync.CloudSyncRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class SyncModule {

    @Binds
    @Singleton
    abstract fun bindCloudSyncRepository(impl: DefaultCloudSyncRepository): CloudSyncRepository
}

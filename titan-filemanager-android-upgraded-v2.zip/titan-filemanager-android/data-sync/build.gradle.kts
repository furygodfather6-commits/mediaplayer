// :data:sync — cloud sync (multi-provider)
plugins {
    id("titan.android.library")
    id("titan.android.hilt")
}

android {
    namespace = "com.titan.filemanager.data.sync"
}

dependencies {
    api(project(":core:common"))
    api(project(":core:model"))
    api(project(":core:database"))
    api(project(":domain"))

    implementation(libs.kotlinx.coroutines.core)
    implementation(libs.timber)
    implementation(libs.okhttp)

    // Apache Commons Net for FTP
    implementation("commons-net:commons-net:3.11.1")

    testImplementation(project(":core:testing"))
    testImplementation(libs.junit5)
    testImplementation(libs.truth)
    testImplementation(libs.robolectric)
}

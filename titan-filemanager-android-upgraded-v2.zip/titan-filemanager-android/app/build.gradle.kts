// :app — main application module
plugins {
    id("titan.android.application")
    id("titan.android.compose")
    id("titan.android.hilt")
}

android {
    namespace = "com.titan.filemanager"

    dexOptions {
        javaMaxHeapSize = "2048m"
    }

    defaultConfig {
        applicationId = "com.titan.filemanager"
        versionCode = 1
        versionName = "1.0.0"
        ndk {
            abiFilters += "arm64-v8a"
        }
    }

    buildTypes {
        release {
            // Phase 6 — enable R8 minification + resource shrinking
            isMinifyEnabled = true
            isShrinkResources = true
            // Use the optimize.txt variant which enables MORE optimizations
            // than the default proguard-android.txt
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro",
            )
        }
        debug {
            // Debug build keeps minification off for faster dev iterations
            isMinifyEnabled = false
        }
    }
}

dependencies {
    // Phase 1 — all core modules
    implementation(project(":core:common"))
    implementation(project(":core:model"))
    implementation(project(":core:designsystem"))
    implementation(project(":core:ui"))
    implementation(project(":core:navigation"))
    implementation(project(":core:database"))
    implementation(project(":core:datastore"))
    implementation(project(":core:resources"))
    // ⚠️ CRITICAL FIX: `:core:testing` must be testImplementation, NOT
    // implementation. Previously this was `implementation(...)` which
    // pulled Robolectric (and its native Windows .dll / macOS .dylib
    // binaries) into the production APK — bloating it by ~40 MB and
    // shipping test-only code to end users. Robolectric is a unit-
    // testing framework that simulates the Android environment on a
    // development machine; it has no business in a release build.
    testImplementation(project(":core:testing"))
    implementation(project(":core:permissions"))

    // Phase 1-6 — domain + data + features
    implementation(project(":domain"))
    implementation(project(":data:scan"))
    implementation(project(":data:files"))
    implementation(project(":data:metadata"))
    implementation(project(":data:cache"))
    implementation(project(":data:thumbnail"))
    implementation(project(":data:watcher"))
    implementation(project(":data:search"))
    implementation(project(":data:trash"))
    implementation(project(":data:indexer"))
    implementation(project(":data:archive"))
    implementation(project(":data:crypto"))
    implementation(project(":data:analytics"))
    implementation(project(":data:sync"))
    implementation(project(":data:ai"))
    implementation(project(":data:backup"))
    implementation(project(":data:memory"))
    implementation(project(":data:io"))
    implementation(project(":data:pipeline"))
    implementation(project(":data:intelligence"))
    implementation(project(":data:monitor"))
    implementation(project(":data:scalability"))
    implementation(project(":feature:browser"))
    implementation(project(":feature:home"))
    implementation(project(":feature:settings"))
    implementation(project(":feature:search"))
    implementation(project(":feature:viewer"))
    implementation(project(":feature:transfer"))
    implementation(project(":feature:archive"))
    implementation(project(":feature:vault"))
    implementation(project(":feature:duplicates"))
    implementation(project(":feature:analytics"))
    implementation(project(":feature:trash"))
    implementation(project(":feature:cloud"))
    implementation(project(":feature:ai"))

    // Lifecycle
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)

    // Splash screen (AndroidX Core Splashscreen for API 26+)
    implementation(libs.androidx.core.splashscreen)

    // Palette — color extraction for DynamicColorManager
    implementation(libs.androidx.palette)

    // Security — EncryptedSharedPreferences for PIN storage
    implementation(libs.androidx.security.crypto)

    // Biometric — fingerprint/face authentication
    implementation(libs.androidx.biometric)

    // Glance — Compose-based home screen widgets
    implementation(libs.androidx.glance.appwidget)
    implementation(libs.androidx.glance.material3)

    // Coroutines
    implementation(libs.kotlinx.coroutines.android)

    // WorkManager + Hilt-work (for background jobs)
    implementation(libs.androidx.work.runtime.ktx)
    implementation(libs.androidx.hilt.work)
    ksp(libs.androidx.hilt.compiler)

    // Logging
    implementation(libs.timber)

    // Coil image loading — decoders used by TitanImageLoaderFactory
    implementation(libs.coil.compose)
    implementation(libs.coil.gif)
    implementation(libs.coil.svg)

    // Debug tools
    debugImplementation(libs.leakcanary.android)

    // Testing
    testImplementation(libs.junit5)
    testImplementation(libs.truth)
    testImplementation(libs.mockk)
    testImplementation(libs.turbine)
    testImplementation(libs.kotlinx.coroutines.test)

    androidTestImplementation(libs.androidx.test.ext.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.compose.ui.test.junit4)
    debugImplementation(libs.androidx.compose.ui.test.manifest)
}

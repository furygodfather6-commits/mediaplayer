# ═════════════════════════════════════════════════════════════════
# TitanFileManager ProGuard / R8 Rules
# ═════════════════════════════════════════════════════════════════
#
# This file contains ProGuard/R8 rules for the TitanFileManager release
# build. Rules are organized by library / feature so they're easy to
# maintain as dependencies change.
#
# ### Build configuration
# In app/build.gradle.kts:
# ```kotlin
# buildTypes {
#     release {
#         isMinifyEnabled = true
#         isShrinkResources = true
#         proguardFiles(
#             getDefaultProguardFile("proguard-android-optimize.txt"),
#             "proguard-rules.pro",
#         )
#     }
# }
# ```
#
# ### Testing
# After enabling minification, always test the release build:
# ```bash
# ./gradlew assembleRelease
# # Install on a device and verify all features work
# adb install app-release.apk
# ```
#
# ### Common issues that this file fixes
#  - Reflection-based libraries (Hilt, Room, Coil) need keep rules
#  - JNI native code needs class name preservation
#  - Serialized data classes need @SerializedName keep
#  - Compose runtime needs annotated class preservation

# ═════════════════════════════════════════════════════════════════
# 1. TITANFILEMANAGER APP CODE
# ═════════════════════════════════════════════════════════════════

# Keep all classes annotated with @HiltAndroidApp, @AndroidEntryPoint,
# @HiltViewModel, @Module, @InstallIn, @Inject, @Provides, @Binds.
# Hilt uses reflection to inject these at runtime.
-keep class com.titan.filemanager.TitanApplication { *; }
-keep class com.titan.filemanager.MainActivity { *; }
-keep @dagger.hilt.android.HiltAndroidApp class * { *; }
-keep @dagger.hilt.android.AndroidEntryPoint class * { *; }
-keep @dagger.hilt.android.lifecycle.HiltViewModel class * { *; }
-keep @dagger.Module class * { *; }
-keep @dagger.hilt.InstallIn class * { *; }
-keepclassmembers class * {
    @javax.inject.Inject *;
    @dagger.Provides *;
    @dagger.Binds *;
}

# Keep all data classes used in DataStore JSON serialization
-keep @kotlinx.serialization.Serializable class * { *; }
-keepclassmembers class * {
    @kotlinx.serialization.SerialName <fields>;
}

# Keep all Room entities, DAOs, and database classes
-keep class * extends androidx.room.RoomDatabase { *; }
-keep @androidx.room.Entity class * { *; }
-keep @androidx.room.Dao interface * { *; }
-keepclassmembers class * {
    @androidx.room.PrimaryKey <fields>;
    @androidx.room.ColumnInfo <fields>;
}

# Keep enums used in ViewModels (Hilt can't reflect on obfuscated enums)
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# ═════════════════════════════════════════════════════════════════
# 2. JETPACK COMPOSE
# ═════════════════════════════════════════════════════════════════

# Compose runtime uses reflection to call Composable functions
-keep class androidx.compose.runtime.** { *; }
-keep class androidx.compose.ui.** { *; }
-keep class androidx.compose.material3.** { *; }
-keep class androidx.compose.foundation.** { *; }
-keep @androidx.compose.runtime.Composable class * { *; }
-keepclassmembers class * {
    @androidx.compose.runtime.Composable <methods>;
}

# Compose Compiler metadata — required for recomposition to work
-keep class androidx.compose.runtime.Composable { *; }
-keep class androidx.compose.runtime.ComposableLambda { *; }
-keep class androidx.compose.runtime.ComposableSingletons { *; }

# Shared transition API (Compose 1.7+)
-keep class androidx.compose.animation.SharedTransitionLayout { *; }
-keep class androidx.compose.animation.SharedTransitionScope { *; }

# ═════════════════════════════════════════════════════════════════
# 3. COIL (Image Loading)
# ═════════════════════════════════════════════════════════════════

# Coil uses reflection for fetcher/decoder registration
-keep class coil.** { *; }
-keep class com.titan.filemanager.imaging.** { *; }
-keepclassmembers class * {
    @coil.annotation.ExperimentalCoilApi *;
}

# Custom fetchers — must be preserved for Coil's component registry
-keep class com.titan.filemanager.imaging.VideoFrameFetcher { *; }
-keep class com.titan.filemanager.imaging.VideoFrameFetcher$Factory { *; }
-keep class com.titan.filemanager.imaging.PdfPageFetcher { *; }
-keep class com.titan.filemanager.imaging.PdfPageFetcher$Factory { *; }
-keep class com.titan.filemanager.imaging.TitanFileKeyer { *; }

# ═════════════════════════════════════════════════════════════════
# 4. HILT / DAGGER (DI)
# ═════════════════════════════════════════════════════════════════

# Hilt generates classes at compile time, but R8 still needs to keep them
-keep class dagger.hilt.** { *; }
-keep class dagger.internal.** { *; }
-keep class * extends dagger.hilt.android.internal.lifecycle.HiltViewModelFactory$ViewModelFactoriesEntryPoint { *; }

# javax.inject classes — used by Hilt
-keep class javax.inject.** { *; }

# ═════════════════════════════════════════════════════════════════
# 5. KOTLINX COROUTINES + SERIALIZATION
# ═════════════════════════════════════════════════════════════════

# Coroutines dispatchers
-keep class kotlinx.coroutines.** { *; }

# Serialization — @Serializable classes need their serializers preserved
-keep @kotlinx.serialization.Serializable class * {
    * Companion;
    *Serializer;
}
-keepclassmembers class **$$serializer { *; }
-keepclasseswithmembers class * {
    kotlinx.serialization.KSerializer serializer(...);
}

# ═════════════════════════════════════════════════════════════════
# 6. KOTLINX DATETIME
# ═════════════════════════════════════════════════════════════════

-keep class kotlinx.datetime.** { *; }

# ═════════════════════════════════════════════════════════════════
# 7. NAVIGATION COMPOSE
# ═════════════════════════════════════════════════════════════════

# Navigation routes are strings — keep NavRoutes object
-keep class com.titan.filemanager.core.navigation.NavRoutes { *; }
-keep class androidx.navigation.** { *; }

# ═════════════════════════════════════════════════════════════════
# 8. TIMBER (Logging)
# ═════════════════════════════════════════════════════════════════

-keep class timber.log.** { *; }
-keep @ timber.log.Timber.Tree class * { *; }

# ═════════════════════════════════════════════════════════════════
# 9. NATIVE LIBRARIES (JNI)
# ═════════════════════════════════════════════════════════════════

# Native code references Java classes by name — keep the JNI bridge classes
-keep class com.titan.filemanager.native_scan.** { *; }
-keep class com.titan.filemanager.native_crypto.** { *; }
-keep class com.titan.filemanager.native_archive.** { *; }
-keep class com.titan.filemanager.native_media.** { *; }

# JNI methods
-keepclasseswithmembernames class * {
    native <methods>;
}

# ═════════════════════════════════════════════════════════════════
# 10. SDK MODULE
# ═════════════════════════════════════════════════════════════════

# Public SDK API — must be preserved for external consumers
-keep class com.titan.filemanager.sdk.** { *; }
-keep @kotlinx.serialization.Serializable class com.titan.filemanager.sdk.** { *; }

# ═════════════════════════════════════════════════════════════════
# 11. RETROFIT / OKHTTP (Cloud Sync)
# ═════════════════════════════════════════════════════════════════

# Retrofit uses reflection for interface proxies
-keep,allowobfuscation,allowshrinking interface retrofit2.Call
-keep,allowobfuscation,allowshrinking class retrofit2.Response
-keep,allowobfuscation,allowshrinking class kotlin.coroutines.Continuation

# OkHttp platform-specific classes
-dontwarn okhttp3.internal.platform.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**

# Retrofit response classes — must match API JSON exactly
-keep class retrofit2.** { *; }
-keepclasseswithmembers class * {
    @retrofit2.http.* <methods>;
}

# ═════════════════════════════════════════════════════════════════
# 12. WORKMANAGER
# ═════════════════════════════════════════════════════════════════

# Worker classes are instantiated by reflection
-keep class * extends androidx.work.Worker { *; }
-keep class * extends androidx.work.CoroutineWorker { *; }
-keep class * extends androidx.work.ListenableWorker { *; }
-keepclassmembers class * {
    public <init>(android.content.Context, androidx.work.WorkerParameters);
}

# ═════════════════════════════════════════════════════════════════
# 13. PALETTE LIBRARY
# ═════════════════════════════════════════════════════════════════

-keep class androidx.palette.** { *; }
-keep class androidx.core.graphics.** { *; }

# ═════════════════════════════════════════════════════════════════
# 14. SPLASH SCREEN API
# ═════════════════════════════════════════════════════════════════

-keep class androidx.core.splashscreen.** { *; }

# ═════════════════════════════════════════════════════════════════
# 15. WEAR COMPOSE
# ═════════════════════════════════════════════════════════════════

-keep class androidx.wear.compose.** { *; }

# ═════════════════════════════════════════════════════════════════
# 16. GLANCE (Widgets)
# ═════════════════════════════════════════════════════════════════

-keep class androidx.glance.** { *; }

# ═════════════════════════════════════════════════════════════════
# 17. GENERAL OPTIMIZATIONS
# ═════════════════════════════════════════════════════════════════

# Remove logging calls in release builds
-assumenosideeffects class timber.log.Timber {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
}

# Keep line numbers for stack traces (very useful for crash reports)
-renamesourcefileattribute SourceFile
-keepattributes SourceFile,LineNumberTable

# Keep annotations — many libraries use them for runtime reflection
-keepattributes RuntimeVisibleAnnotations,RuntimeInvisibleAnnotations
-keepattributes RuntimeVisibleParameterAnnotations,RuntimeInvisibleParameterAnnotations
-keepattributes AnnotationDefault
-keepattributes Signature
-keepattributes Exceptions
-keepattributes EnclosingMethod
-keepattributes InnerClasses

# Kotlin metadata — needed for reflection-based libraries
-keep class kotlin.Metadata { *; }
-keepattributes KotlinMetadata

# ═════════════════════════════════════════════════════════════════
# 18. DEBUG-ONLY CLASSES — STRIP FROM RELEASE
# ═════════════════════════════════════════════════════════════════

# LeakCanary — debug only, strip from release
-assume	no side effects class leakcanary.** { *; }

# Chucker — debug only
-assume no side effects class com.chuckerteam.chucker.** { *; }

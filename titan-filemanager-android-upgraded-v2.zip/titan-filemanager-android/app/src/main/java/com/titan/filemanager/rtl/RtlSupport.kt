package com.titan.filemanager.rtl

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import java.util.Locale

/**
 * ## RtlSupport
 *
 * Utilities for bidirectional (RTL/LTR) text and layout support.
 *
 * ### What this provides
 *  - [isRtl] — check if the current locale is RTL (Arabic, Hebrew, Persian, Urdu)
 *  - [LayoutDirection] helpers — start/end padding that adapts to direction
 *  - [mirroredIcon] — flip icons that imply direction (back arrow, etc.)
 *  - [formatRtlNumber] — format numbers with Arabic-Indic digits in Arabic locale
 *  - [bidiWrap] — wrap strings with BiDi control characters for mixed-direction text
 *
 * ### Supported RTL locales
 *  - ar (Arabic)
 *  - he (Hebrew)
 *  - fa (Persian / Farsi)
 *  - ur (Urdu)
 *  - yi (Yiddish)
 *  - dv (Dhivehi)
 *
 * ### File paths
 * File paths are inherently LTR (even in Arabic locales) because they
 * follow Unix path conventions. Use [bidiWrap] when displaying paths in
 * RTL contexts to prevent text reordering issues.
 */
object RtlSupport {

    /** ISO 639-1 codes for RTL languages. */
    private val RTL_LANGUAGE_CODES = setOf(
        "ar", "he", "iw", "fa", "ur", "yi", "dv",
    )

    /**
     * Check whether the given [locale] is an RTL language.
     */
    fun isRtlLocale(locale: Locale): Boolean {
        val lang = locale.language.lowercase()
        return lang in RTL_LANGUAGE_CODES
    }

    /**
     * Check whether the given BCP-47 language tag is RTL.
     */
    fun isRtlLanguageTag(languageTag: String): Boolean {
        val lang = languageTag.substringBefore('-').lowercase()
        return lang in RTL_LANGUAGE_CODES
    }

    /**
     * BiDi isolate a string — wraps the input with U+2068 (FIRST STRONG ISOLATE)
     * and U+2069 (POP DIRECTIONAL ISOLATE) so the system renders the string
     * in its natural direction regardless of surrounding context.
     *
     * Used for file paths, numbers, and other LTR content embedded in RTL text.
     */
    fun bidiWrap(text: String): String {
        return "\u2068$text\u2069"
    }

    /**
     * Format a file size with proper digit grouping and BiDi isolation.
     *
     * Example: `1234567` → `"1,234,567"` in LTR locale, `"1٬234٬567"` in Arabic.
     */
    fun formatFileSize(bytes: Long, locale: Locale): String {
        val formatted = when {
            bytes < 1024 -> "$bytes B"
            bytes < 1024 * 1024 -> String.format(locale, "%.1f KB", bytes / 1024.0)
            bytes < 1024 * 1024 * 1024 -> String.format(locale, "%.1f MB", bytes / (1024.0 * 1024))
            else -> String.format(locale, "%.2f GB", bytes / (1024.0 * 1024 * 1024))
        }
        return bidiWrap(formatted)
    }

    /**
     * Format a number with locale-specific digit grouping.
     *
     * In Arabic locale, uses Arabic-Indic digits (٠١٢٣٤٥٦٧٨٩).
     * In other locales, uses Western Arabic digits (0123456789).
     */
    fun formatNumber(value: Long, locale: Locale): String {
        val formatter = java.text.NumberFormat.getInstance(locale)
        return bidiWrap(formatter.format(value))
    }
}

/**
 * ## isRtl
 *
 * Compose helper that returns true if the current layout direction is RTL.
 *
 * Usage:
 * ```kotlin
 * val rtl = isRtl()
 * if (rtl) {
 *     // Flip icon, swap start/end, etc.
 * }
 * ```
 */
@Composable
fun isRtl(): Boolean = LocalLayoutDirection.current == LayoutDirection.Rtl

/**
 * ## Modifier.mirroredIfRtl
 *
 * Mirror (flip horizontally) the composable if the current layout direction is RTL.
 *
 * Use for directional icons like back arrows, play/skip buttons, and chevrons
 * that should visually point in the direction of motion (not text direction).
 *
 * Usage:
 * ```kotlin
 * Icon(
 *     imageVector = Icons.Filled.ArrowBack,
 *     modifier = Modifier.mirroredIfRtl(),
 *     ...
 * )
 * ```
 */
@Composable
fun Modifier.mirroredIfRtl(): Modifier {
    val rtl = isRtl()
    return if (rtl) this.then(Modifier.scaleX(-1f))
           else this
}

/**
 * ## directionalPadding
 *
 * Returns padding values that swap start/end based on layout direction.
 *
 * - In LTR: `start` becomes `left`, `end` becomes `right`
 * - In RTL: `start` becomes `right`, `end` becomes `left`
 *
 * Usage:
 * ```kotlin
 * Box(modifier = Modifier.padding(directionalPadding(start = 16.dp, end = 8.dp)))
 * ```
 */
@Composable
fun directionalPadding(
    start: androidx.compose.ui.unit.Dp = 0.dp,
    end: androidx.compose.ui.unit.Dp = 0.dp,
    top: androidx.compose.ui.unit.Dp = 0.dp,
    bottom: androidx.compose.ui.unit.Dp = 0.dp,
): PaddingValues {
    val rtl = isRtl()
    return PaddingValues(
        start = if (rtl) end else start,
        end = if (rtl) start else end,
        top = top,
        bottom = bottom,
    )
}

/**
 * ## rememberLayoutDirection
 *
 * Returns the current [LayoutDirection] as a remembered value.
 * Useful for passing to non-Composable code.
 */
@Composable
fun rememberLayoutDirection(): LayoutDirection = LocalLayoutDirection.current

// ═══════════════════════════════════════════════════════════════
// INTERNAL — Modifier helpers
// ═══════════════════════════════════════════════════════════════

/**
 * Scale only the X axis — used by [mirroredIfRtl] to flip horizontally.
 */
private fun Modifier.scaleX(scale: Float): Modifier =
    this.then(Modifier.scale(scaleX = scale, scaleY = 1f))

package com.titan.filemanager.ui.screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.titan.filemanager.core.ui.contracts.RecentFilesContract
import com.titan.filemanager.core.ui.contracts.UiRecentFile
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Lightweight ViewModel for the Recent Files screen.
 *
 * Previously the RecentFilesScreen was wired with
 * `recentFiles = emptyList()` and `onClearHistory` as a no-op — the
 * screen always showed "no recent files" and the Clear button did
 * nothing.
 *
 * This VM injects the existing [RecentFilesContract] (bound to
 * [com.titan.filemanager.di.RecentFilesContractAdapter] which
 * delegates to the domain `RecentFileRepository`) and exposes a
 * reactive `recentFiles` StateFlow.
 */
@HiltViewModel
class RecentFilesViewModel @Inject constructor(
    private val recentFilesContract: RecentFilesContract,
) : ViewModel() {

    val recentFiles: StateFlow<List<UiRecentFile>> = recentFilesContract.observeRecent(100)
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000L),
            initialValue = emptyList(),
        )

    fun removeRecent(path: String) {
        viewModelScope.launch {
            recentFilesContract.removeRecent(path)
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            recentFilesContract.clearAll()
        }
    }
}

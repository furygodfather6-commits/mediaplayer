package com.titan.filemanager.error

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.titan.filemanager.core.designsystem.modifier.clipToCircle
import com.titan.filemanager.core.designsystem.modifier.clipToRounded
import com.titan.filemanager.core.designsystem.tokens.ElevationTokens
import com.titan.filemanager.core.designsystem.tokens.ShapeTokens
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.inject.Inject

/**
 * ## ErrorViewModel
 *
 * Exposes crash reports from [CrashReporter] to the UI. Used by the
 * in-app crash review screen (accessible from Settings → About → View crashes).
 */
@HiltViewModel
class ErrorViewModel @Inject constructor(
    private val crashReporter: CrashReporter,
) : ViewModel() {

    private val _reports = MutableStateFlow<List<CrashReport>>(emptyList())
    val reports: StateFlow<List<CrashReport>> = _reports.asStateFlow()

    private val _selectedReport = MutableStateFlow<CrashReport?>(null)
    val selectedReport: StateFlow<CrashReport?> = _selectedReport.asStateFlow()

    init {
        loadReports()
    }

    fun loadReports() {
        viewModelScope.launch {
            _reports.value = crashReporter.getPendingReports()
        }
    }

    fun selectReport(report: CrashReport?) {
        _selectedReport.value = report
    }

    fun dismissReport(report: CrashReport) {
        viewModelScope.launch {
            crashReporter.markReviewed(report.timestampMs)
            loadReports()
            _selectedReport.value = null
        }
    }

    fun dismissAll() {
        viewModelScope.launch {
            _reports.value.forEach { crashReporter.markReviewed(it.timestampMs) }
            _reports.value = emptyList()
        }
    }
}

/**
 * ## ErrorReportDialog
 *
 * Modal dialog shown when a [CrashReport] is emitted on [GlobalErrorHandler.errorBus].
 * The dialog shows:
 *  - Severity badge (FATAL / NON-FATAL)
 *  - Exception class + message
 *  - Stack trace (collapsible)
 *  - Device + memory info
 *  - Action buttons: Send Report / Dismiss / View Details
 *
 * ### Auto-display
 * In [TitanApp], observe [GlobalErrorHandler.errorBus] and show this dialog:
 * ```kotlin
 * val report by globalErrorHandler.errorBus.collectAsState(initial = null)
 * report?.let { ErrorReportDialog(it, onDismiss = { ... }) }
 * ```
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ErrorReportDialog(
    report: CrashReport,
    onDismiss: () -> Unit,
    onSendReport: (CrashReport) -> Unit = {},
    onViewDetails: (CrashReport) -> Unit = {},
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clipToCircle()
                        .background(
                            if (report.isFatal) MaterialTheme.colorScheme.errorContainer
                            else MaterialTheme.colorScheme.tertiaryContainer,
                        ),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = if (report.isFatal) Icons.Filled.Error else Icons.Filled.Warning,
                        contentDescription = null,
                        modifier = Modifier.size(24.dp),
                        tint = if (report.isFatal) MaterialTheme.colorScheme.error
                               else MaterialTheme.colorScheme.tertiary,
                    )
                }
                Spacer(Modifier.width(SpacingTokens.Md))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (report.isFatal) "App crashed" else "Something went wrong",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(
                        text = report.summary(),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(SpacingTokens.Sm),
            ) {
                // Exception details
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                    ),
                    shape = ShapeTokens.Medium,
                ) {
                    Column(modifier = Modifier.padding(SpacingTokens.Md)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.BugReport, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(SpacingTokens.Xs))
                            Text("Exception", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                        }
                        Spacer(Modifier.height(SpacingTokens.Xs))
                        Text(
                            text = report.exceptionClass.substringAfterLast('.'),
                            style = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.error,
                        )
                        if (report.exceptionMessage.isNotEmpty()) {
                            Text(
                                text = report.exceptionMessage,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }

                // Device + memory snapshot
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                    ),
                    shape = ShapeTokens.Medium,
                ) {
                    Column(modifier = Modifier.padding(SpacingTokens.Md)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Memory, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(SpacingTokens.Xs))
                            Text("Environment", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                        }
                        Spacer(Modifier.height(SpacingTokens.Xs))
                        InfoRow("Device", "${report.deviceManufacturer} ${report.deviceModel}")
                        InfoRow("Android", "${report.androidVersion} (SDK ${report.sdkLevel})")
                        InfoRow("App", "${report.appVersionName} (${report.appVersionCode})")
                        InfoRow("Thread", report.threadName)
                    }
                }
            }
        },
        confirmButton = {
            FilledTonalButton(
                onClick = { onSendReport(report); onDismiss() },
            ) {
                Icon(Icons.Filled.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(SpacingTokens.Xs))
                Text("Send Report")
            }
        },
        dismissButton = {
            Row {
                OutlinedButton(onClick = { onViewDetails(report) }) {
                    Text("Details")
                }
                Spacer(Modifier.width(SpacingTokens.Xs))
                TextButton(onClick = onDismiss) {
                    Text("Dismiss")
                }
            }
        },
    )
}

/**
 * ## CrashReviewScreen
 *
 * Full screen showing all pending crash reports. Accessible from
 * Settings → About → View crash logs.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CrashReviewScreen(
    onBack: () -> Unit,
    viewModel: ErrorViewModel = hiltViewModel(),
) {
    val reports by viewModel.reports.collectAsState()
    val selectedReport by viewModel.selectedReport.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Crash Reports", fontWeight = FontWeight.SemiBold)
                        Text(
                            text = "${reports.size} pending",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                actions = {
                    if (reports.isNotEmpty()) {
                        IconButton(onClick = { viewModel.dismissAll() }) {
                            Icon(Icons.Filled.Delete, "Dismiss all")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                ),
            )
        },
    ) { padding ->
        if (reports.isEmpty()) {
            // Empty state
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center,
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(SpacingTokens.Xxl),
                ) {
                    Icon(
                        Icons.Filled.Info,
                        contentDescription = null,
                        modifier = Modifier.size(72.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                    )
                    Spacer(Modifier.height(SpacingTokens.Lg))
                    Text(
                        "No crash reports",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Text(
                        "Crash reports will appear here if the app encounters issues.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentPadding = PaddingValues(SpacingTokens.Md),
                verticalArrangement = Arrangement.spacedBy(SpacingTokens.Sm),
            ) {
                items(reports, key = { it.timestampMs }) { report ->
                    CrashReportCard(
                        report = report,
                        onClick = { viewModel.selectReport(report) },
                        onDismiss = { viewModel.dismissReport(report) },
                    )
                }
            }
        }
    }

    // Detail dialog
    selectedReport?.let { report ->
        CrashReportDetailDialog(
            report = report,
            onDismiss = { viewModel.selectReport(null) },
        )
    }
}

@Composable
private fun CrashReportCard(
    report: CrashReport,
    onClick: () -> Unit,
    onDismiss: () -> Unit,
) {
    val dateFormat = remember { SimpleDateFormat("MMM dd, yyyy 'at' HH:mm:ss", Locale.getDefault()) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(ShapeTokens.Medium),
        onClick = onClick,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
        ),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(SpacingTokens.Md),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            // Severity icon
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clipToCircle()
                    .background(
                        if (report.isFatal) MaterialTheme.colorScheme.errorContainer
                        else MaterialTheme.colorScheme.tertiaryContainer,
                    ),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = if (report.isFatal) Icons.Filled.Error else Icons.Filled.Warning,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp),
                    tint = if (report.isFatal) MaterialTheme.colorScheme.error
                           else MaterialTheme.colorScheme.tertiary,
                )
            }

            Spacer(Modifier.width(SpacingTokens.Md))

            // Info
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = report.exceptionClass.substringAfterLast('.'),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(top = 2.dp),
                ) {
                    Icon(
                        Icons.Filled.Schedule,
                        contentDescription = null,
                        modifier = Modifier.size(12.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.width(SpacingTokens.Xxs))
                    Text(
                        text = dateFormat.format(Date(report.timestampMs)),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            // Dismiss button
            IconButton(onClick = onDismiss) {
                Icon(Icons.Filled.Close, "Dismiss", modifier = Modifier.size(20.dp))
            }
        }
    }
}

@Composable
private fun CrashReportDetailDialog(
    report: CrashReport,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Crash Details", fontWeight = FontWeight.SemiBold) },
        text = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(400.dp)
                    .verticalScroll(rememberScrollState()),
            ) {
                Text(
                    text = report.toPlainText(),
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontFamily = FontFamily.Monospace,
                        lineHeight = 16.sp,
                    ),
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        },
    )
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = "$label:",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.width(80.dp),
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

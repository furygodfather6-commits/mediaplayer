package com.titan.filemanager.ui.screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.domain.scan.DirectoryScanRepository
import com.titan.filemanager.core.model.file.SortDescriptor
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject

/**
 * ViewModel for the Hidden Files screen.
 *
 * Previously the HiddenFilesScreen was wired with
 * `hiddenFiles = emptyList()` and `onUnhide`/`onUnhideAll` as no-ops.
 *
 * This VM scans `/sdcard` for files/folders starting with `.` (Unix
 * hidden files) and exposes them reactively. "Unhide" renames the
 * file to remove the leading dot.
 */
@HiltViewModel
class HiddenFilesViewModel @Inject constructor(
    private val scanRepository: DirectoryScanRepository,
) : ViewModel() {

    private val _hiddenFiles = MutableStateFlow<List<HiddenFileInfo>>(emptyList())
    val hiddenFiles: StateFlow<List<HiddenFileInfo>> = _hiddenFiles.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    init {
        scan()
    }

    fun scan() {
        viewModelScope.launch {
            val root = android.os.Environment.getExternalStorageDirectory() ?: return@launch
            val results = mutableListOf<HiddenFileInfo>()
            withContext(Dispatchers.IO) {
                root.walkTopDown()
                    .take(5000)
                    .filter { it.name.startsWith(".") && it.name != "." && it.name != ".." }
                    .forEach { file ->
                        results.add(
                            HiddenFileInfo(
                                name = file.name,
                                path = file.absolutePath,
                                size = if (file.isDirectory) 0L else file.length(),
                                isDirectory = file.isDirectory,
                            ),
                        )
                    }
            }
            _hiddenFiles.value = results
        }
    }

    /** Unhide a file by renaming it (remove leading dot). */
    fun unhide(path: String) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                val file = File(path)
                val parent = file.parentFile
                val newName = file.name.removePrefix(".")
                if (parent != null) {
                    val dest = File(parent, newName)
                    if (file.renameTo(dest)) {
                        _hiddenFiles.value = _hiddenFiles.value.filterNot { it.path == path }
                        _message.value = "Unhidden: $newName"
                    } else {
                        _message.value = "Failed to unhide: ${file.name}"
                    }
                }
            }
        }
    }

    /** Unhide all currently-listed hidden files. */
    fun unhideAll() {
        val current = _hiddenFiles.value.toList()
        current.forEach { unhide(it.path) }
    }

    fun clearMessage() {
        _message.value = null
    }
}

data class HiddenFileInfo(
    val name: String,
    val path: String,
    val size: Long,
    val isDirectory: Boolean,
)

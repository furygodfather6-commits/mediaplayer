package com.titan.filemanager.ui.screens

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.titan.filemanager.core.ui.contracts.DuplicatesContract
import com.titan.filemanager.core.ui.contracts.UiDuplicateFile
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * ViewModel for the Duplicate Detail screen.
 *
 * Previously the DuplicateDetailScreen was wired with
 * `files = emptyList()` and `onDelete` / `onKeep` as no-ops — the
 * screen always showed "no duplicates" and the buttons did nothing.
 *
 * This VM injects the existing [DuplicatesContract] (bound to
 * [com.titan.filemanager.di.DuplicatesContractAdapter]) and loads the
 * duplicate group by ID. Delete/Keep actions delegate to the contract.
 */
@HiltViewModel
class DuplicateDetailViewModel @Inject constructor(
    private val duplicatesContract: DuplicatesContract,
    savedStateHandle: SavedStateHandle,
) : ViewModel() {

    private val groupId: String = savedStateHandle.get<String>("groupId") ?: ""

    private val _files = MutableStateFlow<List<UiDuplicateFile>>(emptyList())
    val files: StateFlow<List<UiDuplicateFile>> = _files.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    init {
        loadGroup()
    }

    private fun loadGroup() {
        viewModelScope.launch {
            try {
                _files.value = duplicatesContract.getDuplicateGroup(groupId)
            } catch (e: Exception) {
                _message.value = "Failed to load: ${e.message}"
            }
        }
    }

    fun deleteFile(path: String, expectedHash: String) {
        viewModelScope.launch {
            val success = duplicatesContract.deleteFile(path, expectedHash)
            _message.value = if (success) "Deleted" else "Delete failed"
            if (success) {
                // Remove from the list reactively
                _files.value = _files.value.filterNot { it.path == path }
            }
        }
    }

    fun markAsKept(path: String) {
        viewModelScope.launch {
            duplicatesContract.markAsKept(path)
            _message.value = "Kept"
            // Remove from the list — kept files are no longer "duplicates to review"
            _files.value = _files.value.filterNot { it.path == path }
        }
    }

    fun clearMessage() {
        _message.value = null
    }
}

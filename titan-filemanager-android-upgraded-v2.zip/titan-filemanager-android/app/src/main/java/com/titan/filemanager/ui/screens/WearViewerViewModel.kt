package com.titan.filemanager.ui.screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.core.ui.contracts.RecentFilesContract
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

/**
 * ViewModel for the Wear Viewer screen.
 *
 * Previously the WearViewerScreen was wired with `files = emptyList()`
 * — the screen always showed "no files" on the Wear OS companion.
 *
 * This VM injects [RecentFilesContract] and exposes recent files as
 * `FileItem`s (mapping from `UiRecentFile`). The Wear OS companion
 * shows these as a simple list the user can scroll through.
 */
@HiltViewModel
class WearViewerViewModel @Inject constructor(
    recentFilesContract: RecentFilesContract,
) : ViewModel() {

    val files: StateFlow<List<FileItem>> = recentFilesContract.observeRecent(20)
        .map { recent ->
            recent.map {
                FileItem(
                    path = it.path,
                    name = it.name,
                    stableId = it.path.hashCode().toLong(),
                    size = it.size,
                    modifiedAt = it.modifiedAt,
                    isDirectory = it.isDirectory,
                )
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000L),
            initialValue = emptyList(),
        )
}

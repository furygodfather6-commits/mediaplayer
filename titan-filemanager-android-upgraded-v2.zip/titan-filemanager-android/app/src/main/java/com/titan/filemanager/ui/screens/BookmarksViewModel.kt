package com.titan.filemanager.ui.screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.titan.filemanager.core.ui.contracts.BookmarksContract
import com.titan.filemanager.core.ui.contracts.UiBookmark
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Lightweight ViewModel for the Bookmarks screen.
 *
 * Previously the BookmarksScreen was wired with `bookmarks = emptyList()`
 * and all action callbacks as no-ops — the screen always showed "no
 * bookmarks" and tapping add/remove/rename did nothing.
 *
 * This VM injects the existing [BookmarksContract] (bound to
 * [com.titan.filemanager.di.BookmarksContractAdapter] which delegates
 * to the domain `BookmarkRepository`) and exposes a reactive
 * `bookmarks` StateFlow. Add/remove/rename actions delegate to the
 * contract.
 */
@HiltViewModel
class BookmarksViewModel @Inject constructor(
    private val bookmarksContract: BookmarksContract,
) : ViewModel() {

    val bookmarks: StateFlow<List<UiBookmark>> = bookmarksContract.observeBookmarks()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000L),
            initialValue = emptyList(),
        )

    fun addBookmark(path: String) {
        val name = path.trimEnd('/').substringAfterLast('/').ifEmpty { "Bookmark" }
        viewModelScope.launch {
            bookmarksContract.addBookmark(path, name)
        }
    }

    fun removeBookmark(id: Long) {
        viewModelScope.launch {
            bookmarksContract.removeBookmark(id)
        }
    }

    fun renameBookmark(id: Long, newName: String) {
        viewModelScope.launch {
            bookmarksContract.renameBookmark(id, newName)
        }
    }
}

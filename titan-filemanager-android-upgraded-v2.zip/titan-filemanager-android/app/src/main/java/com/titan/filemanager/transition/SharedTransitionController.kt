package com.titan.filemanager.transition

import androidx.compose.animation.AnimatedVisibilityScope
import androidx.compose.animation.BoundsTransform
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.ExperimentalSharedTransitionApi
import androidx.compose.animation.SharedTransitionLayout
import androidx.compose.animation.SharedTransitionScope
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Rect

/**
 * ## SharedTransitionController
 *
 * Wrapper around Compose's [SharedTransitionScope] + [AnimatedVisibilityScope]
 * that provides the API for shared element transitions between list and detail
 * screens.
 *
 * ### How shared element transitions work
 * When navigating from a list (e.g., BrowserScreen) to a detail (e.g., ViewerScreen):
 *  1. Both screens are wrapped in a single [SharedTransitionLayout]
 *  2. List items use [Modifier.sharedElement] with a unique key (e.g., file path)
 *  3. Detail screen uses the same key on its image
 *  4. During the transition, the system animates the list element's bounds
 *     into the detail element's bounds
 *
 * ### Setup
 * In [TitanApp], wrap the NavHost in a [SharedTransitionLayout]:
 * ```kotlin
 * SharedTransitionLayout {
 *     TitanNavHost(navController, ...)
 * }
 * ```
 *
 * Then each screen's composable receives the [SharedTransitionScope] and
 * [AnimatedVisibilityScope] via CompositionLocals or parameters.
 *
 * ### Key naming convention
 * Keys follow the format `"<type>:<id>"`:
 *  - `"image:/sdcard/photo.jpg"` — image thumbnail
 *  - `"title:/sdcard/photo.jpg"` — title text
 *  - `"icon:/sdcard/folder"` — file-type icon
 *
 * ### Performance
 * Shared element transitions are GPU-accelerated and run at 60+ FPS on
 * most devices. The transition duration is 300ms by default.
 */
@OptIn(ExperimentalSharedTransitionApi::class)
object SharedTransitionController {

    /** Default transition duration (ms). */
    const val DEFAULT_DURATION_MS = 300

    /** Easing curve — Material 3 emphasized decelerate. */
    val EmphasizedDecelerate = CubicBezierEasing(0.05f, 0.7f, 0.1f, 1.0f)

    /** Easing curve — Material 3 emphasized accelerate. */
    val EmphasizedAccelerate = CubicBezierEasing(0.3f, 0.0f, 0.8f, 0.15f)

    /**
     * Bounds transform for shared elements — uses spring physics for a
     * natural, bouncy feel.
     *
     * Override the default [BoundsTransform] to use Material 3 motion easing
     * instead of Coil's default spring.
     */
    val MaterialBoundsTransform: BoundsTransform = BoundsTransform { _, _ ->
        spring(
            dampingRatio = 0.8f,
            stiffness = 350f,
        )
    }
}

/**
 * ## Modifier.sharedThumbnail
 *
 * Apply this modifier to an image/thumbnail in a list to make it a shared
 * element with the detail screen.
 *
 * Usage:
 * ```kotlin
 * AsyncImage(
 *     modifier = Modifier
 *         .size(96.dp)
 *         .sharedThumbnail(
 *             sharedTransitionScope = sharedScope,
 *             animatedVisibilityScope = animatedScope,
 *             filePath = file.path,
 *         ),
 *     ...
 * )
 * ```
 *
 * @param sharedTransitionScope the scope from [SharedTransitionLayout].
 * @param animatedVisibilityScope the scope from the current composable's AnimatedContent.
 * @param filePath the file path — used as the unique key for the shared element.
 * @param keyPrefix prefix to disambiguate (e.g., "image" vs "title").
 */
@OptIn(ExperimentalSharedTransitionApi::class)
@Composable
fun Modifier.sharedThumbnail(
    sharedTransitionScope: SharedTransitionScope,
    animatedVisibilityScope: AnimatedVisibilityScope,
    filePath: String,
    keyPrefix: String = "image",
): Modifier = with(sharedTransitionScope) {
    this@sharedThumbnail.sharedElement(
        rememberSharedContentState(key = "$keyPrefix:$filePath"),
        animatedVisibilityScope = animatedVisibilityScope,
        boundsTransform = SharedTransitionController.MaterialBoundsTransform,
    )
}

/**
 * ## Modifier.sharedTitle
 *
 * Apply this modifier to a title Text in a list to make it a shared element
 * with the detail screen's title.
 */
@OptIn(ExperimentalSharedTransitionApi::class)
@Composable
fun Modifier.sharedTitle(
    sharedTransitionScope: SharedTransitionScope,
    animatedVisibilityScope: AnimatedVisibilityScope,
    filePath: String,
): Modifier = with(sharedTransitionScope) {
    this@sharedTitle.sharedElement(
        rememberSharedContentState(key = "title:$filePath"),
        animatedVisibilityScope = animatedVisibilityScope,
        boundsTransform = SharedTransitionController.MaterialBoundsTransform,
    )
}

/**
 * ## TitanNavTransitions
 *
 * Navigation transitions for TitanNavHost — combines slide + fade + scale
 * for a polished Material 3 motion.
 *
 * ### Forward navigation (list → detail)
 *  - Enter: slide-in from right (50%) + fade-in + scale-in (0.92 → 1.0)
 *  - Exit: slide-out to left (25%) + fade-out (0.5)
 *
 * ### Backward navigation (detail → list)
 *  - Pop enter: slide-in from left (25%) + fade-in + scale-in (0.92 → 1.0)
 *  - Pop exit: slide-out to right (50%) + fade-out
 *
 * ### Tab switching (top-level)
 *  - Enter: fade-in only (no slide — feels faster)
 *  - Exit: fade-out only
 */
object TitanNavTransitions {

    /** Forward navigation transitions. */
    fun forwardEnter(): EnterTransition =
        slideInHorizontally(
            animationSpec = tween(SharedTransitionController.DEFAULT_DURATION_MS, easing = SharedTransitionController.EmphasizedDecelerate),
            initialOffsetX = { fullWidth -> fullWidth / 2 },
        ) + fadeIn(
            animationSpec = tween(SharedTransitionController.DEFAULT_DURATION_MS),
        ) + scaleIn(
            animationSpec = tween(SharedTransitionController.DEFAULT_DURATION_MS, easing = SharedTransitionController.EmphasizedDecelerate),
            initialScale = 0.92f,
        )

    fun forwardExit(): ExitTransition =
        slideOutHorizontally(
            animationSpec = tween(SharedTransitionController.DEFAULT_DURATION_MS, easing = SharedTransitionController.EmphasizedAccelerate),
            targetOffsetX = { fullWidth -> -fullWidth / 4 },
        ) + fadeOut(
            animationSpec = tween(SharedTransitionController.DEFAULT_DURATION_MS),
            targetAlpha = 0.5f,
        )

    /** Backward navigation transitions. */
    fun backwardEnter(): EnterTransition =
        slideInHorizontally(
            animationSpec = tween(SharedTransitionController.DEFAULT_DURATION_MS, easing = SharedTransitionController.EmphasizedDecelerate),
            initialOffsetX = { fullWidth -> -fullWidth / 4 },
        ) + fadeIn(
            animationSpec = tween(SharedTransitionController.DEFAULT_DURATION_MS),
        ) + scaleIn(
            animationSpec = tween(SharedTransitionController.DEFAULT_DURATION_MS, easing = SharedTransitionController.EmphasizedDecelerate),
            initialScale = 0.92f,
        )

    fun backwardExit(): ExitTransition =
        slideOutHorizontally(
            animationSpec = tween(SharedTransitionController.DEFAULT_DURATION_MS, easing = SharedTransitionController.EmphasizedAccelerate),
            targetOffsetX = { fullWidth -> fullWidth / 2 },
        ) + fadeOut(
            animationSpec = tween(SharedTransitionController.DEFAULT_DURATION_MS),
        )

    /** Tab switching transitions (fade only). */
    fun tabEnter(): EnterTransition = fadeIn(tween(SharedTransitionController.DEFAULT_DURATION_MS))
    fun tabExit(): ExitTransition = fadeOut(tween(SharedTransitionController.DEFAULT_DURATION_MS))
}

/**
 * ## rememberSharedFilePath
 *
 * Helper to remember the file path being navigated to, for use as the
 * shared element key.
 *
 * Used by BrowserScreen / SearchResultsGridScreen to mark which file
 * was tapped, so the ViewerScreen knows which shared element to animate
 * from.
 */
@Composable
fun rememberSharedFilePath(initial: String? = null): androidx.compose.runtime.MutableState<String?> {
    return remember { androidx.compose.runtime.mutableStateOf(initial) }
}

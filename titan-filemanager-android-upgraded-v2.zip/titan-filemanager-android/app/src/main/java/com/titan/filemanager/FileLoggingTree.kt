package com.titan.filemanager

import android.os.Build
import android.os.Environment
import timber.log.Timber
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * FileLoggingTree — a custom Timber tree that writes all log messages
 * (including crash stack traces) to the public Download folder.
 *
 * ## Why this exists
 * The app crashes on launch but the user can't see logcat.
 * This tree writes every log line to:
 *   /sdcard/Download/titan-logs/titan-log-<timestamp>.txt
 *
 * On crash, the GlobalExceptionHandler also writes a separate crash report:
 *   /sdcard/Download/titan-logs/crash-<timestamp>.txt
 *
 * ## Usage
 * ```kotlin
 * Timber.plant(Timber.DebugTree())
 * Timber.plant(FileLoggingTree())
 * ```
 */
class FileLoggingTree : Timber.Tree() {

    private val logDir: File by lazy {
        val dir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "titan-logs"
        )
        if (!dir.exists()) dir.mkdirs()
        dir
    }

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault())
    private val fileDateFormat = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.getDefault())

    override fun log(priority: Int, tag: String?, message: String, t: Throwable?) {
        try {
            val timestamp = dateFormat.format(Date())
            val level = when (priority) {
                android.util.Log.VERBOSE -> "V"
                android.util.Log.DEBUG -> "D"
                android.util.Log.INFO -> "I"
                android.util.Log.WARN -> "W"
                android.util.Log.ERROR -> "E"
                android.util.Log.ASSERT -> "A"
                else -> "?"
            }

            val logLine = buildString {
                append("[$timestamp] ")
                append("$level/")
                append(tag ?: "TitanFM")
                append(": ")
                append(message)
                if (t != null) {
                    append("\n")
                    val sw = StringWriter()
                    t.printStackTrace(PrintWriter(sw))
                    append(sw.toString())
                }
                append("\n")
            }

            // Write to today's log file
            val fileName = "titan-log-${SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())}.txt"
            val logFile = File(logDir, fileName)
            logFile.appendText(logLine)
        } catch (_: Exception) {
            // Don't crash the app if logging fails
        }
    }

    /**
     * Write a crash report to a separate file for easy identification.
     */
    fun writeCrashReport(thread: Thread, throwable: Throwable) {
        try {
            val crashFile = File(logDir, "crash-${fileDateFormat.format(Date())}.txt")
            val report = buildString {
                append("═══════════════════════════════════════════════════════════\n")
                append("  TITAN FILE MANAGER — CRASH REPORT\n")
                append("═══════════════════════════════════════════════════════════\n")
                append("Date: ${dateFormat.format(Date())}\n")
                append("Thread: ${thread.name} (id=${thread.id})\n")
                append("Process: ${android.os.Process.myPid()}\n")
                append("Android SDK: ${Build.VERSION.SDK_INT} (${Build.VERSION.RELEASE})\n")
                append("Device: ${Build.MANUFACTURER} ${Build.MODEL}\n")
                append("App Version: ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})\n")
                append("Build Type: ${if (BuildConfig.DEBUG) "debug" else "release"}\n")
                append("═══════════════════════════════════════════════════════════\n")
                append("\n")
                append("EXCEPTION:\n")
                append(throwable.javaClass.name)
                append(": ")
                append(throwable.message ?: "(no message)")
                append("\n\n")
                append("STACK TRACE:\n")
                val sw = StringWriter()
                throwable.printStackTrace(PrintWriter(sw))
                append(sw.toString())
                append("\n")
                append("═══════════════════════════════════════════════════════════\n")
                append("END OF CRASH REPORT\n")
            }
            crashFile.writeText(report)
        } catch (_: Exception) {
            // Don't crash again
        }
    }
}

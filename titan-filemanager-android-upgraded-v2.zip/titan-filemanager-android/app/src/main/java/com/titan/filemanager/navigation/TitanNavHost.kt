package com.titan.filemanager.navigation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.titan.filemanager.core.navigation.NavRoutes
import com.titan.filemanager.core.permissions.StoragePermissionRationale
import com.titan.filemanager.core.permissions.rememberStoragePermissionState
import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.core.ui.analyticsdetail.AnalyticsDetailScreen
import com.titan.filemanager.core.ui.automotive.AutomotiveBrowserScreen
import com.titan.filemanager.core.ui.bookmarks.BookmarksScreen
import com.titan.filemanager.core.ui.cloud.CloudAuthScreen
import com.titan.filemanager.core.ui.cloud.CloudBrowserScreen
import com.titan.filemanager.core.ui.compression.CompressionOptionsDialog
import com.titan.filemanager.core.ui.duplicatedetail.DuplicateDetailScreen
import com.titan.filemanager.core.ui.extract.ExtractOptionsDialog
import com.titan.filemanager.core.ui.hidden.HiddenFilesScreen
import com.titan.filemanager.core.ui.preview.FilePreviewBottomSheet
import com.titan.filemanager.core.ui.properties.FilePropertiesBottomSheet
import com.titan.filemanager.core.ui.recent.RecentFilesScreen
import com.titan.filemanager.core.ui.searchfilter.SearchFilterScreen
import com.titan.filemanager.core.ui.searchresults.SearchResultsGridScreen
import com.titan.filemanager.core.ui.settingsabout.SettingsAboutScreen
import com.titan.filemanager.core.ui.settingsappearance.SettingsAppearanceScreen
import com.titan.filemanager.core.ui.appearance.AdvancedAppearanceScreen
import com.titan.filemanager.core.ui.settingsstorage.SettingsStorageScreen
import com.titan.filemanager.core.ui.storage.StorageOverviewScreen
import com.titan.filemanager.core.ui.tagmanager.TagManagerScreen
import com.titan.filemanager.core.ui.wear.WearViewerScreen
import com.titan.filemanager.error.CrashReviewScreen
import com.titan.filemanager.feature.analytics.AnalyticsScreen
import com.titan.filemanager.feature.archive.ArchiveScreen
import com.titan.filemanager.feature.browser.BrowserScreen
import com.titan.filemanager.feature.cloud.CloudScreen
import com.titan.filemanager.feature.duplicates.DuplicatesScreen
import com.titan.filemanager.feature.home.HomeScreen
import com.titan.filemanager.feature.search.SearchScreen
import com.titan.filemanager.feature.settings.SettingsScreen
import com.titan.filemanager.feature.transfer.TransferScreen
import com.titan.filemanager.feature.trash.TrashScreen
import com.titan.filemanager.feature.vault.VaultScreen
import com.titan.filemanager.feature.viewer.ViewerScreen
import com.titan.filemanager.ui.importfiles.ImportFilesDialog
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch

/**
 * App-level NavHost — wires in ALL feature and core-ui screens.
 *
 * ═══════════════════════════════════════════════════════════
 * ROUTE INVENTORY (32 routes — ALL WIRED, zero placeholders)
 * ═══════════════════════════════════════════════════════════
 *
 * TOP-LEVEL (5 — bottom nav tabs):
 *   HOME, BROWSER, SEARCH, CLOUD, SETTINGS
 *
 * DETAIL (14 — pushed from top-level):
 *   VIEWER/{path}, TRANSFER, ARCHIVE/{path}, VAULT, DUPLICATES,
 *   ANALYTICS, TRASH, STORAGE_OVERVIEW, BOOKMARKS, RECENT_FILES,
 *   HIDDEN_FILES, CLOUD_AUTH/{providerId}, CLOUD_BROWSER/{providerId}/{path},
 *   DUPLICATE_DETAIL/{groupId}, ANALYTICS_DETAIL
 *
 * SETTINGS SUB-SCREENS (3):
 *   SETTINGS_ABOUT, SETTINGS_STORAGE, SETTINGS_APPEARANCE
 *
 * UTILITY SCREENS (4 — added in Priority 3):
 *   TAG_MANAGER, SEARCH_RESULTS/{query}, WEAR_VIEWER, AUTOMOTIVE_BROWSER
 *
 * MODAL (4 — bottom sheets / dialogs, ALL WIRED in Category 1 fix):
 *   MODAL_FILE_PROPERTIES/{path}     → FilePropertiesBottomSheet
 *   MODAL_FILE_PREVIEW/{path}        → FilePreviewBottomSheet
 *   MODAL_COMPRESSION/{count}/{size} → CompressionOptionsDialog
 *   MODAL_EXTRACT/{path}/{count}/{encrypted} → ExtractOptionsDialog
 *
 * ═══════════════════════════════════════════════════════════
 * TRANSITIONS
 * ═══════════════════════════════════════════════════════════
 *
 * Forward navigation: slide-in from right + fade-in
 * Backward navigation: slide-out to right + fade-out
 * Tab switch: fade-in / fade-out (no slide)
 */
@Composable
fun TitanNavHost(
    navController: NavHostController,
    modifier: Modifier = Modifier,
) {
    NavHost(
        navController = navController,
        startDestination = NavRoutes.HOME,
        modifier = modifier,
        // Default transitions — forward slide
        enterTransition = {
            slideInHorizontally(tween(300), initialOffsetX = { it }) + fadeIn(tween(300))
        },
        exitTransition = {
            slideOutHorizontally(tween(200), targetOffsetX = { -it / 3 }) + fadeOut(tween(200))
        },
        popEnterTransition = {
            slideInHorizontally(tween(300), initialOffsetX = { -it / 3 }) + fadeIn(tween(300))
        },
        popExitTransition = {
            slideOutHorizontally(tween(200), targetOffsetX = { it }) + fadeOut(tween(200))
        },
    ) {
        // ═══════════════════════════════════════════════════════════
        // TOP-LEVEL DESTINATIONS (bottom nav tabs)
        // ═══════════════════════════════════════════════════════════

        composable(NavRoutes.HOME) {
            // Wire up the HomeScreen's quick action / bookmark / recent-file
            // tap callbacks to actual navigation routes. Previously these
            // were not passed, so all quick action tiles on the home
            // dashboard (Scan, Search, Vault, Analytics, Duplicates, Clean,
            // and crucially the new "Files" tile) silently did nothing
            // when tapped — the user had no way to reach the Browser from
            // the Home tab other than via the bottom nav.
            HomeScreen(
                modifier = modifier,
                onBookmarkClick = { bookmark ->
                    // Open the Browser at the bookmarked path.
                    // Previously this navigated to bare NavRoutes.BROWSER
                    // which always opened at /sdcard — the bookmarked
                    // path was silently ignored, making bookmarks
                    // useless. Now we use browserRoute(path) which
                    // passes the path as a URL-encoded argument.
                    navController.navigate(NavRoutes.browserRoute(bookmark.path))
                },
                onRecentFileClick = { recentFile ->
                    // Open the file viewer for this file
                    navController.navigate(NavRoutes.viewerRoute(recentFile.path))
                },
                onQuickAction = { actionKey ->
                    when (actionKey) {
                        "files"      -> navController.navigate(NavRoutes.BROWSER)
                        "search"     -> navController.navigate(NavRoutes.SEARCH)
                        "vault"      -> navController.navigate(NavRoutes.VAULT)
                        "analytics"  -> navController.navigate(NavRoutes.ANALYTICS)
                        "duplicates" -> navController.navigate(NavRoutes.DUPLICATES)
                        "ai"         -> navController.navigate(NavRoutes.AI)
                        "scan"       -> navController.navigate(NavRoutes.ENGINE_SCAN)
                        "clean"      -> navController.navigate(NavRoutes.TRASH)
                        // Settings is no longer a bottom-nav tab — the
                        // gear icon in the Home top bar is now the
                        // primary entry point to the Settings screen.
                        "settings"   -> navController.navigate(NavRoutes.SETTINGS)
                        // Unknown actions are no-ops rather than crashes
                        else -> { }
                    }
                },
            )
        }

        // Browser supports two route patterns:
        //   - "browser"        → opens at default start path (/sdcard)
        //   - "browser/{path}" → opens at the specified folder
        // The optional path argument is used when navigating from a
        // bookmark tap. Both patterns share the same composable body.
        composable(NavRoutes.BROWSER) {
            val permission = rememberStoragePermissionState()
            if (permission.isGranted) {
                val startPath = rememberStartPath()
                BrowserScreenWithConfig(
                    startPath = startPath,
                    modifier = modifier,
                    navController = navController,
                )
            } else {
                StoragePermissionRationale(state = permission, modifier = modifier)
            }
        }

        composable(
            route = NavRoutes.BROWSER_ROUTE,
            arguments = listOf(navArgument(NavRoutes.ARG_PATH) { type = NavType.StringType }),
        ) { backStackEntry ->
            val permission = rememberStoragePermissionState()
            if (permission.isGranted) {
                val encodedPath = backStackEntry.arguments?.getString(NavRoutes.ARG_PATH)
                val startPath = decodePath(encodedPath).ifBlank { rememberStartPath() }
                BrowserScreenWithConfig(
                    startPath = startPath,
                    modifier = modifier,
                    navController = navController,
                )
            } else {
                StoragePermissionRationale(state = permission, modifier = modifier)
            }
        }

        composable(NavRoutes.SEARCH) {
            // Wire onFileClick so tapping a search result opens the
            // Viewer. Previously this was not passed, so taps on
            // search results did nothing.
            SearchScreen(
                modifier = modifier,
                onFileClick = { file ->
                    navController.navigate(NavRoutes.viewerRoute(file.path))
                },
            )
        }

        composable(NavRoutes.CLOUD) { CloudScreen(modifier = modifier) }

        composable(NavRoutes.SETTINGS) {
            // Pass real version info from PackageInfo so the hero
            // header and footer don't show hardcoded "v1.0.0" /
            // "Build 2024.06" anymore. This keeps the Settings tab
            // consistent with the About sub-screen.
            val context = androidx.compose.ui.platform.LocalContext.current
            val packageInfo = remember {
                try {
                    context.packageManager.getPackageInfo(context.packageName, 0)
                } catch (_: Throwable) {
                    null
                }
            }
            val versionName = packageInfo?.versionName ?: "1.0"
            val versionCode = packageInfo?.let {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) it.longVersionCode.toInt()
                else @Suppress("DEPRECATION") it.versionCode
            } ?: 1

            SettingsScreen(
                modifier = modifier,
                versionName = versionName,
                versionCode = versionCode,
                onNavigateToAppearance = { navController.navigate(NavRoutes.SETTINGS_APPEARANCE) },
                onNavigateToStorage = { navController.navigate(NavRoutes.SETTINGS_STORAGE) },
                onNavigateToTags = { navController.navigate(NavRoutes.TAG_MANAGER) },
                onNavigateToAbout = { navController.navigate(NavRoutes.SETTINGS_ABOUT) },
                onNavigateToCrashReview = { navController.navigate(NavRoutes.CRASH_REVIEW) },
                onNavigateToEngine = { navController.navigate(NavRoutes.ENGINE_SETTINGS) },
                onNavigateToSecurity = { navController.navigate(NavRoutes.SECURITY_SETTINGS) },
                onNavigateToSystem = { navController.navigate(NavRoutes.SYSTEM_SETTINGS) },
                onNavigateToBackup = { navController.navigate(NavRoutes.BACKUP_SETTINGS) },
            )
        }

        // ═══════════════════════════════════════════════════════════
        // DETAIL SCREENS — with path arguments
        // ═══════════════════════════════════════════════════════════

        composable(
            route = NavRoutes.VIEWER_ROUTE,
            arguments = listOf(navArgument(NavRoutes.ARG_PATH) { type = NavType.StringType }),
        ) { backStackEntry ->
            val path = decodePath(backStackEntry.arguments?.getString(NavRoutes.ARG_PATH))
            ViewerScreen(
                file = buildFileItemFromPath(path),
                modifier = modifier,
                onBack = { navController.popBackStack() },
            )
        }

        composable(
            route = NavRoutes.ARCHIVE_ROUTE,
            arguments = listOf(navArgument(NavRoutes.ARG_PATH) { type = NavType.StringType }),
        ) { backStackEntry ->
            val path = decodePath(backStackEntry.arguments?.getString(NavRoutes.ARG_PATH))
            ArchiveScreen(
                modifier = modifier,
                onBack = { navController.popBackStack() },
                // Pass the tapped archive path so the screen auto-lists
                // its entries. Previously this was decoded but never
                // passed — the screen showed a hardcoded sample path.
                initialArchivePath = path,
            )
        }

        composable(
            route = NavRoutes.CLOUD_AUTH_ROUTE,
            arguments = listOf(navArgument(NavRoutes.ARG_PROVIDER_ID) { type = NavType.StringType }),
        ) { backStackEntry ->
            val providerId = backStackEntry.arguments?.getString(NavRoutes.ARG_PROVIDER_ID) ?: ""
            CloudAuthScreen(
                providerName = providerId,
                authUrl = "https://example.com/oauth?provider=$providerId",
                redirectUrl = "titanfilemanager://oauth/callback",
                onAuthSuccess = { code -> /* ViewModel.exchangeCode(code) */ },
                onBack = { navController.popBackStack() },
            )
        }

        composable(
            route = NavRoutes.CLOUD_BROWSER_ROUTE,
            arguments = listOf(
                navArgument(NavRoutes.ARG_PROVIDER_ID) { type = NavType.StringType },
                navArgument(NavRoutes.ARG_PATH) { type = NavType.StringType },
            ),
        ) { backStackEntry ->
            // Wire with real CloudBrowserViewModel instead of
            // emptyList(). Previously this screen always showed "no
            // files" and Download/Upload/Refresh were no-ops.
            val viewModel: com.titan.filemanager.ui.screens.CloudBrowserViewModel = hiltViewModel()
            val cloudFiles by viewModel.files.collectAsStateWithLifecycle()
            val message by viewModel.message.collectAsStateWithLifecycle()
            val snackbarHostState = remember { androidx.compose.material3.SnackbarHostState() }
            androidx.compose.runtime.LaunchedEffect(message) {
                message?.let {
                    snackbarHostState.showSnackbar(it)
                    viewModel.clearMessage()
                }
            }
            val providerId = backStackEntry.arguments?.getString(NavRoutes.ARG_PROVIDER_ID) ?: ""
            val path = decodePath(backStackEntry.arguments?.getString(NavRoutes.ARG_PATH))
            // Map UiCloudFile → CloudFile (screen type).
            val items = cloudFiles.map {
                com.titan.filemanager.core.ui.cloud.CloudFile(
                    name = it.name,
                    path = it.path,
                    size = it.size,
                    modifiedAt = it.modifiedAt,
                    isDirectory = it.isDirectory,
                    mimeType = it.mimeType,
                )
            }
            CloudBrowserScreen(
                providerName = providerId,
                providerColor = androidx.compose.ui.graphics.Color(0xFF1A73E8),
                currentPath = path,
                files = items,
                onBack = { navController.popBackStack() },
                onNavigate = { newPath ->
                    navController.navigate(NavRoutes.cloudBrowserRoute(providerId, newPath))
                },
                onDownload = { file ->
                    // Map back to UiCloudFile for the VM.
                    val uiFile = cloudFiles.first { it.path == file.path }
                    viewModel.downloadFile(uiFile)
                },
                onUpload = {
                    // TODO: launch SAF picker, then call viewModel.uploadFile(localPath, remotePath)
                    // For now, set a message that the snackbar LaunchedEffect will pick up.
                    // Can't call showSnackbar directly here because it's a suspend function.
                    viewModel.showUploadPickerMessage()
                },
                onRefresh = { viewModel.loadFiles() },
            )
        }

        composable(
            route = NavRoutes.DUPLICATE_DETAIL_ROUTE,
            arguments = listOf(navArgument(NavRoutes.ARG_GROUP_ID) { type = NavType.StringType }),
        ) { backStackEntry ->
            // Wire with real DuplicateDetailViewModel instead of
            // emptyList(). Previously this screen always showed "no
            // duplicates" and Delete/Keep buttons were no-ops.
            val viewModel: com.titan.filemanager.ui.screens.DuplicateDetailViewModel = hiltViewModel()
            val files by viewModel.files.collectAsStateWithLifecycle()
            val message by viewModel.message.collectAsStateWithLifecycle()
            val snackbarHostState = remember { androidx.compose.material3.SnackbarHostState() }
            androidx.compose.runtime.LaunchedEffect(message) {
                message?.let {
                    snackbarHostState.showSnackbar(it)
                    viewModel.clearMessage()
                }
            }
            // Map UiDuplicateFile → DuplicateFile (screen type).
            val items = files.map {
                com.titan.filemanager.core.ui.duplicatedetail.DuplicateFile(
                    name = it.name,
                    path = it.path,
                    size = it.size,
                    modifiedAt = it.modifiedAt,
                    contentHash = it.contentHash,
                )
            }
            DuplicateDetailScreen(
                files = items,
                onBack = { navController.popBackStack() },
                onDelete = { path ->
                    // Find the file by path to get its contentHash for verification.
                    val file = items.firstOrNull { it.path == path }
                    if (file != null) viewModel.deleteFile(file.path, file.contentHash)
                },
                onKeep = { path -> viewModel.markAsKept(path) },
            )
        }

        // ═══════════════════════════════════════════════════════════
        // DETAIL SCREENS — no arguments
        // ═══════════════════════════════════════════════════════════

        composable(NavRoutes.TRANSFER) {
            TransferScreen(modifier = modifier, onBack = { navController.popBackStack() })
        }

        composable(NavRoutes.VAULT) {
            VaultScreen(modifier = modifier, onBack = { navController.popBackStack() })
        }

        composable(NavRoutes.DUPLICATES) {
            DuplicatesScreen(modifier = modifier, onBack = { navController.popBackStack() })
        }

        composable(NavRoutes.ANALYTICS) {
            AnalyticsScreen(modifier = modifier, onBack = { navController.popBackStack() })
        }

        composable(NavRoutes.TRASH) {
            TrashScreen(modifier = modifier, onBack = { navController.popBackStack() })
        }

        composable(NavRoutes.AI) {
            com.titan.filemanager.feature.ai.AiScreen(
                modifier = modifier,
                onBack = { navController.popBackStack() },
            )
        }

        composable(NavRoutes.STORAGE_OVERVIEW) {
            StorageOverviewScreen(onBack = { navController.popBackStack() })
        }

        composable(NavRoutes.BOOKMARKS) {
            // Wire with real BookmarksViewModel instead of emptyList().
            // Previously this screen always showed "no bookmarks" and
            // all add/remove/rename callbacks were no-ops.
            val viewModel: com.titan.filemanager.ui.screens.BookmarksViewModel = hiltViewModel()
            val bookmarks by viewModel.bookmarks.collectAsStateWithLifecycle()
            // Map UiBookmark (contract type) → BookmarkItem (screen type).
            val items = bookmarks.map {
                com.titan.filemanager.core.ui.bookmarks.BookmarkItem(
                    id = it.id,
                    name = it.name,
                    path = it.path,
                    isFolder = it.isFolder,
                    sortOrder = it.sortOrder,
                )
            }
            BookmarksScreen(
                bookmarks = items,
                onBack = { navController.popBackStack() },
                onNavigate = { path -> navController.navigate(NavRoutes.browserRoute(path)) },
                onAddBookmark = { path -> viewModel.addBookmark(path) },
                onRemoveBookmark = { id -> viewModel.removeBookmark(id) },
                onRenameBookmark = { id, name -> viewModel.renameBookmark(id, name) },
            )
        }

        composable(NavRoutes.RECENT_FILES) {
            // Wire with real RecentFilesViewModel instead of emptyList().
            // Previously this screen always showed "no recent files"
            // and the Clear button did nothing.
            val viewModel: com.titan.filemanager.ui.screens.RecentFilesViewModel = hiltViewModel()
            val recentFiles by viewModel.recentFiles.collectAsStateWithLifecycle()
            // Map UiRecentFile (contract type) → RecentFileItem (screen type).
            // Both have the same fields but are different classes.
            val items = recentFiles.map {
                com.titan.filemanager.core.ui.recent.RecentFileItem(
                    name = it.name,
                    path = it.path,
                    size = it.size,
                    modifiedAt = it.modifiedAt,
                    isDirectory = it.isDirectory,
                )
            }
            RecentFilesScreen(
                recentFiles = items,
                onBack = { navController.popBackStack() },
                onFileClick = { path -> navController.navigate(NavRoutes.viewerRoute(path)) },
                onClearHistory = { viewModel.clearHistory() },
            )
        }

        composable(NavRoutes.HIDDEN_FILES) {
            // Wire with real HiddenFilesViewModel instead of emptyList().
            // Previously this screen always showed "no hidden files"
            // and Unhide/Unhide All buttons were no-ops.
            val viewModel: com.titan.filemanager.ui.screens.HiddenFilesViewModel = hiltViewModel()
            val hiddenFiles by viewModel.hiddenFiles.collectAsStateWithLifecycle()
            val message by viewModel.message.collectAsStateWithLifecycle()
            val snackbarHostState = remember { androidx.compose.material3.SnackbarHostState() }
            androidx.compose.runtime.LaunchedEffect(message) {
                message?.let {
                    snackbarHostState.showSnackbar(it)
                    viewModel.clearMessage()
                }
            }
            val items = hiddenFiles.map {
                com.titan.filemanager.core.ui.hidden.HiddenFile(
                    name = it.name,
                    path = it.path,
                    size = it.size,
                    isDirectory = it.isDirectory,
                )
            }
            HiddenFilesScreen(
                hiddenFiles = items,
                onBack = { navController.popBackStack() },
                onUnhide = { path -> viewModel.unhide(path) },
                onUnhideAll = { viewModel.unhideAll() },
            )
        }

        composable(NavRoutes.SEARCH_FILTER) {
            SearchFilterScreen(
                onApply = { filters -> /* ViewModel.applyFilters(filters) */ },
                onBack = { navController.popBackStack() },
            )
        }

        composable(NavRoutes.ANALYTICS_DETAIL) {
            AnalyticsDetailScreen(onBack = { navController.popBackStack() })
        }

        // ═══════════════════════════════════════════════════════════
        // SETTINGS SUB-SCREENS
        // ═══════════════════════════════════════════════════════════

        composable(NavRoutes.SETTINGS_ABOUT) {
            // Wire real BuildConfig info + action intents.
            // Previously the screen was called with only `onBack`,
            // so version "2.0.0" / build 180 / "Jul 04, 2026" were
            // all hardcoded defaults — and the 6 action rows
            // (Privacy/Terms/Source/Licenses/Rate/Bug) were all
            // no-ops. Now we pass real version info from PackageInfo
            // and wire each action to a system Intent (web URL,
            // mailto, or Play Store).
            val context = androidx.compose.ui.platform.LocalContext.current
            val packageInfo = remember {
                try {
                    context.packageManager.getPackageInfo(context.packageName, 0)
                } catch (_: Throwable) {
                    null
                }
            }
            val versionName = packageInfo?.versionName ?: "1.0"
            val versionCode = packageInfo?.let {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) it.longVersionCode.toInt()
                else @Suppress("DEPRECATION") it.versionCode
            } ?: 1
            val buildDate = remember {
                val installMs = runCatching {
                    context.packageManager.getPackageInfo(context.packageName, 0).firstInstallTime
                }.getOrDefault(System.currentTimeMillis())
                java.text.SimpleDateFormat("MMM dd, yyyy", java.util.Locale.getDefault())
                    .format(java.util.Date(installMs))
            }

            SettingsAboutScreen(
                onBack = { navController.popBackStack() },
                versionName = versionName,
                versionCode = versionCode,
                buildDate = buildDate,
                onRateApp = {
                    // Open Play Store listing (falls back to Play Store
                    // web URL if the app isn't installed).
                    val intent = android.content.Intent(
                        android.content.Intent.ACTION_VIEW,
                        android.net.Uri.parse("market://details?id=${context.packageName}"),
                    ).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                    runCatching { context.startActivity(intent) }
                },
                onReportBug = {
                    // Open email composer with pre-filled bug report.
                    val intent = android.content.Intent(android.content.Intent.ACTION_SENDTO).apply {
                        data = android.net.Uri.parse("mailto:titan-filemanager@example.com?subject=Bug Report v${versionName}")
                        addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    runCatching { context.startActivity(intent) }
                },
                onViewSource = {
                    val intent = android.content.Intent(
                        android.content.Intent.ACTION_VIEW,
                        android.net.Uri.parse("https://github.com/titan-filemanager/android"),
                    ).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                    runCatching { context.startActivity(intent) }
                },
                onViewPrivacy = {
                    val intent = android.content.Intent(
                        android.content.Intent.ACTION_VIEW,
                        android.net.Uri.parse("https://titan-filemanager.github.io/privacy"),
                    ).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                    runCatching { context.startActivity(intent) }
                },
                onViewTerms = {
                    val intent = android.content.Intent(
                        android.content.Intent.ACTION_VIEW,
                        android.net.Uri.parse("https://titan-filemanager.github.io/terms"),
                    ).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                    runCatching { context.startActivity(intent) }
                },
                onViewLicenses = {
                    // Open the system "Open source licenses" view.
                    // Most apps use a dedicated Activity for this; we
                    // fall back to a web URL to keep this wiring
                    // self-contained.
                    val intent = android.content.Intent(
                        android.content.Intent.ACTION_VIEW,
                        android.net.Uri.parse("https://titan-filemanager.github.io/licenses"),
                    ).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                    runCatching { context.startActivity(intent) }
                },
            )
        }

        composable(NavRoutes.SETTINGS_STORAGE) {
            // Wire real cache sizes + real clear operations.
            // Previously the screen was called with only `onBack`,
            // so all 5 cache rows showed hardcoded mock numbers (45 MB
            // thumbnails, 28 MB search index, 12 MB database, 8 MB
            // temp, 2 MB logs) and tapping "Clear" on any row opened
            // the confirmation dialog but confirming it did nothing
            // (the `onClearXxx = {}` defaults silently discarded the
            // action). Now we compute real sizes from the app's
            // cacheDir / databaseList / filesDir, and each clear
            // callback actually deletes the corresponding files.
            val context = androidx.compose.ui.platform.LocalContext.current
            val cacheInfoState = remember { mutableStateOf<com.titan.filemanager.core.ui.settingsstorage.CacheInfo?>(null) }

            // Helper: compute the real CacheInfo from the filesystem.
            // Run on IO dispatcher because directory walks can be slow.
            androidx.compose.runtime.LaunchedEffect(Unit) {
                cacheInfoState.value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    val cacheDir = context.cacheDir
                    val thumbsBytes = dirSize(java.io.File(cacheDir, "thumbnails"))
                    val searchBytes = dirSize(java.io.File(cacheDir, "search_index"))
                    val databaseBytes = context.databaseList().sumOf { name ->
                        runCatching {
                            context.getDatabasePath(name).takeIf { it.exists() }?.length() ?: 0L
                        }.getOrDefault(0L)
                    }
                    val tempBytes = dirSize(java.io.File(context.filesDir, "tmp"))
                    val logBytes = dirSize(java.io.File(context.filesDir, "logs"))
                    val totalCache = thumbsBytes + searchBytes + databaseBytes + tempBytes + logBytes
                    // Total app size: code + data + cache. Approximated
                    // via the app's data dir size for now (the accurate
                    // value would come from StorageStatsManager which
                    // requires API 26+ and is more complex).
                    val totalApp = dirSize(context.dataDir) + dirSize(cacheDir)
                    com.titan.filemanager.core.ui.settingsstorage.CacheInfo(
                        thumbnailCacheBytes = thumbsBytes,
                        searchIndexBytes = searchBytes,
                        databaseBytes = databaseBytes,
                        tempFilesBytes = tempBytes,
                        logFilesBytes = logBytes,
                        totalAppBytes = totalApp,
                        totalCacheBytes = totalCache,
                    )
                }
            }

            // Use a CoroutineScope tied to the screen's lifecycle for
            // the clear operations (GlobalScope is discouraged in
            // Compose). We use rememberCoroutineScope() which gives us
            // a scope that's cancelled when the composable leaves the
            // composition — safe for fire-and-forget file deletions.
            val clearScope = androidx.compose.runtime.rememberCoroutineScope()
            fun clearDir(child: String) {
                clearScope.launch(kotlinx.coroutines.Dispatchers.IO) {
                    val target = java.io.File(context.cacheDir, child).takeIf { it.exists() }
                        ?: java.io.File(context.filesDir, child).takeIf { it.exists() }
                        ?: return@launch
                    target.listFiles()?.forEach { it.deleteRecursively() }
                }
            }
            fun clearLogs() {
                clearScope.launch(kotlinx.coroutines.Dispatchers.IO) {
                    val logsDir = java.io.File(context.filesDir, "logs").takeIf { it.exists() } ?: return@launch
                    logsDir.listFiles()?.forEach { it.deleteRecursively() }
                }
            }

            SettingsStorageScreen(
                onBack = { navController.popBackStack() },
                cacheInfo = cacheInfoState.value
                    ?: com.titan.filemanager.core.ui.settingsstorage.CacheInfo(
                        thumbnailCacheBytes = 0,
                        searchIndexBytes = 0,
                        databaseBytes = 0,
                        tempFilesBytes = 0,
                        logFilesBytes = 0,
                        totalAppBytes = 0,
                        totalCacheBytes = 0,
                    ),
                onClearThumbnails = { clearDir("thumbnails") },
                onClearSearchIndex = { clearDir("search_index") },
                onClearDatabase = {
                    // Deleting databases at runtime is risky — only
                    // clear the cache tables, not the whole DB file.
                    // For now, no-op with a TODO comment.
                    // TODO: invoke cacheRepository.invalidateAll() instead.
                },
                onClearTempFiles = { clearDir("tmp") },
                onClearLogs = { clearLogs() },
                onClearAll = {
                    clearDir("thumbnails")
                    clearDir("search_index")
                    clearDir("tmp")
                    clearLogs()
                },
            )
        }

        composable(NavRoutes.SETTINGS_APPEARANCE) {
            SettingsAppearanceScreen(
                onBack = { navController.popBackStack() },
                onNavigateToAdvanced = { navController.navigate(NavRoutes.ADVANCED_APPEARANCE) },
            )
        }

        // ── Advanced Appearance Hub ──────────────────────────────
        composable(NavRoutes.ADVANCED_APPEARANCE) {
            AdvancedAppearanceScreen(
                onBack = { navController.popBackStack() },
                onNavigateToTheme = { navController.navigate(NavRoutes.APPEARANCE_THEME) },
                onNavigateToTypography = { navController.navigate(NavRoutes.APPEARANCE_TYPOGRAPHY) },
                onNavigateToShape = { navController.navigate(NavRoutes.APPEARANCE_SHAPE) },
                onNavigateToDensity = { navController.navigate(NavRoutes.APPEARANCE_DENSITY) },
                onNavigateToElevation = { navController.navigate(NavRoutes.APPEARANCE_ELEVATION) },
                onNavigateToMotion = { navController.navigate(NavRoutes.APPEARANCE_MOTION) },
                onNavigateToGlass = { navController.navigate(NavRoutes.APPEARANCE_GLASS) },
            )
        }

        composable(NavRoutes.APPEARANCE_THEME) {
            com.titan.filemanager.core.ui.appearance.theme.ThemeColorScreen(
                onBack = { navController.popBackStack() },
            )
        }
        composable(NavRoutes.APPEARANCE_TYPOGRAPHY) {
            com.titan.filemanager.core.ui.appearance.typography.TypographyScreen(
                onBack = { navController.popBackStack() },
            )
        }
        composable(NavRoutes.APPEARANCE_SHAPE) {
            com.titan.filemanager.core.ui.appearance.shape.ShapeScreen(
                onBack = { navController.popBackStack() },
            )
        }
        composable(NavRoutes.APPEARANCE_DENSITY) {
            com.titan.filemanager.core.ui.appearance.density.DensityScreen(
                onBack = { navController.popBackStack() },
            )
        }
        composable(NavRoutes.APPEARANCE_ELEVATION) {
            com.titan.filemanager.core.ui.appearance.elevation.ElevationScreen(
                onBack = { navController.popBackStack() },
            )
        }
        composable(NavRoutes.APPEARANCE_MOTION) {
            com.titan.filemanager.core.ui.appearance.motion.MotionScreen(
                onBack = { navController.popBackStack() },
            )
        }
        composable(NavRoutes.APPEARANCE_GLASS) {
            com.titan.filemanager.core.ui.appearance.glass.GlassmorphismScreen(
                onBack = { navController.popBackStack() },
            )
        }

        // ═══════════════════════════════════════════════════════════
        // ENGINE CONFIGURATION SCREENS (Phase B)
        // ═══════════════════════════════════════════════════════════

        composable(NavRoutes.ENGINE_SETTINGS) {
            com.titan.filemanager.core.ui.engine.EngineSettingsScreen(
                onBack = { navController.popBackStack() },
                onNavigateToScan = { navController.navigate(NavRoutes.ENGINE_SCAN) },
                onNavigateToCache = { navController.navigate(NavRoutes.ENGINE_CACHE) },
                onNavigateToSearch = { navController.navigate(NavRoutes.ENGINE_SEARCH) },
                onNavigateToThumbnail = { navController.navigate(NavRoutes.ENGINE_THUMBNAIL) },
                onNavigateToTrash = { navController.navigate(NavRoutes.ENGINE_TRASH) },
                onNavigateToAnalytics = { navController.navigate(NavRoutes.ENGINE_ANALYTICS) },
                onNavigateToAi = { navController.navigate(NavRoutes.ENGINE_AI) },
            )
        }
        composable(NavRoutes.ENGINE_SCAN) {
            com.titan.filemanager.core.ui.engine.ScanEngineScreen(onBack = { navController.popBackStack() })
        }
        composable(NavRoutes.ENGINE_CACHE) {
            com.titan.filemanager.core.ui.engine.CacheEngineScreen(onBack = { navController.popBackStack() })
        }
        composable(NavRoutes.ENGINE_SEARCH) {
            com.titan.filemanager.core.ui.engine.SearchEngineScreen(onBack = { navController.popBackStack() })
        }
        composable(NavRoutes.ENGINE_THUMBNAIL) {
            com.titan.filemanager.core.ui.engine.ThumbnailEngineScreen(onBack = { navController.popBackStack() })
        }
        composable(NavRoutes.ENGINE_TRASH) {
            com.titan.filemanager.core.ui.engine.TrashEngineScreen(onBack = { navController.popBackStack() })
        }
        composable(NavRoutes.ENGINE_ANALYTICS) {
            com.titan.filemanager.core.ui.engine.AnalyticsEngineScreen(onBack = { navController.popBackStack() })
        }
        composable(NavRoutes.ENGINE_AI) {
            com.titan.filemanager.core.ui.engine.AiEngineScreen(onBack = { navController.popBackStack() })
        }

        // ═══════════════════════════════════════════════════════════
        // SECURITY & CLOUD SCREENS (Phase C)
        // ═══════════════════════════════════════════════════════════

        composable(NavRoutes.SECURITY_SETTINGS) {
            com.titan.filemanager.core.ui.security.SecuritySettingsScreen(
                onBack = { navController.popBackStack() },
                onNavigateToVault = { navController.navigate(NavRoutes.SECURITY_VAULT) },
                onNavigateToCloud = { navController.navigate(NavRoutes.SECURITY_CLOUD) },
                onNavigateToNotifications = { navController.navigate(NavRoutes.SECURITY_NOTIFICATIONS) },
            )
        }
        composable(NavRoutes.SECURITY_VAULT) {
            com.titan.filemanager.core.ui.security.VaultSecurityScreen(onBack = { navController.popBackStack() })
        }
        composable(NavRoutes.SECURITY_CLOUD) {
            com.titan.filemanager.core.ui.security.CloudSyncScreen(onBack = { navController.popBackStack() })
        }
        composable(NavRoutes.SECURITY_NOTIFICATIONS) {
            com.titan.filemanager.core.ui.security.NotificationSettingsScreen(onBack = { navController.popBackStack() })
        }

        // ═══════════════════════════════════════════════════════════
        // SYSTEM & BEHAVIOR SCREENS (Phase D)
        // ═══════════════════════════════════════════════════════════

        composable(NavRoutes.SYSTEM_SETTINGS) {
            com.titan.filemanager.core.ui.system.SystemSettingsScreen(
                onBack = { navController.popBackStack() },
                onNavigateToFileBrowser = { navController.navigate(NavRoutes.SYSTEM_FILE_BROWSER) },
                onNavigateToAccessibility = { navController.navigate(NavRoutes.SYSTEM_ACCESSIBILITY) },
                onNavigateToPerformance = { navController.navigate(NavRoutes.SYSTEM_PERFORMANCE) },
                onNavigateToStorage = { navController.navigate(NavRoutes.SYSTEM_STORAGE) },
                onNavigateToBehavior = { navController.navigate(NavRoutes.SYSTEM_BEHAVIOR) },
                onNavigateToAdvanced = { navController.navigate(NavRoutes.SYSTEM_ADVANCED) },
            )
        }
        composable(NavRoutes.SYSTEM_FILE_BROWSER) {
            com.titan.filemanager.core.ui.system.FileBrowserSettingsScreen(onBack = { navController.popBackStack() })
        }
        composable(NavRoutes.SYSTEM_ACCESSIBILITY) {
            com.titan.filemanager.core.ui.system.AccessibilitySettingsScreen(onBack = { navController.popBackStack() })
        }
        composable(NavRoutes.SYSTEM_PERFORMANCE) {
            com.titan.filemanager.core.ui.system.PerformanceSettingsScreen(onBack = { navController.popBackStack() })
        }
        composable(NavRoutes.SYSTEM_STORAGE) {
            com.titan.filemanager.core.ui.system.StorageSettingsScreen(onBack = { navController.popBackStack() })
        }
        composable(NavRoutes.SYSTEM_BEHAVIOR) {
            com.titan.filemanager.core.ui.system.BehaviorSettingsScreen(onBack = { navController.popBackStack() })
        }
        composable(NavRoutes.SYSTEM_ADVANCED) {
            com.titan.filemanager.core.ui.system.AdvancedSettingsScreen(onBack = { navController.popBackStack() })
        }

        // ═══════════════════════════════════════════════════════════
        // BACKUP & ARCHIVE SCREENS (Phase E)
        // ═══════════════════════════════════════════════════════════

        composable(NavRoutes.BACKUP_SETTINGS) {
            com.titan.filemanager.core.ui.backup.BackupSettingsScreen(
                onBack = { navController.popBackStack() },
                onNavigateToBackup = { navController.navigate(NavRoutes.BACKUP_CONFIG) },
                onNavigateToArchive = { navController.navigate(NavRoutes.ARCHIVE_CONFIG) },
            )
        }
        composable(NavRoutes.BACKUP_CONFIG) {
            com.titan.filemanager.core.ui.backup.BackupConfigScreen(onBack = { navController.popBackStack() })
        }
        composable(NavRoutes.ARCHIVE_CONFIG) {
            com.titan.filemanager.core.ui.backup.ArchiveConfigScreen(onBack = { navController.popBackStack() })
        }

        composable(NavRoutes.TAG_MANAGER) {
            // Wire with real TagManagerViewModel instead of
            // emptyList(). Previously this screen always showed "no
            // tags" and Create/Update/Delete were no-ops.
            val viewModel: com.titan.filemanager.ui.screens.TagManagerViewModel = hiltViewModel()
            val tags by viewModel.tags.collectAsStateWithLifecycle()
            TagManagerScreen(
                tags = tags,
                onBack = { navController.popBackStack() },
                onCreateTag = { viewModel.createTag(it) },
                onUpdateTag = { viewModel.updateTag(it) },
                onDeleteTag = { viewModel.deleteTag(it) },
            )
        }

        composable(
            route = NavRoutes.SEARCH_RESULTS_ROUTE,
            arguments = listOf(navArgument(NavRoutes.ARG_QUERY) { type = NavType.StringType }),
        ) { backStackEntry ->
            // Wire with real SearchResultsViewModel instead of
            // emptyList(). Previously this screen always showed "no
            // results" even when the user navigated from a search.
            val viewModel: com.titan.filemanager.ui.screens.SearchResultsViewModel = hiltViewModel()
            val results by viewModel.results.collectAsStateWithLifecycle()
            val query = decodePath(backStackEntry.arguments?.getString(NavRoutes.ARG_QUERY))
            SearchResultsGridScreen(
                query = query,
                results = results,
                onBack = { navController.popBackStack() },
            )
        }

        composable(NavRoutes.WEAR_VIEWER) {
            // Wire with real WearViewerViewModel instead of
            // emptyList(). Previously this screen always showed "no
            // files" on the Wear OS companion.
            val viewModel: com.titan.filemanager.ui.screens.WearViewerViewModel = hiltViewModel()
            val files by viewModel.files.collectAsStateWithLifecycle()
            WearViewerScreen(
                files = files,
            )
        }

        composable(NavRoutes.AUTOMOTIVE_BROWSER) {
            // Wire with real AutomotiveBrowserViewModel instead of
            // emptyList(). Previously this screen always showed "no
            // files" on the Android Auto companion.
            val viewModel: com.titan.filemanager.ui.screens.AutomotiveBrowserViewModel = hiltViewModel()
            val files by viewModel.files.collectAsStateWithLifecycle()
            val startPath = rememberStartPath()
            androidx.compose.runtime.LaunchedEffect(startPath) {
                viewModel.loadPath(startPath)
            }
            AutomotiveBrowserScreen(
                currentPath = startPath,
                files = files,
                onBack = { navController.popBackStack() },
            )
        }

        composable(NavRoutes.CRASH_REVIEW) {
            CrashReviewScreen(
                onBack = { navController.popBackStack() },
            )
        }

        composable(
            route = NavRoutes.IMPORT_FILES_ROUTE,
            arguments = listOf(
                navArgument(NavRoutes.ARG_PATHS) { type = NavType.StringType },
                navArgument(NavRoutes.ARG_LABEL) { type = NavType.StringType },
            ),
        ) { backStackEntry ->
            val encodedPaths = backStackEntry.arguments?.getString(NavRoutes.ARG_PATHS)
            val label = decodePath(backStackEntry.arguments?.getString(NavRoutes.ARG_LABEL))
            val filePaths = NavRoutes.parseImportPaths(encodedPaths)
            ImportFilesDialog(
                filePaths = filePaths,
                sourceLabel = label,
                onDismiss = { navController.popBackStack() },
            )
        }

        // ═══════════════════════════════════════════════════════════
        // MODAL SCREENS — bottom sheets and dialogs
        //
        // Each modal route accepts path/count/size arguments and renders
        // the real composable from core-ui. Dismissal pops the back stack.
        // ═══════════════════════════════════════════════════════════

        // ── File Properties Bottom Sheet ───────────────────────────
        // Shows full metadata: size, dates, permissions, hash, tags.
        composable(
            route = NavRoutes.MODAL_FILE_PROPERTIES_ROUTE,
            arguments = listOf(navArgument(NavRoutes.ARG_PATH) { type = NavType.StringType }),
        ) { backStackEntry ->
            val path = decodePath(backStackEntry.arguments?.getString(NavRoutes.ARG_PATH))
            val file = remember(path) { buildFileItemFromPath(path) }
            FilePropertiesBottomSheet(
                file = file,
                onDismiss = { navController.popBackStack() },
                onCopyPath = {
                    // Copy path to system clipboard
                    val clipboard = navController.context
                        .getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    clipboard.setPrimaryClip(
                        android.content.ClipData.newPlainText("File path", path),
                    )
                },
                onCopyHash = null, // Populated by ViewModel when hash is computed
                contentHash = null, // Populated by ViewModel
                permissions = null, // Populated by ViewModel
                inode = null,       // Populated by ViewModel
            )
        }

        // ── File Preview Bottom Sheet ──────────────────────────────
        // Quick preview: image (pinch-zoom), video, audio, PDF, text, generic.
        composable(
            route = NavRoutes.MODAL_FILE_PREVIEW_ROUTE,
            arguments = listOf(navArgument(NavRoutes.ARG_PATH) { type = NavType.StringType }),
        ) { backStackEntry ->
            val path = decodePath(backStackEntry.arguments?.getString(NavRoutes.ARG_PATH))
            val file = remember(path) { buildFileItemFromPath(path) }
            FilePreviewBottomSheet(
                files = listOf(file),
                onDismiss = { navController.popBackStack() },
                onOpen = { clickedFile ->
                    navController.navigate(NavRoutes.viewerRoute(clickedFile.path))
                },
                onShare = { clickedFile ->
                    // Launch system share intent
                    val shareIntent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                        type = "*/*"
                        putExtra(
                            android.content.Intent.EXTRA_STREAM,
                            androidx.core.content.FileProvider.getUriForFile(
                                navController.context,
                                "${navController.context.packageName}.fileprovider",
                                java.io.File(clickedFile.path),
                            ),
                        )
                        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    navController.context.startActivity(
                        android.content.Intent.createChooser(shareIntent, "Share ${clickedFile.name}"),
                    )
                },
                onCopyPath = { clickedFile ->
                    val clipboard = navController.context
                        .getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    clipboard.setPrimaryClip(
                        android.content.ClipData.newPlainText("File path", clickedFile.path),
                    )
                },
                onShowInfo = { clickedFile ->
                    navController.navigate(NavRoutes.modalFilePropertiesRoute(clickedFile.path))
                },
            )
        }

        // ── Compression Options Dialog ─────────────────────────────
        // Format selection, compression level, password, split volumes.
        composable(
            route = NavRoutes.MODAL_COMPRESSION_ROUTE,
            arguments = listOf(
                navArgument(NavRoutes.ARG_COUNT) { type = NavType.IntType },
                navArgument(NavRoutes.ARG_TOTAL_SIZE) { type = NavType.StringType },
            ),
        ) { backStackEntry ->
            val fileCount = backStackEntry.arguments?.getInt(NavRoutes.ARG_COUNT) ?: 1
            val totalSize = backStackEntry.arguments?.getString(NavRoutes.ARG_TOTAL_SIZE) ?: "0 B"
            val context = androidx.compose.ui.platform.LocalContext.current
            CompressionOptionsDialog(
                fileCount = fileCount,
                totalSize = totalSize,
                onConfirm = { options ->
                    // Launch archive creation via WorkManager (background)
                    // The ArchiveEngine handles ZIP/7z/TAR.GZ creation
                    // TODO: wire CompressionWorker from data-archive module
                    navController.popBackStack()
                },
                onDismiss = { navController.popBackStack() },
            )
        }

        // ── Extract Options Dialog ─────────────────────────────────
        // Destination, password, overwrite mode, structure preservation.
        composable(
            route = NavRoutes.MODAL_EXTRACT_ROUTE,
            arguments = listOf(
                navArgument(NavRoutes.ARG_PATH) { type = NavType.StringType },
                navArgument(NavRoutes.ARG_COUNT) { type = NavType.IntType },
                navArgument(NavRoutes.ARG_ENCRYPTED) { type = NavType.BoolType },
            ),
        ) { backStackEntry ->
            val archivePath = decodePath(backStackEntry.arguments?.getString(NavRoutes.ARG_PATH))
            val entryCount = backStackEntry.arguments?.getInt(NavRoutes.ARG_COUNT) ?: 0
            val isEncrypted = backStackEntry.arguments?.getBoolean(NavRoutes.ARG_ENCRYPTED) ?: false
            val archiveName = remember(archivePath) {
                java.io.File(archivePath).name
            }
            val context = androidx.compose.ui.platform.LocalContext.current
            val destinationPath = remember { mutableStateOf("/storage/emulated/0/Download") }

            // SAF directory picker launcher
            val pickDirectoryLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
                contract = androidx.activity.result.contract.ActivityResultContracts.OpenDocumentTree(),
            ) { uri ->
                if (uri != null) {
                    // Convert content URI to filesystem path if possible
                    val path = uri.path ?: return@rememberLauncherForActivityResult
                    // SAF returns paths like /tree/primary:Download → convert to /storage/emulated/0/Download
                    val fsPath = if (path.startsWith("/tree/primary:")) {
                        "/storage/emulated/0/${path.removePrefix("/tree/primary:")}"
                    } else if (path.startsWith("/tree/")) {
                        path.removePrefix("/tree/").replace(":", "/")
                    } else {
                        path
                    }
                    destinationPath.value = fsPath
                }
            }

            ExtractOptionsDialog(
                archiveName = archiveName,
                entryCount = entryCount,
                isEncrypted = isEncrypted,
                defaultDestination = destinationPath.value,
                onConfirm = { options ->
                    // Launch archive extraction via WorkManager (background)
                    // TODO: wire ExtractionWorker from data-archive module
                    navController.popBackStack()
                },
                onDismiss = { navController.popBackStack() },
                onBrowseDestination = {
                    // Launch SAF directory picker (ACTION_OPEN_DOCUMENT_TREE)
                    pickDirectoryLauncher.launch(null)
                },
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════════════

/**
 * Renders the Browser screen.
 *
 * Previously this checked `screenWidthDp >= 600` and rendered a
 * dual-pane (split-screen) Browser on wide screens / landscape.
 * The dual-pane "multi-window" system has been removed by user
 * request — the Browser now always uses the standard single-pane
 * `BrowserScreen` regardless of screen size. This simplifies the
 * UX (no confusing split view, no toggle button) and the codebase
 * (no need to maintain two parallel Browser implementations).
 */
@Composable
private fun BrowserScreenWithConfig(
    startPath: String,
    modifier: Modifier,
    navController: NavHostController,
) {
    val onFileClick: (com.titan.filemanager.core.model.file.FileItem) -> Unit = { file ->
        navController.navigate(NavRoutes.viewerRoute(file.path))
    }

    BrowserScreen(
        startPath = startPath,
        modifier = modifier,
        onFileClick = onFileClick,
    )
}

@Composable
private fun rememberStartPath(): String {
    val externalDir = android.os.Environment.getExternalStorageDirectory()
    return externalDir?.absolutePath ?: "/"
}

/**
 * Recursively compute the total size in bytes of a directory tree.
 * Returns 0 if the file does not exist or is not a directory.
 *
 * Used by the Storage & Cache settings screen to compute real cache
 * sizes (thumbnails, search index, temp files, logs) instead of the
 * hardcoded mock values that were previously shown.
 */
private fun dirSize(file: java.io.File): Long {
    if (!file.exists()) return 0L
    if (file.isFile) return file.length()
    var size = 0L
    file.listFiles()?.forEach { child ->
        size += if (child.isDirectory) dirSize(child) else child.length()
    }
    return size
}

private fun decodePath(encoded: String?): String {
    if (encoded.isNullOrEmpty()) return ""
    return try {
        java.net.URLDecoder.decode(encoded, "UTF-8")
    } catch (_: Exception) {
        encoded
    }
}

/**
 * Construct a [FileItem] from a filesystem path by reading metadata via [java.io.File].
 *
 * Used by modal routes (File Properties, File Preview) that receive a path argument
 * from NavController and need a full [FileItem] to pass to the composable.
 *
 * If the file doesn't exist or metadata can't be read, returns a minimal placeholder
 * with just the path and name — the composable will handle the display gracefully.
 *
 * @param path absolute filesystem path (already URL-decoded).
 * @return a [FileItem] with real metadata, or a minimal placeholder on failure.
 */
private fun buildFileItemFromPath(path: String): FileItem {
    if (path.isBlank()) return FileItem(
        path = "",
        name = "",
        stableId = -1L,
        size = 0L,
        modifiedAt = 0L,
        isDirectory = false,
        isHidden = false,
    )

    return try {
        val file = java.io.File(path)
        val name = file.name.ifBlank { path }
        val isDirectory = file.isDirectory
        val size = if (isDirectory) 0L else file.length()
        val modifiedAt = file.lastModified()
        val isHidden = name.startsWith(".")
        // stableId: use hashCode of path as a fallback for inode (real inode
        // requires lstat() which is only available via Os.lstat() on API 21+)
        val stableId = path.hashCode().toLong() and 0xFFFFFFFFL

        FileItem(
            path = path,
            name = name,
            stableId = stableId,
            size = size,
            modifiedAt = modifiedAt,
            isDirectory = isDirectory,
            isHidden = isHidden,
        )
    } catch (_: Throwable) {
        // Fallback: return a minimal FileItem with just path and name
        FileItem(
            path = path,
            name = path.substringAfterLast('/'),
            stableId = 0L,
            size = 0L,
            modifiedAt = 0L,
            isDirectory = false,
        )
    }
}

@Composable
private fun PlaceholderScreen(label: String) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = "$label — coming soon",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

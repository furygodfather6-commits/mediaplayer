package com.titan.filemanager.ui.importfiles

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FileCopy
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.titan.filemanager.core.designsystem.icon.FileTypeIcon
import com.titan.filemanager.core.designsystem.modifier.clipToCircle
import com.titan.filemanager.core.designsystem.modifier.clipToRounded
import com.titan.filemanager.core.designsystem.tokens.ShapeTokens
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import com.titan.filemanager.deeplink.DeepLink
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.File
import javax.inject.Inject

/**
 * ## ImportFilesDialog
 *
 * Dialog shown when files are shared to TitanFileManager from another app
 * (via `android.intent.action.SEND` or `SEND_MULTIPLE`).
 *
 * ### Anatomy
 * ```
 * ┌──────────────────────────────────────────┐
 * │  Import 3 files                  ✕       │
 * ├──────────────────────────────────────────┤
 * │                                          │
 * │  📄 photo1.jpg           2.4 MB          │
 * │  📄 photo2.jpg           3.1 MB          │
 * │  📄 document.pdf         850 KB          │
 * │                                          │
 * ├──────────────────────────────────────────┤
 * │  Destination:                            │
 * │  📁 /storage/emulated/0/Download  [Browse]│
 * ├──────────────────────────────────────────┤
 * │            [Cancel]  [Import 3 files]    │
 * └──────────────────────────────────────────┘
 * ```
 *
 * ### Import flow
 *  1. User shares files from another app → DeepLinkHandler parses to [DeepLink.ImportFiles]
 *  2. TitanAppState.dispatchDeepLink() routes to this dialog
 *  3. User selects destination folder (defaults to /Download)
 *  4. User taps "Import" → files are copied to destination via IO dispatcher
 *  5. Progress shown inline; dialog dismisses on completion
 *
 * @param filePaths list of absolute file paths to import.
 * @param sourceLabel label shown in the dialog title (e.g., "Imported from Chrome").
 * @param onDismiss callback when the dialog is dismissed (cancel or complete).
 * @param onBrowseDestination callback to launch a folder picker (SAF).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImportFilesDialog(
    filePaths: List<String>,
    sourceLabel: String,
    onDismiss: () -> Unit,
    onBrowseDestination: () -> Unit = {},
    viewModel: ImportFilesViewModel = hiltViewModel(),
) {
    // Initialize the ViewModel with the file paths
    LaunchedEffect(filePaths) {
        viewModel.initialize(filePaths, sourceLabel)
    }

    val state by viewModel.state.collectAsState()

    AlertDialog(
        onDismissRequest = {
            if (!state.isImporting) onDismiss()
        },
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clipToCircle()
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        Icons.Filled.FileCopy,
                        contentDescription = null,
                        modifier = Modifier.size(24.dp),
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                    )
                }
                Spacer(Modifier.width(SpacingTokens.Md))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Import ${state.files.size} file${if (state.files.size != 1) "s" else ""}",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                    )
                    if (state.sourceLabel.isNotBlank()) {
                        Text(
                            text = state.sourceLabel,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
                IconButton(onClick = onDismiss, enabled = !state.isImporting) {
                    Icon(Icons.Filled.Close, contentDescription = "Close")
                }
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(SpacingTokens.Md),
            ) {
                // ── File list ────────────────────────────────────────
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp),
                ) {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(SpacingTokens.Xs),
                    ) {
                        items(state.files, key = { it.path }) { file ->
                            ImportFileRow(file)
                        }
                    }
                }

                // ── Destination picker ───────────────────────────────
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = ShapeTokens.Small,
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                    ),
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(SpacingTokens.Md),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            Icons.Filled.Folder,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp),
                            tint = MaterialTheme.colorScheme.primary,
                        )
                        Spacer(Modifier.width(SpacingTokens.Sm))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Save to",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            Text(
                                text = state.destinationPath,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Medium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                        TextButton(
                            onClick = onBrowseDestination,
                            enabled = !state.isImporting,
                        ) {
                            Text("Browse")
                        }
                    }
                }

                // ── Progress (when importing) ────────────────────────
                if (state.isImporting) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text(
                            text = "Importing ${state.importedCount} of ${state.files.size}...",
                            style = MaterialTheme.typography.bodyMedium,
                        )
                        Spacer(Modifier.height(SpacingTokens.Xs))
                        androidx.compose.material3.LinearProgressIndicator(
                            progress = { if (state.files.isNotEmpty()) state.importedCount.toFloat() / state.files.size else 0f },
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }

                // ── Error ────────────────────────────────────────────
                state.error?.let { err ->
                    Text(
                        text = err,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
            }
        },
        confirmButton = {
            if (state.isComplete) {
                Button(onClick = onDismiss) {
                    Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(SpacingTokens.Xs))
                    Text("Done")
                }
            } else {
                Button(
                    onClick = { viewModel.startImport() },
                    enabled = !state.isImporting && state.files.isNotEmpty(),
                ) {
                    Icon(Icons.Filled.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(SpacingTokens.Xs))
                    Text("Import ${state.files.size} file${if (state.files.size != 1) "s" else ""}")
                }
            }
        },
        dismissButton = {
            if (!state.isImporting && !state.isComplete) {
                TextButton(onClick = onDismiss) {
                    Text("Cancel")
                }
            }
        },
    )
}

@Composable
private fun ImportFileRow(file: ImportableFile) {
    val fileTypeIcon = FileTypeIcon.fromPath(file.path)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(ShapeTokens.Small)
            .background(MaterialTheme.colorScheme.surfaceContainerLow)
            .padding(SpacingTokens.Sm),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            imageVector = fileTypeIcon.imageVector,
            contentDescription = null,
            modifier = Modifier.size(28.dp),
            tint = fileTypeIcon.color,
        )
        Spacer(Modifier.width(SpacingTokens.Sm))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = file.name,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = formatBytes(file.size),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        if (file.imported) {
            Icon(
                Icons.Filled.Check,
                contentDescription = "Imported",
                modifier = Modifier.size(20.dp),
                tint = MaterialTheme.colorScheme.primary,
            )
        }
    }
}

private fun formatBytes(bytes: Long): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
    bytes < 1024 * 1024 * 1024 -> "%.1f MB".format(bytes / (1024.0 * 1024))
    else -> "%.2f GB".format(bytes / (1024.0 * 1024 * 1024))
}

// ═══════════════════════════════════════════════════════════════
// VIEW MODEL
// ═══════════════════════════════════════════════════════════════

/**
 * ImportFilesViewModel — manages the file import state + actual copy operations.
 *
 * Copies files on the IO dispatcher to avoid blocking the UI. Updates
 * progress incrementally as each file completes.
 */
@HiltViewModel
class ImportFilesViewModel @Inject constructor() : ViewModel() {

    private val _state = MutableStateFlow(ImportFilesUiState())
    val state: StateFlow<ImportFilesUiState> = _state.asStateFlow()

    /**
     * Initialize the view model with the files to import.
     * Called once when the dialog is first shown.
     */
    fun initialize(filePaths: List<String>, sourceLabel: String) {
        if (_state.value.files.isNotEmpty()) return // Already initialized

        val files = filePaths.map { path ->
            val file = File(path)
            ImportableFile(
                path = path,
                name = file.name,
                size = if (file.exists()) file.length() else 0L,
                imported = false,
            )
        }
        _state.update {
            it.copy(
                files = files,
                sourceLabel = sourceLabel,
                destinationPath = DEFAULT_DESTINATION,
            )
        }
    }

    /**
     * Set the destination folder for the import.
     */
    fun setDestination(path: String) {
        _state.update { it.copy(destinationPath = path) }
    }

    /**
     * Start the import — copies all files to the destination folder.
     *
     * Updates progress incrementally. Sets `isComplete` when all files
     * are copied (or an error occurs).
     */
    fun startImport() {
        if (_state.value.isImporting) return

        viewModelScope.launch {
            _state.update { it.copy(isImporting = true, error = null) }

            val destination = File(_state.value.destinationPath)
            if (!destination.exists() && !destination.mkdirs()) {
                _state.update {
                    it.copy(
                        isImporting = false,
                        error = "Cannot create destination folder: ${destination.absolutePath}",
                    )
                }
                return@launch
            }

            var importedCount = 0
            val updatedFiles = _state.value.files.toMutableList()

            for ((index, file) in updatedFiles.withIndex()) {
                try {
                    val source = File(file.path)
                    val target = File(destination, file.name)

                    // Handle name conflicts — append (1), (2), etc.
                    val finalTarget = resolveConflict(target)

                    withContext(Dispatchers.IO) {
                        source.copyTo(finalTarget, overwrite = false)
                    }

                    updatedFiles[index] = file.copy(imported = true)
                    importedCount++
                    _state.update {
                        it.copy(
                            files = updatedFiles.toList(),
                            importedCount = importedCount,
                        )
                    }
                } catch (e: Throwable) {
                    Timber.w(e, "Failed to import ${file.path}")
                    // Continue with remaining files — partial import is better than total failure
                }
            }

            _state.update {
                it.copy(
                    isImporting = false,
                    isComplete = true,
                    importedCount = importedCount,
                )
            }
        }
    }

    /**
     * Resolve a filename conflict by appending a number suffix.
     * Example: `photo.jpg` → `photo (1).jpg` → `photo (2).jpg`
     */
    private fun resolveConflict(target: File): File {
        if (!target.exists()) return target
        val baseName = target.nameWithoutExtension
        val ext = target.extension
        var counter = 1
        var candidate = File(target.parentFile, "$baseName ($counter).$ext")
        while (candidate.exists()) {
            counter++
            candidate = File(target.parentFile, "$baseName ($counter).$ext")
        }
        return candidate
    }

    companion object {
        private const val DEFAULT_DESTINATION = "/storage/emulated/0/Download"
    }
}

// ═══════════════════════════════════════════════════════════════
// DATA CLASSES
// ═══════════════════════════════════════════════════════════════

data class ImportableFile(
    val path: String,
    val name: String,
    val size: Long,
    val imported: Boolean,
)

data class ImportFilesUiState(
    val files: List<ImportableFile> = emptyList(),
    val sourceLabel: String = "",
    val destinationPath: String = "",
    val isImporting: Boolean = false,
    val isComplete: Boolean = false,
    val importedCount: Int = 0,
    val error: String? = null,
)

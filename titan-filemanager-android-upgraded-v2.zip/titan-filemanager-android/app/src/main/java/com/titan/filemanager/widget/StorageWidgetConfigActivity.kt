package com.titan.filemanager.widget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.titan.filemanager.core.designsystem.modifier.clipToCircle
import com.titan.filemanager.core.designsystem.modifier.clipToRounded
import com.titan.filemanager.core.designsystem.tokens.ShapeTokens
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens
import com.titan.filemanager.core.designsystem.theme.TitanTheme
import timber.log.Timber

/**
 * ## StorageWidgetConfigActivity
 *
 * Configuration activity shown when the user adds the storage widget to
 * their home screen. Lets the user choose widget options before the widget
 * is placed.
 *
 * ### Configuration options
 *  - **Show percentage** — toggle whether the usage percentage is shown
 *  - **Auto-refresh** — toggle whether the widget auto-updates every 30 min
 *  - **Storage source** — internal storage only (future: SD card, USB)
 *
 * ### Result
 * When the user taps "Add widget", the activity:
 *  1. Persists the configuration to SharedPreferences (`widget_prefs.xml`)
 *  2. Sets the result code to `RESULT_OK` with the widget ID extra
 *  3. Triggers an immediate widget update via [StorageWidgetProvider.forceUpdate]
 *  4. Finishes the activity — the system places the widget on the home screen
 *
 * ### AndroidManifest registration
 * ```xml
 * <activity
 *     android:name=".widget.StorageWidgetConfigActivity"
 *     android:exported="true"
 *     android:theme="@style/Theme.TitanFileManager">
 *     <intent-filter>
 *         <action android:name="android.appwidget.action.APPWIDGET_CONFIGURE" />
 *     </intent-filter>
 * </activity>
 * ```
 *
 * The activity must be declared with the `APPWIDGET_CONFIGURE` intent filter
 * for the system to launch it when the widget is added.
 */
class StorageWidgetConfigActivity : ComponentActivity() {

    private var appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // ── Extract widget ID from intent extras ────────────────────
        appWidgetId = intent?.extras?.getInt(
            AppWidgetManager.EXTRA_APPWIDGET_ID,
            AppWidgetManager.INVALID_APPWIDGET_ID,
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID

        // If no valid widget ID, finish immediately
        if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            setResult(RESULT_CANCELED)
            finish()
            return
        }

        // ── Set result to CANCELED by default (user might press back) ──
        setResult(RESULT_CANCELED)

        setContent {
            TitanTheme {
                WidgetConfigScreen(
                    onAddWidget = { showPercentage, autoRefresh ->
                        persistConfiguration(showPercentage, autoRefresh)
                        acceptWidget()
                    },
                    onCancel = { finish() },
                )
            }
        }
    }

    /**
     * Persist the widget configuration to SharedPreferences.
     *
     * Each widget instance gets its own preference key namespace based on
     * the widget ID, so multiple widgets can have different configurations.
     */
    private fun persistConfiguration(showPercentage: Boolean, autoRefresh: Boolean) {
        val prefs = getSharedPreferences("widget_prefs", MODE_PRIVATE)
        prefs.edit()
            .putBoolean("widget_${appWidgetId}_show_percentage", showPercentage)
            .putBoolean("widget_${appWidgetId}_auto_refresh", autoRefresh)
            .apply()
        Timber.i("Widget $appWidgetId config saved: showPercentage=$showPercentage, autoRefresh=$autoRefresh")
    }

    /**
     * Accept the widget — set result OK + trigger immediate update + finish.
     */
    private fun acceptWidget() {
        // Set result with widget ID
        val resultValue = Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
        setResult(RESULT_OK, resultValue)

        // Force immediate widget update so it shows fresh data right away
        StorageWidgetProvider.forceUpdate(this)

        finish()
    }
}

/**
 * Compose UI for the widget configuration screen.
 */
@Composable
private fun WidgetConfigScreen(
    onAddWidget: (showPercentage: Boolean, autoRefresh: Boolean) -> Unit,
    onCancel: () -> Unit,
) {
    var showPercentage by remember { mutableStateOf(true) }
    var autoRefresh by remember { mutableStateOf(true) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background,
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(SpacingTokens.Xxl),
            verticalArrangement = Arrangement.spacedBy(SpacingTokens.Lg),
        ) {
            // ── Header ──────────────────────────────────────────────
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.Md),
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clipToCircle()
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        Icons.Filled.Storage,
                        contentDescription = null,
                        modifier = Modifier.size(28.dp),
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                    )
                }
                Column {
                    Text(
                        text = "Storage Widget",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(
                        text = "Customize your home screen widget",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            Spacer(Modifier.height(SpacingTokens.Md))

            // ── Configuration options ───────────────────────────────
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = ShapeTokens.Medium,
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
                ),
            ) {
                Column(
                    modifier = Modifier.padding(SpacingTokens.Lg),
                    verticalArrangement = Arrangement.spacedBy(SpacingTokens.Md),
                ) {
                    Text(
                        text = "Display Options",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                    )

                    ConfigToggleRow(
                        icon = Icons.Filled.Bolt,
                        title = "Show percentage",
                        subtitle = "Display usage percentage next to progress bar",
                        checked = showPercentage,
                        onChange = { showPercentage = it },
                    )

                    ConfigToggleRow(
                        icon = Icons.Filled.Refresh,
                        title = "Auto-refresh",
                        subtitle = "Update widget every 30 minutes automatically",
                        checked = autoRefresh,
                        onChange = { autoRefresh = it },
                    )
                }
            }

            Spacer(Modifier.weight(1f))

            // ── Action buttons ──────────────────────────────────────
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(SpacingTokens.Sm),
            ) {
                TextButton(
                    onClick = onCancel,
                    modifier = Modifier.weight(1f),
                ) {
                    Text("Cancel")
                }
                Button(
                    onClick = { onAddWidget(showPercentage, autoRefresh) },
                    modifier = Modifier.weight(1f),
                ) {
                    Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(SpacingTokens.Xs))
                    Text("Add Widget")
                }
            }
        }
    }
}

@Composable
private fun ConfigToggleRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            icon,
            contentDescription = null,
            modifier = Modifier.size(24.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.width(SpacingTokens.Md))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium,
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

package com.titan.filemanager

import android.app.Application
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import androidx.work.WorkManager
import coil.ImageLoader
import coil.ImageLoaderFactory
import com.titan.filemanager.color.DynamicColorManager
import com.titan.filemanager.data.indexer.di.IndexerScheduler
import com.titan.filemanager.data.trash.cleanup.TrashCleanupWorker
import com.titan.filemanager.error.GlobalErrorHandler
import com.titan.filemanager.imaging.TitanImageLoaderFactory
import com.titan.filemanager.permission.NotificationPermissionHandler
import dagger.hilt.android.HiltAndroidApp
import timber.log.Timber
import javax.inject.Inject

/**
 * Titan Application entry point.
 *
 * Phase 6:
 *   - Implements [ImageLoaderFactory] — provides custom Coil ImageLoader
 *     with video/PDF thumbnail fetchers + mtime-aware cache keyer
 *   - Initializes [DynamicColorManager] — Material You dynamic color on
 *     Android 12+, manual wallpaper palette extraction on older versions
 *   - All Phase 5 features retained (GlobalErrorHandler, notification channels)
 *
 * ### Image loading pipeline
 * The custom [ImageLoader] from [TitanImageLoaderFactory] is the process-wide
 * singleton. All `AsyncImage` composables use it automatically.
 *
 * ### Dynamic color pipeline
 * [DynamicColorManager] observes wallpaper changes (Android 11-) or system
 * dynamic color (Android 12+) and exposes a StateFlow<ColorScheme?> that
 * TitanTheme observes.
 */
@HiltAndroidApp
class TitanApplication : Application(), Configuration.Provider, ImageLoaderFactory {

    @Inject
    lateinit var workerFactory: HiltWorkerFactory

    @Inject
    lateinit var indexerScheduler: IndexerScheduler

    @Inject
    lateinit var globalErrorHandler: GlobalErrorHandler

    @Inject
    lateinit var notificationPermissionHandler: NotificationPermissionHandler

    @Inject
    lateinit var imageLoaderFactory: TitanImageLoaderFactory

    @Inject
    lateinit var dynamicColorManager: DynamicColorManager

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .build()

    /**
     * Custom Coil ImageLoader — process-wide singleton.
     * Called by Coil when `coil.imageLoader(context)` is invoked.
     */
    override fun newImageLoader(): ImageLoader = imageLoaderFactory.create()

    override fun onCreate() {
        super.onCreate()

        // ═══════════════════════════════════════════════════════════
        // TIMBER + CRASH LOGGING — install FIRST before anything else
        // ═══════════════════════════════════════════════════════════
        if (Timber.treeCount == 0) {
            Timber.plant(Timber.DebugTree())
        }
        val fileTree = FileLoggingTree()
        Timber.plant(fileTree)

        // Install GlobalCrashHandler — saves crash reports to Download/titan-logs/
        GlobalCrashHandler.install(this)

        Timber.i("=======================================================")
        Timber.i("TitanApplication onCreate START")
        Timber.i("Version: ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})")
        Timber.i("Package: $packageName  PID: ${android.os.Process.myPid()}")
        Timber.i("=======================================================")

        try {
            // Step 1: GlobalErrorHandler
            Timber.i("Step 1: GlobalErrorHandler...")
            globalErrorHandler.install(
                appVersionName = BuildConfig.VERSION_NAME,
                appVersionCode = BuildConfig.VERSION_CODE.toLong(),
                buildType = if (BuildConfig.DEBUG) "debug" else "release",
            )
            globalErrorHandler.setCustomData("build_type", if (BuildConfig.DEBUG) "debug" else "release")
            globalErrorHandler.setCustomData("process_id", android.os.Process.myPid().toString())
            Timber.i("Step 1 done")

            // Step 2: Notification channels
            Timber.i("Step 2: Notification channels...")
            notificationPermissionHandler.createChannels()
            Timber.i("Step 2 done")

            // Step 3: DynamicColorManager
            Timber.i("Step 3: DynamicColorManager...")
            dynamicColorManager.initialize()
            Timber.i("Step 3 done")

            // Step 4: Background jobs
            Timber.i("Step 4: Background jobs...")
            scheduleBackgroundJobs()
            Timber.i("Step 4 done")

            Timber.i("=======================================================")
            Timber.i("TitanApplication onCreate COMPLETE — app ready!")
            Timber.i("=======================================================")

        } catch (e: Throwable) {
            Timber.e(e, "FATAL ERROR during onCreate: ${e.javaClass.name}: ${e.message}")
            fileTree.writeCrashReport(Thread.currentThread(), e)
            throw e
        }
    }

    override fun onTerminate() {
        super.onTerminate()
        globalErrorHandler.uninstall()
    }

    /**
     * Schedule periodic WorkManager jobs:
     *   - TrashCleanupWorker: every 24h, purges trash entries >30 days old
     *   - OneTimeIndexerWorker: one-shot on first launch, indexes storage
     *   - IncrementalIndexerWorker: every 6h, re-indexes modified files
     */
    private fun scheduleBackgroundJobs() {
        try {
            // Schedule periodic trash cleanup (every 24h)
            WorkManager.getInstance(this).enqueueUniquePeriodicWork(
                TrashCleanupWorker.WORK_NAME,
                androidx.work.ExistingPeriodicWorkPolicy.KEEP,
                androidx.work.PeriodicWorkRequestBuilder<TrashCleanupWorker>(
                    24, java.util.concurrent.TimeUnit.HOURS,
                ).build(),
            )

            // Schedule search indexer
            indexerScheduler.scheduleInitialIndex()
            indexerScheduler.schedulePeriodicReindex()

            Timber.i("Background jobs scheduled")
        } catch (e: Exception) {
            Timber.w(e, "Failed to schedule background jobs")
            // Report as non-fatal — the app can still run without periodic jobs
            // (they'll just be rescheduled on next launch).
            kotlinx.coroutines.runBlocking {
                globalErrorHandler.reportNonFatal(
                    throwable = e,
                    customData = mapOf("context" to "scheduleBackgroundJobs"),
                )
            }
        }
    }
}

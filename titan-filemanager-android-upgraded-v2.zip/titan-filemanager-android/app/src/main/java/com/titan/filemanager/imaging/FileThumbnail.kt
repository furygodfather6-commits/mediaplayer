package com.titan.filemanager.imaging

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BrokenImage
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImagePainter
import coil.compose.SubcomposeAsyncImage
import coil.compose.SubcomposeAsyncImageContent
import coil.request.ImageRequest
import com.titan.filemanager.core.designsystem.icon.FileTypeIcon
import com.titan.filemanager.core.designsystem.modifier.clipToRounded
import com.titan.filemanager.core.designsystem.tokens.ShapeTokens
import com.titan.filemanager.core.model.file.FileItem
import java.io.File

/**
 * ## FileThumbnail
 *
 * Compose component that displays a thumbnail for any [FileItem], automatically
 * choosing the right loading strategy based on file type:
 *
 *  - **Images** (jpg, png, gif, webp, bmp, heic) → load full image, downsampled
 *  - **Videos** (mp4, mkv, mov, etc.) → extract frame at 1s offset via [VideoFrameFetcher]
 *  - **PDFs** → render page 0 via [PdfPageFetcher]
 *  - **Other types** → show file-type icon from [FileTypeIcon]
 *
 * ### Loading states
 * The component shows three states via [SubcomposeAsyncImage]:
 *  - **Loading** — small CircularProgressIndicator over a placeholder background
 *  - **Success** — the loaded bitmap with [ContentScale.Crop]
 *  - **Error** — BrokenImage icon over a tinted background
 *
 * ### Memory efficiency
 * The image is loaded at the exact size of the Compose layout (via Coil's
 * automatic size resolution). No full-resolution bitmaps are kept in memory
 * for thumbnails.
 *
 * ### Usage
 * ```kotlin
 * FileThumbnail(
 *     file = fileItem,
 *     modifier = Modifier.size(96.dp),
 *     contentDescription = fileItem.name,
 * )
 * ```
 *
 * @param file the file to display a thumbnail for.
 * @param modifier modifier for the image.
 * @param contentDescription accessibility description (typically the file name).
 * @param contentScale how to scale the content within the bounds.
 * @param shape corner radius for the thumbnail (default: Small).
 * @param showFallbackIcon when true (default), shows file-type icon for non-image files.
 */
@Composable
fun FileThumbnail(
    file: FileItem,
    modifier: Modifier = Modifier,
    contentDescription: String? = file.name,
    contentScale: ContentScale = ContentScale.Crop,
    shape: androidx.compose.ui.graphics.Shape = ShapeTokens.Small,
    showFallbackIcon: Boolean = true,
) {
    val context = LocalContext.current
    val physicalFile = remember(file.path) { File(file.path) }
    val isThumbnailable = remember(file) { isThumbnailable(file) }

    if (!isThumbnailable && showFallbackIcon) {
        // Non-thumbnailable file — show icon
        val icon = if (file.isDirectory) FileTypeIcon.Folder
                   else FileTypeIcon.fromPath(file.path)
        Box(
            modifier = modifier
                .clip(shape)
                .background(icon.color.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = icon.imageVector,
                contentDescription = contentDescription,
                modifier = Modifier.size(widthOrHeight(modifier)),
                tint = icon.color,
            )
        }
        return
    }

    val request = remember(file.path, file.modifiedAt) {
        ImageRequest.Builder(context)
            .data(physicalFile)
            .crossfade(true)
            .build()
    }

    SubcomposeAsyncImage(
        model = request,
        contentDescription = contentDescription,
        contentScale = contentScale,
        modifier = modifier.clip(shape),
        loading = {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.surfaceContainerHigh),
                contentAlignment = Alignment.Center,
            ) {
                CircularProgressIndicator(
                    modifier = Modifier.size(20.dp),
                    strokeWidth = 2.dp,
                )
            }
        },
        error = {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.errorContainer),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    Icons.Filled.BrokenImage,
                    contentDescription = "Failed to load",
                    modifier = Modifier.size(widthOrHeight(modifier) / 2),
                    tint = MaterialTheme.colorScheme.onErrorContainer,
                )
            }
        },
        success = { SubcomposeAsyncImageContent() },
    )
}

/**
 * ## FileGridThumbnail
 *
 * Variant of [FileThumbnail] optimized for grid layouts. Adds a subtle
 * gradient overlay at the bottom for the file name, similar to Google Photos.
 *
 * @param file the file to display.
 * @param modifier modifier for the container.
 * @param showNameOverlay when true, overlays the file name at the bottom.
 */
@Composable
fun FileGridThumbnail(
    file: FileItem,
    modifier: Modifier = Modifier,
    showNameOverlay: Boolean = true,
) {
    Box(modifier = modifier) {
        FileThumbnail(
            file = file,
            modifier = Modifier.fillMaxSize(),
            contentDescription = file.name,
            shape = ShapeTokens.Small,
        )

        if (showNameOverlay && !file.isDirectory) {
            // Gradient overlay at the bottom for the file name
            androidx.compose.foundation.Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(ShapeTokens.Small),
            ) {
                val gradient = androidx.compose.ui.graphics.Brush.verticalGradient(
                    colors = listOf(
                        Color.Transparent,
                        Color.Black.copy(alpha = 0.6f),
                    ),
                    startY = size.height * 0.6f,
                    endY = size.height,
                )
                drawRect(gradient)
            }

            Text(
                text = file.name,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .size(width = 100.dp, height = 24.dp) // placeholder; real layout uses weight
                    .background(Color.Transparent),
                color = Color.White,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

/**
 * ## FileListThumbnail
 *
 * Variant of [FileThumbnail] optimized for list layouts — smaller (48dp default),
 * rounded square, no overlay.
 */
@Composable
fun FileListThumbnail(
    file: FileItem,
    modifier: Modifier = Modifier,
    size: Dp = 48.dp,
) {
    FileThumbnail(
        file = file,
        modifier = modifier.size(size),
        contentDescription = file.name,
        shape = ShapeTokens.Small,
    )
}

// ═══════════════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════════════

/**
 * Check whether the given file can be thumbnailed by Coil + our custom fetchers.
 */
private fun isThumbnailable(file: FileItem): Boolean {
    if (file.isDirectory) return false
    val ext = file.extension.lowercase()
    return ext in IMAGE_EXTENSIONS || ext in VIDEO_EXTENSIONS || ext == "pdf"
}

/**
 * Try to extract the width or height from a Modifier (best-effort).
 * Falls back to 24.dp if the modifier doesn't carry a fixed size.
 */
@Composable
private fun widthOrHeight(modifier: Modifier): Dp {
    // We can't easily read the size from a Modifier — fall back to a sensible default.
    // The actual size will be applied by the parent's Modifier.size().
    return 24.dp
}

private val IMAGE_EXTENSIONS = setOf(
    "jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif", "svg",
)

private val VIDEO_EXTENSIONS = setOf(
    "mp4", "mkv", "avi", "mov", "webm", "3gp", "flv", "wmv", "m4v",
)

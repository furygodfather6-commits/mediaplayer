package com.titan.filemanager.di

import com.titan.filemanager.core.common.dispatcher.DefaultDispatcherProvider
import com.titan.filemanager.core.common.dispatcher.DispatcherProvider
import com.titan.filemanager.core.common.logger.Logger
import com.titan.filemanager.core.common.logger.TimberLogger
import com.titan.filemanager.core.common.time.DefaultTimeProvider
import com.titan.filemanager.core.common.time.TimeProvider
import com.titan.filemanager.error.CrashReporter
import com.titan.filemanager.error.LocalCrashReporter
import com.titan.filemanager.error.NoopCrashReporter
import com.titan.filemanager.error.CompositeCrashReporter
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * App-level Hilt module — provides cross-cutting infrastructure
 * that has no natural home in any feature module:
 *
 *  - [DispatcherProvider] — coroutine dispatchers abstraction
 *  - [Logger] — Timber-backed logger
 *  - [TimeProvider] — current-time abstraction (for testability)
 *  - [CrashReporter] — local file-based crash reporter (with optional Firebase)
 *
 * Each is `@Singleton` because the underlying implementations are
 * stateless / thread-safe.
 *
 * ═══════════════════════════════════════════════════════════
 * CRASH REPORTER BINDING
 * ═══════════════════════════════════════════════════════════
 *
 * In **debug** builds we use a [CompositeCrashReporter] that fans out to:
 *   1. [LocalCrashReporter] — always persists to disk
 *   2. [NoopCrashReporter] — logs to Timber only
 *
 * In **release** builds we use [LocalCrashReporter] alone (Firebase
 * Crashlytics can be added when the google-services plugin is configured).
 *
 * The binding is controlled by [BuildConfig.DEBUG].
 */
@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDispatcherProvider(): DispatcherProvider = DefaultDispatcherProvider()

    @Provides
    @Singleton
    fun provideLogger(): Logger = TimberLogger()

    @Provides
    @Singleton
    fun provideTimeProvider(): TimeProvider = DefaultTimeProvider()

    /**
     * Provide the [CrashReporter] binding.
     *
     * In debug: composite (local + noop for logging)
     * In release: local only (Crashlytics to be added later)
     */
    @Provides
    @Singleton
    fun provideCrashReporter(
        localCrashReporter: LocalCrashReporter,
        noopCrashReporter: NoopCrashReporter,
    ): CrashReporter {
        return if (com.titan.filemanager.BuildConfig.DEBUG) {
            CompositeCrashReporter(setOf(localCrashReporter, noopCrashReporter))
        } else {
            // Production: local file reporter only — Firebase Crashlytics
            // will be added when the google-services plugin is configured.
            CompositeCrashReporter(setOf(localCrashReporter))
        }
    }
}

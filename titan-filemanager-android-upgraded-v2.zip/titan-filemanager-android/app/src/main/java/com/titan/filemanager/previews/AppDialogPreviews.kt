package com.titan.filemanager.previews

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.titan.filemanager.core.designsystem.theme.TitanTheme
import com.titan.filemanager.core.designsystem.theme.TitanThemeConfig
import com.titan.filemanager.error.CrashReport
import com.titan.filemanager.error.ErrorReportDialog
import com.titan.filemanager.permission.NotificationPermissionBanner
import com.titan.filemanager.permission.NotificationPermissionRationale

/**
 * ## AppDialogPreviews
 *
 * @Preview composables for app-level dialogs:
 *  - ErrorReportDialog (crash report display)
 *  - NotificationPermissionRationale (Android 13+ permission explanation)
 *  - NotificationPermissionBanner (inline banner for Settings)
 *
 * Note: ImportFilesDialog is NOT previewed here because it uses
 * `hiltViewModel()` which requires a Hilt-bound ViewModelStoreOwner.
 * Previewing it would require a custom preview parameter provider.
 */

// ═══════════════════════════════════════════════════════════════
// ERROR REPORT DIALOG
// ═══════════════════════════════════════════════════════════════

@Preview(name = "Error Report — Fatal crash", showBackground = true)
@Composable
private fun ErrorReportDialogFatalPreview() {
    val report = CrashReport(
        exceptionClass = "java.lang.NullPointerException",
        exceptionMessage = "Attempt to invoke virtual method on a null object reference",
        stackTrace = "at com.titan.filemanager.feature.browser.BrowserViewModel.loadFiles(BrowserViewModel.kt:45)\n" +
            "at com.titan.filemanager.feature.browser.BrowserScreen\$onCreate\$1.invokeSuspend(BrowserScreen.kt:78)",
        threadName = "main",
        threadPriority = 5,
        threadId = 1L,
        isFatal = true,
        timestampMs = System.currentTimeMillis(),
        deviceManufacturer = "Google",
        deviceModel = "Pixel 8 Pro",
        androidVersion = "14",
        sdkLevel = 34,
        abi = "arm64-v8a",
        appVersionName = "2.0.0",
        appVersionCode = 180L,
        buildType = "release",
        processId = 12345,
        processName = "com.titan.filemanager",
        freeHeapBytes = 50_000_000L,
        totalHeapBytes = 256_000_000L,
        nativeFreeBytes = 100_000_000L,
        storageFreeBytes = 50_000_000_000L,
        storageTotalBytes = 128_000_000_000L,
    )
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            ErrorReportDialog(
                report = report,
                onDismiss = {},
                onSendReport = {},
                onViewDetails = {},
            )
        }
    }
}

@Preview(name = "Error Report — Non-fatal", showBackground = true)
@Composable
private fun ErrorReportDialogNonFatalPreview() {
    val report = CrashReport(
        exceptionClass = "java.io.IOException",
        exceptionMessage = "Failed to read file: /sdcard/missing.txt",
        stackTrace = "at com.titan.filemanager.data.io.FileReader.read(FileReader.kt:23)",
        threadName = "DefaultDispatcher-worker-1",
        threadPriority = 5,
        threadId = 8L,
        isFatal = false,
        timestampMs = System.currentTimeMillis(),
        deviceManufacturer = "Samsung",
        deviceModel = "Galaxy S24",
        androidVersion = "14",
        sdkLevel = 34,
        abi = "arm64-v8a",
        appVersionName = "2.0.0",
        appVersionCode = 180L,
        buildType = "debug",
        processId = 5432,
        processName = "com.titan.filemanager",
        freeHeapBytes = 80_000_000L,
        totalHeapBytes = 192_000_000L,
        nativeFreeBytes = 120_000_000L,
        storageFreeBytes = 30_000_000_000L,
        storageTotalBytes = 64_000_000_000L,
    )
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            ErrorReportDialog(
                report = report,
                onDismiss = {},
                onSendReport = {},
                onViewDetails = {},
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// NOTIFICATION PERMISSION RATIONALE DIALOG
// ═══════════════════════════════════════════════════════════════

@Preview(name = "Notif Permission — First prompt", showBackground = true)
@Composable
private fun NotificationPermissionRationalePreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            NotificationPermissionRationale(
                onGrant = {},
                onDismiss = {},
                isPermanentlyDenied = false,
            )
        }
    }
}

@Preview(name = "Notif Permission — Permanently denied", showBackground = true)
@Composable
private fun NotificationPermissionRationaleDeniedPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            NotificationPermissionRationale(
                onGrant = {},
                onDismiss = {},
                onOpenSettings = {},
                isPermanentlyDenied = true,
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// NOTIFICATION PERMISSION BANNER (inline)
// ═══════════════════════════════════════════════════════════════

@Preview(name = "Notif Permission Banner", showBackground = true, widthDp = 360)
@Composable
private fun NotificationPermissionBannerPreview() {
    TitanTheme(config = TitanThemeConfig(dynamicColor = false)) {
        Surface(modifier = Modifier.padding(16.dp)) {
            NotificationPermissionBanner(
                onOpenSettings = {},
            )
        }
    }
}

package com.titan.filemanager.permission

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.titan.filemanager.core.designsystem.modifier.clipToCircle
import com.titan.filemanager.core.designsystem.modifier.clipToRounded
import com.titan.filemanager.core.designsystem.tokens.ElevationTokens
import com.titan.filemanager.core.designsystem.tokens.ShapeTokens
import com.titan.filemanager.core.designsystem.tokens.SpacingTokens

/**
 * ## NotificationPermissionRationale
 *
 * Dialog explaining why TitanFileManager needs notification permission.
 *
 * ### When to show
 *  - **First launch** — after onboarding, before the user enters the main app.
 *  - **Permission denied** — when the user tries to start a transfer, scan,
 *    or backup but notifications are disabled.
 *
 * ### Anatomy
 * ```
 * ┌────────────────────────────────────────┐
 * │            🔔 (icon)                   │
 * │                                        │
 * │  Notifications keep you informed       │
 * │                                        │
 * │  TitanFileManager uses notifications   │
 * │  to show:                              │
 * │                                        │
 * │  ✓ Transfer progress                   │
 * │  ✓ Scan completion                     │
 * │  ✓ Vault auto-lock alerts              │
 * │  ✓ Low storage warnings                │
 * │                                        │
 * │  ┌──────────────┐  ┌──────────────┐    │
 * │  │   Dismiss    │  │  Allow       │    │
 * │  └──────────────┘  └──────────────┘    │
 * └────────────────────────────────────────┘
 * ```
 */
@Composable
fun NotificationPermissionRationale(
    onGrant: () -> Unit,
    onDismiss: () -> Unit,
    onOpenSettings: (() -> Unit)? = null,
    isPermanentlyDenied: Boolean = false,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clipToCircle()
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = if (isPermanentlyDenied) Icons.Filled.NotificationsOff
                                      else Icons.Filled.Notifications,
                        contentDescription = null,
                        modifier = Modifier.size(32.dp),
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                    )
                }
                Spacer(Modifier.height(SpacingTokens.Md))
                Text(
                    text = if (isPermanentlyDenied) "Notifications are off"
                           else "Stay informed",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                )
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(SpacingTokens.Md),
            ) {
                Text(
                    text = if (isPermanentlyDenied) {
                        "You've blocked notifications for TitanFileManager. " +
                        "To re-enable them, open Settings and toggle " +
                        "\"Show notifications\"."
                    } else {
                        "TitanFileManager uses notifications to keep you " +
                        "informed about important events:"
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )

                if (!isPermanentlyDenied) {
                    // Feature list
                    FeatureItem(Icons.Filled.Notifications, "Transfer progress", "Live updates for copy/move operations")
                    FeatureItem(Icons.Filled.Notifications, "Scan completion", "Know when indexing finishes")
                    FeatureItem(Icons.Filled.Notifications, "Vault auto-lock", "Alerts when vault locks automatically")
                    FeatureItem(Icons.Filled.Notifications, "Low storage warnings", "Get notified before storage fills up")
                }
            }
        },
        confirmButton = {
            if (isPermanentlyDenied && onOpenSettings != null) {
                Button(onClick = onOpenSettings) {
                    Icon(Icons.Filled.Settings, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(SpacingTokens.Xs))
                    Text("Open Settings")
                }
            } else {
                Button(onClick = onGrant) {
                    Icon(Icons.Filled.Notifications, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(SpacingTokens.Xs))
                    Text("Allow notifications")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(if (isPermanentlyDenied) "Not now" else "Skip")
            }
        },
    )
}

/**
 * ## NotificationPermissionBanner
 *
 * Inline banner shown in Settings → Notifications when notifications are
 * disabled. Less intrusive than the [NotificationPermissionRationale] dialog.
 *
 * Anatomy:
 * ```
 * ┌────────────────────────────────────────────────────────┐
 * │ 🔔  Notifications are off                              │
 * │     You won't receive transfer or scan alerts.         │
 * │                                       [Open Settings]  │
 * └────────────────────────────────────────────────────────┘
 * ```
 */
@Composable
fun NotificationPermissionBanner(
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = ShapeTokens.Medium,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.tertiaryContainer,
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = ElevationTokens.Level1),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(SpacingTokens.Md),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clipToCircle()
                    .background(MaterialTheme.colorScheme.tertiary),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    Icons.Filled.NotificationsOff,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onTertiary,
                    modifier = Modifier.size(24.dp),
                )
            }
            Spacer(Modifier.width(SpacingTokens.Md))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Notifications are off",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onTertiaryContainer,
                )
                Text(
                    text = "You won't receive transfer or scan alerts.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.8f),
                )
            }
            TextButton(onClick = onOpenSettings) {
                Text("Open Settings")
            }
        }
    }
}

@Composable
private fun FeatureItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clipToCircle()
                .background(MaterialTheme.colorScheme.surfaceContainerHigh),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = Icons.Filled.Check,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
                tint = MaterialTheme.colorScheme.primary,
            )
        }
        Spacer(Modifier.width(SpacingTokens.Sm))
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

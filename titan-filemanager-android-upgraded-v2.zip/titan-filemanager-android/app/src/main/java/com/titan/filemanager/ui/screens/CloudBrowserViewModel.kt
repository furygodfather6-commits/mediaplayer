package com.titan.filemanager.ui.screens

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.titan.filemanager.core.ui.contracts.CloudBrowserContract
import com.titan.filemanager.core.ui.contracts.CloudTransferCallback
import com.titan.filemanager.core.ui.contracts.UiCloudFile
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * ViewModel for the Cloud Browser screen.
 *
 * Previously the CloudBrowserScreen was wired with `files = emptyList()`
 * and `onDownload`/`onUpload`/`onRefresh` as no-ops — the screen
 * always showed "no files" and the buttons did nothing.
 *
 * This VM injects the existing [CloudBrowserContract] (bound to
 * [com.titan.filemanager.di.CloudBrowserContractAdapter]) and loads
 * files reactively for the current provider + path. Download/upload
 * delegate to the contract.
 *
 * Note: the CloudBrowserContractAdapter is currently a stub (returns
 * empty lists / reports failure) because real cloud providers aren't
 * wired yet. But at least the screen now has the right plumbing —
 * when the adapter is filled in with real Google Drive / Dropbox /
 * OneDrive calls, this VM will work without changes.
 */
@HiltViewModel
class CloudBrowserViewModel @Inject constructor(
    private val cloudContract: CloudBrowserContract,
    savedStateHandle: SavedStateHandle,
) : ViewModel() {

    private val providerId: String = savedStateHandle.get<String>("providerId") ?: ""
    private val path: String = savedStateHandle.get<String>("path") ?: "/"

    private val _files = MutableStateFlow<List<UiCloudFile>>(emptyList())
    val files: StateFlow<List<UiCloudFile>> = _files.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    init {
        loadFiles()
    }

    fun loadFiles() {
        viewModelScope.launch {
            try {
                cloudContract.observeFiles(providerId, path)
                    .collectLatest { files ->
                        _files.value = files
                    }
            } catch (e: Exception) {
                _message.value = "Failed to load: ${e.message}"
            }
        }
    }

    fun downloadFile(file: UiCloudFile) {
        viewModelScope.launch {
            cloudContract.downloadFile(
                providerId,
                file,
                object : CloudTransferCallback {
                    override fun onProgress(bytesTransferred: Long, totalBytes: Long) {
                        // Could expose as a progress StateFlow — skip for now
                    }

                    override fun onComplete(success: Boolean, error: String?) {
                        _message.value = if (success) "Downloaded: ${file.name}"
                        else "Download failed: ${error ?: "unknown"}"
                    }
                },
            )
        }
    }

    fun uploadFile(localPath: String, remotePath: String) {
        viewModelScope.launch {
            cloudContract.uploadFile(
                providerId,
                localPath,
                remotePath,
                object : CloudTransferCallback {
                    override fun onProgress(bytesTransferred: Long, totalBytes: Long) {}

                    override fun onComplete(success: Boolean, error: String?) {
                        _message.value = if (success) "Uploaded: $remotePath"
                        else "Upload failed: ${error ?: "unknown"}"
                        if (success) loadFiles()
                    }
                },
            )
        }
    }

    fun clearMessage() {
        _message.value = null
    }

    /** Called by the UI when the Upload button is tapped but the SAF
     *  picker isn't wired yet. Sets a message that the snackbar
     *  LaunchedEffect will pick up. */
    fun showUploadPickerMessage() {
        _message.value = "Upload: file picker not yet wired"
    }
}

package com.titan.filemanager.error

import android.app.ActivityManager
import android.app.Application
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.compose.runtime.Immutable
import com.titan.filemanager.core.common.logger.Logger
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * ## GlobalErrorHandler
 *
 * The single, authoritative handler for ALL uncaught exceptions and errors
 * in the TitanFileManager app. Installed as the default uncaught-exception
 * handler on every thread, plus an ANR watchdog, plus an OOM pre-detector.
 *
 * ### Installation
 * In [TitanApplication.onCreate]:
 * ```kotlin
 * globalErrorHandler.install()
 * ```
 *
 * This wires three things:
 *  1. `Thread.setDefaultUncaughtExceptionHandler` — catches exceptions that
 *     propagate to the top of any thread.
 *  2. ANR Watchdog — polls the main thread every 5s; if it doesn't respond
 *     within 5s, an ANR report is generated.
 *  3. OOM Pre-detector — polls free heap every 30s; if free heap < 5% of
 *     total, a warning is logged and a low-memory event is emitted.
 *
 * ### Crash flow
 * When an uncaught exception fires:
 *
 * ```
 * Thread throws exception
 *     ↓
 * GlobalExceptionHandler.uncaughtException()
 *     ↓
 * Build CrashReport (with thread info + device info + memory snapshot)
 *     ↓
 * CrashReporter.report()  ← writes to local file + remote backend
 *     ↓
 * errorBus.emit(CrashReport)  ← UI shows error dialog if app still alive
 *     ↓
 * Delegate to original handler (Android's default → kill process)
 * ```
 *
 * ### ANR detection
 * ANR (Application Not Responding) happens when the main thread is blocked
 * for >5s. The system shows a dialog and may kill the app. Our watchdog
 * detects ANRs before the system does and logs a stack trace to help
 * diagnose the issue.
 *
 * ### OOM pre-detection
 * Instead of waiting for `OutOfMemoryError` (which crashes the app), the
 * pre-detector warns when free heap drops below 5% — giving us a chance to
 * release caches and avoid the crash. The warning is emitted on
 * [lowMemoryEvents] which the UI observes to clear thumbnail caches.
 *
 * ### Custom crash handlers
 * Feature modules can register custom handlers for specific exception types:
 * ```kotlin
 * globalErrorHandler.registerHandler(IOException::class) { report ->
 *     // Feature-specific handling
 * }
 * ```
 */
@Singleton
class GlobalErrorHandler @Inject constructor(
    @ApplicationContext private val context: Context,
    private val crashReporter: CrashReporter,
    private val logger: Logger,
) {

    /** Whether [install] has been called. */
    @Volatile private var isInstalled = false

    /** The original uncaught-exception handler, restored on [uninstall]. */
    private var previousHandler: Thread.UncaughtExceptionHandler? = null

    /** Background scope for crash report writing. */
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /** ANR watchdog job. */
    private var anrWatchdogJob: Job? = null

    /** OOM pre-detector job. */
    private var oomDetectorJob: Job? = null

    /** Main-thread heartbeat — bumped by [anrHeartbeatRunnable]. */
    @Volatile private var mainThreadHeartbeat: Long = 0L

    /** Last time the heartbeat was checked. */
    @Volatile private var lastHeartbeatCheck: Long = 0L

    /** Whether the app is in foreground (set by Activity lifecycle callbacks). */
    @Volatile private var isForeground: Boolean = false

    /** Mutex to serialize crash report submission. */
    private val reportMutex = Mutex()

    /** Custom exception-type-specific handlers. */
    private val customHandlers = mutableMapOf<Class<out Throwable>, (CrashReport) -> Unit>()

    /**
     * Hot flow of crash reports — UI observes this to show error dialogs.
     */
    private val _errorBus = MutableSharedFlow<CrashReport>(
        replay = 0,
        extraBufferCapacity = 16,
    )
    val errorBus: SharedFlow<CrashReport> = _errorBus.asSharedFlow()

    /**
     * Hot flow of ANR events — UI observes this to show "App not responding" dialog.
     */
    private val _anrBus = MutableSharedFlow<AnrEvent>(
        replay = 0,
        extraBufferCapacity = 4,
    )
    val anrBus: SharedFlow<AnrEvent> = _anrBus.asSharedFlow()

    /**
     * Hot flow of low-memory warnings — UI observes this to clear caches.
     */
    private val _lowMemoryBus = MutableSharedFlow<LowMemoryEvent>(
        replay = 0,
        extraBufferCapacity = 4,
    )
    val lowMemoryEvents: SharedFlow<LowMemoryEvent> = _lowMemoryBus.asSharedFlow()

    /**
     * Install the global error handler. Called once from [TitanApplication.onCreate].
     *
     * After installation, ALL uncaught exceptions on ANY thread will route
     * through [handleUncaughtException]. The original handler is preserved
     * and called after our handling, so the process still terminates as
     * expected.
     */
    fun install(appVersionName: String, appVersionCode: Long, buildType: String) {
        if (isInstalled) {
            logger.w { "install() called twice — ignoring" }
            return
        }
        isInstalled = true

        this.appVersionName = appVersionName
        this.appVersionCode = appVersionCode
        this.buildType = buildType
        this.processName = getCurrentProcessName(context)

        // 1. Install uncaught-exception handler
        previousHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler(::handleUncaughtException)

        // 2. Start ANR watchdog
        startAnrWatchdog()

        // 3. Start OOM pre-detector
        startOomDetector()

        logger.i { "GlobalErrorHandler installed (process=$processName, pid=${android.os.Process.myPid()})" }
    }

    /**
     * Restore the original uncaught-exception handler. Used in tests.
     */
    fun uninstall() {
        if (!isInstalled) return
        isInstalled = false
        Thread.setDefaultUncaughtExceptionHandler(previousHandler)
        anrWatchdogJob?.cancel()
        oomDetectorJob?.cancel()
        scope.cancel()
        logger.i { "GlobalErrorHandler uninstalled" }
    }

    /**
     * Set whether the app is currently in the foreground. Used by ANR
     * detector — ANRs only matter when the app is foregrounded.
     */
    fun setForeground(isForeground: Boolean) {
        this.isForeground = isForeground
    }

    /**
     * Register a custom handler for a specific exception type. The handler
     * is called BEFORE [CrashReporter.report], giving feature modules a
     * chance to add custom metadata or skip reporting.
     */
    fun <T : Throwable> registerHandler(
        exceptionClass: Class<T>,
        handler: (CrashReport) -> Unit,
    ) {
        customHandlers[exceptionClass] = handler
    }

    /**
     * Manually report a non-fatal exception. Useful for try-catch blocks
     * that want to log exceptions without rethrowing.
     *
     * Example:
     * ```kotlin
     * try {
     *     riskyOperation()
     * } catch (e: IOException) {
     *     globalErrorHandler.reportNonFatal(e, customData = mapOf("path" to filePath))
     * }
     * ```
     */
    suspend fun reportNonFatal(
        throwable: Throwable,
        thread: Thread = Thread.currentThread(),
        customData: Map<String, String> = emptyMap(),
    ) {
        val report = CrashReport.capture(
            thread = thread,
            throwable = throwable,
            isFatal = false,
            appVersionName = appVersionName,
            appVersionCode = appVersionCode,
            buildType = buildType,
            processName = processName,
            customData = customData,
        )
        submitReport(report)
    }

    /**
     * Add custom metadata to the next crash report. Useful for tracking
     * "last user action" so crash reports have context.
     *
     * Example:
     * ```kotlin
     * globalErrorHandler.setCustomData("last_screen", "BrowserScreen")
     * globalErrorHandler.setCustomData("last_action", "delete_file")
     * ```
     */
    fun setCustomData(key: String, value: String) {
        customMetadata[key] = value
    }

    fun clearCustomData(key: String) {
        customMetadata.remove(key)
    }

    // ═══════════════════════════════════════════════════════════════
    // INTERNAL STATE
    // ═══════════════════════════════════════════════════════════════

    @Volatile private var appVersionName: String = "unknown"
    @Volatile private var appVersionCode: Long = 0L
    @Volatile private var buildType: String = "debug"
    @Volatile private var processName: String = "unknown"

    private val customMetadata = mutableMapOf<String, String>()

    // ═══════════════════════════════════════════════════════════════
    // UNCAUGHT EXCEPTION HANDLER
    // ═══════════════════════════════════════════════════════════════

    /**
     * Called by the JVM when an exception reaches the top of any thread
     * without being caught.
     *
     * This MUST NOT throw — we're the last line of defense before the
     * process dies.
     */
    private fun handleUncaughtException(thread: Thread, throwable: Throwable) {
        logger.e(throwable) { "Uncaught exception on thread ${thread.name}" }

        val report = CrashReport.capture(
            thread = thread,
            throwable = throwable,
            isFatal = true,
            appVersionName = appVersionName,
            appVersionCode = appVersionCode,
            buildType = buildType,
            processName = processName,
            customData = customMetadata.toMap(),
        )

        // Run custom handlers (best-effort)
        runCatching {
            customHandlers[throwable.javaClass]?.invoke(report)
        }.onFailure { e ->
            logger.e(e) { "Custom handler failed" }
        }

        // Submit report (blocking — we're about to die anyway)
        runBlocking {
            submitReport(report)
            crashReporter.flush()
        }

        // Emit to UI (if process still alive)
        runCatching {
            _errorBus.tryEmit(report)
        }

        // Delegate to original handler (Android's default will kill the process)
        previousHandler?.uncaughtException(thread, throwable)
    }

    /**
     * Submit a crash report to the [CrashReporter]. Serialized via [reportMutex]
     * to avoid interleaving if multiple threads crash simultaneously.
     */
    private suspend fun submitReport(report: CrashReport) {
        reportMutex.withLock {
            runCatching {
                crashReporter.report(report)
            }.onFailure { e ->
                logger.e(e) { "CrashReporter.report() failed" }
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // ANR WATCHDOG
    // ═══════════════════════════════════════════════════════════════

    /**
     * Start the ANR watchdog. The watchdog:
     *  1. Posts a heartbeat runnable to the main thread every 5s.
     *  2. Checks 5s later whether the heartbeat was processed.
     *  3. If not, the main thread is blocked → emit an ANR event.
     *
     * The watchdog only triggers when the app is in the foreground —
     * background ANRs are the system's responsibility.
     */
    private fun startAnrWatchdog() {
        anrWatchdogJob = scope.launch {
            while (true) {
                delay(ANR_POLL_INTERVAL_MS)

                if (!isForeground) continue

                // Post heartbeat to main thread
                mainThreadHeartbeat = 0L
                lastHeartbeatCheck = SystemClock.elapsedRealtime()

                Handler(Looper.getMainLooper()).post {
                    mainThreadHeartbeat = SystemClock.elapsedRealtime()
                }

                // Wait for heartbeat (with timeout)
                delay(ANR_THRESHOLD_MS)

                val heartbeatDelta = mainThreadHeartbeat - lastHeartbeatCheck
                if (heartbeatDelta <= 0 && isForeground) {
                    // Main thread is blocked — emit ANR
                    val stackTrace = captureMainThreadStackTrace()
                    val event = AnrEvent(
                        timestampMs = System.currentTimeMillis(),
                        blockedDurationMs = ANR_THRESHOLD_MS,
                        mainThreadStackTrace = stackTrace,
                    )
                    logger.e { "ANR detected: main thread blocked > ${ANR_THRESHOLD_MS}ms\n$stackTrace" }
                    _anrBus.tryEmit(event)

                    // Also write to crash reporter as a non-fatal issue
                    val report = CrashReport.capture(
                        thread = Looper.getMainLooper().thread,
                        throwable = AnrException(stackTrace),
                        isFatal = false,
                        appVersionName = appVersionName,
                        appVersionCode = appVersionCode,
                        buildType = buildType,
                        processName = processName,
                        customData = mapOf("anr_blocked_ms" to ANR_THRESHOLD_MS.toString()),
                    )
                    submitReport(report)
                }
            }
        }
    }

    /**
     * Capture the main thread's stack trace. Uses `Thread.getStackTrace()`
     * which returns an array of `StackTraceElement` — one per frame on the
     * call stack.
     */
    private fun captureMainThreadStackTrace(): String {
        val mainThread = Looper.getMainLooper().thread
        val elements = mainThread.stackTrace
        return buildString {
            appendLine("\"${mainThread.name}\" (pid=${android.os.Process.myPid()}, tid=${mainThread.id})")
            appendLine("   java.lang.Thread.State: ${mainThread.state}")
            elements.take(50).forEach { element ->
                appendLine("   at $element")
            }
            if (elements.size > 50) {
                appendLine("   ... ${elements.size - 50} more frames")
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // OOM PRE-DETECTOR
    // ═══════════════════════════════════════════════════════════════

    /**
     * Start the OOM pre-detector. Every 30s, checks free heap as a fraction
     * of total heap. If free < 5% of total, emits a [LowMemoryEvent] so the
     * UI can release caches.
     */
    private fun startOomDetector() {
        oomDetectorJob = scope.launch {
            while (true) {
                delay(OOM_POLL_INTERVAL_MS)

                val runtime = Runtime.getRuntime()
                val free = runtime.freeMemory()
                val total = runtime.totalMemory()
                val max = runtime.maxMemory()

                val freeFraction = if (max > 0) free.toFloat() / max else 0f

                if (freeFraction < OOM_WARNING_THRESHOLD) {
                    val event = LowMemoryEvent(
                        timestampMs = System.currentTimeMillis(),
                        freeHeapBytes = free,
                        totalHeapBytes = total,
                        maxHeapBytes = max,
                        freeFraction = freeFraction,
                    )
                    logger.w { "Low memory: ${freeFraction * 100}% free (${formatBytes(free)} / ${formatBytes(max)})" }
                    _lowMemoryBus.tryEmit(event)
                }
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // HELPERS
    // ═══════════════════════════════════════════════════════════════

    private fun getCurrentProcessName(context: Context): String {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            return Application.getProcessName()
        }
        // Fallback for API < 28
        val pid = android.os.Process.myPid()
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        return am?.runningAppProcesses?.firstOrNull { it.pid == pid }?.processName
            ?: context.packageName
    }

    private fun formatBytes(bytes: Long): String = when {
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
        bytes < 1024 * 1024 * 1024 -> "%.1f MB".format(bytes / (1024.0 * 1024))
        else -> "%.2f GB".format(bytes / (1024.0 * 1024 * 1024))
    }

    companion object {
        private const val TAG = "GlobalErrorHandler"

        /** Poll interval for ANR watchdog (5s). */
        private const val ANR_POLL_INTERVAL_MS = 5_000L

        /** ANR threshold — main thread blocked for this long triggers an ANR (5s). */
        private const val ANR_THRESHOLD_MS = 5_000L

        /** Poll interval for OOM detector (30s). */
        private const val OOM_POLL_INTERVAL_MS = 30_000L

        /** Free heap fraction below which we emit a low-memory warning (5%). */
        private const val OOM_WARNING_THRESHOLD = 0.05f
    }
}

// ═══════════════════════════════════════════════════════════════
// EVENT TYPES
// ═══════════════════════════════════════════════════════════════

/**
 * ANR event — emitted when the main thread is blocked for >5s.
 */
@Immutable
data class AnrEvent(
    val timestampMs: Long,
    val blockedDurationMs: Long,
    val mainThreadStackTrace: String,
)

/**
 * Low-memory event — emitted when free heap drops below 5%.
 */
@Immutable
data class LowMemoryEvent(
    val timestampMs: Long,
    val freeHeapBytes: Long,
    val totalHeapBytes: Long,
    val maxHeapBytes: Long,
    val freeFraction: Float,
)

/**
 * Internal exception type used to wrap ANR stack traces for [CrashReporter].
 * Not a real exception — just a vehicle for the stack trace string.
 */
private class AnrException(val stackTraceString: String) : Throwable("ANR detected: main thread blocked") {
    override fun fillInStackTrace(): Throwable = this
    init {
        // Set the stack trace to a single-frame trace containing our message
        stackTrace = arrayOf(StackTraceElement("ANRWatchdog", "monitor", "GlobalErrorHandler.kt", 0))
    }
}

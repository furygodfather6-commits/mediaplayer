package com.titan.filemanager.ui.screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.domain.scan.DirectoryScanRepository
import com.titan.filemanager.core.model.file.SortDescriptor
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * ViewModel for the Automotive Browser screen.
 *
 * Previously the AutomotiveBrowserScreen was wired with
 * `files = emptyList()` — the screen always showed "no files".
 *
 * This VM scans the start path (default: /sdcard) and exposes the
 * file list reactively. Used by the Android Auto companion.
 */
@HiltViewModel
class AutomotiveBrowserViewModel @Inject constructor(
    private val scanRepository: DirectoryScanRepository,
) : ViewModel() {

    private val _files = MutableStateFlow<List<FileItem>>(emptyList())
    val files: StateFlow<List<FileItem>> = _files.asStateFlow()

    private val _currentPath = MutableStateFlow("")
    val currentPath: StateFlow<String> = _currentPath.asStateFlow()

    fun loadPath(path: String) {
        _currentPath.value = path
        viewModelScope.launch {
            val result = scanRepository.scanDirectory(
                path = path,
                sort = SortDescriptor(),
                showHidden = false,
            )
            // scanDirectory returns Result<ScanResult>
            when (result) {
                is com.titan.filemanager.core.common.result.Result.Success -> {
                    _files.value = result.data.items
                }
                else -> {
                    _files.value = emptyList()
                }
            }
        }
    }
}

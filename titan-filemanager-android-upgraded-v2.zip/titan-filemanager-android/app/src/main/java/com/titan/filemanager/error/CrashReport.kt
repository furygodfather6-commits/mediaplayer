package com.titan.filemanager.error

import android.os.Build
import android.os.Process
import android.os.StatFs
import android.os.Environment
import androidx.compose.runtime.Immutable
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * ## CrashReport
 *
 * Immutable data class representing a single crash report captured by
 * [GlobalErrorHandler]. The report contains enough information for the
 * crash-reporting backend (or local log file) to diagnose the crash
 * without requiring live access to the device.
 *
 * ### Captured data
 *  - **Exception** — class name + message + full stack trace
 *  - **Thread** — name + priority + ID of the crashing thread
 *  - **Device** — manufacturer, model, Android version, SDK level, ABI
 *  - **App** — version name + code + build date + build type
 *  - **Memory** — free/total heap + native heap + storage free/total
 *  - **Process** — PID, TID, process name
 *  - **Timestamp** — when the crash occurred (epoch ms + formatted)
 *  - **IsFatal** — whether the crash is fatal (will kill the process)
 *
 * ### Privacy
 * The report does NOT include:
 *  - File paths from user storage
 *  - Vault contents or encryption keys
 *  - Cloud OAuth tokens
 *  - User names or email addresses
 *  - Contact list or call log
 *
 * ### Serialization
 * The `toPlainText()` method produces a human-readable string suitable
 * for writing to a log file or displaying to the user. The companion
 * `fromJson()` method supports deserialization from a crash backend
 * JSON response (e.g., Firebase Crashlytics, Sentry).
 */
@Immutable
data class CrashReport(
    /** Fully-qualified exception class name (e.g., `java.lang.NullPointerException`). */
    val exceptionClass: String,
    /** Exception message (may be empty if the exception has no message). */
    val exceptionMessage: String,
    /** Full stack trace as a single string, with newlines preserved. */
    val stackTrace: String,
    /** Name of the thread that crashed (e.g., `main`, `DefaultDispatcher-worker-1`). */
    val threadName: String,
    /** Thread priority (1-10). */
    val threadPriority: Int,
    /** Thread ID (kernel TID). */
    val threadId: Long,
    /** Whether the crash is fatal — true for uncaught exceptions, false for caught ones. */
    val isFatal: Boolean,
    /** Crash timestamp in epoch milliseconds. */
    val timestampMs: Long,
    /** Device manufacturer (e.g., `Google`, `Samsung`). */
    val deviceManufacturer: String,
    /** Device model (e.g., `Pixel 8 Pro`). */
    val deviceModel: String,
    /** Android release version (e.g., `14`). */
    val androidVersion: String,
    /** Android SDK level (e.g., `34`). */
    val sdkLevel: Int,
    /** Primary ABI (e.g., `arm64-v8a`). */
    val abi: String,
    /** App version name (e.g., `2.0.0`). */
    val appVersionName: String,
    /** App version code (e.g., `180`). */
    val appVersionCode: Long,
    /** Build type (`debug` or `release`). */
    val buildType: String,
    /** Process ID. */
    val processId: Int,
    /** Process name (typically the package name). */
    val processName: String,
    /** Free heap memory in bytes. */
    val freeHeapBytes: Long,
    /** Total heap memory in bytes. */
    val totalHeapBytes: Long,
    /** Native heap free memory in bytes. */
    val nativeFreeBytes: Long,
    /** Storage free bytes (external storage). */
    val storageFreeBytes: Long,
    /** Storage total bytes (external storage). */
    val storageTotalBytes: Long,
    /** Optional custom metadata (e.g., last screen, user action). */
    val customData: Map<String, String> = emptyMap(),
) {

    /**
     * Convert the crash report to a human-readable plain-text format.
     *
     * Used by:
     *  - [CrashReportWriter] to write to the crash log file
     *  - [ErrorReportDialog] to display to the user (if they tap "View details")
     *  - Crash-sharing intents (email, GitHub issue, etc.)
     */
    fun toPlainText(): String = buildString {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US)
        appendLine("═══════════════════════════════════════════════════════════════")
        appendLine("TitanFileManager Crash Report")
        appendLine("═══════════════════════════════════════════════════════════════")
        appendLine()
        appendLine("─ Crash ──────────────────────────────────────────────────────")
        appendLine("Timestamp: ${dateFormat.format(Date(timestampMs))} (epoch: $timestampMs)")
        appendLine("Severity:  ${if (isFatal) "FATAL" else "NON-FATAL"}")
        appendLine("Exception: $exceptionClass")
        appendLine("Message:   $exceptionMessage")
        appendLine("Thread:    $threadName (priority=$threadPriority, tid=$threadId)")
        appendLine()
        appendLine("─ Stack Trace ────────────────────────────────────────────────")
        appendLine(stackTrace)
        appendLine()
        appendLine("─ Device ─────────────────────────────────────────────────────")
        appendLine("Manufacturer: $deviceManufacturer")
        appendLine("Model:        $deviceModel")
        appendLine("Android:      $androidVersion (SDK $sdkLevel)")
        appendLine("ABI:          $abi")
        appendLine()
        appendLine("─ App ────────────────────────────────────────────────────────")
        appendLine("Version:      $appVersionName ($appVersionCode)")
        appendLine("Build type:   $buildType")
        appendLine("Process:      $processName (pid=$processId)")
        appendLine()
        appendLine("─ Memory ─────────────────────────────────────────────────────")
        appendLine("Heap:     ${formatBytes(freeHeapBytes)} free of ${formatBytes(totalHeapBytes)}")
        appendLine("Native:   ${formatBytes(nativeFreeBytes)} free")
        appendLine("Storage:  ${formatBytes(storageFreeBytes)} free of ${formatBytes(storageTotalBytes)}")
        appendLine()
        if (customData.isNotEmpty()) {
            appendLine("─ Custom Data ────────────────────────────────────────────────")
            customData.forEach { (k, v) -> appendLine("$k: $v") }
            appendLine()
        }
        appendLine("═══════════════════════════════════════════════════════════════")
    }

    /**
     * A short one-line summary suitable for notification titles or list items.
     * Example: `FATAL NullPointerException on main thread — 2026-07-04 12:34:56`
     */
    fun summary(): String {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        val severity = if (isFatal) "FATAL" else "NON-FATAL"
        val shortException = exceptionClass.substringAfterLast('.')
        return "$severity $shortException on $threadName — ${dateFormat.format(Date(timestampMs))}"
    }

    companion object {

        /**
         * Capture a [CrashReport] from the given [thread] and [throwable].
         *
         * Called by [GlobalErrorHandler] when an uncaught exception reaches
         * the top of any thread, or by try-catch blocks that want to log
         * non-fatal exceptions.
         *
         * @param thread the thread that threw the exception.
         * @param throwable the exception (or error) that was thrown.
         * @param isFatal whether the exception is fatal (will kill the process).
         * @param appVersionName app version name (passed in to avoid coupling).
         * @param appVersionCode app version code.
         * @param buildType build type string ("debug" / "release").
         * @param processName process name (typically the package name).
         * @param customData optional metadata to include in the report.
         */
        @Suppress("DEPRECATION")
        fun capture(
            thread: Thread,
            throwable: Throwable,
            isFatal: Boolean,
            appVersionName: String,
            appVersionCode: Long,
            buildType: String,
            processName: String,
            customData: Map<String, String> = emptyMap(),
        ): CrashReport {
            val sw = StringWriter()
            throwable.printStackTrace(PrintWriter(sw))

            val runtime = Runtime.getRuntime()
            var storageFree: Long = -1L
            var storageTotal: Long = -1L
            try {
                val stat = StatFs(Environment.getExternalStorageDirectory().absolutePath)
                storageFree = stat.availableBlocksLong * stat.blockSizeLong
                storageTotal = stat.blockCountLong * stat.blockSizeLong
            } catch (_: Throwable) {
                storageFree = -1L
                storageTotal = -1L
            }

            return CrashReport(
                exceptionClass = throwable.javaClass.name,
                exceptionMessage = throwable.message ?: "",
                stackTrace = sw.toString().trim(),
                threadName = thread.name,
                threadPriority = thread.priority,
                threadId = thread.id,
                isFatal = isFatal,
                timestampMs = System.currentTimeMillis(),
                deviceManufacturer = Build.MANUFACTURER ?: "unknown",
                deviceModel = Build.MODEL ?: "unknown",
                androidVersion = Build.VERSION.RELEASE ?: "unknown",
                sdkLevel = Build.VERSION.SDK_INT,
                abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown",
                appVersionName = appVersionName,
                appVersionCode = appVersionCode,
                buildType = buildType,
                processId = Process.myPid(),
                processName = processName,
                freeHeapBytes = runtime.freeMemory(),
                totalHeapBytes = runtime.totalMemory(),
                nativeFreeBytes = Debug.getNativeHeapFreeSize(),
                storageFreeBytes = storageFree,
                storageTotalBytes = storageTotal,
                customData = customData,
            )
        }

        private fun formatBytes(bytes: Long): String = when {
            bytes < 0 -> "unknown"
            bytes < 1024 -> "$bytes B"
            bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
            bytes < 1024 * 1024 * 1024 -> "%.1f MB".format(bytes / (1024.0 * 1024))
            else -> "%.2f GB".format(bytes / (1024.0 * 1024 * 1024))
        }

        /**
         * Deserialize a [CrashReport] from a JSON string.
         *
         * Supports JSON format from:
         *  - Firebase Crashlytics REST API
         *  - Sentry event API
         *  - Custom crash backend
         *
         * Expected JSON structure:
         * ```json
         * {
         *   "exceptionClass": "java.lang.NullPointerException",
         *   "exceptionMessage": "value was null",
         *   "stackTrace": "...",
         *   "threadName": "main",
         *   "threadPriority": 5,
         *   "threadId": 1,
         *   "isFatal": true,
         *   "timestampMs": 1720000000000,
         *   "deviceManufacturer": "Google",
         *   "deviceModel": "Pixel 8",
         *   "androidVersion": "14",
         *   "sdkLevel": 34,
         *   "abi": "arm64-v8a",
         *   "appVersionName": "2.0.0",
         *   "appVersionCode": 180,
         *   "buildType": "release",
         *   "processId": 12345,
         *   "processName": "com.titan.filemanager",
         *   "freeHeapBytes": 50000000,
         *   "totalHeapBytes": 256000000,
         *   "nativeFreeBytes": 100000000,
         *   "storageFreeBytes": 50000000000,
         *   "storageTotalBytes": 128000000000,
         *   "customData": {"key": "value"}
         * }
         * ```
         *
         * @param json JSON string from crash backend.
         * @return parsed [CrashReport], or null if parsing fails.
         */
        fun fromJson(json: String): CrashReport? {
            return try {
                val root = org.json.JSONObject(json)
                val customDataObj = root.optJSONObject("customData")
                val customData = mutableMapOf<String, String>()
                if (customDataObj != null) {
                    val keys = customDataObj.keys()
                    while (keys.hasNext()) {
                        val key = keys.next()
                        customData[key] = customDataObj.getString(key)
                    }
                }
                CrashReport(
                    exceptionClass = root.optString("exceptionClass", "Unknown"),
                    exceptionMessage = root.optString("exceptionMessage", ""),
                    stackTrace = root.optString("stackTrace", ""),
                    threadName = root.optString("threadName", "unknown"),
                    threadPriority = root.optInt("threadPriority", 5),
                    threadId = root.optLong("threadId", -1L),
                    isFatal = root.optBoolean("isFatal", false),
                    timestampMs = root.optLong("timestampMs", 0L),
                    deviceManufacturer = root.optString("deviceManufacturer", "unknown"),
                    deviceModel = root.optString("deviceModel", "unknown"),
                    androidVersion = root.optString("androidVersion", "unknown"),
                    sdkLevel = root.optInt("sdkLevel", 0),
                    abi = root.optString("abi", "unknown"),
                    appVersionName = root.optString("appVersionName", "unknown"),
                    appVersionCode = root.optLong("appVersionCode", 0L),
                    buildType = root.optString("buildType", "unknown"),
                    processId = root.optInt("processId", -1),
                    processName = root.optString("processName", "unknown"),
                    freeHeapBytes = root.optLong("freeHeapBytes", -1L),
                    totalHeapBytes = root.optLong("totalHeapBytes", -1L),
                    nativeFreeBytes = root.optLong("nativeFreeBytes", -1L),
                    storageFreeBytes = root.optLong("storageFreeBytes", -1L),
                    storageTotalBytes = root.optLong("storageTotalBytes", -1L),
                    customData = customData,
                )
            } catch (_: Throwable) {
                null
            }
        }

        /**
         * Serialize a [CrashReport] to JSON string.
         * Inverse of [fromJson].
         */
        fun toJson(report: CrashReport): String {
            val root = org.json.JSONObject()
            root.put("exceptionClass", report.exceptionClass)
            root.put("exceptionMessage", report.exceptionMessage)
            root.put("stackTrace", report.stackTrace)
            root.put("threadName", report.threadName)
            root.put("threadPriority", report.threadPriority)
            root.put("threadId", report.threadId)
            root.put("isFatal", report.isFatal)
            root.put("timestampMs", report.timestampMs)
            root.put("deviceManufacturer", report.deviceManufacturer)
            root.put("deviceModel", report.deviceModel)
            root.put("androidVersion", report.androidVersion)
            root.put("sdkLevel", report.sdkLevel)
            root.put("abi", report.abi)
            root.put("appVersionName", report.appVersionName)
            root.put("appVersionCode", report.appVersionCode)
            root.put("buildType", report.buildType)
            root.put("processId", report.processId)
            root.put("processName", report.processName)
            root.put("freeHeapBytes", report.freeHeapBytes)
            root.put("totalHeapBytes", report.totalHeapBytes)
            root.put("nativeFreeBytes", report.nativeFreeBytes)
            root.put("storageFreeBytes", report.storageFreeBytes)
            root.put("storageTotalBytes", report.storageTotalBytes)
            if (report.customData.isNotEmpty()) {
                val customDataObj = org.json.JSONObject()
                report.customData.forEach { (k, v) -> customDataObj.put(k, v) }
                root.put("customData", customDataObj)
            }
            return root.toString()
        }
    }
}

/**
 * Bridge to `android.os.Debug` for native heap size. Wrapped in an object
 * to keep the import explicit and allow easy mocking in tests.
 */
private object Debug {
    fun getNativeHeapFreeSize(): Long = try {
        android.os.Debug.getNativeHeapFreeSize().toLong()
    } catch (_: Throwable) {
        -1L
    }
}

package com.titan.filemanager.imaging

import android.app.Application
import android.content.Context
import android.graphics.drawable.Drawable
import android.os.Build
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache
import coil.request.CachePolicy
import coil.request.ImageRequest
import coil.request.ImageResult
import coil.util.Logger as CoilLogger
import com.titan.filemanager.core.common.logger.Logger
import dagger.hilt.android.qualifiers.ApplicationContext
import timber.log.Timber
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * ## TitanImageLoaderFactory
 *
 * Custom Coil [ImageLoader] factory that configures the image pipeline
 * for TitanFileManager's specific needs:
 *
 *  - **Large memory cache** — 25% of available app memory (default is 15%)
 *  - **Large disk cache** — 250 MB for thumbnails (default is 250 MB, OK)
 *  - **Crossfade transitions** — 200ms fade-in for smooth UX
 *  - **Hardware bitmaps** — enabled on API 28+ for lower memory usage
 *  - **Custom decoders** — video frame thumbnails, PDF page previews
 *  - **Custom keyer** — uses file path + mtime as cache key (so changed
 *    files get re-decoded even if the path stays the same)
 *
 * ### Registration
 * In [TitanApplication], implement [ImageLoaderFactory]:
 * ```kotlin
 * class TitanApplication : Application(), ImageLoaderFactory {
 *     override fun newImageLoader(): ImageLoader =
 *         titanImageLoaderFactory.create()
 * }
 * ```
 *
 * ### Thumbnail pipeline
 * When a list/grid cell requests a thumbnail for `/sdcard/photo.jpg`:
 *
 * ```
 * AsyncImage(model = "/sdcard/photo.jpg")
 *     ↓
 * ImageLoader.load() → check memory cache
 *     ↓ (miss)
 * FileFetcher() → open file, read first bytes
 *     ↓
 * BitmapDecoder() → decode bitmap at target size
 *     ↓
 * Memory cache put + Disk cache put
 *     ↓
 * AsyncImage renders bitmap
 * ```
 *
 * ### Video thumbnails
 * Video files use [VideoFrameFetcher] which uses MediaMetadataRetriever
 * to extract a frame at 1s offset. The result is cached just like images.
 *
 * ### PDF thumbnails
 * PDF files use [PdfPageFetcher] which uses PdfRenderer to render page 0
 * at the target size.
 *
 * ### Memory pressure
 * The ImageLoader observes [ComponentCallbacks2.onTrimMemory] and clears
 * the memory cache on TRIM_MEMORY_MODERATE+ levels.
 */
@Singleton
class TitanImageLoaderFactory @Inject constructor(
    @ApplicationContext private val context: Context,
    private val logger: Logger,
) {

    /**
     * Create the configured [ImageLoader] instance.
     *
     * Called once per process — the resulting ImageLoader is a process-wide
     * singleton accessible via `coil.imageLoader(context)`.
     */
    fun create(): ImageLoader {
        logger.i { "Creating TitanImageLoader (memCache=${memoryCacheSizeBytes() / 1024 / 1024}MB, diskCache=${DISK_CACHE_SIZE_BYTES / 1024 / 1024}MB)" }

        return ImageLoader.Builder(context)
            // ── Memory cache ──────────────────────────────────────────
            .memoryCache {
                MemoryCache.Builder(context)
                    .maxSizeBytes(memoryCacheSizeBytes())
                    .build()
            }
            .memoryCachePolicy(CachePolicy.ENABLED)

            // ── Disk cache ────────────────────────────────────────────
            .diskCache {
                DiskCache.Builder()
                    .directory(File(context.cacheDir, "image_cache"))
                    .maxSizeBytes(DISK_CACHE_SIZE_BYTES)
                    .build()
            }
            .diskCachePolicy(CachePolicy.ENABLED)

            // ── Crossfade ─────────────────────────────────────────────
            .crossfade(CROSSFADE_DURATION_MS)

            // ── Hardware bitmaps (API 28+ — lower memory, faster rendering) ──
            .allowHardware(Build.VERSION.SDK_INT >= Build.VERSION_CODES.P)
            .allowRgb565(true) // For low-RAM devices

            // ── Custom components (registered below) ───────────────────
            .components {
                // Video frame fetcher
                add(VideoFrameFetcher.Factory())
                // PDF page fetcher
                add(PdfPageFetcher.Factory())
                // SVG decoder
                add(coil.decode.SvgDecoder.Factory())
                // GIF decoder
                add(coil.decode.GifDecoder.Factory())
                // Custom file-based keyer (uses path + mtime)
                add(TitanFileKeyer())
            }

            // ── Custom error drawable ─────────────────────────────────
            .error(android.R.drawable.ic_menu_report_image)

            // ── Custom placeholder ────────────────────────────────────
            .placeholder(android.R.drawable.ic_menu_gallery)

            // ── Logger ────────────────────────────────────────────────
            .logger(TitanCoilLogger(logger))

            .build()
    }

    /**
     * Calculate the memory cache size — 25% of available app memory.
     *
     * The default Coil value is 15% of available memory, but TitanFileManager
     * is image-heavy (file thumbnails everywhere) so we bump it to 25%.
     *
     * On low-RAM devices (<2GB), we cap at 32MB to avoid OOM.
     */
    private fun memoryCacheSizeBytes(): Int {
        val maxMemory = Runtime.getRuntime().maxMemory()
        val default = (maxMemory * 0.25).toInt()

        // Cap at 32MB on low-RAM devices
        val lowRamCap = 32 * 1024 * 1024
        return if (maxMemory < 256L * 1024 * 1024) minOf(default, lowRamCap)
               else default
    }

    companion object {
        private const val TAG = "TitanImageLoader"

        /** Crossfade animation duration (ms). */
        private const val CROSSFADE_DURATION_MS = 200

        /** Disk cache size — 250 MB. */
        private const val DISK_CACHE_SIZE_BYTES = 250L * 1024 * 1024
    }
}

/**
 * ## TitanFileKeyer
 *
 * Custom Coil cache keyer that incorporates the file's last-modified time
 * into the cache key. This ensures that when a file is modified (e.g., a
 * photo is re-saved), the cache key changes and the new content is decoded
 * instead of returning a stale cached bitmap.
 *
 * Without this keyer, Coil would cache `/sdcard/photo.jpg` indefinitely
 * even if the user replaces the file with a different image at the same path.
 *
 * ### Behavior
 * - For `File` data: key = `"${file.absolutePath}#${file.lastModified()}"`
 * - For `String` data (file path string): same logic via `File(path)`
 * - For other data types: falls through to Coil's default keyer
 */
class TitanFileKeyer : coil.key.Keyer<File> {

    override fun key(data: File, options: coil.request.Options): String {
        return "${data.absolutePath}#${data.lastModified()}"
    }
}

/**
 * ## TitanCoilLogger
 *
 * Coil logger that bridges to Timber. Logs at DEBUG level so it's quiet
 * in production but visible in debug builds.
 */
private class TitanCoilLogger(
    private val logger: Logger,
) : CoilLogger {

    override var level: Int = LEVEL_INFO

    override fun log(tag: String, priority: Int, message: String?, throwable: Throwable?) {
        val timberTag = "Coil:$tag"
        when (priority) {
            LEVEL_VERBOSE, LEVEL_DEBUG -> logger.d(throwable) { message.orEmpty() }
            LEVEL_INFO -> logger.i(throwable) { message.orEmpty() }
            LEVEL_WARNING -> logger.w(throwable) { message.orEmpty() }
            LEVEL_ERROR -> logger.e(throwable) { message.orEmpty() }
            else -> logger.d(throwable) { message.orEmpty() }
        }
    }

    private companion object {
        private const val LEVEL_VERBOSE = 2
        private const val LEVEL_DEBUG = 3
        private const val LEVEL_INFO = 4
        private const val LEVEL_WARNING = 5
        private const val LEVEL_ERROR = 6
    }
}

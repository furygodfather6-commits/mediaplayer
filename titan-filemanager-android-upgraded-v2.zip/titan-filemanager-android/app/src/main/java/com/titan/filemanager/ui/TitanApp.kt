package com.titan.filemanager.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.navigation.NavDestination
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.titan.filemanager.MainActivity
import com.titan.filemanager.core.designsystem.component.NavItem
import com.titan.filemanager.core.designsystem.component.TitanNavigationBar
import com.titan.filemanager.core.navigation.NavRoutes
import com.titan.filemanager.core.navigation.TopLevelDestination
import com.titan.filemanager.core.permissions.StoragePermissionRationale
import com.titan.filemanager.core.permissions.rememberStoragePermissionState
import com.titan.filemanager.core.ui.lock.AppLockScreen
import com.titan.filemanager.core.ui.permission.TitanOnboardingScreen
import com.titan.filemanager.core.ui.splash.TitanSplashScreen
import com.titan.filemanager.navigation.TitanNavHost

/**
 * Root Composable for the entire TitanFileManager app.
 *
 * ═══════════════════════════════════════════════════════════
 * APP FLOW STATE MACHINE
 * ═══════════════════════════════════════════════════════════
 *
 * The app cycles through these phases before entering the main flow:
 *
 *   1. **SPLASH** — Animated logo (2s) → transitions to ONBOARDING or MAIN
 *   2. **ONBOARDING** — First-run only: 4-slide intro + permission request
 *   3. **PERMISSION_RATIONALE** — Full-screen rationale if storage permission
 *      was not granted during onboarding (re-prompt or open Settings)
 *   4. **APP_LOCK** — If app lock is enabled: biometric or PIN entry
 *   5. **MAIN** — Scaffold with bottom nav + TitanNavHost (all screens)
 *
 * Each phase is an [AppPhase] enum, managed by a simple state machine.
 * The state machine ensures phases are shown in order and never skipped.
 *
 * ═══════════════════════════════════════════════════════════
 * STORAGE PERMISSION
 * ═══════════════════════════════════════════════════════════
 *
 * Storage permission is requested via [rememberStoragePermissionState],
 * which picks the right strategy for the device's Android version:
 *  - API ≤ 28: READ_EXTERNAL_STORAGE (normal dialog)
 *  - API 29-32: READ_EXTERNAL_STORAGE (normal dialog, scoped storage)
 *  - API 30+: MANAGE_EXTERNAL_STORAGE (Settings deep-link)
 *  - API 33+: READ_MEDIA_* (normal dialog)
 *
 * The permission state is checked after onboarding completes and on every
 * app resume (so returning from Settings updates the UI immediately).
 *
 * ═══════════════════════════════════════════════════════════
 * BOTTOM NAVIGATION
 * ═══════════════════════════════════════════════════════════
 *
 * The bottom bar shows 5 top-level destinations (Home, Files, Search, Cloud,
 * Settings). It is hidden on boot flow screens and detail/modal screens.
 */
@Composable
fun TitanApp(
    appState: TitanAppState? = null,
) {
    // ── NavController resolution ────────────────────────────────
    //
    // CRITICAL FIX: Previously this function created its OWN
    // `rememberNavController()` even when an `appState` was passed
    // in from MainActivity. That meant:
    //
    //   - MainActivity created NC #1 + TitanAppState(NC #1)
    //   - TitanApp created NC #2 (a DIFFERENT NavController!)
    //   - TitanApp used the passed-in appState (tied to NC #1) for
    //     `currentRoute` / `shouldShowBottomBar` / navigation
    //   - But TitanNavHost was wired to NC #2
    //
    // Result: NC #1 never had any navigation happen on it (NavHost
    // was on NC #2), so `appState.currentRoute` was always null or
    // stale. The bottom bar's visibility check
    // (`shouldShowBottomBar(currentRoute)`) returned false because
    // `currentRoute` was null — so the bar NEVER showed up.
    //
    // Fix: when an `appState` is passed in, use its `navController`
    // for the NavHost so both stay in sync. Only create a new
    // NavController when no `appState` is provided (the default
    // param case).
    val resolvedAppState = appState ?: rememberTitanAppState(rememberNavController())
    val navController = resolvedAppState.navController as androidx.navigation.NavHostController

    // ═══════════════════════════════════════════════════════════
    // CONSUME STARTUP DEEP LINK (if any arrived during cold start)
    // ═══════════════════════════════════════════════════════════
    val context = androidx.compose.ui.platform.LocalContext.current
    LaunchedEffect(Unit) {
        (context as? MainActivity)?.consumeStartupDeepLink()?.let { deepLink ->
            resolvedAppState.dispatchDeepLink(deepLink)
        }
    }

    // ═══════════════════════════════════════════════════════════
    // STORAGE PERMISSION STATE
    // ═══════════════════════════════════════════════════════════
    val storagePermission = rememberStoragePermissionState()

    // Refresh permission state on every ON_RESUME so that returning from
    // the system Settings page (MANAGE_EXTERNAL_STORAGE flow) immediately
    // updates the UI without needing a manual refresh.
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                storagePermission.refresh()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // ═══════════════════════════════════════════════════════════
    // BOOT FLOW STATE MACHINE
    // ═══════════════════════════════════════════════════════════
    var appPhase by remember { mutableStateOf(AppPhase.SPLASH) }

    // Read onboarding-seen flag from a SharedPreferences file.
    // Previously this was hardcoded to `false` which meant the
    // onboarding (4-slide intro + permission prompt) replayed on
    // EVERY app launch — even if the user had already seen it and
    // granted permission. Now we persist a boolean flag in
    // SharedPreferences so onboarding only shows on genuine first
    // run. The flag is set to `true` when the user completes or
    // skips onboarding (see `onOnboardingComplete` below).
    val bootPrefs = remember {
        context.getSharedPreferences("titan_boot_state", android.content.Context.MODE_PRIVATE)
    }
    val hasSeenOnboarding by remember { mutableStateOf(bootPrefs.getBoolean(KEY_ONBOARDING_SEEN, false)) }
    val isAppLockEnabled by remember { mutableStateOf(false) }

    /** Called when onboarding completes (Get Started or Skip). Persists
     *  the flag so onboarding doesn't replay on next launch. */
    fun onOnboardingComplete() {
        bootPrefs.edit().putBoolean(KEY_ONBOARDING_SEEN, true).apply()
    }

    // Helper: where to go after onboarding completes
    fun nextPhaseAfterOnboarding(): AppPhase {
        // If storage permission is still not granted, show the full-screen
        // rationale so the user can re-request (or open Settings) before
        // entering the main app. Otherwise proceed to APP_LOCK or MAIN.
        return if (!storagePermission.isGranted) {
            AppPhase.PERMISSION_RATIONALE
        } else if (isAppLockEnabled) {
            AppPhase.APP_LOCK
        } else {
            AppPhase.MAIN
        }
    }

    when (appPhase) {
        // ─── SPLASH ───────────────────────────────────────────
        AppPhase.SPLASH -> {
            TitanSplashScreen(
                onComplete = {
                    appPhase = if (hasSeenOnboarding) {
                        if (isAppLockEnabled) AppPhase.APP_LOCK else AppPhase.MAIN
                    } else {
                        AppPhase.ONBOARDING
                    }
                },
                versionName = "2.0.0",
                versionCode = 180,
            )
        }

        // ─── ONBOARDING ───────────────────────────────────────
        AppPhase.ONBOARDING -> {
            TitanOnboardingScreen(
                onRequestStoragePermission = {
                    // Trigger the system permission dialog (or Settings page
                    // for MANAGE_EXTERNAL_STORAGE on API 30+).
                    storagePermission.request()
                },
                onComplete = {
                    // Persist the onboarding-seen flag so it doesn't
                    // replay on next launch.
                    onOnboardingComplete()
                    appPhase = nextPhaseAfterOnboarding()
                },
            )

            // If the user just granted permission while still on the onboarding
            // screen (e.g., returned from Settings and granted), auto-advance.
            LaunchedEffect(storagePermission.isGranted) {
                if (storagePermission.isGranted) {
                    onOnboardingComplete()
                    appPhase = if (isAppLockEnabled) AppPhase.APP_LOCK else AppPhase.MAIN
                }
            }
        }

        // ─── PERMISSION RATIONALE ─────────────────────────────
        AppPhase.PERMISSION_RATIONALE -> {
            StoragePermissionRationale(
                state = storagePermission,
                onRequest = { storagePermission.request() },
            )

            // Once the user grants permission (after returning from Settings),
            // advance to the next phase automatically.
            LaunchedEffect(storagePermission.isGranted) {
                if (storagePermission.isGranted) {
                    appPhase = if (isAppLockEnabled) AppPhase.APP_LOCK else AppPhase.MAIN
                }
            }

            // Allow the user to skip the rationale and proceed without granting
            // (e.g., if they want to use the app in a limited mode). Tapping the
            // system back button also exits this screen. For simplicity, we add
            // a "Skip" affordance via a TextButton overlay at the bottom.
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.BottomCenter,
            ) {
                TextButton(
                    onClick = {
                        appPhase = if (isAppLockEnabled) AppPhase.APP_LOCK else AppPhase.MAIN
                    },
                    modifier = Modifier.padding(bottom = 24.dp),
                ) {
                    Text("Skip for now")
                }
            }
        }

        // ─── APP LOCK ─────────────────────────────────────────
        AppPhase.APP_LOCK -> {
            AppLockScreen(
                onUnlock = {
                    appPhase = AppPhase.MAIN
                },
                onBiometricRequest = {
                    // In production: trigger BiometricPrompt
                    // On success → appPhase = AppPhase.MAIN
                },
                correctPin = "1234", // In production: read from encrypted DataStore
                appName = "TitanFileManager",
            )
        }

        // ─── MAIN ─────────────────────────────────────────────
        AppPhase.MAIN -> {
            MainAppContent(
                appState = resolvedAppState,
                navController = navController,
            )
        }
    }
}

/**
 * Main app content — Scaffold with bottom nav + NavHost.
 *
 * Shown after the boot flow completes (Splash → Onboarding → Lock → Main).
 */
@Composable
private fun MainAppContent(
    appState: TitanAppState,
    navController: androidx.navigation.NavHostController,
) {
    // ── Bottom bar visibility logic ─────────────────────────────
    //
    // The previous implementation read `appState.currentRoute` inside
    // the Scaffold's `bottomBar = { ... }` slot, which had two
    // problems:
    //
    //   1. `currentRoute` is `null` during the very first composition
    //      (NavController hasn't resolved the start destination yet).
    //      This made `showBottomBar = false` on first frame, and in
    //      some cases the recomposition that should have flipped it
    //      back to `true` was missed — leaving the bar permanently
    //      hidden.
    //
    //   2. Wrapping the bar in `AnimatedVisibility` added an
    //      additional layer of timing fragility — the bar could get
    //      stuck at alpha 0 during the fade-out animation if a
    //      recomposition changed `visible` mid-animation.
    //
    // Fix:
    //   - Default to SHOWING the bottom bar (since `MainAppContent`
    //     is only ever called when we're on a top-level route — the
    //     boot flow screens don't reach here).
    //   - Hide it only when we explicitly know we're on a route that
    //     shouldn't have it (detail / modal screens).
    //   - When `currentRoute` is null (first frame), assume it's the
    //     start destination (HOME) which IS a top-level route, so
    //     show the bar.
    //
    // This guarantees the bar is visible from the very first frame
    // the main app renders.
    val currentRoute = appState.currentRoute
    val showBottomBar = when {
        // First frame: NavController hasn't resolved yet. Show the
        // bar — we know we're at the start destination (HOME) which
        // is a top-level route.
        currentRoute == null -> true
        // Normal case: defer to the route-based check.
        else -> NavRoutes.shouldShowBottomBar(currentRoute)
    }

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                TitanBottomBar(
                    destinations = TopLevelDestination.entries.toList(),
                    currentRoute = currentRoute ?: NavRoutes.HOME,
                    onNavigate = { dest ->
                        appState.navigateToTopLevelDestination(dest)
                    },
                )
            }
        },
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
        ) {
            TitanNavHost(
                navController = navController,
                modifier = Modifier.fillMaxSize(),
            )
        }
    }
}

/**
 * Bottom navigation bar — 5 top-level destinations.
 *
 * Uses the design system's [TitanNavigationBar] with badge support.
 */
@Composable
private fun TitanBottomBar(
    destinations: List<TopLevelDestination>,
    currentRoute: String?,
    onNavigate: (TopLevelDestination) -> Unit,
) {
    val navItems = destinations.map { dest ->
        NavItem(
            label = dest.label,
            icon = dest.icon,
            route = dest.route,
            badgeCount = dest.badgeCount,
        )
    }
    TitanNavigationBar(
        items = navItems,
        currentRoute = currentRoute,
        onNavigate = { route ->
            destinations.find { it.route == route }?.let { onNavigate(it) }
        },
    )
}

/**
 * App phase enum — controls the boot flow state machine.
 *
 * ```
 * SPLASH → ONBOARDING (first run) → PERMISSION_RATIONALE (if not granted)
 *        → APP_LOCK (if enabled) → MAIN
 * SPLASH → MAIN (returning user, no lock, permission already granted)
 * SPLASH → APP_LOCK → MAIN (returning user, lock enabled, permission granted)
 * ```
 */
enum class AppPhase {
    /** Animated splash screen — logo, version, loading. */
    SPLASH,

    /** First-run onboarding — 4-slide intro + permission request. */
    ONBOARDING,

    /** Full-screen storage permission rationale (re-prompt or Settings). */
    PERMISSION_RATIONALE,

    /** App lock — biometric or PIN entry. */
    APP_LOCK,

    /** Main app — Scaffold + bottom nav + NavHost with all screens. */
    MAIN,
}

/** SharedPreferences key for the onboarding-seen flag. */
private const val KEY_ONBOARDING_SEEN = "has_seen_onboarding"

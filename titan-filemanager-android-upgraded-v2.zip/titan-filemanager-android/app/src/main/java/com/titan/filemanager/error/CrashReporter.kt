package com.titan.filemanager.error

import android.content.Context
import android.os.Build
import com.titan.filemanager.core.common.logger.Logger
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

/**
 * ## CrashReporter
 *
 * Abstraction over the crash-reporting backend. Implementations can route
 * crash reports to:
 *  - Local file (`LocalCrashReporter`) — always available, no network needed
 *  - Firebase Crashlytics (`FirebaseCrashReporter`) — when Firebase is set up
 *  - Sentry / Bugsnag (`SentryCrashReporter`) — alternative backends
 *  - No-op (`NoopCrashReporter`) — for tests / debug builds
 *
 * ### Why an interface?
 *  - **Testability** — unit tests can inject a NoopCrashReporter
 *  - **Modularity** — the core error handler doesn't depend on Firebase/Sentry
 *  - **Multiple backends** — a [CompositeCrashReporter] can fan out to several
 *    backends simultaneously (e.g., local file + Crashlytics)
 *
 * ### Threading
 * All [report] implementations MUST be safe to call from any thread,
 * including the crashing thread. Implementations should not throw —
 * failure to report a crash should be logged but never propagate.
 */
interface CrashReporter {

    /**
     * Report a crash. Implementations should be non-blocking — long IO
     * operations should be dispatched to a background coroutine.
     *
     * @param report the crash report to send.
     */
    suspend fun report(report: CrashReport)

    /**
     * Flush any buffered reports. Called by [GlobalErrorHandler] when the
     * app is about to terminate, to ensure reports are persisted before
     * the process dies.
     */
    suspend fun flush()

    /**
     * Retrieve all pending crash reports that have not yet been uploaded
     * to a remote backend. Used by the in-app crash review screen.
     */
    suspend fun getPendingReports(): List<CrashReport>

    /**
     * Mark a crash report as reviewed / dismissed. The reporter can then
     * delete it from the pending queue.
     */
    suspend fun markReviewed(timestampMs: Long)
}

/**
 * ## LocalCrashReporter
 *
 * Persists crash reports to a local file in the app's internal files dir.
 * Each crash is stored as a separate `.txt` file named by timestamp, allowing
 * easy enumeration and sharing via Intent.
 *
 * ### File layout
 * ```
 * /data/data/com.titan.filemanager/files/crashes/
 *   ├── 2026-07-04_12-34-56-789_FATAL_NullPointerException.txt
 *   ├── 2026-07-04_13-01-23-456_NON-FATAL_IOException.txt
 *   └── ...
 * ```
 *
 * ### Rotation
 * To prevent unbounded growth, the reporter keeps at most 20 crash files.
 * Older files are deleted when the limit is exceeded.
 *
 * ### Privacy
 * Files are stored in internal storage, inaccessible to other apps. They
 * are NOT uploaded automatically — the user must explicitly share them
 * via the in-app crash review screen.
 */
@Singleton
class LocalCrashReporter @Inject constructor(
    @ApplicationContext private val context: Context,
    private val logger: Logger,
) : CrashReporter {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutex = Mutex()
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss-SSS", Locale.US)

    /** Directory where crash report files are stored. */
    private val crashDir: File by lazy {
        File(context.filesDir, "crashes").apply { if (!exists()) mkdirs() }
    }

    override suspend fun report(report: CrashReport) {
        scope.launch {
            try {
                val file = withContext(Dispatchers.IO) {
                    val severity = if (report.isFatal) "FATAL" else "NON-FATAL"
                    val shortClass = report.exceptionClass.substringAfterLast('.')
                    val fileName = "${dateFormat.format(Date(report.timestampMs))}_${severity}_${shortClass}.txt"
                    File(crashDir, fileName).also { it.writeText(report.toPlainText()) }
                }
                logger.i { "Crash report written to ${file.absolutePath}" }

                rotateOldFiles()
            } catch (e: IOException) {
                logger.e(e) { "Failed to write crash report" }
            }
        }
    }

    override suspend fun flush() {
        // No-op: writes are synchronous in [report]
    }

    override suspend fun getPendingReports(): List<CrashReport> = mutex.withLock {
        crashDir.listFiles { f -> f.isFile && f.name.endsWith(".txt") }
            ?.sortedByDescending { it.lastModified() }
            ?.map { parseFile(it) }
            ?: emptyList()
    }

    override suspend fun markReviewed(timestampMs: Long) {
        mutex.withLock {
            val target = crashDir.listFiles { f -> f.isFile && f.name.endsWith(".txt") }
                ?.firstOrNull { it.lastModified() == timestampMs }
            target?.delete()
        }
    }

    /**
     * Delete oldest crash files when total count exceeds [MAX_FILES].
     */
    private suspend fun rotateOldFiles() {
        val files: List<File> = withContext(Dispatchers.IO) {
            crashDir.listFiles { f -> f.isFile && f.name.endsWith(".txt") }
                ?.sortedBy { it.lastModified() }
                ?: emptyList()
        }
        if (files.size > MAX_FILES) {
            val toDelete = files.take(files.size - MAX_FILES)
            toDelete.forEach { f ->
                withContext(Dispatchers.IO) {
                    if (!f.delete()) {
                        logger.w { "Failed to delete old crash file: ${f.name}" }
                    }
                }
            }
            logger.i { "Rotated ${toDelete.size} old crash file(s)" }
        }
    }

    /**
     * Parse a crash report file back into a [CrashReport] (best-effort).
     * Returns a minimal report with just the file contents if parsing fails.
     */
    private fun parseFile(file: File): CrashReport {
        return try {
            val content = file.readText()
            val lines = content.lines()
            CrashReport(
                exceptionClass = extractValue(lines, "Exception:") ?: "Unknown",
                exceptionMessage = extractValue(lines, "Message:") ?: "",
                stackTrace = content.substringAfter("─ Stack Trace ─", content)
                    .substringBefore("─ Device ─").trim(),
                threadName = extractValue(lines, "Thread:")?.substringBefore(" ") ?: "unknown",
                threadPriority = extractValue(lines, "Thread:")?.let {
                    Regex("priority=(\\d+)").find(it)?.groupValues?.get(1)?.toIntOrNull()
                } ?: Thread.NORM_PRIORITY,
                threadId = -1L, // Not recoverable from text
                isFatal = content.contains("Severity:  FATAL"),
                timestampMs = file.lastModified(),
                deviceManufacturer = extractValue(lines, "Manufacturer:") ?: "unknown",
                deviceModel = extractValue(lines, "Model:") ?: "unknown",
                androidVersion = extractValue(lines, "Android:")?.substringBefore(" ") ?: "unknown",
                sdkLevel = extractValue(lines, "Android:")?.let {
                    Regex("SDK (\\d+)").find(it)?.groupValues?.get(1)?.toIntOrNull()
                } ?: 0,
                abi = extractValue(lines, "ABI:") ?: "unknown",
                appVersionName = extractValue(lines, "Version:")?.substringBefore(" ") ?: "unknown",
                appVersionCode = extractValue(lines, "Version:")?.let {
                    Regex("\\((\\d+)\\)").find(it)?.groupValues?.get(1)?.toLongOrNull()
                } ?: 0L,
                buildType = extractValue(lines, "Build type:") ?: "unknown",
                processId = -1,
                processName = extractValue(lines, "Process:")?.substringBefore(" ") ?: "unknown",
                freeHeapBytes = -1L,
                totalHeapBytes = -1L,
                nativeFreeBytes = -1L,
                storageFreeBytes = -1L,
                storageTotalBytes = -1L,
            )
        } catch (e: Throwable) {
            Timber.w(e, "Failed to parse crash file ${file.name}")
            CrashReport(
                exceptionClass = "ParseError",
                exceptionMessage = "Failed to parse: ${file.name}",
                stackTrace = file.readText(),
                threadName = "unknown",
                threadPriority = Thread.NORM_PRIORITY,
                threadId = -1L,
                isFatal = false,
                timestampMs = file.lastModified(),
                deviceManufacturer = "unknown",
                deviceModel = "unknown",
                androidVersion = "unknown",
                sdkLevel = 0,
                abi = "unknown",
                appVersionName = "unknown",
                appVersionCode = 0L,
                buildType = "unknown",
                processId = -1,
                processName = "unknown",
                freeHeapBytes = -1L,
                totalHeapBytes = -1L,
                nativeFreeBytes = -1L,
                storageFreeBytes = -1L,
                storageTotalBytes = -1L,
            )
        }
    }

    private fun extractValue(lines: List<String>, prefix: String): String? {
        return lines.firstOrNull { it.startsWith(prefix) }
            ?.substringAfter(prefix)
            ?.trim()
            ?.takeIf { it.isNotEmpty() }
    }

    companion object {
        private const val TAG = "LocalCrashReporter"
        private const val MAX_FILES = 20
    }
}

/**
 * ## NoopCrashReporter
 *
 * No-op implementation for debug builds and tests. All operations are
 * no-ops except [report], which logs to Timber for visibility.
 */
@Singleton
class NoopCrashReporter @Inject constructor() : CrashReporter {

    override suspend fun report(report: CrashReport) {
        Timber.tag("NoopCrashReporter").i("Crash captured: ${report.summary()}")
    }

    override suspend fun flush() = Unit
    override suspend fun getPendingReports(): List<CrashReport> = emptyList()
    override suspend fun markReviewed(timestampMs: Long) = Unit
}

/**
 * ## CompositeCrashReporter
 *
 * Fans out crash reports to multiple backends simultaneously. Useful when
 * you want both local persistence (always) and remote upload (when network
 * is available).
 *
 * ### Failure handling
 * If any backend throws during [report], the error is logged but does NOT
 * propagate — we want the other backends to still receive the report.
 */
@Singleton
class CompositeCrashReporter @Inject constructor(
    private val reporters: Set<@JvmSuppressWildcards CrashReporter>,
) : CrashReporter {

    override suspend fun report(report: CrashReport) {
        reporters.forEach { reporter ->
            try {
                reporter.report(report)
            } catch (e: Throwable) {
                Timber.tag("CompositeCrashReporter").e(e, "Backend ${reporter::class.simpleName} failed")
            }
        }
    }

    override suspend fun flush() {
        reporters.forEach { runCatching { it.flush() } }
    }

    override suspend fun getPendingReports(): List<CrashReport> {
        return reporters.flatMap { runCatching { it.getPendingReports() }.getOrDefault(emptyList()) }
    }

    override suspend fun markReviewed(timestampMs: Long) {
        reporters.forEach { runCatching { it.markReviewed(timestampMs) } }
    }
}

package com.titan.filemanager.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.widget.RemoteViews
import androidx.core.content.ContextCompat
import com.titan.filemanager.MainActivity
import com.titan.filemanager.R
import timber.log.Timber

/**
 * ## StorageWidgetProvider
 *
 * Home screen widget provider for the TitanFileManager storage overview widget.
 *
 * ### Widget behavior
 * The widget shows:
 *  - App name + "Storage Overview" subtitle
 *  - Used space / total space (e.g., "47.2 GB used of 128 GB")
 *  - Progress bar with usage percentage
 *  - Tap-to-open action (launches MainActivity)
 *
 * ### Update cycle
 *  - **Periodic**: every 30 minutes (declared in `widget_storage_info_provider.xml`)
 *  - **Manual**: user taps the refresh button inside the widget
 *  - **System events**: app sends `ACTION_APPWIDGET_UPDATE` when storage changes
 *    significantly (e.g., after a large file transfer completes)
 *
 * ### Data source
 * Storage stats are read from [StatFs] on the primary external storage
 * (`/storage/emulated/0`). This is a fast syscall (~1ms) and safe to call
 * from the main thread (which is where `onUpdate` runs).
 *
 * ### Pending intents
 *  - **Widget tap** → launches MainActivity (deep link to storage overview)
 *  - **Refresh button** → sends `WIDGET_REFRESH` action back to this provider
 *
 * ### Threading
 * [onUpdate] runs on the main thread. The StatFs call is fast enough that
 * we don't need to dispatch to a background thread. If future enhancements
 * add slower data sources (e.g., cloud storage stats), dispatch to IO.
 */
class StorageWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray,
    ) {
        Timber.d("StorageWidgetProvider.onUpdate — ${appWidgetIds.size} widget(s)")
        appWidgetIds.forEach { widgetId ->
            updateWidget(context, appWidgetManager, widgetId)
        }
    }

    /**
     * Handle the manual refresh action (user tapped the refresh button).
     */
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_WIDGET_REFRESH -> {
                Timber.d("Widget manual refresh requested")
                val manager = AppWidgetManager.getInstance(context)
                val ids = manager.getAppWidgetIds(ComponentName(context, StorageWidgetProvider::class.java))
                ids.forEach { widgetId ->
                    updateWidget(context, manager, widgetId)
                }
            }
        }
    }

    /**
     * Update a single widget instance with fresh storage data.
     */
    private fun updateWidget(
        context: Context,
        appWidgetManager: AppWidgetManager,
        widgetId: Int,
    ) {
        val views = RemoteViews(context.packageName, R.layout.widget_storage_info)

        // ── Read storage stats ──────────────────────────────────────
        val storageStats = readStorageStats()
        val usedPercent = if (storageStats.totalBytes > 0) {
            ((storageStats.usedBytes.toFloat() / storageStats.totalBytes) * 100).toInt()
        } else 0

        // ── Update text views ───────────────────────────────────────
        views.setTextViewText(
            R.id.widget_used,
            "${formatBytes(storageStats.usedBytes)} used of ${formatBytes(storageStats.totalBytes)}",
        )
        views.setTextViewText(
            R.id.widget_percent,
            "$usedPercent%",
        )

        // ── Update progress bar ─────────────────────────────────────
        views.setProgressBar(R.id.widget_progress, 100, usedPercent, false)

        // ── Set tap-to-open intent ──────────────────────────────────
        val openIntent = Intent(context, MainActivity::class.java).apply {
            action = Intent.ACTION_VIEW
            data = android.net.Uri.parse("titan://storage_overview")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        val openPendingIntent = PendingIntent.getActivity(
            context,
            widgetId,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        views.setOnClickPendingIntent(R.id.widget_storage_info, openPendingIntent)

        // ── Set refresh button intent ───────────────────────────────
        val refreshIntent = Intent(context, StorageWidgetProvider::class.java).apply {
            action = ACTION_WIDGET_REFRESH
        }
        val refreshPendingIntent = PendingIntent.getBroadcast(
            context,
            widgetId,
            refreshIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        views.setOnClickPendingIntent(R.id.widget_refresh, refreshPendingIntent)

        // ── Apply update ────────────────────────────────────────────
        appWidgetManager.updateAppWidget(widgetId, views)
    }

    /**
     * Read storage stats from the primary external storage via [StatFs].
     *
     * Returns a [StorageStats] with used + total bytes. On failure (e.g.,
     * storage not mounted), returns zeros.
     */
    private fun readStorageStats(): StorageStats {
        return try {
            val path = Environment.getExternalStorageDirectory()?.absolutePath
                ?: return StorageStats(0, 0)
            val stat = StatFs(path)
            val totalBytes = stat.totalBytes
            val availableBytes = stat.availableBytes
            val usedBytes = totalBytes - availableBytes
            StorageStats(usedBytes = usedBytes, totalBytes = totalBytes)
        } catch (e: Throwable) {
            Timber.w(e, "Failed to read storage stats")
            StorageStats(0, 0)
        }
    }

    /**
     * Format bytes as a human-readable string (e.g., "47.2 GB").
     */
    private fun formatBytes(bytes: Long): String = when {
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
        bytes < 1024 * 1024 * 1024 -> "%.1f MB".format(bytes / (1024.0 * 1024))
        else -> "%.2f GB".format(bytes / (1024.0 * 1024 * 1024))
    }

    /**
     * Storage stats data class.
     */
    private data class StorageStats(
        val usedBytes: Long,
        val totalBytes: Long,
    )

    companion object {
        /** Action sent by the widget refresh button. */
        const val ACTION_WIDGET_REFRESH = "com.titan.filemanager.widget.WIDGET_REFRESH"

        /**
         * Force-update all widget instances. Call this from app code when
         * storage changes significantly (e.g., after a large file transfer).
         */
        fun forceUpdate(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, StorageWidgetProvider::class.java))
            if (ids.isNotEmpty()) {
                val intent = Intent(context, StorageWidgetProvider::class.java).apply {
                    action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                    putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
                }
                context.sendBroadcast(intent)
            }
        }
    }
}

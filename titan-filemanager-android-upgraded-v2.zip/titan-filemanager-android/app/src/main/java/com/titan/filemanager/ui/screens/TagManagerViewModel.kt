package com.titan.filemanager.ui.screens

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.titan.filemanager.core.ui.tagmanager.Tag
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import org.json.JSONArray
import org.json.JSONObject
import javax.inject.Inject

/**
 * ViewModel for the Tag Manager screen.
 *
 * Previously the TagManagerScreen was wired with `tags = emptyList()`
 * and all CRUD callbacks as no-ops — the screen always showed "no
 * tags" and creating/editing/deleting tags did nothing.
 *
 * This VM persists tags to a SharedPreferences JSON array (simple,
 * no Room schema needed). Tags are loaded on init, and CRUD
 * operations update both the in-memory StateFlow and the persisted
 * JSON.
 */
@HiltViewModel
class TagManagerViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
) : ViewModel() {

    private val prefs = context.getSharedPreferences("titan_tags", Context.MODE_PRIVATE)

    private val _tags = MutableStateFlow<List<Tag>>(emptyList())
    val tags: StateFlow<List<Tag>> = _tags.asStateFlow()

    init {
        loadTags()
    }

    private fun loadTags() {
        viewModelScope.launch {
            val loaded = withContext(Dispatchers.IO) {
                val json = prefs.getString(KEY_TAGS, "[]") ?: "[]"
                val array = JSONArray(json)
                (0 until array.length()).map { i ->
                    val obj = array.getJSONObject(i)
                    Tag(
                        id = obj.getString("id"),
                        name = obj.getString("name"),
                        color = try {
                            com.titan.filemanager.core.ui.tagmanager.TagColor.valueOf(obj.getString("color"))
                        } catch (_: Exception) {
                            com.titan.filemanager.core.ui.tagmanager.TagColor.BLUE
                        },
                        icon = try {
                            com.titan.filemanager.core.ui.tagmanager.TagIcon.valueOf(obj.getString("icon"))
                        } catch (_: Exception) {
                            com.titan.filemanager.core.ui.tagmanager.TagIcon.LABEL
                        },
                    )
                }
            }
            _tags.value = loaded
        }
    }

    fun createTag(tag: Tag) {
        val current = _tags.value.toMutableList()
        val newTag = tag.copy(id = System.currentTimeMillis().toString())
        current.add(newTag)
        _tags.value = current
        persist(current)
    }

    fun updateTag(tag: Tag) {
        val current = _tags.value.toMutableList()
        val index = current.indexOfFirst { it.id == tag.id }
        if (index >= 0) {
            current[index] = tag
            _tags.value = current
            persist(current)
        }
    }

    fun deleteTag(tag: Tag) {
        val current = _tags.value.filterNot { it.id == tag.id }
        _tags.value = current
        persist(current)
    }

    private fun persist(tags: List<Tag>) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                val array = JSONArray()
                tags.forEach { tag ->
                    array.put(JSONObject().apply {
                        put("id", tag.id)
                        put("name", tag.name)
                        put("color", tag.color.name)
                        put("icon", tag.icon.name)
                    })
                }
                prefs.edit().putString(KEY_TAGS, array.toString()).apply()
            }
        }
    }

    companion object {
        private const val KEY_TAGS = "tags_json"
    }
}

package com.titan.filemanager

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.lifecycleScope
import com.titan.filemanager.core.designsystem.theme.TitanTheme
import com.titan.filemanager.core.designsystem.theme.TitanThemeConfig
import com.titan.filemanager.deeplink.DeepLink
import com.titan.filemanager.deeplink.DeepLinkHandler
import com.titan.filemanager.error.CrashReport
import com.titan.filemanager.error.ErrorReportDialog
import com.titan.filemanager.error.GlobalErrorHandler
import com.titan.filemanager.permission.NotificationPermissionHandler
import com.titan.filemanager.ui.TitanApp
import com.titan.filemanager.ui.TitanAppState
import com.titan.filemanager.ui.rememberTitanAppState
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject
import androidx.navigation.compose.rememberNavController

/**
 * Single-Activity host for the entire TitanFileManager app.
 *
 * ═══════════════════════════════════════════════════════════
 * ACTIVITY LIFECYCLE
 * ═══════════════════════════════════════════════════════════
 *
 * 1. `installSplashScreen()` — shows the API-26+ system splash on cold
 *    start. The system splash is dismissed once the Compose tree is ready.
 *
 * 2. `enableEdgeToEdge()` — draws the app under system bars (status bar +
 *    navigation bar) for an immersive, modern look.
 *
 * 3. `setContent { TitanTheme { TitanApp() } }` — mounts the root Compose
 *    tree wrapped in [TitanTheme] for Material 3 + dynamic color.
 *
 * ═══════════════════════════════════════════════════════════
 * HILT INTEGRATION
 * ═══════════════════════════════════════════════════════════
 *
 * `@AndroidEntryPoint` enables Hilt dependency injection for this Activity.
 * All ViewModels and repositories are injected via Hilt throughout the app.
 *
 * ═══════════════════════════════════════════════════════════
 * DEEP LINK HANDLING (Phase 5)
 * ═══════════════════════════════════════════════════════════
 *
 * All inbound intents route through [DeepLinkHandler]:
 *  - `titan://` scheme URIs (app shortcuts)
 *  - `file://` / `content://` URIs (external file open)
 *  - `SEND` / `SEND_MULTIPLE` actions (share-to-app)
 *  - Notification taps with `EXTRA_DESTINATION`
 *
 * The handler converts each intent to a [DeepLink] value, which is then
 * passed to [TitanAppState] for navigation.
 *
 * ═══════════════════════════════════════════════════════════
 * CRASH REPORTING (Phase 5)
 * ═══════════════════════════════════════════════════════════
 *
 * The Activity observes [GlobalErrorHandler.errorBus]. When a crash report
 * is emitted (from any thread), the [ErrorReportDialog] is shown.
 *
 * The Activity also observes [GlobalErrorHandler.anrBus] for ANR events
 * and [GlobalErrorHandler.lowMemoryEvents] for OOM pre-warnings.
 *
 * ═══════════════════════════════════════════════════════════
 * NOTIFICATION PERMISSION (Phase 5)
 * ═══════════════════════════════════════════════════════════
 *
 * On Android 13+, the Activity requests `POST_NOTIFICATIONS` permission
 * after the boot flow completes. The permission is requested via the
 * [NotificationPermissionHandler] injected by Hilt.
 *
 * ═══════════════════════════════════════════════════════════
 * FOREGROUND / BACKGROUND TRACKING
 * ═══════════════════════════════════════════════════════════
 *
 * The Activity's [androidx.lifecycle.Lifecycle] is observed to update
 * [GlobalErrorHandler.setForeground]. The ANR watchdog only triggers
 * when the app is foregrounded — background ANRs are the system's
 * responsibility.
 */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject
    lateinit var deepLinkHandler: DeepLinkHandler

    @Inject
    lateinit var globalErrorHandler: GlobalErrorHandler

    @Inject
    lateinit var notificationPermissionHandler: NotificationPermissionHandler

    override fun onCreate(savedInstanceState: Bundle?) {
        // Install system splash screen BEFORE super.onCreate
        // so it shows during cold start, then dismisses when ready.
        val splash = installSplashScreen()

        super.onCreate(savedInstanceState)

        // Draw app under system bars for edge-to-edge experience.
        enableEdgeToEdge()

        // Keep system splash visible until first Compose frame is ready.
        // In production, set this to `true` while async init (DB, DataStore)
        // is running, then flip to `false` when ready.
        splash.setKeepOnScreenCondition { false }

        // Observe foreground state for ANR detector
        lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onStart(owner: LifecycleOwner) {
                globalErrorHandler.setForeground(true)
            }
            override fun onStop(owner: LifecycleOwner) {
                globalErrorHandler.setForeground(false)
            }
        })

        // Process the initial intent (cold start from notification / deep link)
        handleIntent(intent)

        setContent {
            TitanTheme(
                config = TitanThemeConfig(
                    dynamicColor = true,
                    darkTheme = null, // Follow system
                ),
            ) {
                val navController = rememberNavController()
                val appState = rememberTitanAppState(navController)

                // ═══════════════════════════════════════════════════════════
                // OBSERVE GLOBAL ERROR BUS — show ErrorReportDialog on crash
                // ═══════════════════════════════════════════════════════════
                val crashReport by globalErrorHandler.errorBus.collectAsState(initial = null)

                crashReport?.let { report ->
                    ErrorReportDialog(
                        report = report,
                        onDismiss = { /* report stays in bus — will be shown again next launch */ },
                        onSendReport = { crashReport ->
                            // Launch system share intent with crash report text
                            val shareIntent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(
                                    android.content.Intent.EXTRA_SUBJECT,
                                    "TitanFileManager Crash Report: ${crashReport.summary()}",
                                )
                                putExtra(
                                    android.content.Intent.EXTRA_TEXT,
                                    crashReport.toPlainText(),
                                )
                            }
                            startActivity(
                                android.content.Intent.createChooser(shareIntent, "Send crash report"),
                            )
                        },
                        onViewDetails = { crashReport ->
                            // Navigate to CrashReviewScreen to view all pending crash reports
                            appState.navController.navigate(com.titan.filemanager.core.navigation.NavRoutes.CRASH_REVIEW)
                        },
                    )
                }

                // ═══════════════════════════════════════════════════════════
                // OBSERVE ANR BUS — log ANR events
                // ═══════════════════════════════════════════════════════════
                LaunchedEffect(Unit) {
                    globalErrorHandler.anrBus.collectLatest { anr ->
                        Timber.w("ANR detected: blocked for ${anr.blockedDurationMs}ms")
                    }
                }

                // ═══════════════════════════════════════════════════════════
                // OBSERVE LOW MEMORY — log warnings
                // ═══════════════════════════════════════════════════════════
                LaunchedEffect(Unit) {
                    globalErrorHandler.lowMemoryEvents.collectLatest { event ->
                        Timber.w("Low memory: ${(event.freeFraction * 100).toInt()}% free")
                    }
                }

                // ═══════════════════════════════════════════════════════════
                // OBSERVE PENDING DEEP LINK — dispatch when NavController is ready
                // ═══════════════════════════════════════════════════════════
                val pendingDeepLink by appState.pendingDeepLink.collectAsState()
                LaunchedEffect(pendingDeepLink) {
                    if (pendingDeepLink != null) {
                        appState.consumePendingDeepLink()
                    }
                }

                TitanApp(appState = appState)
            }
        }
    }

    /**
     * Handle inbound intents. Called from:
     *  - `onCreate` — cold start with an intent
     *  - `onNewIntent` — warm start (app already running, user taps notification)
     */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    /**
     * Process an intent and navigate to the appropriate screen.
     *
     * Deep link flow:
     *  1. [DeepLinkHandler.parseIntent] converts the intent to a [DeepLink]
     *  2. [DeepLink] is dispatched to [TitanAppState] via [dispatchDeepLink]
     *  3. TitanApp observes `pendingDeepLink` StateFlow and calls
     *     [consumePendingDeepLink] when the NavController is ready
     *  4. [consumePendingDeepLink] navigates to the route from [DeepLink.toNavRoute]
     */
    private fun handleIntent(intent: Intent?) {
        if (intent == null) return

        val deepLink = deepLinkHandler.parseIntent(intent)
        if (deepLink != null) {
            Timber.i("Deep link received: $deepLink")
            // Dispatch to pendingDeepLink — TitanApp will process it
            // once the NavController is ready (observes the StateFlow)
            pendingDeepLinkForDispatch = deepLink
        } else {
            Timber.d("No deep link recognized for intent: ${intent.action}")
        }
    }

    /**
     * Temporary holder for deep links received before the Compose tree is ready.
     * TitanApp reads this on first composition and dispatches it to TitanAppState.
     */
    @Volatile
    private var pendingDeepLinkForDispatch: DeepLink? = null

    /**
     * Called by TitanApp on first composition to retrieve any pending deep link
     * that arrived during cold start (before the NavController existed).
     */
    fun consumeStartupDeepLink(): DeepLink? {
        val link = pendingDeepLinkForDispatch
        pendingDeepLinkForDispatch = null
        return link
    }

    /**
     * Request notification permission after the user has completed onboarding
     * and entered the main app. Called by TitanApp when the boot flow completes.
     *
     * This is intentionally NOT called in [onCreate] — we wait until the user
     * has gone through splash + onboarding + app lock so that the permission
     * prompt doesn't interrupt the first-run experience.
     */
    fun requestNotificationPermissionIfNeeded() {
        if (!notificationPermissionHandler.isGranted()) {
            lifecycleScope.launch {
                // Mark that we've prompted once
                notificationPermissionHandler.markPrompted()
                // The actual permission request is launched via the Compose
                // rememberNotificationPermissionState() helper from
                // NotificationPermissionRationale composable.
                Timber.i("Notification permission needed — will prompt via Compose UI")
            }
        }
    }
}

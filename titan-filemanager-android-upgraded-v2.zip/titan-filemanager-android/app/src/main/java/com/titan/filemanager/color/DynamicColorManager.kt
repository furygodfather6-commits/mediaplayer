package com.titan.filemanager.color

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color as ComposeColor
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.toArgb
import androidx.palette.graphics.Palette
import com.titan.filemanager.core.common.logger.Logger
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * ## DynamicColorManager
 *
 * Manages Material You dynamic color extraction on Android 12+ (API 31+),
 * with a fallback to manual palette extraction on older Android versions.
 *
 * ### Behavior
 *  - **Android 12+ (API 31+)**: Uses [dynamicLightColorScheme] and
 *    [dynamicDarkColorScheme] which delegate to the system's wallpaper
 *    color extraction (powered by SystemUI).
 *  - **Android 11 and below**: Manually extracts the dominant colors from
 *    the current wallpaper using the Palette library, then builds a
 *    ColorScheme from those colors.
 *
 * ### Observation
 * The manager exposes [colorSchemeState] — a StateFlow<DynamicColorScheme?>
 * that updates whenever:
 *  - The user changes wallpaper
 *  - The user toggles dark mode
 *  - The user enables/disables dynamic color in Settings
 *
 * ### Wallpaper listener
 * On Android 11 and below, we register a [WallpaperManager.OnColorsChangedListener]
 * to detect wallpaper changes. On Android 12+, the system handles this
 * automatically — no listener needed.
 *
 * ### Custom palettes
 * The manager also supports custom color extraction from any bitmap:
 * ```kotlin
 * val palette = dynamicColorManager.extractPalette(bitmap)
 * val colorScheme = dynamicColorManager.buildColorSchemeFromPalette(palette, dark = false)
 * ```
 * This is used by the TagManager to auto-suggest tag colors from a file's
 * thumbnail.
 */
@Singleton
class DynamicColorManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val logger: Logger,
) {

    private val _colorSchemeState = MutableStateFlow<DynamicColorScheme?>(null)
    val colorSchemeState: StateFlow<DynamicColorScheme?> = _colorSchemeState.asStateFlow()

    /** Wallpaper colors listener (Android 11 and below only). */
    private var wallpaperListener: WallpaperManager.OnColorsChangedListener? = null

    /**
     * Initialize the dynamic color manager. Called from [TitanApplication.onCreate].
     *
     * On Android 12+, this is a no-op — the system handles everything.
     * On Android 11 and below, this registers a wallpaper listener.
     */
    fun initialize() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            logger.i { "DynamicColorManager initialized (Android 12+ — system-managed)" }
            // System handles color extraction; we just need to refresh the cached scheme
            refreshColorScheme(isDark = false, dynamicColorEnabled = true)
        } else {
            logger.i { "DynamicColorManager initialized (Android 11 and below — manual extraction)" }
            registerWallpaperListener()
            // Extract initial palette
            refreshColorScheme(isDark = false, dynamicColorEnabled = true)
        }
    }

    /**
     * Refresh the cached [DynamicColorScheme] based on the current state.
     *
     * Called when:
     *  - Dark mode toggles
     *  - Dynamic color setting toggles
     *  - Wallpaper changes (Android 11 and below)
     *
     * @param isDark whether the system is in dark mode.
     * @param dynamicColorEnabled whether the user has enabled dynamic color in Settings.
     */
    fun refreshColorScheme(isDark: Boolean, dynamicColorEnabled: Boolean) {
        if (!dynamicColorEnabled) {
            _colorSchemeState.value = null
            return
        }

        val scheme = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // Android 12+ — system-managed dynamic color
            if (isDark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        } else {
            // Android 11 and below — manual extraction
            extractColorSchemeFromWallpaper(isDark)
        }

        _colorSchemeState.value = DynamicColorScheme(
            lightScheme = if (isDark) extractColorSchemeFromWallpaper(dark = false) else scheme,
            darkScheme = if (isDark) scheme else extractColorSchemeFromWallpaper(dark = true),
            isDynamic = true,
            source = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) "system" else "wallpaper_extraction",
        )

        logger.i { "Color scheme refreshed (dark=$isDark, source=${_colorSchemeState.value?.source})" }
    }

    /**
     * Extract a color palette from the given [bitmap].
     *
     * Returns a [TitanPalette] containing the dominant, vibrant, muted, and
     * dark/light vibrant colors. Used for:
     *  - TagManager auto-suggest tag colors
     *  - FileProperties "extract dominant color" feature
     *  - Splash screen color adaptation
     */
    suspend fun extractPalette(bitmap: Bitmap): TitanPalette = withContext(Dispatchers.Default) {
        val palette = Palette.from(bitmap).generate()
        TitanPalette.from(palette)
    }

    /**
     * Build a [ColorScheme] from a [TitanPalette].
     *
     * This is a simplified color scheme generator — it doesn't match the
     * exact Material You algorithm, but produces a usable Material 3 scheme
     * from any palette.
     *
     * @param palette the palette to build from.
     * @param isDark whether to build a dark or light scheme.
     */
    fun buildColorSchemeFromPalette(palette: TitanPalette, isDark: Boolean): ColorScheme {
        val primary = ComposeColor(palette.dominantColor)
        return if (isDark) {
            darkColorScheme(
                primary = primary,
                onPrimary = ComposeColor(pickContrastColor(palette.dominantColor)),
                primaryContainer = ComposeColor(darken(palette.dominantColor, 0.3f)),
                onPrimaryContainer = ComposeColor(pickContrastColor(darken(palette.dominantColor, 0.3f))),
                secondary = ComposeColor(palette.mutedColor),
                tertiary = ComposeColor(palette.vibrantColor),
            )
        } else {
            lightColorScheme(
                primary = primary,
                onPrimary = ComposeColor(pickContrastColor(palette.dominantColor)),
                primaryContainer = ComposeColor(lighten(palette.dominantColor, 0.7f)),
                onPrimaryContainer = ComposeColor(pickContrastColor(lighten(palette.dominantColor, 0.7f))),
                secondary = ComposeColor(palette.mutedColor),
                tertiary = ComposeColor(palette.vibrantColor),
            )
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // INTERNAL — WALLPAPER EXTRACTION
    // ═══════════════════════════════════════════════════════════════

    /**
     * Extract a color scheme from the current wallpaper.
     *
     * On Android 12+, this is a fallback (system handles it).
     * On Android 11 and below, this is the primary extraction method.
     */
    private fun extractColorSchemeFromWallpaper(dark: Boolean): ColorScheme {
        return try {
            val wallpaperManager = WallpaperManager.getInstance(context)
            val drawable = wallpaperManager.drawable
                ?: return if (dark) darkFallbackColorScheme() else lightFallbackColorScheme()

            // Convert wallpaper drawable to bitmap
            val bitmap = drawableToBitmap(drawable)
            val palette = Palette.from(bitmap).generate()

            val dominantColor = palette.getDominantColor(0xFF1A73E8.toInt())
            val vibrantColor = palette.getVibrantColor(dominantColor)
            val mutedColor = palette.getMutedColor(dominantColor)

            if (dark) {
                darkColorScheme(
                    primary = ComposeColor(vibrantColor),
                    onPrimary = ComposeColor(pickContrastColor(vibrantColor)),
                    primaryContainer = ComposeColor(darken(vibrantColor, 0.3f)),
                    onPrimaryContainer = ComposeColor(pickContrastColor(darken(vibrantColor, 0.3f))),
                    secondary = ComposeColor(mutedColor),
                    tertiary = ComposeColor(vibrantColor),
                )
            } else {
                lightColorScheme(
                    primary = ComposeColor(vibrantColor),
                    onPrimary = ComposeColor(pickContrastColor(vibrantColor)),
                    primaryContainer = ComposeColor(lighten(vibrantColor, 0.7f)),
                    onPrimaryContainer = ComposeColor(pickContrastColor(lighten(vibrantColor, 0.7f))),
                    secondary = ComposeColor(mutedColor),
                    tertiary = ComposeColor(vibrantColor),
                )
            }
        } catch (e: Throwable) {
            logger.e(e) { "Wallpaper color extraction failed" }
            if (dark) darkFallbackColorScheme() else lightFallbackColorScheme()
        }
    }

    /**
     * Register a wallpaper colors listener (Android 11 and below).
     */
    private fun registerWallpaperListener() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            wallpaperListener = WallpaperManager.OnColorsChangedListener { _, _ ->
                logger.i { "Wallpaper changed — refreshing color scheme" }
                refreshColorScheme(isDark = false, dynamicColorEnabled = true)
            }
            try {
                val listener = wallpaperListener ?: return
                WallpaperManager.getInstance(context).addOnColorsChangedListener(
                    listener,
                    Handler(Looper.getMainLooper()),
                )
            } catch (e: Throwable) {
                logger.e(e) { "Failed to register wallpaper listener" }
            }
        }
    }

    /**
     * Convert a Drawable to a Bitmap (downsampled to 128x128 for fast palette extraction).
     */
    private fun drawableToBitmap(drawable: android.graphics.drawable.Drawable): Bitmap {
        val targetSize = 128
        val bitmap = Bitmap.createBitmap(targetSize, targetSize, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bitmap)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)
        return bitmap
    }

    /**
     * Pick a contrasting color (black or white) for the given background color.
     */
    private fun pickContrastColor(backgroundColor: Int): Int {
        val luminance = (0.299 * Color.red(backgroundColor) +
                         0.587 * Color.green(backgroundColor) +
                         0.114 * Color.blue(backgroundColor)) / 255.0
        return if (luminance > 0.5) Color.BLACK else Color.WHITE
    }

    /**
     * Darken a color by the given fraction (0.0 = no change, 1.0 = full black).
     */
    private fun darken(color: Int, fraction: Float): Int {
        val r = (Color.red(color) * (1 - fraction)).toInt().coerceIn(0, 255)
        val g = (Color.green(color) * (1 - fraction)).toInt().coerceIn(0, 255)
        val b = (Color.blue(color) * (1 - fraction)).toInt().coerceIn(0, 255)
        return Color.rgb(r, g, b)
    }

    /**
     * Lighten a color by mixing it with white.
     */
    private fun lighten(color: Int, fraction: Float): Int {
        val r = (Color.red(color) + (255 - Color.red(color)) * fraction).toInt().coerceIn(0, 255)
        val g = (Color.green(color) + (255 - Color.green(color)) * fraction).toInt().coerceIn(0, 255)
        val b = (Color.blue(color) + (255 - Color.blue(color)) * fraction).toInt().coerceIn(0, 255)
        return Color.rgb(r, g, b)
    }

    private fun lightFallbackColorScheme(): ColorScheme = lightColorScheme(
        primary = ComposeColor(0xFF1A73E8),
        secondary = ComposeColor(0xFF52606D),
        tertiary = ComposeColor(0xFF00897B),
    )

    private fun darkFallbackColorScheme(): ColorScheme = darkColorScheme(
        primary = ComposeColor(0xFFA4C9FE),
        secondary = ComposeColor(0xFFBBC7D4),
        tertiary = ComposeColor(0xFF4DB6AC),
    )

    companion object {
        private const val TAG = "DynamicColorManager"
    }
}

// ═══════════════════════════════════════════════════════════════
// DATA CLASSES
// ═══════════════════════════════════════════════════════════════

/**
 * Immutable container holding both light and dark dynamic color schemes.
 */
@Immutable
data class DynamicColorScheme(
    val lightScheme: ColorScheme,
    val darkScheme: ColorScheme,
    val isDynamic: Boolean,
    val source: String, // "system" or "wallpaper_extraction"
)

/**
 * Simplified color palette extracted from a bitmap.
 *
 * Wraps the Palette library's color extraction results in an immutable
 * data class with named colors.
 */
@Immutable
data class TitanPalette(
    val dominantColor: Int,
    val vibrantColor: Int,
    val darkVibrantColor: Int,
    val lightVibrantColor: Int,
    val mutedColor: Int,
    val darkMutedColor: Int,
    val lightMutedColor: Int,
) {

    companion object {
        fun from(palette: Palette): TitanPalette {
            val dominant = palette.getDominantColor(0xFF1A73E8.toInt())
            return TitanPalette(
                dominantColor = dominant,
                vibrantColor = palette.getVibrantColor(dominant),
                darkVibrantColor = palette.getDarkVibrantColor(dominant),
                lightVibrantColor = palette.getLightVibrantColor(dominant),
                mutedColor = palette.getMutedColor(dominant),
                darkMutedColor = palette.getDarkMutedColor(dominant),
                lightMutedColor = palette.getLightMutedColor(dominant),
            )
        }
    }

    /** All colors as a list, useful for showing swatches. */
    fun allColors(): List<Int> = listOf(
        dominantColor, vibrantColor, darkVibrantColor, lightVibrantColor,
        mutedColor, darkMutedColor, lightMutedColor,
    ).distinct()
}

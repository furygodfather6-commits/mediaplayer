package com.titan.filemanager

import android.content.Context
import android.os.Build
import android.os.Environment
import timber.log.Timber
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * GlobalCrashHandler — catches all uncaught exceptions and writes
 * a detailed crash report to the public Download folder.
 *
 * ## How it works
 * 1. Installed as the default UncaughtExceptionHandler
 * 2. When a crash occurs, writes a crash report to:
 *    /sdcard/Download/titan-logs/crash-<timestamp>.txt
 * 3. Also logs to logcat via Timber
 * 4. Delegates to the original handler (so the app still shows the crash dialog)
 *
 * ## Usage
 * ```kotlin
 * GlobalCrashHandler.install(applicationContext)
 * ```
 */
class GlobalCrashHandler private constructor(
    private val context: Context,
    private val defaultHandler: Thread.UncaughtExceptionHandler?,
) : Thread.UncaughtExceptionHandler {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.getDefault())
    private val fullDateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault())

    companion object {
        @Volatile
        private var instance: GlobalCrashHandler? = null

        fun install(context: Context) {
            if (instance != null) return
            val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
            val handler = GlobalCrashHandler(context.applicationContext, defaultHandler)
            instance = handler
            Thread.setDefaultUncaughtExceptionHandler(handler)
            Timber.i("GlobalCrashHandler installed — crash reports will be saved to Download/titan-logs/")
        }
    }

    override fun uncaughtException(thread: Thread, throwable: Throwable) {
        try {
            Timber.e(throwable, "FATAL CRASH on thread ${thread.name}")
            writeCrashReport(thread, throwable)
        } catch (_: Throwable) {
            // Don't crash again in the crash handler
        }

        // Delegate to default handler
        defaultHandler?.uncaughtException(thread, throwable)
    }

    private fun writeCrashReport(thread: Thread, throwable: Throwable) {
        val logDir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "titan-logs"
        )
        if (!logDir.exists()) logDir.mkdirs()

        val crashFile = File(logDir, "crash-${dateFormat.format(Date())}.txt")

        val report = buildString {
            append("═══════════════════════════════════════════════════════════\n")
            append("  TITAN FILE MANAGER — CRASH REPORT\n")
            append("═══════════════════════════════════════════════════════════\n")
            append("Date: ${fullDateFormat.format(Date())}\n")
            append("Thread: ${thread.name} (id=${thread.id})\n")
            append("Process PID: ${android.os.Process.myPid()}\n")
            append("Android SDK: ${Build.VERSION.SDK_INT} (${Build.VERSION.RELEASE})\n")
            append("Device: ${Build.MANUFACTURER} ${Build.MODEL}\n")
            append("App Version: ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})\n")
            append("Build Type: ${if (BuildConfig.DEBUG) "debug" else "release"}\n")
            append("Package: ${context.packageName}\n")
            append("═══════════════════════════════════════════════════════════\n")
            append("\n")
            append("EXCEPTION:\n")
            append(throwable.javaClass.name)
            append(": ")
            append(throwable.message ?: "(no message)")
            append("\n\n")

            // Print cause chain
            var cause: Throwable? = throwable
            var depth = 0
            while (cause != null && depth < 10) {
                if (depth > 0) {
                    append("Caused by: ")
                    append(cause.javaClass.name)
                    append(": ")
                    append(cause.message ?: "(no message)")
                    append("\n\n")
                }
                depth++
                cause = cause.cause
            }

            append("FULL STACK TRACE:\n")
            val sw = StringWriter()
            throwable.printStackTrace(PrintWriter(sw))
            append(sw.toString())
            append("\n")
            append("═══════════════════════════════════════════════════════════\n")
            append("END OF CRASH REPORT\n")
        }

        crashFile.writeText(report)
        Timber.i("Crash report saved to: ${crashFile.absolutePath}")
    }
}

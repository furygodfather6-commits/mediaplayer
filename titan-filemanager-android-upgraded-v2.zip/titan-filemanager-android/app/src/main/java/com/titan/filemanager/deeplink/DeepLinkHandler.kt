package com.titan.filemanager.deeplink

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Parcelable
import androidx.compose.runtime.Immutable
import com.titan.filemanager.core.common.logger.Logger
import com.titan.filemanager.core.navigation.NavRoutes
import dagger.hilt.android.qualifiers.ApplicationContext
import timber.log.Timber
import java.net.URLDecoder
import javax.inject.Inject
import javax.inject.Singleton

/**
 * ## DeepLinkHandler
 *
 * Centralized handler for ALL inbound intents to MainActivity:
 *
 *  - **App shortcuts** — long-press launcher icon → "Browse" / "Search" / "Vault" / "Recent"
 *  - **Custom scheme deep links** — `titan://browse`, `titan://search?query=foo`
 *  - **File view intents** — `android.intent.action.VIEW` with `file://` or `content://` URIs
 *  - **Share intents** — `android.intent.action.SEND` with one or more files
 *  - **Notification intents** — taps on notifications with extras
 *
 * ### API surface
 *  - [parseIntent] — converts an [Intent] into a [DeepLink] sealed class
 *  - [DeepLink.toNavRoute] — converts a DeepLink into a navigation route string for TitanNavHost
 *  - [DeepLink.toCustomData] — exposes any extra metadata for the destination screen
 *
 * ### Why a sealed class?
 * A sealed class gives us exhaustive `when` matching — when a new deep link
 * type is added, the compiler flags every `when` that needs updating. This
 * prevents silent drops of new deep link types.
 *
 * ### Threading
 * [parseIntent] is synchronous and non-blocking. The Intent object is
 * already in memory by the time MainActivity receives it, so parsing is
 * just pattern matching on URI + extras.
 *
 * ### Privacy / Safety
 *  - All file URIs are validated against path traversal (`..`).
 *  - Content URIs are NOT granted persistent permission — caller must
 *    take a persistable URI permission if needed.
 *  - Sensitive extras (e.g., vault passwords) are NOT logged.
 */
@Singleton
class DeepLinkHandler @Inject constructor(
    @ApplicationContext private val context: Context,
    private val logger: Logger,
) {

    /**
     * Parse an [Intent] into a [DeepLink] value, or `null` if the intent
     * doesn't match any known deep link pattern.
     *
     * Called from `MainActivity.onNewIntent` and `MainActivity.onCreate`
     * (when started from an external source).
     */
    fun parseIntent(intent: Intent): DeepLink? {
        val action = intent.action ?: return null
        val data = intent.data

        Timber.tag(TAG).d("parseIntent: action=%s data=%s", action, data)

        return when {
            // ═══════════════════════════════════════════════════════════
            // APP SHORTCUTS — titan:// scheme
            // ═══════════════════════════════════════════════════════════
            action == Intent.ACTION_VIEW && data != null && data.scheme == SCHEME_TITAN -> {
                parseTitanScheme(data)
            }

            // ═══════════════════════════════════════════════════════════
            // EXTERNAL FILE VIEW — file:// or content:// URIs
            // ═══════════════════════════════════════════════════════════
            action == Intent.ACTION_VIEW && data != null && data.scheme in FILE_SCHEMES -> {
                parseExternalFile(data, intent.type)
            }

            // ═══════════════════════════════════════════════════════════
            // SHARE INTENT — single file
            // ═══════════════════════════════════════════════════════════
            action == Intent.ACTION_SEND -> {
                parseShareSingle(intent)
            }

            // ═══════════════════════════════════════════════════════════
            // SHARE INTENT — multiple files
            // ═══════════════════════════════════════════════════════════
            action == Intent.ACTION_SEND_MULTIPLE -> {
                parseShareMultiple(intent)
            }

            // ═══════════════════════════════════════════════════════════
            // NOTIFICATION TAP — extra "destination" present
            // ═══════════════════════════════════════════════════════════
            intent.hasExtra(EXTRA_DESTINATION) -> {
                parseNotificationTap(intent)
            }

            else -> {
                Timber.tag(TAG).w("Unrecognized intent: action=%s data=%s", action, data)
                null
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // TITAN:// SCHEME PARSING
    // ═══════════════════════════════════════════════════════════════

    /**
     * Parse a `titan://` URI into a [DeepLink].
     *
     * Supported host/path combinations:
     *  - `titan://browse` → DeepLink.Browse (root)
     *  - `titan://browse?path=/sdcard/DCIM` → DeepLink.Browse with path
     *  - `titan://search?query=foo` → DeepLink.Search with query
     *  - `titan://vault` → DeepLink.Vault
     *  - `titan://recent` → DeepLink.Recent
     *  - `titan://viewer?path=/sdcard/photo.jpg` → DeepLink.Viewer with path
     *  - `titan://bookmarks` → DeepLink.Bookmarks
     *  - `titan://analytics` → DeepLink.Analytics
     *  - `titan://settings` → DeepLink.Settings
     */
    private fun parseTitanScheme(uri: Uri): DeepLink? {
        val host = uri.host ?: return null
        val queryParams = uri.queryParameterNames.associateWith { uri.getQueryParameter(it).orEmpty() }

        return when (host) {
            "browse" -> DeepLink.Browse(
                initialPath = queryParams["path"]?.let { decodePath(it) },
            )
            "search" -> DeepLink.Search(
                initialQuery = queryParams["query"].orEmpty(),
            )
            "vault" -> DeepLink.Vault
            "recent" -> DeepLink.Recent
            "viewer" -> DeepLink.Viewer(
                filePath = queryParams["path"]?.let { decodePath(it) } ?: return null,
            )
            "bookmarks" -> DeepLink.Bookmarks
            "analytics" -> DeepLink.Analytics
            "settings" -> DeepLink.Settings
            "duplicates" -> DeepLink.Duplicates
            "trash" -> DeepLink.Trash
            "transfer" -> DeepLink.Transfer
            else -> {
                Timber.tag(TAG).w("Unknown titan:// host: %s", host)
                null
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // EXTERNAL FILE PARSING
    // ═══════════════════════════════════════════════════════════════

    /**
     * Parse an `android.intent.action.VIEW` intent with a `file://` or `content://` URI.
     * The file is opened in the in-app viewer (image, video, audio, PDF, text).
     */
    private fun parseExternalFile(uri: Uri, mimeType: String?): DeepLink? {
        val path = resolveFilePath(uri) ?: run {
            Timber.tag(TAG).w("Could not resolve path for URI: %s", uri)
            return null
        }

        // Security: reject paths with traversal sequences
        if (path.contains("..")) {
            Timber.tag(TAG).w("Path traversal rejected: %s", path)
            return null
        }

        return DeepLink.Viewer(
            filePath = path,
            mimeType = mimeType,
            isFromExternalApp = true,
        )
    }

    /**
     * Parse an `android.intent.action.SEND` intent with a single file URI.
     * The file is imported into the user's chosen destination.
     */
    private fun parseShareSingle(intent: Intent): DeepLink? {
        val uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(Intent.EXTRA_STREAM) as? Uri
        } ?: return null

        val path = resolveFilePath(uri) ?: return null

        return DeepLink.ImportFiles(
            filePaths = listOf(path),
            sourceLabel = intent.getStringExtra(Intent.EXTRA_TITLE) ?: "Imported file",
        )
    }

    /**
     * Parse an `android.intent.action.SEND_MULTIPLE` intent with multiple file URIs.
     */
    private fun parseShareMultiple(intent: Intent): DeepLink? {
        val uris = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
        } else {
            @Suppress("DEPRECATION", "UNCHECKED_CAST")
            intent.getParcelableArrayListExtra<Parcelable>(Intent.EXTRA_STREAM)
                ?.filterIsInstance<Uri>()
        } ?: return null

        if (uris.isEmpty()) return null

        val paths = uris.mapNotNull { resolveFilePath(it) }
        if (paths.isEmpty()) return null

        return DeepLink.ImportFiles(
            filePaths = paths,
            sourceLabel = intent.getStringExtra(Intent.EXTRA_TITLE) ?: "Imported ${paths.size} files",
        )
    }

    // ═══════════════════════════════════════════════════════════════
    // NOTIFICATION TAP PARSING
    // ═══════════════════════════════════════════════════════════════

    /**
     * Parse a notification-tap intent with `EXTRA_DESTINATION` set.
     */
    private fun parseNotificationTap(intent: Intent): DeepLink? {
        val destination = intent.getStringExtra(EXTRA_DESTINATION) ?: return null
        val extras = intent.extras?.keyValueMap() ?: emptyMap()

        return when (destination) {
            "transfer" -> DeepLink.Transfer
            "vault" -> DeepLink.Vault
            "duplicates" -> DeepLink.Duplicates
            "analytics" -> DeepLink.Analytics
            "trash" -> DeepLink.Trash
            "search" -> DeepLink.Search(initialQuery = extras["query"].orEmpty())
            "viewer" -> extras["path"]?.let { DeepLink.Viewer(filePath = it) }
            else -> {
                Timber.tag(TAG).w("Unknown notification destination: %s", destination)
                null
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // HELPERS
    // ═══════════════════════════════════════════════════════════════

    /**
     * Resolve a `file://` or `content://` URI to a filesystem path.
     *
     * - `file://` URIs are decoded directly.
     * - `content://` URIs require MediaStore query — returns `null` on failure.
     */
    private fun resolveFilePath(uri: Uri): String? {
        return when (uri.scheme?.lowercase()) {
            "file" -> decodePath(uri.path ?: return null)
            "content" -> resolveContentUri(uri)
            else -> null
        }
    }

    /**
     * Resolve a `content://` URI to a filesystem path via MediaStore query.
     * Returns `null` if the URI doesn't have a filesystem backing (e.g.,
     * Google Drive virtual files).
     */
    private fun resolveContentUri(uri: Uri): String? {
        return try {
            val projection = arrayOf(android.provider.MediaStore.MediaColumns.DATA)
            context.contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val index = cursor.getColumnIndexOrThrow(android.provider.MediaStore.MediaColumns.DATA)
                    cursor.getString(index)
                } else null
            }
        } catch (e: Throwable) {
            Timber.tag(TAG).w(e, "Failed to resolve content URI: %s", uri)
            null
        }
    }

    /**
     * URL-decode a path string. Used for both `titan://` query parameters
     * and `file://` URI paths.
     */
    private fun decodePath(encoded: String): String {
        return try {
            URLDecoder.decode(encoded, "UTF-8")
        } catch (_: Throwable) {
            encoded
        }
    }

    /**
     * Convert a Bundle's key-value pairs to a Map<String, String>.
     * Used for [EXTRA_DESTINATION] extras.
     */
    private fun android.os.Bundle.keyValueMap(): Map<String, String> {
        val result = mutableMapOf<String, String>()
        keySet()?.forEach { key ->
            getString(key)?.let { value -> result[key] = value }
        }
        return result
    }

    companion object {
        private const val TAG = "DeepLinkHandler"

        /** Custom URI scheme for TitanFileManager deep links. */
        const val SCHEME_TITAN = "titan"

        /** File URI schemes accepted by [parseExternalFile]. */
        private val FILE_SCHEMES = setOf("file", "content")

        /** Intent extra key for notification tap destinations. */
        const val EXTRA_DESTINATION = "destination"

        /** Intent extra key for notification tap parameters. */
        const val EXTRA_PARAMS = "params"
    }
}

// ═══════════════════════════════════════════════════════════════
// DEEP LINK SEALED CLASS
// ═══════════════════════════════════════════════════════════════

/**
 * Sealed class representing all possible inbound deep links.
 *
 * Each variant maps to a specific navigation destination in [TitanNavHost].
 * Use [toNavRoute] to convert to a route string for `navController.navigate()`.
 */
@Immutable
sealed class DeepLink {

    /**
     * Convert this deep link to a TitanNavHost route string.
     * Returns `null` if the deep link doesn't map to a navigation route
     * (e.g., [ImportFiles] requires custom handling).
     */
    abstract fun toNavRoute(): String?

    // ═══════════════════════════════════════════════════════════════
    // TOP-LEVEL DESTINATIONS
    // ═══════════════════════════════════════════════════════════════

    /** Open the file browser, optionally at [initialPath]. */
    data class Browse(val initialPath: String? = null) : DeepLink() {
        override fun toNavRoute(): String = NavRoutes.BROWSER
    }

    /** Open the search screen with [initialQuery] pre-filled. */
    data class Search(val initialQuery: String = "") : DeepLink() {
        override fun toNavRoute(): String = NavRoutes.SEARCH
    }

    /** Open the secure vault. */
    data object Vault : DeepLink() {
        override fun toNavRoute(): String = NavRoutes.VAULT
    }

    /** Open the recent files screen. */
    data object Recent : DeepLink() {
        override fun toNavRoute(): String = NavRoutes.RECENT_FILES
    }

    /** Open the bookmarks screen. */
    data object Bookmarks : DeepLink() {
        override fun toNavRoute(): String = NavRoutes.BOOKMARKS
    }

    /** Open the storage analytics screen. */
    data object Analytics : DeepLink() {
        override fun toNavRoute(): String = NavRoutes.ANALYTICS
    }

    /** Open the settings screen. */
    data object Settings : DeepLink() {
        override fun toNavRoute(): String = NavRoutes.SETTINGS
    }

    /** Open the duplicate file finder. */
    data object Duplicates : DeepLink() {
        override fun toNavRoute(): String = NavRoutes.DUPLICATES
    }

    /** Open the trash screen. */
    data object Trash : DeepLink() {
        override fun toNavRoute(): String = NavRoutes.TRASH
    }

    /** Open the active transfers screen. */
    data object Transfer : DeepLink() {
        override fun toNavRoute(): String = NavRoutes.TRANSFER
    }

    // ═══════════════════════════════════════════════════════════════
    // DETAIL SCREEN DESTINATIONS
    // ═══════════════════════════════════════════════════════════════

    /** Open the file viewer for [filePath]. */
    data class Viewer(
        val filePath: String,
        val mimeType: String? = null,
        val isFromExternalApp: Boolean = false,
    ) : DeepLink() {
        override fun toNavRoute(): String = NavRoutes.viewerRoute(filePath)
    }

    // ═══════════════════════════════════════════════════════════════
    // SPECIAL — NOT A NAVIGATION DESTINATION
    // ═══════════════════════════════════════════════════════════════

    /**
     * Import one or more files shared from another app.
     *
     * This deep link requires custom handling — the app should show an
     * "Import to..." dialog asking where to save the files. The dialog
     * is shown by the [com.titan.filemanager.ui.import.ImportFilesDialog]
     * composable.
     */
    data class ImportFiles(
        val filePaths: List<String>,
        val sourceLabel: String,
    ) : DeepLink() {
        override fun toNavRoute(): String? = null
    }
}

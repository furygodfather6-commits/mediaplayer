package com.titan.filemanager.imaging

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.Size
import coil.decode.DataSource
import coil.fetch.FetchResult
import coil.fetch.Fetcher
import coil.fetch.SourceResult
import coil.key.Keyer
import coil.request.Options
import coil.size.Dimension
import coil.size.Precision
import com.titan.filemanager.core.common.logger.Logger
import com.titan.filemanager.core.common.logger.TimberLogger
import timber.log.Timber
import java.io.ByteArrayOutputStream
import java.io.File

/**
 * ## VideoFrameFetcher
 *
 * Custom Coil [Fetcher] that extracts a frame from a video file at a
 * specific timestamp (default: 1 second offset) and returns it as a bitmap.
 *
 * Used for video thumbnails in the file browser grid view.
 *
 * ### Why a custom fetcher?
 * Coil's default behavior for video files is to use `MediaMetadataRetriever`
 * via `VideoFrameDecoder`, but only for `Uri` data — not `File` data. Since
 * TitanFileManager loads thumbnails from file paths, we need a custom fetcher
 * that handles `File` directly.
 *
 * ### Frame extraction
 * The fetcher uses [MediaMetadataRetriever.getFrameAtTime] with the
 * `OPTION_CLOSEST_SYNC` flag at the configured timestamp (default 1s).
 * This gives us a key frame near the desired position, which is faster
 * than exact-frame extraction.
 *
 * ### Caching
 * The extracted bitmap is cached in Coil's memory + disk caches. The cache
 * key incorporates the file's mtime so changed videos get re-decoded.
 *
 * ### Performance
 * Frame extraction is CPU-intensive (~50-100ms per video). To avoid
 * blocking the main thread, the fetcher runs on Coil's IO dispatcher.
 */
class VideoFrameFetcher(
    private val file: File,
    private val context: Context,
    private val logger: Logger,
    private val frameTimeUs: Long = DEFAULT_FRAME_TIME_US,
) : Fetcher {

    override suspend fun fetch(): FetchResult {
        Timber.tag(TAG).d("Extracting video frame: %s @ %dus", file.absolutePath, frameTimeUs)

        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(file.absolutePath)

            // Check video duration — if shorter than frameTimeUs, use frame at 0
            val durationMs = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_DURATION,
            )?.toLongOrNull() ?: 0L

            val targetTimeUs = if (durationMs * 1000 < frameTimeUs) 0L else frameTimeUs

            val bitmap = retriever.getFrameAtTime(
                targetTimeUs,
                MediaMetadataRetriever.OPTION_CLOSEST_SYNC,
            ) ?: throw IllegalStateException("Failed to extract frame at ${targetTimeUs}us")

            // Convert bitmap to byte array for Coil's SourceFetchResult
            val outputStream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 85, outputStream)
            val bytes = outputStream.toByteArray()

            return SourceResult(
                source = coil.decode.ImageSource(
                    okio.Buffer().write(bytes),
                    file,
                ),
                mimeType = "image/jpeg",
                dataSource = DataSource.DISK,
            )
        } finally {
            retriever.release()
        }
    }

    /**
     * Factory that creates [VideoFrameFetcher] for video file extensions.
     */
    class Factory : Fetcher.Factory<File> {

        override fun create(data: File, options: Options, imageLoader: coil.ImageLoader): Fetcher? {
            if (!isVideoFile(data)) return null

            // Use injected logger if available, otherwise default to Timber-only
            val logger: Logger = TimberLogger()

            return VideoFrameFetcher(
                file = data,
                context = options.context,
                logger = logger,
                frameTimeUs = DEFAULT_FRAME_TIME_US,
            )
        }

        private fun isVideoFile(file: File): Boolean {
            val ext = file.extension.lowercase()
            return ext in VIDEO_EXTENSIONS
        }
    }

    companion object {
        private const val TAG = "VideoFrameFetcher"

        /** Default frame extraction time (1 second into the video). */
        private const val DEFAULT_FRAME_TIME_US = 1_000_000L

        /** Video file extensions that this fetcher handles. */
        private val VIDEO_EXTENSIONS = setOf(
            "mp4", "mkv", "avi", "mov", "webm", "3gp", "flv",
            "wmv", "m4v", "mpg", "mpeg", "ts", "vob",
        )
    }
}

/**
 * ## PdfPageFetcher
 *
 * Custom Coil [Fetcher] that renders page 0 of a PDF file as a bitmap.
 * Uses [android.graphics.pdf.PdfRenderer] (API 21+).
 *
 * ### Page selection
 * Always renders page 0 (first page) — this is the conventional thumbnail
 * for PDF documents.
 *
 * ### Render size
 * The page is rendered at the requested size from Coil (which derives from
 * the `Modifier.size()` of the AsyncImage). If no size is specified, defaults
 * to 512x512 (sufficient for thumbnails).
 *
 * ### Caching
 * Rendered page bitmaps are cached in Coil's memory + disk caches.
 */
class PdfPageFetcher(
    private val file: File,
    private val context: Context,
    private val logger: Logger,
) : Fetcher {

    override suspend fun fetch(): FetchResult {
        Timber.tag(TAG).d("Rendering PDF page 0: %s", file.absolutePath)

        val inputStream = java.io.FileInputStream(file)
        val pdfRenderer = android.graphics.pdf.PdfRenderer(
            android.os.ParcelFileDescriptor.dup(inputStream.fd),
        )

        try {
            val page = pdfRenderer.openPage(0)

            // Determine target dimensions
            val targetWidth = 512
            val targetHeight = (page.height.toFloat() / page.width * targetWidth).toInt()

            val bitmap = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888)
            bitmap.eraseColor(android.graphics.Color.WHITE) // White background for transparent PDFs

            page.render(bitmap, null, null, android.graphics.pdf.PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            page.close()

            val outputStream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 85, outputStream)
            val bytes = outputStream.toByteArray()
            bitmap.recycle()

            return SourceResult(
                source = coil.decode.ImageSource(
                    okio.Buffer().write(bytes),
                    file,
                ),
                mimeType = "image/jpeg",
                dataSource = DataSource.DISK,
            )
        } finally {
            pdfRenderer.close()
            inputStream.close()
        }
    }

    /**
     * Factory that creates [PdfPageFetcher] for PDF files.
     */
    class Factory : Fetcher.Factory<File> {

        override fun create(data: File, options: Options, imageLoader: coil.ImageLoader): Fetcher? {
            if (data.extension.lowercase() != "pdf") return null

            val logger: Logger = TimberLogger()

            return PdfPageFetcher(
                file = data,
                context = options.context,
                logger = logger,
            )
        }
    }

    companion object {
        private const val TAG = "PdfPageFetcher"
    }
}

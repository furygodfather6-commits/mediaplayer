package com.titan.filemanager.permission

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import com.titan.filemanager.core.common.logger.Logger
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * ## NotificationPermissionHandler
 *
 * Handles the Android 13+ `POST_NOTIFICATIONS` runtime permission, plus
 * creates all required notification channels for TitanFileManager.
 *
 * ### Background
 * Starting with Android 13 (API 33), apps must request the
 * `POST_NOTIFICATIONS` runtime permission before posting any notification.
 * Pre-Android-13 devices grant this permission at install time.
 *
 * ### Channels created
 *  - `channel_transfer` — File transfers (HIGH importance)
 *  - `channel_scan` — Scan progress (LOW importance)
 *  - `channel_vault` — Vault auto-lock (DEFAULT importance)
 *  - `channel_duplicate` — Duplicate finder results (DEFAULT importance)
 *  - `channel_backup` — Backup progress (LOW importance)
 *  - `channel_sync` — Cloud sync (LOW importance)
 *  - `channel_warning` — Warnings (HIGH importance)
 *
 * ### API surface
 *  - [createChannels] — call once from [TitanApplication.onCreate]
 *  - [isGranted] — check if notifications are allowed
 *  - [shouldShowRationale] — true if user denied once (we should explain why)
 *  - [requestPermission] — launches system permission dialog
 *  - [openAppNotificationSettings] — opens app-specific settings page
 *  - [permissionState] — StateFlow of [PermissionStatus] for UI observation
 *
 * ### Compose integration
 * Use [rememberNotificationPermissionState] in composables to track and
 * request the permission:
 * ```kotlin
 * val notifPermission = rememberNotificationPermissionState()
 * if (!notifPermission.isGranted && notifPermission.shouldRequest) {
 *     NotificationPermissionRationale(
 *         onGrant = { notifPermission.request() },
 *         onDismiss = { notifPermission.markRequested() },
 *     )
 * }
 * ```
 */
@Singleton
class NotificationPermissionHandler @Inject constructor(
    @ApplicationContext private val context: Context,
    private val logger: Logger,
) {

    /** Current permission status. */
    private val _permissionState = MutableStateFlow(determinePermissionStatus())
    val permissionState: StateFlow<PermissionStatus> = _permissionState.asStateFlow()

    /** Whether the user has been prompted at least once. */
    private val _hasPromptedOnce = MutableStateFlow(false)
    val hasPromptedOnce: StateFlow<Boolean> = _hasPromptedOnce.asStateFlow()

    /**
     * Create all notification channels required by TitanFileManager.
     *
     * Call this from [TitanApplication.onCreate] — channels are idempotent
     * (creating an existing channel is a no-op).
     */
    fun createChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return

        val nm = context.getSystemService(NotificationManager::class.java) ?: run {
            logger.w { "NotificationManager not available" }
            return
        }

        channelsToCreate().forEach { channel ->
            try {
                nm.createNotificationChannel(channel)
                logger.d { "Created channel: ${channel.id}" }
            } catch (e: Throwable) {
                logger.e(e) { "Failed to create channel ${channel.id}" }
            }
        }

        logger.i { "Notification channels created (${channelsToCreate().size} total)" }
    }

    /**
     * Whether notifications are currently allowed.
     *
     * On Android 13+ this checks `POST_NOTIFICATIONS` permission.
     * On older Android versions, always returns `true` (permission granted at install).
     */
    fun isGranted(): Boolean = _permissionState.value is PermissionStatus.Granted

    /**
     * Whether we should show a rationale dialog before requesting permission.
     * True only after the user has denied the permission at least once.
     */
    fun shouldShowRationale(activity: android.app.Activity): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return false
        return activity.shouldShowRequestPermissionRationale(
            android.Manifest.permission.POST_NOTIFICATIONS,
        )
    }

    /**
     * Update the cached permission status. Call this after returning from
     * the system permission dialog or Settings.
     */
    fun refresh() {
        _permissionState.value = determinePermissionStatus()
    }

    /**
     * Mark that we've prompted the user at least once. Used to suppress
     * auto-prompting on subsequent launches.
     */
    fun markPrompted() {
        _hasPromptedOnce.value = true
    }

    /**
     * Open the app's notification settings page in the system Settings app.
     * Used when the user has permanently denied permission (system dialog
     * won't show anymore).
     */
    fun openAppNotificationSettings(activity: android.app.Activity) {
        val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
            }
        } else {
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", context.packageName, null)
            }
        }
        runCatching {
            activity.startActivity(intent)
        }.onFailure { e ->
            logger.e(e) { "Failed to open notification settings" }
        }
    }

    /**
     * Delete a notification channel by ID. Used by the in-app channel management
     * screen (Settings → Notifications → Manage channels).
     */
    fun deleteChannel(channelId: String) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        runCatching {
            nm.deleteNotificationChannel(channelId)
            logger.i { "Deleted channel: $channelId" }
        }.onFailure { e ->
            logger.e(e) { "Failed to delete channel $channelId" }
        }
    }

    /**
     * Get all notification channels created by this app, sorted by importance
     * (HIGH → DEFAULT → LOW → MIN).
     */
    fun getChannels(): List<TitanNotificationChannel> {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return emptyList()
        val nm = context.getSystemService(NotificationManager::class.java) ?: return emptyList()
        return nm.notificationChannels
            .sortedByDescending { it.importance }
            .map { channel ->
                TitanNotificationChannel(
                    id = channel.id,
                    name = channel.name?.toString() ?: channel.id,
                    description = channel.description ?: "",
                    importance = channel.importance,
                    isVibrationEnabled = channel.shouldVibrate(),
                    isSoundEnabled = channel.sound != null,
                    isShowBadge = channel.canShowBadge(),
                )
            }
    }

    // ═══════════════════════════════════════════════════════════════
    // INTERNAL — CHANNEL DEFINITIONS
    // ═══════════════════════════════════════════════════════════════

    /**
     * All notification channels TitanFileManager creates. Channel IDs match
     * the resource IDs declared in `ints.xml` (notif_id_*).
     */
    private fun channelsToCreate(): List<NotificationChannel> {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return emptyList()

        return listOf(
            NotificationChannel(
                CHANNEL_TRANSFER,
                "File transfers",
                NotificationManager.IMPORTANCE_HIGH,
            ).apply {
                description = "Progress for active copy/move operations"
                enableVibration(true)
                setShowBadge(true)
            },

            NotificationChannel(
                CHANNEL_SCAN,
                "Scanning",
                NotificationManager.IMPORTANCE_LOW,
            ).apply {
                description = "Progress for file system scans"
                setShowBadge(false)
            },

            NotificationChannel(
                CHANNEL_VAULT,
                "Vault",
                NotificationManager.IMPORTANCE_DEFAULT,
            ).apply {
                description = "Notifies when vault is auto-locked"
                enableVibration(true)
                setShowBadge(true)
            },

            NotificationChannel(
                CHANNEL_DUPLICATE,
                "Duplicate finder",
                NotificationManager.IMPORTANCE_DEFAULT,
            ).apply {
                description = "Notifies when duplicate scan completes"
                setShowBadge(true)
            },

            NotificationChannel(
                CHANNEL_BACKUP,
                "Backup",
                NotificationManager.IMPORTANCE_LOW,
            ).apply {
                description = "Progress for cloud backups"
                setShowBadge(false)
            },

            NotificationChannel(
                CHANNEL_SYNC,
                "Sync",
                NotificationManager.IMPORTANCE_LOW,
            ).apply {
                description = "Progress for cloud sync"
                setShowBadge(false)
            },

            NotificationChannel(
                CHANNEL_WARNING,
                "Warnings",
                NotificationManager.IMPORTANCE_HIGH,
            ).apply {
                description = "Important warnings (low space, sync errors)"
                enableVibration(true)
                setShowBadge(true)
            },
        )
    }

    // ═══════════════════════════════════════════════════════════════
    // INTERNAL — PERMISSION CHECK
    // ═══════════════════════════════════════════════════════════════

    /**
     * Determine the current permission status by checking the system.
     */
    private fun determinePermissionStatus(): PermissionStatus {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            return PermissionStatus.Granted(preAndroid13 = true)
        }

        val granted = context.checkSelfPermission(
            android.Manifest.permission.POST_NOTIFICATIONS,
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED

        return if (granted) PermissionStatus.Granted(preAndroid13 = false)
               else PermissionStatus.Denied
    }

    companion object {
        private const val TAG = "NotifPermission"

        // Channel IDs — match the resource declarations
        const val CHANNEL_TRANSFER = "channel_transfer"
        const val CHANNEL_SCAN = "channel_scan"
        const val CHANNEL_VAULT = "channel_vault"
        const val CHANNEL_DUPLICATE = "channel_duplicate"
        const val CHANNEL_BACKUP = "channel_backup"
        const val CHANNEL_SYNC = "channel_sync"
        const val CHANNEL_WARNING = "channel_warning"
    }
}

// ═══════════════════════════════════════════════════════════════
// PERMISSION STATUS
// ═══════════════════════════════════════════════════════════════

/**
 * Status of the POST_NOTIFICATIONS permission.
 */
sealed class PermissionStatus {

    /**
     * Permission is granted.
     *
     * @param preAndroid13 true if running on Android < 13 (no runtime permission needed).
     */
    data class Granted(val preAndroid13: Boolean) : PermissionStatus()

    /**
     * Permission is denied. The user may have denied it once, permanently
     * denied it, or hasn't been prompted yet.
     */
    data object Denied : PermissionStatus()
}

/**
 * Lightweight info about a notification channel — used by the in-app
 * channel management screen.
 */
data class TitanNotificationChannel(
    val id: String,
    val name: String,
    val description: String,
    val importance: Int,
    val isVibrationEnabled: Boolean,
    val isSoundEnabled: Boolean,
    val isShowBadge: Boolean,
)

// ═══════════════════════════════════════════════════════════════
// COMPOSE INTEGRATION
// ═══════════════════════════════════════════════════════════════

/**
 * Compose-friendly holder for notification permission state.
 *
 * Tracks whether permission is granted, exposes a [request] action that
 * launches the system permission dialog, and a [openSettings] action
 * that opens the system Settings page.
 *
 * Usage:
 * ```kotlin
 * val notifPermission = rememberNotificationPermissionState()
 *
 * when {
 *     notifPermission.isGranted -> { /* show notifications */ }
 *     notifPermission.shouldShowRationale -> {
 *         NotificationRationale(
 *             onGrant = { notifPermission.request() },
 *             onDismiss = { /* skip */ },
 *         )
 *     }
 *     else -> notifPermission.request()
 * }
 * ```
 */
@Stable
class NotificationPermissionState(
    private val context: Context,
    private val handler: NotificationPermissionHandler?,
    private val launchPermissionRequest: () -> Unit,
    private val launchSettings: () -> Unit,
) {

    private var _isGranted by mutableStateOf(checkGranted())
    val isGranted: Boolean get() = _isGranted

    private var _hasRequestedOnce by mutableStateOf(false)
    val hasRequestedOnce: Boolean get() = _hasRequestedOnce

    /**
     * True if we should show a rationale dialog before requesting permission.
     * On pre-Android-13 devices, this is always false.
     */
    val shouldShowRationale: Boolean
        get() = handler != null &&
                context is android.app.Activity &&
                handler.shouldShowRationale(context)

    /**
     * Whether we should auto-request permission on first launch.
     * False if user has already been prompted once.
     */
    val shouldAutoRequest: Boolean
        get() = !isGranted && !_hasRequestedOnce && handler != null

    /**
     * Refresh the [isGranted] state — call after returning from the
     * system permission dialog or Settings.
     */
    fun refresh() {
        _isGranted = checkGranted()
        handler?.refresh()
    }

    /**
     * Launch the system permission dialog. If the user has permanently
     * denied permission, this is a no-op — use [openSettings] instead.
     */
    fun request() {
        _hasRequestedOnce = true
        handler?.markPrompted()
        launchPermissionRequest()
    }

    /**
     * Open the app's notification settings page in the system Settings app.
     */
    fun openSettings() {
        handler?.let { h ->
            (context as? android.app.Activity)?.let { h.openAppNotificationSettings(it) }
        } ?: launchSettings()
    }

    private fun checkGranted(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return true
        return context.checkSelfPermission(
            android.Manifest.permission.POST_NOTIFICATIONS,
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
    }
}

/**
 * Composable factory for [NotificationPermissionState].
 *
 * Wires up the [ActivityResultContracts.RequestPermission] launcher
 * for the POST_NOTIFICATIONS permission.
 */
@Composable
fun rememberNotificationPermissionState(
    handler: NotificationPermissionHandler? = null,
): NotificationPermissionState {
    val context = LocalContext.current

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { _ ->
        // Re-check status after the user responds
        // (refresh() is called by the caller via Lifecycle observer)
    }

    val settingsLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) { _ ->
        // Re-check status after returning from Settings
    }

    val state = remember(context, handler) {
        NotificationPermissionState(
            context = context,
            handler = handler,
            launchPermissionRequest = {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    permissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                }
            },
            launchSettings = {
                val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                        putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                    }
                } else {
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                        data = Uri.fromParts("package", context.packageName, null)
                    }
                }
                runCatching { settingsLauncher.launch(intent) }
            },
        )
    }

    // Refresh on every composition (cheap — just a PackageManager check)
    LaunchedEffect(Unit) { state.refresh() }

    return state
}

package com.titan.filemanager.ui.screens

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.domain.search.SearchQuery
import com.titan.filemanager.domain.search.SearchRepository
import com.titan.filemanager.domain.search.SearchType
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * ViewModel for the Search Results Grid screen.
 *
 * Previously the SearchResultsGridScreen was wired with
 * `results = emptyList()` — the screen always showed "no results"
 * even when the user navigated from a search query. This VM actually
 * runs the search via [SearchRepository] and exposes the results
 * reactively.
 */
@HiltViewModel
class SearchResultsViewModel @Inject constructor(
    private val searchRepository: SearchRepository,
    savedStateHandle: SavedStateHandle,
) : ViewModel() {

    private val query: String = savedStateHandle.get<String>("query") ?: ""

    private val _results = MutableStateFlow<List<FileItem>>(emptyList())
    val results: StateFlow<List<FileItem>> = _results.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    init {
        if (query.isNotBlank()) {
            search()
        }
    }

    private fun search() {
        viewModelScope.launch {
            _isSearching.value = true
            try {
                searchRepository.search(
                    SearchQuery(text = query, type = SearchType.PREFIX, maxResults = 200),
                ).collectLatest { searchResult ->
                    // Accumulate results — the flow emits multiple
                    // times as each backend (trie, fulltext, fs scan)
                    // contributes results.
                    val current = _results.value.toMutableList()
                    if (current.none { it.path == searchResult.file.path }) {
                        current.add(searchResult.file)
                        _results.value = current
                    }
                }
            } finally {
                _isSearching.value = false
            }
        }
    }
}

package com.titan.filemanager.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.remember
import androidx.navigation.NavController
import androidx.navigation.NavDestination
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.currentBackStackEntryAsState
import com.titan.filemanager.core.navigation.NavRoutes
import com.titan.filemanager.core.navigation.TopLevelDestination
import com.titan.filemanager.deeplink.DeepLink
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Holder for app-level UI state + navigation helpers.
 *
 * ═══════════════════════════════════════════════════════════
 * RESPONSIBILITIES
 * ═══════════════════════════════════════════════════════════
 *
 *  1. **Track current destination** — exposes the current route so the
 *     bottom bar can highlight the active tab.
 *
 *  2. **Bottom bar visibility** — decides whether to show the bottom nav
 *     based on the current route (hidden on detail/modal/boot screens).
 *
 *  3. **Top-level navigation** — provides `navigateToTopLevelDestination`
 *     with the recommended Material 3 back-stack pattern (pop-up to start,
 *     save state, restore state, avoid duplicate launches).
 *
 *  4. **Detail navigation helpers** — convenience methods for navigating
 *     to detail screens with encoded path arguments.
 *
 * ═══════════════════════════════════════════════════════════
 * USAGE
 * ═══════════════════════════════════════════════════════════
 *
 * ```kotlin
 * val navController = rememberNavController()
 * val appState = remember(navController) { TitanAppState(navController) }
 *
 * // Navigate to a top-level tab
 * appState.navigateToTopLevelDestination(TopLevelDestination.SEARCH)
 *
 * // Navigate to file viewer
 * appState.navigateToViewer("/sdcard/photo.jpg")
 *
 * // Navigate to cloud browser
 * appState.navigateToCloudBrowser("google_drive", "/")
 *
 * // Check if bottom bar should show
 * if (appState.shouldShowBottomBar) { ... }
 * ```
 */
@Stable
class TitanAppState(
    val navController: NavController,
) {

    // ═══════════════════════════════════════════════════════════
    // CURRENT DESTINATION
    // ═══════════════════════════════════════════════════════════

    /** The current [NavDestination] — null during composition transitions. */
    val currentDestination: NavDestination?
        @Composable get() = navController
            .currentBackStackEntryAsState().value?.destination

    /** The current route string — null if no destination. */
    val currentRoute: String?
        @Composable get() = currentDestination?.route

    /** The current [TopLevelDestination] — null for detail/modal screens. */
    val currentTopLevelDestination: TopLevelDestination?
        @Composable get() = TopLevelDestination.fromRoute(currentRoute)

    // ═══════════════════════════════════════════════════════════
    // BOTTOM BAR VISIBILITY
    // ═══════════════════════════════════════════════════════════

    /** Whether the bottom navigation bar should be visible. */
    val shouldShowBottomBar: Boolean
        @Composable get() = NavRoutes.shouldShowBottomBar(currentRoute)

    // ═══════════════════════════════════════════════════════════
    // TOP-LEVEL NAVIGATION
    // ═══════════════════════════════════════════════════════════

    /**
     * Navigate to a top-level destination with the recommended Material 3
     * back-stack pattern:
     *
     *  1. Pop up to the start destination, saving state.
     *  2. Avoid duplicate launches (`launchSingleTop = true`).
     *  3. Restore state for the destination.
     *
     * This way, switching tabs preserves each tab's scroll position and
     * back-stack — feels like a real native app.
     */
    fun navigateToTopLevelDestination(destination: TopLevelDestination) {
        navController.navigate(destination.route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    // ═══════════════════════════════════════════════════════════
    // DETAIL NAVIGATION — with encoded path arguments
    // ═══════════════════════════════════════════════════════════

    /** Navigate to the file viewer with a file path. */
    fun navigateToViewer(filePath: String) {
        navController.navigate(NavRoutes.viewerRoute(filePath))
    }

    /** Navigate to the archive browser with an archive path. */
    fun navigateToArchive(archivePath: String) {
        navController.navigate(NavRoutes.archiveRoute(archivePath))
    }

    /** Navigate to the cloud auth screen for a provider. */
    fun navigateToCloudAuth(providerId: String) {
        navController.navigate(NavRoutes.cloudAuthRoute(providerId))
    }

    /** Navigate to the cloud file browser for a provider and path. */
    fun navigateToCloudBrowser(providerId: String, path: String) {
        navController.navigate(NavRoutes.cloudBrowserRoute(providerId, path))
    }

    /** Navigate to the duplicate detail screen for a group. */
    fun navigateToDuplicateDetail(groupId: String) {
        navController.navigate(NavRoutes.duplicateDetailRoute(groupId))
    }

    // ═══════════════════════════════════════════════════════════
    // DETAIL NAVIGATION — no arguments
    // ═══════════════════════════════════════════════════════════

    fun navigateToBrowser() { navController.navigate(NavRoutes.BROWSER) }
    fun navigateToSearch() { navController.navigate(NavRoutes.SEARCH) }
    fun navigateToTransfer() { navController.navigate(NavRoutes.TRANSFER) }
    fun navigateToVault() { navController.navigate(NavRoutes.VAULT) }
    fun navigateToTrash() { navController.navigate(NavRoutes.TRASH) }
    fun navigateToDuplicates() { navController.navigate(NavRoutes.DUPLICATES) }
    fun navigateToAnalytics() { navController.navigate(NavRoutes.ANALYTICS) }
    fun navigateToAnalyticsDetail() { navController.navigate(NavRoutes.ANALYTICS_DETAIL) }
    fun navigateToStorageOverview() { navController.navigate(NavRoutes.STORAGE_OVERVIEW) }
    fun navigateToBookmarks() { navController.navigate(NavRoutes.BOOKMARKS) }
    fun navigateToRecentFiles() { navController.navigate(NavRoutes.RECENT_FILES) }
    fun navigateToHiddenFiles() { navController.navigate(NavRoutes.HIDDEN_FILES) }
    fun navigateToSearchFilter() { navController.navigate(NavRoutes.SEARCH_FILTER) }
    fun navigateToSettingsAbout() { navController.navigate(NavRoutes.SETTINGS_ABOUT) }
    fun navigateToSettingsStorage() { navController.navigate(NavRoutes.SETTINGS_STORAGE) }
    fun navigateToSettingsAppearance() { navController.navigate(NavRoutes.SETTINGS_APPEARANCE) }
    fun navigateToTagManager() { navController.navigate(NavRoutes.TAG_MANAGER) }
    fun navigateToSearchResults(query: String) { navController.navigate(NavRoutes.searchResultsRoute(query)) }

    // ═══════════════════════════════════════════════════════════
    // DEEP LINK DISPATCH
    // ═══════════════════════════════════════════════════════════

    /**
     * Pending deep link to process — set by [dispatchDeepLink], consumed by TitanApp.
     *
     * The TitanApp composable observes this StateFlow and calls [consumePendingDeepLink]
     * when a new deep link arrives, navigating to the corresponding screen.
     */
    private val _pendingDeepLink = MutableStateFlow<DeepLink?>(null)
    val pendingDeepLink: StateFlow<DeepLink?> = _pendingDeepLink.asStateFlow()

    /**
     * Dispatch a deep link for processing.
     * Called by MainActivity when an intent is received.
     *
     * The deep link is stored in [pendingDeepLink] — TitanApp observes
     * this flow and navigates to the corresponding route when the
     * NavController is ready.
     */
    fun dispatchDeepLink(deepLink: DeepLink) {
        _pendingDeepLink.value = deepLink
    }

    /**
     * Consume and process the pending deep link.
     * Called by TitanApp after the NavController is ready.
     *
     * Returns true if a navigation was performed, false if the deep link
     * requires custom handling (e.g., ImportFiles shows a dialog).
     */
    fun consumePendingDeepLink(): Boolean {
        val deepLink = _pendingDeepLink.value ?: return false
        _pendingDeepLink.value = null

        val route = deepLink.toNavRoute()
        if (route != null) {
            navController.navigate(route)
            return true
        }

        // Special deep links that require custom handling
        return when (deepLink) {
            is DeepLink.ImportFiles -> {
                // Navigate to the ImportFilesDialog route with encoded paths + label
                val importRoute = NavRoutes.importFilesRoute(deepLink.filePaths, deepLink.sourceLabel)
                navController.navigate(importRoute)
                true
            }
            else -> false
        }
    }

    // ═══════════════════════════════════════════════════════════
    // BACK NAVIGATION
    // ═══════════════════════════════════════════════════════════

    /** Pop the back stack — returns to the previous screen. */
    fun navigateBack() {
        navController.popBackStack()
    }

    /** Pop the back stack to a specific route. Returns false if route not in stack. */
    fun navigateBackTo(route: String): Boolean {
        return navController.popBackStack(route, inclusive = false)
    }

    /** Pop all the way to the start destination (Home). */
    fun navigateHome() {
        navController.popBackStack(navController.graph.findStartDestination().id, false)
    }
}

/** Remember a [TitanAppState] tied to a [NavController]. */
@Composable
fun rememberTitanAppState(navController: NavController): TitanAppState {
    return remember(navController) { TitanAppState(navController) }
}

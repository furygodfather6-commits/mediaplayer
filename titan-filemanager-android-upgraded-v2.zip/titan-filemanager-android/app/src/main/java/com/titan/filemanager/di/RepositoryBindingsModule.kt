package com.titan.filemanager.di

import android.content.Context
import com.titan.filemanager.core.ui.contracts.AppLockContract
import com.titan.filemanager.core.ui.contracts.BookmarksContract
import com.titan.filemanager.core.ui.contracts.CloudBrowserContract
import com.titan.filemanager.core.ui.contracts.CloudTransferCallback
import com.titan.filemanager.core.ui.contracts.DuplicatesContract
import com.titan.filemanager.core.ui.contracts.PreferencesContract
import com.titan.filemanager.core.ui.contracts.RecentFilesContract
import com.titan.filemanager.core.ui.contracts.UiBookmark
import com.titan.filemanager.core.ui.contracts.UiCloudFile
import com.titan.filemanager.core.ui.contracts.UiDuplicateFile
import com.titan.filemanager.core.ui.contracts.UiRecentFile
import com.titan.filemanager.domain.bookmark.BookmarkRepository
import com.titan.filemanager.domain.preferences.PreferencesRepository
import com.titan.filemanager.domain.recent.RecentFileRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.io.File
import java.security.MessageDigest
import javax.inject.Inject
import javax.inject.Singleton

/**
 * ## RepositoryBindingsModule
 *
 * Hilt module that binds the abstract contracts declared in
 * `core-ui/.../contracts/RepositoryContracts.kt` to concrete
 * implementations that adapt the domain repositories.
 *
 * ### Why this module exists
 * core-ui cannot depend on the `:domain` module (circular dependency).
 * Instead, core-ui declares minimal contract interfaces, and this
 * module (in `:app`) provides adapter implementations that bridge
 * the domain repositories to the contracts.
 *
 * ### Binding strategy
 * For each contract, we provide a `@Singleton` adapter class via
 * `@Provides`. The adapter injects the domain repository and
 * translates between domain types and core-ui types.
 *
 * ### Contracts bound
 *  - [PreferencesContract] → adapts [PreferencesRepository]
 *  - [BookmarksContract] → adapts [BookmarkRepository]
 *  - [RecentFilesContract] → adapts [RecentFileRepository]
 *  - [AppLockContract] → standalone impl using EncryptedSharedPreferences
 *  - [CloudBrowserContract] → stub impl (cloud providers not yet wired)
 *  - [DuplicatesContract] → stub impl (uses real SHA-256 hashing)
 */
@Module
@InstallIn(SingletonComponent::class)
object RepositoryBindingsModule {

    // ═══════════════════════════════════════════════════════════════
    // PREFERENCES CONTRACT
    // ═══════════════════════════════════════════════════════════════

    @Provides
    @Singleton
    fun providePreferencesContract(
        @ApplicationContext context: Context,
        preferencesRepository: PreferencesRepository,
    ): PreferencesContract = PreferencesContractAdapter(context, preferencesRepository)

    // ═══════════════════════════════════════════════════════════════
    // BOOKMARKS CONTRACT
    // ═══════════════════════════════════════════════════════════════

    @Provides
    @Singleton
    fun provideBookmarksContract(
        bookmarkRepository: BookmarkRepository,
    ): BookmarksContract = BookmarksContractAdapter(bookmarkRepository)

    // ═══════════════════════════════════════════════════════════════
    // RECENT FILES CONTRACT
    // ═══════════════════════════════════════════════════════════════

    @Provides
    @Singleton
    fun provideRecentFilesContract(
        recentFileRepository: RecentFileRepository,
    ): RecentFilesContract = RecentFilesContractAdapter(recentFileRepository)

    // ═══════════════════════════════════════════════════════════════
    // APP LOCK CONTRACT — uses EncryptedSharedPreferences
    // ═══════════════════════════════════════════════════════════════

    @Provides
    @Singleton
    fun provideAppLockContract(
        @ApplicationContext context: Context,
    ): AppLockContract = AppLockContractAdapter(context)

    // ═══════════════════════════════════════════════════════════════
    // DUPLICATES CONTRACT — uses real SHA-256 hashing
    // ═══════════════════════════════════════════════════════════════

    @Provides
    @Singleton
    fun provideDuplicatesContract(): DuplicatesContract = DuplicatesContractAdapter()

    // ═══════════════════════════════════════════════════════════════
    // CLOUD BROWSER CONTRACT — stub (cloud providers not yet wired)
    // ═══════════════════════════════════════════════════════════════

    @Provides
    @Singleton
    fun provideCloudBrowserContract(): CloudBrowserContract = CloudBrowserContractAdapter()
}

// ═══════════════════════════════════════════════════════════════
// ADAPTER IMPLEMENTATIONS
// ═══════════════════════════════════════════════════════════════

/**
 * Adapter that exposes [PreferencesRepository] as [PreferencesContract].
 *
 * The domain PreferencesRepository doesn't have explicit `hasSeenOnboarding`
 * or `isAppLockEnabled` fields — they're stored via SharedPreferences
 * directly. This adapter bridges the gap by reading/writing those specific
 * flags to a dedicated SharedPreferences file.
 */
@Singleton
class PreferencesContractAdapter @Inject constructor(
    @ApplicationContext private val context: Context,
    private val preferencesRepository: PreferencesRepository,
) : PreferencesContract {

    private val prefs by lazy {
        context.getSharedPreferences("titan_app_state", Context.MODE_PRIVATE)
    }

    override fun observeHasSeenOnboarding(): Flow<Boolean> = kotlinx.coroutines.flow.flow {
        emit(prefs.getBoolean(KEY_ONBOARDING_SEEN, false))
    }

    override fun observeIsAppLockEnabled(): Flow<Boolean> = kotlinx.coroutines.flow.flow {
        emit(prefs.getBoolean(KEY_APP_LOCK_ENABLED, false))
    }

    override suspend fun getAppLockPin(): String? {
        return prefs.getString(KEY_APP_LOCK_PIN, null)
    }

    override suspend fun setHasSeenOnboarding(seen: Boolean) {
        prefs.edit().putBoolean(KEY_ONBOARDING_SEEN, seen).apply()
    }

    override suspend fun setAppLockEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_APP_LOCK_ENABLED, enabled).apply()
    }

    override suspend fun setAppLockPin(pin: String?) {
        prefs.edit().putString(KEY_APP_LOCK_PIN, pin).apply()
    }

    companion object {
        private const val KEY_ONBOARDING_SEEN = "has_seen_onboarding"
        private const val KEY_APP_LOCK_ENABLED = "app_lock_enabled"
        private const val KEY_APP_LOCK_PIN = "app_lock_pin"
    }
}

/**
 * Adapter that exposes [BookmarkRepository] as [BookmarksContract].
 */
@Singleton
class BookmarksContractAdapter @Inject constructor(
    private val bookmarkRepository: BookmarkRepository,
) : BookmarksContract {

    override fun observeBookmarks(): Flow<List<UiBookmark>> =
        bookmarkRepository.observeBookmarks().map { bookmarks ->
            bookmarks.map { it.toUiBookmark() }
        }

    override suspend fun getBookmarks(): List<UiBookmark> =
        bookmarkRepository.getBookmarks().map { it.toUiBookmark() }

    override suspend fun addBookmark(path: String, displayName: String): Long {
        bookmarkRepository.addBookmark(path, displayName)
        return System.currentTimeMillis() // Synthetic ID — real ID comes from reactive observer
    }

    override suspend fun removeBookmark(id: Long) {
        // Domain repo uses path, not ID — find the bookmark first
        val bookmarks = bookmarkRepository.getBookmarks()
        val target = bookmarks.find { it.id == id }
        if (target != null) {
            bookmarkRepository.removeBookmark(target.path)
        }
    }

    override suspend fun renameBookmark(id: Long, newName: String) {
        // Domain repo doesn't have rename — remove + re-add
        val bookmarks = bookmarkRepository.getBookmarks()
        val target = bookmarks.find { it.id == id }
        if (target != null) {
            bookmarkRepository.removeBookmark(target.path)
            bookmarkRepository.addBookmark(target.path, newName)
        }
    }

    override suspend fun reorder(bookmarkIds: List<Long>) {
        bookmarkRepository.reorder(bookmarkIds)
    }

    private fun com.titan.filemanager.domain.bookmark.Bookmark.toUiBookmark(): UiBookmark {
        val file = File(path)
        return UiBookmark(
            id = id,
            name = displayName.ifBlank { file.name },
            path = path,
            isFolder = file.isDirectory,
            sortOrder = sortOrder,
        )
    }
}

/**
 * Adapter that exposes [RecentFileRepository] as [RecentFilesContract].
 */
@Singleton
class RecentFilesContractAdapter @Inject constructor(
    private val recentFileRepository: RecentFileRepository,
) : RecentFilesContract {

    override fun observeRecent(limit: Int): Flow<List<UiRecentFile>> =
        recentFileRepository.observeRecent(limit).map { files ->
            files.map { it.toUiRecentFile() }
        }

    override suspend fun getRecent(limit: Int): List<UiRecentFile> =
        recentFileRepository.getRecent(limit).map { it.toUiRecentFile() }

    override suspend fun recordAccess(path: String, name: String, mimeType: String?) {
        recentFileRepository.recordAccess(path, name, mimeType)
    }

    override suspend fun removeRecent(path: String) {
        recentFileRepository.removeRecent(path)
    }

    override suspend fun clearAll() {
        recentFileRepository.clearAll()
    }

    private fun com.titan.filemanager.domain.recent.RecentFile.toUiRecentFile(): UiRecentFile {
        val file = File(path)
        return UiRecentFile(
            name = name,
            path = path,
            size = file.length(),
            modifiedAt = lastAccessedAt,
            isDirectory = file.isDirectory,
        )
    }
}

/**
 * Adapter for [AppLockContract] — uses EncryptedSharedPreferences for PIN
 * storage and BiometricManager for biometric availability checks.
 *
 * Security features:
 *  - PIN stored via EncryptedSharedPreferences (AES-256-GCM at rest)
 *  - BiometricManager.canAuthenticate() checks for fingerprint/face
 *  - Constant-time PIN comparison to prevent timing attacks
 */
@Singleton
class AppLockContractAdapter @Inject constructor(
    private val context: Context,
) : AppLockContract {

    /**
     * Lazily-created EncryptedSharedPreferences for secure PIN storage.
     * Uses AES-256-GCM for values and AES-256-SIV for keys.
     * Falls back to plain SharedPreferences if EncryptedSharedPreferences
     * fails (e.g., on corrupted state after factory reset).
     */
    private val prefs by lazy {
        try {
            androidx.security.crypto.EncryptedSharedPreferences.create(
                context,
                "app_lock_encrypted",
                androidx.security.crypto.MasterKey.Builder(context)
                    .setKeyScheme(androidx.security.crypto.MasterKey.KeyScheme.AES256_GCM)
                    .build(),
                androidx.security.crypto.EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                androidx.security.crypto.EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
            )
        } catch (_: Throwable) {
            // Fallback: plain SharedPreferences (better than crashing)
            context.getSharedPreferences("app_lock", Context.MODE_PRIVATE)
        }
    }

    override suspend fun isAppLockEnabled(): Boolean {
        return prefs.getBoolean(KEY_LOCK_ENABLED, false)
    }

    /**
     * Check if biometric authentication (fingerprint/face) is available
     * on this device using BiometricManager.canAuthenticate().
     *
     * Returns true only if BIOMETRIC_STRONG or BIOMETRIC_WEAK is available.
     */
    override suspend fun isBiometricAvailable(): Boolean {
        return try {
            val biometricManager = androidx.biometric.BiometricManager.from(context)
            val authenticators = androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG or
                androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK
            biometricManager.canAuthenticate(authenticators) == androidx.biometric.BiometricManager.BIOMETRIC_SUCCESS
        } catch (_: Throwable) {
            false
        }
    }

    override suspend fun verifyPin(enteredPin: String): Boolean {
        val storedPin = prefs.getString(KEY_PIN, null) ?: return false
        // Constant-time comparison to prevent timing attacks
        return constantTimeEquals(enteredPin, storedPin)
    }

    override suspend fun setPin(pin: String) {
        prefs.edit().putString(KEY_PIN, pin).putBoolean(KEY_LOCK_ENABLED, true).apply()
    }

    override suspend fun clearPin() {
        prefs.edit().remove(KEY_PIN).putBoolean(KEY_LOCK_ENABLED, false).apply()
    }

    private fun constantTimeEquals(a: String, b: String): Boolean {
        if (a.length != b.length) return false
        var result = 0
        for (i in a.indices) {
            result = result or (a[i].code xor b[i].code)
        }
        return result == 0
    }

    companion object {
        private const val KEY_PIN = "pin"
        private const val KEY_LOCK_ENABLED = "lock_enabled"
    }
}

/**
 * Adapter for [DuplicatesContract] — uses real SHA-256 hashing for
 * duplicate verification. The actual duplicate group loading is a
 * stub until the DuplicateDetectionEngine is wired from data-future-advanced.
 */
@Singleton
class DuplicatesContractAdapter @Inject constructor() : DuplicatesContract {

    override suspend fun getDuplicateGroup(groupId: String): List<UiDuplicateFile> {
        // Stub: return empty list — real impl will query DuplicateDetectionEngine
        // The DuplicateDetailScreen handles empty state gracefully
        return emptyList()
    }

    override suspend fun deleteFile(path: String, expectedHash: String): Boolean {
        return try {
            val file = File(path)
            if (!file.exists()) return false

            // Verify hash before deletion
            val actualHash = computeSha256(file)
            if (actualHash != expectedHash) return false

            file.delete()
        } catch (_: Throwable) {
            false
        }
    }

    override suspend fun markAsKept(path: String) {
        // Stub: real impl will persist "kept" flag to database
        // so the duplicate scanner skips this file in future scans
    }

    private fun computeSha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(8192)
            var read: Int
            while (input.read(buffer).also { read = it } > 0) {
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}

/**
 * Adapter for [CloudBrowserContract] — stub implementation.
 *
 * Cloud provider integration (Google Drive, Dropbox, OneDrive) is not
 * yet wired. This adapter returns empty lists and no-op transfers
 * until the data-sync module provides real cloud API calls.
 */
@Singleton
class CloudBrowserContractAdapter @Inject constructor() : CloudBrowserContract {

    override fun observeFiles(providerId: String, path: String): Flow<List<UiCloudFile>> {
        return kotlinx.coroutines.flow.flowOf(emptyList())
    }

    override suspend fun listFiles(providerId: String, path: String): List<UiCloudFile> {
        // Stub: return empty list — real impl will call cloud provider API
        return emptyList()
    }

    override suspend fun downloadFile(
        providerId: String,
        file: UiCloudFile,
        callback: CloudTransferCallback,
    ) {
        // Stub: immediately report failure
        callback.onComplete(false, "Cloud providers not yet configured")
    }

    override suspend fun uploadFile(
        providerId: String,
        localPath: String,
        remotePath: String,
        callback: CloudTransferCallback,
    ) {
        // Stub: immediately report failure
        callback.onComplete(false, "Cloud providers not yet configured")
    }
}

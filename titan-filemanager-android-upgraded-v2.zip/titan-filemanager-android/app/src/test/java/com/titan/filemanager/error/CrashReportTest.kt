package com.titan.filemanager.error

import com.google.common.truth.Truth.assertThat
import org.junit.Test

/**
 * ## CrashReportTest
 *
 * Unit tests for [CrashReport] data class. Verifies:
 *  - `capture()` extracts exception + thread + system info correctly
 *  - `toPlainText()` produces a human-readable crash report
 *  - `summary()` produces a one-line summary for notifications
 *  - Fatal vs non-fatal classification
 */
class CrashReportTest {

    @Test
    fun `capture extracts exception class name`() {
        val exception = NullPointerException("value was null")
        val report = CrashReport.capture(
            thread = Thread.currentThread(),
            throwable = exception,
            isFatal = true,
            appVersionName = "1.0.0",
            appVersionCode = 1L,
            buildType = "debug",
            processName = "com.titan.filemanager",
        )

        assertThat(report.exceptionClass).isEqualTo("java.lang.NullPointerException")
        assertThat(report.exceptionMessage).isEqualTo("value was null")
    }

    @Test
    fun `capture marks fatal flag correctly`() {
        val fatalReport = CrashReport.capture(
            thread = Thread.currentThread(),
            throwable = RuntimeException("test"),
            isFatal = true,
            appVersionName = "1.0.0",
            appVersionCode = 1L,
            buildType = "debug",
            processName = "com.titan.filemanager",
        )
        assertThat(fatalReport.isFatal).isTrue()

        val nonFatalReport = CrashReport.capture(
            thread = Thread.currentThread(),
            throwable = RuntimeException("test"),
            isFatal = false,
            appVersionName = "1.0.0",
            appVersionCode = 1L,
            buildType = "debug",
            processName = "com.titan.filemanager",
        )
        assertThat(nonFatalReport.isFatal).isFalse()
    }

    @Test
    fun `capture extracts thread info`() {
        val testThread = Thread.currentThread()
        testThread.name = "TestThread-123"

        val report = CrashReport.capture(
            thread = testThread,
            throwable = Exception("test"),
            isFatal = false,
            appVersionName = "1.0.0",
            appVersionCode = 1L,
            buildType = "debug",
            processName = "com.titan.filemanager",
        )

        assertThat(report.threadName).isEqualTo("TestThread-123")
        assertThat(report.threadPriority).isEqualTo(testThread.priority)
        assertThat(report.threadId).isEqualTo(testThread.id)
    }

    @Test
    fun `capture extracts app version info`() {
        val report = CrashReport.capture(
            thread = Thread.currentThread(),
            throwable = Exception("test"),
            isFatal = false,
            appVersionName = "2.5.0",
            appVersionCode = 250L,
            buildType = "release",
            processName = "com.titan.filemanager",
        )

        assertThat(report.appVersionName).isEqualTo("2.5.0")
        assertThat(report.appVersionCode).isEqualTo(250L)
        assertThat(report.buildType).isEqualTo("release")
        assertThat(report.processName).isEqualTo("com.titan.filemanager")
    }

    @Test
    fun `capture includes stack trace`() {
        val exception = RuntimeException("test error")
        val report = CrashReport.capture(
            thread = Thread.currentThread(),
            throwable = exception,
            isFatal = true,
            appVersionName = "1.0.0",
            appVersionCode = 1L,
            buildType = "debug",
            processName = "com.titan.filemanager",
        )

        assertThat(report.stackTrace).isNotEmpty()
        assertThat(report.stackTrace).contains("RuntimeException")
        assertThat(report.stackTrace).contains("test error")
    }

    @Test
    fun `capture preserves custom data`() {
        val customData = mapOf(
            "last_screen" to "BrowserScreen",
            "last_action" to "delete_file",
        )
        val report = CrashReport.capture(
            thread = Thread.currentThread(),
            throwable = Exception("test"),
            isFatal = false,
            appVersionName = "1.0.0",
            appVersionCode = 1L,
            buildType = "debug",
            processName = "com.titan.filemanager",
            customData = customData,
        )

        assertThat(report.customData).isEqualTo(customData)
        assertThat(report.customData["last_screen"]).isEqualTo("BrowserScreen")
    }

    @Test
    fun `capture handles exception with null message`() {
        val exception = RuntimeException() // No message
        val report = CrashReport.capture(
            thread = Thread.currentThread(),
            throwable = exception,
            isFatal = true,
            appVersionName = "1.0.0",
            appVersionCode = 1L,
            buildType = "debug",
            processName = "com.titan.filemanager",
        )

        assertThat(report.exceptionMessage).isEmpty()
    }

    @Test
    fun `toPlainText contains all sections`() {
        val report = CrashReport(
            exceptionClass = "java.lang.NullPointerException",
            exceptionMessage = "value was null",
            stackTrace = "at com.example.Foo.bar(Foo.kt:10)",
            threadName = "main",
            threadPriority = 5,
            threadId = 1L,
            isFatal = true,
            timestampMs = System.currentTimeMillis(),
            deviceManufacturer = "Google",
            deviceModel = "Pixel 8",
            androidVersion = "14",
            sdkLevel = 34,
            abi = "arm64-v8a",
            appVersionName = "1.0.0",
            appVersionCode = 1L,
            buildType = "release",
            processId = 12345,
            processName = "com.titan.filemanager",
            freeHeapBytes = 50_000_000L,
            totalHeapBytes = 256_000_000L,
            nativeFreeBytes = 100_000_000L,
            storageFreeBytes = 50_000_000_000L,
            storageTotalBytes = 128_000_000_000L,
        )

        val plainText = report.toPlainText()

        assertThat(plainText).contains("TitanFileManager Crash Report")
        assertThat(plainText).contains("FATAL")
        assertThat(plainText).contains("NullPointerException")
        assertThat(plainText).contains("value was null")
        assertThat(plainText).contains("main")
        assertThat(plainText).contains("Google")
        assertThat(plainText).contains("Pixel 8")
        assertThat(plainText).contains("1.0.0")
        assertThat(plainText).contains("Stack Trace")
    }

    @Test
    fun `toPlainText includes custom data section when present`() {
        val report = CrashReport(
            exceptionClass = "Exception",
            exceptionMessage = "test",
            stackTrace = "stack",
            threadName = "main",
            threadPriority = 5,
            threadId = 1L,
            isFatal = false,
            timestampMs = System.currentTimeMillis(),
            deviceManufacturer = "Google",
            deviceModel = "Pixel",
            androidVersion = "14",
            sdkLevel = 34,
            abi = "arm64-v8a",
            appVersionName = "1.0.0",
            appVersionCode = 1L,
            buildType = "debug",
            processId = 1,
            processName = "test",
            freeHeapBytes = 0,
            totalHeapBytes = 0,
            nativeFreeBytes = 0,
            storageFreeBytes = 0,
            storageTotalBytes = 0,
            customData = mapOf("key" to "value"),
        )

        val plainText = report.toPlainText()
        assertThat(plainText).contains("Custom Data")
        assertThat(plainText).contains("key: value")
    }

    @Test
    fun `summary produces one-line format with severity`() {
        val report = CrashReport(
            exceptionClass = "java.lang.NullPointerException",
            exceptionMessage = "test",
            stackTrace = "",
            threadName = "main",
            threadPriority = 5,
            threadId = 1L,
            isFatal = true,
            timestampMs = System.currentTimeMillis(),
            deviceManufacturer = "Google",
            deviceModel = "Pixel",
            androidVersion = "14",
            sdkLevel = 34,
            abi = "arm64-v8a",
            appVersionName = "1.0.0",
            appVersionCode = 1L,
            buildType = "debug",
            processId = 1,
            processName = "test",
            freeHeapBytes = 0,
            totalHeapBytes = 0,
            nativeFreeBytes = 0,
            storageFreeBytes = 0,
            storageTotalBytes = 0,
        )

        val summary = report.summary()

        assertThat(summary).contains("FATAL")
        assertThat(summary).contains("NullPointerException")
        assertThat(summary).contains("main")
    }

    @Test
    fun `summary uses short exception class name`() {
        val report = CrashReport(
            exceptionClass = "com.titan.filemanager.error.SomeCustomException",
            exceptionMessage = "",
            stackTrace = "",
            threadName = "main",
            threadPriority = 5,
            threadId = 1L,
            isFatal = false,
            timestampMs = System.currentTimeMillis(),
            deviceManufacturer = "Google",
            deviceModel = "Pixel",
            androidVersion = "14",
            sdkLevel = 34,
            abi = "arm64-v8a",
            appVersionName = "1.0.0",
            appVersionCode = 1L,
            buildType = "debug",
            processId = 1,
            processName = "test",
            freeHeapBytes = 0,
            totalHeapBytes = 0,
            nativeFreeBytes = 0,
            storageFreeBytes = 0,
            storageTotalBytes = 0,
        )

        val summary = report.summary()
        // Should use the short name (after last '.')
        assertThat(summary).contains("SomeCustomException")
        assertThat(summary).doesNotContain("com.titan.filemanager.error.SomeCustomException")
    }
}

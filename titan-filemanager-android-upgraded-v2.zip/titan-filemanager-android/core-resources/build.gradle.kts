// :core:resources — strings, colors, drawables, themes, fonts (single source of truth)
//
// This module is an Android library that contains ONLY Android resources.
// No Kotlin code lives here — resources are accessed via `R.string.*`,
// `R.color.*`, `R.drawable.*`, etc. from other modules.
//
// Other modules that need access to these resources should add:
//   implementation(project(":core:resources"))
//
// Compose code typically uses the design tokens from `:core:designsystem`
// (which are type-safe Kotlin wrappers). The XML resources here are used
// by:
//   - AndroidManifest (themes, icons)
//   - Android Views (legacy screens if any)
//   - Home screen widgets
//   - Notification custom layouts
//   - XML layouts for non-Compose screens

plugins {
    id("titan.android.library")
}

android {
    namespace = "com.titan.filemanager.core.resources"

    defaultConfig {
        // Generate locale-specific resource qualifiers
        // (we ship English, Hindi, and Chinese Simplified)
        resourceConfigurations += listOf("en", "hi", "zh-rCN", "zh-rTW")
    }
}

dependencies {
    // No Kotlin dependencies — this module is resources-only.

    // Required for resource compilation tests
    testImplementation(libs.junit5)
    testImplementation(libs.truth)
}

# Font Resources

This directory contains font family XML definitions for TitanFileManager.
The actual `.ttf` font files are **NOT bundled** in this repository — they
must be downloaded separately and placed in this directory.

## Required font files

The XML files in this directory reference the following `.ttf` files:

### Inter (primary sans-serif)
- `inter_regular.ttf` — weight 400, normal
- `inter_italic.ttf` — weight 400, italic
- `inter_medium.ttf` — weight 500, normal
- `inter_semi_bold.ttf` — weight 600, normal
- `inter_bold.ttf` — weight 700, normal
- `inter_bold_italic.ttf` — weight 700, italic

**Source:** https://github.com/rsms/inter/releases (download Inter-X.zip,
extract `Inter.ttc` and split into individual weight TTFs, or use the
static TTFs from the `Inter Static/` folder)

### Roboto Mono (monospace, for code/hash display)
- `roboto_mono_regular.ttf` — weight 400, normal
- `roboto_mono_italic.ttf` — weight 400, italic
- `roboto_mono_medium.ttf` — weight 500, normal

**Source:** https://github.com/google/fonts/tree/main/ofl/robotomono

### LXGW WenKai (CJK serif, for Chinese locale)
- `lxgw_wenkai_regular.ttf` — weight 400, normal

**Source:** https://github.com/lxgw/LxgwWenKai/releases (download the
TTF variant, not the variable or web-font version)

## Installation

1. Download the font files from the sources above.
2. Place the `.ttf` files in this directory (`core-resources/src/main/res/font/`).
3. Run `./gradlew assembleDebug` to verify they compile.

## Fallback behavior

If the `.ttf` files are missing, the build will fail. To use the system
default fonts instead, delete the XML files in this directory and update
`TypographyTokens.kt` in `core-designsystem` to use `FontFamily.Default`,
`FontFamily.SansSerif`, and `FontFamily.Monospace` instead of the
`R.font.*` references.

## License summary

- **Inter** — SIL Open Font License 1.1
- **Roboto Mono** — Apache 2.0
- **LXGW WenKai** — SIL Open Font License 1.1

All three licenses permit free commercial use, redistribution, and
modification. The full license texts are available at the source URLs
above.

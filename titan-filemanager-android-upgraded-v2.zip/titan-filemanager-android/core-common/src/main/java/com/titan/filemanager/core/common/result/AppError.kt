package com.titan.filemanager.core.common.result

/**
 * Hierarchy of errors used across the app.
 *
 * Every error class is a [Throwable]-free type — we want exhaustive
 * `when` matching in the UI layer, not Java-style catch chains.
 *
 * Top-level categories:
 *   - [IO]          → filesystem / storage errors
 *   - [Network]     → HTTP / connectivity errors
 *   - [Permission]  → runtime permission denied
 *   - [Crypto]      → vault / encryption errors
 *   - [Cloud]       → cloud provider errors (sync, auth, quota)
 *   - [Database]    → Room / SQLite errors
 *   - [Validation]  → input validation
 *   - [Unknown]     → fallback
 */
sealed class AppError(open val message: String, open val cause: Throwable? = null) {

    /* ── I/O ──────────────────────────────────────────────────────── */

    sealed class IO(message: String, cause: Throwable? = null) : AppError(message, cause) {
        data class NotFound(val path: String, override val cause: Throwable? = null) :
            IO("File not found: $path", cause)

        data class PermissionDenied(val path: String, override val cause: Throwable? = null) :
            IO("Permission denied: $path", cause)

        data class ReadError(val path: String, override val cause: Throwable? = null) :
            IO("Failed to read: $path", cause)

        data class WriteError(val path: String, override val cause: Throwable? = null) :
            IO("Failed to write: $path", cause)

        data class OutOfSpace(val requiredBytes: Long, val availableBytes: Long) :
            IO("Insufficient storage: need $requiredBytes, have $availableBytes")
    }

    /* ── Network ──────────────────────────────────────────────────── */

    sealed class Network(message: String, cause: Throwable? = null) : AppError(message, cause) {
        data object NoConnection : Network("No internet connection")
        data class Timeout(val durationMs: Long, override val cause: Throwable? = null) :
            Network("Request timed out after ${durationMs}ms", cause)

        data class Http(val code: Int, val body: String?, override val cause: Throwable? = null) :
            Network("HTTP $code: ${body ?: "no body"}", cause)
    }

    /* ── Permission ───────────────────────────────────────────────── */

    sealed class Permission(message: String, cause: Throwable? = null) : AppError(message, cause) {
        data class Storage(val permission: String) : Permission("Storage permission denied: $permission")
        data object Biometric : Permission("Biometric authentication failed")
        data object Notification : Permission("Notification permission denied")
    }

    /* ── Crypto / Vault ───────────────────────────────────────────── */

    sealed class Crypto(message: String, cause: Throwable? = null) : AppError(message, cause) {
        data object VaultLocked : Crypto("Vault is locked")
        data object WrongPassword : Crypto("Incorrect vault password")
        data class DecryptionFailed(val path: String, override val cause: Throwable? = null) :
            Crypto("Decryption failed: $path", cause)

        data class IntegrityViolation(val path: String) :
            Crypto("Integrity check failed: $path — file may be tampered")
    }

    /* ── Cloud ────────────────────────────────────────────────────── */

    sealed class Cloud(message: String, cause: Throwable? = null) : AppError(message, cause) {
        data class Auth(val provider: String) : Cloud("Authentication failed for $provider")
        data class Quota(val provider: String, val requiredBytes: Long) :
            Cloud("$provider quota exceeded; need $requiredBytes bytes")

        data class Conflict(val path: String, override val cause: Throwable? = null) :
            Cloud("Sync conflict at $path", cause)
    }

    /* ── Database ─────────────────────────────────────────────────── */

    sealed class Database(message: String, cause: Throwable? = null) : AppError(message, cause) {
        data class Migration(val fromVersion: Int, val toVersion: Int) :
            Database("DB migration failed: $fromVersion → $toVersion")

        data class Constraint(val constraint: String, override val cause: Throwable? = null) :
            Database("DB constraint violated: $constraint", cause)
    }

    /* ── Validation ───────────────────────────────────────────────── */

    sealed class Validation(message: String, cause: Throwable? = null) : AppError(message, cause) {
        data class InvalidPath(val path: String) : Validation("Invalid path: $path")
        data class InvalidName(val name: String) : Validation("Invalid name: $name")
        data object EmptyName : Validation("Name cannot be empty")
    }

    /* ── Unknown / fallback ───────────────────────────────────────── */

    data class Unknown(override val cause: Throwable? = null) :
        AppError(cause?.message ?: "Unknown error", cause)
}

/**
 * Convert any [Throwable] to an [AppError.Unknown].
 */
fun Throwable.toAppError(): AppError = AppError.Unknown(this)

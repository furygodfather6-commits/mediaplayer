package com.titan.filemanager.core.common.time

import kotlinx.datetime.Clock
import kotlinx.datetime.Instant

/**
 * Abstraction over [Clock.System] for testability.
 *
 * Production code uses [DefaultTimeProvider]; tests inject
 * [FakeTimeProvider] (from `:core:testing`) to control virtual time.
 *
 * Usage:
 * ```
 * class CacheEntry @Inject constructor(
 *     private val time: TimeProvider,
 * ) {
 *     val createdAt = time.now()
 *     fun isExpired(ttlMs: Long) = (time.now().toEpochMilliseconds() - createdAt.toEpochMilliseconds()) > ttlMs
 * }
 * ```
 */
interface TimeProvider {
    fun now(): Instant
    fun nowEpochMillis(): Long
}

/**
 * Default implementation using [Clock.System].
 */
class DefaultTimeProvider : TimeProvider {
    override fun now(): Instant = Clock.System.now()
    override fun nowEpochMillis(): Long = Clock.System.now().toEpochMilliseconds()
}

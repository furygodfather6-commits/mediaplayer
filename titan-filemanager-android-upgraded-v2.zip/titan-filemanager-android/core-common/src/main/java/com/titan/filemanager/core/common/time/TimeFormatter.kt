package com.titan.filemanager.core.common.time

import kotlinx.datetime.DateTimeUnit
import kotlinx.datetime.Instant
import kotlinx.datetime.TimeZone
import kotlinx.datetime.plus
import kotlinx.datetime.until

/**
 * Human-friendly relative-time formatter.
 *
 * Examples:
 *   - "just now"
 *   - "5 minutes ago"
 *   - "3 hours ago"
 *   - "yesterday"
 *   - "2 days ago"
 *   - "Oct 3, 2026"
 *
 * Phase 0: Simple English implementation. Phase 5 will add ICU-based
 * localization using Android's [android.text.format.DateUtils] for
 * locale-aware formatting.
 */
object TimeFormatter {

    fun relativeTime(
        past: Instant,
        now: Instant,
        timeZone: TimeZone = TimeZone.currentSystemDefault(),
    ): String {
        val diffMillis = past.until(now, DateTimeUnit.MILLISECOND, timeZone)
        if (diffMillis < 0) return "in the future"
        if (diffMillis < MINUTE_MS) return "just now"

        val minutes = diffMillis / MINUTE_MS
        if (minutes < 60) return "$minutes minute${pluralS(minutes)} ago"

        val hours = minutes / 60
        if (hours < 24) return "$hours hour${pluralS(hours)} ago"

        val days = hours / 24
        if (days == 1L) return "yesterday"
        if (days < 7) return "$days day${pluralS(days)} ago"

        val weeks = days / 7
        if (weeks < 4) return "$weeks week${pluralS(weeks)} ago"

        val months = days / 30
        if (months < 12) return "$months month${pluralS(months)} ago"

        val years = days / 365
        return "$years year${pluralS(years)} ago"
    }

    private fun pluralS(n: Long) = if (n == 1L) "" else "s"

    private const val MINUTE_MS = 60_000L
    private const val HOUR_MS = 3_600_000L
    private const val DAY_MS = 86_400_000L
}

/**
 * Convenience for [Instant.plus] with milliseconds.
 */
fun Instant.plusMillis(milliseconds: Long, timeZone: TimeZone = TimeZone.UTC): Instant =
    plus(milliseconds, DateTimeUnit.MILLISECOND, timeZone)

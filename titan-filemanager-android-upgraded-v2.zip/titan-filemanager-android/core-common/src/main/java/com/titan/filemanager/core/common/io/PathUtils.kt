package com.titan.filemanager.core.common.io

import java.io.File

/**
 * Filesystem path utilities — pure functions, no Android deps.
 *
 * Used across scan/metadata/cache modules to normalize, join, and
 * compare paths consistently. Avoids `java.io.File` where possible
 * because:
 *   1. `File` performs filesystem checks we don't always want
 *   2. String-based ops are faster in hot loops (scan engine)
 */
object PathUtils {

    private const val SEPARATOR = '/'

    /**
     * Join path segments with exactly one separator between each.
     * Empty segments are dropped. Leading separators are preserved.
     *
     * Examples:
     *   - join("/sdcard", "DCIM") → "/sdcard/DCIM"
     *   - join("/sdcard/", "/DCIM/") → "/sdcard/DCIM"
     *   - join("", "DCIM") → "DCIM"
     *   - join("/sdcard", "DCIM", "Camera", "photo.jpg") → "/sdcard/DCIM/Camera/photo.jpg"
     */
    fun join(vararg segments: String): String {
        if (segments.isEmpty()) return ""
        val result = StringBuilder(segments.sumOf { it.length + 1 })

        segments.forEachIndexed { index, segment ->
            val trimmed = segment.trimEnd(SEPARATOR).trimStart(SEPARATOR).let { s ->
                if (index == 0 && segment.startsWith(SEPARATOR)) "/$s" else s
            }
            if (trimmed.isEmpty()) return@forEachIndexed

            if (result.isNotEmpty() && !result.endsWith(SEPARATOR)) {
                result.append(SEPARATOR)
            }
            result.append(trimmed)
        }
        return result.toString()
    }

    /**
     * Get the parent of a path. Returns `null` if already at root.
     *
     * Examples:
     *   - parent("/sdcard/DCIM") → "/sdcard"
     *   - parent("/sdcard") → "/"
     *   - parent("/") → null
     *   - parent("DCIM") → ""
     */
    fun parent(path: String): String? {
        if (path.isEmpty()) return null
        val trimmed = path.trimEnd(SEPARATOR)
        if (trimmed.isEmpty()) return null // path was all slashes
        val lastSep = trimmed.lastIndexOf(SEPARATOR)
        return when {
            lastSep < 0 -> ""               // no separator — parent is CWD
            lastSep == 0 -> "/"             // parent is root
            else -> trimmed.substring(0, lastSep)
        }
    }

    /**
     * Get the last segment (file or folder name).
     *
     * Examples:
     *   - name("/sdcard/DCIM/photo.jpg") → "photo.jpg"
     *   - name("/") → ""
     *   - name("photo.jpg") → "photo.jpg"
     */
    fun name(path: String): String {
        val trimmed = path.trimEnd(SEPARATOR)
        if (trimmed.isEmpty()) return ""
        val lastSep = trimmed.lastIndexOf(SEPARATOR)
        return if (lastSep < 0) trimmed else trimmed.substring(lastSep + 1)
    }

    /**
     * Get the file extension (without the dot). Empty if no extension.
     *
     * Examples:
     *   - extension("photo.jpg") → "jpg"
     *   - extension("archive.tar.gz") → "gz"
     *   - extension("README") → ""
     *   - extension(".gitignore") → ""  // dotfiles have no extension
     */
    fun extension(path: String): String {
        val name = name(path)
        if (name.isEmpty() || name == "." || name == "..") return ""
        val lastDot = name.lastIndexOf('.')
        if (lastDot <= 0) return ""  // dotfile or no extension
        return name.substring(lastDot + 1).lowercase()
    }

    /**
     * True if the path is absolute (starts with `/`).
     */
    fun isAbsolute(path: String): Boolean = path.startsWith(SEPARATOR)

    /**
     * Normalize a path by collapsing `.` and `..` segments and duplicate slashes.
     *
     * Examples:
     *   - normalize("/sdcard/./DCIM") → "/sdcard/DCIM"
     *   - normalize("/sdcard/../sdcard/DCIM") → "/sdcard/DCIM"
     *   - normalize("/sdcard//DCIM") → "/sdcard/DCIM"
     */
    fun normalize(path: String): String {
        if (path.isEmpty()) return ""

        val isAbsolute = path.startsWith(SEPARATOR)
        val parts = path.split(SEPARATOR).filter { it.isNotEmpty() && it != "." }
        val stack = ArrayDeque<String>()

        for (part in parts) {
            when (part) {
                ".." -> {
                    if (stack.isNotEmpty() && stack.last() != "..") stack.removeLast()
                    else if (!isAbsolute) stack.addLast("..")
                }
                else -> stack.addLast(part)
            }
        }

        val result = stack.joinToString(SEPARATOR.toString())
        return if (isAbsolute) SEPARATOR + result else result
    }

    /**
     * Get the depth of a path — number of segments from root.
     *
     * Examples:
     *   - depth("/") → 0
     *   - depth("/sdcard") → 1
     *   - depth("/sdcard/DCIM") → 2
     */
    fun depth(path: String): Int {
        val normalized = normalize(path)
        if (normalized.isEmpty() || normalized == "/") return 0
        return normalized.count { it == SEPARATOR }
    }
}

/**
 * Convert a path string to a [File] — convenience for Java interop.
 */
fun String.toFile(): File = File(this)

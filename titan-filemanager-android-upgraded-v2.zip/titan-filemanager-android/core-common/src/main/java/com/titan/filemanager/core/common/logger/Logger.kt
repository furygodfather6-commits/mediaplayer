package com.titan.filemanager.core.common.logger

/**
 * Logger abstraction over Timber / Firebase Crashlytics / Android Log.
 *
 * Production code uses [TimberLogger]; tests inject [NoopLogger].
 * In Phase 5 we'll add [CrashlyticsLogger] that forwards ERROR/WARN
 * logs to Firebase Crashlytics in release builds.
 *
 * Usage:
 * ```
 * class MyClass @Inject constructor(private val logger: Logger) {
 *     fun doWork() {
 *         logger.d { "Starting work" }
 *         try {
 *             // ...
 *         } catch (e: IOException) {
 *             logger.w(e) { "Work failed" }
 *         }
 *     }
 * }
 * ```
 *
 * The lambda form avoids string concatenation when the log level
 * is disabled (lazy evaluation).
 */
interface Logger {
    fun v(throwable: Throwable? = null, message: () -> String)
    fun d(throwable: Throwable? = null, message: () -> String)
    fun i(throwable: Throwable? = null, message: () -> String)
    fun w(throwable: Throwable? = null, message: () -> String)
    fun e(throwable: Throwable? = null, message: () -> String)
    fun wtf(throwable: Throwable? = null, message: () -> String)
}

/**
 * No-op implementation — used in tests where we don't want any log output.
 */
class NoopLogger : Logger {
    override fun v(throwable: Throwable?, message: () -> String) = Unit
    override fun d(throwable: Throwable?, message: () -> String) = Unit
    override fun i(throwable: Throwable?, message: () -> String) = Unit
    override fun w(throwable: Throwable?, message: () -> String) = Unit
    override fun e(throwable: Throwable?, message: () -> String) = Unit
    override fun wtf(throwable: Throwable?, message: () -> String) = Unit
}

/**
 * Default implementation using Timber.
 */
class TimberLogger : Logger {
    override fun v(throwable: Throwable?, message: () -> String) {
        if (throwable != null) Timber.v(throwable, message()) else Timber.v(message())
    }

    override fun d(throwable: Throwable?, message: () -> String) {
        if (throwable != null) Timber.d(throwable, message()) else Timber.d(message())
    }

    override fun i(throwable: Throwable?, message: () -> String) {
        if (throwable != null) Timber.i(throwable, message()) else Timber.i(message())
    }

    override fun w(throwable: Throwable?, message: () -> String) {
        if (throwable != null) Timber.w(throwable, message()) else Timber.w(message())
    }

    override fun e(throwable: Throwable?, message: () -> String) {
        if (throwable != null) Timber.e(throwable, message()) else Timber.e(message())
    }

    override fun wtf(throwable: Throwable?, message: () -> String) {
        if (throwable != null) Timber.wtf(throwable, message()) else Timber.wtf(message())
    }
}

// Local import alias so we don't need `import timber.log.Timber` at the top
// of every file using [TimberLogger]. Keep it private to this file.
private val Timber = timber.log.Timber

package com.titan.filemanager.core.common.io

/**
 * Byte unit constants + conversion utilities.
 *
 * All constants are in [Long] to avoid [Int] overflow for large files
 * (Int max ≈ 2 GB which is too small for video files).
 */
object ByteUnit {
    const val KB: Long = 1024
    const val MB: Long = KB * 1024
    const val GB: Long = MB * 1024
    const val TB: Long = GB * 1024
    const val PB: Long = TB * 1024

    /** Bytes per KiB (1000-based, used by storage manufacturers). */
    const val KB_DEC: Long = 1000
    const val MB_DEC: Long = KB_DEC * 1000
    const val GB_DEC: Long = MB_DEC * 1000
    const val TB_DEC: Long = GB_DEC * 1000
}

/**
 * Convert bytes to a human-readable string using binary prefixes (KiB, MiB, etc.).
 *
 * Examples:
 *   - 0 → "0 B"
 *   - 500 → "500 B"
 *   - 1024 → "1.0 KiB"
 *   - 1048576 → "1.0 MiB"
 *   - 1610612736 → "1.5 GiB"
 */
fun Long.toBinaryByteString(): String {
    if (this < 0) return "-"
    if (this < ByteUnit.KB) return "$this B"

    val units = arrayOf("B", "KiB", "MiB", "GiB", "TiB", "PiB")
    var value = this.toDouble()
    var unitIndex = 0
    while (value >= 1024 && unitIndex < units.lastIndex) {
        value /= 1024
        unitIndex++
    }
    return "%.1f %s".format(value, units[unitIndex])
}

/**
 * Convert bytes to a human-readable string using decimal prefixes (KB, MB, GB).
 *
 * Examples:
 *   - 1000 → "1.0 KB"
 *   - 1000000 → "1.0 MB"
 *
 * Use this for storage device capacity reporting (matches what the OS shows).
 */
fun Long.toDecimalByteString(): String {
    if (this < 0) return "-"
    if (this < ByteUnit.KB_DEC) return "$this B"

    val units = arrayOf("B", "KB", "MB", "GB", "TB", "PB")
    var value = this.toDouble()
    var unitIndex = 0
    while (value >= 1000 && unitIndex < units.lastIndex) {
        value /= 1000
        unitIndex++
    }
    return "%.1f %s".format(value, units[unitIndex])
}

/**
 * Convenience for Int values.
 */
fun Int.toBinaryByteString(): String = this.toLong().toBinaryByteString()
fun Int.toDecimalByteString(): String = this.toLong().toDecimalByteString()

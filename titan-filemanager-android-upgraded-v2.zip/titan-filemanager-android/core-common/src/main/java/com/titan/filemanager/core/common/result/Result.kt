package com.titan.filemanager.core.common.result

/**
 * Result of an operation — a sealed hierarchy with explicit
 * [Success], [Error], and [Loading] states.
 *
 * Replaces `kotlin.Result` because:
 *  - We need a [Loading] state for async UI flows
 *  - We need to attach typed [AppError]s rather than [Throwable]
 *  - Pattern-matching on a sealed type drives exhaustive `when` blocks
 *
 * Usage:
 * ```
 * suspend fun loadFile(path: String): Result<FileItem> = try {
 *     val item = fs.readFile(path)
 *     Result.Success(item)
 * } catch (e: IOException) {
 *     Result.Error(AppError.IO.NotFound(path, e))
 * }
 * ```
 */
sealed interface Result<out T> {

    /**
     * Operation succeeded with data [data].
     */
    data class Success<T>(val data: T) : Result<T>

    /**
     * Operation failed with a typed [error].
     */
    data class Error(val error: AppError) : Result<Nothing>

    /**
     * Operation is in progress — UI should show a loading state.
     */
    data object Loading : Result<Nothing>
}

/**
 * Convenience: fold a [Result] into a single value.
 */
inline fun <T, R> Result<T>.fold(
    onSuccess: (T) -> R,
    onError: (AppError) -> R,
    onLoading: () -> R,
): R = when (this) {
    is Result.Success -> onSuccess(data)
    is Result.Error -> onError(error)
    is Result.Loading -> onLoading()
}

/**
 * Get the data or `null` if not [Success].
 */
fun <T> Result<T>.getOrNull(): T? = (this as? Result.Success)?.data

/**
 * Get the error or `null` if not [Error].
 */
fun <T> Result<T>.errorOrNull(): AppError? = (this as? Result.Error)?.error

/**
 * True if [Success].
 */
val <T> Result<T>.isSuccess: Boolean get() = this is Result.Success

/**
 * True if [Error].
 */
val <T> Result<T>.isError: Boolean get() = this is Result.Error

/**
 * True if [Loading].
 */
val <T> Result<T>.isLoading: Boolean get() = this is Result.Loading

package com.titan.filemanager.core.common.collections

import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedDeque

/**
 * Thread-safe bounded LRU cache backed by a [ConcurrentLinkedDeque] and
 * a [ConcurrentHashMap].
 *
 * Get and put operations are O(1). Eviction uses LRU (least recently used)
 * policy — the oldest accessed entry is removed when capacity is exceeded.
 *
 * Usage:
 * ```
 * val cache = ConcurrentLruCache<String, FileItem>(maxSize = 1000)
 * cache.put(path, item)
 * cache.get(path)   // → FileItem or null
 * cache.size()      // → current size
 * cache.clear()
 * ```
 *
 * For very high contention scenarios consider [java.util.concurrent.
 * ConcurrentHashMap] with `compute*` methods directly — this class adds
 * deque-based LRU on top.
 */
class ConcurrentLruCache<K, V>(private val maxSize: Int) {

    init {
        require(maxSize > 0) { "maxSize must be > 0, was $maxSize" }
    }

    private val map = ConcurrentHashMap<K, V>(maxSize)
    private val accessOrder = ConcurrentLinkedDeque<K>()

    /**
     * Insert or update [key] → [value]. Evicts LRU entry if over capacity.
     */
    fun put(key: K, value: V) {
        // Remove key from deque first (so it gets re-added at MRU position)
        accessOrder.remove(key)
        map[key] = value
        accessOrder.addLast(key)

        evictIfNecessary()
    }

    /**
     * Get the value for [key], or `null` if absent.
     * Updates access order on hit.
     */
    fun get(key: K): V? {
        val value = map[key] ?: return null
        // Move to MRU
        if (accessOrder.remove(key)) {
            accessOrder.addLast(key)
        }
        return value
    }

    fun remove(key: K): V? {
        accessOrder.remove(key)
        return map.remove(key)
    }

    fun contains(key: K): Boolean = map.containsKey(key)

    fun size(): Int = map.size

    fun keys(): Set<K> = map.keys.toSet()

    fun values(): Collection<V> = map.values.toList()

    fun clear() {
        map.clear()
        accessOrder.clear()
    }

    private fun evictIfNecessary() {
        while (map.size > maxSize) {
            val lruKey = accessOrder.pollFirst() ?: return
            map.remove(lruKey)
        }
    }
}

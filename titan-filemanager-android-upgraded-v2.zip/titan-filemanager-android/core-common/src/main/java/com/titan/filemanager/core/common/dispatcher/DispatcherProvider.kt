package com.titan.filemanager.core.common.dispatcher

import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers

/**
 * Abstraction over [Dispatchers] for testability.
 *
 * Production code uses [DefaultDispatcherProvider]; tests inject
 * a [TestDispatcherProvider] (from `:core:testing`) so coroutines
 * run on a [TestScope] with virtual time.
 *
 * Usage:
 * ```
 * class MyUseCase @Inject constructor(
 *     private val dispatchers: DispatcherProvider,
 * ) {
 *     suspend fun run(): Result = withContext(dispatchers.io) {
 *         // do IO
 *     }
 * }
 * ```
 *
 * Never call [Dispatchers] directly — always go through this provider.
 */
interface DispatcherProvider {
    val main: CoroutineDispatcher
    val mainImmediate: CoroutineDispatcher
    val io: CoroutineDispatcher
    val default: CoroutineDispatcher
    val unconfined: CoroutineDispatcher
}

/**
 * Default implementation that delegates to [Dispatchers].
 *
 * Provided via Hilt in `:app:di:AppModule` (added in Phase 1).
 */
class DefaultDispatcherProvider : DispatcherProvider {
    override val main: CoroutineDispatcher = Dispatchers.Main
    override val mainImmediate: CoroutineDispatcher = Dispatchers.Main.immediate
    override val io: CoroutineDispatcher = Dispatchers.IO
    override val default: CoroutineDispatcher = Dispatchers.Default
    override val unconfined: CoroutineDispatcher = Dispatchers.Unconfined
}

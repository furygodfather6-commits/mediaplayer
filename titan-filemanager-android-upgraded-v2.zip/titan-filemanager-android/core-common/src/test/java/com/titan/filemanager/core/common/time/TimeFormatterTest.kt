package com.titan.filemanager.core.common.time

import com.google.common.truth.Truth.assertThat
import kotlinx.datetime.Instant
import org.junit.jupiter.api.Test

class TimeFormatterTest {

    @Test
    fun `just now for events less than 1 minute ago`() {
        val now = Instant.parse("2026-07-03T12:00:00Z")
        val past = Instant.parse("2026-07-03T11:59:30Z")
        assertThat(TimeFormatter.relativeTime(past, now)).isEqualTo("just now")
    }

    @Test
    fun `5 minutes ago for events less than 1 hour ago`() {
        val now = Instant.parse("2026-07-03T12:00:00Z")
        val past = Instant.parse("2026-07-03T11:55:00Z")
        assertThat(TimeFormatter.relativeTime(past, now)).isEqualTo("5 minutes ago")
    }

    @Test
    fun `1 minute ago singular form`() {
        val now = Instant.parse("2026-07-03T12:00:00Z")
        val past = Instant.parse("2026-07-03T11:59:00Z")
        assertThat(TimeFormatter.relativeTime(past, now)).isEqualTo("1 minute ago")
    }

    @Test
    fun `3 hours ago for events less than 1 day ago`() {
        val now = Instant.parse("2026-07-03T12:00:00Z")
        val past = Instant.parse("2026-07-03T09:00:00Z")
        assertThat(TimeFormatter.relativeTime(past, now)).isEqualTo("3 hours ago")
    }

    @Test
    fun `yesterday for events 1 day ago`() {
        val now = Instant.parse("2026-07-03T12:00:00Z")
        val past = Instant.parse("2026-07-02T12:00:00Z")
        assertThat(TimeFormatter.relativeTime(past, now)).isEqualTo("yesterday")
    }

    @Test
    fun `2 days ago for events 2 days ago`() {
        val now = Instant.parse("2026-07-03T12:00:00Z")
        val past = Instant.parse("2026-07-01T12:00:00Z")
        assertThat(TimeFormatter.relativeTime(past, now)).isEqualTo("2 days ago")
    }

    @Test
    fun `in the future for events after now`() {
        val now = Instant.parse("2026-07-03T12:00:00Z")
        val past = Instant.parse("2026-07-03T13:00:00Z")
        assertThat(TimeFormatter.relativeTime(past, now)).isEqualTo("in the future")
    }
}

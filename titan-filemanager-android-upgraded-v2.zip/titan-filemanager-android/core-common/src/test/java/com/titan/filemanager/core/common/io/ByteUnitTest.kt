package com.titan.filemanager.core.common.io

import com.google.common.truth.Truth.assertThat
import org.junit.jupiter.api.Test

class ByteUnitTest {

    @Test
    fun `zero bytes formats as 0 B`() {
        assertThat(0L.toBinaryByteString()).isEqualTo("0 B")
    }

    @Test
    fun `bytes below KiB keep B unit`() {
        assertThat(500L.toBinaryByteString()).isEqualTo("500 B")
    }

    @Test
    fun `exactly 1 KiB formats as 1_0 KiB`() {
        assertThat(1024L.toBinaryByteString()).isEqualTo("1.0 KiB")
    }

    @Test
    fun `1 MiB formats as 1_0 MiB`() {
        assertThat((1024L * 1024).toBinaryByteString()).isEqualTo("1.0 MiB")
    }

    @Test
    fun `1 GiB formats as 1_0 GiB`() {
        assertThat((1024L * 1024 * 1024).toBinaryByteString()).isEqualTo("1.0 GiB")
    }

    @Test
    fun `1_5 GiB formats with one decimal`() {
        val oneAndHalfGiB = (1024L * 1024 * 1024) + (512L * 1024 * 1024)
        assertThat(oneAndHalfGiB.toBinaryByteString()).isEqualTo("1.5 GiB")
    }

    @Test
    fun `decimal 1 KB formats as 1_0 KB`() {
        assertThat(1000L.toDecimalByteString()).isEqualTo("1.0 KB")
    }

    @Test
    fun `decimal 1 MB formats as 1_0 MB`() {
        assertThat(1_000_000L.toDecimalByteString()).isEqualTo("1.0 MB")
    }

    @Test
    fun `negative bytes returns dash`() {
        assertThat((-1L).toBinaryByteString()).isEqualTo("-")
    }
}

package com.titan.filemanager.core.common.io

import com.google.common.truth.Truth.assertThat
import org.junit.jupiter.api.Test

class PathUtilsTest {

    @Test
    fun `join with two segments adds separator`() {
        assertThat(PathUtils.join("/sdcard", "DCIM")).isEqualTo("/sdcard/DCIM")
    }

    @Test
    fun `join with trailing and leading slashes collapses them`() {
        assertThat(PathUtils.join("/sdcard/", "/DCIM/")).isEqualTo("/sdcard/DCIM")
    }

    @Test
    fun `join with multiple segments`() {
        assertThat(PathUtils.join("/sdcard", "DCIM", "Camera", "photo.jpg"))
            .isEqualTo("/sdcard/DCIM/Camera/photo.jpg")
    }

    @Test
    fun `join with empty segment skips it`() {
        assertThat(PathUtils.join("/sdcard", "", "DCIM")).isEqualTo("/sdcard/DCIM")
    }

    @Test
    fun `join with no segments returns empty string`() {
        assertThat(PathUtils.join()).isEmpty()
    }

    @Test
    fun `parent of nested path returns parent directory`() {
        assertThat(PathUtils.parent("/sdcard/DCIM")).isEqualTo("/sdcard")
    }

    @Test
    fun `parent of root returns null`() {
        assertThat(PathUtils.parent("/")).isNull()
    }

    @Test
    fun `parent of single-segment returns empty string`() {
        assertThat(PathUtils.parent("DCIM")).isEmpty()
    }

    @Test
    fun `name returns last segment`() {
        assertThat(PathUtils.name("/sdcard/DCIM/photo.jpg")).isEqualTo("photo.jpg")
    }

    @Test
    fun `name of root returns empty string`() {
        assertThat(PathUtils.name("/")).isEmpty()
    }

    @Test
    fun `extension of regular file returns lowercase extension`() {
        assertThat(PathUtils.extension("photo.JPG")).isEqualTo("jpg")
    }

    @Test
    fun `extension of dotfile returns empty`() {
        assertThat(PathUtils.extension(".gitignore")).isEmpty()
    }

    @Test
    fun `extension of file without extension returns empty`() {
        assertThat(PathUtils.extension("README")).isEmpty()
    }

    @Test
    fun `extension of tar gz returns gz`() {
        assertThat(PathUtils.extension("archive.tar.gz")).isEqualTo("gz")
    }

    @Test
    fun `isAbsolute with leading slash returns true`() {
        assertThat(PathUtils.isAbsolute("/sdcard")).isTrue()
    }

    @Test
    fun `isAbsolute without leading slash returns false`() {
        assertThat(PathUtils.isAbsolute("DCIM")).isFalse()
    }

    @Test
    fun `normalize collapses single dot`() {
        assertThat(PathUtils.normalize("/sdcard/./DCIM")).isEqualTo("/sdcard/DCIM")
    }

    @Test
    fun `normalize collapses double dot`() {
        assertThat(PathUtils.normalize("/sdcard/../sdcard/DCIM")).isEqualTo("/sdcard/DCIM")
    }

    @Test
    fun `normalize collapses duplicate slashes`() {
        assertThat(PathUtils.normalize("/sdcard//DCIM")).isEqualTo("/sdcard/DCIM")
    }

    @Test
    fun `depth of root is zero`() {
        assertThat(PathUtils.depth("/")).isEqualTo(0)
    }

    @Test
    fun `depth of nested path counts segments`() {
        assertThat(PathUtils.depth("/sdcard/DCIM/Camera")).isEqualTo(3)
    }
}

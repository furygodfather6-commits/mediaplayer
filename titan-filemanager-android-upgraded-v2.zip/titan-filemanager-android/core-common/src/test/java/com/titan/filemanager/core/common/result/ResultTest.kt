package com.titan.filemanager.core.common.result

import com.google.common.truth.Truth.assertThat
import org.junit.jupiter.api.Test

class ResultTest {

    @Test
    fun `Success holds data and isSuccess is true`() {
        val result: Result<String> = Result.Success("hello")
        assertThat(result.isSuccess).isTrue()
        assertThat(result.getOrNull()).isEqualTo("hello")
        assertThat(result.errorOrNull()).isNull()
        assertThat(result.isLoading).isFalse()
    }

    @Test
    fun `Error holds AppError and isError is true`() {
        val error = AppError.IO.NotFound("/sdcard/missing")
        val result: Result<String> = Result.Error(error)
        assertThat(result.isError).isTrue()
        assertThat(result.errorOrNull()).isEqualTo(error)
        assertThat(result.getOrNull()).isNull()
        assertThat(result.isSuccess).isFalse()
    }

    @Test
    fun `Loading state is not success or error`() {
        val result: Result<String> = Result.Loading
        assertThat(result.isLoading).isTrue()
        assertThat(result.isSuccess).isFalse()
        assertThat(result.isError).isFalse()
        assertThat(result.getOrNull()).isNull()
        assertThat(result.errorOrNull()).isNull()
    }

    @Test
    fun `fold on Success invokes onSuccess`() {
        val result: Result<Int> = Result.Success(42)
        val folded = result.fold(
            onSuccess = { "got: $it" },
            onError = { "err: ${it.message}" },
            onLoading = { "loading" },
        )
        assertThat(folded).isEqualTo("got: 42")
    }

    @Test
    fun `fold on Error invokes onError`() {
        val result: Result<Int> = Result.Error(AppError.IO.NotFound("/x"))
        val folded = result.fold(
            onSuccess = { "ok" },
            onError = { "err: ${it.message}" },
            onLoading = { "loading" },
        )
        assertThat(folded).isEqualTo("err: File not found: /x")
    }

    @Test
    fun `fold on Loading invokes onLoading`() {
        val result: Result<Int> = Result.Loading
        val folded = result.fold(
            onSuccess = { "ok" },
            onError = { "err" },
            onLoading = { "loading" },
        )
        assertThat(folded).isEqualTo("loading")
    }
}

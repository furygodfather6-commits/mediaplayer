package com.titan.filemanager.core.common.collections

import com.google.common.truth.Truth.assertThat
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertThrows

class ConcurrentLruCacheTest {

    private lateinit var cache: ConcurrentLruCache<String, Int>

    @BeforeEach
    fun setUp() {
        cache = ConcurrentLruCache(maxSize = 3)
    }

    @Test
    fun `put and get returns value`() {
        cache.put("a", 1)
        assertThat(cache.get("a")).isEqualTo(1)
    }

    @Test
    fun `get on missing key returns null`() {
        assertThat(cache.get("missing")).isNull()
    }

    @Test
    fun `put over capacity evicts least recently used`() {
        cache.put("a", 1)
        cache.put("b", 2)
        cache.put("c", 3)
        // Capacity is 3 — adding "d" should evict "a" (LRU)
        cache.put("d", 4)

        assertThat(cache.get("a")).isNull()
        assertThat(cache.get("b")).isEqualTo(2)
        assertThat(cache.get("c")).isEqualTo(3)
        assertThat(cache.get("d")).isEqualTo(4)
    }

    @Test
    fun `get updates access order so LRU is correct`() {
        cache.put("a", 1)
        cache.put("b", 2)
        cache.put("c", 3)

        // Access "a" so it becomes most recently used
        cache.get("a")

        // Adding "d" should now evict "b" (LRU) instead of "a"
        cache.put("d", 4)

        assertThat(cache.get("a")).isEqualTo(1)
        assertThat(cache.get("b")).isNull()
        assertThat(cache.get("c")).isEqualTo(3)
        assertThat(cache.get("d")).isEqualTo(4)
    }

    @Test
    fun `put on existing key updates value and access order`() {
        cache.put("a", 1)
        cache.put("b", 2)
        cache.put("c", 3)

        // Update "a" — should be most recently used now
        cache.put("a", 100)

        cache.put("d", 4)

        assertThat(cache.get("a")).isEqualTo(100)
        assertThat(cache.get("b")).isNull()
        assertThat(cache.get("c")).isEqualTo(3)
        assertThat(cache.get("d")).isEqualTo(4)
    }

    @Test
    fun `remove deletes entry`() {
        cache.put("a", 1)
        assertThat(cache.remove("a")).isEqualTo(1)
        assertThat(cache.get("a")).isNull()
    }

    @Test
    fun `remove on missing key returns null`() {
        assertThat(cache.remove("missing")).isNull()
    }

    @Test
    fun `contains returns true for existing key`() {
        cache.put("a", 1)
        assertThat(cache.contains("a")).isTrue()
        assertThat(cache.contains("b")).isFalse()
    }

    @Test
    fun `size returns current entry count`() {
        assertThat(cache.size()).isEqualTo(0)
        cache.put("a", 1)
        cache.put("b", 2)
        assertThat(cache.size()).isEqualTo(2)
    }

    @Test
    fun `clear empties the cache`() {
        cache.put("a", 1)
        cache.put("b", 2)
        cache.clear()
        assertThat(cache.size()).isEqualTo(0)
        assertThat(cache.get("a")).isNull()
    }

    @Test
    fun `constructor with zero size throws`() {
        assertThrows<IllegalArgumentException> { ConcurrentLruCache<String, Int>(maxSize = 0) }
    }

    @Test
    fun `constructor with negative size throws`() {
        assertThrows<IllegalArgumentException> { ConcurrentLruCache<String, Int>(maxSize = -1) }
    }
}

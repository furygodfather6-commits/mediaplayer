// :core:common — pure Kotlin utilities (no Android deps where possible)
plugins {
    id("titan.android.library")
}

android {
    namespace = "com.titan.filemanager.core.common"
}

dependencies {
    // Pure Kotlin — keep Android deps minimal
    api(libs.kotlinx.coroutines.core)
    api(libs.kotlinx.datetime)

    implementation(libs.timber)

    testImplementation(libs.junit5)
    testImplementation(libs.truth)
    testImplementation(libs.kotlinx.coroutines.test)
    testImplementation(libs.turbine)
}

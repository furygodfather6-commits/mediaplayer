package com.titan.filemanager.data.memory.arena

import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/**
 * Region-Based Memory Allocator (Arena Allocator).
 *
 * Allocates a LARGE block once, then sub-allocates from it.
 * Bulk-free entire region at once = O(1) cleanup regardless of allocation count.
 *
 * Use case: one arena per directory scan → all scan data goes into arena →
 * navigate away → free entire arena = instant cleanup.
 *
 * Technique #97: Memory pooling
 * Technique #99: Avoid temporary allocations
 * Technique #100: GC reduction
 */
class MemoryPoolAllocator(
    private val arenaSize: Int = 2 * 1024 * 1024, // 2MB default
) {
    private var currentArena: ByteArray = ByteArray(arenaSize)
    private var arenaOffset: Int = 0
    private val arenaLock = ReentrantLock()
    private val allArenas = ArrayList<ByteArray>(4)

    private val totalAllocated = AtomicLong(0L)
    private val allocationCount = AtomicLong(0L)
    private val arenaCount = AtomicLong(1L)

    init { allArenas.add(currentArena) }

    fun allocate(size: Int): ByteArraySlice {
        require(size > 0 && size <= arenaSize) { "Allocation size $size out of range [1, $arenaSize]" }
        return arenaLock.withLock {
            val aligned = alignTo8(size)
            if (arenaOffset + aligned > currentArena.size) growArena()
            val offset = arenaOffset
            arenaOffset += aligned
            allocationCount.incrementAndGet()
            totalAllocated.addAndGet(aligned.toLong())
            ByteArraySlice(currentArena, offset, size)
        }
    }

    fun freeAll() = arenaLock.withLock {
        allArenas.clear()
        currentArena = ByteArray(arenaSize)
        allArenas.add(currentArena)
        arenaOffset = 0
        allocationCount.set(0); totalAllocated.set(0); arenaCount.set(1)
    }

    fun reset() = arenaLock.withLock {
        val first = allArenas.first()
        allArenas.clear(); allArenas.add(first)
        currentArena = first; arenaOffset = 0
        allocationCount.set(0); totalAllocated.set(0); arenaCount.set(1)
    }

    private fun growArena() {
        val newArena = ByteArray(arenaSize)
        allArenas.add(newArena)
        currentArena = newArena
        arenaOffset = 0
        arenaCount.incrementAndGet()
    }

    private fun alignTo8(size: Int): Int = (size + 7) and 7.inv()

    fun getStats(): ArenaStats = arenaLock.withLock {
        ArenaStats(
            arenaCount = arenaCount.get().toInt(),
            arenaSize = arenaSize,
            currentArenaUsed = arenaOffset,
            currentArenaFree = currentArena.size - arenaOffset,
            totalAllocatedBytes = totalAllocated.get(),
            allocationCount = allocationCount.get(),
        )
    }
}

data class ByteArraySlice(val data: ByteArray, val offset: Int, val length: Int) {
    fun asByteArray(): ByteArray = data.copyOfRange(offset, offset + length)
}

data class ArenaStats(
    val arenaCount: Int,
    val arenaSize: Int,
    val currentArenaUsed: Int,
    val currentArenaFree: Int,
    val totalAllocatedBytes: Long,
    val allocationCount: Long,
)

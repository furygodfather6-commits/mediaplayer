package com.titan.filemanager.data.memory.zero

import com.titan.filemanager.data.memory.pool.ObjectPoolManager
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.nio.MappedByteBuffer

/**
 * Zero-Copy Engine — mmap + channel transfer + shared direct buffers.
 *
 * Traditional: Disk → Kernel Buffer → User Space → JVM Heap (3 copies)
 * Zero-Copy:   Disk → Memory Mapped Region → Direct access (0 copies)
 *
 * Technique #95: Zero-copy architecture
 * Technique #104: Memory-mapped files
 * Technique #116: Buffered I/O
 */
class ZeroCopyEngine(private val bufferPool: ObjectPoolManager) {

    companion object {
        private const val DIRECT_BUFFER_SIZE = 1024 * 1024 // 1MB

        private val sharedDirectBuffer: ByteBuffer by lazy {
            ByteBuffer.allocateDirect(DIRECT_BUFFER_SIZE)
        }
        private val sharedDirectBufferLock = Any()
    }

    /**
     * Read file metadata via mmap — zero kernel-to-userspace copy for small files.
     */
    fun readFileMetaMapped(path: String): FileMeta? = try {
        FileInputStream(path).use { fis ->
            val channel = fis.channel
            val size = channel.size()
            if (size <= 4 * 1024 * 1024) {
                val mapped: MappedByteBuffer = channel.map(
                    FileChannel.MapMode.READ_ONLY, 0, minOf(size, DIRECT_BUFFER_SIZE.toLong())
                )
                FileMeta(
                    size = size,
                    headerBytes = if (mapped.capacity() >= 16)
                        ByteArray(16).also { mapped.get(it) } else null,
                )
            } else FileMeta(size = size, headerBytes = null)
        }
    } catch (e: Exception) { null }

    /**
     * Shared direct buffer for I/O — no GC pressure.
     */
    fun <R> withSharedDirectBuffer(block: (ByteBuffer) -> R): R {
        synchronized(sharedDirectBufferLock) {
            sharedDirectBuffer.clear()
            return block(sharedDirectBuffer)
        }
    }

    /**
     * Read file header for MIME detection — no per-file ByteArray allocation.
     */
    fun readFileHeader(path: String, headerSize: Int = 16): ByteArray? =
        bufferPool.smallBufferPool.use { buffer ->
            try {
                FileInputStream(path).use { fis ->
                    val read = fis.read(buffer, 0, minOf(headerSize, buffer.size))
                    if (read > 0) buffer.copyOfRange(0, read) else null
                }
            } catch (e: Exception) { null }
        }

    /**
     * Copy file via zero-copy channel transfer — OS-level, no user-space buffer.
     */
    fun copyFileZeroCopy(
        sourcePath: String,
        destPath: String,
        progressCallback: ((Long, Long) -> Unit)? = null,
    ): Boolean = try {
        FileInputStream(sourcePath).channel.use { src ->
            java.io.FileOutputStream(destPath).channel.use { dst ->
                val totalSize = src.size()
                var transferred = 0L
                val chunkSize = 64 * 1024L
                while (transferred < totalSize) {
                    val toTransfer = minOf(chunkSize, totalSize - transferred)
                    val done = dst.transferFrom(src, transferred, toTransfer)
                    if (done <= 0) break
                    transferred += done
                    progressCallback?.invoke(transferred, totalSize)
                }
                transferred >= totalSize
            }
        }
    } catch (e: Exception) { false }
}

data class FileMeta(val size: Long, val headerBytes: ByteArray?)

package com.titan.filemanager.data.memory.pressure

import android.content.ComponentCallbacks2
import android.content.res.Configuration
import com.titan.filemanager.data.memory.buffer.SharedBufferPool
import com.titan.filemanager.data.memory.compressed.CompressedMetadataStore
import com.titan.filemanager.data.memory.gc.GCReductionManager
import com.titan.filemanager.data.memory.pool.ObjectPoolManager
import timber.log.Timber

/**
 * Memory Pressure Handler — Android ComponentCallbacks2 integration.
 *
 * Responds to system memory pressure by releasing caches/pools
 * in order of priority.
 *
 * Technique #100: GC reduction (avoid OOM)
 * Technique #158: Low-memory mode
 */
class MemoryPressureHandler(
    private val poolManager: ObjectPoolManager,
    private val sharedBufferPool: SharedBufferPool,
    private val compressedStore: CompressedMetadataStore,
    private val gcManager: GCReductionManager,
) : ComponentCallbacks2 {

    override fun onTrimMemory(level: Int) {
        when (level) {
            ComponentCallbacks2.TRIM_MEMORY_RUNNING_MODERATE -> {
                Timber.d("TRIM_MEMORY_RUNNING_MODERATE")
                poolManager.fileItemPool.clearSoftPool()
            }
            ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW -> {
                Timber.w("TRIM_MEMORY_RUNNING_LOW")
                poolManager.clearOnLowMemory()
                sharedBufferPool.releaseAll()
            }
            ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL -> {
                Timber.e("TRIM_MEMORY_RUNNING_CRITICAL")
                poolManager.clearOnLowMemory()
                sharedBufferPool.releaseAll()
                compressedStore.clear()
                System.gc()
            }
            ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN -> {
                Timber.d("TRIM_MEMORY_UI_HIDDEN")
                gcManager.onAppBackground()
            }
            ComponentCallbacks2.TRIM_MEMORY_BACKGROUND -> {
                Timber.d("TRIM_MEMORY_BACKGROUND")
                poolManager.clearOnLowMemory()
                compressedStore.clear()
            }
            ComponentCallbacks2.TRIM_MEMORY_MODERATE -> {
                Timber.w("TRIM_MEMORY_MODERATE")
                poolManager.clearOnLowMemory()
                sharedBufferPool.releaseAll()
                compressedStore.clear()
            }
            ComponentCallbacks2.TRIM_MEMORY_COMPLETE -> {
                Timber.e("TRIM_MEMORY_COMPLETE — releasing everything")
                poolManager.clearOnLowMemory()
                sharedBufferPool.releaseAll()
                compressedStore.clear()
                System.gc()
            }
        }
    }

    override fun onLowMemory() {
        Timber.e("onLowMemory — emergency release")
        poolManager.clearOnLowMemory()
        sharedBufferPool.releaseAll()
        compressedStore.clear()
        System.gc()
    }

    override fun onConfigurationChanged(newConfig: Configuration) { /* no-op */ }
}

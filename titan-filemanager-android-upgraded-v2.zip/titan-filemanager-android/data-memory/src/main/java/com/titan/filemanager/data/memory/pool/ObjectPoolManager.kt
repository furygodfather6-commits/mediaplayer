package com.titan.filemanager.data.memory.pool

import com.titan.filemanager.core.model.file.FileItem
import java.util.concurrent.ConcurrentLinkedDeque
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.lang.ref.SoftReference

/**
 * Generic Object Pool — Hot Pool + Soft Pool architecture.
 *
 * Hot Pool: ConcurrentLinkedDeque — lock-free, always available
 * Soft Pool: SoftReference — GC can reclaim under pressure
 *
 * Borrow priority: Hot → Soft → Create New
 *
 * Technique #93: Object pooling
 * Technique #97: Memory pooling
 * Technique #100: GC reduction
 */
class ObjectPool<T>(
    private val factory: () -> T,
    private val reset: (T) -> Unit,
    private val maxSize: Int = 100,
    private val softMaxSize: Int = 500,
    private val name: String = "Pool",
) {
    private val hotPool = ConcurrentLinkedDeque<T>()
    private val softPool = ConcurrentLinkedDeque<SoftReference<T>>()

    private val borrowCount = AtomicLong(0)
    private val returnCount = AtomicLong(0)
    private val createCount = AtomicLong(0)
    private val hotHits = AtomicLong(0)
    private val softHits = AtomicLong(0)
    private val misses = AtomicLong(0)
    private val currentHotSize = AtomicInteger(0)

    fun borrow(): T {
        borrowCount.incrementAndGet()

        // 1. Hot pool (fastest)
        hotPool.pollFirst()?.let {
            currentHotSize.decrementAndGet()
            hotHits.incrementAndGet()
            return it
        }

        // 2. Soft pool (GC-friendly fallback)
        while (true) {
            val ref = softPool.pollFirst() ?: break
            ref.get()?.let {
                softHits.incrementAndGet()
                return it
            }
            // Soft ref was GC'd — try next
        }

        // 3. Create new (cache miss)
        misses.incrementAndGet()
        createCount.incrementAndGet()
        return factory()
    }

    fun returnToPool(item: T) {
        returnCount.incrementAndGet()
        reset(item)

        val hotSize = currentHotSize.get()
        when {
            hotSize < maxSize -> {
                hotPool.addFirst(item)
                currentHotSize.incrementAndGet()
            }
            softPool.size < softMaxSize -> {
                softPool.addFirst(SoftReference(item))
            }
            // Both full → let GC handle
        }
    }

    fun borrowBatch(count: Int): List<T> =
        ArrayList<T>(count).apply { repeat(count) { add(borrow()) } }

    fun returnBatch(items: List<T>) { items.forEach { returnToPool(it) } }

    inline fun <R> use(block: (T) -> R): R {
        val item = borrow()
        return try { block(item) } finally { returnToPool(item) }
    }

    fun clearSoftPool() { softPool.clear() }

    fun clear() {
        hotPool.clear()
        softPool.clear()
        currentHotSize.set(0)
    }

    fun getStats(): PoolStats {
        val total = borrowCount.get()
        return PoolStats(
            name = name,
            hotPoolSize = currentHotSize.get(),
            softPoolSize = softPool.size,
            totalBorrows = total,
            totalReturns = returnCount.get(),
            totalCreated = createCount.get(),
            hotHitRate = if (total > 0) hotHits.get().toFloat() / total else 0f,
            softHitRate = if (total > 0) softHits.get().toFloat() / total else 0f,
            missRate = if (total > 0) misses.get().toFloat() / total else 0f,
        )
    }
}

/**
 * Specialized ByteArray pool for I/O buffers.
 * Zeroes out data before returning (security).
 */
class ByteArrayPool(
    val bufferSize: Int,
    private val maxSize: Int,
    private val name: String,
) {
    private val pool = ConcurrentLinkedDeque<ByteArray>()
    private val currentSize = AtomicInteger(0)
    private val borrowCount = AtomicLong(0)
    private val hitCount = AtomicLong(0)

    fun borrow(): ByteArray {
        borrowCount.incrementAndGet()
        return pool.pollFirst()?.let {
            currentSize.decrementAndGet()
            hitCount.incrementAndGet()
            it
        } ?: ByteArray(bufferSize)
    }

    fun returnToPool(buffer: ByteArray) {
        if (buffer.size != bufferSize || currentSize.get() >= maxSize) return
        buffer.fill(0) // Zero out sensitive data
        pool.addFirst(buffer)
        currentSize.incrementAndGet()
    }

    inline fun <R> use(block: (ByteArray) -> R): R {
        val buf = borrow()
        return try { block(buf) } finally { returnToPool(buf) }
    }

    fun clear() { pool.clear(); currentSize.set(0) }

    fun getStats(): PoolStats {
        val total = borrowCount.get()
        return PoolStats(
            name = name,
            hotPoolSize = currentSize.get(),
            softPoolSize = 0,
            totalBorrows = total,
            totalReturns = 0,
            totalCreated = total - hitCount.get(),
            hotHitRate = if (total > 0) hitCount.get().toFloat() / total else 0f,
            softHitRate = 0f,
            missRate = if (total > 0) (total - hitCount.get()).toFloat() / total else 0f,
        )
    }
}

data class PoolStats(
    val name: String,
    val hotPoolSize: Int,
    val softPoolSize: Int,
    val totalBorrows: Long,
    val totalReturns: Long,
    val totalCreated: Long,
    val hotHitRate: Float,
    val softHitRate: Float,
    val missRate: Float,
)

/**
 * Master pool manager — owns all pools.
 *
 * Pools:
 *   - FileItem pool (2000 hot + 5000 soft)
 *   - Small buffer pool (8KB × 50)
 *   - Large buffer pool (64KB × 20)
 *   - StringBuilder pool (512-cap × 50)
 *   - ArrayList pool (100-cap × 30)
 */
class ObjectPoolManager {

    val fileItemPool = ObjectPool(
        factory = { PooledFileItem() },
        reset = { it.reset() },
        maxSize = 2000,
        softMaxSize = 5000,
        name = "FileItemPool",
    )

    val smallBufferPool = ByteArrayPool(8 * 1024, 50, "SmallBufferPool")
    val largeBufferPool = ByteArrayPool(64 * 1024, 20, "LargeBufferPool")

    val stringBuilderPool = ObjectPool(
        factory = { StringBuilder(512) },
        reset = { it.clear() },
        maxSize = 50,
        name = "StringBuilderPool",
    )

    val listPool = ObjectPool(
        factory = { ArrayList<PooledFileItem>(100) },
        reset = { it.clear() },
        maxSize = 30,
        name = "ArrayListPool",
    )

    fun borrowFileItems(count: Int): List<PooledFileItem> =
        fileItemPool.borrowBatch(count)

    fun returnFileItems(items: List<PooledFileItem>) =
        fileItemPool.returnBatch(items)

    fun getPoolStats(): Map<String, PoolStats> = mapOf(
        "fileItem" to fileItemPool.getStats(),
        "smallBuffer" to smallBufferPool.getStats(),
        "largeBuffer" to largeBufferPool.getStats(),
        "stringBuilder" to stringBuilderPool.getStats(),
    )

    fun clearOnLowMemory() {
        fileItemPool.clearSoftPool()
        smallBufferPool.clear()
        largeBufferPool.clear()
        stringBuilderPool.clearSoftPool()
    }
}

package com.titan.filemanager.data.memory.buffer

import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentLinkedDeque
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * Shared Buffer Pool — 5-tier (TINY → HUGE) + off-heap DirectByteBuffer.
 *
 * All components (scanner, thumbnail engine, database) share the SAME pool
 * = less total memory used.
 *
 * Technique #96: Shared buffers
 * Technique #97: Memory pooling
 * Technique #99: Avoid temporary allocations
 */
class SharedBufferPool {

    enum class Tier(val size: Int, val poolSize: Int) {
        TINY(256, 100),
        SMALL(8 * 1024, 50),
        MEDIUM(64 * 1024, 20),
        LARGE(512 * 1024, 10),
        HUGE(4 * 1024 * 1024, 3),
    }

    private val tierPools = Tier.values().associateWith { BufferTierPool(it) }

    // Off-heap direct buffer pool — NOT GC'd
    private val directBufferPool = ConcurrentLinkedDeque<ByteBuffer>()
    private val directPoolSize = AtomicInteger(0)
    private val totalAllocatedBytes = AtomicLong(0L)

    companion object {
        private const val MAX_DIRECT_BUFFERS = 10
        private const val DIRECT_BUFFER_SIZE = 2 * 1024 * 1024 // 2MB
    }

    fun acquire(neededBytes: Int): PooledBuffer {
        val tier = selectTier(neededBytes)
        return tierPools[tier]!!.acquire(tier)
    }

    fun acquireDirectBuffer(): ByteBuffer {
        directBufferPool.pollFirst()?.let {
            directPoolSize.decrementAndGet()
            it.clear()
            return it
        }
        totalAllocatedBytes.addAndGet(DIRECT_BUFFER_SIZE.toLong())
        return ByteBuffer.allocateDirect(DIRECT_BUFFER_SIZE)
    }

    fun releaseDirectBuffer(buffer: ByteBuffer) {
        if (!buffer.isDirect) return
        buffer.clear()
        if (directPoolSize.get() < MAX_DIRECT_BUFFERS) {
            directBufferPool.addFirst(buffer)
            directPoolSize.incrementAndGet()
        }
    }

    inline fun <R> withBuffer(neededBytes: Int, block: (ByteArray) -> R): R {
        val pooled = acquire(neededBytes)
        return try { block(pooled.data) } finally { pooled.release() }
    }

    inline fun <R> withDirectBuffer(block: (ByteBuffer) -> R): R {
        val buf = acquireDirectBuffer()
        return try { block(buf) } finally { releaseDirectBuffer(buf) }
    }

    fun getStats() = SharedBufferStats(
        tierStats = tierPools.map { (tier, pool) -> tier.name to pool.getStats() }.toMap(),
        directBuffersAvailable = directPoolSize.get(),
        totalAllocatedBytes = totalAllocatedBytes.get(),
    )

    fun releaseAll() {
        tierPools.values.forEach { it.clear() }
        directBufferPool.clear()
        directPoolSize.set(0)
    }

    private fun selectTier(needed: Int): Tier = when {
        needed <= Tier.TINY.size -> Tier.TINY
        needed <= Tier.SMALL.size -> Tier.SMALL
        needed <= Tier.MEDIUM.size -> Tier.MEDIUM
        needed <= Tier.LARGE.size -> Tier.LARGE
        else -> Tier.HUGE
    }
}

class BufferTierPool(private val tier: SharedBufferPool.Tier) {
    private val available = ConcurrentLinkedDeque<ByteArray>()
    private val pooledCount = AtomicInteger(0)
    private val borrowCount = AtomicLong(0)
    private val hitCount = AtomicLong(0)

    fun acquire(tier: SharedBufferPool.Tier): PooledBuffer {
        borrowCount.incrementAndGet()
        available.pollFirst()?.let {
            pooledCount.decrementAndGet()
            hitCount.incrementAndGet()
            return PooledBuffer(it, this)
        }
        return PooledBuffer(ByteArray(tier.size), this)
    }

    fun release(buffer: ByteArray) {
        if (pooledCount.get() < tier.poolSize) {
            buffer.fill(0, 0, minOf(64, buffer.size))
            available.addFirst(buffer)
            pooledCount.incrementAndGet()
        }
    }

    fun clear() { available.clear(); pooledCount.set(0) }

    fun getStats() = TierStats(
        tierSize = tier.size,
        pooled = pooledCount.get(),
        maxPooled = tier.poolSize,
        hitRate = if (borrowCount.get() > 0) hitCount.get().toFloat() / borrowCount.get() else 0f,
    )
}

class PooledBuffer(val data: ByteArray, private val pool: BufferTierPool) : AutoCloseable {
    private var released = false
    fun release() { if (!released) { released = true; pool.release(data) } }
    override fun close() = release()
}

data class SharedBufferStats(
    val tierStats: Map<String, TierStats>,
    val directBuffersAvailable: Int,
    val totalAllocatedBytes: Long,
)

data class TierStats(val tierSize: Int, val pooled: Int, val maxPooled: Int, val hitRate: Float)

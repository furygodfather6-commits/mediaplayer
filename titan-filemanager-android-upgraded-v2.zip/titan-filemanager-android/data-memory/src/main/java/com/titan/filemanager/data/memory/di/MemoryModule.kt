package com.titan.filemanager.data.memory.di

import android.content.Context
import com.titan.filemanager.data.memory.engine.MemoryOptimizationEngine
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object MemoryModule {

    @Provides
    @Singleton
    fun provideMemoryOptimizationEngine(
        @ApplicationContext context: Context,
    ): MemoryOptimizationEngine {
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
        return MemoryOptimizationEngine(context, scope).also { it.initialize() }
    }
}

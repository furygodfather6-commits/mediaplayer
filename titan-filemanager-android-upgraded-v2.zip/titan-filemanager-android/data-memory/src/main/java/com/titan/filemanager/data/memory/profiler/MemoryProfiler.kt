package com.titan.filemanager.data.memory.profiler

import android.os.Debug
import timber.log.Timber
import java.util.concurrent.ConcurrentLinkedDeque
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Memory Profiler — tracks usage patterns to detect leaks + allocation spikes.
 *
 * Technique #138: Memory profiling
 * Technique #141: Automatic tuning
 */
class MemoryProfiler {

    companion object {
        private const val TAG = "MemProfiler"
        private const val MAX_SAMPLES = 100
    }

    private val samples = ConcurrentLinkedDeque<MemorySample>()
    private val isRunning = AtomicBoolean(false)

    fun startProfiling() { isRunning.set(true) }
    fun stopProfiling() { isRunning.set(false) }

    fun takeSample(label: String) {
        if (!isRunning.get()) return
        val runtime = Runtime.getRuntime()
        val sample = MemorySample(
            label = label,
            heapUsed = runtime.totalMemory() - runtime.freeMemory(),
            heapTotal = runtime.totalMemory(),
            heapMax = runtime.maxMemory(),
            nativeHeap = Debug.getNativeHeapAllocatedSize(),
            timestamp = System.currentTimeMillis(),
        )
        samples.addLast(sample)
        if (samples.size > MAX_SAMPLES) samples.removeFirst()
        Timber.d("[$label] Heap: ${sample.heapUsedMB}MB/${sample.heapTotalMB}MB Native: ${sample.nativeHeapMB}MB")
    }

    /**
     * Detect memory leak: heap keeps growing across multiple scans.
     */
    fun detectLeak(): Boolean {
        val recent = samples.toList().takeLast(10)
        if (recent.size < 5) return false
        val first = recent.first().heapUsed
        val last = recent.last().heapUsed
        val growthRate = (last - first).toFloat() / first
        if (growthRate > 0.5f) {
            Timber.e("POTENTIAL LEAK: ${first / 1024 / 1024}MB → ${last / 1024 / 1024}MB " +
                "(${"%.1f".format(growthRate * 100)}% growth)")
            return true
        }
        return false
    }

    fun getReport(): MemoryReport {
        val all = samples.toList()
        if (all.isEmpty()) return MemoryReport(0, 0, 0, 0, false)
        return MemoryReport(
            avgHeapMB = all.map { it.heapUsedMB }.average().toInt(),
            maxHeapMB = all.maxOf { it.heapUsedMB },
            minHeapMB = all.minOf { it.heapUsedMB },
            avgNativeMB = all.map { it.nativeHeapMB }.average().toInt(),
            possibleLeak = detectLeak(),
        )
    }
}

data class MemorySample(
    val label: String, val heapUsed: Long, val heapTotal: Long,
    val heapMax: Long, val nativeHeap: Long, val timestamp: Long,
) {
    val heapUsedMB get() = (heapUsed / 1024 / 1024).toInt()
    val heapTotalMB get() = (heapTotal / 1024 / 1024).toInt()
    val nativeHeapMB get() = (nativeHeap / 1024 / 1024).toInt()
}

data class MemoryReport(
    val avgHeapMB: Int, val maxHeapMB: Int,
    val minHeapMB: Int, val avgNativeMB: Int, val possibleLeak: Boolean,
)

package com.titan.filemanager.data.memory.compressed

import com.titan.filemanager.core.model.file.FileItem
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap
import java.util.zip.Deflater
import java.util.zip.DeflaterOutputStream
import java.util.zip.InflaterInputStream

/**
 * Compressed Metadata Store — L2 cache with GZIP compression.
 *
 * Problem: 10,000+ FileItems in RAM = hundreds of MB
 * Solution: Compress metadata, decompress on access
 *
 * Compression ratio: ~5-10× for text-heavy metadata
 * Trade-off: CPU for decompression (~1-2ms) vs RAM saved (5-10×)
 *
 * Technique #98: Compressed metadata
 */
class CompressedMetadataStore {

    private val store = ConcurrentHashMap<String, CompressedEntry>()

    companion object {
        private const val MAGIC = 0xFEFE0001.toInt()
        private const val VERSION = 1
        private const val COMPRESSION_LEVEL = Deflater.BEST_SPEED
        private const val TTL_MS = 10 * 60 * 1000L // 10 minutes
    }

    fun store(path: String, items: List<FileItem>) {
        val compressed = compress(items)
        store[path] = CompressedEntry(
            data = compressed,
            itemCount = items.size,
            originalSizeEstimate = estimateUncompressedSize(items),
            timestamp = System.currentTimeMillis(),
        )
    }

    fun retrieve(path: String): List<FileItem>? {
        val entry = store[path] ?: return null
        if (System.currentTimeMillis() - entry.timestamp > TTL_MS) {
            store.remove(path)
            return null
        }
        return decompress(entry.data, entry.itemCount)
    }

    fun remove(path: String) { store.remove(path) }
    fun clear() { store.clear() }

    fun getTotalCompressedBytes(): Long = store.values.sumOf { it.data.size.toLong() }

    fun getCompressionRatio(path: String): Float {
        val entry = store[path] ?: return 0f
        return if (entry.data.isNotEmpty()) entry.originalSizeEstimate.toFloat() / entry.data.size else 0f
    }

    // ─── Binary Serialization (faster than JSON/Protobuf) ──────

    private fun serialize(items: List<FileItem>): ByteArray {
        val buf = ByteArrayOutputStream(items.size * 128)
        val bb = ByteBuffer.allocate(32)

        // Header
        bb.clear(); bb.putInt(MAGIC); bb.putInt(VERSION); bb.putInt(items.size)
        buf.write(bb.array(), 0, 12)

        for (item in items) {
            bb.clear()
            bb.putLong(item.stableId)        // 8
            bb.putLong(item.size)            // 8
            bb.putLong(item.modifiedAt)      // 8
            var flags = 0
            if (item.isDirectory) flags = flags or 0x01
            if (item.isHidden) flags = flags or 0x02
            bb.put(flags.toByte())           // 1
            buf.write(bb.array(), 0, 25)

            writeLengthPrefixed(buf, item.name.toByteArray(Charsets.UTF_8))
            writeLengthPrefixed(buf, item.path.toByteArray(Charsets.UTF_8))
            val mime = item.mimeType?.toByteArray(Charsets.UTF_8) ?: ByteArray(0)
            buf.write(mime.size.toByte().toInt()); buf.write(mime)
        }
        return buf.toByteArray()
    }

    private fun deserialize(data: ByteArray): List<FileItem> {
        val buf = ByteBuffer.wrap(data)
        if (buf.int != MAGIC) return emptyList()
        buf.int // version
        val count = buf.int
        val items = ArrayList<FileItem>(count)

        repeat(count) {
            val id = buf.long; val size = buf.long; val lastMod = buf.long
            val flags = buf.get().toInt()
            val isDir = (flags and 0x01) != 0; val isHidden = (flags and 0x02) != 0

            val name = readLengthPrefixed(buf)
            val path = readLengthPrefixed(buf)
            val mimeLen = buf.get().toInt() and 0xFF
            val mime = if (mimeLen > 0) {
                val b = ByteArray(mimeLen); buf.get(b); String(b, Charsets.UTF_8)
            } else null

            items.add(FileItem(
                path = path, name = name, stableId = id, size = size,
                modifiedAt = lastMod, isDirectory = isDir, mimeType = mime, isHidden = isHidden,
            ))
        }
        return items
    }

    private fun writeLengthPrefixed(buf: ByteArrayOutputStream, bytes: ByteArray) {
        buf.write((bytes.size shr 8).toByte().toInt())
        buf.write(bytes.size.toByte().toInt())
        buf.write(bytes)
    }

    private fun readLengthPrefixed(buf: ByteBuffer): String {
        val len = ((buf.get().toInt() and 0xFF) shl 8) or (buf.get().toInt() and 0xFF)
        val b = ByteArray(len); buf.get(b)
        return String(b, Charsets.UTF_8)
    }

    private fun compress(items: List<FileItem>): ByteArray {
        val serialized = serialize(items)
        val out = ByteArrayOutputStream(serialized.size / 3)
        val deflater = Deflater(COMPRESSION_LEVEL)
        DeflaterOutputStream(out, deflater).use { it.write(serialized) }
        deflater.end()
        return out.toByteArray()
    }

    private fun decompress(data: ByteArray, expectedCount: Int): List<FileItem>? = try {
        val out = ByteArrayOutputStream(expectedCount * 128)
        InflaterInputStream(ByteArrayInputStream(data)).use { it.copyTo(out) }
        deserialize(out.toByteArray())
    } catch (e: Exception) { null }

    private fun estimateUncompressedSize(items: List<FileItem>): Int =
        items.sumOf { 25 + it.name.length + it.path.length + (it.mimeType?.length ?: 0) }

    data class CompressedEntry(
        val data: ByteArray,
        val itemCount: Int,
        val originalSizeEstimate: Int,
        val timestamp: Long,
    ) {
        val compressionRatio: Float
            get() = if (data.isNotEmpty()) originalSizeEstimate.toFloat() / data.size else 0f
    }
}

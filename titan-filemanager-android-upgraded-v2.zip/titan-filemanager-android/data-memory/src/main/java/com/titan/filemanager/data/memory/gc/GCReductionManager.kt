package com.titan.filemanager.data.memory.gc

import android.app.ActivityManager
import android.content.Context
import android.os.Debug
import com.titan.filemanager.data.memory.pool.ObjectPoolManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import timber.log.Timber
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * GC Reduction Manager — safe-point GC + monitoring + pool compaction.
 *
 * Strategy:
 *   1. Minimize allocations in hot paths (done via pooling)
 *   2. Pre-allocate before intensive operations
 *   3. Force GC at safe moments (between navigations)
 *   4. Monitor GC frequency
 *   5. Trigger pool cleanup before GC runs
 *
 * Technique #100: GC reduction
 * Technique #138: Memory profiling
 */
class GCReductionManager(
    private val context: Context,
    private val poolManager: ObjectPoolManager,
    private val scope: CoroutineScope,
) {
    companion object {
        private const val TAG = "GCReductionManager"
        private const val GC_MONITOR_INTERVAL_MS = 5000L
        private const val LOW_MEMORY_THRESHOLD_MB = 50
    }

    private val activityManager =
        context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private val isMonitoring = AtomicBoolean(false)
    private val forcedGCCount = AtomicLong(0)
    private val lastGCTime = AtomicLong(0L)

    fun onSafePointNavigationStart(fromPath: String) {
        scope.launch(Dispatchers.Default) {
            Timber.d("Safe point: navigation from $fromPath")
            val memInfo = getMemoryInfo()
            if (memInfo.availableMB < LOW_MEMORY_THRESHOLD_MB) {
                performSafeGC("LowMemory at navigation")
            }
            compactPools()
        }
    }

    fun onAppBackground() {
        scope.launch(Dispatchers.Default) {
            Timber.d("Background: aggressive cleanup")
            poolManager.clearOnLowMemory()
            System.gc()
            forcedGCCount.incrementAndGet()
            lastGCTime.set(System.currentTimeMillis())
        }
    }

    fun onScrollIdle() {
        val timeSinceLastGC = System.currentTimeMillis() - lastGCTime.get()
        if (timeSinceLastGC > 30_000) {
            scope.launch(Dispatchers.Default) { compactPools() }
        }
    }

    fun startMonitoring() {
        if (isMonitoring.compareAndSet(false, true)) {
            scope.launch {
                while (isMonitoring.get()) {
                    checkMemoryPressure()
                    delay(GC_MONITOR_INTERVAL_MS)
                }
            }
        }
    }

    fun stopMonitoring() { isMonitoring.set(false) }

    private suspend fun checkMemoryPressure() {
        val memInfo = getMemoryInfo()
        when {
            memInfo.availableMB < 20 -> {
                Timber.w("CRITICAL memory: ${memInfo.availableMB}MB")
                poolManager.clearOnLowMemory()
                performSafeGC("CriticalMemory")
            }
            memInfo.availableMB < LOW_MEMORY_THRESHOLD_MB -> {
                Timber.w("LOW memory: ${memInfo.availableMB}MB")
                poolManager.clearOnLowMemory()
            }
        }
    }

    fun <R> measureAllocations(tag: String, block: () -> R): R {
        val before = Debug.getRuntimeStat("art.gc.bytes-allocated")?.toLongOrNull() ?: 0L
        val result = block()
        val after = Debug.getRuntimeStat("art.gc.bytes-allocated")?.toLongOrNull() ?: 0L
        val allocated = after - before
        if (allocated > 1024 * 1024) Timber.w("HIGH ALLOCATION in '$tag': ${allocated / 1024}KB")
        return result
    }

    fun getGCStats(): GCStats {
        return GCStats(
            gcCount = Debug.getRuntimeStat("art.gc.gc-count")?.toIntOrNull() ?: 0,
            totalGCTimeMs = Debug.getRuntimeStat("art.gc.gc-time")?.toLongOrNull() ?: 0L,
            bytesAllocated = Debug.getRuntimeStat("art.gc.bytes-allocated")?.toLongOrNull() ?: 0L,
            bytesFreed = Debug.getRuntimeStat("art.gc.bytes-freed")?.toLongOrNull() ?: 0L,
            forcedGCCount = forcedGCCount.get(),
        )
    }

    private fun compactPools() {
        val stats = poolManager.getPoolStats()
        stats.forEach { (name, stat) ->
            Timber.v("Pool[$name]: hot=${stat.hotPoolSize} soft=${stat.softPoolSize} " +
                "hitRate=${"%.1f".format(stat.hotHitRate * 100)}%")
        }
    }

    private fun performSafeGC(reason: String) {
        Timber.d("Performing GC: $reason")
        System.gc(); System.runFinalization()
        forcedGCCount.incrementAndGet()
        lastGCTime.set(System.currentTimeMillis())
    }

    private fun getMemoryInfo(): AppMemoryInfo {
        val info = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(info)
        val runtime = Runtime.getRuntime()
        return AppMemoryInfo(
            availableMB = (info.availMem / 1024 / 1024).toInt(),
            isLowMemory = info.lowMemory,
            heapUsedMB = ((runtime.totalMemory() - runtime.freeMemory()) / 1024 / 1024).toInt(),
            heapMaxMB = (runtime.maxMemory() / 1024 / 1024).toInt(),
        )
    }
}

data class GCStats(
    val gcCount: Int, val totalGCTimeMs: Long,
    val bytesAllocated: Long, val bytesFreed: Long,
    val forcedGCCount: Long,
)

data class AppMemoryInfo(
    val availableMB: Int, val isLowMemory: Boolean,
    val heapUsedMB: Int, val heapMaxMB: Int,
)

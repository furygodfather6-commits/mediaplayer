package com.titan.filemanager.data.memory.pool

import com.titan.filemanager.core.model.file.FileItem
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/**
 * Memory-Optimized FileItem — mutable, pool-aware, bit-packed flags.
 *
 * Design decisions:
 *   - Mutable fields instead of data class copy() → no GC pressure on update
 *   - Primitive types only → no boxing/unboxing overhead
 *   - Fixed-size char arrays for strings → avoids String creation in hot paths
 *   - Bit-packed flags (1 byte = 8 booleans) → cache-line friendly
 *
 * Technique #93: Object pooling
 * Technique #99: Avoid temporary allocations
 * Technique #100: GC reduction
 */
class PooledFileItem {

    var id: Long = 0L
    var nameHash: Int = 0

    // Zero-copy string storage
    private val nameBuffer = CharArray(256)
    private val pathBuffer = CharArray(4096)
    var nameLength: Int = 0
    var pathLength: Int = 0

    // Primitive metadata
    var size: Long = -1L
    var lastModified: Long = 0L
    var inodeNumber: Long = 0L

    // Bit-packed flags: [hidden|dir|symlink|metaLoaded|phase0|phase1|phase2|reserved]
    var flags: Byte = 0

    // Extension (short string — pooled)
    private val extBuffer = CharArray(16)
    var extLength: Int = 0

    // Lazy/optional fields
    var mimeType: String? = null
    var childCount: Int = -1
    var thumbnailKey: Long = 0L

    // Pool management
    val isInPool = AtomicBoolean(true)
    val borrowCount = AtomicInteger(0)
    var poolReturnTime: Long = 0L

    companion object {
        const val FLAG_HIDDEN: Byte = 0x01
        const val FLAG_DIRECTORY: Byte = 0x02
        const val FLAG_SYMLINK: Byte = 0x04
        const val FLAG_META_LOADED: Byte = 0x08
        const val FLAG_PHASE0: Byte = 0x10
        const val FLAG_PHASE1: Byte = 0x20
        const val FLAG_PHASE2: Byte = 0x40
    }

    var isDirectory: Boolean
        get() = (flags.toInt() and FLAG_DIRECTORY.toInt()) != 0
        set(value) { flags = if (value) (flags.toInt() or FLAG_DIRECTORY.toInt()).toByte()
                      else (flags.toInt() and FLAG_DIRECTORY.toInt().inv()).toByte() }

    var isHidden: Boolean
        get() = (flags.toInt() and FLAG_HIDDEN.toInt()) != 0
        set(value) { flags = if (value) (flags.toInt() or FLAG_HIDDEN.toInt()).toByte()
                      else (flags.toInt() and FLAG_HIDDEN.toInt().inv()).toByte() }

    var isSymlink: Boolean
        get() = (flags.toInt() and FLAG_SYMLINK.toInt()) != 0
        set(value) { flags = if (value) (flags.toInt() or FLAG_SYMLINK.toInt()).toByte()
                      else (flags.toInt() and FLAG_SYMLINK.toInt().inv()).toByte() }

    var isMetadataLoaded: Boolean
        get() = (flags.toInt() and FLAG_META_LOADED.toInt()) != 0
        set(value) { flags = if (value) (flags.toInt() or FLAG_META_LOADED.toInt()).toByte()
                      else (flags.toInt() and FLAG_META_LOADED.toInt().inv()).toByte() }

    // String access — creates String only when needed
    val name: String get() = String(nameBuffer, 0, nameLength)
    val path: String get() = String(pathBuffer, 0, pathLength)
    val extension: String get() = if (extLength > 0) String(extBuffer, 0, extLength) else ""

    // Zero-copy name setter — writes into char buffer + extracts extension inline
    fun setName(value: String) {
        val len = minOf(value.length, nameBuffer.size - 1)
        value.toCharArray(nameBuffer, 0, 0, len)
        nameLength = len
        nameHash = value.hashCode()

        // Extract extension inline — no substring allocation
        val dotIdx = value.lastIndexOf('.')
        if (dotIdx > 0 && dotIdx < value.length - 1) {
            val extLen = minOf(value.length - dotIdx - 1, extBuffer.size - 1)
            value.toCharArray(extBuffer, 0, dotIdx + 1, dotIdx + 1 + extLen)
            // Lowercase in-place
            for (i in 0 until extLen) extBuffer[i] = extBuffer[i].lowercaseChar()
            extLength = extLen
        } else {
            extLength = 0
        }
    }

    fun setPath(value: String) {
        val len = minOf(value.length, pathBuffer.size - 1)
        value.toCharArray(pathBuffer, 0, 0, len)
        pathLength = len
    }

    // Reset for pool reuse
    fun reset() {
        id = 0L; nameHash = 0; nameLength = 0; pathLength = 0
        size = -1L; lastModified = 0L; inodeNumber = 0L
        flags = 0; extLength = 0; mimeType = null
        childCount = -1; thumbnailKey = 0L
        poolReturnTime = System.currentTimeMillis()
    }

    // Copy to immutable snapshot
    fun toFileItem(): FileItem = FileItem(
        path = path,
        name = name,
        stableId = id,
        size = if (size < 0) 0L else size,
        modifiedAt = lastModified,
        isDirectory = isDirectory,
        mimeType = mimeType,
        isHidden = isHidden,
    )

    fun estimatedBytes(): Int = 256 * 2 + 4096 * 2 + 16 * 2 + 64
}

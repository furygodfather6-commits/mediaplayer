package com.titan.filemanager.data.memory.engine

import android.content.Context
import com.titan.filemanager.core.model.file.FileItem
import com.titan.filemanager.data.memory.arena.MemoryPoolAllocator
import com.titan.filemanager.data.memory.buffer.SharedBufferPool
import com.titan.filemanager.data.memory.compressed.CompressedMetadataStore
import com.titan.filemanager.data.memory.gc.GCReductionManager
import com.titan.filemanager.data.memory.pool.ObjectPoolManager
import com.titan.filemanager.data.memory.pool.PooledFileItem
import com.titan.filemanager.data.memory.pressure.MemoryPressureHandler
import com.titan.filemanager.data.memory.profiler.MemoryProfiler
import com.titan.filemanager.data.memory.recycler.ObjectRecycler
import com.titan.filemanager.data.memory.scanner.ScanResultContainer
import com.titan.filemanager.data.memory.scanner.ZeroAllocationScanner
import com.titan.filemanager.data.memory.zero.ZeroCopyEngine
import kotlinx.coroutines.CoroutineScope
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Master Memory Optimization Engine — single entry point for all memory optimization.
 *
 * Coordinates all Phase J techniques:
 *   #93  Object pooling       → ObjectPoolManager
 *   #94  Object recycling     → ObjectRecycler
 *   #95  Zero-copy            → ZeroCopyEngine
 *   #96  Shared buffers       → SharedBufferPool
 *   #97  Memory pooling       → MemoryPoolAllocator
 *   #98  Compressed metadata  → CompressedMetadataStore
 *   #99  Zero temp alloc      → ZeroAllocationScanner
 *   #100 GC reduction         → GCReductionManager
 */
@Singleton
class MemoryOptimizationEngine @Inject constructor(
    context: Context,
    scope: CoroutineScope,
) {
    val poolManager = ObjectPoolManager()
    val sharedBufferPool = SharedBufferPool()
    val arenaAllocator = MemoryPoolAllocator(2 * 1024 * 1024)
    val objectRecycler = ObjectRecycler(poolManager)
    val zeroCopyEngine = ZeroCopyEngine(poolManager)
    val compressedMetaStore = CompressedMetadataStore()
    val zeroAllocScanner = ZeroAllocationScanner(poolManager, arenaAllocator)
    val gcManager = GCReductionManager(context, poolManager, scope)
    val memoryProfiler = MemoryProfiler()
    val pressureHandler = MemoryPressureHandler(
        poolManager, sharedBufferPool, compressedMetaStore, gcManager,
    )

    fun initialize() {
        gcManager.startMonitoring()
        memoryProfiler.startProfiling()
        memoryProfiler.takeSample("Engine_Init")
    }

    fun onDirectoryLoaded(path: String, items: List<FileItem>) {
        compressedMetaStore.store(path, items)
        memoryProfiler.takeSample("DirLoaded_${path.substringAfterLast('/')}")
    }

    fun onNavigationStart(fromPath: String) {
        gcManager.onSafePointNavigationStart(fromPath)
        arenaAllocator.reset()
    }

    fun onScrollIdle() { gcManager.onScrollIdle() }
    fun onLowMemory() { pressureHandler.onLowMemory() }

    fun destroy() {
        gcManager.stopMonitoring()
        memoryProfiler.stopProfiling()
        poolManager.clearOnLowMemory()
        sharedBufferPool.releaseAll()
        compressedMetaStore.clear()
        arenaAllocator.freeAll()
    }

    /**
     * Scan with full memory optimization.
     * Returns pooled items — caller must release when done.
     */
    fun scanOptimized(
        dirPath: String,
        fileNames: Array<String>,
        existingItems: List<PooledFileItem> = emptyList(),
    ): ScanResultContainer = if (existingItems.isNotEmpty()) {
        val result = objectRecycler.recycleUpdate(existingItems, fileNames, dirPath)
        ScanResultContainer(result.items) { objectRecycler.returnAll(result.items) }
    } else {
        zeroAllocScanner.scanZeroAlloc(dirPath, fileNames)
    }

    fun getFullStats(): MemoryEngineStats = MemoryEngineStats(
        poolStats = poolManager.getPoolStats(),
        bufferStats = sharedBufferPool.getStats(),
        arenaStats = arenaAllocator.getStats(),
        recyclerStats = objectRecycler.getStats(),
        gcStats = gcManager.getGCStats(),
        memoryReport = memoryProfiler.getReport(),
        compressedCacheBytes = compressedMetaStore.getTotalCompressedBytes(),
    )
}

data class MemoryEngineStats(
    val poolStats: Map<String, com.titan.filemanager.data.memory.pool.PoolStats>,
    val bufferStats: com.titan.filemanager.data.memory.buffer.SharedBufferStats,
    val arenaStats: com.titan.filemanager.data.memory.arena.ArenaStats,
    val recyclerStats: com.titan.filemanager.data.memory.recycler.RecyclerStats,
    val gcStats: com.titan.filemanager.data.memory.gc.GCStats,
    val memoryReport: com.titan.filemanager.data.memory.profiler.MemoryReport,
    val compressedCacheBytes: Long,
)
